using System;
using System.IO;
using System.Threading;

public class AdvancedFpsUnlocker
{
	private static FileSystemWatcher watcher;

	private static string targetPath;

	public static bool IsActive { get; private set; }

	public static void StartUnlocker()
	{
		if (watcher != null)
		{
			return;
		}
		string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox", "Versions");
		if (!Directory.Exists(path))
		{
			return;
		}
		targetPath = path;
		watcher = new FileSystemWatcher();
		watcher.Path = path;
		watcher.Filter = "*";
		watcher.IncludeSubdirectories = false;
		watcher.Created += delegate
		{
			Thread.Sleep(1000);
			if (IsActive)
			{
				ApplyFpsPatch();
			}
		};
		watcher.EnableRaisingEvents = true;
	}

	public static void SetStatus(bool enabled)
	{
		IsActive = enabled;
		StartUnlocker();
		if (enabled)
		{
			ApplyFpsPatch();
		}
		else
		{
			RemoveFpsPatch();
		}
	}

	private static void ApplyFpsPatch()
	{
		try
		{
			string[] directories = Directory.GetDirectories(targetPath, "version-*");
			foreach (string path in directories)
			{
				if (File.Exists(Path.Combine(path, "RobloxPlayerBeta.exe")))
				{
					string text = Path.Combine(path, "ClientSettings");
					string path2 = Path.Combine(text, "ClientAppSettings.json");
					if (!Directory.Exists(text))
					{
						Directory.CreateDirectory(text);
					}
					string contents = "{\"FFlagGameBasicSettingsFramerateCap5\": \"True\", \"DFIntTaskSchedulerTargetFps\": 9999, \"FIntRomarkStartTestPercent2\": 0}";
					File.WriteAllText(path2, contents);
				}
			}
		}
		catch (Exception)
		{
		}
	}

	private static void RemoveFpsPatch()
	{
		try
		{
			string[] directories = Directory.GetDirectories(targetPath, "version-*");
			for (int i = 0; i < directories.Length; i++)
			{
				string path = Path.Combine(directories[i], "ClientSettings", "ClientAppSettings.json");
				if (File.Exists(path))
				{
					File.Delete(path);
				}
			}
		}
		catch (Exception)
		{
		}
	}
}
