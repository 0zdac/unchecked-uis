-- Fly Hack Script
loadstring(game:HttpGet("https://raw.githubusercontent.com/XNEOK/FlyGuiV3/main/FlyGuiV3.lua"))()
