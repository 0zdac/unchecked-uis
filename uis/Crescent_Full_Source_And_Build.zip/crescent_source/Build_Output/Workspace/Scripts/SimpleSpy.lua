-- SimpleSpy V3 Remote Logger
loadstring(game:HttpGet("https://raw.githubusercontent.com/ex-ser/SimpleSpy/main/SimpleSpy.lua"))()
