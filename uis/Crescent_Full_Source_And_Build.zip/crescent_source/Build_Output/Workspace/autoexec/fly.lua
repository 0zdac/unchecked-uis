-- Autoexec Fly Script
print('UltronX Autoexec Loaded')
