-- UltronX Workspace Script
print('Hello from UltronX Workspace!')
