using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Crescent.Properties;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "18.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Resources
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager
	{
		get
		{
			if (resourceMan == null)
			{
				resourceMan = new ResourceManager("Crescent.Properties.Resources", typeof(Resources).Assembly);
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	internal static Bitmap clear => (Bitmap)ResourceManager.GetObject("clear", resourceCulture);

	internal static Bitmap execute => (Bitmap)ResourceManager.GetObject("execute", resourceCulture);

	internal static Bitmap Gemini_Generated_Image_cizuwccizuwccizu_Photoroom => (Bitmap)ResourceManager.GetObject("Gemini_Generated_Image_cizuwccizuwccizu-Photoroom", resourceCulture);

	internal static Bitmap Gemini_Generated_Image_cizuwccizuwccizu_Photoroom1 => (Bitmap)ResourceManager.GetObject("Gemini_Generated_Image_cizuwccizuwccizu-Photoroom1", resourceCulture);

	internal static Bitmap Gemini_Generated_Image_tepoa4tepoa4tepo_Photoroom => (Bitmap)ResourceManager.GetObject("Gemini_Generated_Image_tepoa4tepoa4tepo_Photoroom", resourceCulture);

	internal static Bitmap Gemini_Generated_Image_wyjdrfwyjdrfwyjd_Photoroom => (Bitmap)ResourceManager.GetObject("Gemini_Generated_Image_wyjdrfwyjdrfwyjd-Photoroom", resourceCulture);

	internal static Bitmap inject => (Bitmap)ResourceManager.GetObject("inject", resourceCulture);

	internal static Bitmap inject1 => (Bitmap)ResourceManager.GetObject("inject1", resourceCulture);

	internal static Bitmap inject2 => (Bitmap)ResourceManager.GetObject("inject2", resourceCulture);

	internal static byte[] JetBrainsMono_Bold => (byte[])ResourceManager.GetObject("JetBrainsMono-Bold", resourceCulture);

	internal static Bitmap kill => (Bitmap)ResourceManager.GetObject("kill", resourceCulture);

	internal static Bitmap kill_rb => (Bitmap)ResourceManager.GetObject("kill rb", resourceCulture);

	internal static Bitmap kill1 => (Bitmap)ResourceManager.GetObject("kill1", resourceCulture);

	internal static Bitmap open => (Bitmap)ResourceManager.GetObject("open", resourceCulture);

	internal static Bitmap save => (Bitmap)ResourceManager.GetObject("save", resourceCulture);

	internal static Bitmap save1 => (Bitmap)ResourceManager.GetObject("save1", resourceCulture);

	internal static Bitmap save2 => (Bitmap)ResourceManager.GetObject("save2", resourceCulture);

	internal static Bitmap script => (Bitmap)ResourceManager.GetObject("script", resourceCulture);

	internal static Bitmap Settings1 => (Bitmap)ResourceManager.GetObject("Settings1", resourceCulture);

	internal static byte[] Shield => (byte[])ResourceManager.GetObject("Shield", resourceCulture);

	internal static Bitmap Spectra => (Bitmap)ResourceManager.GetObject("Spectra", resourceCulture);

	internal static Bitmap Spectra1 => (Bitmap)ResourceManager.GetObject("Spectra1", resourceCulture);

	internal static Bitmap Spectra2 => (Bitmap)ResourceManager.GetObject("Spectra2", resourceCulture);

	internal static Bitmap 儲存腳本 => (Bitmap)ResourceManager.GetObject("儲存腳本", resourceCulture);

	internal static Bitmap 刪除 => (Bitmap)ResourceManager.GetObject("刪除", resourceCulture);

	internal static Bitmap 執行 => (Bitmap)ResourceManager.GetObject("執行", resourceCulture);

	internal static Bitmap 打開腳本 => (Bitmap)ResourceManager.GetObject("打開腳本", resourceCulture);

	internal static Bitmap 注入 => (Bitmap)ResourceManager.GetObject("注入", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_20_121335_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-20 121335-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_22_185157 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-22 185157", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_22_185702_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-22 185702-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_22_185710_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-22 185710-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_26_161551_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-26 161551-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_26_161551_Photoroom1 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-26 161551-Photoroom1", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_26_161840_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-26 161840-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_26_161840_Photoroom1 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-26 161840-Photoroom1", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_26_161840_Photoroom2 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-26 161840-Photoroom2", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_26_203026_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-26 203026-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2025_12_27_154134_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2025-12-27 154134-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_01_151807 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-01 151807", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_01_153307 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-01 153307", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_02_205457 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-02 205457", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_03_155728 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-03 155728", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_14_172813 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-14 172813", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_14_205437 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-14 205437", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_17_172046_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-17 172046-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_17_172353_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-17 172353-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_17_172651_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-17 172651-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_23_172014 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-23 172014", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_23_172547 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-23 172547", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_01_24_062719_Photoroom => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-01-24 062719-Photoroom", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_02_04_210955 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-02-04 210955", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_02_04_211003 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-02-04 211003", resourceCulture);

	internal static Bitmap 螢幕擷取畫面_2026_02_04_211009 => (Bitmap)ResourceManager.GetObject("螢幕擷取畫面 2026-02-04 211009", resourceCulture);

	internal static Bitmap 設定 => (Bitmap)ResourceManager.GetObject("設定", resourceCulture);

	internal Resources()
	{
	}
}
