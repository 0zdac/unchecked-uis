using System;
using System.Diagnostics;
using System.IO;
using Microsoft.Win32;

namespace Crescent;

public static class RobloxManager
{
	public static void EnsureWorkerRunning() { }
	public static void SetAutoStart(bool enable) { }
	public static bool IsAutoStartEnabled() => false;
}
