internal class Crescent_ProcessedByFody
{
	internal const string FodyVersion = "6.9.3.0";

	internal const string Costura = "6.2.0";
}
