using System;
using System.Windows.Forms;
using DiscordRPC;
using DiscordRPC.Logging;

namespace Feairl;

public class DiscordRPC
{
	private bool isRunning;

	private DiscordRpcClient client;

	private DateTime startTime;

	private Timer rpcTimer;

	public void ResetTime()
	{
		startTime = DateTime.UtcNow;
	}

	public void Start()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Expected O, but got Unknown
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Expected O, but got Unknown
		client = new DiscordRpcClient("1525661857086574762");
		client.Logger = (ILogger)new ConsoleLogger
		{
			Level = (LogLevel)3
		};
		client.Initialize();
		startTime = DateTime.UtcNow;
		SetState("Not Attach", "https://getcrescent.best");
		rpcTimer = new Timer();
		rpcTimer.Interval = 1000;
		rpcTimer.Tick += delegate
		{
			if (client == null || !isRunning)
			{
				return;
			}
			try
			{
				client.Invoke();
			}
			catch
			{
			}
		};
		isRunning = true;
		rpcTimer.Start();
	}

	public void SetState(string state, string details)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Expected O, but got Unknown
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Expected O, but got Unknown
		//IL_0059: Expected O, but got Unknown
		if (client != null)
		{
			client.SetPresence(new RichPresence
			{
				Details = details,
				State = state,
				Timestamps = new Timestamps
				{
					Start = startTime
				},
				Assets = new Assets
				{
					LargeImageKey = "crescent_dc"
				}
			});
		}
	}

	public void Stop()
	{
		isRunning = false;
		rpcTimer?.Stop();
		rpcTimer?.Dispose();
		rpcTimer = null;
		DiscordRpcClient obj = client;
		if (obj != null)
		{
			obj.Dispose();
		}
		client = null;
	}
}
