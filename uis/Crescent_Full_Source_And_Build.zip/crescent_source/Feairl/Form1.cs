using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using JsonSerializer = System.Text.Json.JsonSerializer;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Crescent;
using Guna.UI2.AnimatorNS;
using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Suite;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using QuorumAPI;
using WebViewProtecter;

namespace Feairl;

public static class ExecutorInfo
{
	public static string Name { get; set; } = "Crescent.best";
	public static string Ver { get; set; } = "v3";
	public static string CUA { get; set; } = "Crescent.best/v3";
}

public class Form1 : Form
{
	public class AppSettings
	{
		public bool AutoUpdate { get; set; } = true;

		public bool AutoLaunchOnStartup { get; set; }

		public bool AutoAttach { get; set; } = true;

		public bool AutoDowngradeRoblox { get; set; }

		public bool AutoLaunchRoblox { get; set; }

		public bool FpsUnlocker { get; set; } = true;

		public bool CrashDetection { get; set; } = true;

		public string Language { get; set; } = "en";

		public string DefaultTab { get; set; } = "Executor";

		public string Theme { get; set; } = "dark";

		public bool AlwaysOnTop { get; set; }

		public bool AutoSaveWindowPosition { get; set; }

		public bool AntiScreenRecorder { get; set; }

		public bool DiscordRPC { get; set; } = true;

		public bool AcrylicBlur { get; set; }

		public int WindowOpacity { get; set; } = 100;

		public int WindowX { get; set; } = -1;

		public int WindowY { get; set; } = -1;

		public int WindowWidth { get; set; }

		public int WindowHeight { get; set; }

		public bool AutoSaveScript { get; set; } = true;

		public bool MiniMap { get; set; } = true;

		public bool LeftMiniMap { get; set; }

		public bool WordWrap { get; set; }

		public bool LineNumber { get; set; } = true;

		public string Font { get; set; } = "JetBrains Mono";

		public int FontSize { get; set; } = 14;

		public bool MeteorEffect { get; set; }

		public bool ShowExplorer { get; set; } = true;

		public bool AutoRefreshExplorer { get; set; } = true;

		public int AutoRefreshInterval { get; set; } = 5;

		public string ExplorerPosition { get; set; } = "left";

		public string ExecuteHotkey { get; set; } = "Ctrl+Enter";

		public string AttachHotkey { get; set; } = "Ctrl+Shift+A";

		public string KillRobloxHotkey { get; set; } = "Ctrl+Shift+K";

		public string BossKeyHotkey { get; set; } = "Ctrl+Alt+Q";

		public bool AntivirusDetectionAlert { get; set; } = true;

		public bool WindowsDefenderAlert { get; set; } = true;
	}

	public static class SettingsManager
	{
		private static readonly string Path = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Crescent", "Crescent.config.json");

		public static AppSettings Current { get; private set; } = new AppSettings();

		public static void Load()
		{
			string directoryName = System.IO.Path.GetDirectoryName(Path);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			if (File.Exists(Path))
			{
				Current = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(Path)) ?? new AppSettings();
			}
			else
			{
				Save();
			}
		}

		public static void Save()
		{
			string contents = JsonSerializer.Serialize(Current, new JsonSerializerOptions
			{
				WriteIndented = true
			});
			File.WriteAllText(Path, contents);
		}
	}

	public class ExplorerNode
	{
		public string name { get; set; }

		public string type { get; set; }

		public List<ExplorerNode> children { get; set; }
	}

	private class VersionCheckResult
	{
		public bool Success { get; set; }

		public string LocalVersion { get; set; }

		public string RemoteVersion { get; set; }

		public bool IsDifferent { get; set; }

		public string Error { get; set; }
	}

	private delegate void WinEventDelegate(nint hWinEventHook, uint eventType, nint hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime);

	private struct MEMORYSTATUSEX
	{
		public uint dwLength;

		public uint dwMemoryLoad;

		public ulong ullTotalPhys;

		public ulong ullAvailPhys;

		public ulong ullTotalPageFile;

		public ulong ullAvailPageFile;

		public ulong ullTotalVirtual;

		public ulong ullAvailVirtual;

		public ulong ullAvailExtendedVirtual;
	}

	private struct WindowCompositionAttributeData
	{
		public int Attribute;

		public nint Data;

		public int SizeOfData;
	}

	private struct AccentPolicy
	{
		public int AccentState;

		public int AccentFlags;

		public int GradientColor;

		public int AnimationId;
	}

	private CancellationTokenSource _autoAttachCts;

	private CancellationTokenSource _cleanerCts;

	private Control currentPanel;

	private DiscordRPC rpc;

	private HttpListener _autoExecStatusListener;

	private HttpListener _gameHubListener;

	private Process watchedProcess;

	private QuorumModule quorum;

	private RobloxLogTracker _logTracker;

	private TaskCompletionSource<bool> _crashRestartTcs;

	private TaskCompletionSource<bool> _downgradeDecisionTcs;

	private TaskCompletionSource<VersionCheckResult> _versionCheckTcs;

	private DateTime _lastGameHubResponseAt;

	private nint _nexomiaHook;

	private bool rpcEnabled;

	private bool isHandlingCrash;

	private bool isSwitching;

	private bool _applyingTheme;

	private bool _bossKeyHidden;

	private bool _webMessageHandlerRegistered;

	private volatile bool watchedProcessHadWindow;

	private int _currentAutoExecPort;

	private int _nextHotkeyId;

	private int _windowlessGraceStrikes;

	private const int AutoExecStatusPortBase = 47901;

	private const int AutoExecStatusPortRange = 15;

	private const int GameHubPort = 47899;

	private const int WM_SETTINGCHANGE = 26;

	private const int WM_HOTKEY = 786;

	private const int GWL_EXSTYLE = -20;

	private const int WS_EX_LAYERED = 524288;

	private const int WS_EX_TRANSPARENT = 32;

	private const uint BM_CLICK = 245u;

	private const uint EVENT_OBJECT_CREATE = 32768u;

	private const uint EVENT_OBJECT_SHOW = 32770u;

	private const uint IDOK = 1u;

	private const uint LWA_ALPHA = 2u;

	private const uint MOD_ALT = 1u;

	private const uint MOD_CONTROL = 2u;

	private const uint MOD_SHIFT = 4u;

	private const uint MOD_WIN = 8u;

	private const uint WM_CLOSE = 16u;

	private const uint WM_COMMAND = 273u;

	private const uint WDA_NONE = 0u;

	private const uint WDA_EXCLUDEFROMCAPTURE = 17u;

	private const uint WINEVENT_OUTOFCONTEXT = 0u;

	private const uint WINEVENT_SKIPOWNPROCESS = 2u;

	private const string LoaderUrl = "https://raw.githubusercontent.com/feairl2/Crescent-Hub/main/Loader.lua";

	private const string ReleaseApiUrl = "https://api.github.com/repos/feairl2/Crescent-Downgrade/releases/tags/RobloxManager";

	private const string RegistryRunKey = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run";

	private string currentTab;

	private string _lastAutoExecValue;

	private string _lastDetectedGame;

	private string _pendingExecuteCode;

	private readonly Dictionary<string, int> _hotkeyIds;

	private readonly Dictionary<int, Action> _hotkeyActions;

	private readonly Dictionary<int, int> _windowlessStrikeCount;

	private readonly HashSet<int> _selectedPids;

	private readonly WinEventDelegate _nexomiaWinEventProc;

	private static readonly HttpClient _http = new HttpClient();

	private static readonly HttpClient _httpClient = new HttpClient
	{
		Timeout = TimeSpan.FromSeconds(5.0)
	};

	private static readonly TimeSpan GameHubStaleTimeout = TimeSpan.FromSeconds(8.0);

	private static readonly string TargetDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox", "Versions");

	private static readonly string WorkerPath = Path.Combine(TargetDir, "RobloxManager.exe");

	private System.Windows.Forms.Timer AutoExecProbeTimer;

	private System.Windows.Forms.Timer GameHubProbeTimer;

	private System.Windows.Forms.Timer RobloxCrashDetection;

	private System.Windows.Forms.Timer RobloxWindowlessDetection;

	private System.Windows.Forms.Timer StatusUpdateTimer;

	private System.Windows.Forms.Timer WindowRefreshTimer;

	private IContainer components;

	private Guna2Transition guna2Transition1;

	private Guna2Panel guna2Panel3;

	private Guna2Panel guna2Panel6;

	private Guna2Button Execute;

	private Guna2Panel guna2Panel1;

	private WebView2 ScriptHub;

	private Guna2Panel guna2Panel20;

	private WebView2 Executor;

	private WebView2 PageTab;

	private WebView2 SettingsTab;

	private WebView2 Dashboard;

	private new WebView2 ControlBox;

	private Guna2PictureBox guna2PictureBox1;

	private WebView2 TitleText;

	private WebView2 Animation;

	private Panel panel1;

	public Form1()
	{
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Expected O, but got Unknown
		rpc = new DiscordRPC();
		_logTracker = new RobloxLogTracker();
		_lastGameHubResponseAt = DateTime.MinValue;
		_nexomiaHook = IntPtr.Zero;
		_currentAutoExecPort = -1;
		_nextHotkeyId = 45056;
		_windowlessGraceStrikes = 5;
		currentTab = "Executor";
		_lastAutoExecValue = "";
		_hotkeyIds = new Dictionary<string, int>();
		_hotkeyActions = new Dictionary<int, Action>();
		_windowlessStrikeCount = new Dictionary<int, int>();
		_selectedPids = new HashSet<int>();
		InitializeComponent();
		try
		{
			panel1.SendToBack();
			panel1.Visible = false;
			((Control)(object)guna2PictureBox1).Visible = true;
			((Control)(object)PageTab).Visible = true;
			((Control)(object)ControlBox).Visible = true;
			SwitchTo(guna2Panel1);
			SetFoldersHidden(shouldHide: true);
			StartGameHubListener();
			_logTracker.StartTracking(Executor, () => quorum.IsAttached(), delegate(string script)
			{
				//IL_0007: Unknown result type (might be due to invalid IL or missing references)
				quorum.ExecuteScript(script);
			});
			_nexomiaWinEventProc = NexomiaWinEventProc;
			_nexomiaHook = SetWinEventHook(32768u, 32770u, IntPtr.Zero, _nexomiaWinEventProc, 0u, 0u, 2u);
			AdvancedFpsUnlocker.StartUnlocker();
		}
		catch
		{
		}
		ExecutorInfo.Name = "Crescent.best";
		ExecutorInfo.Ver = "v3";
		ExecutorInfo.CUA = "Crescent.best/v3";
		QuorumModule.SetAttachNotify((string)null, (string)null);
		QuorumModule.UseAutoUpdate = false;
		QuorumModule.UseAutoUpdateAPI = false;
		QuorumModule.DumbMode = false;
		quorum = new QuorumModule();
		try
		{
			string text = Path.Combine(AppContext.BaseDirectory, "QuorumAPI.dll");
			string destFileName = Path.Combine(AppContext.BaseDirectory, "CrescentAPI.dll");
			if (File.Exists(text) && !File.Exists(destFileName))
			{
				File.Copy(text, destFileName);
			}
			else if (File.Exists(destFileName) && !File.Exists(text))
			{
				File.Copy(destFileName, text);
			}
		}
		catch
		{
		}
		WebView2[] array = (WebView2[])(object)new WebView2[4] { Dashboard, Executor, ScriptHub, SettingsTab };
		for (int num = 0; num < array.Length; num++)
		{
			((Control)(object)array[num]).Top += 2;
		}
		RobloxCrashDetection = new System.Windows.Forms.Timer();
		RobloxCrashDetection.Interval = 3000;
		RobloxCrashDetection.Tick += MonitorTimer_Tick;
		RobloxCrashDetection.Start();
		RobloxWindowlessDetection = new System.Windows.Forms.Timer();
		RobloxWindowlessDetection.Interval = 2000;
		RobloxWindowlessDetection.Tick += RobloxWindowlessDetection_Tick;
		RobloxWindowlessDetection.Start();
		GameHubProbeTimer = new System.Windows.Forms.Timer();
		GameHubProbeTimer.Interval = 3000;
		GameHubProbeTimer.Tick += GameHubProbeTimer_Tick;
		GameHubProbeTimer.Start();
		AutoExecProbeTimer = new System.Windows.Forms.Timer();
		AutoExecProbeTimer.Interval = 3000;
		AutoExecProbeTimer.Tick += AutoExecProbeTimer_Tick;
		AutoExecProbeTimer.Start();
		StatusUpdateTimer = new System.Windows.Forms.Timer();
		StatusUpdateTimer.Interval = 2000;
		StatusUpdateTimer.Tick += StatusUpdateTimer_Tick;
		StatusUpdateTimer.Start();
		WindowRefreshTimer = new System.Windows.Forms.Timer();
		WindowRefreshTimer.Interval = 100;
		WindowRefreshTimer.Tick += WindowRefreshTimer_Tick;
	}

	private List<ExplorerNode> BuildExplorerTree(string folderPath)
	{
		List<ExplorerNode> list = new List<ExplorerNode>();
		string[] directories = Directory.GetDirectories(folderPath);
		foreach (string text in directories)
		{
			list.Add(new ExplorerNode
			{
				name = Path.GetFileName(text),
				type = "folder",
				children = BuildExplorerTree(text)
			});
		}
		directories = Directory.GetFiles(folderPath);
		foreach (string path in directories)
		{
			list.Add(new ExplorerNode
			{
				name = Path.GetFileName(path),
				type = "file"
			});
		}
		return list;
	}

	private void RegisterAllHotkeys()
	{
		RegisterHotkey("ExecuteHotkey", SettingsManager.Current.ExecuteHotkey, delegate
		{
			Execute_Click(null, null);
		});
		RegisterHotkey("AttachHotkey", SettingsManager.Current.AttachHotkey, delegate
		{
			Attach_Click(null, null);
		});
		RegisterHotkey("KillRobloxHotkey", SettingsManager.Current.KillRobloxHotkey, delegate
		{
			TryKillRobloxProcesses();
		});
		RegisterHotkey("BossKeyHotkey", SettingsManager.Current.BossKeyHotkey, delegate
		{
			ToggleBossKey();
		});
	}

	private bool RegisterHotkey(string name, string combo, Action action)
	{
		if (_hotkeyIds.TryGetValue(name, out var value))
		{
			UnregisterHotKey(base.Handle, value);
			_hotkeyActions.Remove(value);
			_hotkeyIds.Remove(name);
		}
		if (string.IsNullOrWhiteSpace(combo))
		{
			return true;
		}
		if (!TryParseHotkey(combo, out var modifiers, out var vk))
		{
			return false;
		}
		int num = _nextHotkeyId++;
		if (!RegisterHotKey(base.Handle, num, modifiers, vk))
		{
			return false;
		}
		_hotkeyIds[name] = num;
		_hotkeyActions[num] = action;
		return true;
	}

	private static bool TryParseHotkey(string combo, out uint modifiers, out uint vk)
	{
		modifiers = 0u;
		vk = 0u;
		string[] array = combo.Split('+', StringSplitOptions.RemoveEmptyEntries);
		if (array.Length == 0)
		{
			return false;
		}
		string text = array[^1];
		for (int i = 0; i < array.Length - 1; i++)
		{
			switch (array[i].Trim().ToLowerInvariant())
			{
			case "ctrl":
				modifiers |= 2u;
				break;
			case "alt":
				modifiers |= 1u;
				break;
			case "shift":
				modifiers |= 4u;
				break;
			case "win":
				modifiers |= 8u;
				break;
			default:
				return false;
			}
		}
		vk = KeyNameToVirtualKey(text.Trim());
		return vk != 0;
	}

	private static uint KeyNameToVirtualKey(string keyName)
	{
		switch (keyName)
		{
		case "Enter":
			return 13u;
		case "Esc":
			return 27u;
		case "Space":
			return 32u;
		case "Up":
			return 38u;
		case "Down":
			return 40u;
		case "Left":
			return 37u;
		case "Right":
			return 39u;
		case "Del":
			return 46u;
		case "Ins":
			return 45u;
		case "PageUp":
			return 33u;
		case "PageDown":
			return 34u;
		default:
		{
			bool flag;
			if (keyName.Length == 1)
			{
				char c = char.ToUpperInvariant(keyName[0]);
				switch (c)
				{
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
				case 'A':
				case 'B':
				case 'C':
				case 'D':
				case 'E':
				case 'F':
				case 'G':
				case 'H':
				case 'I':
				case 'J':
				case 'K':
				case 'L':
				case 'M':
				case 'N':
				case 'O':
				case 'P':
				case 'Q':
				case 'R':
				case 'S':
				case 'T':
				case 'U':
				case 'V':
				case 'W':
				case 'X':
				case 'Y':
				case 'Z':
					flag = true;
					break;
				default:
					flag = false;
					break;
				}
				if (flag)
				{
					return c;
				}
			}
			int length = keyName.Length;
			flag = (uint)(length - 2) <= 1u;
			if (flag && keyName[0] == 'F' && int.TryParse(keyName.Substring(1), out var result) && result >= 1 && result <= 24)
			{
				return (uint)(112 + (result - 1));
			}
			return 0u;
		}
		}
	}

	[DllImport("user32.dll")]
	public static extern bool ReleaseCapture();

	[DllImport("user32.dll")]
	public static extern bool PostMessage(nint hWnd, int Msg, nint wParam, nint lParam);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool RegisterHotKey(nint hWnd, int id, uint fsModifiers, uint vk);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool UnregisterHotKey(nint hWnd, int id);

	[DllImport("user32.dll")]
	private static extern int GetWindowLong(nint hWnd, int nIndex);

	[DllImport("user32.dll")]
	private static extern int SetWindowLong(nint hWnd, int nIndex, int dwNewLong);

	[DllImport("user32.dll")]
	private static extern bool SetLayeredWindowAttributes(nint hWnd, uint crKey, byte bAlpha, uint dwFlags);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool IsWindowVisible(nint hWnd);

	[DllImport("user32.dll")]
	private static extern int SetWindowCompositionAttribute(nint hwnd, ref WindowCompositionAttributeData data);

	[DllImport("user32.dll")]
	private static extern nint SetWinEventHook(uint eventMin, uint eventMax, nint hmodWinEventProc, WinEventDelegate lpfnWinEventProc, uint idProcess, uint idThread, uint dwFlags);

	[DllImport("user32.dll")]
	private static extern bool UnhookWinEvent(nint hWinEventHook);

	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern int GetWindowText(nint hWnd, StringBuilder lpString, int nMaxCount);

	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern nint FindWindowEx(nint parentHandle, nint childAfter, string className, string windowTitle);

	[DllImport("user32.dll")]
	private static extern bool IsWindow(nint hWnd);

	[DllImport("dwmapi.dll")]
	private static extern int DwmSetWindowAttribute(nint hwnd, int attr, ref int attrValue, int attrSize);

	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool SetWindowDisplayAffinity(nint hWnd, uint dwAffinity);

	[DllImport("user32.dll")]
	private static extern bool PostMessage(nint hWnd, uint Msg, nint wParam, nint lParam);

	private void SetAcrylic(bool enable, byte alpha = 180)
	{
		Color backColor = BackColor;
		int gradientColor = (alpha << 24) | (backColor.B << 16) | (backColor.G << 8) | backColor.R;
		AccentPolicy structure = new AccentPolicy
		{
			AccentState = (enable ? 4 : 0),
			GradientColor = gradientColor
		};
		int num = Marshal.SizeOf(structure);
		nint num2 = Marshal.AllocHGlobal(num);
		Marshal.StructureToPtr(structure, num2, fDeleteOld: false);
		WindowCompositionAttributeData data = new WindowCompositionAttributeData
		{
			Attribute = 19,
			SizeOfData = num,
			Data = num2
		};
		SetWindowCompositionAttribute(base.Handle, ref data);
		Marshal.FreeHGlobal(num2);
	}

	protected override void OnHandleCreated(EventArgs e)
	{
		base.OnHandleCreated(e);
		int attrValue = 2;
		DwmSetWindowAttribute(base.Handle, 33, ref attrValue, 4);
	}

	private static IEnumerable<T> FindAllControls<T>(Control root) where T : Control
	{
		foreach (Control child in root.Controls)
		{
			if (child is T val)
			{
				yield return val;
			}
			foreach (T item in FindAllControls<T>(child))
			{
				yield return item;
			}
		}
	}

	protected override void WndProc(ref Message m)
	{
		if (m.Msg == 786)
		{
			int key = ((IntPtr)m.WParam).ToInt32();
			if (_hotkeyActions.TryGetValue(key, out Action value))
			{
				value?.Invoke();
			}
		}
		else if (m.Msg == 131 && m.WParam != IntPtr.Zero)
		{
			m.Result = IntPtr.Zero;
		}
		else if (m.Msg == 132)
		{
			base.WndProc(ref m);
			if ((int)m.Result != 1)
			{
				return;
			}
			Point p = new Point((short)(((IntPtr)m.LParam).ToInt32() & 0xFFFF), (short)(((IntPtr)m.LParam).ToInt32() >> 16));
			Point point = PointToClient(p);
			if (point.Y <= 4)
			{
				if (point.X <= 4)
				{
					m.Result = 13;
				}
				else if (point.X >= base.ClientSize.Width - 4)
				{
					m.Result = 14;
				}
				else
				{
					m.Result = 12;
				}
			}
			else if (point.Y >= base.ClientSize.Height - 4)
			{
				if (point.X <= 4)
				{
					m.Result = 16;
				}
				else if (point.X >= base.ClientSize.Width - 4)
				{
					m.Result = 17;
				}
				else
				{
					m.Result = 15;
				}
			}
			else if (point.X <= 4)
			{
				m.Result = 10;
			}
			else if (point.X >= base.ClientSize.Width - 4)
			{
				m.Result = 11;
			}
			else if (point.Y <= 30)
			{
				m.Result = 2;
			}
		}
		else
		{
			if (m.Msg == 26 && Marshal.PtrToStringUni(m.LParam) == "ImmersiveColorSet" && SettingsManager.Current.Theme == "device")
			{
				ApplyThemeToAllWebViews("device");
			}
			base.WndProc(ref m);
		}
	}

	
	private static Uri GetPageUri(string fileName)
	{
		string localPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ui", fileName);
		if (File.Exists(localPath))
		{
			return new Uri(localPath);
		}
		return new Uri("https://crescent-webview.vercel.app/" + fileName);
	}

	private async void Form1_Load(object sender, EventArgs e)
	{
		try
		{
			panel1.SendToBack();
			panel1.Visible = false;
			((Control)(object)Animation).BringToFront();
			((Control)(object)Animation).Visible = true;
			((Control)(object)guna2PictureBox1).Visible = true;
			((Control)(object)guna2Panel1).Visible = true;
			((Control)(object)PageTab).Visible = true;
			((Control)(object)ControlBox).Visible = true;
			Task.Delay(4500).ContinueWith(_ => {
				try {
					BeginInvoke(new Action(() => {
						if (((Control)(object)Animation).Visible) {
							((Control)(object)Animation).Visible = false;
							SwitchTo(guna2Panel1);
						}
					}));
				} catch { }
			});

			await InitWebView();
			await LoadSettings();
			await EnsureLoaderExistsAsync();
			SyncWorkspace();
			InitSettings();
			InitExplorer();
			if (SettingsManager.Current.DefaultTab != "Executor")
			{
				HandleTabSwitch(SettingsManager.Current.DefaultTab);
				if (PageTab.CoreWebView2 != null)
				{
					await PageTab.CoreWebView2.ExecuteScriptAsync("window.NavAPI.setActive('" + SettingsManager.Current.DefaultTab + "');");
				}
			}
			if (SettingsManager.Current.AutoAttach)
			{
				OnAutoAttachChanged(enabled: true);
			}
			OnLanguageChanged(SettingsManager.Current.Language);
			ApplyThemeToAllWebViews(SettingsManager.Current.Theme);
			await DetectSystemPerformanceAsync();
			await CheckAntivirus();
		}
		catch (Exception ex)
		{
			File.AppendAllText("crescent_error.log", ex.ToString() + "\n");
		}
	}

	private static async Task CheckAndDownloadNexomiaAsync()
	{
		string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "win.nexomia");
		string binPath = Path.Combine(text, "Bin");
		string localVersionPath = Path.Combine(binPath, "version.txt");
		string mainExePath = Path.Combine(text, "Nexomia.exe");
		string baseUrl = "https://crescent-proxy.vercel.app/api/download?file=";
		Directory.CreateDirectory(text);
		Directory.CreateDirectory(binPath);
		string[] binFiles = new string[4] { "version.txt", "Injector.exe", "luau-lsp.exe", "Nexomia.dll" };
		using HttpClient client = new HttpClient();
		if (!File.Exists(mainExePath))
		{
			try
			{
				await File.WriteAllBytesAsync(mainExePath, await client.GetByteArrayAsync(baseUrl + "Nexomia.exe"));
			}
			catch (Exception)
			{
			}
		}
		bool isBinMissingFiles = binFiles.Any((string fileName) => !File.Exists(Path.Combine(binPath, fileName)));
		string remoteVersion = string.Empty;
		string localVersion = string.Empty;
		try
		{
			remoteVersion = (await client.GetStringAsync(baseUrl + "version.txt")).Trim();
		}
		catch (Exception)
		{
		}
		if (File.Exists(localVersionPath))
		{
			try
			{
				localVersion = (await File.ReadAllTextAsync(localVersionPath)).Trim();
			}
			catch
			{
			}
		}
		if (!isBinMissingFiles && (string.IsNullOrEmpty(remoteVersion) || !(localVersion != remoteVersion)))
		{
			return;
		}
		string[] array = binFiles;
		foreach (string text2 in array)
		{
			string filePath = Path.Combine(binPath, text2);
			try
			{
				await File.WriteAllBytesAsync(filePath, await client.GetByteArrayAsync(baseUrl + text2));
			}
			catch (Exception)
			{
			}
		}
	}

	private async Task<bool> DownloadRobloxManagerAsync()
	{
		_ = 2;
		try
		{
			using HttpClient client = new HttpClient();
			client.DefaultRequestHeaders.UserAgent.ParseAdd("Crescent-App");
			client.DefaultRequestHeaders.Accept.ParseAdd("application/vnd.github+json");
			client.Timeout = TimeSpan.FromSeconds(30.0);
			using JsonDocument doc = JsonDocument.Parse(await client.GetStringAsync("https://api.github.com/repos/feairl2/Crescent-Downgrade/releases/tags/RobloxManager"));
			string text = null;
			if (doc.RootElement.TryGetProperty("assets", out var value) && value.ValueKind == JsonValueKind.Array)
			{
				foreach (JsonElement item in value.EnumerateArray())
				{
					if ((item.TryGetProperty("name", out var value2) ? (value2.GetString() ?? "") : "").Equals("RobloxManager.exe", StringComparison.OrdinalIgnoreCase))
					{
						text = (item.TryGetProperty("browser_download_url", out var value3) ? (value3.GetString() ?? "") : null);
						break;
					}
				}
			}
			if (string.IsNullOrEmpty(text))
			{
				return false;
			}
			if (!Directory.Exists(TargetDir))
			{
				Directory.CreateDirectory(TargetDir);
			}
			byte[] bytes = await client.GetByteArrayAsync(text);
			await File.WriteAllBytesAsync(WorkerPath, bytes);
			return File.Exists(WorkerPath);
		}
		catch
		{
			return false;
		}
	}

	private async Task SilentSyncLatestRobloxVersionAsync()
	{
		string[] possibleRoots = new string[3]
		{
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox", "Versions"),
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Roblox", "Versions"),
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Roblox", "Versions")
		};
		try
		{
			using HttpClient client = new HttpClient();
			client.DefaultRequestHeaders.UserAgent.ParseAdd("Crescent/v3");
			client.DefaultRequestHeaders.Accept.ParseAdd("application/vnd.github+json");
			client.Timeout = TimeSpan.FromSeconds(20.0);
			using JsonDocument doc = JsonDocument.Parse(await client.GetStringAsync("https://api.github.com/repos/feairl2/Crescent-Downgrade/releases/latest"));
			JsonElement rootElement = doc.RootElement;
			string tagName = ((!rootElement.TryGetProperty("tag_name", out var value)) ? null : value.GetString()?.Trim());
			if (string.IsNullOrEmpty(tagName))
			{
				return;
			}
			string zipUrl = null;
			if (rootElement.TryGetProperty("assets", out var value2) && value2.ValueKind == JsonValueKind.Array)
			{
				foreach (JsonElement item in value2.EnumerateArray())
				{
					string text = (item.TryGetProperty("name", out var value3) ? (value3.GetString() ?? "") : "");
					string text2 = (item.TryGetProperty("browser_download_url", out var value4) ? (value4.GetString() ?? "") : "");
					if (!string.IsNullOrEmpty(text2) && (text.Equals("WEAO-LIVE.zip", StringComparison.OrdinalIgnoreCase) || (text.StartsWith("WEAO", StringComparison.OrdinalIgnoreCase) && text.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))))
					{
						zipUrl = text2;
						break;
					}
				}
			}
			if (string.IsNullOrEmpty(zipUrl))
			{
				return;
			}
			bool hasVisibleWindow = IsRobloxWindowReady();
			bool needUpdate = false;
			string existingLatestExe = null;
			string[] array = possibleRoots;
			foreach (string text3 in array)
			{
				if (Directory.Exists(text3))
				{
					string targetDir = Path.Combine(text3, tagName);
					string path = Path.Combine(targetDir, "version.lock");
					if (!Directory.Exists(targetDir) || !File.Exists(path) || !string.Equals((await File.ReadAllTextAsync(path)).Trim(), tagName, StringComparison.OrdinalIgnoreCase))
					{
						needUpdate = true;
						break;
					}
					string text4 = Path.Combine(targetDir, "RobloxPlayerBeta.exe");
					if (File.Exists(text4))
					{
						existingLatestExe = text4;
					}
				}
			}
			if (!needUpdate)
			{
				string[] array2 = possibleRoots;
				foreach (string text5 in array2)
				{
					if (!Directory.Exists(text5))
					{
						continue;
					}
					string b = Path.Combine(text5, tagName);
					string[] directories = Directory.GetDirectories(text5, "version-*");
					foreach (string text6 in directories)
					{
						if (!string.Equals(text6, b, StringComparison.OrdinalIgnoreCase))
						{
							ForceDeleteDir(text6);
						}
					}
				}
				if (!string.IsNullOrEmpty(existingLatestExe) && File.Exists(existingLatestExe))
				{
					UpdateRobloxDesktopShortcuts(existingLatestExe);
				}
				return;
			}
			if (hasVisibleWindow)
			{
				string targetDir = Path.Combine(Path.GetTempPath(), $"WEAO-{tagName}-{Guid.NewGuid():N}.zip");
				string tempExtract = Path.Combine(Path.GetTempPath(), $"WEAO-Extract-{Guid.NewGuid():N}");
				string lastSuccessfulExe = null;
				try
				{
					if (!(await DownloadFileFastAsync(zipUrl, targetDir, 8)))
					{
						return;
					}
					if (Directory.Exists(tempExtract))
					{
						ForceDeleteDir(tempExtract);
					}
					Directory.CreateDirectory(tempExtract);
					ZipFile.ExtractToDirectory(targetDir, tempExtract);
					string sourceDir = FindRobloxPlayerDir(tempExtract);
					if (sourceDir == null)
					{
						return;
					}
					array = possibleRoots;
					foreach (string text7 in array)
					{
						try
						{
							if (Directory.Exists(text7))
							{
								string targetDir2 = Path.Combine(text7, tagName);
								string lockPath = Path.Combine(targetDir2, "version.lock");
								if (Directory.Exists(targetDir2) && File.Exists(lockPath) && string.Equals((await File.ReadAllTextAsync(lockPath)).Trim(), tagName, StringComparison.OrdinalIgnoreCase))
								{
									lastSuccessfulExe = Path.Combine(targetDir2, "RobloxPlayerBeta.exe");
								}
								else if (!Directory.Exists(targetDir2))
								{
									CopyDir(sourceDir, targetDir2);
									await File.WriteAllTextAsync(lockPath, tagName);
									lastSuccessfulExe = Path.Combine(targetDir2, "RobloxPlayerBeta.exe");
								}
							}
						}
						catch
						{
						}
					}
					if (!string.IsNullOrEmpty(lastSuccessfulExe) && File.Exists(lastSuccessfulExe))
					{
						UpdateRobloxDesktopShortcuts(lastSuccessfulExe);
					}
					return;
				}
				finally
				{
					try
					{
						if (File.Exists(targetDir))
						{
							File.Delete(targetDir);
						}
					}
					catch
					{
					}
					try
					{
						if (Directory.Exists(tempExtract))
						{
							ForceDeleteDir(tempExtract);
						}
					}
					catch
					{
					}
				}
			}
			string tempZip2 = Path.Combine(Path.GetTempPath(), $"WEAO-{tagName}-{Guid.NewGuid():N}.zip");
			string tempExtract2 = Path.Combine(Path.GetTempPath(), $"WEAO-Extract-{Guid.NewGuid():N}");
			string finalExe = null;
			try
			{
				if (!(await DownloadFileFastAsync(zipUrl, tempZip2, 8)))
				{
					return;
				}
				if (Directory.Exists(tempExtract2))
				{
					ForceDeleteDir(tempExtract2);
				}
				Directory.CreateDirectory(tempExtract2);
				ZipFile.ExtractToDirectory(tempZip2, tempExtract2);
				string lastSuccessfulExe = FindRobloxPlayerDir(tempExtract2);
				if (lastSuccessfulExe == null)
				{
					return;
				}
				TryKillRobloxProcesses();
				await Task.Delay(800);
				array = possibleRoots;
				foreach (string text8 in array)
				{
					try
					{
						if (!Directory.Exists(text8))
						{
							continue;
						}
						string tempExtract = Path.Combine(text8, tagName);
						string path2 = Path.Combine(tempExtract, "version.lock");
						string[] array2 = Directory.GetDirectories(text8, "version-*");
						foreach (string text9 in array2)
						{
							if (!string.Equals(text9, tempExtract, StringComparison.OrdinalIgnoreCase))
							{
								ForceDeleteDir(text9);
							}
						}
						ForceDeleteDir(tempExtract);
						CopyDir(lastSuccessfulExe, tempExtract);
						await File.WriteAllTextAsync(path2, tagName);
						finalExe = Path.Combine(tempExtract, "RobloxPlayerBeta.exe");
					}
					catch
					{
					}
				}
				if (!string.IsNullOrEmpty(finalExe) && File.Exists(finalExe))
				{
					UpdateRobloxDesktopShortcuts(finalExe);
				}
			}
			finally
			{
				try
				{
					if (File.Exists(tempZip2))
					{
						File.Delete(tempZip2);
					}
				}
				catch
				{
				}
				try
				{
					if (Directory.Exists(tempExtract2))
					{
						ForceDeleteDir(tempExtract2);
					}
				}
				catch
				{
				}
			}
		}
		catch
		{
		}
	}

	private async Task<bool> DownloadFileFastAsync(string url, string savePath, int connectionCount = 10)
	{
		try
		{
			using HttpClient headClient = new HttpClient
			{
				Timeout = TimeSpan.FromSeconds(20.0)
			};
			headClient.DefaultRequestHeaders.UserAgent.ParseAdd("Crescent/v3");
			using HttpRequestMessage headReq = new HttpRequestMessage(HttpMethod.Head, url);
			using HttpResponseMessage headResp = await headClient.SendAsync(headReq, HttpCompletionOption.ResponseHeadersRead);
			if (!headResp.IsSuccessStatusCode)
			{
				return await DownloadFileSilentAsync(url, savePath);
			}
			long? contentLength = headResp.Content.Headers.ContentLength;
			if ((!(headResp.Headers.AcceptRanges?.Contains("bytes") ?? false) && headResp.Content.Headers.ContentRange == null) || !contentLength.HasValue || contentLength.Value < 8388608)
			{
				return await DownloadFileSilentAsync(url, savePath);
			}
			long value = contentLength.Value;
			long num = value / connectionCount;
			string[] partFiles = new string[connectionCount];
			Task[] array = new Task[connectionCount];
			for (int i = 0; i < connectionCount; i++)
			{
				long start = i * num;
				long end = ((i == connectionCount - 1) ? (value - 1) : (start + num - 1));
				partFiles[i] = savePath + $".part{i}";
				int index = i;
				array[i] = Task.Run(async delegate
				{
					using HttpClient client = new HttpClient
					{
						Timeout = TimeSpan.FromMinutes(30.0)
					};
					client.DefaultRequestHeaders.UserAgent.ParseAdd("Crescent/v3");
					client.DefaultRequestHeaders.Range = new RangeHeaderValue(start, end);
					using HttpResponseMessage resp = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
					resp.EnsureSuccessStatusCode();
					await using Stream stream = await resp.Content.ReadAsStreamAsync();
					await using FileStream fs = new FileStream(partFiles[index], FileMode.Create, FileAccess.Write, FileShare.None, 262144, useAsync: true);
					await stream.CopyToAsync(fs);
				});
			}
			await Task.WhenAll(array);
			await using (FileStream output = new FileStream(savePath, FileMode.Create, FileAccess.Write, FileShare.None, 262144, useAsync: true))
			{
				string[] array2 = partFiles;
				foreach (string path in array2)
				{
					await using FileStream input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 262144, useAsync: true);
					await input.CopyToAsync(output);
				}
			}
			string[] array3 = partFiles;
			foreach (string path2 in array3)
			{
				try
				{
					File.Delete(path2);
				}
				catch
				{
				}
			}
			return true;
		}
		catch
		{
			try
			{
				for (int num4 = 0; num4 < 16; num4++)
				{
					string path3 = savePath + $".part{num4}";
					if (File.Exists(path3))
					{
						try
						{
							File.Delete(path3);
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
			return await DownloadFileSilentAsync(url, savePath);
		}
	}

	private async Task<bool> DownloadFileSilentAsync(string url, string savePath)
	{
		_ = 4;
		try
		{
			using HttpClient client = new HttpClient
			{
				Timeout = TimeSpan.FromMinutes(45.0)
			};
			client.DefaultRequestHeaders.UserAgent.ParseAdd("Crescent/v3");
			using HttpResponseMessage resp = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
			if (!resp.IsSuccessStatusCode)
			{
				return false;
			}
			bool result;
			await using (Stream stream = await resp.Content.ReadAsStreamAsync())
			{
				bool flag;
				await using (FileStream fs = new FileStream(savePath, FileMode.Create, FileAccess.Write, FileShare.None, 262144, useAsync: true))
				{
					await stream.CopyToAsync(fs);
					flag = true;
				}
				result = flag;
			}
			return result;
		}
		catch
		{
			return false;
		}
	}

	private void UpdateRobloxDesktopShortcuts(string newExePath)
	{
		if (string.IsNullOrEmpty(newExePath) || !File.Exists(newExePath))
		{
			return;
		}
		string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
		if (!Directory.Exists(folderPath))
		{
			return;
		}
		try
		{
			Type typeFromProgID = Type.GetTypeFromProgID("WScript.Shell");
			if (typeFromProgID == null)
			{
				return;
			}
			dynamic val = Activator.CreateInstance(typeFromProgID);
			string[] files = Directory.GetFiles(folderPath, "*.lnk");
			foreach (string text in files)
			{
				try
				{
					dynamic val2 = val.CreateShortcut(text);
					string text2 = (val2.TargetPath as string) ?? "";
					_ = val2.Arguments is string;
					if (text2.IndexOf("RobloxStudio", StringComparison.OrdinalIgnoreCase) < 0 && (text2.IndexOf("Studio", StringComparison.OrdinalIgnoreCase) < 0 || text2.IndexOf("Roblox", StringComparison.OrdinalIgnoreCase) < 0) && (text2.IndexOf("RobloxPlayerBeta.exe", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("RobloxPlayer.exe", StringComparison.OrdinalIgnoreCase) >= 0 || (text2.IndexOf("Roblox", StringComparison.OrdinalIgnoreCase) >= 0 && text2.IndexOf("Versions", StringComparison.OrdinalIgnoreCase) >= 0 && text2.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))))
					{
						val2.TargetPath = newExePath;
						val2.WorkingDirectory = Path.GetDirectoryName(newExePath);
						val2.Save();
					}
				}
				catch
				{
				}
			}
		}
		catch
		{
		}
	}

	private static string FindRobloxPlayerDir(string root)
	{
		if (File.Exists(Path.Combine(root, "RobloxPlayerBeta.exe")))
		{
			return root;
		}
		string[] directories = Directory.GetDirectories(root);
		foreach (string text in directories)
		{
			if (File.Exists(Path.Combine(text, "RobloxPlayerBeta.exe")))
			{
				return text;
			}
		}
		return null;
	}

	private static void KillAllExeInDir(string dir)
	{
		if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir))
		{
			return;
		}
		string value = Path.GetFullPath(dir).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
		try
		{
			foreach (Process item in Process.GetProcessesByName("RobloxPlayerBeta").Concat(Process.GetProcessesByName("RobloxCrashHandler")))
			{
				try
				{
					if (!item.HasExited)
					{
						string text = null;
						try
						{
							text = item.MainModule?.FileName;
						}
						catch
						{
						}
						if (!string.IsNullOrEmpty(text) && Path.GetFullPath(text).StartsWith(value, StringComparison.OrdinalIgnoreCase))
						{
							item.Kill(entireProcessTree: true);
							item.WaitForExit(3000);
						}
					}
				}
				catch
				{
				}
				finally
				{
					try
					{
						item.Dispose();
					}
					catch
					{
					}
				}
			}
		}
		catch
		{
		}
	}

	private static void ForceDeleteDir(string path)
	{
		if (string.IsNullOrEmpty(path) || !Directory.Exists(path))
		{
			return;
		}
		for (int i = 0; i < 3; i++)
		{
			try
			{
				KillAllExeInDir(path);
				string[] files = Directory.GetFiles(path, "*", SearchOption.AllDirectories);
				foreach (string path2 in files)
				{
					try
					{
						File.SetAttributes(path2, FileAttributes.Normal);
					}
					catch
					{
					}
				}
				Directory.Delete(path, recursive: true);
				break;
			}
			catch
			{
				Thread.Sleep(800);
			}
		}
	}

	private static void CopyDir(string source, string dest)
	{
		Directory.CreateDirectory(dest);
		string[] files = Directory.GetFiles(source, "*", SearchOption.AllDirectories);
		foreach (string text in files)
		{
			string relativePath = Path.GetRelativePath(source, text);
			string text2 = Path.Combine(dest, relativePath);
			Directory.CreateDirectory(Path.GetDirectoryName(text2));
			File.Copy(text, text2, overwrite: true);
		}
	}

	private void NexomiaWinEventProc(nint hWinEventHook, uint eventType, nint hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime)
	{
		if (idObject != 0 || idChild != 0)
		{
			return;
		}
		try
		{
			StringBuilder stringBuilder = new StringBuilder(256);
			if (GetWindowText(hwnd, stringBuilder, 256) > 0 && stringBuilder.ToString() == "Nexomia")
			{
				BeginInvoke(delegate
				{
					DismissNexomiaDialog(hwnd);
				});
			}
		}
		catch
		{
		}
	}

	private void DismissNexomiaDialog(nint hWnd)
	{
		try
		{
			if (hWnd == IntPtr.Zero || !IsWindow(hWnd) || !IsWindowVisible(hWnd))
			{
				return;
			}
			string[] array = new string[10] { "確定", "OK", "确定", "확인", "Ouvrir", "Öffnen", "開く", "Aceptar", "Oui", "Ja" };
			foreach (string windowTitle in array)
			{
				nint num = FindWindowEx(hWnd, IntPtr.Zero, "Button", windowTitle);
				if (num != IntPtr.Zero)
				{
					PostMessage(num, 245u, IntPtr.Zero, IntPtr.Zero);
					return;
				}
			}
			nint num2 = FindWindowEx(hWnd, IntPtr.Zero, "Button", null);
			if (num2 != IntPtr.Zero)
			{
				PostMessage(num2, 245u, IntPtr.Zero, IntPtr.Zero);
			}
			else
			{
				PostMessage(hWnd, 16u, IntPtr.Zero, IntPtr.Zero);
			}
		}
		catch
		{
		}
	}

	private async Task EnsureLoaderExistsAsync()
	{
		_ = 1;
		try
		{
			string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "AutoExec");
			string loaderPath = Path.Combine(text, "Loader.lua");
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			if (!File.Exists(loaderPath))
			{
				using HttpClient client = new HttpClient();
				client.Timeout = TimeSpan.FromSeconds(15.0);
				await File.WriteAllBytesAsync(loaderPath, await client.GetByteArrayAsync("https://raw.githubusercontent.com/feairl2/Crescent-Hub/main/Loader.lua"));
			}
		}
		catch (Exception)
		{
		}
	}

	private void SyncWorkspace()
	{
		string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "win.nexomia", "Workspace");
		string text2 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Workspace");
		if (Directory.Exists(text))
		{
			Directory.CreateDirectory(text2);
			MirrorDirectory(text, text2);
		}
	}

	private void MirrorDirectory(string sourceDir, string targetDir)
	{
		string[] directories = Directory.GetDirectories(sourceDir, "*", SearchOption.AllDirectories);
		for (int i = 0; i < directories.Length; i++)
		{
			Directory.CreateDirectory(directories[i].Replace(sourceDir, targetDir));
		}
		directories = Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories);
		foreach (string text in directories)
		{
			string text2 = text.Replace(sourceDir, targetDir);
			if (!File.Exists(text2) || File.GetLastWriteTimeUtc(text) > File.GetLastWriteTimeUtc(text2))
			{
				File.Copy(text, text2, overwrite: true);
			}
		}
		directories = Directory.GetFiles(targetDir, "*", SearchOption.AllDirectories);
		foreach (string text3 in directories)
		{
			if (!File.Exists(text3.Replace(targetDir, sourceDir)))
			{
				File.Delete(text3);
			}
		}
		directories = Directory.GetDirectories(targetDir, "*", SearchOption.AllDirectories);
		foreach (string text4 in directories)
		{
			if (!Directory.Exists(text4.Replace(targetDir, sourceDir)))
			{
				Directory.Delete(text4, recursive: true);
			}
		}
	}

	private void SetFoldersHidden(bool shouldHide)
	{
		try
		{
			string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
			string path = Path.Combine(baseDirectory, "runtimes");
			string path2 = Path.Combine(baseDirectory, "Crescent.exe.WebView2");
			string filePath = Path.Combine(baseDirectory, "WebView2Loader.dll");
			string filePath2 = Path.Combine(baseDirectory, "AutoExec", "Loader.lua");
			string filePath3 = Path.Combine(baseDirectory, "AutoExec", "RobloxNetworkHandler.lua");
			if (shouldHide)
			{
				HideDirectory(path);
				HideDirectory(path2);
				HideFile(filePath);
				HideFile(filePath2);
				HideFile(filePath3);
			}
			else
			{
				ShowDirectory(path);
				ShowDirectory(path2);
				ShowFile(filePath);
				ShowFile(filePath2);
				ShowFile(filePath3);
			}
		}
		catch (Exception)
		{
		}
	}

	private void HideFile(string filePath)
	{
		try
		{
			if (File.Exists(filePath))
			{
				FileAttributes attributes = File.GetAttributes(filePath);
				if ((attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
				{
					File.SetAttributes(filePath, attributes | FileAttributes.Hidden);
				}
			}
		}
		catch
		{
		}
	}

	private void ShowFile(string filePath)
	{
		try
		{
			if (File.Exists(filePath))
			{
				FileAttributes attributes = File.GetAttributes(filePath);
				if ((attributes & FileAttributes.Hidden) == FileAttributes.Hidden)
				{
					File.SetAttributes(filePath, attributes & ~FileAttributes.Hidden);
				}
			}
		}
		catch
		{
		}
	}

	private void HideDirectory(string path)
	{
		if (Directory.Exists(path))
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			if ((directoryInfo.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
			{
				directoryInfo.Attributes |= FileAttributes.Hidden;
			}
		}
	}

	private void ShowDirectory(string path)
	{
		if (Directory.Exists(path))
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			if ((directoryInfo.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden)
			{
				directoryInfo.Attributes &= ~FileAttributes.Hidden;
			}
		}
	}

	private async Task CheckAndUpdate()
	{
		await Task.CompletedTask;
	}

	private string GetLocalVersion()
	{
		string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Bin", "version.dat");
		if (!File.Exists(path))
		{
			return "v0.0.0";
		}
		return File.ReadAllText(path).Trim();
	}

	private async Task<string> GetOnlineVersion()
	{
		string requestUri = "https://api.github.com/repos/cdn-crescent-server/Crescent-Update-Service/releases/latest";
		using HttpClient client = new HttpClient();
		client.DefaultRequestHeaders.UserAgent.ParseAdd("Crescent-App");
		using JsonDocument jsonDocument = JsonDocument.Parse(await client.GetStringAsync(requestUri));
		return jsonDocument.RootElement.GetProperty("tag_name").GetString();
	}

	private void StartUpdater()
	{
		SetFoldersHidden(shouldHide: false);
		string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Updater.exe");
		if (File.Exists(text))
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = text,
				WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory
			});
		}
	}

	private async Task ShowAntivirusModalAsync(string avKey)
	{
		string text = "AntivirusAPI.detect('" + avKey + "')";
		await Executor.CoreWebView2.ExecuteScriptAsync(text);
	}

	private async Task CheckAntivirus()
	{
		Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>();
		dictionary.Add("avira", new string[3] { "avira", "avblock", "avevast" });
		dictionary.Add("norton", new string[3] { "NAVAPSvc", "ccSvcHst", "NS" });
		dictionary.Add("mcafee", new string[3] { "mcshield", "McUICnt", "McSvHost" });
		dictionary.Add("kaspersky", new string[2] { "avp", "avpui" });
		dictionary.Add("bitdefender", new string[3] { "bdagent", "vsserv", "vsservppl" });
		dictionary.Add("avast", new string[2] { "AvastSvc", "AvastUI" });
		dictionary.Add("avg", new string[2] { "AVGSvc", "AvgUi" });
		dictionary.Add("eset", new string[2] { "ekrn", "egui" });
		dictionary.Add("malwarebytes", new string[2] { "MBAMService", "mbam" });
		dictionary.Add("trendmicro", new string[3] { "pccNTMon", "NTRtScan", "UiSeAgnt" });
		dictionary.Add("sophos", new string[3] { "SavService", "SophosUI", "SophosHealth" });
		dictionary.Add("f_secure", new string[3] { "FSAUA", "fsorsp", "fshoster" });
		dictionary.Add("totalav", new string[2] { "TotalAV", "TotalAV.RtProtection" });
		dictionary.Add("panda", new string[2] { "PSANHost", "PandaTray" });
		dictionary.Add("gdata", new string[2] { "AVKService", "GDTray" });
		Dictionary<string, string[]> dictionary2 = dictionary;
		HashSet<string> detectedAVs = new HashSet<string>();
		Process[] processes = Process.GetProcesses();
		foreach (Process process in processes)
		{
			try
			{
				string pName = process.ProcessName;
				foreach (KeyValuePair<string, string[]> item in dictionary2)
				{
					if (!detectedAVs.Contains(item.Key) && item.Value.Any((string keyword) => pName.Equals(keyword, StringComparison.OrdinalIgnoreCase) || pName.StartsWith(keyword, StringComparison.OrdinalIgnoreCase)))
					{
						detectedAVs.Add(item.Key);
					}
				}
			}
			catch
			{
			}
		}
		bool notExcluded = await Task.Run(delegate
		{
			try
			{
				string startupPath = Application.StartupPath;
				string value = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox", "Versions");
				string value2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "win.nexomia");
				string text2 = $"$paths = @('{startupPath}', '{value}', '{value2}'); " + "$exclusions = (Get-MpPreference).ExclusionPath; $missing = $paths | Where-Object {{ $exclusions -notcontains $_ }}; if ($missing.Count -gt 0) {{ exit 1 }} else {{ exit 0 }}";
				using Process process2 = Process.Start(new ProcessStartInfo("powershell", "-Command \"" + text2 + "\"")
				{
					CreateNoWindow = true,
					UseShellExecute = false
				});
				process2.WaitForExit();
				return process2.ExitCode == 1;
			}
			catch
			{
				return false;
			}
		});
		WebView2 settingsTab = SettingsTab;
		if (((settingsTab != null) ? settingsTab.CoreWebView2 : null) != null)
		{
			string text = (notExcluded ? "not-excluded" : "excluded");
			await SettingsTab.CoreWebView2.ExecuteScriptAsync("window.setDefenderStatus && window.setDefenderStatus('" + text + "')");
		}
		if (detectedAVs.Count > 0)
		{
			foreach (string item2 in detectedAVs)
			{
				await ShowAntivirusModalAsync(item2);
			}
		}
		else if (notExcluded && SettingsManager.Current.WindowsDefenderAlert)
		{
			await Executor.CoreWebView2.ExecuteScriptAsync("showDefenderPanel();");
		}
	}

	private async Task InitWebView()
	{
		// Initialize Animation first and navigate to show splash intro immediately
		try
		{
			((Control)(object)Animation).CreateControl();
			await Animation.EnsureCoreWebView2Async((CoreWebView2Environment)null);
			if (Animation.CoreWebView2 != null)
			{
				Animation.CoreWebView2.WebMessageReceived += Animation_WebMessageReceived;
				Animation.CoreWebView2.Navigate(GetPageUri("Animation.html").AbsoluteUri);
			}
		}
		catch { }

		bool isDevMode = File.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ui", "developer_mode.txt"))
		                 || File.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "developer_mode.txt"));

		string customCssPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ui", "custom.css");
		string customCssScript = "";
		if (File.Exists(customCssPath))
		{
			try
			{
				string css = File.ReadAllText(customCssPath);
				if (!string.IsNullOrWhiteSpace(css))
				{
					string escaped = JsonSerializer.Serialize(css);
					customCssScript = $"(function() {{ const inj = () => {{ if (document.getElementById('crescent-custom-css')) return; const s = document.createElement('style'); s.id = 'crescent-custom-css'; s.textContent = {escaped}; (document.head || document.documentElement).appendChild(s); }}; if (document.readyState === 'loading') {{ document.addEventListener('DOMContentLoaded', inj); }} else {{ inj(); }} }})();";
				}
			}
			catch { }
		}

		WebView2[] array = (WebView2[])(object)new WebView2[7] { Dashboard, Executor, ScriptHub, SettingsTab, TitleText, PageTab, ControlBox };
		foreach (WebView2 wv in array)
		{
			try
			{
				((Control)(object)wv).CreateControl();
				await wv.EnsureCoreWebView2Async((CoreWebView2Environment)null);
				if (wv.CoreWebView2 != null)
				{
					CoreWebView2Settings settings = wv.CoreWebView2.Settings;
					settings.AreDevToolsEnabled = isDevMode;
					settings.AreDefaultContextMenusEnabled = isDevMode;
					settings.AreBrowserAcceleratorKeysEnabled = isDevMode;
					settings.IsStatusBarEnabled = false;
					settings.IsZoomControlEnabled = false;
					settings.IsBuiltInErrorPageEnabled = false;
					if (!isDevMode)
					{
						wv.CoreWebView2.ContextMenuRequested += delegate(object? s, CoreWebView2ContextMenuRequestedEventArgs e)
						{
							e.Handled = true;
						};
					}
					wv.CoreWebView2.NewWindowRequested += delegate(object? s, CoreWebView2NewWindowRequestedEventArgs e)
					{
						e.Handled = true;
					};
					wv.CoreWebView2.DownloadStarting += delegate(object? s, CoreWebView2DownloadStartingEventArgs e)
					{
						e.Cancel = true;
					};
					wv.CoreWebView2.WebMessageReceived += OnAnyWebView_ThemeMessage;

					if (!string.IsNullOrEmpty(customCssScript))
					{
						await wv.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(customCssScript);
					}
				}
			}
			catch (Exception ex)
			{
				File.AppendAllText("crash.log", "[InitWebView] " + ((Control)(object)wv).Name + ": " + ex.Message + "\n");
			}
		}


		if (Dashboard.CoreWebView2 != null)
		{
			Dashboard.CoreWebView2.Navigate(GetPageUri("Home.html").AbsoluteUri);
		}
		if (Executor.CoreWebView2 != null)
		{
			Executor.CoreWebView2.WebMessageReceived += Executor_WebMessageReceived;
			Executor.CoreWebView2.NewWindowRequested += delegate(object? sender, CoreWebView2NewWindowRequestedEventArgs e)
			{
				e.Handled = true;
				Process.Start(new ProcessStartInfo
				{
					FileName = e.Uri,
					UseShellExecute = true
				});
			};
			Executor.CoreWebView2.Navigate(GetPageUri("Monaco.html").AbsoluteUri);
		}
		if (ScriptHub.CoreWebView2 != null)
		{
			ScriptHub.CoreWebView2.WebMessageReceived += ScriptHub_WebMessageReceived;
			ScriptHub.CoreWebView2.Navigate(GetPageUri("ScriptHub.html").AbsoluteUri);
		}
		if (SettingsTab.CoreWebView2 != null)
		{
			SettingsTab.CoreWebView2.Navigate(GetPageUri("Settings.html").AbsoluteUri);
		}
		if (TitleText.CoreWebView2 != null)
		{
			TitleText.CoreWebView2.Navigate(GetPageUri("Title.html").AbsoluteUri);
		}
		if (ControlBox.CoreWebView2 != null)
		{
			ControlBox.CoreWebView2.WebMessageReceived += ControlBox_WebMessageReceived;
			ControlBox.CoreWebView2.Navigate(GetPageUri("ControlBox.html").AbsoluteUri);
		}
		if (PageTab.CoreWebView2 != null)
		{
			PageTab.WebMessageReceived += delegate(object? s, CoreWebView2WebMessageReceivedEventArgs args)
			{
				string tabName = args.TryGetWebMessageAsString();
				HandleTabSwitch(tabName);
			};
			PageTab.CoreWebView2.NewWindowRequested += delegate(object? sender, CoreWebView2NewWindowRequestedEventArgs args)
			{
				args.Handled = true;
				Process.Start(new ProcessStartInfo
				{
					FileName = args.Uri,
					UseShellExecute = true
				});
			};
			PageTab.CoreWebView2.Navigate(GetPageUri("PageBtn.html").AbsoluteUri);
		}
	}

	private async void InitExplorer(bool silent = false)
	{
		await Task.Delay(500);
		string text = Path.Combine(Application.StartupPath, "Scripts");
		string text2 = Path.Combine(Application.StartupPath, "AutoExec");
		string text3 = Path.Combine(Application.StartupPath, "Workspace");
		if (!Directory.Exists(text))
		{
			Directory.CreateDirectory(text);
		}
		if (!Directory.Exists(text2))
		{
			Directory.CreateDirectory(text2);
		}
		if (!Directory.Exists(text3))
		{
			Directory.CreateDirectory(text3);
		}
		List<ExplorerNode> children = BuildExplorerTree(text);
		List<ExplorerNode> children2 = BuildExplorerTree(text2);
		List<ExplorerNode> children3 = BuildExplorerTree(text3);
		string value = JsonSerializer.Serialize(new object[3]
		{
			new
			{
				name = "Scripts",
				icon = "fas fa-scroll",
				children = children,
				readOnly = false
			},
			new
			{
				name = "AutoExec",
				icon = "fas fa-bolt",
				children = children2,
				readOnly = false
			},
			new
			{
				name = "Workspace",
				icon = "fas fa-folder",
				children = children3,
				readOnly = false
			}
		});
		string value2 = (silent ? "false" : "true");
		await Executor.CoreWebView2.ExecuteScriptAsync($"renderTree({value}, {value2})");
	}

	private string ResolveManagedFilePath(JsonElement root, string folderName)
	{
		string text = ((root.TryGetProperty("path", out var value) && !string.IsNullOrEmpty(value.GetString())) ? value.GetString() : (root.TryGetProperty("name", out var value2) ? value2.GetString() : null));
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		string text2 = Path.Combine(Application.StartupPath, folderName);
		string fullPath = Path.GetFullPath(Path.Combine(text2, text));
		string fullPath2 = Path.GetFullPath(text2);
		if (!fullPath.StartsWith(fullPath2, StringComparison.OrdinalIgnoreCase))
		{
			return null;
		}
		return fullPath;
	}

	private void Animation_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
	{
		if (e.TryGetWebMessageAsString() == "AnimationFinished")
		{
			((Control)(object)Animation).Visible = false;
			SwitchTo(guna2Panel1);
		}
	}

	private async void Executor_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
	{
		string webMessageAsJson;
		try
		{
			webMessageAsJson = e.WebMessageAsJson;
		}
		catch (Exception)
		{
			return;
		}
		if (string.IsNullOrWhiteSpace(webMessageAsJson))
		{
			return;
		}
		try
		{
			using JsonDocument doc = JsonDocument.Parse(webMessageAsJson);
			JsonElement rootElement = doc.RootElement;
			string text = null;
			JsonElement value2;
			if (rootElement.TryGetProperty("action", out var value))
			{
				text = value.GetString();
			}
			else if (rootElement.TryGetProperty("type", out value2))
			{
				text = value2.GetString();
			}
			if (text == null)
			{
				return;
			}
			if (text == null)
			{
				return;
			}
			switch (text.Length)
			{
			default:
				goto end_IL_0088;
			case 12:
				switch (text[0])
				{
				case 'l':
					if (text == "launchRoblox")
					{
						LaunchRoblox();
					}
					break;
				case 'b':
					if (text == "browseScript")
					{
						OpenScriptHub();
					}
					break;
				case 'r':
					if (text == "refreshFiles")
					{
						bool silent = rootElement.TryGetProperty("silent", out var value5) && value5.GetBoolean();
						InitExplorer(silent);
					}
					break;
				case 'c':
				{
					if (!(text == "createFolder"))
					{
						break;
					}
					string text2 = rootElement.GetProperty("folder").GetString();
					string text3 = (rootElement.TryGetProperty("path", out var value6) ? value6.GetString() : "");
					if (text2 != "Scripts" && text2 != "AutoExec")
					{
						break;
					}
					string text4 = Path.Combine(Application.StartupPath, text2);
					string path4 = (string.IsNullOrEmpty(text3) ? text4 : Path.Combine(text4, text3));
					string fullPath = Path.GetFullPath(text4);
					string fullPath2 = Path.GetFullPath(path4);
					if (!fullPath2.StartsWith(fullPath, StringComparison.OrdinalIgnoreCase))
					{
						break;
					}
					if (!Directory.Exists(fullPath2))
					{
						Directory.CreateDirectory(fullPath2);
					}
					FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
					{
						Description = "Select Folder to Import",
						UseDescriptionForTitle = true
					};
					if (folderBrowserDialog.ShowDialog() != DialogResult.OK)
					{
						break;
					}
					try
					{
						string selectedPath = folderBrowserDialog.SelectedPath;
						string fileName = Path.GetFileName(selectedPath.TrimEnd(Path.DirectorySeparatorChar));
						string msg = Path.Combine(fullPath2, fileName);
						if (Directory.Exists(msg))
						{
							int num = 1;
							while (Directory.Exists(msg))
							{
								msg = Path.Combine(fullPath2, $"{fileName} ({num})");
								num++;
							}
						}
						CopyDirectoryRecursive(selectedPath, msg);
						await Executor.ExecuteScriptAsync("EditorAPI.notify('success', 'Folder imported: " + Path.GetFileName(msg) + "');");
						await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('success', 'Folder imported: " + Path.GetFileName(msg) + "')");
					}
					catch (Exception)
					{
					}
					InitExplorer();
					break;
				}
				case 'd':
				{
					if (!(text == "deleteFolder"))
					{
						break;
					}
					string path = rootElement.GetProperty("folder").GetString();
					string path2 = rootElement.GetProperty("path").GetString();
					string path3 = Path.Combine(Application.StartupPath, path, path2);
					try
					{
						if (Directory.Exists(path3))
						{
							Directory.Delete(path3, recursive: true);
						}
					}
					catch (Exception)
					{
					}
					InitExplorer(silent: true);
					break;
				}
				}
				goto end_IL_0088;
			case 14:
				switch (text[0])
				{
				default:
					goto end_IL_0088;
				case 's':
					if (text == "startNewClient")
					{
						LaunchRoblox();
					}
					goto end_IL_0088;
				case 'c':
					if (text == "contentChanged")
					{
						string tabName = rootElement.GetProperty("tabName").GetString();
						string content = rootElement.GetProperty("content").GetString();
						AutoSaveIfMatchesFile(tabName, content);
					}
					goto end_IL_0088;
				case 'p':
					if (text == "progressUpdate")
					{
						break;
					}
					goto end_IL_0088;
				}
				break;
			case 6:
				switch (text[0])
				{
				default:
					goto end_IL_0088;
				case 'a':
					if (text == "attach")
					{
						Attach_Click(null, null);
					}
					goto end_IL_0088;
				case 'n':
					if (text == "notify")
					{
						break;
					}
					goto end_IL_0088;
				}
				break;
			case 9:
				switch (text[0])
				{
				case 'i':
				{
					if (text == "injectPid" && rootElement.TryGetProperty("pid", out var value12) && value12.TryGetInt32(out var value13))
					{
						InjectSinglePidAsync(value13);
					}
					break;
				}
				case 'c':
					if (text == "clearFile")
					{
						string folderName5 = rootElement.GetProperty("folder").GetString();
						string text14 = ResolveManagedFilePath(rootElement, folderName5);
						if (text14 != null && File.Exists(text14))
						{
							File.WriteAllText(text14, string.Empty);
						}
						InitExplorer();
					}
					break;
				}
				goto end_IL_0088;
			case 4:
				switch (text[0])
				{
				case 'o':
					if (text == "open")
					{
						Open_Click(null, null);
					}
					break;
				case 's':
					if (text == "save")
					{
						Save_Click(null, null);
					}
					break;
				}
				goto end_IL_0088;
			case 10:
				switch (text[0])
				{
				case 's':
					if (text == "saveOutput")
					{
						HandleSaveOutput(rootElement);
					}
					break;
				case 'r':
					if (text == "renameFile")
					{
						string oldName = rootElement.GetProperty("oldName").GetString();
						string newName = rootElement.GetProperty("newName").GetString();
						RenameManagedFile(oldName, newName);
					}
					break;
				case 'c':
				{
					if (!(text == "createFile"))
					{
						break;
					}
					string path6 = rootElement.GetProperty("folder").GetString();
					string text10 = (rootElement.TryGetProperty("path", out var value10) ? value10.GetString() : "");
					string text11 = Path.Combine(Application.StartupPath, path6);
					string path7 = (string.IsNullOrEmpty(text10) ? text11 : Path.Combine(text11, text10));
					string fullPath3 = Path.GetFullPath(text11);
					string fullPath4 = Path.GetFullPath(path7);
					if (!fullPath4.StartsWith(fullPath3, StringComparison.OrdinalIgnoreCase))
					{
						break;
					}
					if (!Directory.Exists(fullPath4))
					{
						Directory.CreateDirectory(fullPath4);
					}
					OpenFileDialog openFileDialog = new OpenFileDialog
					{
						Title = "Select Script File(s)",
						Filter = "Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
						Multiselect = true
					};
					if (openFileDialog.ShowDialog() != DialogResult.OK)
					{
						break;
					}
					int num2 = 0;
					string[] fileNames = openFileDialog.FileNames;
					foreach (string text12 in fileNames)
					{
						try
						{
							string fileName2 = Path.GetFileName(text12);
							string text13 = Path.Combine(fullPath4, fileName2);
							if (File.Exists(text13))
							{
								string fileNameWithoutExtension2 = Path.GetFileNameWithoutExtension(fileName2);
								string extension = Path.GetExtension(fileName2);
								int num4 = 1;
								while (File.Exists(text13))
								{
									text13 = Path.Combine(fullPath4, $"{fileNameWithoutExtension2} ({num4}){extension}");
									num4++;
								}
							}
							File.Copy(text12, text13);
							num2++;
						}
						catch (Exception)
						{
						}
					}
					if (num2 > 0)
					{
						string msg = ((num2 == 1) ? "1 file imported" : $"{num2} files imported");
						await Executor.ExecuteScriptAsync("EditorAPI.notify('success', '" + msg + "');");
						await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('success', '" + msg + "')");
					}
					InitExplorer();
					break;
				}
				case 'd':
				{
					if (!(text == "deleteFile"))
					{
						break;
					}
					string folderName4 = rootElement.GetProperty("folder").GetString();
					string text9 = ResolveManagedFilePath(rootElement, folderName4);
					try
					{
						if (text9 != null)
						{
							if (File.Exists(text9))
							{
								File.Delete(text9);
							}
							else if (Directory.Exists(text9))
							{
								Directory.Delete(text9, recursive: true);
							}
						}
					}
					catch (Exception)
					{
					}
					InitExplorer();
					break;
				}
				}
				goto end_IL_0088;
			case 11:
				switch (text[1])
				{
				case 'd':
					if (text == "editorReady")
					{
						LoadStartupFolders();
						PushExplorerSettingsAsync();
					}
					break;
				case 'x':
				{
					if (!(text == "executeFile"))
					{
						break;
					}
					string folderName3 = rootElement.GetProperty("folder").GetString();
					string text7 = ResolveManagedFilePath(rootElement, folderName3);
					if (text7 == null || !File.Exists(text7))
					{
						break;
					}
					string text8 = File.ReadAllText(text7);
					quorum.ExecuteScript(text8);
					int successCount = _selectedPids.Count;
					if (successCount > 0)
					{
						await Executor.ExecuteScriptAsync($"EditorAPI.notify('success', 'Successfully Executed on {successCount} Client(s)');");
						await Executor.CoreWebView2.ExecuteScriptAsync($"window.WinFormOutput('success', 'Successfully Executed Script on {successCount} Client(s)')");
						break;
					}
					if (!IsRobloxWindowReady())
					{
						await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'No Client Found');");
						await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'No Client Found')");
						return;
					}
					if (_selectedPids.Count != 0)
					{
						break;
					}
					await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'No Clients Selected');");
					await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'No Clients Selected')");
					return;
				}
				}
				goto end_IL_0088;
			case 8:
				switch (text[0])
				{
				case 'o':
					if (text == "openFile")
					{
						string folderName2 = rootElement.GetProperty("folder").GetString();
						string path5 = rootElement.GetProperty("name").GetString();
						string text6 = ResolveManagedFilePath(rootElement, folderName2);
						if (text6 != null && File.Exists(text6))
						{
							string value8 = File.ReadAllText(text6);
							string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(path5);
							await Executor.ExecuteScriptAsync($"window.ExternalAPI.addNewTab({JsonSerializer.Serialize(fileNameWithoutExtension)}, {JsonSerializer.Serialize(value8)}, {JsonSerializer.Serialize(text6)})");
						}
					}
					break;
				case 'c':
					if (text == "copyFile")
					{
						string folderName = rootElement.GetProperty("folder").GetString();
						string text5 = ResolveManagedFilePath(rootElement, folderName);
						if (text5 != null && File.Exists(text5))
						{
							Clipboard.SetText(File.ReadAllText(text5));
							await Executor.ExecuteScriptAsync("window.ExternalAPI.notify('success', " + JsonSerializer.Serialize("Script copied to clipboard") + ")");
						}
					}
					break;
				}
				goto end_IL_0088;
			case 18:
				switch (text[0])
				{
				case 'g':
					if (!(text == "ghDeviceLoginStart"))
					{
						break;
					}
					GitHubDeviceFlow.StartAsync(delegate(string text16)
					{
						if (((Control)(object)Executor).InvokeRequired)
						{
							((Control)(object)Executor).Invoke((Action)delegate
							{
								Executor.CoreWebView2.PostWebMessageAsJson(text16);
							});
						}
						else
						{
							Executor.CoreWebView2.PostWebMessageAsJson(text16);
						}
					});
					break;
				case 'r':
					if (text == "robloxCrashRestart")
					{
						bool result2 = rootElement.TryGetProperty("shouldRestart", out var value9) && value9.GetBoolean();
						_crashRestartTcs?.TrySetResult(result2);
					}
					break;
				}
				goto end_IL_0088;
			case 7:
				if (text == "execute")
				{
					_pendingExecuteCode = (rootElement.TryGetProperty("code", out var value11) ? value11.GetString() : null);
					Execute_Click(null, null);
				}
				goto end_IL_0088;
			case 19:
				if (text == "ghDeviceLoginCancel")
				{
					GitHubDeviceFlow.Cancel();
				}
				goto end_IL_0088;
			case 17:
				if (text == "downgradeDecision")
				{
					bool result = rootElement.TryGetProperty("confirmed", out var value7) && value7.GetBoolean();
					_downgradeDecisionTcs?.TrySetResult(result);
				}
				goto end_IL_0088;
			case 22:
				if (text == "add_defender_exception")
				{
					string startupPath = Application.StartupPath;
					string value3 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox", "Versions");
					string value4 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "win.nexomia");
					Process.Start(new ProcessStartInfo("powershell", $"-Command \"$paths = @('{startupPath}', '{value3}', '{value4}'); foreach ($p in $paths) {{     if ((Get-MpPreference).ExclusionPath -notcontains $p) {{         Add-MpPreference -ExclusionPath $p;     }} }}\"")
					{
						CreateNoWindow = true,
						UseShellExecute = true,
						Verb = "runas",
						WindowStyle = ProcessWindowStyle.Hidden
					});
					Application.Restart();
				}
				goto end_IL_0088;
			case 13:
				if (text == "progressStart")
				{
					break;
				}
				goto end_IL_0088;
			case 16:
				if (text == "progressComplete")
				{
					break;
				}
				goto end_IL_0088;
			}
			string text15 = text switch
			{
				"notify" => BuildNotifyScript(rootElement), 
				"progressStart" => BuildProgressStartScript(rootElement), 
				"progressUpdate" => BuildProgressUpdateScript(rootElement), 
				"progressComplete" => BuildProgressCompleteScript(rootElement), 
				_ => null, 
			};
			if (text15 != null)
			{
				CoreWebView2 coreWebView = Dashboard.CoreWebView2;
				if (coreWebView != null)
				{
					coreWebView.ExecuteScriptAsync(text15);
				}
				CoreWebView2 coreWebView2 = ScriptHub.CoreWebView2;
				if (coreWebView2 != null)
				{
					coreWebView2.ExecuteScriptAsync(text15);
				}
				CoreWebView2 coreWebView3 = SettingsTab.CoreWebView2;
				if (coreWebView3 != null)
				{
					coreWebView3.ExecuteScriptAsync(text15);
				}
			}
			end_IL_0088:;
		}
		catch (Exception)
		{
		}
	}

	private void CopyDirectoryRecursive(string sourceDir, string destDir)
	{
		Directory.CreateDirectory(destDir);
		string[] directories = Directory.GetDirectories(sourceDir, "*", SearchOption.AllDirectories);
		for (int i = 0; i < directories.Length; i++)
		{
			Directory.CreateDirectory(directories[i].Replace(sourceDir, destDir));
		}
		directories = Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories);
		foreach (string obj in directories)
		{
			string destFileName = obj.Replace(sourceDir, destDir);
			File.Copy(obj, destFileName, overwrite: true);
		}
	}

	private void AutoSaveIfMatchesFile(string tabName, string content)
	{
		string[] array = new string[2] { "Scripts", "AutoExec" };
		foreach (string path in array)
		{
			string path2 = Path.Combine(Application.StartupPath, path);
			if (!Directory.Exists(path2))
			{
				continue;
			}
			string[] array2 = new string[2] { ".lua", ".txt" };
			foreach (string text in array2)
			{
				string[] files = Directory.GetFiles(path2, tabName + text, SearchOption.AllDirectories);
				if (files.Length != 0)
				{
					try
					{
						File.WriteAllText(files[0], content);
						return;
					}
					catch
					{
						return;
					}
				}
			}
		}
	}

	private void RenameManagedFile(string oldName, string newName)
	{
		string[] array = new string[2] { "Scripts", "AutoExec" };
		foreach (string path in array)
		{
			string path2 = Path.Combine(Application.StartupPath, path);
			if (!Directory.Exists(path2))
			{
				continue;
			}
			string[] array2 = new string[2] { ".lua", ".txt" };
			foreach (string text in array2)
			{
				string[] files = Directory.GetFiles(path2, oldName + text, SearchOption.AllDirectories);
				if (files.Length == 0)
				{
					continue;
				}
				string text2 = files[0];
				string text3 = Path.Combine(Path.GetDirectoryName(text2), newName + text);
				try
				{
					if (!File.Exists(text3))
					{
						File.Move(text2, text3);
						InitExplorer();
					}
					return;
				}
				catch
				{
					return;
				}
			}
		}
	}

	private void LoadStartupFolders()
	{
		string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
		LoadFolder(Path.Combine(baseDirectory, "AutoExec"));
		LoadFolder(Path.Combine(baseDirectory, "Scripts"));
	}

	private void LoadFolder(string folderPath)
	{
		if (!Directory.Exists(folderPath))
		{
			return;
		}
		foreach (string item in from f in Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories)
			where f.EndsWith(".lua", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".txt", StringComparison.OrdinalIgnoreCase)
			select f)
		{
			string value;
			try
			{
				value = File.ReadAllText(item, Encoding.UTF8);
			}
			catch
			{
				continue;
			}
			string text = $"window.WinFormOpenFile({JsonSerializer.Serialize(item)}, {JsonSerializer.Serialize(value)}, {JsonSerializer.Serialize(Path.GetFileNameWithoutExtension(item))})";
			Executor.CoreWebView2.ExecuteScriptAsync(text);
		}
	}

	private void HandleSaveOutput(JsonElement root)
	{
		string content = root.GetProperty("content").GetString();
		string fileName = (root.TryGetProperty("filename", out var value) ? value.GetString() : "output.txt");
		SaveFileDialog sfd = new SaveFileDialog();
		try
		{
			sfd.FileName = fileName;
			sfd.Filter = "Text File (*.txt)|*.txt|All Files (*.*)|*.*";
			sfd.Title = "Save Output";
			Invoke((MethodInvoker)delegate
			{
				if (sfd.ShowDialog(this) == DialogResult.OK)
				{
					File.WriteAllText(sfd.FileName, content, Encoding.UTF8);
				}
			});
		}
		finally
		{
			if (sfd != null)
			{
				((IDisposable)sfd).Dispose();
			}
		}
	}

	private async Task OpenScriptHub()
	{
		await PageTab.CoreWebView2.ExecuteScriptAsync("window.NavAPI.setActive('ScriptHub');");
		await Executor.CoreWebView2.ExecuteScriptAsync("window.playExitAnimation();");
		await Task.Delay(360);
		SwitchTo(guna2Panel6);
		currentTab = "ScriptHub";
		await ScriptHub.ExecuteScriptAsync("AppAnimation.play('full');");
	}

	private string BuildNotifyScript(JsonElement root)
	{
		string value = JsonSerializer.Serialize(root.GetProperty("message").GetString());
		JsonElement property = root.GetProperty("isError");
		string value2 = property.ValueKind switch
		{
			JsonValueKind.True => "true", 
			JsonValueKind.False => "false", 
			JsonValueKind.String => JsonSerializer.Serialize(property.GetString()), 
			_ => "false", 
		};
		return $"window.showNotification && window.showNotification({value}, {value2});";
	}

	private string BuildProgressStartScript(JsonElement root)
	{
		string value = JsonSerializer.Serialize(root.GetProperty("message").GetString());
		double value2 = root.GetProperty("durationSeconds").GetDouble();
		return $"window.showProgressNotification && window.showProgressNotification({value}, {value2});";
	}

	private string BuildProgressUpdateScript(JsonElement root)
	{
		double value = root.GetProperty("percent").GetDouble();
		return $"window.updateProgressNotification && window.updateProgressNotification({value});";
	}

	private string BuildProgressCompleteScript(JsonElement root)
	{
		string text = ((root.TryGetProperty("message", out var value) && value.ValueKind == JsonValueKind.String) ? JsonSerializer.Serialize(value.GetString()) : "undefined");
		return "window.completeProgressNotification && window.completeProgressNotification(" + text + ");";
	}

	private async void ScriptHub_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
	{
		_ = 5;
		try
		{
			JObject val = JObject.Parse(e.WebMessageAsJson);
			string text = ((object)val["type"])?.ToString();
			if (text == "execute")
			{
				string text2 = ((object)val["script"])?.ToString();
				quorum.ExecuteScript(text2);
				int successCount = _selectedPids.Count;
				if (successCount > 0)
				{
					await Executor.ExecuteScriptAsync($"EditorAPI.notify('success', 'Successfully Executed on {successCount} Client(s)');");
					await Executor.CoreWebView2.ExecuteScriptAsync($"window.WinFormOutput('success', 'Successfully Executed on {successCount} Client(s)')");
				}
				else if (!IsRobloxWindowReady())
				{
					await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'No Client Found');");
					await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'No Client Found')");
				}
				else if (_selectedPids.Count == 0)
				{
					await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'No Clients Selected');");
					await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'No Clients Selected')");
				}
			}
			else if (text == "openInTab")
			{
				JToken val2 = val["case"];
				if (val2 != null)
				{
					OpenScriptInNewTab(val2);
				}
			}
		}
		catch (Exception)
		{
		}
	}

	private async void OpenScriptInNewTab(JToken c)
	{
		string text = ((object)c[(object)"title"])?.ToString() ?? "Untitled";
		string text2 = ((object)c[(object)"script"])?.ToString() ?? "";
		string text3 = $"window.ExternalAPI.addNewTab( {JsonConvert.SerializeObject((object)text)}, {JsonConvert.SerializeObject((object)text2)} );";
		await Executor.CoreWebView2.ExecuteScriptAsync(text3);
		await PageTab.CoreWebView2.ExecuteScriptAsync("window.NavAPI.setActive('Executor');");
		await ScriptHub.CoreWebView2.ExecuteScriptAsync("window.playExitAnimation();");
		await Task.Delay(360);
		SwitchTo(guna2Panel1);
		currentTab = "Executor";
		await Executor.ExecuteScriptAsync("window.AnimationAPI.playGlobalIntro()");
	}

	private void StartGameHubListener()
	{
		try
		{
			_gameHubListener = new HttpListener();
			_gameHubListener.Prefixes.Add($"http://127.0.0.1:{47899}/gamehub/");
			_gameHubListener.Start();
			Task.Run((Func<Task?>)GameHubListenLoop);
		}
		catch (Exception)
		{
		}
	}

	private async Task GameHubListenLoop()
	{
		while (_gameHubListener != null && _gameHubListener.IsListening)
		{
			HttpListenerContext ctx;
			try
			{
				ctx = await _gameHubListener.GetContextAsync();
			}
			catch
			{
				break;
			}
			try
			{
				using StreamReader reader = new StreamReader(ctx.Request.InputStream, ctx.Request.ContentEncoding);
				string placeId = (await reader.ReadToEndAsync())?.Trim();
				ctx.Response.StatusCode = 200;
				ctx.Response.Close();
				_lastGameHubResponseAt = DateTime.UtcNow;
				if (!string.IsNullOrWhiteSpace(placeId))
				{
					string gameName = await ResolveGameNameFromPlaceIdAsync(placeId);
					BeginInvoke(delegate
					{
						SendGameToScriptHub(placeId, gameName);
					});
				}
			}
			catch
			{
				try
				{
					ctx.Response.Close();
				}
				catch
				{
				}
			}
		}
	}

	private async Task<string?> ResolveGameNameFromPlaceIdAsync(string placeId)
	{
		_ = 1;
		try
		{
			using JsonDocument uDoc = JsonDocument.Parse(await _http.GetStringAsync("https://apis.roblox.com/universes/v1/places/" + placeId + "/universe"));
			if (!uDoc.RootElement.TryGetProperty("universeId", out var value))
			{
				return null;
			}
			string rawText = value.GetRawText();
			using JsonDocument jsonDocument = JsonDocument.Parse(await _http.GetStringAsync("https://games.roblox.com/v1/games?universeIds=" + rawText));
			JsonElement property = jsonDocument.RootElement.GetProperty("data");
			if (property.GetArrayLength() == 0)
			{
				return null;
			}
			return property[0].GetProperty("name").GetString();
		}
		catch
		{
			return null;
		}
	}

	private void SendGameToScriptHub(string placeId, string? gameName)
	{
		if (placeId == _lastDetectedGame)
		{
			return;
		}
		_lastDetectedGame = placeId;
		if (!string.IsNullOrWhiteSpace(gameName))
		{
			var value = new
			{
				action = "gameDetected",
				game = gameName
			};
			CoreWebView2 coreWebView = ScriptHub.CoreWebView2;
			if (coreWebView != null)
			{
				coreWebView.PostWebMessageAsJson(JsonSerializer.Serialize(value));
			}
		}
	}

	private void ClearGameHub()
	{
		_lastGameHubResponseAt = DateTime.MinValue;
		if (_lastDetectedGame != null)
		{
			_lastDetectedGame = null;
			var value = new
			{
				action = "gameCleared"
			};
			CoreWebView2 coreWebView = ScriptHub.CoreWebView2;
			if (coreWebView != null)
			{
				coreWebView.PostWebMessageAsJson(JsonSerializer.Serialize(value));
			}
		}
	}

	private async Task LoadSettings()
	{
		SettingsManager.Load();
		SyncStartupState();
		SetAcrylic(SettingsManager.Current.AcrylicBlur, 180);
		base.Opacity = (double)Math.Clamp(SettingsManager.Current.WindowOpacity, 20, 100) / 100.0;
		base.TopMost = SettingsManager.Current.AlwaysOnTop;
		if (SettingsManager.Current.WindowX < 0 || SettingsManager.Current.WindowY < 0)
		{
			CenterToScreen();
		}
		else
		{
			base.StartPosition = FormStartPosition.Manual;
			base.Location = new Point(SettingsManager.Current.WindowX, SettingsManager.Current.WindowY);
		}
		if (SettingsManager.Current.WindowWidth > 0 && SettingsManager.Current.WindowHeight > 0)
		{
			base.Width = SettingsManager.Current.WindowWidth;
			base.Height = SettingsManager.Current.WindowHeight;
		}
		if (!SettingsManager.Current.AutoSaveWindowPosition)
		{
			CenterToScreen();
		}
		if (SettingsManager.Current.AntiScreenRecorder)
		{
			SetWindowDisplayAffinity(base.Handle, 17u);
		}
		if (SettingsManager.Current.DiscordRPC)
		{
			rpc.ResetTime();
			rpc.Start();
			rpcEnabled = true;
		}
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			int value = ((SettingsManager.Current.FontSize > 0) ? SettingsManager.Current.FontSize : 15);
			await Executor.ExecuteScriptAsync($"EditorAPI.setFontSize({value});");
			string text = JsonSerializer.Serialize("'" + SettingsManager.Current.Font + "', Consolas, 'Courier New', monospace");
			await Executor.CoreWebView2.ExecuteScriptAsync("window.EditorAPI?.setFontFamily(" + text + ");");
			await Task.Delay(500);
			await ApplyMiniMapOptionsAsync();
			await Executor.CoreWebView2.ExecuteScriptAsync("EditorAPI.setLineNumbers(" + SettingsManager.Current.LineNumber.ToString().ToLower() + ");");
			await Executor.CoreWebView2.ExecuteScriptAsync("EditorAPI.setWordWrap(" + SettingsManager.Current.WordWrap.ToString().ToLower() + ");");
			await Executor.ExecuteScriptAsync("window.EditorAPI?.setAutoSave(" + SettingsManager.Current.AutoSaveScript.ToString().ToLower() + ");");
			await Executor.ExecuteScriptAsync(SettingsManager.Current.MeteorEffect ? "toggleMeteor(true);" : "toggleMeteor(false);");
		}
		if (SettingsManager.Current.AutoLaunchRoblox && Process.GetProcessesByName("RobloxPlayerBeta").Length == 0 && (SettingsManager.Current?.AutoLaunchRoblox ?? false))
		{
			LaunchRoblox();
		}
		RegisterAllHotkeys();
	}

	private void SettingsTab_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
	{
		string json = e.TryGetWebMessageAsString();
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(json);
			JsonElement rootElement = jsonDocument.RootElement;
			string text = rootElement.GetProperty("type").GetString();
			string key = rootElement.GetProperty("key").GetString();
			switch (text)
			{
			case "toggle":
			{
				bool boolean = rootElement.GetProperty("value").GetBoolean();
				ApplySetting(key, boolean);
				break;
			}
			case "value":
			{
				JsonElement property = rootElement.GetProperty("value");
				object value = ((property.ValueKind == JsonValueKind.Number) ? property.GetRawText() : property.GetString());
				ApplySetting(key, value);
				break;
			}
			case "action":
				ApplySetting(key, null);
				break;
			}
		}
		catch (Exception)
		{
		}
	}

	private void ToggleBossKey()
	{
		int windowLong = GetWindowLong(base.Handle, -20);
		if (!_bossKeyHidden)
		{
			SetWindowLong(base.Handle, -20, windowLong | 0x80000 | 0x20);
			SetLayeredWindowAttributes(base.Handle, 0u, 0, 2u);
		}
		else
		{
			SetLayeredWindowAttributes(base.Handle, 0u, byte.MaxValue, 2u);
			SetWindowLong(base.Handle, -20, windowLong & -33);
		}
		_bossKeyHidden = !_bossKeyHidden;
	}

	private void InitSettings()
	{
		if (SettingsTab?.CoreWebView2 != null)
		{
			SettingsTab.CoreWebView2.WebMessageReceived += SettingsTab_WebMessageReceived;
			SettingsTab.CoreWebView2.NavigationCompleted += delegate
			{
				PushInitialSettings();
			};
			PushInitialSettings();
		}
	}

	private void PushToSettingsTab(string message)
	{
		WebView2 settingsTab = SettingsTab;
		if (((settingsTab != null) ? settingsTab.CoreWebView2 : null) != null)
		{
			SettingsTab.CoreWebView2.PostWebMessageAsString(message);
		}
	}

	private void SyncStartupState()
	{
		SettingsManager.Current.AutoLaunchOnStartup = IsStartupEnabled();
	}

	private bool IsStartupEnabled()
	{
		using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", writable: false);
		return registryKey?.GetValue("Crescent") != null;
	}

	private void OnAnyWebView_ThemeMessage(object sender, CoreWebView2WebMessageReceivedEventArgs e)
	{
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(e.WebMessageAsJson);
			JsonElement rootElement = jsonDocument.RootElement;
			if (rootElement.TryGetProperty("action", out var value) && value.GetString() == "themeChanged" && rootElement.TryGetProperty("theme", out var value2) && !(SettingsManager.Current.Theme == "device"))
			{
				string theme = value2.GetString();
				SettingsManager.Current.Theme = theme;
				SettingsManager.Save();
				ApplyThemeToAllWebViews(theme);
			}
		}
		catch
		{
		}
	}

	private void ApplyThemeToForm(string theme)
	{
		bool num = theme == "light";
		Color color = (num ? Color.FromArgb(243, 243, 243) : Color.FromArgb(12, 12, 12));
		Color fg = (num ? Color.FromArgb(20, 20, 20) : Color.FromArgb(220, 220, 220));
		Color barBg = (num ? Color.FromArgb(235, 235, 235) : Color.FromArgb(18, 18, 18));
		BackColor = color;
		ApplyThemeToControls(base.Controls, color, fg, barBg, theme);
	}

	private void ApplyThemeToControls(Control.ControlCollection controls, Color bg, Color fg, Color barBg, string theme)
	{
		bool num = theme == "light";
		if (!num)
		{
			Color.FromArgb(45, 45, 45);
		}
		else
		{
			Color.FromArgb(216, 216, 216);
		}
		if (!num)
		{
			Color.FromArgb(35, 35, 35);
		}
		else
		{
			Color.FromArgb(216, 216, 216);
		}
		((Control)(object)guna2Panel3).BackColor = bg;
		((Control)(object)guna2PictureBox1).BackColor = bg;
		guna2PictureBox1.FillColor = bg;
		((Control)(object)guna2Panel1).BackColor = bg;
		((Control)(object)guna2Panel6).BackColor = bg;
	}

	private string GetSystemTheme()
	{
		try
		{
			using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize");
			object obj = registryKey?.GetValue("AppsUseLightTheme");
			if (obj is int)
			{
				return ((int)obj == 0) ? "dark" : "light";
			}
		}
		catch
		{
		}
		return "dark";
	}

	private string ResolveActualTheme(string themePreference)
	{
		if (!(themePreference == "device"))
		{
			return themePreference;
		}
		return GetSystemTheme();
	}

	private async void ApplyThemeToAllWebViews(string theme)
	{
		if (_applyingTheme)
		{
			return;
		}
		_applyingTheme = true;
		try
		{
			string text = ResolveActualTheme(theme);
			text = ((text == "light") ? "light" : "dark");
			string script = ((text == "light") ? "window.ThemeAPI && ThemeAPI.setLight();" : "window.ThemeAPI && ThemeAPI.setDark();");
			if (base.IsHandleCreated && !base.IsDisposed)
			{
				ApplyThemeToForm(text);
			}
			WebView2[] array = (WebView2[])(object)new WebView2[7] { ScriptHub, PageTab, SettingsTab, Executor, Dashboard, ControlBox, TitleText };
			foreach (WebView2 val in array)
			{
				try
				{
					if (((val != null) ? val.CoreWebView2 : null) != null)
					{
						await val.CoreWebView2.ExecuteScriptAsync(script);
					}
				}
				catch
				{
				}
			}
			SettingsManager.Current.Theme = theme;
			SettingsManager.Save();
		}
		catch
		{
		}
		finally
		{
			_applyingTheme = false;
		}
	}

	private void PushInitialSettings()
	{
		if (SettingsTab?.CoreWebView2 != null)
		{
			string text = JsonSerializer.Serialize(SettingsManager.Current);
			SettingsTab.CoreWebView2.PostWebMessageAsString("init:" + text);
		}
	}

	private void ApplySetting(string key, object value)
	{
		switch (key)
		{
		case "AutoLaunchOnStartup":
			SettingsManager.Current.AutoLaunchOnStartup = (bool)value;
			OnAutoLaunchOnStartupChanged((bool)value);
			break;
		case "AutoAttach":
			SettingsManager.Current.AutoAttach = (bool)value;
			OnAutoAttachChanged((bool)value);
			break;
		case "AutoLaunchRoblox":
			SettingsManager.Current.AutoLaunchRoblox = (bool)value;
			break;
		case "FpsUnlocker":
			SettingsManager.Current.FpsUnlocker = (bool)value;
			OnFpsUnlockerChanged((bool)value);
			break;
		case "CrashDetection":
			SettingsManager.Current.CrashDetection = (bool)value;
			break;
		case "Language":
			SettingsManager.Current.Language = value.ToString();
			OnLanguageChanged(value.ToString());
			break;
		case "DefaultTab":
			SettingsManager.Current.DefaultTab = value.ToString();
			break;
		case "Theme":
			SettingsManager.Current.Theme = value.ToString();
			ApplyThemeToAllWebViews(value.ToString());
			break;
		case "AlwaysOnTop":
			SettingsManager.Current.AlwaysOnTop = (bool)value;
			OnAlwaysOnTopChanged((bool)value);
			break;
		case "AutoSaveWindowPosition":
			SettingsManager.Current.AutoSaveWindowPosition = (bool)value;
			break;
		case "ResetWindowSize":
			OnResetWindowSize();
			break;
		case "UpdateWindowSize":
			OnUpdateWindowSize();
			break;
		case "AntiScreenRecorder":
			SettingsManager.Current.AntiScreenRecorder = (bool)value;
			OnAntiScreenRecorderChanged((bool)value);
			break;
		case "DiscordRPC":
			SettingsManager.Current.DiscordRPC = (bool)value;
			OnDiscordRPCChanged((bool)value);
			break;
		case "AcrylicBlur":
			SettingsManager.Current.AcrylicBlur = (bool)value;
			OnAcrylicBlurChanged((bool)value);
			break;
		case "WindowOpacity":
		{
			int num2 = Convert.ToInt32(value);
			SettingsManager.Current.WindowOpacity = num2;
			OnWindowOpacityChanged(num2);
			break;
		}
		case "AutoSaveScript":
			SettingsManager.Current.AutoSaveScript = (bool)value;
			OnAutoSaveScriptChanged((bool)value);
			break;
		case "MiniMap":
			SettingsManager.Current.MiniMap = (bool)value;
			OnMiniMapChanged((bool)value);
			break;
		case "LeftMiniMap":
			SettingsManager.Current.LeftMiniMap = (bool)value;
			OnLeftMiniMapChanged((bool)value);
			break;
		case "WordWrap":
			SettingsManager.Current.WordWrap = (bool)value;
			OnWordWrapChanged((bool)value);
			break;
		case "LineNumber":
			SettingsManager.Current.LineNumber = (bool)value;
			OnLineNumberChanged((bool)value);
			break;
		case "Font":
			SettingsManager.Current.Font = value.ToString();
			OnFontChanged(value.ToString());
			break;
		case "FontSize":
		{
			int num = Convert.ToInt32(value);
			SettingsManager.Current.FontSize = num;
			OnFontSizeChanged(num);
			break;
		}
		case "MeteorEffect":
			SettingsManager.Current.MeteorEffect = (bool)value;
			OnMeteorEffectChanged((bool)value);
			break;
		case "ShowExplorer":
			SettingsManager.Current.ShowExplorer = (bool)value;
			OnShowExplorerChanged((bool)value);
			break;
		case "AutoRefreshExplorer":
			SettingsManager.Current.AutoRefreshExplorer = (bool)value;
			OnAutoRefreshExplorerChanged((bool)value);
			break;
		case "AutoRefreshInterval":
		{
			int value2 = Convert.ToInt32(value);
			value2 = Math.Clamp(value2, 1, 300);
			SettingsManager.Current.AutoRefreshInterval = value2;
			OnAutoRefreshIntervalChanged(value2);
			break;
		}
		case "ExplorerPosition":
		{
			string text2 = ((value?.ToString() == "right") ? "right" : "left");
			SettingsManager.Current.ExplorerPosition = text2;
			OnExplorerPositionChanged(text2);
			break;
		}
		case "ExecuteHotkey":
		{
			string text5 = value?.ToString() ?? "";
			bool flag4 = RegisterHotkey("ExecuteHotkey", text5, delegate
			{
				Execute_Click(null, null);
			});
			SettingsManager.Current.ExecuteHotkey = (flag4 ? text5 : SettingsManager.Current.ExecuteHotkey);
			if (!flag4)
			{
				NotifyHotkeyConflict("ExecuteHotkey", text5);
			}
			break;
		}
		case "AttachHotkey":
		{
			string text4 = value?.ToString() ?? "";
			bool flag3 = RegisterHotkey("AttachHotkey", text4, delegate
			{
				Attach_Click(null, null);
			});
			SettingsManager.Current.AttachHotkey = (flag3 ? text4 : SettingsManager.Current.AttachHotkey);
			if (!flag3)
			{
				NotifyHotkeyConflict("AttachHotkey", text4);
			}
			break;
		}
		case "KillRobloxHotkey":
		{
			string text3 = value?.ToString() ?? "";
			bool flag2 = RegisterHotkey("KillRobloxHotkey", text3, delegate
			{
				TryKillRobloxProcesses();
			});
			SettingsManager.Current.KillRobloxHotkey = (flag2 ? text3 : SettingsManager.Current.KillRobloxHotkey);
			if (!flag2)
			{
				NotifyHotkeyConflict("KillRobloxHotkey", text3);
			}
			break;
		}
		case "BossKeyHotkey":
		{
			string text = value?.ToString() ?? "";
			bool flag = RegisterHotkey("BossKeyHotkey", text, delegate
			{
				ToggleBossKey();
			});
			SettingsManager.Current.BossKeyHotkey = (flag ? text : SettingsManager.Current.BossKeyHotkey);
			if (!flag)
			{
				NotifyHotkeyConflict("BossKeyHotkey", text);
			}
			break;
		}
		case "AntivirusDetectionAlert":
			SettingsManager.Current.AntivirusDetectionAlert = (bool)value;
			break;
		case "WindowsDefenderAlert":
			SettingsManager.Current.WindowsDefenderAlert = (bool)value;
			break;
		case "AddDefenderExclusion":
			HandleAddDefenderExclusionAsync();
			break;
		}
		SettingsManager.Save();
	}

	private void NotifyHotkeyConflict(string key, string combo)
	{
		string value = "Hotkey \"" + combo + "\" is already used by another program";
		CoreWebView2 coreWebView = SettingsTab.CoreWebView2;
		if (coreWebView != null)
		{
			coreWebView.ExecuteScriptAsync("window.showNotification && window.showNotification(" + JsonSerializer.Serialize(value) + ", true);");
		}
	}

	private void OnAutoLaunchOnStartupChanged(bool enabled)
	{
		string name = "Crescent";
		string value = "\"" + Application.ExecutablePath + "\"";
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", writable: true))
		{
			if (registryKey != null)
			{
				if (enabled)
				{
					registryKey.SetValue(name, value);
				}
				else
				{
					registryKey.DeleteValue(name, throwOnMissingValue: false);
				}
			}
		}
		if (enabled)
		{
			return;
		}
		try
		{
			using RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run", writable: true);
			registryKey2?.DeleteValue(name, throwOnMissingValue: false);
		}
		catch
		{
		}
	}

	private void OnAutoAttachChanged(bool enabled)
	{
		if (enabled)
		{
			if (_autoAttachCts == null || _autoAttachCts.IsCancellationRequested)
			{
				_autoAttachCts = new CancellationTokenSource();
				StartAutoAttach(_autoAttachCts.Token);
			}
		}
		else
		{
			_autoAttachCts?.Cancel();
			_autoAttachCts = null;
		}
	}

	private async Task OnFpsUnlockerChanged(bool enabled)
	{
		AdvancedFpsUnlocker.SetStatus(enabled);
	}

	private async void OnLanguageChanged(string lang)
	{
		try
		{
			string webviewLang = ((lang == "zh") ? "zh" : "en");
			if (PageTab?.CoreWebView2 != null)
			{
				await PageTab.CoreWebView2.ExecuteScriptAsync("setLanguage('" + webviewLang + "')");
			}
			if (ScriptHub?.CoreWebView2 != null)
			{
				await ScriptHub.CoreWebView2.ExecuteScriptAsync("LanguageAPI.set('" + webviewLang + "')");
			}
			if (SettingsTab?.CoreWebView2 != null)
			{
				await SettingsTab.CoreWebView2.ExecuteScriptAsync("LanguageAPI.set('" + webviewLang + "')");
			}
			if (Executor?.CoreWebView2 != null)
			{
				await Executor.CoreWebView2.ExecuteScriptAsync((webviewLang == "zh") ? "LanguageAPI.setChinese()" : "LanguageAPI.setEnglish()");
			}
			if (Dashboard?.CoreWebView2 != null)
			{
				await Dashboard.CoreWebView2.ExecuteScriptAsync("setLanguage('" + webviewLang + "')");
			}
			PushToSettingsTab("lang:" + webviewLang);
		}
		catch
		{
		}
	}

	private void OnAlwaysOnTopChanged(bool enabled)
	{
		base.TopMost = enabled;
	}

	private void OnResetWindowSize()
	{
		if (base.WindowState != FormWindowState.Minimized)
		{
			base.Size = new Size(1015, 568);
			SettingsManager.Current.WindowWidth = base.Width;
			SettingsManager.Current.WindowHeight = base.Height;
		}
	}

	private void OnUpdateWindowSize()
	{
		if (base.WindowState != FormWindowState.Minimized)
		{
			SettingsManager.Current.WindowWidth = base.Width;
			SettingsManager.Current.WindowHeight = base.Height;
		}
	}

	private void OnAntiScreenRecorderChanged(bool enabled)
	{
		if (enabled)
		{
			SetWindowDisplayAffinity(base.Handle, 17u);
		}
		else
		{
			SetWindowDisplayAffinity(base.Handle, 0u);
		}
	}

	private void OnDiscordRPCChanged(bool enabled)
	{
		if (enabled)
		{
			if (!rpcEnabled)
			{
				rpc.Start();
				rpcEnabled = true;
			}
		}
		else if (rpcEnabled)
		{
			rpc.Stop();
			rpcEnabled = false;
		}
	}

	private void OnAcrylicBlurChanged(bool enabled)
	{
		SetAcrylic(enabled, 180);
	}

	private void OnWindowOpacityChanged(int opacityPercent)
	{
		base.Opacity = (double)Math.Clamp(opacityPercent, 20, 100) / 100.0;
	}

	private async void OnAutoSaveScriptChanged(bool enabled)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			await Executor.ExecuteScriptAsync("window.EditorAPI?.setAutoSave(" + enabled.ToString().ToLower() + ");");
		}
	}

	private async Task ApplyMiniMapOptionsAsync()
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			bool miniMap = SettingsManager.Current.MiniMap;
			string value = (SettingsManager.Current.LeftMiniMap ? "left" : "right");
			await Executor.CoreWebView2.ExecuteScriptAsync($"if (window.editor) {{editor.updateOptions({{minimap: {{ enabled: {miniMap.ToString().ToLower()}, side: '{value}' }}}});editor.layout();}}");
		}
	}

	private void OnMiniMapChanged(bool enabled)
	{
		ApplyMiniMapOptionsAsync();
	}

	private void OnLeftMiniMapChanged(bool enabled)
	{
		if (enabled && !SettingsManager.Current.MiniMap)
		{
			SettingsManager.Current.MiniMap = true;
			SettingsManager.Save();
			PushInitialSettings();
		}
		ApplyMiniMapOptionsAsync();
	}

	private async void OnWordWrapChanged(bool enabled)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			await Executor.CoreWebView2.ExecuteScriptAsync("EditorAPI.setWordWrap(" + enabled.ToString().ToLower() + ");");
		}
	}

	private async void OnLineNumberChanged(bool enabled)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			await Executor.CoreWebView2.ExecuteScriptAsync("EditorAPI.setLineNumbers(" + enabled.ToString().ToLower() + ");");
		}
	}

	private async void OnFontChanged(string fontName)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			string text = JsonSerializer.Serialize("'" + fontName + "', Consolas, 'Courier New', monospace");
			await Executor.CoreWebView2.ExecuteScriptAsync("window.EditorAPI?.setFontFamily(" + text + ");");
		}
	}

	private async void OnFontSizeChanged(int size)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			if (size < 10)
			{
				size = 10;
			}
			if (size > 30)
			{
				size = 30;
			}
			SettingsManager.Current.FontSize = size;
			await Executor.ExecuteScriptAsync($"EditorAPI.setFontSize({size});");
		}
	}

	private async void OnMeteorEffectChanged(bool enabled)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			await Executor.ExecuteScriptAsync(enabled ? "toggleMeteor(true);" : "toggleMeteor(false);");
		}
	}

	private async void OnShowExplorerChanged(bool enabled)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			await Executor.CoreWebView2.ExecuteScriptAsync("window.ExplorerVisibilityAPI && window.ExplorerVisibilityAPI.setVisible(" + enabled.ToString().ToLower() + ");");
		}
	}

	private async void OnAutoRefreshExplorerChanged(bool enabled)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			await Executor.CoreWebView2.ExecuteScriptAsync("window.ExplorerAutoRefreshAPI && window.ExplorerAutoRefreshAPI.setEnabled(" + enabled.ToString().ToLower() + ");");
		}
	}

	private async void OnAutoRefreshIntervalChanged(int seconds)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			await Executor.CoreWebView2.ExecuteScriptAsync($"window.ExplorerAutoRefreshAPI && window.ExplorerAutoRefreshAPI.setInterval({seconds});");
		}
	}

	private async void OnExplorerPositionChanged(string position)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			string text = JsonSerializer.Serialize(position);
			await Executor.CoreWebView2.ExecuteScriptAsync("window.ExplorerPositionAPI && window.ExplorerPositionAPI.setPosition(" + text + ");");
		}
	}

	private async Task PushExplorerSettingsAsync()
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) != null)
		{
			bool showExplorer = SettingsManager.Current.ShowExplorer;
			bool autoRefresh = SettingsManager.Current.AutoRefreshExplorer;
			int interval = SettingsManager.Current.AutoRefreshInterval;
			string position = SettingsManager.Current.ExplorerPosition;
			await Executor.CoreWebView2.ExecuteScriptAsync("window.ExplorerVisibilityAPI && window.ExplorerVisibilityAPI.setVisible(" + showExplorer.ToString().ToLower() + ");");
			await Executor.CoreWebView2.ExecuteScriptAsync($"window.ExplorerAutoRefreshAPI && window.ExplorerAutoRefreshAPI.setInterval({interval});");
			await Executor.CoreWebView2.ExecuteScriptAsync("window.ExplorerAutoRefreshAPI && window.ExplorerAutoRefreshAPI.setEnabled(" + autoRefresh.ToString().ToLower() + ");");
			await Executor.CoreWebView2.ExecuteScriptAsync("window.ExplorerPositionAPI && window.ExplorerPositionAPI.setPosition(" + JsonSerializer.Serialize(position) + ");");
		}
	}

	private async Task HandleAddDefenderExclusionAsync()
	{
		string crescentFolder = Application.StartupPath;
		string robloxVersionsFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox", "Versions");
		string nexomiaFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "win.nexomia");
		bool flag = await Task.Run(delegate
		{
			try
			{
				using Process process = Process.Start(new ProcessStartInfo("powershell", $"-Command \"$paths = @('{crescentFolder}', '{robloxVersionsFolder}', '{nexomiaFolder}'); foreach ($p in $paths) {{     if ((Get-MpPreference).ExclusionPath -notcontains $p) {{         Add-MpPreference -ExclusionPath $p;     }} }}\"")
				{
					UseShellExecute = true,
					Verb = "runas",
					WindowStyle = ProcessWindowStyle.Hidden
				});
				process.WaitForExit();
				return process.ExitCode == 0;
			}
			catch
			{
				return false;
			}
		});
		string value = (flag ? "Successfully added to the exclusion list" : "Adding to the exclusion list failed. Please confirm whether you are executing this as a system administrator");
		WebView2 settingsTab = SettingsTab;
		if (((settingsTab != null) ? settingsTab.CoreWebView2 : null) != null)
		{
			await SettingsTab.CoreWebView2.ExecuteScriptAsync($"onDefenderExclusionResult({flag.ToString().ToLower()}, {JsonSerializer.Serialize(value)})");
		}
	}

	private void ControlBox_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
	{
		switch (e.TryGetWebMessageAsString())
		{
		case "Minimize":
			base.WindowState = FormWindowState.Minimized;
			break;
		case "Maximize":
			base.WindowState = FormWindowState.Maximized;
			break;
		case "Restore":
			base.WindowState = FormWindowState.Normal;
			break;
		case "Close":
			Application.Exit();
			break;
		}
	}

	private async void SwitchTo(Guna2Panel targetPanel)
	{
		if (!isSwitching && (object)currentPanel != targetPanel)
		{
			isSwitching = true;
			Control control = currentPanel;
			SuspendLayout();
			((Control)(object)targetPanel).BringToFront();
			((Control)(object)targetPanel).Visible = true;
			if (control != null)
			{
				control.Visible = false;
			}
			ResumeLayout();
			currentPanel = (Control)(object)targetPanel;
			isSwitching = false;
		}
	}

	private async void HandleTabSwitch(string tabName)
	{
		if (!(tabName == currentTab))
		{
			Func<Task> obj = currentTab switch
			{
				"Dashboard" => (Func<Task>)(() => Dashboard.CoreWebView2.ExecuteScriptAsync("window.playExitAnimation();")), 
				"Executor" => (Func<Task>)(() => Executor.CoreWebView2.ExecuteScriptAsync("window.playExitAnimation();")), 
				"ScriptHub" => (Func<Task>)(() => ScriptHub.CoreWebView2.ExecuteScriptAsync("window.playExitAnimation();")), 
				"Settings" => (Func<Task>)(() => SettingsTab.CoreWebView2.ExecuteScriptAsync("window.playExitAnimation();")), 
				_ => (Func<Task>)(() => Task.CompletedTask), 
			};
			int exitDelay = 240;
			await obj();
			await Task.Delay(exitDelay);
			GetActualTheme();
			switch (tabName)
			{
			case "Dashboard":
				SwitchTo(guna2Panel20);
				await Dashboard.ExecuteScriptAsync("startEntranceAnimation();");
				break;
			case "Executor":
				SwitchTo(guna2Panel1);
				await Executor.ExecuteScriptAsync("window.AnimationAPI.playGlobalIntro()");
				break;
			case "ScriptHub":
				SwitchTo(guna2Panel6);
				await ScriptHub.ExecuteScriptAsync("AppAnimation.play('full');");
				break;
			case "Settings":
				SwitchTo(guna2Panel3);
				await SettingsTab.ExecuteScriptAsync("if (window.AnimationAPI) { AnimationAPI.playGlobalIntro(); }");
				break;
			}
			currentTab = tabName;
		}
	}

	private string GetActualTheme()
	{
		return ResolveActualTheme(SettingsManager.Current.Theme);
	}

	private bool IsRobloxWindowReady()
	{
		Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
		foreach (Process process in processesByName)
		{
			try
			{
				if (process.MainWindowHandle != IntPtr.Zero && !string.IsNullOrEmpty(process.MainWindowTitle) && process.Responding)
				{
					return true;
				}
			}
			catch
			{
			}
		}
		return false;
	}

	private async void LaunchRoblox()
	{
		string versionsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox", "Versions");
		string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
		string downgradeExePath = Path.Combine(baseDirectory, "Roblox_Downgrade", "RobloxPlayerBeta.exe");
		try
		{
			string value = string.Empty;
			using (HttpClient client = new HttpClient())
			{
				value = (await client.GetStringAsync("https://crescent-webview.vercel.app/roblox-version.txt")).Trim();
			}
			DirectoryInfo directoryInfo = (from d in new DirectoryInfo(versionsPath).GetDirectories("version-*")
				orderby d.LastWriteTimeUtc descending
				select d).FirstOrDefault((DirectoryInfo d) => File.Exists(Path.Combine(d.FullName, "RobloxPlayerBeta.exe")));
			if (directoryInfo != null && !string.IsNullOrEmpty(value) && directoryInfo.Name.Equals(value, StringComparison.OrdinalIgnoreCase))
			{
				string fileName = Path.Combine(directoryInfo.FullName, "RobloxPlayerBeta.exe");
				Process.Start(new ProcessStartInfo
				{
					FileName = fileName,
					WorkingDirectory = directoryInfo.FullName,
					UseShellExecute = true
				});
				return;
			}
		}
		catch (Exception)
		{
		}
		if (File.Exists(downgradeExePath))
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = downgradeExePath,
				WorkingDirectory = Path.GetDirectoryName(downgradeExePath),
				UseShellExecute = true
			});
		}
	}

	private void WindowRefreshTimer_Tick(object sender, EventArgs e)
	{
		WindowRefreshTimer.Stop();
		PerformWindowRefresh();
	}

	private void PerformWindowRefresh()
	{
		if (!base.IsDisposed)
		{
			Invalidate(invalidateChildren: true);
			Update();
		}
	}

	private async void StatusUpdateTimer_Tick(object sender, EventArgs e)
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) == null)
		{
			return;
		}
		int count = GetRobloxProcesses().Count;
		await Executor.CoreWebView2.ExecuteScriptAsync($"ClientStatusAPI.setPidCount({count})");
		if (quorum.IsAttached())
		{
			Executor.CoreWebView2.PostWebMessageAsString("ukdownStatus:green:Attached");
			if (SettingsManager.Current.DiscordRPC)
			{
				rpc.SetState("Attached", "https://getcrescent.best");
			}
		}
		else
		{
			Executor.CoreWebView2.PostWebMessageAsString("ukdownStatus:red:Not Attach");
			if (SettingsManager.Current.DiscordRPC)
			{
				rpc.SetState("Not Attach", "https://getcrescent.best");
			}
		}
		await PushPidListToUiAsync();
	}

	private void MonitorTimer_Tick(object sender, EventArgs e)
	{
		if (!SettingsManager.Current.CrashDetection || watchedProcess != null)
		{
			return;
		}
		Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
		if (processesByName.Length == 0)
		{
			return;
		}
		Process[] array = processesByName;
		foreach (Process process in array)
		{
			try
			{
				if (process.MainWindowHandle != IntPtr.Zero && !string.IsNullOrEmpty(process.MainWindowTitle))
				{
					watchedProcess = process;
					watchedProcessHadWindow = true;
					watchedProcess.EnableRaisingEvents = true;
					watchedProcess.Exited += WatchedProcess_Exited;
					break;
				}
			}
			catch
			{
			}
		}
	}

	private void WatchedProcess_Exited(object sender, EventArgs e)
	{
		BeginInvoke(async delegate
		{
			int num = -1;
			bool flag = watchedProcessHadWindow;
			try
			{
				if (watchedProcess != null)
				{
					num = watchedProcess.ExitCode;
					watchedProcess.Dispose();
					watchedProcess = null;
				}
			}
			catch (Exception)
			{
				watchedProcess = null;
				watchedProcessHadWindow = false;
				return;
			}
			watchedProcessHadWindow = false;
			if (!SettingsManager.Current.CrashDetection || !flag || num == 0 || num == -1 || Process.GetProcessesByName("RobloxPlayerBeta").Any(delegate(Process p)
			{
				try
				{
					return p.MainWindowHandle != IntPtr.Zero;
				}
				catch
				{
					return false;
				}
			}) || isHandlingCrash)
			{
				return;
			}
			isHandlingCrash = true;
			RobloxCrashDetection.Stop();
			try
			{
				if (!(await AskUserForRobloxRestartAsync()))
				{
					return;
				}
				try
				{
					await Executor.ExecuteScriptAsync("EditorAPI.notify('loading', 'Restarting Roblox')");
					await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('system', 'Restarting Roblox...')");
					await RestartRoblox();
				}
				catch (Exception)
				{
				}
			}
			finally
			{
				isHandlingCrash = false;
				if (!RobloxCrashDetection.Enabled)
				{
					RobloxCrashDetection.Start();
				}
			}
		});
	}

	private async Task<bool> AskUserForRobloxRestartAsync()
	{
		_crashRestartTcs = new TaskCompletionSource<bool>();
		try
		{
			await Executor.ExecuteScriptAsync("typeof window.askForRobloxRestart === 'function'");
			await Executor.ExecuteScriptAsync("window.askForRobloxRestart()");
		}
		catch (Exception)
		{
			return false;
		}
		if (await Task.WhenAny(_crashRestartTcs.Task, Task.Delay(TimeSpan.FromMinutes(5.0))) != _crashRestartTcs.Task)
		{
			return false;
		}
		return await _crashRestartTcs.Task;
	}

	private async Task RestartRoblox()
	{
		using (new HttpClient
		{
			Timeout = TimeSpan.FromSeconds(5.0)
		})
		{
			try
			{
				RobloxCrashDetection.Stop();
				TryKillRobloxProcesses();
				LaunchRoblox();
			}
			catch (Exception)
			{
			}
			finally
			{
				await Executor.ExecuteScriptAsync("EditorAPI.notify('success', 'Successfully Restarted Roblox');");
				RobloxCrashDetection.Start();
			}
		}
	}

	private void RobloxWindowlessDetection_Tick(object sender, EventArgs e)
	{
		if (!SettingsManager.Current.CrashDetection)
		{
			_windowlessStrikeCount.Clear();
			return;
		}
		Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
		HashSet<int> livePids = new HashSet<int>();
		Process[] array = processesByName;
		foreach (Process process in array)
		{
			livePids.Add(process.Id);
			try
			{
				if (process.MainWindowHandle != IntPtr.Zero && !string.IsNullOrEmpty(process.MainWindowTitle))
				{
					_windowlessStrikeCount[process.Id] = 0;
					continue;
				}
				int num = ((!_windowlessStrikeCount.TryGetValue(process.Id, out var value)) ? 1 : (value + 1));
				_windowlessStrikeCount[process.Id] = num;
				if (num < _windowlessGraceStrikes)
				{
					continue;
				}
				try
				{
					if (!process.HasExited)
					{
						process.Kill();
						process.WaitForExit(3000);
					}
				}
				catch
				{
				}
				finally
				{
					_windowlessStrikeCount.Remove(process.Id);
				}
			}
			catch
			{
			}
			finally
			{
				process.Dispose();
			}
		}
		foreach (int item in _windowlessStrikeCount.Keys.Where((int pid) => !livePids.Contains(pid)).ToList())
		{
			_windowlessStrikeCount.Remove(item);
		}
	}

	private void GameHubProbeTimer_Tick(object sender, EventArgs e)
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		if (!quorum.IsAttached() || !IsRobloxWindowReady())
		{
			ClearGameHub();
			return;
		}
		if (_lastGameHubResponseAt != DateTime.MinValue && DateTime.UtcNow - _lastGameHubResponseAt > GameHubStaleTimeout)
		{
			ClearGameHub();
		}
		string text = $"\r\n            pcall(function()\r\n                local placeId = tostring(game.PlaceId)\r\n                local req = request or http_request or (syn and syn.request)\r\n                if req then\r\n                    req({{\r\n                        Url = 'http://127.0.0.1:{47899}/gamehub/',\r\n                        Method = 'POST',\r\n                        Body = placeId\r\n                    }})\r\n                end\r\n            end)\r\n            ";
		quorum.ExecuteScript(text);
	}

	private async Task StartAutoAttach(CancellationToken token = default(CancellationToken))
	{
		bool windowFoundLastCheck = false;
		while (!token.IsCancellationRequested)
		{
			try
			{
				bool flag = IsRobloxWindowReady();
				if (!quorum.IsAttached())
				{
					if (flag && !windowFoundLastCheck)
					{
						windowFoundLastCheck = true;
						await Task.Delay(2000, token);
						if (IsRobloxWindowReady() && !quorum.IsAttached())
						{
							Attach_Click(null, null);
						}
					}
					else if (!flag)
					{
						windowFoundLastCheck = false;
					}
				}
				else
				{
					windowFoundLastCheck = true;
				}
			}
			catch (OperationCanceledException)
			{
				break;
			}
			catch
			{
			}
			try
			{
				await Task.Delay(1000, token);
			}
			catch (OperationCanceledException)
			{
				break;
			}
		}
	}

	private long GetTotalPhysicalMemoryMB()
	{
		try
		{
			MEMORYSTATUSEX lpBuffer = new MEMORYSTATUSEX
			{
				dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX))
			};
			if (GlobalMemoryStatusEx(ref lpBuffer))
			{
				return (long)(lpBuffer.ullTotalPhys / 1048576);
			}
		}
		catch
		{
		}
		return 8000L;
	}

	private async Task<double> MeasureDiskSpeedMBpsAsync()
	{
		string testPath = Path.Combine(Path.GetTempPath(), $"crescent_disktest_{Guid.NewGuid()}.tmp");
		try
		{
			byte[] buffer = new byte[16777216];
			new Random().NextBytes(buffer);
			Stopwatch sw = Stopwatch.StartNew();
			await using (FileStream fs = new FileStream(testPath, FileMode.Create, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
			{
				await fs.WriteAsync(buffer, 0, buffer.Length);
				await fs.FlushAsync();
			}
			double writeSeconds = sw.Elapsed.TotalSeconds;
			sw.Restart();
			await using (FileStream fs = new FileStream(testPath, FileMode.Open, FileAccess.Read, FileShare.None, 4096, FileOptions.SequentialScan))
			{
				byte[] readBuf = new byte[buffer.Length];
				int num;
				for (int totalRead = 0; totalRead < readBuf.Length; totalRead += num)
				{
					num = await fs.ReadAsync(readBuf, totalRead, readBuf.Length - totalRead);
					if (num <= 0)
					{
						break;
					}
				}
			}
			double totalSeconds = sw.Elapsed.TotalSeconds;
			double num2 = Math.Max(writeSeconds + totalSeconds, 0.001);
			return 32.0 / num2;
		}
		catch
		{
			return 100.0;
		}
		finally
		{
			try
			{
				if (File.Exists(testPath))
				{
					File.Delete(testPath);
				}
			}
			catch
			{
			}
		}
	}

	private async Task DetectSystemPerformanceAsync()
	{
		int cores = Environment.ProcessorCount;
		long totalRamMB;
		try
		{
			totalRamMB = GetTotalPhysicalMemoryMB();
		}
		catch
		{
			totalRamMB = 8000L;
		}
		double num;
		try
		{
			num = await MeasureDiskSpeedMBpsAsync();
		}
		catch
		{
			num = 100.0;
		}
		int num2 = 0;
		if (cores >= 8)
		{
			num2 += 2;
		}
		else if (cores >= 4)
		{
			num2++;
		}
		if (totalRamMB >= 16000)
		{
			num2 += 2;
		}
		else if (totalRamMB >= 8000)
		{
			num2++;
		}
		if (num >= 150.0)
		{
			num2++;
		}
		if (num2 >= 4)
		{
			_windowlessGraceStrikes = 6;
		}
		else if (num2 >= 2)
		{
			_windowlessGraceStrikes = 9;
		}
		else
		{
			_windowlessGraceStrikes = 15;
		}
	}

	private async void Execute_Click(object sender, EventArgs e)
	{
		if (Executor.CoreWebView2 == null)
		{
			return;
		}
		string value;
		if (_pendingExecuteCode != null)
		{
			value = _pendingExecuteCode;
			_pendingExecuteCode = null;
		}
		else
		{
			value = JsonSerializer.Deserialize<string>(await Executor.CoreWebView2.ExecuteScriptAsync("(function () {\r\n                try \r\n                {\r\n                    if (!window.editor) return '';\r\n                    return window.editor.getValue();\r\n                }\r\n                catch (e) \r\n                { \r\n                    return ''; \r\n                }\r\n                })();"));
		}
		if (!IsRobloxWindowReady())
		{
			await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'No Client Found');");
			await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'No Client Found')");
			return;
		}
		if (_selectedPids.Count == 0)
		{
			await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'No Clients Selected');");
			await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'No Clients Selected')");
			return;
		}
		if (!string.IsNullOrWhiteSpace(value))
		{
			string value2 = Guid.NewGuid().ToString("N");
			string text = $"\r\n            _G.__CRESCENT_RUNS = _G.__CRESCENT_RUNS or {{}}\r\n\r\n            local runId = \"{value2}\"\r\n\r\n            if _G.__CRESCENT_RUNS[runId] then\r\n                return\r\n            end\r\n\r\n            _G.__CRESCENT_RUNS[runId] = true\r\n\r\n            task.spawn(function()\r\n                pcall(function()\r\n                    {value}\r\n                end)\r\n            end)\r\n            ";
			try
			{
				quorum.ExecuteScript(text);
				int successCount = _selectedPids.Count;
				if (successCount > 0)
				{
					await Executor.ExecuteScriptAsync($"EditorAPI.notify('success', 'Successfully Executed on {successCount} Client(s)');");
					await Executor.CoreWebView2.ExecuteScriptAsync($"window.WinFormOutput('success', 'Successfully Executed Script on {successCount} Client(s)')");
				}
				else
				{
					await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'Failed to Execute Script');");
					await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'Failed to Execute Script')");
				}
				return;
			}
			catch (Exception)
			{
				return;
			}
		}
		await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'Script Empty');");
		await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'Script Empty')");
	}

	private async void Attach_Click(object sender, EventArgs e)
	{
		if (quorum.IsAttached())
		{
			return;
		}
		if (!IsRobloxWindowReady())
		{
			await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'No Client Found');");
			await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'No Client Found')");
		}
		else
		{
			if (!(await CheckLocalRobloxVersionAsync()))
			{
				return;
			}
			try
			{
				await Executor.ExecuteScriptAsync("EditorAPI.notify('loading', 'Attaching to All Roblox Client(s)');");
				await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('info', 'Attaching to All Roblox Client(s)...')");
				if (!(await CheckRateLimitAsync()))
				{
					return;
				}
				await RunExternalInjectorAsync();
				await quorum.AttachAPI(false);
				if (!quorum.IsAttached())
				{
					return;
				}
				await Executor.ExecuteScriptAsync("EditorAPI.notify('success', 'Successfully Attached to All Roblox Client(s)');");
				await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('info', 'Successfully Attached to All Roblox Client(s)')");
				await PushPidListToUiAsync();
				StartAutoExecStatusListener();
				foreach (Process robloxProcess in GetRobloxProcesses())
				{
					if (quorum.IsPIDAttached(robloxProcess.Id))
					{
						_selectedPids.Add(robloxProcess.Id);
					}
				}
			}
			catch
			{
			}
		}
	}

	private async Task InjectSinglePidAsync(int pid)
	{
		if (!(await CheckLocalRobloxVersionAsync()))
		{
			return;
		}
		try
		{
			await Executor.ExecuteScriptAsync($"EditorAPI.notify('loading', 'Attaching to Client {pid}');");
			await Executor.CoreWebView2.ExecuteScriptAsync($"window.WinFormOutput('info', 'Attaching to Client {pid}')");
			if (!(await CheckRateLimitAsync()))
			{
				return;
			}
			await RunExternalInjectorAsync();
			await quorum.Attach(pid, false);
			if (quorum.IsPIDAttached(pid))
			{
				_selectedPids.Add(pid);
				WebView2 executor = Executor;
				if (((executor != null) ? executor.CoreWebView2 : null) != null)
				{
					await Executor.CoreWebView2.ExecuteScriptAsync($"window.setPidInjected && window.setPidInjected({pid}, true);");
				}
				await Executor.ExecuteScriptAsync($"EditorAPI.notify('success', 'Successfully Attached to Client {pid}');");
				await Executor.CoreWebView2.ExecuteScriptAsync($"window.WinFormOutput('success', 'Successfully Attached to Client {pid}')");
				StartAutoExecStatusListener();
			}
			else
			{
				await Executor.ExecuteScriptAsync($"EditorAPI.notify('error', 'Failed to Attach to Client {pid}');");
			}
		}
		catch (Exception)
		{
			try
			{
				await Executor.ExecuteScriptAsync($"EditorAPI.notify('error', 'Failed to Attach to Client {pid}');");
			}
			catch
			{
			}
		}
	}

	private async Task<bool> RunExternalInjectorAsync()
	{
		string text = Path.Combine(Application.StartupPath, "Bin", "Injector.exe");
		if (!File.Exists(text))
		{
			await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'Injector.exe not found in Bin folder');");
			return false;
		}
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = text,
			UseShellExecute = true,
			CreateNoWindow = false,
			WindowStyle = ProcessWindowStyle.Normal
		};
		try
		{
			using Process proc = Process.Start(startInfo);
			if (proc != null)
			{
				await proc.WaitForExitAsync().ConfigureAwait(continueOnCapturedContext: false);
				return proc.ExitCode == 0;
			}
		}
		catch (Exception)
		{
		}
		return false;
	}

	private async Task PushPidListToUiAsync()
	{
		WebView2 executor = Executor;
		if (((executor != null) ? executor.CoreWebView2 : null) == null)
		{
			return;
		}
		List<object> list = new List<object>();
		foreach (Process robloxProcess in GetRobloxProcesses())
		{
			try
			{
				bool flag = quorum.IsPIDAttached(robloxProcess.Id);
				if (flag)
				{
					_selectedPids.Add(robloxProcess.Id);
				}
				else
				{
					_selectedPids.Remove(robloxProcess.Id);
				}
				list.Add(new
				{
					pid = robloxProcess.Id,
					name = (string.IsNullOrEmpty(robloxProcess.MainWindowTitle) ? $"Client {robloxProcess.Id}" : robloxProcess.MainWindowTitle),
					injected = flag
				});
			}
			catch
			{
			}
		}
		HashSet<int> live = new HashSet<int>(list.Select((object x) => (int)((dynamic)x).pid));
		_selectedPids.RemoveWhere((int pid) => !live.Contains(pid));
		string text = JsonSerializer.Serialize(list);
		await Executor.CoreWebView2.ExecuteScriptAsync("window.setPidList && window.setPidList(" + text + ");");
	}

	private List<Process> GetRobloxProcesses()
	{
		return Process.GetProcessesByName("RobloxPlayerBeta").Where(delegate(Process p)
		{
			try
			{
				return p.MainWindowHandle != IntPtr.Zero && !string.IsNullOrEmpty(p.MainWindowTitle) && p.Responding;
			}
			catch
			{
				return false;
			}
		}).ToList();
	}

	private async Task<bool> CheckLocalRobloxVersionAsync()
	{
		string requestUri = "https://crescent-webview.vercel.app/roblox-version.txt";
		try
		{
			using HttpClient client = new HttpClient();
			string remoteVersion = (await client.GetStringAsync(requestUri)).Trim().Replace("\r", "").Replace("\n", "")
				.Replace("\ufeff", "");
			if (string.IsNullOrEmpty(remoteVersion))
			{
				return true;
			}
			Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
			if (processesByName.Length == 0)
			{
				return true;
			}
			string fileName = Path.GetFileName(Path.GetDirectoryName(processesByName[0].MainModule.FileName));
			if (!string.Equals(fileName, "Roblox_Downgrade", StringComparison.OrdinalIgnoreCase) && !fileName.StartsWith("WEAO", StringComparison.OrdinalIgnoreCase) && !string.Equals(fileName, remoteVersion, StringComparison.OrdinalIgnoreCase))
			{
				await Executor.ExecuteScriptAsync("EditorAPI.notify('error', 'Roblox Version Wrong');");
				await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', 'Roblox Version Wrong, Correct version: " + remoteVersion + "')");
				return false;
			}
			return true;
		}
		catch
		{
			return true;
		}
	}

	private async Task<bool> CheckRateLimitAsync()
	{
		_ = 2;
		try
		{
			using HttpClient authClient = new HttpClient();
			string requestUri = "https://crescent-auth.daniel1234-lu.workers.dev/";
			HttpResponseMessage httpResponseMessage = await authClient.GetAsync(requestUri);
			if (httpResponseMessage.StatusCode == HttpStatusCode.TooManyRequests)
			{
				int num = 60 - DateTime.Now.Minute;
				string text = DateTime.Now.AddMinutes(num).ToString("HH:mm");
				string text2 = "Rate limit exceeded, Try again at " + text;
				string outputMsg = "Rate limit exceeded, Maximum 15 requests per hour, Please try again at " + text;
				await Executor.ExecuteScriptAsync("EditorAPI.notify('error', '" + text2 + "');");
				await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('error', '" + outputMsg + "')");
				return false;
			}
			return httpResponseMessage.IsSuccessStatusCode;
		}
		catch
		{
			return true;
		}
	}

	private void StartAutoExecStatusListener()
	{
		for (int i = 0; i < 15; i++)
		{
			int num = 47901 + i;
			try
			{
				if (_autoExecStatusListener != null)
				{
					try
					{
						_autoExecStatusListener.Stop();
					}
					catch
					{
					}
					try
					{
						_autoExecStatusListener.Close();
					}
					catch
					{
					}
					_autoExecStatusListener = null;
				}
				_autoExecStatusListener = new HttpListener();
				_autoExecStatusListener.Prefixes.Add($"http://127.0.0.1:{num}/");
				_autoExecStatusListener.Start();
				_currentAutoExecPort = num;
				Task.Run((Func<Task?>)AutoExecStatusListenLoop);
				break;
			}
			catch (HttpListenerException ex) when (ex.ErrorCode == 183)
			{
			}
			catch (Exception)
			{
			}
		}
	}

	private void AutoExecProbeTimer_Tick(object sender, EventArgs e)
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		SyncWorkspace();
		if (_currentAutoExecPort != -1)
		{
			string text = $"\r\n            pcall(function()\r\n                local req = request or http_request or (syn and syn.request)\r\n                if req then\r\n                    local jobId = game.JobId or ''\r\n                    req({{\r\n                        Url = 'http://127.0.0.1:{_currentAutoExecPort}/autoexec-heartbeat',\r\n                        Method = 'POST',\r\n                        Body = jobId\r\n                    }})\r\n                end\r\n            end)\r\n            ";
			quorum.ExecuteScript(text);
		}
	}

	private async Task AutoExecStatusListenLoop()
	{
		while (_autoExecStatusListener != null && _autoExecStatusListener.IsListening)
		{
			HttpListenerContext ctx;
			try
			{
				ctx = await _autoExecStatusListener.GetContextAsync();
			}
			catch
			{
				break;
			}
			try
			{
				string absolutePath = ctx.Request.Url.AbsolutePath;
				if (absolutePath == "/autoexec-status" || absolutePath == "/autoexec-heartbeat")
				{
					using StreamReader reader = new StreamReader(ctx.Request.InputStream, ctx.Request.ContentEncoding);
					string text = (await reader.ReadToEndAsync())?.Trim();
					if (string.IsNullOrEmpty(text))
					{
						_lastAutoExecValue = "";
					}
					else if (text != _lastAutoExecValue && quorum.IsAttached())
					{
						ExecuteAutoExecScripts();
						_lastAutoExecValue = text;
					}
				}
				ctx.Response.StatusCode = 200;
				ctx.Response.Close();
			}
			catch
			{
				try
				{
					ctx.Response.Close();
				}
				catch
				{
				}
			}
		}
	}

	private void StopAutoExecStatusListener()
	{
		try
		{
			if (_autoExecStatusListener != null)
			{
				_autoExecStatusListener.Stop();
				_autoExecStatusListener.Close();
				_autoExecStatusListener = null;
			}
			_currentAutoExecPort = -1;
		}
		catch (Exception)
		{
		}
	}

	private void ExecuteAutoExecScripts()
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			string path = Path.Combine(Application.StartupPath, "AutoExec");
			if (!Directory.Exists(path))
			{
				return;
			}
			string[] array = Directory.GetFiles(path, "*.lua", SearchOption.AllDirectories).Concat(Directory.GetFiles(path, "*.txt", SearchOption.AllDirectories)).ToArray();
			foreach (string text in array)
			{
				try
				{
					string originalCode = File.ReadAllText(text);
					string text2 = WrapWithRunOnceGuard(originalCode, text);
					quorum.ExecuteScript(text2);
				}
				catch
				{
				}
			}
		}
		catch
		{
		}
	}

	private string WrapWithRunOnceGuard(string originalCode, string filePath)
	{
		string value = Convert.ToBase64String(MD5.HashData(Encoding.UTF8.GetBytes(filePath + originalCode.Length))).Replace("=", "").Replace("+", "_")
			.Replace("/", "-");
		string value2 = originalCode.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n")
			.Replace("\r", "\\r");
		return $"\r\n            _G.__CRESCENT_AUTOEXEC = _G.__CRESCENT_AUTOEXEC or {{}}\r\n            local __runId = \"{value}\"\r\n            if _G.__CRESCENT_AUTOEXEC[__runId] then return end\r\n            _G.__CRESCENT_AUTOEXEC[__runId] = true\r\n\r\n            local __code = \"{value2}\"\r\n            local __fn, __err = loadstring(__code, \"[AutoExec] {Path.GetFileName(filePath)}\")\r\n            if __fn then\r\n                pcall(__fn)\r\n            else\r\n                warn(\"AutoExec compile error: \" .. tostring(__err))\r\n            end\r\n            ";
	}

	private async void Open_Click(object sender, EventArgs e)
	{
		if (Executor.CoreWebView2 == null)
		{
			return;
		}
		using OpenFileDialog ofd = new OpenFileDialog();
		ofd.Filter = "Lua Script (*.lua)|*.lua|Text File (*.txt)|*.txt|All Files (*.*)|*.*";
		ofd.Title = "Open Lua / Txt Scripts";
		ofd.Multiselect = false;
		if (ofd.ShowDialog() != DialogResult.OK)
		{
			return;
		}
		string value = JsonSerializer.Serialize(File.ReadAllText(ofd.FileName));
		string fileName = Path.GetFileName(ofd.FileName);
		await Executor.CoreWebView2.ExecuteScriptAsync($"ExternalAPI.addNewTab({JsonSerializer.Serialize(fileName)}, {value});");
		await Executor.CoreWebView2.ExecuteScriptAsync("EditorAPI.notify('success', 'File opened: " + fileName + "')");
		await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('info', 'File opened: " + fileName + "')");
	}

	private async void Save_Click(object sender, EventArgs e)
	{
		if (Executor.CoreWebView2 == null)
		{
			return;
		}
		string code = JsonSerializer.Deserialize<string>(await Executor.CoreWebView2.ExecuteScriptAsync("EditorAPI.getCode();"));
		string fileName = JsonSerializer.Deserialize<string>(await Executor.CoreWebView2.ExecuteScriptAsync("(function(){const t = window.tabs.find(x => x.id === window.activeTab);return t ? t.name : 'script.lua';})();"));
		if (IsFileAlreadyManaged(fileName))
		{
			await Executor.ExecuteScriptAsync("EditorAPI.notify('success', 'File already saved');");
			await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('info', 'File already saved')");
			return;
		}
		using (SaveFileDialog sfd = new SaveFileDialog())
		{
			sfd.Filter = "Lua Script (*.lua)|*.lua|Text File (*.txt)|*.txt|All Files (*.*)|*.*";
			sfd.Title = "Save Lua / Txt Scripts";
			sfd.FileName = fileName;
			sfd.DefaultExt = "lua";
			sfd.AddExtension = true;
			if (sfd.ShowDialog() != DialogResult.OK)
			{
				return;
			}
			File.WriteAllText(sfd.FileName, code);
			string value = JsonSerializer.Serialize(Path.GetFileNameWithoutExtension(sfd.FileName));
			string value2 = JsonSerializer.Serialize(sfd.FileName);
			await Executor.CoreWebView2.ExecuteScriptAsync($"\r\n                (function() \r\n                {{\r\n                    const t = window.tabs.find(x => x.id === window.activeTab);\r\n                    if (t) \r\n                    {{\r\n                        t.name = {value};\r\n                        t._filePath = {value2};\r\n\r\n                        if (typeof window.renderTabs === 'function') window.renderTabs();\r\n                        if (typeof window.updateTabNameDisplay === 'function') window.updateTabNameDisplay();\r\n                        if (typeof window.save === 'function') window.save();\r\n                    }}\r\n                }} )();");
		}
		await Executor.CoreWebView2.ExecuteScriptAsync("EditorAPI.notify('success', 'File saved: " + fileName + "')");
		await Executor.CoreWebView2.ExecuteScriptAsync("window.WinFormOutput('info', 'File saved: " + fileName + "')");
		InitExplorer();
	}

	private bool IsFileAlreadyManaged(string tabName)
	{
		string[] obj = new string[2] { "Scripts", "AutoExec" };
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(tabName);
		string[] array = obj;
		foreach (string path in array)
		{
			string path2 = Path.Combine(Application.StartupPath, path);
			if (!Directory.Exists(path2))
			{
				continue;
			}
			string[] array2 = new string[2] { ".lua", ".txt" };
			foreach (string text in array2)
			{
				if (Directory.GetFiles(path2, fileNameWithoutExtension + text, SearchOption.AllDirectories).Length != 0)
				{
					return true;
				}
			}
		}
		return false;
	}

	private bool TryKillRobloxProcesses()
	{
		string[] obj = new string[2] { "RobloxPlayerBeta", "RobloxCrashHandler" };
		bool result = false;
		string[] array = obj;
		for (int i = 0; i < array.Length; i++)
		{
			Process[] processesByName = Process.GetProcessesByName(array[i]);
			foreach (Process process in processesByName)
			{
				try
				{
					if (!process.HasExited)
					{
						process.Kill();
						process.WaitForExit(3000);
						result = true;
					}
				}
				catch (Exception)
				{
				}
				finally
				{
					process.Dispose();
				}
			}
		}
		return result;
	}

	private void KillNexomiaProcess()
	{
		Process[] processesByName = Process.GetProcessesByName("Nexomia");
		if (processesByName.Length == 0)
		{
			return;
		}
		int num = 0;
		Process[] array = processesByName;
		foreach (Process process in array)
		{
			try
			{
				process.Kill(entireProcessTree: true);
				process.WaitForExit(3000);
				num++;
			}
			catch (Exception)
			{
			}
			finally
			{
				process.Dispose();
			}
		}
	}

	private void Form1_MouseDown(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			ReleaseCapture();
			PostMessage(base.Handle, 161, 2, IntPtr.Zero);
		}
	}

	private void TitleText_MouseDown(object sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			ReleaseCapture();
			PostMessage(base.Handle, 161, 2, IntPtr.Zero);
		}
	}

	private void Form1_Move(object sender, EventArgs e)
	{
		if (SettingsManager.Current.AutoSaveWindowPosition)
		{
			SettingsManager.Current.WindowX = base.Location.X;
			SettingsManager.Current.WindowY = base.Location.Y;
		}
	}

	private void Form1_Resize(object sender, EventArgs e)
	{
		if (base.IsHandleCreated && !base.IsDisposed)
		{
			WindowRefreshTimer.Stop();
			WindowRefreshTimer.Start();
		}
	}

	private void Form1_SizeChanged(object sender, EventArgs e)
	{
		if (ControlBox.CoreWebView2 != null)
		{
			if (base.WindowState == FormWindowState.Maximized)
			{
				ControlBox.CoreWebView2.PostWebMessageAsString("OnMaximized");
			}
			else if (base.WindowState == FormWindowState.Normal)
			{
				ControlBox.CoreWebView2.PostWebMessageAsString("OnRestored");
			}
		}
	}

	private void Form1_FormClosed(object sender, FormClosedEventArgs e)
	{
		rpc.Stop();
		_gameHubListener?.Stop();
		_gameHubListener?.Close();
		_logTracker.StopTracking();
		StopAutoExecStatusListener();
		foreach (int value in _hotkeyIds.Values)
		{
			UnregisterHotKey(base.Handle, value);
		}
		if (_nexomiaHook != IntPtr.Zero)
		{
			UnhookWinEvent(_nexomiaHook);
			_nexomiaHook = IntPtr.Zero;
		}
		if (SettingsManager.Current.AutoSaveWindowPosition)
		{
			SettingsManager.Current.WindowX = base.Location.X;
			SettingsManager.Current.WindowY = base.Location.Y;
		}
		SettingsManager.Save();
		try
		{
			string baseDirectory = AppContext.BaseDirectory;
			string path = Path.Combine(baseDirectory, "Crescent.dll");
			string text = Path.Combine(baseDirectory, "CrescentAPI.dll");
			string text2 = Path.Combine(baseDirectory, "QuorumAPI.dll");
			if (File.Exists(path) && File.Exists(text))
			{
				if (File.Exists(text2))
				{
					File.Delete(text2);
				}
				File.Move(text, text2);
			}
		}
		catch
		{
		}
		int id = Process.GetCurrentProcess().Id;
		Process.Start(new ProcessStartInfo
		{
			FileName = "powershell.exe",
			Arguments = $"-NoProfile -WindowStyle Hidden -Command \"Start-Sleep -Seconds 5; Stop-Process -Id {id} -Force\"",
			CreateNoWindow = true,
			UseShellExecute = false
		});
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Expected O, but got Unknown
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected O, but got Unknown
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Expected O, but got Unknown
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Expected O, but got Unknown
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Expected O, but got Unknown
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Expected O, but got Unknown
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Expected O, but got Unknown
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Expected O, but got Unknown
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Expected O, but got Unknown
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Expected O, but got Unknown
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Expected O, but got Unknown
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Expected O, but got Unknown
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Expected O, but got Unknown
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Expected O, but got Unknown
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Expected O, but got Unknown
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Expected O, but got Unknown
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Expected O, but got Unknown
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Expected O, but got Unknown
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Expected O, but got Unknown
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Expected O, but got Unknown
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Expected O, but got Unknown
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Expected O, but got Unknown
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Expected O, but got Unknown
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Expected O, but got Unknown
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Expected O, but got Unknown
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Expected O, but got Unknown
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Expected O, but got Unknown
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Expected O, but got Unknown
		Animation val = new Animation();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Feairl.Form1));
		CustomizableEdges customizableEdges = new CustomizableEdges();
		CustomizableEdges customizableEdges2 = new CustomizableEdges();
		CustomizableEdges customizableEdges3 = new CustomizableEdges();
		CustomizableEdges customizableEdges4 = new CustomizableEdges();
		CustomizableEdges customizableEdges5 = new CustomizableEdges();
		CustomizableEdges customizableEdges6 = new CustomizableEdges();
		CustomizableEdges customizableEdges7 = new CustomizableEdges();
		CustomizableEdges customizableEdges8 = new CustomizableEdges();
		CustomizableEdges customizableEdges9 = new CustomizableEdges();
		CustomizableEdges customizableEdges10 = new CustomizableEdges();
		CustomizableEdges customizableEdges11 = new CustomizableEdges();
		CustomizableEdges customizableEdges12 = new CustomizableEdges();
		this.guna2Transition1 = new Guna2Transition();
		this.guna2Panel3 = new Guna2Panel();
		this.SettingsTab = new WebView2();
		this.guna2Panel6 = new Guna2Panel();
		this.ScriptHub = new WebView2();
		this.Execute = new Guna2Button();
		this.guna2Panel1 = new Guna2Panel();
		this.Executor = new WebView2();
		this.guna2Panel20 = new Guna2Panel();
		this.Dashboard = new WebView2();
		this.ControlBox = new WebView2();
		this.PageTab = new WebView2();
		this.guna2PictureBox1 = new Guna2PictureBox();
		this.TitleText = new WebView2();
		this.Animation = new WebView2();
		this.panel1 = new System.Windows.Forms.Panel();
		((System.Windows.Forms.Control)(object)this.guna2Panel3).SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.SettingsTab).BeginInit();
		((System.Windows.Forms.Control)(object)this.guna2Panel6).SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.ScriptHub).BeginInit();
		((System.Windows.Forms.Control)(object)this.guna2Panel1).SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.Executor).BeginInit();
		((System.Windows.Forms.Control)(object)this.guna2Panel20).SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.Dashboard).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.ControlBox).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.PageTab).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.guna2PictureBox1).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.TitleText).BeginInit();
		((System.ComponentModel.ISupportInitialize)this.Animation).BeginInit();
		base.SuspendLayout();
		((Animator)this.guna2Transition1).AnimationType = (AnimationType)8;
		((Animator)this.guna2Transition1).Cursor = null;
		val.AnimateOnlyDifferences = true;
		val.BlindCoeff = new System.Drawing.PointF(0f, 0f);
		val.LeafCoeff = 0f;
		val.MaxTime = 1f;
		val.MinTime = 0f;
		val.MosaicCoeff = new System.Drawing.PointF(0f, 0f);
		val.MosaicShift = new System.Drawing.PointF(0f, 0f);
		val.MosaicSize = 0;
		val.Padding = new System.Windows.Forms.Padding(0);
		val.RotateCoeff = 0f;
		val.RotateLimit = 0f;
		val.ScaleCoeff = new System.Drawing.PointF(0f, 0f);
		val.SlideCoeff = new System.Drawing.PointF(1f, 0f);
		val.TimeCoeff = 0f;
		val.TransparencyCoeff = 1f;
		((Animator)this.guna2Transition1).DefaultAnimation = val;
		((Animator)this.guna2Transition1).Interval = 1;
		((Animator)this.guna2Transition1).TimeStep = 0.1f;
		((System.Windows.Forms.Control)(object)this.guna2Panel3).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		((System.Windows.Forms.Control)(object)this.guna2Panel3).BackColor = System.Drawing.Color.FromArgb(12, 12, 12);
		this.guna2Panel3.BorderColor = System.Drawing.Color.FromArgb(25, 25, 25);
		((System.Windows.Forms.Control)(object)this.guna2Panel3).Controls.Add((System.Windows.Forms.Control?)(object)this.SettingsTab);
		this.guna2Panel3.CustomizableEdges = customizableEdges;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.guna2Panel3, (DecorationType)0);
		((System.Windows.Forms.Control)(object)this.guna2Panel3).ForeColor = System.Drawing.Color.FromArgb(10, 7, 20);
		((System.Windows.Forms.Control)(object)this.guna2Panel3).Location = new System.Drawing.Point(75, 50);
		((System.Windows.Forms.Control)(object)this.guna2Panel3).Margin = new System.Windows.Forms.Padding(2);
		((System.Windows.Forms.Control)(object)this.guna2Panel3).Name = "guna2Panel3";
		this.guna2Panel3.ShadowDecoration.CustomizableEdges = customizableEdges2;
		((System.Windows.Forms.Control)(object)this.guna2Panel3).Size = new System.Drawing.Size(1172, 610);
		((System.Windows.Forms.Control)(object)this.guna2Panel3).TabIndex = 13;
		((System.Windows.Forms.Control)(object)this.guna2Panel3).Visible = false;
		this.SettingsTab.AllowExternalDrop = true;
		((System.Windows.Forms.Control)(object)this.SettingsTab).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.SettingsTab.CreationProperties = null;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.SettingsTab, (DecorationType)0);
		this.SettingsTab.DefaultBackgroundColor = System.Drawing.Color.FromArgb(12, 12, 12);
		((System.Windows.Forms.Control)(object)this.SettingsTab).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.SettingsTab).Location = new System.Drawing.Point(0, 0);
		((System.Windows.Forms.Control)(object)this.SettingsTab).Margin = new System.Windows.Forms.Padding(4);
		((System.Windows.Forms.Control)(object)this.SettingsTab).Name = "SettingsTab";
		((System.Windows.Forms.Control)(object)this.SettingsTab).Size = new System.Drawing.Size(1174, 608);
		// this.SettingsTab.Source = GetPageUri("Settings.html");
		((System.Windows.Forms.Control)(object)this.SettingsTab).TabIndex = 61;
		this.SettingsTab.ZoomFactor = 1.0;
		((System.Windows.Forms.Control)(object)this.guna2Panel6).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		((System.Windows.Forms.Control)(object)this.guna2Panel6).BackColor = System.Drawing.Color.FromArgb(12, 12, 12);
		this.guna2Panel6.BorderColor = System.Drawing.Color.FromArgb(40, 40, 40);
		((System.Windows.Forms.Control)(object)this.guna2Panel6).Controls.Add((System.Windows.Forms.Control?)(object)this.ScriptHub);
		this.guna2Panel6.CustomizableEdges = customizableEdges3;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.guna2Panel6, (DecorationType)0);
		((System.Windows.Forms.Control)(object)this.guna2Panel6).ForeColor = System.Drawing.Color.FromArgb(12, 12, 12);
		((System.Windows.Forms.Control)(object)this.guna2Panel6).Location = new System.Drawing.Point(75, 50);
		((System.Windows.Forms.Control)(object)this.guna2Panel6).Margin = new System.Windows.Forms.Padding(2);
		((System.Windows.Forms.Control)(object)this.guna2Panel6).Name = "guna2Panel6";
		this.guna2Panel6.ShadowDecoration.CustomizableEdges = customizableEdges4;
		((System.Windows.Forms.Control)(object)this.guna2Panel6).Size = new System.Drawing.Size(1174, 610);
		((System.Windows.Forms.Control)(object)this.guna2Panel6).TabIndex = 31;
		((System.Windows.Forms.Control)(object)this.guna2Panel6).Visible = false;
		this.ScriptHub.AllowExternalDrop = true;
		((System.Windows.Forms.Control)(object)this.ScriptHub).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.ScriptHub.CreationProperties = null;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.ScriptHub, (DecorationType)0);
		this.ScriptHub.DefaultBackgroundColor = System.Drawing.Color.FromArgb(12, 12, 12);
		((System.Windows.Forms.Control)(object)this.ScriptHub).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.ScriptHub).Location = new System.Drawing.Point(0, 0);
		((System.Windows.Forms.Control)(object)this.ScriptHub).Margin = new System.Windows.Forms.Padding(4);
		((System.Windows.Forms.Control)(object)this.ScriptHub).Name = "ScriptHub";
		((System.Windows.Forms.Control)(object)this.ScriptHub).Size = new System.Drawing.Size(1174, 608);
		// this.ScriptHub.Source = GetPageUri("ScriptHub.html");
		((System.Windows.Forms.Control)(object)this.ScriptHub).TabIndex = 0;
		this.ScriptHub.ZoomFactor = 1.0;
		this.Execute.CustomizableEdges = customizableEdges5;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.Execute, (DecorationType)0);
		((System.Windows.Forms.Control)(object)this.Execute).Font = new System.Drawing.Font("Segoe UI", 9f);
		((System.Windows.Forms.Control)(object)this.Execute).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.Execute).Location = new System.Drawing.Point(0, 0);
		((System.Windows.Forms.Control)(object)this.Execute).Name = "Execute";
		this.Execute.ShadowDecoration.CustomizableEdges = customizableEdges6;
		((System.Windows.Forms.Control)(object)this.Execute).Size = new System.Drawing.Size(180, 45);
		((System.Windows.Forms.Control)(object)this.Execute).TabIndex = 0;
		((System.Windows.Forms.Control)(object)this.guna2Panel1).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		((System.Windows.Forms.Control)(object)this.guna2Panel1).BackColor = System.Drawing.Color.FromArgb(12, 12, 12);
		((System.Windows.Forms.Control)(object)this.guna2Panel1).Controls.Add((System.Windows.Forms.Control?)(object)this.Executor);
		this.guna2Panel1.CustomizableEdges = customizableEdges7;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.guna2Panel1, (DecorationType)0);
		((System.Windows.Forms.Control)(object)this.guna2Panel1).ForeColor = System.Drawing.Color.FromArgb(12, 12, 12);
		((System.Windows.Forms.Control)(object)this.guna2Panel1).Location = new System.Drawing.Point(75, 50);
		((System.Windows.Forms.Control)(object)this.guna2Panel1).Margin = new System.Windows.Forms.Padding(0);
		((System.Windows.Forms.Control)(object)this.guna2Panel1).Name = "guna2Panel1";
		this.guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges8;
		((System.Windows.Forms.Control)(object)this.guna2Panel1).Size = new System.Drawing.Size(1174, 610);
		((System.Windows.Forms.Control)(object)this.guna2Panel1).TabIndex = 4;
		((System.Windows.Forms.Control)(object)this.guna2Panel1).Visible = false;
		this.Executor.AllowExternalDrop = true;
		((System.Windows.Forms.Control)(object)this.Executor).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		((System.Windows.Forms.Control)(object)this.Executor).BackColor = System.Drawing.Color.FromArgb(12, 12, 12);
		this.Executor.CreationProperties = null;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.Executor, (DecorationType)0);
		this.Executor.DefaultBackgroundColor = System.Drawing.Color.FromArgb(12, 12, 12);
		((System.Windows.Forms.Control)(object)this.Executor).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.Executor).Location = new System.Drawing.Point(0, 0);
		((System.Windows.Forms.Control)(object)this.Executor).Margin = new System.Windows.Forms.Padding(4);
		((System.Windows.Forms.Control)(object)this.Executor).Name = "Executor";
		((System.Windows.Forms.Control)(object)this.Executor).Size = new System.Drawing.Size(1174, 608);
		// this.Executor.Source = GetPageUri("Monaco.html");
		((System.Windows.Forms.Control)(object)this.Executor).TabIndex = 0;
		this.Executor.ZoomFactor = 1.0;
		((System.Windows.Forms.Control)(object)this.guna2Panel20).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		((System.Windows.Forms.Control)(object)this.guna2Panel20).Controls.Add((System.Windows.Forms.Control?)(object)this.Dashboard);
		this.guna2Panel20.CustomizableEdges = customizableEdges9;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.guna2Panel20, (DecorationType)0);
		((System.Windows.Forms.Control)(object)this.guna2Panel20).Location = new System.Drawing.Point(75, 50);
		((System.Windows.Forms.Control)(object)this.guna2Panel20).Margin = new System.Windows.Forms.Padding(2);
		((System.Windows.Forms.Control)(object)this.guna2Panel20).Name = "guna2Panel20";
		this.guna2Panel20.ShadowDecoration.CustomizableEdges = customizableEdges10;
		((System.Windows.Forms.Control)(object)this.guna2Panel20).Size = new System.Drawing.Size(1174, 610);
		((System.Windows.Forms.Control)(object)this.guna2Panel20).TabIndex = 53;
		this.Dashboard.AllowExternalDrop = true;
		((System.Windows.Forms.Control)(object)this.Dashboard).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.Dashboard.CreationProperties = null;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.Dashboard, (DecorationType)0);
		this.Dashboard.DefaultBackgroundColor = System.Drawing.Color.FromArgb(12, 12, 12);
		((System.Windows.Forms.Control)(object)this.Dashboard).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.Dashboard).Location = new System.Drawing.Point(0, 0);
		((System.Windows.Forms.Control)(object)this.Dashboard).Margin = new System.Windows.Forms.Padding(4);
		((System.Windows.Forms.Control)(object)this.Dashboard).Name = "Dashboard";
		((System.Windows.Forms.Control)(object)this.Dashboard).Size = new System.Drawing.Size(1174, 608);
		// this.Dashboard.Source = GetPageUri("Home.html");
		((System.Windows.Forms.Control)(object)this.Dashboard).TabIndex = 0;
		this.Dashboard.ZoomFactor = 1.0;
		this.ControlBox.AllowExternalDrop = true;
		((System.Windows.Forms.Control)(object)this.ControlBox).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.ControlBox.CreationProperties = null;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.ControlBox, (DecorationType)0);
		this.ControlBox.DefaultBackgroundColor = System.Drawing.Color.Transparent;
		((System.Windows.Forms.Control)(object)this.ControlBox).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.ControlBox).Location = new System.Drawing.Point(1076, -1);
		((System.Windows.Forms.Control)(object)this.ControlBox).Margin = new System.Windows.Forms.Padding(2);
		((System.Windows.Forms.Control)(object)this.ControlBox).Name = "ControlBox";
		((System.Windows.Forms.Control)(object)this.ControlBox).Size = new System.Drawing.Size(174, 48);
		// this.ControlBox.Source = GetPageUri("ControlBox.html");
		((System.Windows.Forms.Control)(object)this.ControlBox).TabIndex = 55;
		((System.Windows.Forms.Control)(object)this.ControlBox).Visible = false;
		this.ControlBox.ZoomFactor = 1.0;
		this.PageTab.AllowExternalDrop = true;
		((System.Windows.Forms.Control)(object)this.PageTab).Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.PageTab.CreationProperties = null;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.PageTab, (DecorationType)0);
		this.PageTab.DefaultBackgroundColor = System.Drawing.Color.Transparent;
		((System.Windows.Forms.Control)(object)this.PageTab).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.PageTab).Location = new System.Drawing.Point(0, 52);
		((System.Windows.Forms.Control)(object)this.PageTab).Margin = new System.Windows.Forms.Padding(4);
		((System.Windows.Forms.Control)(object)this.PageTab).Name = "PageTab";
		((System.Windows.Forms.Control)(object)this.PageTab).Size = new System.Drawing.Size(76, 610);
		// this.PageTab.Source = GetPageUri("PageBtn.html");
		((System.Windows.Forms.Control)(object)this.PageTab).TabIndex = 54;
		((System.Windows.Forms.Control)(object)this.PageTab).Visible = false;
		this.PageTab.ZoomFactor = 1.0;
		((System.Windows.Forms.Control)(object)this.guna2PictureBox1).BackColor = System.Drawing.Color.Transparent;
		this.guna2PictureBox1.CustomizableEdges = customizableEdges11;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.guna2PictureBox1, (DecorationType)0);
		this.guna2PictureBox1.FillColor = System.Drawing.Color.Transparent;
		try { ((System.Windows.Forms.PictureBox)(object)this.guna2PictureBox1).Image = (System.Drawing.Image)resources.GetObject("guna2PictureBox1.Image"); } catch { }
		this.guna2PictureBox1.ImageRotate = 0f;
		((System.Windows.Forms.Control)(object)this.guna2PictureBox1).Location = new System.Drawing.Point(22, 12);
		((System.Windows.Forms.Control)(object)this.guna2PictureBox1).Margin = new System.Windows.Forms.Padding(2);
		((System.Windows.Forms.Control)(object)this.guna2PictureBox1).Name = "guna2PictureBox1";
		this.guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges12;
		((System.Windows.Forms.Control)(object)this.guna2PictureBox1).Size = new System.Drawing.Size(32, 32);
		((System.Windows.Forms.PictureBox)(object)this.guna2PictureBox1).SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
		((System.Windows.Forms.PictureBox)(object)this.guna2PictureBox1).TabIndex = 52;
		((System.Windows.Forms.PictureBox)(object)this.guna2PictureBox1).TabStop = false;
		((System.Windows.Forms.Control)(object)this.guna2PictureBox1).Visible = false;
		this.TitleText.AllowExternalDrop = true;
		((System.Windows.Forms.Control)(object)this.TitleText).Anchor = System.Windows.Forms.AnchorStyles.Top;
		this.TitleText.CreationProperties = null;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.TitleText, (DecorationType)0);
		this.TitleText.DefaultBackgroundColor = System.Drawing.Color.Transparent;
		((System.Windows.Forms.Control)(object)this.TitleText).Enabled = false;
		((System.Windows.Forms.Control)(object)this.TitleText).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.TitleText).Location = new System.Drawing.Point(562, 9);
		((System.Windows.Forms.Control)(object)this.TitleText).Margin = new System.Windows.Forms.Padding(2);
		((System.Windows.Forms.Control)(object)this.TitleText).Name = "TitleText";
		((System.Windows.Forms.Control)(object)this.TitleText).Size = new System.Drawing.Size(140, 35);
		// this.TitleText.Source = GetPageUri("Title.html");
		((System.Windows.Forms.Control)(object)this.TitleText).TabIndex = 56;
		this.TitleText.ZoomFactor = 1.0;
		((System.Windows.Forms.Control)(object)this.TitleText).MouseDown += new System.Windows.Forms.MouseEventHandler(TitleText_MouseDown);
		this.Animation.AllowExternalDrop = true;
		this.Animation.CreationProperties = null;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)(object)this.Animation, (DecorationType)0);
		this.Animation.DefaultBackgroundColor = System.Drawing.Color.Transparent;
		((System.Windows.Forms.Control)(object)this.Animation).Dock = System.Windows.Forms.DockStyle.Fill;
		((System.Windows.Forms.Control)(object)this.Animation).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.Animation).Location = new System.Drawing.Point(0, 0);
		((System.Windows.Forms.Control)(object)this.Animation).Margin = new System.Windows.Forms.Padding(2);
		((System.Windows.Forms.Control)(object)this.Animation).Name = "Animation";
		((System.Windows.Forms.Control)(object)this.Animation).Size = new System.Drawing.Size(1249, 661);
		// this.Animation.Source = GetPageUri("Animation.html");
		((System.Windows.Forms.Control)(object)this.Animation).TabIndex = 57;
		this.Animation.ZoomFactor = 1.0;
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)this.panel1, (DecorationType)0);
		this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
		this.panel1.Location = new System.Drawing.Point(0, 0);
		this.panel1.Margin = new System.Windows.Forms.Padding(2);
		this.panel1.Name = "panel1";
		this.panel1.Size = new System.Drawing.Size(1249, 661);
		this.panel1.TabIndex = 58;
		base.AutoScaleDimensions = new System.Drawing.SizeF(120f, 120f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
		this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
		this.BackColor = System.Drawing.Color.FromArgb(12, 12, 12);
		base.ClientSize = new System.Drawing.Size(1249, 661);
		base.Controls.Add((System.Windows.Forms.Control?)(object)this.TitleText);
		base.Controls.Add((System.Windows.Forms.Control?)(object)this.PageTab);
		base.Controls.Add((System.Windows.Forms.Control?)(object)this.guna2PictureBox1);
		base.Controls.Add((System.Windows.Forms.Control?)(object)this.ControlBox);
		base.Controls.Add((System.Windows.Forms.Control?)(object)this.guna2Panel1);
		base.Controls.Add((System.Windows.Forms.Control?)(object)this.guna2Panel6);
		base.Controls.Add((System.Windows.Forms.Control?)(object)this.guna2Panel3);
		base.Controls.Add((System.Windows.Forms.Control?)(object)this.guna2Panel20);
		base.Controls.Add(this.panel1);
		base.Controls.Add((System.Windows.Forms.Control?)(object)this.Animation);
		((Animator)this.guna2Transition1).SetDecoration((System.Windows.Forms.Control)this, (DecorationType)0);
		this.ForeColor = System.Drawing.Color.FromArgb(12, 12, 12);
		try { base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon"); } catch { }
		base.Margin = new System.Windows.Forms.Padding(2);
		this.MinimumSize = new System.Drawing.Size(933, 351);
		base.Name = "Form1";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "Crescent";
		base.FormClosed += new System.Windows.Forms.FormClosedEventHandler(Form1_FormClosed);
		base.Load += new System.EventHandler(Form1_Load);
		base.SizeChanged += new System.EventHandler(Form1_SizeChanged);
		base.MouseDown += new System.Windows.Forms.MouseEventHandler(Form1_MouseDown);
		base.Move += new System.EventHandler(Form1_Move);
		base.Resize += new System.EventHandler(Form1_Resize);
		((System.Windows.Forms.Control)(object)this.guna2Panel3).ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.SettingsTab).EndInit();
		((System.Windows.Forms.Control)(object)this.guna2Panel6).ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.ScriptHub).EndInit();
		((System.Windows.Forms.Control)(object)this.guna2Panel1).ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.Executor).EndInit();
		((System.Windows.Forms.Control)(object)this.guna2Panel20).ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.Dashboard).EndInit();
		((System.ComponentModel.ISupportInitialize)this.ControlBox).EndInit();
		((System.ComponentModel.ISupportInitialize)this.PageTab).EndInit();
		((System.ComponentModel.ISupportInitialize)this.guna2PictureBox1).EndInit();
		((System.ComponentModel.ISupportInitialize)this.TitleText).EndInit();
		((System.ComponentModel.ISupportInitialize)this.Animation).EndInit();
		base.ResumeLayout(false);
	}
}
