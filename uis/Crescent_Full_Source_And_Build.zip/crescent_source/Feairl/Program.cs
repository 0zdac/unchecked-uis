using System;
using System.IO;
using System.Windows.Forms;
using Crescent;

namespace Feairl;

internal static class Program
{
	[STAThread]
	private static void Main(string[] args)
	{
		Console.WriteLine("[Main] Starting Crescent...");
		try
		{
			string text = Path.Combine(AppContext.BaseDirectory, "QuorumAPI.dll");
			string text2 = Path.Combine(AppContext.BaseDirectory, "CrescentAPI.dll");
			if (File.Exists(text2) && !File.Exists(text))
			{
				File.Copy(text2, text);
			}
			else if (File.Exists(text) && !File.Exists(text2))
			{
				File.Copy(text, text2);
			}
		}
		catch
		{
		}
		Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
		Application.ThreadException += (s, e) =>
		{
			File.AppendAllText("thread_exception.txt", e.Exception.ToString() + "\n");
		};
		AppDomain.CurrentDomain.UnhandledException += (s, e) =>
		{
			File.AppendAllText("thread_exception.txt", e.ExceptionObject.ToString() + "\n");
		};
		try
		{
			Console.WriteLine("[Main] Creating Form1...");
			Form1 form = new Form1();
			Console.WriteLine("[Main] Form1 created! Running Application.Run...");
			Application.Run(form);
			Console.WriteLine("[Main] Application.Run exited.");
		}
		catch (Exception ex)
		{
			Console.WriteLine("[Main] Exception: " + ex);
			File.AppendAllText("crescent_crash.txt", ex.ToString() + "\n");
		}
	}
}
