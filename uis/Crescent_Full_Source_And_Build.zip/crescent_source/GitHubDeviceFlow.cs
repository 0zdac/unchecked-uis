using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

public static class GitHubDeviceFlow
{
	private const string ClientId = "Ov23liQN8qifISu3WIMk";

	private const string Scopes = "repo read:user";

	private static readonly HttpClient Http = CreateHttpClient();

	private static CancellationTokenSource _cts;

	private static HttpClient CreateHttpClient()
	{
		return new HttpClient
		{
			DefaultRequestHeaders = 
			{
				Accept = 
				{
					new MediaTypeWithQualityHeaderValue("application/json")
				}
			}
		};
	}

	public static async void StartAsync(Action<string> postToPage)
	{
		_cts?.Cancel();
		_cts = new CancellationTokenSource();
		CancellationToken ct = _cts.Token;
		try
		{
			JsonElement rootElement = JsonDocument.Parse(await (await Http.PostAsync("https://github.com/login/device/code", new FormUrlEncodedContent(new Dictionary<string, string>
			{
				["client_id"] = "Ov23liQN8qifISu3WIMk",
				["scope"] = "repo read:user"
			}), ct)).Content.ReadAsStringAsync(ct)).RootElement;
			if (rootElement.TryGetProperty("error", out var value))
			{
				postToPage(JsonSerializer.Serialize(new
				{
					type = "ghDeviceError",
					message = value.GetString()
				}));
				return;
			}
			string deviceCode = rootElement.GetProperty("device_code").GetString();
			string userCode = rootElement.GetProperty("user_code").GetString();
			string verificationUri = rootElement.GetProperty("verification_uri").GetString();
			int @int = rootElement.GetProperty("expires_in").GetInt32();
			int interval = (rootElement.TryGetProperty("interval", out var value2) ? value2.GetInt32() : 5);
			postToPage(JsonSerializer.Serialize(new
			{
				type = "ghDeviceCode",
				userCode = userCode,
				verificationUri = verificationUri,
				expiresIn = @int,
				interval = interval
			}));
			DateTime deadline = DateTime.UtcNow.AddSeconds(@int);
			while (DateTime.UtcNow < deadline)
			{
				if (ct.IsCancellationRequested)
				{
					return;
				}
				await Task.Delay(TimeSpan.FromSeconds(interval), ct);
				JsonElement rootElement2 = JsonDocument.Parse(await (await Http.PostAsync("https://github.com/login/oauth/access_token", new FormUrlEncodedContent(new Dictionary<string, string>
				{
					["client_id"] = "Ov23liQN8qifISu3WIMk",
					["device_code"] = deviceCode,
					["grant_type"] = "urn:ietf:params:oauth:grant-type:device_code"
				}), ct)).Content.ReadAsStringAsync(ct)).RootElement;
				if (rootElement2.TryGetProperty("access_token", out var value3))
				{
					postToPage(JsonSerializer.Serialize(new
					{
						type = "ghDeviceToken",
						accessToken = value3.GetString()
					}));
					return;
				}
				if (rootElement2.TryGetProperty("error", out var value4))
				{
					string text = value4.GetString();
					switch (text)
					{
					case "slow_down":
						interval += 5;
						break;
					case "expired_token":
						postToPage(JsonSerializer.Serialize(new
						{
							type = "ghDeviceError",
							message = "驗證碼已過期，請重新登入"
						}));
						return;
					case "access_denied":
						postToPage(JsonSerializer.Serialize(new
						{
							type = "ghDeviceError",
							message = "使用者拒絕了授權"
						}));
						return;
					default:
						postToPage(JsonSerializer.Serialize(new
						{
							type = "ghDeviceError",
							message = text
						}));
						return;
					case "authorization_pending":
						break;
					}
				}
			}
			postToPage(JsonSerializer.Serialize(new
			{
				type = "ghDeviceError",
				message = "驗證逾時，請重新登入"
			}));
		}
		catch (TaskCanceledException)
		{
		}
		catch (Exception ex2)
		{
			postToPage(JsonSerializer.Serialize(new
			{
				type = "ghDeviceError",
				message = ex2.Message
			}));
		}
	}

	public static void Cancel()
	{
		_cts?.Cancel();
	}
}
