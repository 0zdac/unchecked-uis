using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;

public class RobloxLogTracker
{
	private CancellationTokenSource _cts;

	private HttpListener _httpListener;

	private bool _isListening;

	private const int LocalPort = 59888;

	public void StartTracking(WebView2 monacoWebView, Func<bool> checkIsAttached, Action<string> executeScriptAction)
	{
		if (_isListening)
		{
			return;
		}
		_cts = new CancellationTokenSource();
		CancellationToken token = _cts.Token;
		_isListening = true;
		StartHttpServer(monacoWebView, token);
		Task.Run(async delegate
		{
			while (!token.IsCancellationRequested)
			{
				try
				{
					bool flag;
					try
					{
						flag = checkIsAttached != null && checkIsAttached();
					}
					catch
					{
						flag = false;
					}
					if (flag)
					{
						string obj2 = $"\r\n                            if not getgenv()._ConsoleHooked then\r\n                                getgenv()._ConsoleHooked = true\r\n                                \r\n                                local HttpService = game:GetService('HttpService')\r\n                                local requestFunc = syn and syn.request or http_request or request or (http and http.request)\r\n                                \r\n                                if requestFunc then\r\n                                    pcall(function()\r\n                                        requestFunc({{\r\n                                            Url = 'http://127.0.0.1:{59888}/',\r\n                                            Method = 'POST',\r\n                                            Headers = {{['Content-Type'] = 'application/json'}},\r\n                                            Body = HttpService:JSONEncode({{ type = 'system', text = 'Connected to Roblox Console' }})\r\n                                        }});\r\n                                    end)\r\n\r\n                                    print(\"Connected to Roblox Console\")\r\n\r\n                                    local LogService = game:GetService('LogService')\r\n                                    LogService.MessageOut:Connect(function(message, messageType)\r\n                                        if string.sub(message, 1, 13) == '[ConsoleLog]:' then \r\n                                            return \r\n                                        end\r\n\r\n                                        local typeStr = 'info'\r\n                                        if messageType == Enum.MessageType.MessageWarning then \r\n                                            typeStr = 'warning' \r\n                                        elseif messageType == Enum.MessageType.MessageError then \r\n                                            typeStr = 'error' \r\n                                        end\r\n                                        \r\n                                        pcall(function()\r\n                                            requestFunc({{\r\n                                                Url = 'http://127.0.0.1:{59888}/',\r\n                                                Method = 'POST',\r\n                                                Headers = {{['Content-Type'] = 'application/json'}},\r\n                                                Body = HttpService:JSONEncode({{ type = typeStr, text = message }})\r\n                                            }});\r\n                                        end)\r\n                                    end)\r\n                                end\r\n                            end\r\n                        ";
						executeScriptAction(obj2);
					}
				}
				catch
				{
				}
				await Task.Delay(1000, token);
			}
		}, token);
	}

	public void StopTracking()
	{
		_cts?.Cancel();
		try
		{
			_httpListener?.Stop();
			_httpListener?.Close();
		}
		catch
		{
		}
		_httpListener = null;
		_cts = null;
		_isListening = false;
	}

	private void StartHttpServer(WebView2 monacoWebView, CancellationToken token)
	{
		Task.Run(async delegate
		{
			_ = 1;
			try
			{
				_httpListener = new HttpListener();
				_httpListener.Prefixes.Add($"http://127.0.0.1:{59888}/");
				_httpListener.Start();
				while (!token.IsCancellationRequested && _httpListener.IsListening)
				{
					HttpListenerContext context = await _httpListener.GetContextAsync();
					if (context.Request.HttpMethod == "POST")
					{
						using (StreamReader reader = new StreamReader(context.Request.InputStream, context.Request.ContentEncoding))
						{
							string json = await reader.ReadToEndAsync();
							try
							{
								using JsonDocument jsonDocument = JsonDocument.Parse(json);
								JsonElement rootElement = jsonDocument.RootElement;
								string logType = rootElement.GetProperty("type").GetString() ?? "info";
								string logText = rootElement.GetProperty("text").GetString() ?? "";
								SafeInvoke(monacoWebView, delegate
								{
									SendToWebView(monacoWebView, logType, logText);
								});
							}
							catch
							{
							}
						}
						HttpListenerResponse response = context.Response;
						byte[] bytes = Encoding.UTF8.GetBytes("OK");
						response.ContentLength64 = bytes.Length;
						response.OutputStream.Write(bytes, 0, bytes.Length);
						response.OutputStream.Close();
					}
				}
			}
			catch
			{
			}
		}, token);
	}

	private void SafeInvoke(WebView2 monacoWebView, Action action)
	{
		try
		{
			if (((Control)(object)monacoWebView).InvokeRequired)
			{
				((Control)(object)monacoWebView).Invoke(action);
			}
			else
			{
				action();
			}
		}
		catch
		{
		}
	}

	private void SendToWebView(WebView2 monacoWebView, string type, string text)
	{
		if (monacoWebView.CoreWebView2 != null)
		{
			string text2 = $"window.WinFormOutput({JsonSerializer.Serialize(type)}, {JsonSerializer.Serialize(text)}, \"terminal\");";
			monacoWebView.CoreWebView2.ExecuteScriptAsync(text2);
		}
	}
}
