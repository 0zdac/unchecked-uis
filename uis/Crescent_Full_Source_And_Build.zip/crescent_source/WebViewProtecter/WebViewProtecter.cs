using System;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace WebViewProtecter;

public class WebViewProtecter
{
	private readonly WebView2 _wv;

	private bool _failed;

	public static void Attach(WebView2 wv)
	{
		new WebViewProtecter(wv);
	}

	private WebViewProtecter(WebView2 wv)
	{
		_wv = wv;
		_wv.CoreWebView2InitializationCompleted += delegate(object? s, CoreWebView2InitializationCompletedEventArgs e)
		{
			if (e.IsSuccess)
			{
				_wv.NavigationCompleted += Wv_NavigationCompleted;
			}
			else
			{
				ExitApp();
			}
		};
	}

	private void Wv_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Invalid comparison between Unknown and I4
		if (e.IsSuccess)
		{
			_failed = false;
		}
		else if ((int)e.WebErrorStatus != 14)
		{
			if (_failed)
			{
				ExitApp();
				return;
			}
			_failed = true;
			_wv.Reload();
		}
	}

	private void ExitApp()
	{
		// Disabled to avoid killing the application on WebView events
	}
}
