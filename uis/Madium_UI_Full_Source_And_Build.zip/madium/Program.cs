using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Madium
{
    public static class Program
    {
        [STAThread]
        public static void Main()
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainWindow());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Startup error: " + ex.Message, "constraintt.ez Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    public class EmbeddedHttpServer : IDisposable
    {
        private readonly HttpListener _listener;
        private readonly string _uiFolder;
        private bool _running;
        public int Port { get; }

        private static readonly Dictionary<string, string> MimeTypes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { ".html", "text/html; charset=utf-8" },
            { ".htm", "text/html; charset=utf-8" },
            { ".js", "text/javascript; charset=utf-8" },
            { ".mjs", "text/javascript; charset=utf-8" },
            { ".css", "text/css; charset=utf-8" },
            { ".json", "application/json; charset=utf-8" },
            { ".svg", "image/svg+xml" },
            { ".png", "image/png" },
            { ".jpg", "image/jpeg" },
            { ".jpeg", "image/jpeg" },
            { ".ico", "image/x-icon" },
            { ".ttf", "font/ttf" },
            { ".woff", "font/woff" },
            { ".woff2", "font/woff2" },
            { ".wasm", "application/wasm" }
        };

        public EmbeddedHttpServer(string uiFolder, int port = 1420)
        {
            _uiFolder = uiFolder;
            Port = port;
            _listener = new HttpListener();
            try
            {
                _listener.Prefixes.Add($"http://localhost:{port}/");
                _listener.Prefixes.Add($"http://127.0.0.1:{port}/");
                _listener.Start();
                _running = true;
                Task.Run(ListenLoop);
            }
            catch
            {
                // Fallback to random free port if 1420 is busy
                try
                {
                    _listener.Close();
                    _listener = new HttpListener();
                    Port = 18420;
                    _listener.Prefixes.Add($"http://localhost:{Port}/");
                    _listener.Prefixes.Add($"http://127.0.0.1:{Port}/");
                    _listener.Start();
                    _running = true;
                    Task.Run(ListenLoop);
                }
                catch { }
            }
        }

        private async Task ListenLoop()
        {
            while (_running && _listener.IsListening)
            {
                try
                {
                    var ctx = await _listener.GetContextAsync();
                    _ = Task.Run(() => HandleRequest(ctx));
                }
                catch
                {
                    if (!_running) break;
                }
            }
        }

        private void HandleRequest(HttpListenerContext ctx)
        {
            try
            {
                string rawPath = ctx.Request.Url?.AbsolutePath.TrimStart('/') ?? "";
                if (string.IsNullOrEmpty(rawPath) || rawPath == "index.html")
                {
                    rawPath = "index.html";
                }

                string localPath = Path.Combine(_uiFolder, rawPath.Replace('/', Path.DirectorySeparatorChar));

                // Fallback to index.html for client-side routing
                if (!File.Exists(localPath))
                {
                    localPath = Path.Combine(_uiFolder, "index.html");
                }

                if (File.Exists(localPath))
                {
                    byte[] bytes = File.ReadAllBytes(localPath);
                    string ext = Path.GetExtension(localPath);
                    ctx.Response.ContentType = MimeTypes.TryGetValue(ext, out var mime) ? mime : "application/octet-stream";
                    ctx.Response.ContentLength64 = bytes.Length;
                    ctx.Response.StatusCode = 200;
                    ctx.Response.AddHeader("Access-Control-Allow-Origin", "*");
                    ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
                }
                else
                {
                    ctx.Response.StatusCode = 404;
                }
            }
            catch { }
            finally
            {
                try { ctx.Response.Close(); } catch { }
            }
        }

        public void Dispose()
        {
            _running = false;
            try { _listener.Stop(); _listener.Close(); } catch { }
        }
    }

    public class MainWindow : Form
    {
        private WebView2? _webView;
        private EmbeddedHttpServer? _server;

        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("dwmapi.dll")]
        public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

        [DllImport("dwmapi.dll")]
        public static extern int DwmExtendFrameIntoClientArea(IntPtr hWnd, ref MARGINS pMarInset);

        [StructLayout(LayoutKind.Sequential)]
        public struct MARGINS
        {
            public int cxLeftWidth;
            public int cxRightWidth;
            public int cyTopHeight;
            public int cyBottomHeight;
        }

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HT_CAPTION = 0x2;

        
        private void LogDebug(string msg)
        {
            try
            {
                string logFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "webview_debug.log");
                File.AppendAllText(logFile, $"[{DateTime.Now:HH:mm:ss.fff}] {msg}\n");
            }
            catch { }
        }

        public MainWindow()
        {
            this.Text = "constraintt.ez";
            this.Width = 1180;
            this.Height = 720;
            this.MinimumSize = new Size(800, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.None;
            this.DoubleBuffered = true;
            this.BackColor = Color.FromArgb(13, 13, 13);

            string iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
            if (!File.Exists(iconPath))
            {
                iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", "app.ico");
            }
            if (File.Exists(iconPath))
            {
                try { this.Icon = new Icon(iconPath); } catch { }
            }

            // Enable Dark Mode & Window Shadows
            try
            {
                int darkMode = 1;
                DwmSetWindowAttribute(this.Handle, 20, ref darkMode, sizeof(int));
                DwmSetWindowAttribute(this.Handle, 19, ref darkMode, sizeof(int));
                int cornerPref = 2; // DWMWCP_ROUND
                DwmSetWindowAttribute(this.Handle, 33, ref cornerPref, sizeof(int));

                MARGINS margins = new MARGINS { cxLeftWidth = 1, cxRightWidth = 1, cyTopHeight = 1, cyBottomHeight = 1 };
                DwmExtendFrameIntoClientArea(this.Handle, ref margins);
            }
            catch { }

            InitServerAndWebView();
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= 0x20000; // CS_DROPSHADOW
                return cp;
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _server?.Dispose();
            base.OnFormClosed(e);
        }

        private string FindUiDirectory()
        {
            string[] searchPaths = new string[]
            {
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ui"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "ui"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", "ui"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", "Build_Output", "ui"),
                @"C:\Users\entity\Downloads\ultronx\madium\ui",
                @"C:\Users\entity\Downloads\ultronx\madium\Build_Output\ui"
            };

            foreach (var p in searchPaths)
            {
                if (Directory.Exists(p) && File.Exists(Path.Combine(p, "index.html")))
                {
                    return Path.GetFullPath(p);
                }
            }
            return "";
        }

        private async void InitServerAndWebView()
        {
            _webView = new WebView2
            {
                Dock = DockStyle.Fill,
                DefaultBackgroundColor = Color.FromArgb(13, 13, 13)
            };
            this.Controls.Add(_webView);

            try
            {
                string uiFolder = FindUiDirectory();
                if (!string.IsNullOrEmpty(uiFolder))
                {
                    _server = new EmbeddedHttpServer(uiFolder, 1420);
                }

                string userDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ConstrainttEz", "WebViewData");
                var env = await CoreWebView2Environment.CreateAsync(null, userDataFolder, new CoreWebView2EnvironmentOptions());
                await _webView.EnsureCoreWebView2Async(env);

                var settings = _webView.CoreWebView2.Settings;
                settings.IsScriptEnabled = true;
                settings.AreDefaultScriptDialogsEnabled = true;
                settings.IsWebMessageEnabled = true;
                settings.AreDevToolsEnabled = true;
                settings.AreDefaultContextMenusEnabled = false;
                settings.IsZoomControlEnabled = false;

                // Complete Tauri 2.0 Bridge Polyfill
                string tauriPolyfill = @"
(function() {
    window.__TAURI_INTERNALS__ = {
        plugins: {},
        callbacks: {},
        metadata: {
            currentWindow: { label: 'main' },
            currentWebview: { label: 'main' }
        },
        transformCallback: function(callback, once) {
            var id = Math.floor(Math.random() * 1000000000);
            window.__TAURI_INTERNALS__.callbacks[id] = function(res) {
                if (once) {
                    delete window.__TAURI_INTERNALS__.callbacks[id];
                }
                return typeof callback === 'function' ? callback(res) : null;
            };
            return id;
        },
        unregisterCallback: function(id) {
            delete window.__TAURI_INTERNALS__.callbacks[id];
        },
        invoke: function(cmd, args, options) {
            return new Promise((resolve, reject) => {
                const callbackId = 'cb_' + Math.random().toString(36).substring(2);
                window.__TAURI_INTERNALS__.callbacks[callbackId] = { resolve, reject };
                window.chrome.webview.postMessage({
                    type: 'tauri_invoke',
                    cmd: cmd,
                    args: args || {},
                    callbackId: callbackId
                });
            });
        },
        postMessage: function(msg) {
            window.chrome.webview.postMessage(msg);
        }
    };

    window.__TAURI_EVENT_PLUGIN_INTERNALS__ = {
        unregisterListener: function(event, eventId) {}
    };

    window.__TAURI__ = {
        core: {
            invoke: window.__TAURI_INTERNALS__.invoke
        }
    };
})();
";
                await _webView.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(tauriPolyfill);

                _webView.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;

                _webView.CoreWebView2.NavigationCompleted += async (s, args) =>
                {
                    LogDebug($"NavigationCompleted: Success={args.IsSuccess}, ErrorStatus={args.WebErrorStatus}");
                    await Task.Delay(2000);
                    try
                    {
                        
                    try
                    {
                        string probeScript = @"(function() {
                            return JSON.stringify({
                                bodyChildCount: document.body.childElementCount,
                                bodyHTML: document.body.innerHTML.slice(0, 1000),
                                elementsCount: document.querySelectorAll('*').length,
                                appShellFound: !!document.querySelector('.app-shell'),
                                appWindowFound: !!document.querySelector('.app-window-frame'),
                                errors: window.__errors || []
                            });
                        })()";
                        string probeRes = await _webView.CoreWebView2.ExecuteScriptAsync(probeScript);
                        LogDebug("PROBE: " + probeRes);

                    try
                    {
                        string testScript = @"(async function() {
                            try {
                                const [kit, app] = await Promise.all([
                                    import('/_app/immutable/entry/start.Bys0E55f.js'),
                                    import('/_app/immutable/entry/app.BVPeVSSD.js')
                                ]);
                                return JSON.stringify({ success: true, kitKeys: Object.keys(kit), appKeys: Object.keys(app) });
                            } catch(e) {
                                return JSON.stringify({ success: false, error: e.message, stack: e.stack });
                            }
                        })()";
                        string res = await _webView.CoreWebView2.ExecuteScriptAsync(testScript);
                        LogDebug("IMPORT_TEST: " + res);
                    }
                    catch(Exception ex)
                    {
                        LogDebug("IMPORT_TEST_EX: " + ex.Message);
                    }

                    }
                    catch (Exception ex)
                    {
                        LogDebug("Probe Error: " + ex.Message);
                    }

                        string dom = await _webView.CoreWebView2.ExecuteScriptAsync("document.documentElement.outerHTML");
                        string parsedDom = JsonConvert.DeserializeObject<string>(dom) ?? dom;
                        string outPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "rendered_dom.html");
                        File.WriteAllText(outPath, parsedDom);
                        LogDebug($"Dumped rendered DOM ({parsedDom.Length} chars) to rendered_dom.html");
                    }
                    catch (Exception ex)
                    {
                        LogDebug("DOM Dump Error: " + ex.Message);
                    }
                };


                if (_server != null)
                {
                    _webView.CoreWebView2.Navigate($"http://localhost:{_server.Port}/");
                }
                else if (!string.IsNullOrEmpty(uiFolder))
                {
                    _webView.CoreWebView2.SetVirtualHostNameToFolderMapping(
                        "madium.local",
                        uiFolder,
                        CoreWebView2HostResourceAccessKind.Allow
                    );
                    _webView.CoreWebView2.Navigate("https://madium.local/");
                }
                else
                {
                    _webView.CoreWebView2.NavigateToString("<h1 style='color:white;font-family:sans-serif;padding:40px;'>UI directory not found. Please ensure the 'ui' directory exists alongside the executable.</h1>");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("WebView2 Initialization Error: " + ex.Message, "constraintt.ez Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CoreWebView2_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                string rawJson = e.WebMessageAsJson;
                JObject msg = JObject.Parse(rawJson);
                string? cmd = (string?)msg["cmd"];
                string? callbackId = (string?)msg["callbackId"];
                JObject args = (JObject)(msg["args"] ?? new JObject());

                object? result = null;
                bool isError = false;

                if (cmd != null)
                {
                    switch (cmd)
                    {
                        case "plugin:window|start_dragging":
                            this.BeginInvoke((MethodInvoker)delegate
                            {
                                ReleaseCapture();
                                SendMessage(this.Handle, WM_NCLBUTTONDOWN, (IntPtr)HT_CAPTION, IntPtr.Zero);
                            });
                            break;

                        case "plugin:window|minimize":
                            this.BeginInvoke((MethodInvoker)delegate { this.WindowState = FormWindowState.Minimized; });
                            break;

                        case "plugin:window|toggle_maximize":
                        case "plugin:window|maximize":
                            this.BeginInvoke((MethodInvoker)delegate
                            {
                                this.WindowState = (this.WindowState == FormWindowState.Maximized) ? FormWindowState.Normal : FormWindowState.Maximized;
                            });
                            break;

                        case "plugin:window|unmaximize":
                            this.BeginInvoke((MethodInvoker)delegate { this.WindowState = FormWindowState.Normal; });
                            break;

                        case "plugin:window|is_maximized":
                            result = (this.WindowState == FormWindowState.Maximized);
                            break;

                        case "plugin:window|is_fullscreen":
                            result = false;
                            break;

                        case "plugin:window|set_fullscreen":
                            break;

                        case "plugin:window|get_all_windows":
                            result = new string[] { "main" };
                            break;

                        case "plugin:window|scale_factor":
                            result = 1.0;
                            break;

                        case "plugin:window|inner_size":
                        case "plugin:window|outer_size":
                            result = new { width = this.Width, height = this.Height };
                            break;

                        case "plugin:window|close":
                        case "plugin:window|destroy":
                            this.BeginInvoke((MethodInvoker)delegate { this.Close(); });
                            break;

                        case "plugin:window|set_always_on_top":
                            bool onTop = (bool?)args["alwaysOnTop"] ?? true;
                            this.BeginInvoke((MethodInvoker)delegate { this.TopMost = onTop; });
                            break;

                        case "plugin:event|listen":
                            result = 1;
                            break;

                        case "plugin:event|unlisten":
                        case "plugin:event|emit":
                        case "plugin:event|emit_to":
                            result = true;
                            break;

                        case "check_license":
                        case "redeem_key":
                            result = new { valid = true, reason = (string?)null, expires_at = (string?)null, has_token = true };
                            break;

                        case "get_hardware_id":
                            result = "constraintt-hwid";
                            break;

                        case "check_madium_update":
                            result = new { update_available = false };
                            break;

                        case "get_roblox_clients":
                        case "get_roblox_instances":
                        case "get_installed_launchers":
                        case "list_installed_versions":
                        case "get_roblox_channel_versions":
                            result = new object[] { };
                            break;

                        case "get_running_roblox_version":
                        case "get_latest_roblox_version":
                            result = "version-latest";
                            break;

                        case "detect_roblox_install":
                        case "inspect_roblox_install":
                            result = new { installed = true, path = "" };
                            break;

                        case "start_roblox_watch":
                        case "start_instances_watch":
                        case "stop_roblox_watch":
                        case "stop_instances_watch":
                        case "execute_script":
                        case "execute_in_instance":
                            result = true;
                            break;

                        case "plugin:opener|open_url":
                            string? url = (string?)args["url"] ?? (string?)args["path"];
                            if (!string.IsNullOrEmpty(url))
                            {
                                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                                {
                                    FileName = url,
                                    UseShellExecute = true
                                });
                            }
                            break;

                        case "plugin:dialog|open":
                            using (var ofd = new OpenFileDialog())
                            {
                                ofd.Title = (string?)args["title"] ?? "Open Script";
                                ofd.Filter = "Lua/Luau Scripts (*.lua;*.luau;*.txt)|*.lua;*.luau;*.txt|All Files (*.*)|*.*";
                                if (ofd.ShowDialog(this) == DialogResult.OK)
                                {
                                    result = ofd.FileName;
                                }
                            }
                            break;

                        case "plugin:dialog|save":
                            using (var sfd = new SaveFileDialog())
                            {
                                sfd.Title = (string?)args["title"] ?? "Save Script";
                                sfd.Filter = "Lua Scripts (*.lua)|*.lua|Luau Scripts (*.luau)|*.luau|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                                if (sfd.ShowDialog(this) == DialogResult.OK)
                                {
                                    result = sfd.FileName;
                                }
                            }
                            break;

                        case "plugin:fs|read_text_file":
                            string? readPath = (string?)args["path"];
                            if (readPath != null && File.Exists(readPath))
                            {
                                result = File.ReadAllText(readPath);
                            }
                            else
                            {
                                result = "{}";
                            }
                            break;

                        case "plugin:fs|write_text_file":
                            string? writePath = (string?)args["path"];
                            string? writeData = (string?)args["contents"] ?? (string?)args["data"];
                            if (writePath != null && writeData != null)
                            {
                                string? dir = Path.GetDirectoryName(writePath);
                                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
                                File.WriteAllText(writePath, writeData);
                                result = true;
                            }
                            break;

                        case "plugin:fs|exists":
                            string? checkPath = (string?)args["path"];
                            result = checkPath != null && (File.Exists(checkPath) || Directory.Exists(checkPath));
                            break;

                        case "plugin:fs|read_dir":
                            result = new object[] { };
                            break;

                        case "plugin:path|join":
                            JArray? pathSegments = (JArray?)args["paths"];
                            if (pathSegments != null)
                            {
                                List<string> parts = new List<string>();
                                foreach (var seg in pathSegments) if (seg != null) parts.Add(seg.ToString());
                                result = Path.Combine(parts.ToArray());
                            }
                            else
                            {
                                result = "";
                            }
                            break;

                        case "plugin:path|resolve":
                        case "plugin:path|resolve_directory":
                            result = AppDomain.CurrentDomain.BaseDirectory;
                            break;

                        default:
                            result = true;
                            break;
                    }
                }

                if (callbackId != null && _webView != null)
                {
                    string resJson = JsonConvert.SerializeObject(result);
                    string script = isError
                        ? $"if(window.__TAURI_INTERNALS__ && window.__TAURI_INTERNALS__.callbacks['{callbackId}']){{ window.__TAURI_INTERNALS__.callbacks['{callbackId}'].reject({resJson}); delete window.__TAURI_INTERNALS__.callbacks['{callbackId}']; }}"
                        : $"if(window.__TAURI_INTERNALS__ && window.__TAURI_INTERNALS__.callbacks['{callbackId}']){{ window.__TAURI_INTERNALS__.callbacks['{callbackId}'].resolve({resJson}); delete window.__TAURI_INTERNALS__.callbacks['{callbackId}']; }}";
                    _webView.CoreWebView2.ExecuteScriptAsync(script);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("IPC Error: " + ex.Message);
            }
        }
    }
}
