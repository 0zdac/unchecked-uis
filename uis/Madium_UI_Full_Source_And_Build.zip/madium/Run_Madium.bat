@echo off
start "" "%~dp0Build_Output\Madium.exe"
