var Zt = t => {
  throw TypeError(t)
};
var $e = (t, e, n) => e.has(t) || Zt("Cannot " + n);
var y = (t, e, n) => ($e(t, e, "read from private field"), n ? n.call(t) : e.get(t)),
  U = (t, e, n) => e.has(t) ? Zt("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, n);
import {
  aP as Dt,
  w as te,
  y as T,
  m as I,
  l as O,
  x as mt,
  bs as Ce
} from "./BZGnCJ3u.js";
class qt {
  constructor(e, n) {
    this.status = e, typeof n == "string" ? this.body = {
      message: n
    } : n ? this.body = n : this.body = {
      message: `Error: ${e}`
    }
  }
  toString() {
    return JSON.stringify(this.body)
  }
}
class Vt {
  constructor(e, n) {
    try {
      new Headers({
        location: n
      })
    } catch {
      throw new Error(`Invalid redirect location ${JSON.stringify(n)}: this string contains characters that cannot be used in HTTP headers`)
    }
    this.status = e, this.location = n
  }
}
class Bt extends Error {
  constructor(e, n, a) {
    super(a), this.status = e, this.text = n
  }
}
new URL("sveltekit-internal://");

function je(t, e) {
  return t === "/" || e === "ignore" ? t : e === "never" ? t.endsWith("/") ? t.slice(0, -1) : t : e === "always" && !t.endsWith("/") ? t + "/" : t
}

function Ne(t) {
  return t.split("%25").map(decodeURI).join("%25")
}

function De(t) {
  for (const e in t) t[e] = decodeURIComponent(t[e]);
  return t
}

function Tt({
  href: t
}) {
  return t.split("#")[0]
}

function C() {}

function qe(...t) {
  let e = 5381;
  for (const n of t)
    if (typeof n == "string") {
      let a = n.length;
      for (; a;) e = e * 33 ^ n.charCodeAt(--a)
    } else if (ArrayBuffer.isView(n)) {
    const a = new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
    let r = a.length;
    for (; r;) e = e * 33 ^ a[--r]
  } else throw new TypeError("value must be a string or TypedArray");
  return (e >>> 0).toString(36)
}
new TextEncoder;
new TextDecoder;

function Ve(t) {
  const e = atob(t),
    n = new Uint8Array(e.length);
  for (let a = 0; a < e.length; a++) n[a] = e.charCodeAt(a);
  return n
}
const Be = window.fetch;
window.fetch = (t, e) => ((t instanceof Request ? t.method : (e == null ? void 0 : e.method) || "GET") !== "GET" && z.delete(Kt(t)), Be(t, e));
const z = new Map;

function Ke(t, e) {
  const n = Kt(t, e),
    a = document.querySelector(n);
  if (a != null && a.textContent) {
    a.remove();
    let {
      body: r,
      ...i
    } = JSON.parse(a.textContent);
    const o = a.getAttribute("data-ttl");
    return o && z.set(n, {
      body: r,
      init: i,
      ttl: 1e3 * Number(o)
    }), a.getAttribute("data-b64") !== null && (r = Ve(r)), Promise.resolve(new Response(r, i))
  }
  return window.fetch(t, e)
}

function Me(t, e, n) {
  if (z.size > 0) {
    const a = Kt(t, n),
      r = z.get(a);
    if (r) {
      if (performance.now() < r.ttl && ["default", "force-cache", "only-if-cached", void 0].includes(n == null ? void 0 : n.cache)) return new Response(r.body, r.init);
      z.delete(a)
    }
  }
  return window.fetch(e, n)
}

function Kt(t, e) {
  let a = `script[data-sveltekit-fetched][data-url=${JSON.stringify(t instanceof Request?t.url:t)}]`;
  if (e != null && e.headers || e != null && e.body) {
    const r = [];
    e.headers && r.push([...new Headers(e.headers)].join(",")), e.body && (typeof e.body == "string" || ArrayBuffer.isView(e.body)) && r.push(e.body), a += `[data-hash="${qe(...r)}"]`
  }
  return a
}
const Fe = /^(\[)?(\.\.\.)?(\w+)(?:=(\w+))?(\])?$/;

function Ge(t) {
  const e = [];
  return {
    pattern: t === "/" ? /^\/$/ : new RegExp(`^${We(t).map(a=>{const r=/^\[\.\.\.(\w+)(?:=(\w+))?\]$/.exec(a);if(r)return e.push({name:r[1],matcher:r[2],optional:!1,rest:!0,chained:!0}),"(?:/([^]*))?";const i=/^\[\[(\w+)(?:=(\w+))?\]\]$/.exec(a);if(i)return e.push({name:i[1],matcher:i[2],optional:!0,rest:!1,chained:!0}),"(?:/([^/]+))?";if(!a)return;const o=a.split(/\[(.+?)\](?!\])/);return"/"+o.map((l,c)=>{if(c%2){if(l.startsWith("x+"))return It(String.fromCharCode(parseInt(l.slice(2),16)));if(l.startsWith("u+"))return It(String.fromCharCode(...l.slice(2).split("-").map(m=>parseInt(m,16))));const d=Fe.exec(l),[,u,w,p,f]=d;return e.push({name:p,matcher:f,optional:!!u,rest:!!w,chained:w?c===1&&o[0]==="":!1}),w?"([^]*?)":u?"([^/]*)?":"([^/]+?)"}return It(l)}).join("")}).join("")}/?$`),
    params: e
  }
}

function He(t) {
  return t !== "" && !/^\([^)]+\)$/.test(t)
}

function We(t) {
  return t.slice(1).split("/").filter(He)
}

function Je(t, e, n) {
  const a = {},
    r = t.slice(1),
    i = r.filter(s => s !== void 0);
  let o = 0;
  for (let s = 0; s < e.length; s += 1) {
    const l = e[s];
    let c = r[s - o];
    if (l.chained && l.rest && o && (c = r.slice(s - o, s + 1).filter(d => d).join("/"), o = 0), c === void 0)
      if (l.rest) c = "";
      else continue;
    if (!l.matcher || n[l.matcher](c)) {
      a[l.name] = c;
      const d = e[s + 1],
        u = r[s + 1];
      d && !d.rest && d.optional && u && l.chained && (o = 0), !d && !u && Object.keys(a).length === i.length && (o = 0);
      continue
    }
    if (l.optional && l.chained) {
      o++;
      continue
    }
    return
  }
  if (!o) return a
}

function It(t) {
  return t.normalize().replace(/[[\]]/g, "\\$&").replace(/%/g, "%25").replace(/\//g, "%2[Ff]").replace(/\?/g, "%3[Ff]").replace(/#/g, "%23").replace(/[.*+?^${}()|\\]/g, "\\$&")
}

function Ye({
  nodes: t,
  server_loads: e,
  dictionary: n,
  matchers: a
}) {
  const r = new Set(e);
  return Object.entries(n).map(([s, [l, c, d]]) => {
    const {
      pattern: u,
      params: w
    } = Ge(s), p = {
      id: s,
      exec: f => {
        const m = u.exec(f);
        if (m) return Je(m, w, a)
      },
      errors: [1, ...d || []].map(f => t[f]),
      layouts: [0, ...c || []].map(o),
      leaf: i(l)
    };
    return p.errors.length = p.layouts.length = Math.max(p.errors.length, p.layouts.length), p
  });

  function i(s) {
    const l = s < 0;
    return l && (s = ~s), [l, t[s]]
  }

  function o(s) {
    return s === void 0 ? s : [r.has(s), t[s]]
  }
}

function he(t, e = JSON.parse) {
  try {
    return e(sessionStorage[t])
  } catch {}
}

function ee(t, e, n = JSON.stringify) {
  const a = n(e);
  try {
    sessionStorage[t] = a
  } catch {}
}
var le;
const A = ((le = globalThis.__sveltekit_xftamw) == null ? void 0 : le.base) ?? "";
var ce;
const ze = ((ce = globalThis.__sveltekit_xftamw) == null ? void 0 : ce.assets) ?? A ?? "",
  Xe = "1787504509584",
  pe = "sveltekit:snapshot",
  ge = "sveltekit:scroll",
  me = "sveltekit:states",
  Qe = "sveltekit:pageurl",
  F = "sveltekit:history",
  Q = "sveltekit:navigation",
  q = {
    tap: 1,
    hover: 2,
    viewport: 3,
    eager: 4,
    off: -1,
    false: -1
  },
  Mt = location.origin;

function _e(t) {
  if (t instanceof URL) return t;
  let e = document.baseURI;
  if (!e) {
    const n = document.getElementsByTagName("base");
    e = n.length ? n[0].href : document.URL
  }
  return new URL(t, e)
}

function B() {
  return {
    x: pageXOffset,
    y: pageYOffset
  }
}

function M(t, e) {
  return t.getAttribute(`data-sveltekit-${e}`)
}
const ne = {
  ...q,
  "": q.hover
};

function we(t) {
  let e = t.assignedSlot ?? t.parentNode;
  return (e == null ? void 0 : e.nodeType) === 11 && (e = e.host), e
}

function ve(t, e) {
  for (; t && t !== e;) {
    if (t.nodeName.toUpperCase() === "A" && t.hasAttribute("href")) return t;
    t = we(t)
  }
}

function $t(t, e, n) {
  let a;
  try {
    if (a = new URL(t instanceof SVGAElement ? t.href.baseVal : t.href, document.baseURI), n && a.hash.match(/^#[^/]/)) {
      const s = location.hash.split("#")[1] || "/";
      a.hash = `#${s}${a.hash}`
    }
  } catch {}
  const r = t instanceof SVGAElement ? t.target.baseVal : t.target,
    i = !a || !!r || xt(a, e, n) || (t.getAttribute("rel") || "").split(/\s+/).includes("external"),
    o = (a == null ? void 0 : a.origin) === Mt && t.hasAttribute("download");
  return {
    url: a,
    external: i,
    target: r,
    download: o
  }
}

function _t(t) {
  let e = null,
    n = null,
    a = null,
    r = null,
    i = null,
    o = null,
    s = t;
  for (; s && s !== document.documentElement;) a === null && (a = M(s, "preload-code")), r === null && (r = M(s, "preload-data")), e === null && (e = M(s, "keepfocus")), n === null && (n = M(s, "noscroll")), i === null && (i = M(s, "reload")), o === null && (o = M(s, "replacestate")), s = we(s);

  function l(c) {
    switch (c) {
      case "":
      case "true":
        return !0;
      case "off":
      case "false":
        return !1;
      default:
        return
    }
  }
  return {
    preload_code: ne[a ?? "off"],
    preload_data: ne[r ?? "off"],
    keepfocus: l(e),
    noscroll: l(n),
    reload: l(i),
    replace_state: l(o)
  }
}

function re(t) {
  const e = Dt(t);
  let n = !0;

  function a() {
    n = !0, e.update(o => o)
  }

  function r(o) {
    n = !1, e.set(o)
  }

  function i(o) {
    let s;
    return e.subscribe(l => {
      (s === void 0 || n && l !== s) && o(s = l)
    })
  }
  return {
    notify: a,
    set: r,
    subscribe: i
  }
}
const ye = {
  v: C
};

function Ze() {
  const {
    set: t,
    subscribe: e
  } = Dt(!1);
  let n;
  async function a() {
    clearTimeout(n);
    try {
      const r = await fetch(`${ze}/_app/version.json`, {
        headers: {
          pragma: "no-cache",
          "cache-control": "no-cache"
        }
      });
      if (!r.ok) return !1;
      const o = (await r.json()).version !== Xe;
      return o && (t(!0), ye.v(), clearTimeout(n)), o
    } catch {
      return !1
    }
  }
  return {
    subscribe: e,
    check: a
  }
}

function xt(t, e, n) {
  return t.origin !== Mt || !t.pathname.startsWith(e) ? !0 : n ? t.pathname !== location.pathname : !1
}

function An(t) {}
const be = new Set(["load", "prerender", "csr", "ssr", "trailingSlash", "config"]);
[...be];
const tn = new Set([...be]);
[...tn];

function en(t) {
  return t.filter(e => e != null)
}

function Ft(t) {
  return t instanceof qt || t instanceof Bt ? t.status : 500
}

function nn(t) {
  return t instanceof Bt ? t.text : "Internal Error"
}
let R, Z, Ot;
const rn = te.toString().includes("$$") || /function \w+\(\) \{\}/.test(te.toString()),
  ae = "a:";
var at, ot, st, it, lt, ct, ft, ut, fe, dt, ue, ht, de;
rn ? (R = {
  data: {},
  form: null,
  error: null,
  params: {},
  route: {
    id: null
  },
  state: {},
  status: -1,
  url: new URL(ae)
}, Z = {
  current: null
}, Ot = {
  current: !1
}) : (R = new(fe = class {
  constructor() {
    U(this, at, T({}));
    U(this, ot, T(null));
    U(this, st, T(null));
    U(this, it, T({}));
    U(this, lt, T({
      id: null
    }));
    U(this, ct, T({}));
    U(this, ft, T(-1));
    U(this, ut, T(new URL(ae)))
  }
  get data() {
    return I(y(this, at))
  }
  set data(e) {
    O(y(this, at), e)
  }
  get form() {
    return I(y(this, ot))
  }
  set form(e) {
    O(y(this, ot), e)
  }
  get error() {
    return I(y(this, st))
  }
  set error(e) {
    O(y(this, st), e)
  }
  get params() {
    return I(y(this, it))
  }
  set params(e) {
    O(y(this, it), e)
  }
  get route() {
    return I(y(this, lt))
  }
  set route(e) {
    O(y(this, lt), e)
  }
  get state() {
    return I(y(this, ct))
  }
  set state(e) {
    O(y(this, ct), e)
  }
  get status() {
    return I(y(this, ft))
  }
  set status(e) {
    O(y(this, ft), e)
  }
  get url() {
    return I(y(this, ut))
  }
  set url(e) {
    O(y(this, ut), e)
  }
}, at = new WeakMap, ot = new WeakMap, st = new WeakMap, it = new WeakMap, lt = new WeakMap, ct = new WeakMap, ft = new WeakMap, ut = new WeakMap, fe), Z = new(ue = class {
  constructor() {
    U(this, dt, T(null))
  }
  get current() {
    return I(y(this, dt))
  }
  set current(e) {
    O(y(this, dt), e)
  }
}, dt = new WeakMap, ue), Ot = new(de = class {
  constructor() {
    U(this, ht, T(!1))
  }
  get current() {
    return I(y(this, ht))
  }
  set current(e) {
    O(y(this, ht), e)
  }
}, ht = new WeakMap, de), ye.v = () => Ot.current = !0);

function an(t) {
  Object.assign(R, t)
}
const on = new Set(["icon", "shortcut icon", "apple-touch-icon"]);
let J = null;
const N = he(ge) ?? {},
  tt = he(pe) ?? {},
  j = {
    url: re({}),
    page: re({}),
    navigating: Dt(null),
    updated: Ze()
  };

function Gt(t) {
  N[t] = B()
}

function sn(t, e) {
  let n = t + 1;
  for (; N[n];) delete N[n], n += 1;
  for (n = e + 1; tt[n];) delete tt[n], n += 1
}

function et(t, e = !1) {
  return e ? location.replace(t.href) : location.href = t.href, new Promise(C)
}
async function ke() {
  if ("serviceWorker" in navigator) {
    const t = await navigator.serviceWorker.getRegistration(A || "/");
    t && await t.update()
  }
}
let Ht, Ct, wt, P, jt, E;
const vt = [],
  yt = [];
let v = null;

function bt() {
  var t;
  (t = v == null ? void 0 : v.fork) == null || t.then(e => e == null ? void 0 : e.discard()), v = null
}
const gt = new Map,
  Ee = new Set,
  ln = new Set,
  X = new Set;
let _ = {
    branch: [],
    error: null,
    url: null
  },
  Se = !1,
  kt = !1,
  oe = !0,
  nt = !1,
  Y = !1,
  Re = !1,
  Wt = !1,
  xe, k, L, V;
const Et = new Set,
  se = new Map;
async function On(t, e, n) {
  var i, o, s, l;
  globalThis.__sveltekit_xftamw && (globalThis.__sveltekit_xftamw.query, globalThis.__sveltekit_xftamw.prerender), document.URL !== location.href && (location.href = location.href), E = t, await ((o = (i = t.hooks).init) == null ? void 0 : o.call(i)), Ht = Ye(t), P = document.documentElement, jt = e, Ct = t.nodes[0], wt = t.nodes[1], Ct(), wt(), k = (s = history.state) == null ? void 0 : s[F], L = (l = history.state) == null ? void 0 : l[Q], k || (k = L = Date.now(), history.replaceState({
    ...history.state,
    [F]: k,
    [Q]: L
  }, ""));
  const a = N[k];

  function r() {
    a && (history.scrollRestoration = "manual", scrollTo(a.x, a.y))
  }
  n ? (r(), await kn(jt, n)) : (await G({
    type: "enter",
    url: _e(E.hash ? Rn(new URL(location.href)) : location.href),
    replace_state: !0
  }), r()), bn()
}

function cn() {
  vt.length = 0, Wt = !1
}

function Le(t) {
  yt.some(e => e == null ? void 0 : e.snapshot) && (tt[t] = yt.map(e => {
    var n;
    return (n = e == null ? void 0 : e.snapshot) == null ? void 0 : n.capture()
  }))
}

function Ae(t) {
  var e;
  (e = tt[t]) == null || e.forEach((n, a) => {
    var r, i;
    (i = (r = yt[a]) == null ? void 0 : r.snapshot) == null || i.restore(n)
  })
}

function ie() {
  Gt(k), ee(ge, N), Le(L), ee(pe, tt)
}
async function fn(t, e, n, a) {
  let r;
  e.invalidateAll && bt(), await G({
    type: "goto",
    url: _e(t),
    keepfocus: e.keepFocus,
    noscroll: e.noScroll,
    replace_state: e.replaceState,
    state: e.state,
    redirect_count: n,
    nav_token: a,
    accept: () => {
      e.invalidateAll && (Wt = !0, r = [], se.forEach((i, o) => {
        for (const s of i.keys()) r.push(o + "/" + s)
      })), e.invalidate && e.invalidate.forEach(yn)
    }
  }), e.invalidateAll && mt().then(mt).then(() => {
    se.forEach((i, o) => {
      i.forEach(({
        resource: s
      }, l) => {
        var c;
        r != null && r.includes(o + "/" + l) && ((c = s.refresh) == null || c.call(s))
      })
    })
  })
}
async function un(t) {
  if (t.id !== (v == null ? void 0 : v.id)) {
    bt();
    const e = {};
    Et.add(e), v = {
      id: t.id,
      token: e,
      promise: Te({
        ...t,
        preload: e
      }).then(n => (Et.delete(e), n.type === "loaded" && n.state.error && bt(), n)),
      fork: null
    }
  }
  return v.promise
}
async function Pt(t) {
  var n;
  const e = (n = await Lt(t, !1)) == null ? void 0 : n.route;
  e && await Promise.all([...e.layouts, e.leaf].filter(Boolean).map(a => a[1]()))
}
async function Ue(t, e, n) {
  var i;
  const a = {
    params: _.params,
    route: {
      id: ((i = _.route) == null ? void 0 : i.id) ?? null
    },
    url: new URL(location.href)
  };
  _ = {
    ...t.state,
    nav: a
  };
  const r = document.querySelector("style[data-sveltekit]");
  if (r && r.remove(), Object.assign(R, t.props.page), xe = new E.root({
      target: e,
      props: {
        ...t.props,
        stores: j,
        components: yt
      },
      hydrate: n,
      sync: !1,
      transformError: void 0
    }), await Promise.resolve(), Ae(L), n) {
    const o = {
      from: null,
      to: {
        ...a,
        scroll: N[k] ?? B()
      },
      willUnload: !1,
      type: "enter",
      complete: Promise.resolve()
    };
    X.forEach(s => s(o))
  }
  kt = !0
}
async function St({
  url: t,
  params: e,
  branch: n,
  errors: a,
  status: r,
  error: i,
  route: o,
  form: s
}) {
  let l = "never";
  if (A && (t.pathname === A || t.pathname === A + "/")) l = "always";
  else
    for (const f of n)(f == null ? void 0 : f.slash) !== void 0 && (l = f.slash);
  t.pathname = je(t.pathname, l), t.search = t.search;
  const c = {
    type: "loaded",
    state: {
      url: t,
      params: e,
      branch: n,
      error: i,
      route: o
    },
    props: {
      constructors: en(n).map(f => f.node.component),
      page: Qt(R)
    }
  };
  s !== void 0 && (c.props.form = s);
  let d = {},
    u = !R,
    w = 0;
  for (let f = 0; f < Math.max(n.length, _.branch.length); f += 1) {
    const m = n[f],
      h = _.branch[f];
    (m == null ? void 0 : m.data) !== (h == null ? void 0 : h.data) && (u = !0), m && (d = {
      ...d,
      ...m.data
    }, u && (c.props[`data_${w}`] = d), w += 1)
  }
  return (!_.url || t.href !== _.url.href || _.error !== i || s !== void 0 && s !== R.form || u) && (c.props.page = {
    error: i,
    params: e,
    route: {
      id: (o == null ? void 0 : o.id) ?? null
    },
    state: {},
    status: r,
    url: new URL(t),
    form: s ?? null,
    data: u ? d : R.data
  }), c
}
async function Jt({
  loader: t,
  parent: e,
  url: n,
  params: a,
  route: r,
  server_data_node: i
}) {
  var c, d;
  let o = null;
  const s = {
      dependencies: new Set,
      params: new Set,
      parent: !1,
      route: !1,
      url: !1,
      search_params: new Set
    },
    l = await t();
  return {
    node: l,
    loader: t,
    server: i,
    universal: (c = l.universal) != null && c.load ? {
      type: "data",
      data: o,
      uses: s
    } : null,
    data: o ?? (i == null ? void 0 : i.data) ?? null,
    slash: ((d = l.universal) == null ? void 0 : d.trailingSlash) ?? (i == null ? void 0 : i.slash)
  }
}

function dn(t, e, n) {
  let a = t instanceof Request ? t.url : t;
  const r = new URL(a, n);
  r.origin === n.origin && (a = r.href.slice(n.origin.length));
  const i = kt ? Me(a, r.href, e) : Ke(a, e);
  return {
    resolved: r,
    promise: i
  }
}

function hn(t, e, n, a, r, i) {
  if (Wt) return !0;
  if (!r) return !1;
  if (r.parent && t || r.route && e || r.url && n) return !0;
  for (const o of r.search_params)
    if (a.has(o)) return !0;
  for (const o of r.params)
    if (i[o] !== _.params[o]) return !0;
  for (const o of r.dependencies)
    if (vt.some(s => s(new URL(o)))) return !0;
  return !1
}

function Yt(t, e) {
  return (t == null ? void 0 : t.type) === "data" ? t : (t == null ? void 0 : t.type) === "skip" ? e ?? null : null
}

function pn(t, e) {
  if (!t) return new Set(e.searchParams.keys());
  const n = new Set([...t.searchParams.keys(), ...e.searchParams.keys()]);
  for (const a of n) {
    const r = t.searchParams.getAll(a),
      i = e.searchParams.getAll(a);
    r.every(o => i.includes(o)) && i.every(o => r.includes(o)) && n.delete(a)
  }
  return n
}

function gn({
  error: t,
  url: e,
  route: n,
  params: a
}) {
  return {
    type: "loaded",
    state: {
      error: t,
      url: e,
      route: n,
      params: a,
      branch: []
    },
    props: {
      page: Qt(R),
      constructors: []
    }
  }
}
async function Te({
  id: t,
  invalidating: e,
  url: n,
  params: a,
  route: r,
  preload: i
}) {
  if ((v == null ? void 0 : v.id) === t) return Et.delete(v.token), v.promise;
  const {
    errors: o,
    layouts: s,
    leaf: l
  } = r, c = [...s, l];
  o.forEach(h => h == null ? void 0 : h().catch(C)), c.forEach(h => h == null ? void 0 : h[1]().catch(C));
  const d = _.url ? t !== Rt(_.url) : !1,
    u = _.route ? r.id !== _.route.id : !1,
    w = pn(_.url, n);
  let p = !1;
  const f = c.map(async (h, g) => {
    var $;
    if (!h) return;
    const b = _.branch[g];
    return h[1] === (b == null ? void 0 : b.loader) && !hn(p, u, d, w, ($ = b.universal) == null ? void 0 : $.uses, a) ? b : (p = !0, Jt({
      loader: h[1],
      url: n,
      params: a,
      route: r,
      parent: async () => {
        var pt;
        const D = {};
        for (let K = 0; K < g; K += 1) Object.assign(D, (pt = await f[K]) == null ? void 0 : pt.data);
        return D
      },
      server_data_node: Yt(h[0] ? {
        type: "skip"
      } : null, h[0] ? b == null ? void 0 : b.server : void 0)
    }))
  });
  for (const h of f) h.catch(C);
  const m = [];
  for (let h = 0; h < c.length; h += 1)
    if (c[h]) try {
      m.push(await f[h])
    } catch (g) {
      if (g instanceof Vt) return {
        type: "redirect",
        location: g.location
      };
      if (Et.has(i)) return gn({
        error: await rt(g, {
          params: a,
          url: n,
          route: {
            id: r.id
          }
        }),
        url: n,
        params: a,
        route: r
      });
      let b = Ft(g),
        x;
      if (g instanceof qt) x = g.body;
      else {
        if (await j.updated.check()) return await ke(), await et(n);
        x = await rt(g, {
          params: a,
          url: n,
          route: {
            id: r.id
          }
        })
      }
      const $ = await mn(h, m, o);
      return $ ? St({
        url: n,
        params: a,
        branch: m.slice(0, $.idx).concat($.node),
        errors: o,
        status: b,
        error: x,
        route: r
      }) : await Oe(n, {
        id: r.id
      }, x, b)
    } else m.push(void 0);
  return St({
    url: n,
    params: a,
    branch: m,
    errors: o,
    status: 200,
    error: null,
    route: r,
    form: e ? void 0 : null
  })
}
async function mn(t, e, n) {
  for (; t--;)
    if (n[t]) {
      let a = t;
      for (; !e[a];) a -= 1;
      try {
        return {
          idx: a + 1,
          node: {
            node: await n[t](),
            loader: n[t],
            data: {},
            server: null,
            universal: null
          }
        }
      } catch {
        continue
      }
    }
}
async function zt({
  status: t,
  error: e,
  url: n,
  route: a
}) {
  const r = {};
  let i = null;
  try {
    const o = await Jt({
        loader: Ct,
        url: n,
        params: r,
        route: a,
        parent: () => Promise.resolve({}),
        server_data_node: Yt(i)
      }),
      s = {
        node: await wt(),
        loader: wt,
        universal: null,
        server: null,
        data: null
      };
    return St({
      url: n,
      params: r,
      branch: [o, s],
      status: t,
      error: e,
      errors: [],
      route: null
    })
  } catch (o) {
    if (o instanceof Vt) return fn(new URL(o.location, location.href), {}, 0);
    throw o
  }
}
async function _n(t) {
  const e = t.href;
  if (gt.has(e)) return gt.get(e);
  let n;
  try {
    const a = (async () => {
      let r = await E.hooks.reroute({
        url: new URL(t),
        fetch: async (i, o) => dn(i, o, t).promise
      }) ?? t;
      if (typeof r == "string") {
        const i = new URL(t);
        E.hash ? i.hash = r : i.pathname = r, r = i
      }
      return r
    })();
    gt.set(e, a), n = await a
  } catch {
    gt.delete(e);
    return
  }
  return n
}
async function Lt(t, e) {
  if (t && !xt(t, A, E.hash)) {
    const n = await _n(t);
    if (!n) return;
    const a = wn(n);
    for (const r of Ht) {
      const i = r.exec(a);
      if (i) return {
        id: Rt(t),
        invalidating: e,
        route: r,
        params: De(i),
        url: t
      }
    }
  }
}

function wn(t) {
  return Ne(E.hash ? t.hash.replace(/^#/, "").replace(/[?#].+/, "") : t.pathname.slice(A.length)) || "/"
}

function Rt(t) {
  return (E.hash ? t.hash.replace(/^#/, "") : t.pathname) + t.search
}

function Ie({
  url: t,
  type: e,
  intent: n,
  delta: a,
  event: r,
  scroll: i
}) {
  let o = !1;
  const s = Xt(_, n, t, e, i ?? null);
  a !== void 0 && (s.navigation.delta = a), r !== void 0 && (s.navigation.event = r);
  const l = {
    ...s.navigation,
    cancel: () => {
      o = !0, s.reject(new Error("navigation cancelled"))
    }
  };
  return nt || Ee.forEach(c => c(l)), o ? null : s
}
async function G({
  type: t,
  url: e,
  popped: n,
  keepfocus: a,
  noscroll: r,
  replace_state: i,
  state: o = {},
  redirect_count: s = 0,
  nav_token: l = {},
  accept: c = C,
  block: d = C,
  event: u
}) {
  var K;
  const w = V;
  V = l;
  const p = await Lt(e, !1),
    f = t === "enter" ? Xt(_, p, e, t) : Ie({
      url: e,
      type: t,
      delta: n == null ? void 0 : n.delta,
      intent: p,
      scroll: n == null ? void 0 : n.scroll,
      event: u
    });
  if (!f) {
    d(), V === l && (V = w);
    return
  }
  const m = k,
    h = L;
  c(), nt = !0, kt && f.navigation.type !== "enter" && j.navigating.set(Z.current = f.navigation);
  let g = p && await Te(p);
  if (!g) {
    if (xt(e, A, E.hash)) return await et(e, i);
    g = await Oe(e, {
      id: null
    }, await rt(new Bt(404, "Not Found", `Not found: ${e.pathname}`), {
      url: e,
      params: {},
      route: {
        id: null
      }
    }), 404, i)
  }
  if (e = (p == null ? void 0 : p.url) || e, V !== l) return f.reject(new Error("navigation aborted")), !1;
  if (g.type === "redirect") {
    if (s < 20) {
      await G({
        type: t,
        url: new URL(g.location, e),
        popped: n,
        keepfocus: a,
        noscroll: r,
        replace_state: i,
        state: o,
        redirect_count: s + 1,
        nav_token: l
      }), f.fulfil(void 0);
      return
    }
    g = await zt({
      status: 500,
      error: await rt(new Error("Redirect loop"), {
        url: e,
        params: {},
        route: {
          id: null
        }
      }),
      url: e,
      route: {
        id: null
      }
    })
  } else g.props.page.status >= 400 && await j.updated.check() && (await ke(), await et(e, i));
  if (cn(), Gt(m), Le(h), g.props.page.url.pathname !== e.pathname && (e.pathname = g.props.page.url.pathname), o = n ? n.state : o, !n) {
    const S = i ? 0 : 1,
      H = {
        [F]: k += S,
        [Q]: L += S,
        [me]: o
      };
    (i ? history.replaceState : history.pushState).call(history, H, "", e), i || sn(k, L)
  }
  const b = p && (v == null ? void 0 : v.id) === p.id ? v.fork : null;
  v != null && v.fork && !b && bt(), v = null, g.props.page.state = o;
  let x;
  if (kt) {
    const S = (await Promise.all(Array.from(ln, W => W(f.navigation)))).filter(W => typeof W == "function");
    if (S.length > 0) {
      let W = function() {
        S.forEach(Ut => {
          X.delete(Ut)
        })
      };
      S.push(W), S.forEach(Ut => {
        X.add(Ut)
      })
    }
    const H = f.navigation.to;
    _ = {
      ...g.state,
      nav: {
        params: H.params,
        route: H.route,
        url: H.url
      }
    }, g.props.page && (g.props.page.url = e);
    const At = b && await b;
    At ? x = At.commit() : (J = null, xe.$set(g.props), J && Object.assign(g.props.page, J), an(g.props.page), x = (K = Ce) == null ? void 0 : K()), Re = !0
  } else await Ue(g, jt, !1);
  const {
    activeElement: $
  } = document;
  await x, await mt(), await mt();
  let D = null;
  if (oe) {
    const S = n ? n.scroll : r ? B() : null;
    S ? scrollTo(S.x, S.y) : (D = e.hash && document.getElementById(Pe(e))) ? D.scrollIntoView() : scrollTo(0, 0)
  }
  const pt = document.activeElement !== $ && document.activeElement !== document.body;
  !a && !pt && Sn(e, !D), oe = !0, g.props.page && (J && Object.assign(g.props.page, J), Object.assign(R, g.props.page)), nt = !1, t === "popstate" && Ae(L), f.fulfil(void 0), f.navigation.to && (f.navigation.to.scroll = B()), X.forEach(S => S(f.navigation)), j.navigating.set(Z.current = null)
}
async function Oe(t, e, n, a, r) {
  return t.origin === Mt && t.pathname === location.pathname && !Se ? await zt({
    status: a,
    error: n,
    url: t,
    route: e
  }) : await et(t, r)
}

function vn() {
  let t, e = {
      element: void 0,
      href: void 0
    },
    n;
  P.addEventListener("mousemove", s => {
    const l = s.target;
    clearTimeout(t), t = setTimeout(() => {
      i(l, q.hover)
    }, 20)
  });

  function a(s) {
    s.defaultPrevented || i(s.composedPath()[0], q.tap)
  }
  P.addEventListener("mousedown", a), P.addEventListener("touchstart", a, {
    passive: !0
  });
  const r = new IntersectionObserver(s => {
    for (const l of s) l.isIntersecting && (Pt(new URL(l.target.href)), r.unobserve(l.target))
  }, {
    threshold: 0
  });
  async function i(s, l) {
    const c = ve(s, P),
      d = c === e.element && (c == null ? void 0 : c.href) === e.href && l >= n;
    if (!c || d) return;
    const {
      url: u,
      external: w,
      download: p
    } = $t(c, A, E.hash);
    if (w || p) return;
    const f = _t(c),
      m = u && Rt(_.url) === Rt(u);
    if (!(f.reload || m))
      if (l <= f.preload_data) {
        e = {
          element: c,
          href: c.href
        }, n = q.tap;
        const h = await Lt(u, !1);
        if (!h) return;
        un(h)
      } else l <= f.preload_code && (e = {
        element: c,
        href: c.href
      }, n = l, Pt(u))
  }

  function o() {
    r.disconnect();
    for (const s of P.querySelectorAll("a")) {
      const {
        url: l,
        external: c,
        download: d
      } = $t(s, A, E.hash);
      if (c || d) continue;
      const u = _t(s);
      u.reload || (u.preload_code === q.viewport && r.observe(s), u.preload_code === q.eager && Pt(l))
    }
  }
  X.add(o), o()
}

function rt(t, e) {
  if (t instanceof qt) return t.body;
  const n = Ft(t),
    a = nn(t);
  return E.hooks.handleError({
    error: t,
    event: e,
    status: n,
    message: a
  }) ?? {
    message: a
  }
}

function yn(t) {
  if (typeof t == "function") vt.push(t);
  else {
    const {
      href: e
    } = new URL(t, location.href);
    vt.push(n => n.href === e)
  }
}

function bn() {
  var e;
  history.scrollRestoration = "manual", addEventListener("beforeunload", n => {
    let a = !1;
    if (ie(), !nt) {
      const r = Xt(_, void 0, null, "leave"),
        i = {
          ...r.navigation,
          cancel: () => {
            a = !0, r.reject(new Error("navigation cancelled"))
          }
        };
      Ee.forEach(o => o(i))
    }
    a ? (n.preventDefault(), n.returnValue = "") : history.scrollRestoration = "auto"
  }), addEventListener("visibilitychange", () => {
    document.visibilityState === "hidden" && ie()
  }), (e = navigator.connection) != null && e.saveData || vn(), P.addEventListener("click", async n => {
    if (n.button || n.which !== 1 || n.metaKey || n.ctrlKey || n.shiftKey || n.altKey || n.defaultPrevented) return;
    const a = ve(n.composedPath()[0], P);
    if (!a) return;
    const {
      url: r,
      external: i,
      target: o,
      download: s
    } = $t(a, A, E.hash);
    if (!r) return;
    if (o === "_parent" || o === "_top") {
      if (window.parent !== window) return
    } else if (o && o !== "_self") return;
    const l = _t(a);
    if (!(a instanceof SVGAElement) && r.protocol !== location.protocol && !(r.protocol === "https:" || r.protocol === "http:") || s) return;
    const [d, u] = (E.hash ? r.hash.replace(/^#/, "") : r.href).split("#"), w = d === Tt(location);
    if (i || l.reload && (!w || !u)) {
      Ie({
        url: r,
        type: "link",
        event: n
      }) ? nt = !0 : n.preventDefault();
      return
    }
    if (u !== void 0 && w) {
      const [, p] = _.url.href.split("#");
      if (p === u) {
        if (n.preventDefault(), u === "" || u === "top" && a.ownerDocument.getElementById("top") === null) scrollTo({
          top: 0
        });
        else {
          const f = a.ownerDocument.getElementById(decodeURIComponent(u));
          f && (f.scrollIntoView(), f.focus())
        }
        return
      }
      if (Y = !0, Gt(k), t(r), !l.replace_state) return;
      Y = !1
    }
    n.preventDefault(), await new Promise(p => {
      requestAnimationFrame(() => {
        setTimeout(p, 0)
      }), setTimeout(p, 100)
    }), await G({
      type: "link",
      url: r,
      keepfocus: l.keepfocus,
      noscroll: l.noscroll,
      replace_state: l.replace_state ?? r.href === location.href,
      event: n
    })
  }), P.addEventListener("submit", n => {
    if (n.defaultPrevented) return;
    const a = HTMLFormElement.prototype.cloneNode.call(n.target),
      r = n.submitter;
    if (((r == null ? void 0 : r.formTarget) || a.target) === "_blank" || ((r == null ? void 0 : r.formMethod) || a.method) !== "get") return;
    const s = new URL((r == null ? void 0 : r.hasAttribute("formaction")) && (r == null ? void 0 : r.formAction) || a.action);
    if (xt(s, A, !1)) return;
    const l = n.target,
      c = _t(l);
    if (c.reload) return;
    n.preventDefault(), n.stopPropagation();
    const d = new FormData(l, r);
    s.search = new URLSearchParams(d).toString(), G({
      type: "form",
      url: s,
      keepfocus: c.keepfocus,
      noscroll: c.noscroll,
      replace_state: c.replace_state ?? s.href === location.href,
      event: n
    })
  }), addEventListener("popstate", async n => {
    var a;
    if (!Nt) {
      if ((a = n.state) != null && a[F]) {
        const r = n.state[F];
        if (V = {}, r === k) return;
        const i = N[r],
          o = n.state[me] ?? {},
          s = new URL(n.state[Qe] ?? location.href),
          l = n.state[Q],
          c = _.url ? Tt(location) === Tt(_.url) : !1;
        if (l === L && (Re || c)) {
          o !== R.state && (R.state = o), t(s), N[k] = B(), i && scrollTo(i.x, i.y), k = r;
          return
        }
        const u = r - k;
        await G({
          type: "popstate",
          url: s,
          popped: {
            state: o,
            scroll: i,
            delta: u
          },
          accept: () => {
            k = r, L = l
          },
          block: () => {
            history.go(-u)
          },
          nav_token: V,
          event: n
        })
      } else if (!Y) {
        const r = new URL(location.href);
        t(r), E.hash && location.reload()
      }
    }
  }), addEventListener("hashchange", () => {
    Y && (Y = !1, history.replaceState({
      ...history.state,
      [F]: ++k,
      [Q]: L
    }, "", location.href))
  });
  for (const n of document.querySelectorAll("link")) on.has(n.rel) && (n.href = n.href);
  addEventListener("pageshow", n => {
    n.persisted && j.navigating.set(Z.current = null)
  });

  function t(n) {
    _.url = R.url = n, j.page.set(Qt(R)), j.page.notify()
  }
}
async function kn(t, {
  status: e = 200,
  error: n,
  node_ids: a,
  params: r,
  route: i,
  server_route: o,
  data: s,
  form: l
}) {
  Se = !0;
  const c = new URL(location.href);
  let d;
  ({
    params: r = {},
    route: i = {
      id: null
    }
  } = await Lt(c, !1) || {}), d = Ht.find(({
    id: p
  }) => p === i.id);
  let u, w = !0;
  try {
    const p = a.map(async (m, h) => {
        const g = s[h];
        return g != null && g.uses && (g.uses = En(g.uses)), Jt({
          loader: E.nodes[m],
          url: c,
          params: r,
          route: i,
          parent: async () => {
            const b = {};
            for (let x = 0; x < h; x += 1) Object.assign(b, (await p[x]).data);
            return b
          },
          server_data_node: Yt(g)
        })
      }),
      f = await Promise.all(p);
    if (d) {
      const m = d.layouts;
      for (let h = 0; h < m.length; h++) m[h] || f.splice(h, 0, void 0)
    }
    u = await St({
      url: c,
      params: r,
      branch: f,
      status: e,
      error: n,
      errors: d == null ? void 0 : d.errors,
      form: l,
      route: d ?? null
    })
  } catch (p) {
    if (p instanceof Vt) {
      await et(new URL(p.location, location.href));
      return
    }
    u = await zt({
      status: Ft(p),
      error: await rt(p, {
        url: c,
        params: r,
        route: i
      }),
      url: c,
      route: i
    }), t.textContent = "", w = !1
  } finally {}
  u.props.page && (u.props.page.state = {}), await Ue(u, t, w)
}

function En(t) {
  return {
    dependencies: new Set((t == null ? void 0 : t.dependencies) ?? []),
    params: new Set((t == null ? void 0 : t.params) ?? []),
    parent: !!(t != null && t.parent),
    route: !!(t != null && t.route),
    url: !!(t != null && t.url),
    search_params: new Set((t == null ? void 0 : t.search_params) ?? [])
  }
}
let Nt = !1;

function Sn(t, e = !0) {
  const n = document.querySelector("[autofocus]");
  if (n) n.focus();
  else {
    const a = Pe(t);
    if (a && document.getElementById(a)) {
      const {
        x: i,
        y: o
      } = B();
      setTimeout(() => {
        const s = history.state;
        Nt = !0, location.replace(new URL(`#${a}`, location.href)), history.replaceState(s, "", t), e && scrollTo(i, o), Nt = !1
      })
    } else {
      const i = document.body,
        o = i.getAttribute("tabindex");
      i.tabIndex = -1, i.focus({
        preventScroll: !0,
        focusVisible: !1
      }), o !== null ? i.setAttribute("tabindex", o) : i.removeAttribute("tabindex")
    }
    const r = getSelection();
    if (r && r.type !== "None") {
      const i = [];
      for (let o = 0; o < r.rangeCount; o += 1) i.push(r.getRangeAt(o));
      setTimeout(() => {
        if (r.rangeCount === i.length) {
          for (let o = 0; o < r.rangeCount; o += 1) {
            const s = i[o],
              l = r.getRangeAt(o);
            if (s.commonAncestorContainer !== l.commonAncestorContainer || s.startContainer !== l.startContainer || s.endContainer !== l.endContainer || s.startOffset !== l.startOffset || s.endOffset !== l.endOffset) return
          }
          r.removeAllRanges()
        }
      })
    }
  }
}

function Xt(t, e, n, a, r = null) {
  var c, d;
  let i, o;
  const s = new Promise((u, w) => {
    i = u, o = w
  });
  return s.catch(C), {
    navigation: {
      from: {
        params: t.params,
        route: {
          id: ((c = t.route) == null ? void 0 : c.id) ?? null
        },
        url: t.url,
        scroll: B()
      },
      to: n && {
        params: (e == null ? void 0 : e.params) ?? null,
        route: {
          id: ((d = e == null ? void 0 : e.route) == null ? void 0 : d.id) ?? null
        },
        url: n,
        scroll: r
      },
      willUnload: !e,
      type: a,
      complete: s
    },
    fulfil: i,
    reject: o
  }
}

function Qt(t) {
  return {
    data: t.data,
    error: t.error,
    form: t.form,
    params: t.params,
    route: t.route,
    state: t.state,
    status: t.status,
    url: t.url
  }
}

function Rn(t) {
  const e = new URL(t);
  return e.hash = decodeURIComponent(t.hash), e
}

function Pe(t) {
  let e;
  if (E.hash) {
    const [, , n] = t.hash.split("#", 3);
    e = n ?? ""
  } else e = t.hash.slice(1);
  return decodeURIComponent(e)
}
export {
  On as a, An as l, R as p, j as s
};