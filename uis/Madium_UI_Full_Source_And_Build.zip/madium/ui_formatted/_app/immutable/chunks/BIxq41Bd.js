import {
  c as D,
  l as t
} from "./QxO3pMDe.js";
import {
  H as d,
  D as l,
  h as c,
  F as u,
  b as h,
  S as m,
  c as p,
  f as w,
  g as _,
  C as R
} from "./CTCvwghO.js";
import {
  a as E,
  e as H,
  d as b,
  R as y,
  i as U,
  j as T,
  t as x,
  k as M
} from "./CTCvwghO.js";
const I = 120 * 1e3;
class f {
  constructor(n) {
    this._defaults = n, this._worker = null, this._client = null, this._idleCheckInterval = window.setInterval(() => this._checkIfIdle(), 30 * 1e3), this._lastUsedTime = 0, this._configChangeListener = this._defaults.onDidChange(() => this._stopWorker())
  }
  _stopWorker() {
    this._worker && (this._worker.dispose(), this._worker = null), this._client = null
  }
  dispose() {
    clearInterval(this._idleCheckInterval), this._configChangeListener.dispose(), this._stopWorker()
  }
  _checkIfIdle() {
    if (!this._worker) return;
    Date.now() - this._lastUsedTime > I && this._stopWorker()
  }
  _getClient() {
    return this._lastUsedTime = Date.now(), this._client || (this._worker = D({
      moduleId: "vs/language/html/htmlWorker",
      createWorker: () => new Worker(new URL("" + new URL("../workers/html.worker-DtiGdgqp.js", import.meta.url).href, import.meta.url), {
        type: "module"
      }),
      createData: {
        languageSettings: this._defaults.options,
        languageId: this._defaults.languageId
      },
      label: this._defaults.languageId
    }), this._client = this._worker.getProxy()), this._client
  }
  getLanguageServiceWorker(...n) {
    let e;
    return this._getClient().then(r => {
      e = r
    }).then(r => {
      if (this._worker) return this._worker.withSyncedResources(n)
    }).then(r => e)
  }
}
class v extends R {
  constructor(n) {
    super(n, [".", ":", "<", '"', "=", "/"])
  }
}

function C(i) {
  const n = new f(i),
    e = (...o) => n.getLanguageServiceWorker(...o);
  let r = i.languageId;
  t.registerCompletionItemProvider(r, new v(e)), t.registerHoverProvider(r, new d(e)), t.registerDocumentHighlightProvider(r, new l(e)), t.registerLinkProvider(r, new c(e)), t.registerFoldingRangeProvider(r, new u(e)), t.registerDocumentSymbolProvider(r, new h(e)), t.registerSelectionRangeProvider(r, new m(e)), t.registerRenameProvider(r, new p(e)), r === "html" && (t.registerDocumentFormattingEditProvider(r, new w(e)), t.registerDocumentRangeFormattingEditProvider(r, new _(e)))
}

function L(i) {
  const n = [],
    e = [],
    r = new f(i);
  n.push(r);
  const o = (...s) => r.getLanguageServiceWorker(...s);

  function P() {
    const {
      languageId: s,
      modeConfiguration: a
    } = i;
    k(e), a.completionItems && e.push(t.registerCompletionItemProvider(s, new v(o))), a.hovers && e.push(t.registerHoverProvider(s, new d(o))), a.documentHighlights && e.push(t.registerDocumentHighlightProvider(s, new l(o))), a.links && e.push(t.registerLinkProvider(s, new c(o))), a.documentSymbols && e.push(t.registerDocumentSymbolProvider(s, new h(o))), a.rename && e.push(t.registerRenameProvider(s, new p(o))), a.foldingRanges && e.push(t.registerFoldingRangeProvider(s, new u(o))), a.selectionRanges && e.push(t.registerSelectionRangeProvider(s, new m(o))), a.documentFormattingEdits && e.push(t.registerDocumentFormattingEditProvider(s, new w(o))), a.documentRangeFormattingEdits && e.push(t.registerDocumentRangeFormattingEditProvider(s, new _(o)))
  }
  return P(), n.push(g(e)), g(n)
}

function g(i) {
  return {
    dispose: () => k(i)
  }
}

function k(i) {
  for (; i.length;) i.pop().dispose()
}
export {
  R as CompletionAdapter, E as DefinitionAdapter, H as DiagnosticsAdapter, b as DocumentColorAdapter, w as DocumentFormattingEditProvider, l as DocumentHighlightAdapter, c as DocumentLinkAdapter, _ as DocumentRangeFormattingEditProvider, h as DocumentSymbolAdapter, u as FoldingRangeAdapter, d as HoverAdapter, y as ReferenceAdapter, p as RenameAdapter, m as SelectionRangeAdapter, f as WorkerManager, U as fromPosition, T as fromRange, L as setupMode, C as setupMode1, x as toRange, M as toTextEdit
};