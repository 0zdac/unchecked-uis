import {
  c as P,
  l as _,
  e as B
} from "./QxO3pMDe.js";
import {
  f as y,
  g as J,
  C as Q,
  H as Y,
  b as G,
  d as X,
  F as Z,
  S as $,
  e as K
} from "./CTCvwghO.js";
import {
  a as Ae,
  D as Oe,
  h as Ie,
  R as Le,
  c as Ne,
  i as Ee,
  j as Ue,
  t as De,
  k as Be
} from "./CTCvwghO.js";
const x = 120 * 1e3;
class C {
  constructor(i) {
    this._defaults = i, this._worker = null, this._client = null, this._idleCheckInterval = window.setInterval(() => this._checkIfIdle(), 30 * 1e3), this._lastUsedTime = 0, this._configChangeListener = this._defaults.onDidChange(() => this._stopWorker())
  }
  _stopWorker() {
    this._worker && (this._worker.dispose(), this._worker = null), this._client = null
  }
  dispose() {
    clearInterval(this._idleCheckInterval), this._configChangeListener.dispose(), this._stopWorker()
  }
  _checkIfIdle() {
    if (!this._worker) return;
    Date.now() - this._lastUsedTime > x && this._stopWorker()
  }
  _getClient() {
    return this._lastUsedTime = Date.now(), this._client || (this._worker = P({
      moduleId: "vs/language/json/jsonWorker",
      createWorker: () => new Worker(new URL("" + new URL("../workers/json.worker-leyajbqV.js", import.meta.url).href, import.meta.url), {
        type: "module"
      }),
      label: this._defaults.languageId,
      createData: {
        languageSettings: this._defaults.diagnosticsOptions,
        languageId: this._defaults.languageId,
        enableSchemaRequest: this._defaults.diagnosticsOptions.enableSchemaRequest
      }
    }), this._client = this._worker.getProxy()), this._client
  }
  getLanguageServiceWorker(...i) {
    let t;
    return this._getClient().then(n => {
      t = n
    }).then(n => {
      if (this._worker) return this._worker.withSyncedResources(i)
    }).then(n => t)
  }
}

function ee(e, i = !1) {
  const t = e.length;
  let n = 0,
    u = "",
    p = 0,
    l = 16,
    o = 0,
    g = 0,
    w = 0,
    v = 0,
    c = 0;

  function O(s, m) {
    let a = 0,
      r = 0;
    for (; a < s;) {
      let f = e.charCodeAt(n);
      if (f >= 48 && f <= 57) r = r * 16 + f - 48;
      else if (f >= 65 && f <= 70) r = r * 16 + f - 65 + 10;
      else if (f >= 97 && f <= 102) r = r * 16 + f - 97 + 10;
      else break;
      n++, a++
    }
    return a < s && (r = -1), r
  }

  function U(s) {
    n = s, u = "", p = 0, l = 16, c = 0
  }

  function N() {
    let s = n;
    if (e.charCodeAt(n) === 48) n++;
    else
      for (n++; n < e.length && T(e.charCodeAt(n));) n++;
    if (n < e.length && e.charCodeAt(n) === 46)
      if (n++, n < e.length && T(e.charCodeAt(n)))
        for (n++; n < e.length && T(e.charCodeAt(n));) n++;
      else return c = 3, e.substring(s, n);
    let m = n;
    if (n < e.length && (e.charCodeAt(n) === 69 || e.charCodeAt(n) === 101))
      if (n++, (n < e.length && e.charCodeAt(n) === 43 || e.charCodeAt(n) === 45) && n++, n < e.length && T(e.charCodeAt(n))) {
        for (n++; n < e.length && T(e.charCodeAt(n));) n++;
        m = n
      } else c = 3;
    return e.substring(s, m)
  }

  function H() {
    let s = "",
      m = n;
    for (;;) {
      if (n >= t) {
        s += e.substring(m, n), c = 2;
        break
      }
      const a = e.charCodeAt(n);
      if (a === 34) {
        s += e.substring(m, n), n++;
        break
      }
      if (a === 92) {
        if (s += e.substring(m, n), n++, n >= t) {
          c = 2;
          break
        }
        switch (e.charCodeAt(n++)) {
          case 34:
            s += '"';
            break;
          case 92:
            s += "\\";
            break;
          case 47:
            s += "/";
            break;
          case 98:
            s += "\b";
            break;
          case 102:
            s += "\f";
            break;
          case 110:
            s += `
`;
            break;
          case 114:
            s += "\r";
            break;
          case 116:
            s += "	";
            break;
          case 117:
            const f = O(4);
            f >= 0 ? s += String.fromCharCode(f) : c = 4;
            break;
          default:
            c = 5
        }
        m = n;
        continue
      }
      if (a >= 0 && a <= 31)
        if (I(a)) {
          s += e.substring(m, n), c = 2;
          break
        } else c = 6;
      n++
    }
    return s
  }

  function D() {
    if (u = "", c = 0, p = n, g = o, v = w, n >= t) return p = t, l = 17;
    let s = e.charCodeAt(n);
    if (E(s)) {
      do n++, u += String.fromCharCode(s), s = e.charCodeAt(n); while (E(s));
      return l = 15
    }
    if (I(s)) return n++, u += String.fromCharCode(s), s === 13 && e.charCodeAt(n) === 10 && (n++, u += `
`), o++, w = n, l = 14;
    switch (s) {
      case 123:
        return n++, l = 1;
      case 125:
        return n++, l = 2;
      case 91:
        return n++, l = 3;
      case 93:
        return n++, l = 4;
      case 58:
        return n++, l = 6;
      case 44:
        return n++, l = 5;
      case 34:
        return n++, u = H(), l = 10;
      case 47:
        const m = n - 1;
        if (e.charCodeAt(n + 1) === 47) {
          for (n += 2; n < t && !I(e.charCodeAt(n));) n++;
          return u = e.substring(m, n), l = 12
        }
        if (e.charCodeAt(n + 1) === 42) {
          n += 2;
          const a = t - 1;
          let r = !1;
          for (; n < a;) {
            const f = e.charCodeAt(n);
            if (f === 42 && e.charCodeAt(n + 1) === 47) {
              n += 2, r = !0;
              break
            }
            n++, I(f) && (f === 13 && e.charCodeAt(n) === 10 && n++, o++, w = n)
          }
          return r || (n++, c = 1), u = e.substring(m, n), l = 13
        }
        return u += String.fromCharCode(s), n++, l = 16;
      case 45:
        if (u += String.fromCharCode(s), n++, n === t || !T(e.charCodeAt(n))) return l = 16;
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
        return u += N(), l = 11;
      default:
        for (; n < t && d(s);) n++, s = e.charCodeAt(n);
        if (p !== n) {
          switch (u = e.substring(p, n), u) {
            case "true":
              return l = 8;
            case "false":
              return l = 9;
            case "null":
              return l = 7
          }
          return l = 16
        }
        return u += String.fromCharCode(s), n++, l = 16
    }
  }

  function d(s) {
    if (E(s) || I(s)) return !1;
    switch (s) {
      case 125:
      case 93:
      case 123:
      case 91:
      case 34:
      case 58:
      case 44:
      case 47:
        return !1
    }
    return !0
  }

  function z() {
    let s;
    do s = D(); while (s >= 12 && s <= 15);
    return s
  }
  return {
    setPosition: U,
    getPosition: () => n,
    scan: i ? z : D,
    getToken: () => l,
    getTokenValue: () => u,
    getTokenOffset: () => p,
    getTokenLength: () => n - p,
    getTokenStartLine: () => g,
    getTokenStartCharacter: () => p - v,
    getTokenError: () => c
  }
}

function E(e) {
  return e === 32 || e === 9
}

function I(e) {
  return e === 10 || e === 13
}

function T(e) {
  return e >= 48 && e <= 57
}
var R;
(function(e) {
  e[e.lineFeed = 10] = "lineFeed", e[e.carriageReturn = 13] = "carriageReturn", e[e.space = 32] = "space", e[e._0 = 48] = "_0", e[e._1 = 49] = "_1", e[e._2 = 50] = "_2", e[e._3 = 51] = "_3", e[e._4 = 52] = "_4", e[e._5 = 53] = "_5", e[e._6 = 54] = "_6", e[e._7 = 55] = "_7", e[e._8 = 56] = "_8", e[e._9 = 57] = "_9", e[e.a = 97] = "a", e[e.b = 98] = "b", e[e.c = 99] = "c", e[e.d = 100] = "d", e[e.e = 101] = "e", e[e.f = 102] = "f", e[e.g = 103] = "g", e[e.h = 104] = "h", e[e.i = 105] = "i", e[e.j = 106] = "j", e[e.k = 107] = "k", e[e.l = 108] = "l", e[e.m = 109] = "m", e[e.n = 110] = "n", e[e.o = 111] = "o", e[e.p = 112] = "p", e[e.q = 113] = "q", e[e.r = 114] = "r", e[e.s = 115] = "s", e[e.t = 116] = "t", e[e.u = 117] = "u", e[e.v = 118] = "v", e[e.w = 119] = "w", e[e.x = 120] = "x", e[e.y = 121] = "y", e[e.z = 122] = "z", e[e.A = 65] = "A", e[e.B = 66] = "B", e[e.C = 67] = "C", e[e.D = 68] = "D", e[e.E = 69] = "E", e[e.F = 70] = "F", e[e.G = 71] = "G", e[e.H = 72] = "H", e[e.I = 73] = "I", e[e.J = 74] = "J", e[e.K = 75] = "K", e[e.L = 76] = "L", e[e.M = 77] = "M", e[e.N = 78] = "N", e[e.O = 79] = "O", e[e.P = 80] = "P", e[e.Q = 81] = "Q", e[e.R = 82] = "R", e[e.S = 83] = "S", e[e.T = 84] = "T", e[e.U = 85] = "U", e[e.V = 86] = "V", e[e.W = 87] = "W", e[e.X = 88] = "X", e[e.Y = 89] = "Y", e[e.Z = 90] = "Z", e[e.asterisk = 42] = "asterisk", e[e.backslash = 92] = "backslash", e[e.closeBrace = 125] = "closeBrace", e[e.closeBracket = 93] = "closeBracket", e[e.colon = 58] = "colon", e[e.comma = 44] = "comma", e[e.dot = 46] = "dot", e[e.doubleQuote = 34] = "doubleQuote", e[e.minus = 45] = "minus", e[e.openBrace = 123] = "openBrace", e[e.openBracket = 91] = "openBracket", e[e.plus = 43] = "plus", e[e.slash = 47] = "slash", e[e.formFeed = 12] = "formFeed", e[e.tab = 9] = "tab"
})(R || (R = {}));
new Array(20).fill(0).map((e, i) => " ".repeat(i));
const A = 200;
new Array(A).fill(0).map((e, i) => `
` + " ".repeat(i)), new Array(A).fill(0).map((e, i) => "\r" + " ".repeat(i)), new Array(A).fill(0).map((e, i) => `\r
` + " ".repeat(i)), new Array(A).fill(0).map((e, i) => `
` + "	".repeat(i)), new Array(A).fill(0).map((e, i) => "\r" + "	".repeat(i)), new Array(A).fill(0).map((e, i) => `\r
` + "	".repeat(i));
var F;
(function(e) {
  e.DEFAULT = {
    allowTrailingComma: !1
  }
})(F || (F = {}));
const ne = ee;
var W;
(function(e) {
  e[e.None = 0] = "None", e[e.UnexpectedEndOfComment = 1] = "UnexpectedEndOfComment", e[e.UnexpectedEndOfString = 2] = "UnexpectedEndOfString", e[e.UnexpectedEndOfNumber = 3] = "UnexpectedEndOfNumber", e[e.InvalidUnicode = 4] = "InvalidUnicode", e[e.InvalidEscapeCharacter = 5] = "InvalidEscapeCharacter", e[e.InvalidCharacter = 6] = "InvalidCharacter"
})(W || (W = {}));
var h;
(function(e) {
  e[e.OpenBraceToken = 1] = "OpenBraceToken", e[e.CloseBraceToken = 2] = "CloseBraceToken", e[e.OpenBracketToken = 3] = "OpenBracketToken", e[e.CloseBracketToken = 4] = "CloseBracketToken", e[e.CommaToken = 5] = "CommaToken", e[e.ColonToken = 6] = "ColonToken", e[e.NullKeyword = 7] = "NullKeyword", e[e.TrueKeyword = 8] = "TrueKeyword", e[e.FalseKeyword = 9] = "FalseKeyword", e[e.StringLiteral = 10] = "StringLiteral", e[e.NumericLiteral = 11] = "NumericLiteral", e[e.LineCommentTrivia = 12] = "LineCommentTrivia", e[e.BlockCommentTrivia = 13] = "BlockCommentTrivia", e[e.LineBreakTrivia = 14] = "LineBreakTrivia", e[e.Trivia = 15] = "Trivia", e[e.Unknown = 16] = "Unknown", e[e.EOF = 17] = "EOF"
})(h || (h = {}));
var j;
(function(e) {
  e[e.InvalidSymbol = 1] = "InvalidSymbol", e[e.InvalidNumberFormat = 2] = "InvalidNumberFormat", e[e.PropertyNameExpected = 3] = "PropertyNameExpected", e[e.ValueExpected = 4] = "ValueExpected", e[e.ColonExpected = 5] = "ColonExpected", e[e.CommaExpected = 6] = "CommaExpected", e[e.CloseBraceExpected = 7] = "CloseBraceExpected", e[e.CloseBracketExpected = 8] = "CloseBracketExpected", e[e.EndOfFileExpected = 9] = "EndOfFileExpected", e[e.InvalidCommentToken = 10] = "InvalidCommentToken", e[e.UnexpectedEndOfComment = 11] = "UnexpectedEndOfComment", e[e.UnexpectedEndOfString = 12] = "UnexpectedEndOfString", e[e.UnexpectedEndOfNumber = 13] = "UnexpectedEndOfNumber", e[e.InvalidUnicode = 14] = "InvalidUnicode", e[e.InvalidEscapeCharacter = 15] = "InvalidEscapeCharacter", e[e.InvalidCharacter = 16] = "InvalidCharacter"
})(j || (j = {}));

function ie(e) {
  return {
    getInitialState: () => new L(null, null, !1, null),
    tokenize: (i, t) => me(e, i, t)
  }
}
const M = "delimiter.bracket.json",
  V = "delimiter.array.json",
  te = "delimiter.colon.json",
  se = "delimiter.comma.json",
  le = "keyword.json",
  ue = "keyword.json",
  oe = "string.value.json",
  ce = "number.json",
  fe = "string.key.json",
  pe = "comment.block.json",
  ge = "comment.line.json";
class b {
  constructor(i, t) {
    this.parent = i, this.type = t
  }
  static pop(i) {
    return i ? i.parent : null
  }
  static push(i, t) {
    return new b(i, t)
  }
  static equals(i, t) {
    if (!i && !t) return !0;
    if (!i || !t) return !1;
    for (; i && t;) {
      if (i === t) return !0;
      if (i.type !== t.type) return !1;
      i = i.parent, t = t.parent
    }
    return !0
  }
}
class L {
  constructor(i, t, n, u) {
    this._state = i, this.scanError = t, this.lastWasColon = n, this.parents = u
  }
  clone() {
    return new L(this._state, this.scanError, this.lastWasColon, this.parents)
  }
  equals(i) {
    return i === this ? !0 : !i || !(i instanceof L) ? !1 : this.scanError === i.scanError && this.lastWasColon === i.lastWasColon && b.equals(this.parents, i.parents)
  }
  getStateData() {
    return this._state
  }
  setStateData(i) {
    this._state = i
  }
}

function me(e, i, t, n = 0) {
  let u = 0,
    p = !1;
  switch (t.scanError) {
    case 2:
      i = '"' + i, u = 1;
      break;
    case 1:
      i = "/*" + i, u = 2;
      break
  }
  const l = ne(i);
  let o = t.lastWasColon,
    g = t.parents;
  const w = {
    tokens: [],
    endState: t.clone()
  };
  for (;;) {
    let v = n + l.getPosition(),
      c = "";
    const O = l.scan();
    if (O === 17) break;
    if (v === n + l.getPosition()) throw new Error("Scanner did not advance, next 3 characters are: " + i.substr(l.getPosition(), 3));
    switch (p && (v -= u), p = u > 0, O) {
      case 1:
        g = b.push(g, 0), c = M, o = !1;
        break;
      case 2:
        g = b.pop(g), c = M, o = !1;
        break;
      case 3:
        g = b.push(g, 1), c = V, o = !1;
        break;
      case 4:
        g = b.pop(g), c = V, o = !1;
        break;
      case 6:
        c = te, o = !0;
        break;
      case 5:
        c = se, o = !1;
        break;
      case 8:
      case 9:
        c = le, o = !1;
        break;
      case 7:
        c = ue, o = !1;
        break;
      case 10:
        const N = (g ? g.type : 0) === 1;
        c = o || N ? oe : fe, o = !1;
        break;
      case 11:
        c = ce, o = !1;
        break
    }
    switch (O) {
      case 12:
        c = ge;
        break;
      case 13:
        c = pe;
        break
    }
    w.endState = new L(t.getStateData(), l.getTokenError(), o, g), w.tokens.push({
      startIndex: v,
      scopes: c
    })
  }
  return w
}
let k;

function we() {
  return new Promise((e, i) => {
    if (!k) return i("JSON not registered!");
    e(k)
  })
}
class re extends K {
  constructor(i, t, n) {
    super(i, t, n.onDidChange), this._disposables.push(B.onWillDisposeModel(u => {
      this._resetSchema(u.uri)
    })), this._disposables.push(B.onDidChangeModelLanguage(u => {
      this._resetSchema(u.model.uri)
    }))
  }
  _resetSchema(i) {
    this._worker().then(t => {
      t.resetSchema(i.toString())
    })
  }
}

function be(e) {
  const i = [],
    t = [],
    n = new C(e);
  i.push(n), k = (...l) => n.getLanguageServiceWorker(...l);

  function u() {
    const {
      languageId: l,
      modeConfiguration: o
    } = e;
    q(t), o.documentFormattingEdits && t.push(_.registerDocumentFormattingEditProvider(l, new y(k))), o.documentRangeFormattingEdits && t.push(_.registerDocumentRangeFormattingEditProvider(l, new J(k))), o.completionItems && t.push(_.registerCompletionItemProvider(l, new Q(k, [" ", ":", '"']))), o.hovers && t.push(_.registerHoverProvider(l, new Y(k))), o.documentSymbols && t.push(_.registerDocumentSymbolProvider(l, new G(k))), o.tokens && t.push(_.setTokensProvider(l, ie(!0))), o.colors && t.push(_.registerColorProvider(l, new X(k))), o.foldingRanges && t.push(_.registerFoldingRangeProvider(l, new Z(k))), o.diagnostics && t.push(new re(l, k, e)), o.selectionRanges && t.push(_.registerSelectionRangeProvider(l, new $(k)))
  }
  u(), i.push(_.setLanguageConfiguration(e.languageId, ke));
  let p = e.modeConfiguration;
  return e.onDidChange(l => {
    l.modeConfiguration !== p && (p = l.modeConfiguration, u())
  }), i.push(S(t)), S(i)
}

function S(e) {
  return {
    dispose: () => q(e)
  }
}

function q(e) {
  for (; e.length;) e.pop().dispose()
}
const ke = {
  wordPattern: /(-?\d*\.\d\w*)|([^\[\{\]\}\:\"\,\s]+)/g,
  comments: {
    lineComment: "//",
    blockComment: ["/*", "*/"]
  },
  brackets: [
    ["{", "}"],
    ["[", "]"]
  ],
  autoClosingPairs: [{
    open: "{",
    close: "}",
    notIn: ["string"]
  }, {
    open: "[",
    close: "]",
    notIn: ["string"]
  }, {
    open: '"',
    close: '"',
    notIn: ["string"]
  }]
};
export {
  Q as CompletionAdapter, Ae as DefinitionAdapter, K as DiagnosticsAdapter, X as DocumentColorAdapter, y as DocumentFormattingEditProvider, Oe as DocumentHighlightAdapter, Ie as DocumentLinkAdapter, J as DocumentRangeFormattingEditProvider, G as DocumentSymbolAdapter, Z as FoldingRangeAdapter, Y as HoverAdapter, Le as ReferenceAdapter, Ne as RenameAdapter, $ as SelectionRangeAdapter, C as WorkerManager, Ee as fromPosition, Ue as fromRange, we as getWorker, be as setupMode, De as toRange, Be as toTextEdit
};