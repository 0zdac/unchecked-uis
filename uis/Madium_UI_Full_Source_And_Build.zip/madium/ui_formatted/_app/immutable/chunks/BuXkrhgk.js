import {
  l as e
} from "./QxO3pMDe.js";
const t = ["area", "base", "br", "col", "embed", "hr", "img", "input", "keygen", "link", "menuitem", "meta", "param", "source", "track", "wbr"],
  i = {
    wordPattern: /(-?\d*\.\d\w*)|([^\`\~\!\@\$\^\&\*\(\)\=\+\[\{\]\}\\\|\;\:\'\"\,\.\<\>\/\s]+)/g,
    comments: {
      blockComment: ["<!--", "-->"]
    },
    brackets: [
      ["<!--", "-->"],
      ["<", ">"],
      ["{", "}"],
      ["(", ")"]
    ],
    autoClosingPairs: [{
      open: "{",
      close: "}"
    }, {
      open: "[",
      close: "]"
    }, {
      open: "(",
      close: ")"
    }, {
      open: '"',
      close: '"'
    }, {
      open: "'",
      close: "'"
    }],
    surroundingPairs: [{
      open: '"',
      close: '"'
    }, {
      open: "'",
      close: "'"
    }, {
      open: "{",
      close: "}"
    }, {
      open: "[",
      close: "]"
    }, {
      open: "(",
      close: ")"
    }, {
      open: "<",
      close: ">"
    }],
    onEnterRules: [{
      beforeText: new RegExp(`<(?!(?:${t.join("|")}))([_:\\w][_:\\w-.\\d]*)([^/>]*(?!/)>)[^<]*$`, "i"),
      afterText: /^<\/([_:\w][_:\w-.\d]*)\s*>$/i,
      action: {
        indentAction: e.IndentAction.IndentOutdent
      }
    }, {
      beforeText: new RegExp(`<(?!(?:${t.join("|")}))(\\w[\\w\\d]*)([^/>]*(?!/)>)[^<]*$`, "i"),
      action: {
        indentAction: e.IndentAction.Indent
      }
    }],
    folding: {
      markers: {
        start: new RegExp("^\\s*<!--\\s*#region\\b.*-->"),
        end: new RegExp("^\\s*<!--\\s*#endregion\\b.*-->")
      }
    }
  },
  r = {
    defaultToken: "",
    tokenPostfix: ".html",
    ignoreCase: !0,
    tokenizer: {
      root: [
        [/<!DOCTYPE/, "metatag", "@doctype"],
        [/<!--/, "comment", "@comment"],
        [/(<)((?:[\w\-]+:)?[\w\-]+)(\s*)(\/>)/, ["delimiter", "tag", "", "delimiter"]],
        [/(<)(script)/, ["delimiter", {
          token: "tag",
          next: "@script"
        }]],
        [/(<)(style)/, ["delimiter", {
          token: "tag",
          next: "@style"
        }]],
        [/(<)((?:[\w\-]+:)?[\w\-]+)/, ["delimiter", {
          token: "tag",
          next: "@otherTag"
        }]],
        [/(<\/)((?:[\w\-]+:)?[\w\-]+)/, ["delimiter", {
          token: "tag",
          next: "@otherTag"
        }]],
        [/</, "delimiter"],
        [/[^<]+/]
      ],
      doctype: [
        [/[^>]+/, "metatag.content"],
        [/>/, "metatag", "@pop"]
      ],
      comment: [
        [/-->/, "comment", "@pop"],
        [/[^-]+/, "comment.content"],
        [/./, "comment.content"]
      ],
      otherTag: [
        [/\/?>/, "delimiter", "@pop"],
        [/"([^"]*)"/, "attribute.value"],
        [/'([^']*)'/, "attribute.value"],
        [/[\w\-]+/, "attribute.name"],
        [/=/, "delimiter"],
        [/[ \t\r\n]+/]
      ],
      script: [
        [/type/, "attribute.name", "@scriptAfterType"],
        [/"([^"]*)"/, "attribute.value"],
        [/'([^']*)'/, "attribute.value"],
        [/[\w\-]+/, "attribute.name"],
        [/=/, "delimiter"],
        [/>/, {
          token: "delimiter",
          next: "@scriptEmbedded",
          nextEmbedded: "text/javascript"
        }],
        [/[ \t\r\n]+/],
        [/(<\/)(script\s*)(>)/, ["delimiter", "tag", {
          token: "delimiter",
          next: "@pop"
        }]]
      ],
      scriptAfterType: [
        [/=/, "delimiter", "@scriptAfterTypeEquals"],
        [/>/, {
          token: "delimiter",
          next: "@scriptEmbedded",
          nextEmbedded: "text/javascript"
        }],
        [/[ \t\r\n]+/],
        [/<\/script\s*>/, {
          token: "@rematch",
          next: "@pop"
        }]
      ],
      scriptAfterTypeEquals: [
        [/"module"/, {
          token: "attribute.value",
          switchTo: "@scriptWithCustomType.text/javascript"
        }],
        [/'module'/, {
          token: "attribute.value",
          switchTo: "@scriptWithCustomType.text/javascript"
        }],
        [/"([^"]*)"/, {
          token: "attribute.value",
          switchTo: "@scriptWithCustomType.$1"
        }],
        [/'([^']*)'/, {
          token: "attribute.value",
          switchTo: "@scriptWithCustomType.$1"
        }],
        [/>/, {
          token: "delimiter",
          next: "@scriptEmbedded",
          nextEmbedded: "text/javascript"
        }],
        [/[ \t\r\n]+/],
        [/<\/script\s*>/, {
          token: "@rematch",
          next: "@pop"
        }]
      ],
      scriptWithCustomType: [
        [/>/, {
          token: "delimiter",
          next: "@scriptEmbedded.$S2",
          nextEmbedded: "$S2"
        }],
        [/"([^"]*)"/, "attribute.value"],
        [/'([^']*)'/, "attribute.value"],
        [/[\w\-]+/, "attribute.name"],
        [/=/, "delimiter"],
        [/[ \t\r\n]+/],
        [/<\/script\s*>/, {
          token: "@rematch",
          next: "@pop"
        }]
      ],
      scriptEmbedded: [
        [/<\/script/, {
          token: "@rematch",
          next: "@pop",
          nextEmbedded: "@pop"
        }],
        [/[^<]+/, ""]
      ],
      style: [
        [/type/, "attribute.name", "@styleAfterType"],
        [/"([^"]*)"/, "attribute.value"],
        [/'([^']*)'/, "attribute.value"],
        [/[\w\-]+/, "attribute.name"],
        [/=/, "delimiter"],
        [/>/, {
          token: "delimiter",
          next: "@styleEmbedded",
          nextEmbedded: "text/css"
        }],
        [/[ \t\r\n]+/],
        [/(<\/)(style\s*)(>)/, ["delimiter", "tag", {
          token: "delimiter",
          next: "@pop"
        }]]
      ],
      styleAfterType: [
        [/=/, "delimiter", "@styleAfterTypeEquals"],
        [/>/, {
          token: "delimiter",
          next: "@styleEmbedded",
          nextEmbedded: "text/css"
        }],
        [/[ \t\r\n]+/],
        [/<\/style\s*>/, {
          token: "@rematch",
          next: "@pop"
        }]
      ],
      styleAfterTypeEquals: [
        [/"([^"]*)"/, {
          token: "attribute.value",
          switchTo: "@styleWithCustomType.$1"
        }],
        [/'([^']*)'/, {
          token: "attribute.value",
          switchTo: "@styleWithCustomType.$1"
        }],
        [/>/, {
          token: "delimiter",
          next: "@styleEmbedded",
          nextEmbedded: "text/css"
        }],
        [/[ \t\r\n]+/],
        [/<\/style\s*>/, {
          token: "@rematch",
          next: "@pop"
        }]
      ],
      styleWithCustomType: [
        [/>/, {
          token: "delimiter",
          next: "@styleEmbedded.$S2",
          nextEmbedded: "$S2"
        }],
        [/"([^"]*)"/, "attribute.value"],
        [/'([^']*)'/, "attribute.value"],
        [/[\w\-]+/, "attribute.name"],
        [/=/, "delimiter"],
        [/[ \t\r\n]+/],
        [/<\/style\s*>/, {
          token: "@rematch",
          next: "@pop"
        }]
      ],
      styleEmbedded: [
        [/<\/style/, {
          token: "@rematch",
          next: "@pop",
          nextEmbedded: "@pop"
        }],
        [/[^<]+/, ""]
      ]
    }
  };
export {
  i as conf, r as language
};