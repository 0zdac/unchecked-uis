import {
  R as Ge,
  l as x,
  e as w,
  U as Je,
  M as R
} from "./QxO3pMDe.js";
var T;
(function(e) {
  function n(i) {
    return typeof i == "string"
  }
  e.is = n
})(T || (T = {}));
var O;
(function(e) {
  function n(i) {
    return typeof i == "string"
  }
  e.is = n
})(O || (O = {}));
var K;
(function(e) {
  e.MIN_VALUE = -2147483648, e.MAX_VALUE = 2147483647;

  function n(i) {
    return typeof i == "number" && e.MIN_VALUE <= i && i <= e.MAX_VALUE
  }
  e.is = n
})(K || (K = {}));
var j;
(function(e) {
  e.MIN_VALUE = 0, e.MAX_VALUE = 2147483647;

  function n(i) {
    return typeof i == "number" && e.MIN_VALUE <= i && i <= e.MAX_VALUE
  }
  e.is = n
})(j || (j = {}));
var _;
(function(e) {
  function n(r, t) {
    return r === Number.MAX_VALUE && (r = j.MAX_VALUE), t === Number.MAX_VALUE && (t = j.MAX_VALUE), {
      line: r,
      character: t
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.objectLiteral(t) && o.uinteger(t.line) && o.uinteger(t.character)
  }
  e.is = i
})(_ || (_ = {}));
var h;
(function(e) {
  function n(r, t, a, u) {
    if (o.uinteger(r) && o.uinteger(t) && o.uinteger(a) && o.uinteger(u)) return {
      start: _.create(r, t),
      end: _.create(a, u)
    };
    if (_.is(r) && _.is(t)) return {
      start: r,
      end: t
    };
    throw new Error(`Range#create called with invalid arguments[${r}, ${t}, ${a}, ${u}]`)
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.objectLiteral(t) && _.is(t.start) && _.is(t.end)
  }
  e.is = i
})(h || (h = {}));
var N;
(function(e) {
  function n(r, t) {
    return {
      uri: r,
      range: t
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.objectLiteral(t) && h.is(t.range) && (o.string(t.uri) || o.undefined(t.uri))
  }
  e.is = i
})(N || (N = {}));
var ee;
(function(e) {
  function n(r, t, a, u) {
    return {
      targetUri: r,
      targetRange: t,
      targetSelectionRange: a,
      originSelectionRange: u
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.objectLiteral(t) && h.is(t.targetRange) && o.string(t.targetUri) && h.is(t.targetSelectionRange) && (h.is(t.originSelectionRange) || o.undefined(t.originSelectionRange))
  }
  e.is = i
})(ee || (ee = {}));
var S;
(function(e) {
  function n(r, t, a, u) {
    return {
      red: r,
      green: t,
      blue: a,
      alpha: u
    }
  }
  e.create = n;

  function i(r) {
    const t = r;
    return o.objectLiteral(t) && o.numberRange(t.red, 0, 1) && o.numberRange(t.green, 0, 1) && o.numberRange(t.blue, 0, 1) && o.numberRange(t.alpha, 0, 1)
  }
  e.is = i
})(S || (S = {}));
var te;
(function(e) {
  function n(r, t) {
    return {
      range: r,
      color: t
    }
  }
  e.create = n;

  function i(r) {
    const t = r;
    return o.objectLiteral(t) && h.is(t.range) && S.is(t.color)
  }
  e.is = i
})(te || (te = {}));
var ne;
(function(e) {
  function n(r, t, a) {
    return {
      label: r,
      textEdit: t,
      additionalTextEdits: a
    }
  }
  e.create = n;

  function i(r) {
    const t = r;
    return o.objectLiteral(t) && o.string(t.label) && (o.undefined(t.textEdit) || L.is(t)) && (o.undefined(t.additionalTextEdits) || o.typedArray(t.additionalTextEdits, L.is))
  }
  e.is = i
})(ne || (ne = {}));
var M;
(function(e) {
  e.Comment = "comment", e.Imports = "imports", e.Region = "region"
})(M || (M = {}));
var re;
(function(e) {
  function n(r, t, a, u, s, f) {
    const l = {
      startLine: r,
      endLine: t
    };
    return o.defined(a) && (l.startCharacter = a), o.defined(u) && (l.endCharacter = u), o.defined(s) && (l.kind = s), o.defined(f) && (l.collapsedText = f), l
  }
  e.create = n;

  function i(r) {
    const t = r;
    return o.objectLiteral(t) && o.uinteger(t.startLine) && o.uinteger(t.startLine) && (o.undefined(t.startCharacter) || o.uinteger(t.startCharacter)) && (o.undefined(t.endCharacter) || o.uinteger(t.endCharacter)) && (o.undefined(t.kind) || o.string(t.kind))
  }
  e.is = i
})(re || (re = {}));
var H;
(function(e) {
  function n(r, t) {
    return {
      location: r,
      message: t
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && N.is(t.location) && o.string(t.message)
  }
  e.is = i
})(H || (H = {}));
var A;
(function(e) {
  e.Error = 1, e.Warning = 2, e.Information = 3, e.Hint = 4
})(A || (A = {}));
var ie;
(function(e) {
  e.Unnecessary = 1, e.Deprecated = 2
})(ie || (ie = {}));
var ae;
(function(e) {
  function n(i) {
    const r = i;
    return o.objectLiteral(r) && o.string(r.href)
  }
  e.is = n
})(ae || (ae = {}));
var P;
(function(e) {
  function n(r, t, a, u, s, f) {
    let l = {
      range: r,
      message: t
    };
    return o.defined(a) && (l.severity = a), o.defined(u) && (l.code = u), o.defined(s) && (l.source = s), o.defined(f) && (l.relatedInformation = f), l
  }
  e.create = n;

  function i(r) {
    var t;
    let a = r;
    return o.defined(a) && h.is(a.range) && o.string(a.message) && (o.number(a.severity) || o.undefined(a.severity)) && (o.integer(a.code) || o.string(a.code) || o.undefined(a.code)) && (o.undefined(a.codeDescription) || o.string((t = a.codeDescription) === null || t === void 0 ? void 0 : t.href)) && (o.string(a.source) || o.undefined(a.source)) && (o.undefined(a.relatedInformation) || o.typedArray(a.relatedInformation, H.is))
  }
  e.is = i
})(P || (P = {}));
var E;
(function(e) {
  function n(r, t, ...a) {
    let u = {
      title: r,
      command: t
    };
    return o.defined(a) && a.length > 0 && (u.arguments = a), u
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && o.string(t.title) && o.string(t.command)
  }
  e.is = i
})(E || (E = {}));
var L;
(function(e) {
  function n(a, u) {
    return {
      range: a,
      newText: u
    }
  }
  e.replace = n;

  function i(a, u) {
    return {
      range: {
        start: a,
        end: a
      },
      newText: u
    }
  }
  e.insert = i;

  function r(a) {
    return {
      range: a,
      newText: ""
    }
  }
  e.del = r;

  function t(a) {
    const u = a;
    return o.objectLiteral(u) && o.string(u.newText) && h.is(u.range)
  }
  e.is = t
})(L || (L = {}));
var W;
(function(e) {
  function n(r, t, a) {
    const u = {
      label: r
    };
    return t !== void 0 && (u.needsConfirmation = t), a !== void 0 && (u.description = a), u
  }
  e.create = n;

  function i(r) {
    const t = r;
    return o.objectLiteral(t) && o.string(t.label) && (o.boolean(t.needsConfirmation) || t.needsConfirmation === void 0) && (o.string(t.description) || t.description === void 0)
  }
  e.is = i
})(W || (W = {}));
var I;
(function(e) {
  function n(i) {
    const r = i;
    return o.string(r)
  }
  e.is = n
})(I || (I = {}));
var oe;
(function(e) {
  function n(a, u, s) {
    return {
      range: a,
      newText: u,
      annotationId: s
    }
  }
  e.replace = n;

  function i(a, u, s) {
    return {
      range: {
        start: a,
        end: a
      },
      newText: u,
      annotationId: s
    }
  }
  e.insert = i;

  function r(a, u) {
    return {
      range: a,
      newText: "",
      annotationId: u
    }
  }
  e.del = r;

  function t(a) {
    const u = a;
    return L.is(u) && (W.is(u.annotationId) || I.is(u.annotationId))
  }
  e.is = t
})(oe || (oe = {}));
var X;
(function(e) {
  function n(r, t) {
    return {
      textDocument: r,
      edits: t
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && Q.is(t.textDocument) && Array.isArray(t.edits)
  }
  e.is = i
})(X || (X = {}));
var $;
(function(e) {
  function n(r, t, a) {
    let u = {
      kind: "create",
      uri: r
    };
    return t !== void 0 && (t.overwrite !== void 0 || t.ignoreIfExists !== void 0) && (u.options = t), a !== void 0 && (u.annotationId = a), u
  }
  e.create = n;

  function i(r) {
    let t = r;
    return t && t.kind === "create" && o.string(t.uri) && (t.options === void 0 || (t.options.overwrite === void 0 || o.boolean(t.options.overwrite)) && (t.options.ignoreIfExists === void 0 || o.boolean(t.options.ignoreIfExists))) && (t.annotationId === void 0 || I.is(t.annotationId))
  }
  e.is = i
})($ || ($ = {}));
var z;
(function(e) {
  function n(r, t, a, u) {
    let s = {
      kind: "rename",
      oldUri: r,
      newUri: t
    };
    return a !== void 0 && (a.overwrite !== void 0 || a.ignoreIfExists !== void 0) && (s.options = a), u !== void 0 && (s.annotationId = u), s
  }
  e.create = n;

  function i(r) {
    let t = r;
    return t && t.kind === "rename" && o.string(t.oldUri) && o.string(t.newUri) && (t.options === void 0 || (t.options.overwrite === void 0 || o.boolean(t.options.overwrite)) && (t.options.ignoreIfExists === void 0 || o.boolean(t.options.ignoreIfExists))) && (t.annotationId === void 0 || I.is(t.annotationId))
  }
  e.is = i
})(z || (z = {}));
var B;
(function(e) {
  function n(r, t, a) {
    let u = {
      kind: "delete",
      uri: r
    };
    return t !== void 0 && (t.recursive !== void 0 || t.ignoreIfNotExists !== void 0) && (u.options = t), a !== void 0 && (u.annotationId = a), u
  }
  e.create = n;

  function i(r) {
    let t = r;
    return t && t.kind === "delete" && o.string(t.uri) && (t.options === void 0 || (t.options.recursive === void 0 || o.boolean(t.options.recursive)) && (t.options.ignoreIfNotExists === void 0 || o.boolean(t.options.ignoreIfNotExists))) && (t.annotationId === void 0 || I.is(t.annotationId))
  }
  e.is = i
})(B || (B = {}));
var q;
(function(e) {
  function n(i) {
    let r = i;
    return r && (r.changes !== void 0 || r.documentChanges !== void 0) && (r.documentChanges === void 0 || r.documentChanges.every(t => o.string(t.kind) ? $.is(t) || z.is(t) || B.is(t) : X.is(t)))
  }
  e.is = n
})(q || (q = {}));
var ue;
(function(e) {
  function n(r) {
    return {
      uri: r
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && o.string(t.uri)
  }
  e.is = i
})(ue || (ue = {}));
var se;
(function(e) {
  function n(r, t) {
    return {
      uri: r,
      version: t
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && o.string(t.uri) && o.integer(t.version)
  }
  e.is = i
})(se || (se = {}));
var Q;
(function(e) {
  function n(r, t) {
    return {
      uri: r,
      version: t
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && o.string(t.uri) && (t.version === null || o.integer(t.version))
  }
  e.is = i
})(Q || (Q = {}));
var ce;
(function(e) {
  function n(r, t, a, u) {
    return {
      uri: r,
      languageId: t,
      version: a,
      text: u
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && o.string(t.uri) && o.string(t.languageId) && o.integer(t.version) && o.string(t.text)
  }
  e.is = i
})(ce || (ce = {}));
var G;
(function(e) {
  e.PlainText = "plaintext", e.Markdown = "markdown";

  function n(i) {
    const r = i;
    return r === e.PlainText || r === e.Markdown
  }
  e.is = n
})(G || (G = {}));
var F;
(function(e) {
  function n(i) {
    const r = i;
    return o.objectLiteral(i) && G.is(r.kind) && o.string(r.value)
  }
  e.is = n
})(F || (F = {}));
var p;
(function(e) {
  e.Text = 1, e.Method = 2, e.Function = 3, e.Constructor = 4, e.Field = 5, e.Variable = 6, e.Class = 7, e.Interface = 8, e.Module = 9, e.Property = 10, e.Unit = 11, e.Value = 12, e.Enum = 13, e.Keyword = 14, e.Snippet = 15, e.Color = 16, e.File = 17, e.Reference = 18, e.Folder = 19, e.EnumMember = 20, e.Constant = 21, e.Struct = 22, e.Event = 23, e.Operator = 24, e.TypeParameter = 25
})(p || (p = {}));
var J;
(function(e) {
  e.PlainText = 1, e.Snippet = 2
})(J || (J = {}));
var de;
(function(e) {
  e.Deprecated = 1
})(de || (de = {}));
var fe;
(function(e) {
  function n(r, t, a) {
    return {
      newText: r,
      insert: t,
      replace: a
    }
  }
  e.create = n;

  function i(r) {
    const t = r;
    return t && o.string(t.newText) && h.is(t.insert) && h.is(t.replace)
  }
  e.is = i
})(fe || (fe = {}));
var le;
(function(e) {
  e.asIs = 1, e.adjustIndentation = 2
})(le || (le = {}));
var ge;
(function(e) {
  function n(i) {
    const r = i;
    return r && (o.string(r.detail) || r.detail === void 0) && (o.string(r.description) || r.description === void 0)
  }
  e.is = n
})(ge || (ge = {}));
var he;
(function(e) {
  function n(i) {
    return {
      label: i
    }
  }
  e.create = n
})(he || (he = {}));
var pe;
(function(e) {
  function n(i, r) {
    return {
      items: i || [],
      isIncomplete: !!r
    }
  }
  e.create = n
})(pe || (pe = {}));
var y;
(function(e) {
  function n(r) {
    return r.replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&")
  }
  e.fromPlainText = n;

  function i(r) {
    const t = r;
    return o.string(t) || o.objectLiteral(t) && o.string(t.language) && o.string(t.value)
  }
  e.is = i
})(y || (y = {}));
var me;
(function(e) {
  function n(i) {
    let r = i;
    return !!r && o.objectLiteral(r) && (F.is(r.contents) || y.is(r.contents) || o.typedArray(r.contents, y.is)) && (i.range === void 0 || h.is(i.range))
  }
  e.is = n
})(me || (me = {}));
var ve;
(function(e) {
  function n(i, r) {
    return r ? {
      label: i,
      documentation: r
    } : {
      label: i
    }
  }
  e.create = n
})(ve || (ve = {}));
var be;
(function(e) {
  function n(i, r, ...t) {
    let a = {
      label: i
    };
    return o.defined(r) && (a.documentation = r), o.defined(t) ? a.parameters = t : a.parameters = [], a
  }
  e.create = n
})(be || (be = {}));
var D;
(function(e) {
  e.Text = 1, e.Read = 2, e.Write = 3
})(D || (D = {}));
var _e;
(function(e) {
  function n(i, r) {
    let t = {
      range: i
    };
    return o.number(r) && (t.kind = r), t
  }
  e.create = n
})(_e || (_e = {}));
var m;
(function(e) {
  e.File = 1, e.Module = 2, e.Namespace = 3, e.Package = 4, e.Class = 5, e.Method = 6, e.Property = 7, e.Field = 8, e.Constructor = 9, e.Enum = 10, e.Interface = 11, e.Function = 12, e.Variable = 13, e.Constant = 14, e.String = 15, e.Number = 16, e.Boolean = 17, e.Array = 18, e.Object = 19, e.Key = 20, e.Null = 21, e.EnumMember = 22, e.Struct = 23, e.Event = 24, e.Operator = 25, e.TypeParameter = 26
})(m || (m = {}));
var xe;
(function(e) {
  e.Deprecated = 1
})(xe || (xe = {}));
var we;
(function(e) {
  function n(i, r, t, a, u) {
    let s = {
      name: i,
      kind: r,
      location: {
        uri: a,
        range: t
      }
    };
    return u && (s.containerName = u), s
  }
  e.create = n
})(we || (we = {}));
var ke;
(function(e) {
  function n(i, r, t, a) {
    return a !== void 0 ? {
      name: i,
      kind: r,
      location: {
        uri: t,
        range: a
      }
    } : {
      name: i,
      kind: r,
      location: {
        uri: t
      }
    }
  }
  e.create = n
})(ke || (ke = {}));
var Ae;
(function(e) {
  function n(r, t, a, u, s, f) {
    let l = {
      name: r,
      detail: t,
      kind: a,
      range: u,
      selectionRange: s
    };
    return f !== void 0 && (l.children = f), l
  }
  e.create = n;

  function i(r) {
    let t = r;
    return t && o.string(t.name) && o.number(t.kind) && h.is(t.range) && h.is(t.selectionRange) && (t.detail === void 0 || o.string(t.detail)) && (t.deprecated === void 0 || o.boolean(t.deprecated)) && (t.children === void 0 || Array.isArray(t.children)) && (t.tags === void 0 || Array.isArray(t.tags))
  }
  e.is = i
})(Ae || (Ae = {}));
var Ee;
(function(e) {
  e.Empty = "", e.QuickFix = "quickfix", e.Refactor = "refactor", e.RefactorExtract = "refactor.extract", e.RefactorInline = "refactor.inline", e.RefactorRewrite = "refactor.rewrite", e.Source = "source", e.SourceOrganizeImports = "source.organizeImports", e.SourceFixAll = "source.fixAll"
})(Ee || (Ee = {}));
var V;
(function(e) {
  e.Invoked = 1, e.Automatic = 2
})(V || (V = {}));
var Le;
(function(e) {
  function n(r, t, a) {
    let u = {
      diagnostics: r
    };
    return t != null && (u.only = t), a != null && (u.triggerKind = a), u
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && o.typedArray(t.diagnostics, P.is) && (t.only === void 0 || o.typedArray(t.only, o.string)) && (t.triggerKind === void 0 || t.triggerKind === V.Invoked || t.triggerKind === V.Automatic)
  }
  e.is = i
})(Le || (Le = {}));
var Ie;
(function(e) {
  function n(r, t, a) {
    let u = {
        title: r
      },
      s = !0;
    return typeof t == "string" ? (s = !1, u.kind = t) : E.is(t) ? u.command = t : u.edit = t, s && a !== void 0 && (u.kind = a), u
  }
  e.create = n;

  function i(r) {
    let t = r;
    return t && o.string(t.title) && (t.diagnostics === void 0 || o.typedArray(t.diagnostics, P.is)) && (t.kind === void 0 || o.string(t.kind)) && (t.edit !== void 0 || t.command !== void 0) && (t.command === void 0 || E.is(t.command)) && (t.isPreferred === void 0 || o.boolean(t.isPreferred)) && (t.edit === void 0 || q.is(t.edit))
  }
  e.is = i
})(Ie || (Ie = {}));
var Re;
(function(e) {
  function n(r, t) {
    let a = {
      range: r
    };
    return o.defined(t) && (a.data = t), a
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && h.is(t.range) && (o.undefined(t.command) || E.is(t.command))
  }
  e.is = i
})(Re || (Re = {}));
var Me;
(function(e) {
  function n(r, t) {
    return {
      tabSize: r,
      insertSpaces: t
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && o.uinteger(t.tabSize) && o.boolean(t.insertSpaces)
  }
  e.is = i
})(Me || (Me = {}));
var De;
(function(e) {
  function n(r, t, a) {
    return {
      range: r,
      target: t,
      data: a
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.defined(t) && h.is(t.range) && (o.undefined(t.target) || o.string(t.target))
  }
  e.is = i
})(De || (De = {}));
var Fe;
(function(e) {
  function n(r, t) {
    return {
      range: r,
      parent: t
    }
  }
  e.create = n;

  function i(r) {
    let t = r;
    return o.objectLiteral(t) && h.is(t.range) && (t.parent === void 0 || e.is(t.parent))
  }
  e.is = i
})(Fe || (Fe = {}));
var Ce;
(function(e) {
  e.namespace = "namespace", e.type = "type", e.class = "class", e.enum = "enum", e.interface = "interface", e.struct = "struct", e.typeParameter = "typeParameter", e.parameter = "parameter", e.variable = "variable", e.property = "property", e.enumMember = "enumMember", e.event = "event", e.function = "function", e.method = "method", e.macro = "macro", e.keyword = "keyword", e.modifier = "modifier", e.comment = "comment", e.string = "string", e.number = "number", e.regexp = "regexp", e.operator = "operator", e.decorator = "decorator"
})(Ce || (Ce = {}));
var je;
(function(e) {
  e.declaration = "declaration", e.definition = "definition", e.readonly = "readonly", e.static = "static", e.deprecated = "deprecated", e.abstract = "abstract", e.async = "async", e.modification = "modification", e.documentation = "documentation", e.defaultLibrary = "defaultLibrary"
})(je || (je = {}));
var Ne;
(function(e) {
  function n(i) {
    const r = i;
    return o.objectLiteral(r) && (r.resultId === void 0 || typeof r.resultId == "string") && Array.isArray(r.data) && (r.data.length === 0 || typeof r.data[0] == "number")
  }
  e.is = n
})(Ne || (Ne = {}));
var Pe;
(function(e) {
  function n(r, t) {
    return {
      range: r,
      text: t
    }
  }
  e.create = n;

  function i(r) {
    const t = r;
    return t != null && h.is(t.range) && o.string(t.text)
  }
  e.is = i
})(Pe || (Pe = {}));
var ye;
(function(e) {
  function n(r, t, a) {
    return {
      range: r,
      variableName: t,
      caseSensitiveLookup: a
    }
  }
  e.create = n;

  function i(r) {
    const t = r;
    return t != null && h.is(t.range) && o.boolean(t.caseSensitiveLookup) && (o.string(t.variableName) || t.variableName === void 0)
  }
  e.is = i
})(ye || (ye = {}));
var Ve;
(function(e) {
  function n(r, t) {
    return {
      range: r,
      expression: t
    }
  }
  e.create = n;

  function i(r) {
    const t = r;
    return t != null && h.is(t.range) && (o.string(t.expression) || t.expression === void 0)
  }
  e.is = i
})(Ve || (Ve = {}));
var Ue;
(function(e) {
  function n(r, t) {
    return {
      frameId: r,
      stoppedLocation: t
    }
  }
  e.create = n;

  function i(r) {
    const t = r;
    return o.defined(t) && h.is(r.stoppedLocation)
  }
  e.is = i
})(Ue || (Ue = {}));
var Y;
(function(e) {
  e.Type = 1, e.Parameter = 2;

  function n(i) {
    return i === 1 || i === 2
  }
  e.is = n
})(Y || (Y = {}));
var Z;
(function(e) {
  function n(r) {
    return {
      value: r
    }
  }
  e.create = n;

  function i(r) {
    const t = r;
    return o.objectLiteral(t) && (t.tooltip === void 0 || o.string(t.tooltip) || F.is(t.tooltip)) && (t.location === void 0 || N.is(t.location)) && (t.command === void 0 || E.is(t.command))
  }
  e.is = i
})(Z || (Z = {}));
var Oe;
(function(e) {
  function n(r, t, a) {
    const u = {
      position: r,
      label: t
    };
    return a !== void 0 && (u.kind = a), u
  }
  e.create = n;

  function i(r) {
    const t = r;
    return o.objectLiteral(t) && _.is(t.position) && (o.string(t.label) || o.typedArray(t.label, Z.is)) && (t.kind === void 0 || Y.is(t.kind)) && t.textEdits === void 0 || o.typedArray(t.textEdits, L.is) && (t.tooltip === void 0 || o.string(t.tooltip) || F.is(t.tooltip)) && (t.paddingLeft === void 0 || o.boolean(t.paddingLeft)) && (t.paddingRight === void 0 || o.boolean(t.paddingRight))
  }
  e.is = i
})(Oe || (Oe = {}));
var Se;
(function(e) {
  function n(i) {
    return {
      kind: "snippet",
      value: i
    }
  }
  e.createSnippet = n
})(Se || (Se = {}));
var He;
(function(e) {
  function n(i, r, t, a) {
    return {
      insertText: i,
      filterText: r,
      range: t,
      command: a
    }
  }
  e.create = n
})(He || (He = {}));
var We;
(function(e) {
  function n(i) {
    return {
      items: i
    }
  }
  e.create = n
})(We || (We = {}));
var Xe;
(function(e) {
  e.Invoked = 0, e.Automatic = 1
})(Xe || (Xe = {}));
var $e;
(function(e) {
  function n(i, r) {
    return {
      range: i,
      text: r
    }
  }
  e.create = n
})($e || ($e = {}));
var ze;
(function(e) {
  function n(i, r) {
    return {
      triggerKind: i,
      selectedCompletionInfo: r
    }
  }
  e.create = n
})(ze || (ze = {}));
var Be;
(function(e) {
  function n(i) {
    const r = i;
    return o.objectLiteral(r) && O.is(r.uri) && o.string(r.name)
  }
  e.is = n
})(Be || (Be = {}));
var qe;
(function(e) {
  function n(a, u, s, f) {
    return new nt(a, u, s, f)
  }
  e.create = n;

  function i(a) {
    let u = a;
    return !!(o.defined(u) && o.string(u.uri) && (o.undefined(u.languageId) || o.string(u.languageId)) && o.uinteger(u.lineCount) && o.func(u.getText) && o.func(u.positionAt) && o.func(u.offsetAt))
  }
  e.is = i;

  function r(a, u) {
    let s = a.getText(),
      f = t(u, (d, g) => {
        let b = d.range.start.line - g.range.start.line;
        return b === 0 ? d.range.start.character - g.range.start.character : b
      }),
      l = s.length;
    for (let d = f.length - 1; d >= 0; d--) {
      let g = f[d],
        b = a.offsetAt(g.range.start),
        c = a.offsetAt(g.range.end);
      if (c <= l) s = s.substring(0, b) + g.newText + s.substring(c, s.length);
      else throw new Error("Overlapping edit");
      l = b
    }
    return s
  }
  e.applyEdits = r;

  function t(a, u) {
    if (a.length <= 1) return a;
    const s = a.length / 2 | 0,
      f = a.slice(0, s),
      l = a.slice(s);
    t(f, u), t(l, u);
    let d = 0,
      g = 0,
      b = 0;
    for (; d < f.length && g < l.length;) u(f[d], l[g]) <= 0 ? a[b++] = f[d++] : a[b++] = l[g++];
    for (; d < f.length;) a[b++] = f[d++];
    for (; g < l.length;) a[b++] = l[g++];
    return a
  }
})(qe || (qe = {}));
class nt {
  constructor(n, i, r, t) {
    this._uri = n, this._languageId = i, this._version = r, this._content = t, this._lineOffsets = void 0
  }
  get uri() {
    return this._uri
  }
  get languageId() {
    return this._languageId
  }
  get version() {
    return this._version
  }
  getText(n) {
    if (n) {
      let i = this.offsetAt(n.start),
        r = this.offsetAt(n.end);
      return this._content.substring(i, r)
    }
    return this._content
  }
  update(n, i) {
    this._content = n.text, this._version = i, this._lineOffsets = void 0
  }
  getLineOffsets() {
    if (this._lineOffsets === void 0) {
      let n = [],
        i = this._content,
        r = !0;
      for (let t = 0; t < i.length; t++) {
        r && (n.push(t), r = !1);
        let a = i.charAt(t);
        r = a === "\r" || a === `
`, a === "\r" && t + 1 < i.length && i.charAt(t + 1) === `
` && t++
      }
      r && i.length > 0 && n.push(i.length), this._lineOffsets = n
    }
    return this._lineOffsets
  }
  positionAt(n) {
    n = Math.max(Math.min(n, this._content.length), 0);
    let i = this.getLineOffsets(),
      r = 0,
      t = i.length;
    if (t === 0) return _.create(0, n);
    for (; r < t;) {
      let u = Math.floor((r + t) / 2);
      i[u] > n ? t = u : r = u + 1
    }
    let a = r - 1;
    return _.create(a, n - i[a])
  }
  offsetAt(n) {
    let i = this.getLineOffsets();
    if (n.line >= i.length) return this._content.length;
    if (n.line < 0) return 0;
    let r = i[n.line],
      t = n.line + 1 < i.length ? i[n.line + 1] : this._content.length;
    return Math.max(Math.min(r + n.character, t), r)
  }
  get lineCount() {
    return this.getLineOffsets().length
  }
}
var o;
(function(e) {
  const n = Object.prototype.toString;

  function i(c) {
    return typeof c < "u"
  }
  e.defined = i;

  function r(c) {
    return typeof c > "u"
  }
  e.undefined = r;

  function t(c) {
    return c === !0 || c === !1
  }
  e.boolean = t;

  function a(c) {
    return n.call(c) === "[object String]"
  }
  e.string = a;

  function u(c) {
    return n.call(c) === "[object Number]"
  }
  e.number = u;

  function s(c, U, tt) {
    return n.call(c) === "[object Number]" && U <= c && c <= tt
  }
  e.numberRange = s;

  function f(c) {
    return n.call(c) === "[object Number]" && -2147483648 <= c && c <= 2147483647
  }
  e.integer = f;

  function l(c) {
    return n.call(c) === "[object Number]" && 0 <= c && c <= 2147483647
  }
  e.uinteger = l;

  function d(c) {
    return n.call(c) === "[object Function]"
  }
  e.func = d;

  function g(c) {
    return c !== null && typeof c == "object"
  }
  e.objectLiteral = g;

  function b(c, U) {
    return Array.isArray(c) && c.every(U)
  }
  e.typedArray = b
})(o || (o = {}));
class pt {
  constructor(n, i, r) {
    this._languageId = n, this._worker = i, this._disposables = [], this._listener = Object.create(null);
    const t = u => {
        let s = u.getLanguageId();
        if (s !== this._languageId) return;
        let f;
        this._listener[u.uri.toString()] = u.onDidChangeContent(() => {
          window.clearTimeout(f), f = window.setTimeout(() => this._doValidate(u.uri, s), 500)
        }), this._doValidate(u.uri, s)
      },
      a = u => {
        w.setModelMarkers(u, this._languageId, []);
        let s = u.uri.toString(),
          f = this._listener[s];
        f && (f.dispose(), delete this._listener[s])
      };
    this._disposables.push(w.onDidCreateModel(t)), this._disposables.push(w.onWillDisposeModel(a)), this._disposables.push(w.onDidChangeModelLanguage(u => {
      a(u.model), t(u.model)
    })), this._disposables.push(r(u => {
      w.getModels().forEach(s => {
        s.getLanguageId() === this._languageId && (a(s), t(s))
      })
    })), this._disposables.push({
      dispose: () => {
        w.getModels().forEach(a);
        for (let u in this._listener) this._listener[u].dispose()
      }
    }), w.getModels().forEach(t)
  }
  dispose() {
    this._disposables.forEach(n => n && n.dispose()), this._disposables.length = 0
  }
  _doValidate(n, i) {
    this._worker(n).then(r => r.doValidation(n.toString())).then(r => {
      const t = r.map(u => it(n, u));
      let a = w.getModel(n);
      a && a.getLanguageId() === i && w.setModelMarkers(a, i, t)
    }).then(void 0, r => {
      console.error(r)
    })
  }
}

function rt(e) {
  switch (e) {
    case A.Error:
      return R.Error;
    case A.Warning:
      return R.Warning;
    case A.Information:
      return R.Info;
    case A.Hint:
      return R.Hint;
    default:
      return R.Info
  }
}

function it(e, n) {
  let i = typeof n.code == "number" ? String(n.code) : n.code;
  return {
    severity: rt(n.severity),
    startLineNumber: n.range.start.line + 1,
    startColumn: n.range.start.character + 1,
    endLineNumber: n.range.end.line + 1,
    endColumn: n.range.end.character + 1,
    message: n.message,
    code: i,
    source: n.source
  }
}
class mt {
  constructor(n, i) {
    this._worker = n, this._triggerCharacters = i
  }
  get triggerCharacters() {
    return this._triggerCharacters
  }
  provideCompletionItems(n, i, r, t) {
    const a = n.uri;
    return this._worker(a).then(u => u.doComplete(a.toString(), k(i))).then(u => {
      if (!u) return;
      const s = n.getWordUntilPosition(i),
        f = new Ge(i.lineNumber, s.startColumn, i.lineNumber, s.endColumn),
        l = u.items.map(d => {
          const g = {
            label: d.label,
            insertText: d.insertText || d.label,
            sortText: d.sortText,
            filterText: d.filterText,
            documentation: d.documentation,
            detail: d.detail,
            command: ut(d.command),
            range: f,
            kind: ot(d.kind)
          };
          return d.textEdit && (at(d.textEdit) ? g.range = {
            insert: v(d.textEdit.insert),
            replace: v(d.textEdit.replace)
          } : g.range = v(d.textEdit.range), g.insertText = d.textEdit.newText), d.additionalTextEdits && (g.additionalTextEdits = d.additionalTextEdits.map(C)), d.insertTextFormat === J.Snippet && (g.insertTextRules = x.CompletionItemInsertTextRule.InsertAsSnippet), g
        });
      return {
        isIncomplete: u.isIncomplete,
        suggestions: l
      }
    })
  }
}

function k(e) {
  if (e) return {
    character: e.column - 1,
    line: e.lineNumber - 1
  }
}

function Ye(e) {
  if (e) return {
    start: {
      line: e.startLineNumber - 1,
      character: e.startColumn - 1
    },
    end: {
      line: e.endLineNumber - 1,
      character: e.endColumn - 1
    }
  }
}

function v(e) {
  if (e) return new Ge(e.start.line + 1, e.start.character + 1, e.end.line + 1, e.end.character + 1)
}

function at(e) {
  return typeof e.insert < "u" && typeof e.replace < "u"
}

function ot(e) {
  const n = x.CompletionItemKind;
  switch (e) {
    case p.Text:
      return n.Text;
    case p.Method:
      return n.Method;
    case p.Function:
      return n.Function;
    case p.Constructor:
      return n.Constructor;
    case p.Field:
      return n.Field;
    case p.Variable:
      return n.Variable;
    case p.Class:
      return n.Class;
    case p.Interface:
      return n.Interface;
    case p.Module:
      return n.Module;
    case p.Property:
      return n.Property;
    case p.Unit:
      return n.Unit;
    case p.Value:
      return n.Value;
    case p.Enum:
      return n.Enum;
    case p.Keyword:
      return n.Keyword;
    case p.Snippet:
      return n.Snippet;
    case p.Color:
      return n.Color;
    case p.File:
      return n.File;
    case p.Reference:
      return n.Reference
  }
  return n.Property
}

function C(e) {
  if (e) return {
    range: v(e.range),
    text: e.newText
  }
}

function ut(e) {
  return e && e.command === "editor.action.triggerSuggest" ? {
    id: e.command,
    title: e.title,
    arguments: e.arguments
  } : void 0
}
class vt {
  constructor(n) {
    this._worker = n
  }
  provideHover(n, i, r) {
    let t = n.uri;
    return this._worker(t).then(a => a.doHover(t.toString(), k(i))).then(a => {
      if (a) return {
        range: v(a.range),
        contents: ct(a.contents)
      }
    })
  }
}

function st(e) {
  return e && typeof e == "object" && typeof e.kind == "string"
}

function Qe(e) {
  return typeof e == "string" ? {
    value: e
  } : st(e) ? e.kind === "plaintext" ? {
    value: e.value.replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&")
  } : {
    value: e.value
  } : {
    value: "```" + e.language + `
` + e.value + "\n```\n"
  }
}

function ct(e) {
  if (e) return Array.isArray(e) ? e.map(Qe) : [Qe(e)]
}
class bt {
  constructor(n) {
    this._worker = n
  }
  provideDocumentHighlights(n, i, r) {
    const t = n.uri;
    return this._worker(t).then(a => a.findDocumentHighlights(t.toString(), k(i))).then(a => {
      if (a) return a.map(u => ({
        range: v(u.range),
        kind: dt(u.kind)
      }))
    })
  }
}

function dt(e) {
  switch (e) {
    case D.Read:
      return x.DocumentHighlightKind.Read;
    case D.Write:
      return x.DocumentHighlightKind.Write;
    case D.Text:
      return x.DocumentHighlightKind.Text
  }
  return x.DocumentHighlightKind.Text
}
class _t {
  constructor(n) {
    this._worker = n
  }
  provideDefinition(n, i, r) {
    const t = n.uri;
    return this._worker(t).then(a => a.findDefinition(t.toString(), k(i))).then(a => {
      if (a) return [Ze(a)]
    })
  }
}

function Ze(e) {
  return {
    uri: Je.parse(e.uri),
    range: v(e.range)
  }
}
class xt {
  constructor(n) {
    this._worker = n
  }
  provideReferences(n, i, r, t) {
    const a = n.uri;
    return this._worker(a).then(u => u.findReferences(a.toString(), k(i))).then(u => {
      if (u) return u.map(Ze)
    })
  }
}
class wt {
  constructor(n) {
    this._worker = n
  }
  provideRenameEdits(n, i, r, t) {
    const a = n.uri;
    return this._worker(a).then(u => u.doRename(a.toString(), k(i), r)).then(u => ft(u))
  }
}

function ft(e) {
  if (!e || !e.changes) return;
  let n = [];
  for (let i in e.changes) {
    const r = Je.parse(i);
    for (let t of e.changes[i]) n.push({
      resource: r,
      versionId: void 0,
      textEdit: {
        range: v(t.range),
        text: t.newText
      }
    })
  }
  return {
    edits: n
  }
}
class kt {
  constructor(n) {
    this._worker = n
  }
  provideDocumentSymbols(n, i) {
    const r = n.uri;
    return this._worker(r).then(t => t.findDocumentSymbols(r.toString())).then(t => {
      if (t) return t.map(a => lt(a) ? Te(a) : {
        name: a.name,
        detail: "",
        containerName: a.containerName,
        kind: Ke(a.kind),
        range: v(a.location.range),
        selectionRange: v(a.location.range),
        tags: []
      })
    })
  }
}

function lt(e) {
  return "children" in e
}

function Te(e) {
  return {
    name: e.name,
    detail: e.detail ?? "",
    kind: Ke(e.kind),
    range: v(e.range),
    selectionRange: v(e.selectionRange),
    tags: e.tags ?? [],
    children: (e.children ?? []).map(n => Te(n))
  }
}

function Ke(e) {
  let n = x.SymbolKind;
  switch (e) {
    case m.File:
      return n.File;
    case m.Module:
      return n.Module;
    case m.Namespace:
      return n.Namespace;
    case m.Package:
      return n.Package;
    case m.Class:
      return n.Class;
    case m.Method:
      return n.Method;
    case m.Property:
      return n.Property;
    case m.Field:
      return n.Field;
    case m.Constructor:
      return n.Constructor;
    case m.Enum:
      return n.Enum;
    case m.Interface:
      return n.Interface;
    case m.Function:
      return n.Function;
    case m.Variable:
      return n.Variable;
    case m.Constant:
      return n.Constant;
    case m.String:
      return n.String;
    case m.Number:
      return n.Number;
    case m.Boolean:
      return n.Boolean;
    case m.Array:
      return n.Array
  }
  return n.Function
}
class At {
  constructor(n) {
    this._worker = n
  }
  provideLinks(n, i) {
    const r = n.uri;
    return this._worker(r).then(t => t.findDocumentLinks(r.toString())).then(t => {
      if (t) return {
        links: t.map(a => ({
          range: v(a.range),
          url: a.target
        }))
      }
    })
  }
}
class Et {
  constructor(n) {
    this._worker = n
  }
  provideDocumentFormattingEdits(n, i, r) {
    const t = n.uri;
    return this._worker(t).then(a => a.format(t.toString(), null, et(i)).then(u => {
      if (!(!u || u.length === 0)) return u.map(C)
    }))
  }
}
class Lt {
  constructor(n) {
    this._worker = n, this.canFormatMultipleRanges = !1
  }
  provideDocumentRangeFormattingEdits(n, i, r, t) {
    const a = n.uri;
    return this._worker(a).then(u => u.format(a.toString(), Ye(i), et(r)).then(s => {
      if (!(!s || s.length === 0)) return s.map(C)
    }))
  }
}

function et(e) {
  return {
    tabSize: e.tabSize,
    insertSpaces: e.insertSpaces
  }
}
class It {
  constructor(n) {
    this._worker = n
  }
  provideDocumentColors(n, i) {
    const r = n.uri;
    return this._worker(r).then(t => t.findDocumentColors(r.toString())).then(t => {
      if (t) return t.map(a => ({
        color: a.color,
        range: v(a.range)
      }))
    })
  }
  provideColorPresentations(n, i, r) {
    const t = n.uri;
    return this._worker(t).then(a => a.getColorPresentations(t.toString(), i.color, Ye(i.range))).then(a => {
      if (a) return a.map(u => {
        let s = {
          label: u.label
        };
        return u.textEdit && (s.textEdit = C(u.textEdit)), u.additionalTextEdits && (s.additionalTextEdits = u.additionalTextEdits.map(C)), s
      })
    })
  }
}
class Rt {
  constructor(n) {
    this._worker = n
  }
  provideFoldingRanges(n, i, r) {
    const t = n.uri;
    return this._worker(t).then(a => a.getFoldingRanges(t.toString(), i)).then(a => {
      if (a) return a.map(u => {
        const s = {
          start: u.startLine + 1,
          end: u.endLine + 1
        };
        return typeof u.kind < "u" && (s.kind = gt(u.kind)), s
      })
    })
  }
}

function gt(e) {
  switch (e) {
    case M.Comment:
      return x.FoldingRangeKind.Comment;
    case M.Imports:
      return x.FoldingRangeKind.Imports;
    case M.Region:
      return x.FoldingRangeKind.Region
  }
}
class Mt {
  constructor(n) {
    this._worker = n
  }
  provideSelectionRanges(n, i, r) {
    const t = n.uri;
    return this._worker(t).then(a => a.getSelectionRanges(t.toString(), i.map(k))).then(a => {
      if (a) return a.map(u => {
        const s = [];
        for (; u;) s.push({
          range: v(u.range)
        }), u = u.parent;
        return s
      })
    })
  }
}
export {
  mt as C, bt as D, Rt as F, vt as H, xt as R, Mt as S, _t as a, kt as b, wt as c, It as d, pt as e, Et as f, Lt as g, At as h, k as i, Ye as j, C as k, v as t
};