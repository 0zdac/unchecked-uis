import {
  c as M,
  e as w,
  U as F,
  a as P,
  M as v,
  l as f,
  t as K,
  R as O
} from "./QxO3pMDe.js";
class E {
  constructor(e, t) {
    this._modeId = e, this._defaults = t, this._worker = null, this._client = null, this._configChangeListener = this._defaults.onDidChange(() => this._stopWorker()), this._updateExtraLibsToken = 0, this._extraLibsChangeListener = this._defaults.onDidExtraLibsChange(() => this._updateExtraLibs())
  }
  dispose() {
    this._configChangeListener.dispose(), this._extraLibsChangeListener.dispose(), this._stopWorker()
  }
  _stopWorker() {
    this._worker && (this._worker.dispose(), this._worker = null), this._client = null
  }
  async _updateExtraLibs() {
    if (!this._worker) return;
    const e = ++this._updateExtraLibsToken,
      t = await this._worker.getProxy();
    this._updateExtraLibsToken === e && t.updateExtraLibs(this._defaults.getExtraLibs())
  }
  _getClient() {
    return this._client || (this._client = (async () => (this._worker = M({
      moduleId: "vs/language/typescript/tsWorker",
      createWorker: () => new Worker(new URL("" + new URL("../workers/ts.worker-59MjiAqk.js", import.meta.url).href, import.meta.url), {
        type: "module"
      }),
      label: this._modeId,
      keepIdleModels: !0,
      createData: {
        compilerOptions: this._defaults.getCompilerOptions(),
        extraLibs: this._defaults.getExtraLibs(),
        customWorkerPath: this._defaults.workerOptions.customWorkerPath,
        inlayHintsOptions: this._defaults.inlayHintsOptions
      }
    }), this._defaults.getEagerModelSync() ? await this._worker.withSyncedResources(w.getModels().filter(e => e.getLanguageId() === this._modeId).map(e => e.uri)) : await this._worker.getProxy()))()), this._client
  }
  async getLanguageServiceWorker(...e) {
    const t = await this._getClient();
    return this._worker && await this._worker.withSyncedResources(e), t
  }
}
const s = {};
s["lib.d.ts"] = !0;
s["lib.decorators.d.ts"] = !0;
s["lib.decorators.legacy.d.ts"] = !0;
s["lib.dom.asynciterable.d.ts"] = !0;
s["lib.dom.d.ts"] = !0;
s["lib.dom.iterable.d.ts"] = !0;
s["lib.es2015.collection.d.ts"] = !0;
s["lib.es2015.core.d.ts"] = !0;
s["lib.es2015.d.ts"] = !0;
s["lib.es2015.generator.d.ts"] = !0;
s["lib.es2015.iterable.d.ts"] = !0;
s["lib.es2015.promise.d.ts"] = !0;
s["lib.es2015.proxy.d.ts"] = !0;
s["lib.es2015.reflect.d.ts"] = !0;
s["lib.es2015.symbol.d.ts"] = !0;
s["lib.es2015.symbol.wellknown.d.ts"] = !0;
s["lib.es2016.array.include.d.ts"] = !0;
s["lib.es2016.d.ts"] = !0;
s["lib.es2016.full.d.ts"] = !0;
s["lib.es2016.intl.d.ts"] = !0;
s["lib.es2017.arraybuffer.d.ts"] = !0;
s["lib.es2017.d.ts"] = !0;
s["lib.es2017.date.d.ts"] = !0;
s["lib.es2017.full.d.ts"] = !0;
s["lib.es2017.intl.d.ts"] = !0;
s["lib.es2017.object.d.ts"] = !0;
s["lib.es2017.sharedmemory.d.ts"] = !0;
s["lib.es2017.string.d.ts"] = !0;
s["lib.es2017.typedarrays.d.ts"] = !0;
s["lib.es2018.asyncgenerator.d.ts"] = !0;
s["lib.es2018.asynciterable.d.ts"] = !0;
s["lib.es2018.d.ts"] = !0;
s["lib.es2018.full.d.ts"] = !0;
s["lib.es2018.intl.d.ts"] = !0;
s["lib.es2018.promise.d.ts"] = !0;
s["lib.es2018.regexp.d.ts"] = !0;
s["lib.es2019.array.d.ts"] = !0;
s["lib.es2019.d.ts"] = !0;
s["lib.es2019.full.d.ts"] = !0;
s["lib.es2019.intl.d.ts"] = !0;
s["lib.es2019.object.d.ts"] = !0;
s["lib.es2019.string.d.ts"] = !0;
s["lib.es2019.symbol.d.ts"] = !0;
s["lib.es2020.bigint.d.ts"] = !0;
s["lib.es2020.d.ts"] = !0;
s["lib.es2020.date.d.ts"] = !0;
s["lib.es2020.full.d.ts"] = !0;
s["lib.es2020.intl.d.ts"] = !0;
s["lib.es2020.number.d.ts"] = !0;
s["lib.es2020.promise.d.ts"] = !0;
s["lib.es2020.sharedmemory.d.ts"] = !0;
s["lib.es2020.string.d.ts"] = !0;
s["lib.es2020.symbol.wellknown.d.ts"] = !0;
s["lib.es2021.d.ts"] = !0;
s["lib.es2021.full.d.ts"] = !0;
s["lib.es2021.intl.d.ts"] = !0;
s["lib.es2021.promise.d.ts"] = !0;
s["lib.es2021.string.d.ts"] = !0;
s["lib.es2021.weakref.d.ts"] = !0;
s["lib.es2022.array.d.ts"] = !0;
s["lib.es2022.d.ts"] = !0;
s["lib.es2022.error.d.ts"] = !0;
s["lib.es2022.full.d.ts"] = !0;
s["lib.es2022.intl.d.ts"] = !0;
s["lib.es2022.object.d.ts"] = !0;
s["lib.es2022.regexp.d.ts"] = !0;
s["lib.es2022.string.d.ts"] = !0;
s["lib.es2023.array.d.ts"] = !0;
s["lib.es2023.collection.d.ts"] = !0;
s["lib.es2023.d.ts"] = !0;
s["lib.es2023.full.d.ts"] = !0;
s["lib.es2023.intl.d.ts"] = !0;
s["lib.es2024.arraybuffer.d.ts"] = !0;
s["lib.es2024.collection.d.ts"] = !0;
s["lib.es2024.d.ts"] = !0;
s["lib.es2024.full.d.ts"] = !0;
s["lib.es2024.object.d.ts"] = !0;
s["lib.es2024.promise.d.ts"] = !0;
s["lib.es2024.regexp.d.ts"] = !0;
s["lib.es2024.sharedmemory.d.ts"] = !0;
s["lib.es2024.string.d.ts"] = !0;
s["lib.es5.d.ts"] = !0;
s["lib.es6.d.ts"] = !0;
s["lib.esnext.array.d.ts"] = !0;
s["lib.esnext.collection.d.ts"] = !0;
s["lib.esnext.d.ts"] = !0;
s["lib.esnext.decorators.d.ts"] = !0;
s["lib.esnext.disposable.d.ts"] = !0;
s["lib.esnext.error.d.ts"] = !0;
s["lib.esnext.float16.d.ts"] = !0;
s["lib.esnext.full.d.ts"] = !0;
s["lib.esnext.intl.d.ts"] = !0;
s["lib.esnext.iterator.d.ts"] = !0;
s["lib.esnext.promise.d.ts"] = !0;
s["lib.esnext.sharedmemory.d.ts"] = !0;
s["lib.scripthost.d.ts"] = !0;
s["lib.webworker.asynciterable.d.ts"] = !0;
s["lib.webworker.d.ts"] = !0;
s["lib.webworker.importscripts.d.ts"] = !0;
s["lib.webworker.iterable.d.ts"] = !0;

function A(c, e, t = 0) {
  if (typeof c == "string") return c;
  if (c === void 0) return "";
  let o = "";
  if (t) {
    o += e;
    for (let i = 0; i < t; i++) o += "  "
  }
  if (o += c.messageText, t++, c.next)
    for (const i of c.next) o += A(i, e, t);
  return o
}

function _(c) {
  return c ? c.map(e => e.text).join("") : ""
}
class y {
  constructor(e) {
    this._worker = e
  }
  _textSpanToRange(e, t) {
    let o = e.getPositionAt(t.start),
      i = e.getPositionAt(t.start + t.length),
      {
        lineNumber: l,
        column: p
      } = o,
      {
        lineNumber: n,
        column: r
      } = i;
    return {
      startLineNumber: l,
      startColumn: p,
      endLineNumber: n,
      endColumn: r
    }
  }
}
class H {
  constructor(e) {
    this._worker = e, this._libFiles = {}, this._hasFetchedLibFiles = !1, this._fetchLibFilesPromise = null
  }
  isLibFile(e) {
    return e && e.path.indexOf("/lib.") === 0 ? !!s[e.path.slice(1)] : !1
  }
  getOrCreateModel(e) {
    const t = F.parse(e),
      o = w.getModel(t);
    if (o) return o;
    if (this.isLibFile(t) && this._hasFetchedLibFiles) return w.createModel(this._libFiles[t.path.slice(1)], "typescript", t);
    const i = K.getExtraLibs()[e];
    return i ? w.createModel(i.content, "typescript", t) : null
  }
  _containsLibFile(e) {
    for (let t of e)
      if (this.isLibFile(t)) return !0;
    return !1
  }
  async fetchLibFilesIfNecessary(e) {
    this._containsLibFile(e) && await this._fetchLibFiles()
  }
  _fetchLibFiles() {
    return this._fetchLibFilesPromise || (this._fetchLibFilesPromise = this._worker().then(e => e.getLibFiles()).then(e => {
      this._hasFetchedLibFiles = !0, this._libFiles = e
    })), this._fetchLibFilesPromise
  }
}
class W extends y {
  constructor(e, t, o, i) {
    super(i), this._libFiles = e, this._defaults = t, this._selector = o, this._disposables = [], this._listener = Object.create(null);
    const l = r => {
        if (r.getLanguageId() !== o) return;
        const u = () => {
          const {
            onlyVisible: h
          } = this._defaults.getDiagnosticsOptions();
          h ? r.isAttachedToEditor() && this._doValidate(r) : this._doValidate(r)
        };
        let d;
        const g = r.onDidChangeContent(() => {
            clearTimeout(d), d = window.setTimeout(u, 500)
          }),
          b = r.onDidChangeAttached(() => {
            const {
              onlyVisible: h
            } = this._defaults.getDiagnosticsOptions();
            h && (r.isAttachedToEditor() ? u() : w.setModelMarkers(r, this._selector, []))
          });
        this._listener[r.uri.toString()] = {
          dispose() {
            g.dispose(), b.dispose(), clearTimeout(d)
          }
        }, u()
      },
      p = r => {
        w.setModelMarkers(r, this._selector, []);
        const u = r.uri.toString();
        this._listener[u] && (this._listener[u].dispose(), delete this._listener[u])
      };
    this._disposables.push(w.onDidCreateModel(r => l(r))), this._disposables.push(w.onWillDisposeModel(p)), this._disposables.push(w.onDidChangeModelLanguage(r => {
      p(r.model), l(r.model)
    })), this._disposables.push({
      dispose() {
        for (const r of w.getModels()) p(r)
      }
    });
    const n = () => {
      for (const r of w.getModels()) p(r), l(r)
    };
    this._disposables.push(this._defaults.onDidChange(n)), this._disposables.push(this._defaults.onDidExtraLibsChange(n)), w.getModels().forEach(r => l(r))
  }
  dispose() {
    this._disposables.forEach(e => e && e.dispose()), this._disposables = []
  }
  async _doValidate(e) {
    const t = await this._worker(e.uri);
    if (e.isDisposed()) return;
    const o = [],
      {
        noSyntaxValidation: i,
        noSemanticValidation: l,
        noSuggestionDiagnostics: p
      } = this._defaults.getDiagnosticsOptions();
    i || o.push(t.getSyntacticDiagnostics(e.uri.toString())), l || o.push(t.getSemanticDiagnostics(e.uri.toString())), p || o.push(t.getSuggestionDiagnostics(e.uri.toString()));
    const n = await Promise.all(o);
    if (!n || e.isDisposed()) return;
    const r = n.reduce((d, g) => g.concat(d), []).filter(d => (this._defaults.getDiagnosticsOptions().diagnosticCodesToIgnore || []).indexOf(d.code) === -1),
      u = r.map(d => d.relatedInformation || []).reduce((d, g) => g.concat(d), []).map(d => d.file ? F.parse(d.file.fileName) : null);
    await this._libFiles.fetchLibFilesIfNecessary(u), !e.isDisposed() && w.setModelMarkers(e, this._selector, r.map(d => this._convertDiagnostics(e, d)))
  }
  _convertDiagnostics(e, t) {
    const o = t.start || 0,
      i = t.length || 1,
      {
        lineNumber: l,
        column: p
      } = e.getPositionAt(o),
      {
        lineNumber: n,
        column: r
      } = e.getPositionAt(o + i),
      u = [];
    return t.reportsUnnecessary && u.push(P.Unnecessary), t.reportsDeprecated && u.push(P.Deprecated), {
      severity: this._tsDiagnosticCategoryToMarkerSeverity(t.category),
      startLineNumber: l,
      startColumn: p,
      endLineNumber: n,
      endColumn: r,
      message: A(t.messageText, `
`),
      code: t.code.toString(),
      tags: u,
      relatedInformation: this._convertRelatedInformation(e, t.relatedInformation)
    }
  }
  _convertRelatedInformation(e, t) {
    if (!t) return [];
    const o = [];
    return t.forEach(i => {
      let l = e;
      if (i.file && (l = this._libFiles.getOrCreateModel(i.file.fileName)), !l) return;
      const p = i.start || 0,
        n = i.length || 1,
        {
          lineNumber: r,
          column: u
        } = l.getPositionAt(p),
        {
          lineNumber: d,
          column: g
        } = l.getPositionAt(p + n);
      o.push({
        resource: l.uri,
        startLineNumber: r,
        startColumn: u,
        endLineNumber: d,
        endColumn: g,
        message: A(i.messageText, `
`)
      })
    }), o
  }
  _tsDiagnosticCategoryToMarkerSeverity(e) {
    switch (e) {
      case 1:
        return v.Error;
      case 3:
        return v.Info;
      case 0:
        return v.Warning;
      case 2:
        return v.Hint
    }
    return v.Info
  }
}
class C extends y {
  get triggerCharacters() {
    return ["."]
  }
  async provideCompletionItems(e, t, o, i) {
    const l = e.getWordUntilPosition(t),
      p = new O(t.lineNumber, l.startColumn, t.lineNumber, l.endColumn),
      n = e.uri,
      r = e.getOffsetAt(t),
      u = await this._worker(n);
    if (e.isDisposed()) return;
    const d = await u.getCompletionsAtPosition(n.toString(), r);
    return !d || e.isDisposed() ? void 0 : {
      suggestions: d.entries.map(b => {
        let h = p;
        if (b.replacementSpan) {
          const x = e.getPositionAt(b.replacementSpan.start),
            D = e.getPositionAt(b.replacementSpan.start + b.replacementSpan.length);
          h = new O(x.lineNumber, x.column, D.lineNumber, D.column)
        }
        const k = [];
        return b.kindModifiers !== void 0 && b.kindModifiers.indexOf("deprecated") !== -1 && k.push(f.CompletionItemTag.Deprecated), {
          uri: n,
          position: t,
          offset: r,
          range: h,
          label: b.name,
          insertText: b.name,
          sortText: b.sortText,
          kind: C.convertKind(b.kind),
          tags: k
        }
      })
    }
  }
  async resolveCompletionItem(e, t) {
    const o = e,
      i = o.uri,
      l = o.position,
      p = o.offset,
      r = await (await this._worker(i)).getCompletionEntryDetails(i.toString(), p, o.label);
    return r ? {
      uri: i,
      position: l,
      label: r.name,
      kind: C.convertKind(r.kind),
      detail: _(r.displayParts),
      documentation: {
        value: C.createDocumentationString(r)
      }
    } : o
  }
  static convertKind(e) {
    switch (e) {
      case a.primitiveType:
      case a.keyword:
        return f.CompletionItemKind.Keyword;
      case a.variable:
      case a.localVariable:
        return f.CompletionItemKind.Variable;
      case a.memberVariable:
      case a.memberGetAccessor:
      case a.memberSetAccessor:
        return f.CompletionItemKind.Field;
      case a.function:
      case a.memberFunction:
      case a.constructSignature:
      case a.callSignature:
      case a.indexSignature:
        return f.CompletionItemKind.Function;
      case a.enum:
        return f.CompletionItemKind.Enum;
      case a.module:
        return f.CompletionItemKind.Module;
      case a.class:
        return f.CompletionItemKind.Class;
      case a.interface:
        return f.CompletionItemKind.Interface;
      case a.warning:
        return f.CompletionItemKind.File
    }
    return f.CompletionItemKind.Property
  }
  static createDocumentationString(e) {
    let t = _(e.documentation);
    if (e.tags)
      for (const o of e.tags) t += `

${N(o)}`;
    return t
  }
}

function N(c) {
  let e = `*@${c.name}*`;
  if (c.name === "param" && c.text) {
    const [t, ...o] = c.text;
    e += `\`${t.text}\``, o.length > 0 && (e += ` — ${o.map(i=>i.text).join(" ")}`)
  } else Array.isArray(c.text) ? e += ` — ${c.text.map(t=>t.text).join(" ")}` : c.text && (e += ` — ${c.text}`);
  return e
}
class I extends y {
  constructor() {
    super(...arguments), this.signatureHelpTriggerCharacters = ["(", ","]
  }
  static _toSignatureHelpTriggerReason(e) {
    switch (e.triggerKind) {
      case f.SignatureHelpTriggerKind.TriggerCharacter:
        return e.triggerCharacter ? e.isRetrigger ? {
          kind: "retrigger",
          triggerCharacter: e.triggerCharacter
        } : {
          kind: "characterTyped",
          triggerCharacter: e.triggerCharacter
        } : {
          kind: "invoked"
        };
      case f.SignatureHelpTriggerKind.ContentChange:
        return e.isRetrigger ? {
          kind: "retrigger"
        } : {
          kind: "invoked"
        };
      case f.SignatureHelpTriggerKind.Invoke:
      default:
        return {
          kind: "invoked"
        }
    }
  }
  async provideSignatureHelp(e, t, o, i) {
    const l = e.uri,
      p = e.getOffsetAt(t),
      n = await this._worker(l);
    if (e.isDisposed()) return;
    const r = await n.getSignatureHelpItems(l.toString(), p, {
      triggerReason: I._toSignatureHelpTriggerReason(i)
    });
    if (!r || e.isDisposed()) return;
    const u = {
      activeSignature: r.selectedItemIndex,
      activeParameter: r.argumentIndex,
      signatures: []
    };
    return r.items.forEach(d => {
      const g = {
        label: "",
        parameters: []
      };
      g.documentation = {
        value: _(d.documentation)
      }, g.label += _(d.prefixDisplayParts), d.parameters.forEach((b, h, k) => {
        const x = _(b.displayParts),
          D = {
            label: x,
            documentation: {
              value: _(b.documentation)
            }
          };
        g.label += x, g.parameters.push(D), h < k.length - 1 && (g.label += _(d.separatorDisplayParts))
      }), g.label += _(d.suffixDisplayParts), u.signatures.push(g)
    }), {
      value: u,
      dispose() {}
    }
  }
}
class V extends y {
  async provideHover(e, t, o) {
    const i = e.uri,
      l = e.getOffsetAt(t),
      p = await this._worker(i);
    if (e.isDisposed()) return;
    const n = await p.getQuickInfoAtPosition(i.toString(), l);
    if (!n || e.isDisposed()) return;
    const r = _(n.documentation),
      u = n.tags ? n.tags.map(g => N(g)).join(`  

`) : "",
      d = _(n.displayParts);
    return {
      range: this._textSpanToRange(e, n.textSpan),
      contents: [{
        value: "```typescript\n" + d + "\n```\n"
      }, {
        value: r + (u ? `

` + u : "")
      }]
    }
  }
}
class j extends y {
  async provideDocumentHighlights(e, t, o) {
    const i = e.uri,
      l = e.getOffsetAt(t),
      p = await this._worker(i);
    if (e.isDisposed()) return;
    const n = await p.getDocumentHighlights(i.toString(), l, [i.toString()]);
    if (!(!n || e.isDisposed())) return n.flatMap(r => r.highlightSpans.map(u => ({
      range: this._textSpanToRange(e, u.textSpan),
      kind: u.kind === "writtenReference" ? f.DocumentHighlightKind.Write : f.DocumentHighlightKind.Text
    })))
  }
}
class B extends y {
  constructor(e, t) {
    super(t), this._libFiles = e
  }
  async provideDefinition(e, t, o) {
    const i = e.uri,
      l = e.getOffsetAt(t),
      p = await this._worker(i);
    if (e.isDisposed()) return;
    const n = await p.getDefinitionAtPosition(i.toString(), l);
    if (!n || e.isDisposed() || (await this._libFiles.fetchLibFilesIfNecessary(n.map(u => F.parse(u.fileName))), e.isDisposed())) return;
    const r = [];
    for (let u of n) {
      const d = this._libFiles.getOrCreateModel(u.fileName);
      d && r.push({
        uri: d.uri,
        range: this._textSpanToRange(d, u.textSpan)
      })
    }
    return r
  }
}
class U extends y {
  constructor(e, t) {
    super(t), this._libFiles = e
  }
  async provideReferences(e, t, o, i) {
    const l = e.uri,
      p = e.getOffsetAt(t),
      n = await this._worker(l);
    if (e.isDisposed()) return;
    const r = await n.getReferencesAtPosition(l.toString(), p);
    if (!r || e.isDisposed() || (await this._libFiles.fetchLibFilesIfNecessary(r.map(d => F.parse(d.fileName))), e.isDisposed())) return;
    const u = [];
    for (let d of r) {
      const g = this._libFiles.getOrCreateModel(d.fileName);
      g && u.push({
        uri: g.uri,
        range: this._textSpanToRange(g, d.textSpan)
      })
    }
    return u
  }
}
class $ extends y {
  async provideDocumentSymbols(e, t) {
    const o = e.uri,
      i = await this._worker(o);
    if (e.isDisposed()) return;
    const l = await i.getNavigationTree(o.toString());
    if (!l || e.isDisposed()) return;
    const p = (r, u) => {
      var g;
      return {
        name: r.text,
        detail: "",
        kind: m[r.kind] || f.SymbolKind.Variable,
        range: this._textSpanToRange(e, r.spans[0]),
        selectionRange: this._textSpanToRange(e, r.spans[0]),
        tags: [],
        children: (g = r.childItems) == null ? void 0 : g.map(b => p(b, r.text)),
        containerName: u
      }
    };
    return l.childItems ? l.childItems.map(r => p(r)) : []
  }
}
class a {}
a.unknown = "";
a.keyword = "keyword";
a.script = "script";
a.module = "module";
a.class = "class";
a.interface = "interface";
a.type = "type";
a.enum = "enum";
a.variable = "var";
a.localVariable = "local var";
a.function = "function";
a.localFunction = "local function";
a.memberFunction = "method";
a.memberGetAccessor = "getter";
a.memberSetAccessor = "setter";
a.memberVariable = "property";
a.constructorImplementation = "constructor";
a.callSignature = "call";
a.indexSignature = "index";
a.constructSignature = "construct";
a.parameter = "parameter";
a.typeParameter = "type parameter";
a.primitiveType = "primitive type";
a.label = "label";
a.alias = "alias";
a.const = "const";
a.let = "let";
a.warning = "warning";
let m = Object.create(null);
m[a.module] = f.SymbolKind.Module;
m[a.class] = f.SymbolKind.Class;
m[a.enum] = f.SymbolKind.Enum;
m[a.interface] = f.SymbolKind.Interface;
m[a.memberFunction] = f.SymbolKind.Method;
m[a.memberVariable] = f.SymbolKind.Property;
m[a.memberGetAccessor] = f.SymbolKind.Property;
m[a.memberSetAccessor] = f.SymbolKind.Property;
m[a.variable] = f.SymbolKind.Variable;
m[a.const] = f.SymbolKind.Variable;
m[a.localVariable] = f.SymbolKind.Variable;
m[a.variable] = f.SymbolKind.Variable;
m[a.function] = f.SymbolKind.Function;
m[a.localFunction] = f.SymbolKind.Function;
class S extends y {
  static _convertOptions(e) {
    return {
      ConvertTabsToSpaces: e.insertSpaces,
      TabSize: e.tabSize,
      IndentSize: e.tabSize,
      IndentStyle: 2,
      NewLineCharacter: `
`,
      InsertSpaceAfterCommaDelimiter: !0,
      InsertSpaceAfterSemicolonInForStatements: !0,
      InsertSpaceBeforeAndAfterBinaryOperators: !0,
      InsertSpaceAfterKeywordsInControlFlowStatements: !0,
      InsertSpaceAfterFunctionKeywordForAnonymousFunctions: !0,
      InsertSpaceAfterOpeningAndBeforeClosingNonemptyParenthesis: !1,
      InsertSpaceAfterOpeningAndBeforeClosingNonemptyBrackets: !1,
      InsertSpaceAfterOpeningAndBeforeClosingTemplateStringBraces: !1,
      PlaceOpenBraceOnNewLineForControlBlocks: !1,
      PlaceOpenBraceOnNewLineForFunctions: !1
    }
  }
  _convertTextChanges(e, t) {
    return {
      text: t.newText,
      range: this._textSpanToRange(e, t.span)
    }
  }
}
class z extends S {
  constructor() {
    super(...arguments), this.canFormatMultipleRanges = !1
  }
  async provideDocumentRangeFormattingEdits(e, t, o, i) {
    const l = e.uri,
      p = e.getOffsetAt({
        lineNumber: t.startLineNumber,
        column: t.startColumn
      }),
      n = e.getOffsetAt({
        lineNumber: t.endLineNumber,
        column: t.endColumn
      }),
      r = await this._worker(l);
    if (e.isDisposed()) return;
    const u = await r.getFormattingEditsForRange(l.toString(), p, n, S._convertOptions(o));
    if (!(!u || e.isDisposed())) return u.map(d => this._convertTextChanges(e, d))
  }
}
class G extends S {
  get autoFormatTriggerCharacters() {
    return [";", "}", `
`]
  }
  async provideOnTypeFormattingEdits(e, t, o, i, l) {
    const p = e.uri,
      n = e.getOffsetAt(t),
      r = await this._worker(p);
    if (e.isDisposed()) return;
    const u = await r.getFormattingEditsAfterKeystroke(p.toString(), n, o, S._convertOptions(i));
    if (!(!u || e.isDisposed())) return u.map(d => this._convertTextChanges(e, d))
  }
}
class J extends S {
  async provideCodeActions(e, t, o, i) {
    const l = e.uri,
      p = e.getOffsetAt({
        lineNumber: t.startLineNumber,
        column: t.startColumn
      }),
      n = e.getOffsetAt({
        lineNumber: t.endLineNumber,
        column: t.endColumn
      }),
      r = S._convertOptions(e.getOptions()),
      u = o.markers.filter(h => h.code).map(h => h.code).map(Number),
      d = await this._worker(l);
    if (e.isDisposed()) return;
    const g = await d.getCodeFixesAtPosition(l.toString(), p, n, u, r);
    return !g || e.isDisposed() ? {
      actions: [],
      dispose: () => {}
    } : {
      actions: g.filter(h => h.changes.filter(k => k.isNewFile).length === 0).map(h => this._tsCodeFixActionToMonacoCodeAction(e, o, h)),
      dispose: () => {}
    }
  }
  _tsCodeFixActionToMonacoCodeAction(e, t, o) {
    const i = [];
    for (const p of o.changes)
      for (const n of p.textChanges) i.push({
        resource: e.uri,
        versionId: void 0,
        textEdit: {
          range: this._textSpanToRange(e, n.span),
          text: n.newText
        }
      });
    return {
      title: o.description,
      edit: {
        edits: i
      },
      diagnostics: t.markers,
      kind: "quickfix"
    }
  }
}
class q extends y {
  constructor(e, t) {
    super(t), this._libFiles = e
  }
  async provideRenameEdits(e, t, o, i) {
    const l = e.uri,
      p = l.toString(),
      n = e.getOffsetAt(t),
      r = await this._worker(l);
    if (e.isDisposed()) return;
    const u = await r.getRenameInfo(p, n, {
      allowRenameOfImportPath: !1
    });
    if (u.canRename === !1) return {
      edits: [],
      rejectReason: u.localizedErrorMessage
    };
    if (u.fileToRename !== void 0) throw new Error("Renaming files is not supported.");
    const d = await r.findRenameLocations(p, n, !1, !1, !1);
    if (!d || e.isDisposed()) return;
    const g = [];
    for (const b of d) {
      const h = this._libFiles.getOrCreateModel(b.fileName);
      if (h) g.push({
        resource: h.uri,
        versionId: void 0,
        textEdit: {
          range: this._textSpanToRange(h, b.textSpan),
          text: o
        }
      });
      else throw new Error(`Unknown file ${b.fileName}.`)
    }
    return {
      edits: g
    }
  }
}
class Q extends y {
  async provideInlayHints(e, t, o) {
    const i = e.uri,
      l = i.toString(),
      p = e.getOffsetAt({
        lineNumber: t.startLineNumber,
        column: t.startColumn
      }),
      n = e.getOffsetAt({
        lineNumber: t.endLineNumber,
        column: t.endColumn
      }),
      r = await this._worker(i);
    return e.isDisposed() ? null : {
      hints: (await r.provideInlayHints(l, p, n)).map(g => ({
        ...g,
        label: g.text,
        position: e.getPositionAt(g.position),
        kind: this._convertHintKind(g.kind)
      })),
      dispose: () => {}
    }
  }
  _convertHintKind(e) {
    switch (e) {
      case "Parameter":
        return f.InlayHintKind.Parameter;
      case "Type":
        return f.InlayHintKind.Type;
      default:
        return f.InlayHintKind.Type
    }
  }
}
let T, L;

function Z(c) {
  L = R(c, "typescript")
}

function ee(c) {
  T = R(c, "javascript")
}

function te() {
  return new Promise((c, e) => {
    if (!T) return e("JavaScript not registered!");
    c(T)
  })
}

function se() {
  return new Promise((c, e) => {
    if (!L) return e("TypeScript not registered!");
    c(L)
  })
}

function R(c, e) {
  const t = [],
    o = new E(e, c),
    i = (...n) => o.getLanguageServiceWorker(...n),
    l = new H(i);

  function p() {
    const {
      modeConfiguration: n
    } = c;
    X(t), n.completionItems && t.push(f.registerCompletionItemProvider(e, new C(i))), n.signatureHelp && t.push(f.registerSignatureHelpProvider(e, new I(i))), n.hovers && t.push(f.registerHoverProvider(e, new V(i))), n.documentHighlights && t.push(f.registerDocumentHighlightProvider(e, new j(i))), n.definitions && t.push(f.registerDefinitionProvider(e, new B(l, i))), n.references && t.push(f.registerReferenceProvider(e, new U(l, i))), n.documentSymbols && t.push(f.registerDocumentSymbolProvider(e, new $(i))), n.rename && t.push(f.registerRenameProvider(e, new q(l, i))), n.documentRangeFormattingEdits && t.push(f.registerDocumentRangeFormattingEditProvider(e, new z(i))), n.onTypeFormattingEdits && t.push(f.registerOnTypeFormattingEditProvider(e, new G(i))), n.codeActions && t.push(f.registerCodeActionProvider(e, new J(i))), n.inlayHints && t.push(f.registerInlayHintsProvider(e, new Q(i))), n.diagnostics && t.push(new W(l, c, e, i))
  }
  return p(), i
}

function X(c) {
  for (; c.length;) c.pop().dispose()
}
export {
  y as Adapter, J as CodeActionAdaptor, B as DefinitionAdapter, W as DiagnosticsAdapter, j as DocumentHighlightAdapter, z as FormatAdapter, S as FormatHelper, G as FormatOnTypeAdapter, Q as InlayHintsAdapter, a as Kind, H as LibFiles, $ as OutlineAdapter, V as QuickInfoAdapter, U as ReferenceAdapter, q as RenameAdapter, I as SignatureHelpAdapter, C as SuggestAdapter, E as WorkerManager, A as flattenDiagnosticMessageText, te as getJavaScriptWorker, se as getTypeScriptWorker, ee as setupJavaScript, Z as setupTypeScript
};