var Ve = Object.defineProperty;
var me = t => {
  throw TypeError(t)
};
var Be = (t, e, r) => e in t ? Ve(t, e, {
  enumerable: !0,
  configurable: !0,
  writable: !0,
  value: r
}) : t[e] = r;
var K = (t, e, r) => Be(t, typeof e != "symbol" ? e + "" : e, r),
  ae = (t, e, r) => e.has(t) || me("Cannot " + r);
var s = (t, e, r) => (ae(t, e, "read from private field"), r ? r.call(t) : e.get(t)),
  d = (t, e, r) => e.has(t) ? me("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, r),
  f = (t, e, r, i) => (ae(t, e, "write to private field"), i ? i.call(t, r) : e.set(t, r), r),
  _ = (t, e, r) => (ae(t, e, "access private method"), r);
import {
  a7 as We,
  m as Se,
  R as je,
  a8 as Re,
  S as $e,
  a9 as ye,
  aa as $,
  k as v,
  h as N,
  T as I,
  ab as be,
  d as Ye,
  b as De,
  ac as qe,
  ad as Ee,
  K as F,
  J as Y,
  I as oe,
  M as P,
  N as ze,
  ae as Ge,
  af as re,
  ag as se,
  ah as Te,
  ai as Ue,
  aj as Je,
  ak as Me,
  P as Oe,
  al as Ke,
  G as fe,
  i as q,
  am as Xe,
  g as Qe,
  an as X,
  E as Ze,
  ao as et,
  ap as tt,
  aq as rt,
  D as st,
  ar as nt,
  o as it,
  as as at,
  at as z,
  au as ot,
  av as ft,
  aw as ut,
  ax as lt,
  ay as ct,
  az as dt,
  aA as le,
  aB as Ie,
  H as ht,
  aC as _t,
  aD as ce,
  j as Q,
  aE as pt,
  aF as vt,
  aG as gt,
  aH as mt,
  p as yt,
  aI as bt,
  aJ as Et,
  a as Tt
} from "./BZGnCJ3u.js";

function wt(t) {
  let e = 0,
    r = Re(0),
    i;
  return () => {
    We() && (Se(r), je(() => (e === 0 && (i = $e(() => t(() => ye(r)))), e += 1, () => {
      $(() => {
        e -= 1, e === 0 && (i == null || i(), i = void 0, ye(r))
      })
    })))
  }
}
var Nt = Ze | et;

function kt(t, e, r, i) {
  new At(t, e, r, i)
}
var T, G, k, x, m, A, p, w, R, V, O, W, U, J, D, ne, u, Le, Ce, Fe, de, ee, te, he, _e;
class At {
  constructor(e, r, i, o) {
    d(this, u);
    K(this, "parent");
    K(this, "is_pending", !1);
    K(this, "transform_error");
    d(this, T);
    d(this, G, N ? v : null);
    d(this, k);
    d(this, x);
    d(this, m);
    d(this, A, null);
    d(this, p, null);
    d(this, w, null);
    d(this, R, null);
    d(this, V, 0);
    d(this, O, 0);
    d(this, W, !1);
    d(this, U, new Set);
    d(this, J, new Set);
    d(this, D, null);
    d(this, ne, wt(() => (f(this, D, Re(s(this, V))), () => {
      f(this, D, null)
    })));
    var n;
    f(this, T, e), f(this, k, r), f(this, x, a => {
      var c = I;
      c.b = this, c.f |= be, i(a)
    }), this.parent = I.b, this.transform_error = o ?? ((n = this.parent) == null ? void 0 : n.transform_error) ?? (a => a), f(this, m, Ye(() => {
      if (N) {
        const a = s(this, G);
        De();
        const c = a.data === qe;
        if (a.data.startsWith(Ee)) {
          const h = JSON.parse(a.data.slice(Ee.length));
          _(this, u, Ce).call(this, h)
        } else c ? _(this, u, Fe).call(this) : _(this, u, Le).call(this)
      } else _(this, u, de).call(this)
    }, Nt)), N && f(this, T, v)
  }
  defer_effect(e) {
    Ge(e, s(this, U), s(this, J))
  }
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered())
  }
  has_pending_snippet() {
    return !!s(this, k).pending
  }
  update_pending_count(e, r) {
    _(this, u, he).call(this, e, r), f(this, V, s(this, V) + e), !(!s(this, D) || s(this, W)) && (f(this, W, !0), $(() => {
      f(this, W, !1), s(this, D) && Ke(s(this, D), s(this, V))
    }))
  }
  get_effect_pending() {
    return s(this, ne).call(this), Se(s(this, D))
  }
  error(e) {
    var r;
    if (!s(this, k).onerror && !s(this, k).failed) throw e;
    (r = P) != null && r.is_fork ? (s(this, A) && P.skip_effect(s(this, A)), s(this, p) && P.skip_effect(s(this, p)), s(this, w) && P.skip_effect(s(this, w)), P.on_fork_commit(() => {
      _(this, u, _e).call(this, e)
    })) : _(this, u, _e).call(this, e)
  }
}
T = new WeakMap, G = new WeakMap, k = new WeakMap, x = new WeakMap, m = new WeakMap, A = new WeakMap, p = new WeakMap, w = new WeakMap, R = new WeakMap, V = new WeakMap, O = new WeakMap, W = new WeakMap, U = new WeakMap, J = new WeakMap, D = new WeakMap, ne = new WeakMap, u = new WeakSet, Le = function() {
  try {
    f(this, A, F(() => s(this, x).call(this, s(this, T))))
  } catch (e) {
    this.error(e)
  }
}, Ce = function(e) {
  const r = s(this, k).failed;
  r && f(this, w, F(() => {
    r(s(this, T), () => e, () => () => {})
  }))
}, Fe = function() {
  const e = s(this, k).pending;
  e && (this.is_pending = !0, f(this, p, F(() => e(s(this, T)))), $(() => {
    var r = f(this, R, document.createDocumentFragment()),
      i = Y();
    r.append(i), f(this, A, _(this, u, te).call(this, () => F(() => s(this, x).call(this, i)))), s(this, O) === 0 && (s(this, T).before(r), f(this, R, null), oe(s(this, p), () => {
      f(this, p, null)
    }), _(this, u, ee).call(this, P))
  }))
}, de = function() {
  try {
    if (this.is_pending = this.has_pending_snippet(), f(this, O, 0), f(this, V, 0), f(this, A, F(() => {
        s(this, x).call(this, s(this, T))
      })), s(this, O) > 0) {
      var e = f(this, R, document.createDocumentFragment());
      ze(s(this, A), e);
      const r = s(this, k).pending;
      f(this, p, F(() => r(s(this, T))))
    } else _(this, u, ee).call(this, P)
  } catch (r) {
    this.error(r)
  }
}, ee = function(e) {
  this.is_pending = !1, e.transfer_effects(s(this, U), s(this, J))
}, te = function(e) {
  var r = I,
    i = Me,
    o = Oe;
  re(s(this, m)), se(s(this, m)), Te(s(this, m).ctx);
  try {
    return Ue.ensure(), e()
  } catch (n) {
    return Je(n), null
  } finally {
    re(r), se(i), Te(o)
  }
}, he = function(e, r) {
  var i;
  if (!this.has_pending_snippet()) {
    this.parent && _(i = this.parent, u, he).call(i, e, r);
    return
  }
  f(this, O, s(this, O) + e), s(this, O) === 0 && (_(this, u, ee).call(this, r), s(this, p) && oe(s(this, p), () => {
    f(this, p, null)
  }), s(this, R) && (s(this, T).before(s(this, R)), f(this, R, null)))
}, _e = function(e) {
  s(this, A) && (fe(s(this, A)), f(this, A, null)), s(this, p) && (fe(s(this, p)), f(this, p, null)), s(this, w) && (fe(s(this, w)), f(this, w, null)), N && (q(s(this, G)), Xe(), q(Qe()));
  var r = s(this, k).onerror;
  let i = s(this, k).failed;
  var o = !1,
    n = !1;
  const a = () => {
      if (o) {
        rt();
        return
      }
      o = !0, n && tt(), s(this, w) !== null && oe(s(this, w), () => {
        f(this, w, null)
      }), _(this, u, te).call(this, () => {
        _(this, u, de).call(this)
      })
    },
    c = l => {
      try {
        n = !0, r == null || r(l, a), n = !1
      } catch (h) {
        X(h, s(this, m) && s(this, m).parent)
      }
      i && f(this, w, _(this, u, te).call(this, () => {
        try {
          return F(() => {
            var h = I;
            h.b = this, h.f |= be, i(s(this, T), () => l, () => a)
          })
        } catch (h) {
          return X(h, s(this, m).parent), null
        }
      }))
    };
  $(() => {
    var l;
    try {
      l = this.transform_error(e)
    } catch (h) {
      X(h, s(this, m) && s(this, m).parent);
      return
    }
    l !== null && typeof l == "object" && typeof l.then == "function" ? l.then(c, h => X(h, s(this, m) && s(this, m).parent)) : c(l)
  })
};

function xt(t) {
  return t.endsWith("capture") && t !== "gotpointercapture" && t !== "lostpointercapture"
}
const St = ["beforeinput", "click", "change", "dblclick", "contextmenu", "focusin", "focusout", "input", "keydown", "keyup", "mousedown", "mousemove", "mouseout", "mouseover", "mouseup", "pointerdown", "pointermove", "pointerout", "pointerover", "pointerup", "touchend", "touchmove", "touchstart"];

function Vt(t) {
  return St.includes(t)
}
const Rt = {
  formnovalidate: "formNoValidate",
  ismap: "isMap",
  nomodule: "noModule",
  playsinline: "playsInline",
  readonly: "readOnly",
  defaultvalue: "defaultValue",
  defaultchecked: "defaultChecked",
  srcobject: "srcObject",
  novalidate: "noValidate",
  allowfullscreen: "allowFullscreen",
  disablepictureinpicture: "disablePictureInPicture",
  disableremoteplayback: "disableRemotePlayback"
};

function Bt(t) {
  return t = t.toLowerCase(), Rt[t] ?? t
}
const Dt = ["touchstart", "touchmove"];

function Mt(t) {
  return Dt.includes(t)
}
const H = Symbol("events"),
  Pe = new Set,
  pe = new Set;

function Wt(t) {
  if (!N) return;
  t.removeAttribute("onload"), t.removeAttribute("onerror");
  const e = t.__e;
  e !== void 0 && (t.__e = void 0, queueMicrotask(() => {
    t.isConnected && t.dispatchEvent(e)
  }))
}

function Ot(t, e, r, i = {}) {
  function o(n) {
    if (i.capture || ve.call(e, n), !n.cancelBubble) return nt(() => r == null ? void 0 : r.call(this, n))
  }
  return t.startsWith("pointer") || t.startsWith("touch") || t === "wheel" ? $(() => {
    e.addEventListener(t, o, i)
  }) : e.addEventListener(t, o, i), o
}

function jt(t, e, r, i, o) {
  var n = {
      capture: i,
      passive: o
    },
    a = Ot(t, e, r, n);
  (e === document.body || e === window || e === document || e instanceof HTMLMediaElement) && st(() => {
    e.removeEventListener(t, a, n)
  })
}

function $t(t, e, r) {
  (e[H] ?? (e[H] = {}))[t] = r
}

function Yt(t) {
  for (var e = 0; e < t.length; e++) Pe.add(t[e]);
  for (var r of pe) r(t)
}
let we = null;

function ve(t) {
  var L, E;
  var e = this,
    r = e.ownerDocument,
    i = t.type,
    o = ((L = t.composedPath) == null ? void 0 : L.call(t)) || [],
    n = o[0] || t.target;
  we = t;
  var a = 0,
    c = we === t && t[H];
  if (c) {
    var l = o.indexOf(c);
    if (l !== -1 && (e === document || e === window)) {
      t[H] = e;
      return
    }
    var h = o.indexOf(e);
    if (h === -1) return;
    l <= h && (a = l)
  }
  if (n = o[a] || t.target, n !== e) {
    it(t, "currentTarget", {
      configurable: !0,
      get() {
        return n || r
      }
    });
    var B = Me,
      j = I;
    se(null), re(null);
    try {
      for (var M, y = []; n !== null;) {
        var g = n.assignedSlot || n.parentNode || n.host || null;
        try {
          var b = (E = n[H]) == null ? void 0 : E[i];
          b != null && (!n.disabled || t.target === n) && b.call(n, t)
        } catch (C) {
          M ? y.push(C) : M = C
        }
        if (t.cancelBubble || g === e || g === null) break;
        n = g
      }
      if (M) {
        for (let C of y) queueMicrotask(() => {
          throw C
        });
        throw M
      }
    } finally {
      t[H] = e, delete t.currentTarget, se(B), re(j)
    }
  }
}
var ke;
const ue = ((ke = globalThis == null ? void 0 : globalThis.window) == null ? void 0 : ke.trustedTypes) && globalThis.window.trustedTypes.createPolicy("svelte-trusted-html", {
  createHTML: t => t
});

function It(t) {
  return (ue == null ? void 0 : ue.createHTML(t)) ?? t
}

function He(t) {
  var e = at("template");
  return e.innerHTML = It(t.replaceAll("<!>", "<!---->")), e.content
}

function S(t, e) {
  var r = I;
  r.nodes === null && (r.nodes = {
    start: t,
    end: e,
    a: null,
    t: null
  })
}

function qt(t, e) {
  var r = (e & ft) !== 0,
    i = (e & ut) !== 0,
    o, n = !t.startsWith("<!>");
  return () => {
    if (N) return S(v, null), v;
    o === void 0 && (o = He(n ? t : "<!>" + t), r || (o = z(o)));
    var a = i || ot ? document.importNode(o, !0) : o.cloneNode(!0);
    if (r) {
      var c = z(a),
        l = a.lastChild;
      S(c, l)
    } else S(a, a);
    return a
  }
}

function Lt(t, e, r = "svg") {
  var i = !t.startsWith("<!>"),
    o = `<${r}>${i?t:"<!>"+t}</${r}>`,
    n;
  return () => {
    if (N) return S(v, null), v;
    if (!n) {
      var a = He(o),
        c = z(a);
      n = z(c)
    }
    var l = n.cloneNode(!0);
    return S(l, l), l
  }
}

function zt(t, e) {
  return Lt(t, e, "svg")
}

function Gt(t = "") {
  if (!N) {
    var e = Y(t + "");
    return S(e, e), e
  }
  var r = v;
  return r.nodeType !== ct ? (r.before(r = Y()), q(r)) : dt(r), S(r, r), r
}

function Ut() {
  if (N) return S(v, null), v;
  var t = document.createDocumentFragment(),
    e = document.createComment(""),
    r = Y();
  return t.append(e, r), S(e, r), t
}

function Jt(t, e) {
  if (N) {
    var r = I;
    ((r.f & lt) === 0 || r.nodes.end === null) && (r.nodes.end = v), De();
    return
  }
  t !== null && t.before(e)
}
let Ne = !0;

function Kt(t, e) {
  var r = e == null ? "" : typeof e == "object" ? `${e}` : e;
  r !== (t.__t ?? (t.__t = t.nodeValue)) && (t.__t = r, t.nodeValue = `${r}`)
}

function Ct(t, e) {
  return xe(t, e)
}

function Xt(t, e) {
  le(), e.intro = e.intro ?? !1;
  const r = e.target,
    i = N,
    o = v;
  try {
    for (var n = z(r); n && (n.nodeType !== Ie || n.data !== ht);) n = _t(n);
    if (!n) throw ce;
    Q(!0), q(n);
    const a = xe(t, {
      ...e,
      anchor: n
    });
    return Q(!1), a
  } catch (a) {
    if (a instanceof Error && a.message.split(`
`).some(c => c.startsWith("https://svelte.dev/e/"))) throw a;
    return a !== ce && console.warn("Failed to hydrate: ", a), e.recover === !1 && pt(), le(), vt(r), Q(!1), Ct(t, e)
  } finally {
    Q(i), q(o)
  }
}
const Z = new Map;

function xe(t, {
  target: e,
  anchor: r,
  props: i = {},
  events: o,
  context: n,
  intro: a = !0,
  transformError: c
}) {
  le();
  var l = void 0,
    h = gt(() => {
      var B = r ?? e.appendChild(Y());
      kt(B, {
        pending: () => {}
      }, y => {
        yt({});
        var g = Oe;
        if (n && (g.c = n), o && (i.$$events = o), N && S(y, null), Ne = a, l = t(y, i) || {}, Ne = !0, N && (I.nodes.end = v, v === null || v.nodeType !== Ie || v.data !== bt)) throw Et(), ce;
        Tt()
      }, c);
      var j = new Set,
        M = y => {
          for (var g = 0; g < y.length; g++) {
            var b = y[g];
            if (!j.has(b)) {
              j.add(b);
              var L = Mt(b);
              for (const ie of [e, document]) {
                var E = Z.get(ie);
                E === void 0 && (E = new Map, Z.set(ie, E));
                var C = E.get(b);
                C === void 0 ? (ie.addEventListener(b, ve, {
                  passive: L
                }), E.set(b, 1)) : E.set(b, C + 1)
              }
            }
          }
        };
      return M(mt(Pe)), pe.add(M), () => {
        var L;
        for (var y of j)
          for (const E of [e, document]) {
            var g = Z.get(E),
              b = g.get(y);
            --b == 0 ? (E.removeEventListener(y, ve), g.delete(y), g.size === 0 && Z.delete(E)) : g.set(y, b)
          }
        pe.delete(M), B !== r && ((L = B.parentNode) == null || L.removeChild(B))
      }
    });
  return ge.set(l, h), l
}
let ge = new WeakMap;

function Qt(t, e) {
  const r = ge.get(t);
  return r ? (ge.delete(t), r(e)) : Promise.resolve()
}
const Ft = "5";
var Ae;
typeof window < "u" && ((Ae = window.__svelte ?? (window.__svelte = {})).v ?? (Ae.v = new Set)).add(Ft);
export {
  Jt as a, $t as b, Ut as c, Yt as d, jt as e, qt as f, zt as g, Xt as h, S as i, Ne as j, xt as k, Ot as l, Ct as m, Bt as n, Vt as o, Wt as r, Kt as s, Gt as t, Qt as u
};