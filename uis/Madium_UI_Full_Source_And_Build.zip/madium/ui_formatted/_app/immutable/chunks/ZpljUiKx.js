var X = Object.defineProperty;
var U = t => {
  throw TypeError(t)
};
var H = (t, e, r) => e in t ? X(t, e, {
  enumerable: !0,
  configurable: !0,
  writable: !0,
  value: r
}) : t[e] = r;
var C = (t, e, r) => H(t, typeof e != "symbol" ? e + "" : e, r),
  $ = (t, e, r) => e.has(t) || U("Cannot " + r);
var i = (t, e, r) => ($(t, e, "read from private field"), r ? r.call(t) : e.get(t)),
  S = (t, e, r) => e.has(t) ? U("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, r),
  M = (t, e, r, s) => ($(t, e, "write to private field"), s ? s.call(t, r) : e.set(t, r), r);
import {
  A as Y,
  q as ee,
  B as te,
  C as re,
  m as O,
  D as se,
  o as ne,
  l as W,
  F as ie,
  G as L,
  I as ae,
  J as F,
  K as q,
  M as fe,
  h as x,
  k as Z,
  N as ue,
  O as ce,
  d as oe,
  b as le,
  E as de,
  e as he,
  g as _e,
  i as ve,
  j,
  P as be,
  Q as pe,
  R as me,
  S as z,
  T as J,
  U as ge,
  V as Q,
  W as Se,
  X as Pe,
  Y as Ee,
  Z as we,
  _ as ye,
  $ as Re,
  a0 as Ae,
  a1 as Ie,
  a2 as Oe,
  a3 as Te,
  a4 as De,
  a5 as Le,
  a6 as xe,
  L as Be
} from "./BZGnCJ3u.js";
let I = !1,
  B = Symbol();

function Fe(t, e, r) {
  const s = r[e] ?? (r[e] = {
    store: null,
    source: ee(void 0),
    unsubscribe: Y
  });
  if (s.store !== t && !(B in r))
    if (s.unsubscribe(), s.store = t ?? null, t == null) s.source.v = void 0, s.unsubscribe = Y;
    else {
      var f = !0;
      s.unsubscribe = te(t, u => {
        f ? s.source.v = u : W(s.source, u)
      }), f = !1
    } return t && B in r ? re(t) : O(s.source)
}

function qe() {
  const t = {};

  function e() {
    se(() => {
      for (var r in t) t[r].unsubscribe();
      ne(t, B, {
        enumerable: !1,
        value: !0
      })
    })
  }
  return [t, e]
}

function ke(t) {
  var e = I;
  try {
    return I = !1, [t(), I]
  } finally {
    I = e
  }
}
var b, p, _, E, y, R, T;
class Ne {
  constructor(e, r = !0) {
    C(this, "anchor");
    S(this, b, new Map);
    S(this, p, new Map);
    S(this, _, new Map);
    S(this, E, new Set);
    S(this, y, !0);
    S(this, R, e => {
      if (i(this, b).has(e)) {
        var r = i(this, b).get(e),
          s = i(this, p).get(r);
        if (s) ie(s), i(this, E).delete(r);
        else {
          var f = i(this, _).get(r);
          f && (i(this, p).set(r, f.effect), i(this, _).delete(r), f.fragment.lastChild.remove(), this.anchor.before(f.fragment), s = f.effect)
        }
        for (const [u, c] of i(this, b)) {
          if (i(this, b).delete(u), u === e) break;
          const n = i(this, _).get(c);
          n && (L(n.effect), i(this, _).delete(c))
        }
        for (const [u, c] of i(this, p)) {
          if (u === r || i(this, E).has(u)) continue;
          const n = () => {
            if (Array.from(i(this, b).values()).includes(u)) {
              var l = document.createDocumentFragment();
              ue(c, l), l.append(F()), i(this, _).set(u, {
                effect: c,
                fragment: l
              })
            } else L(c);
            i(this, E).delete(u), i(this, p).delete(u)
          };
          i(this, y) || !s ? (i(this, E).add(u), ae(c, n, !1)) : n()
        }
      }
    });
    S(this, T, e => {
      i(this, b).delete(e);
      const r = Array.from(i(this, b).values());
      for (const [s, f] of i(this, _)) r.includes(s) || (L(f.effect), i(this, _).delete(s))
    });
    this.anchor = e, M(this, y, r)
  }
  ensure(e, r) {
    var s = fe,
      f = ce();
    if (r && !i(this, p).has(e) && !i(this, _).has(e))
      if (f) {
        var u = document.createDocumentFragment(),
          c = F();
        u.append(c), i(this, _).set(e, {
          effect: q(() => r(c)),
          fragment: u
        })
      } else i(this, p).set(e, q(() => r(this.anchor)));
    if (i(this, b).set(s, e), f) {
      for (const [n, a] of i(this, p)) n === e ? s.unskip_effect(a) : s.skip_effect(a);
      for (const [n, a] of i(this, _)) n === e ? s.unskip_effect(a.effect) : s.skip_effect(a.effect);
      s.oncommit(i(this, R)), s.ondiscard(i(this, T))
    } else x && (this.anchor = Z), i(this, R).call(this, s)
  }
}
b = new WeakMap, p = new WeakMap, _ = new WeakMap, E = new WeakMap, y = new WeakMap, R = new WeakMap, T = new WeakMap;

function je(t, e, r = !1) {
  var s;
  x && (s = Z, le());
  var f = new Ne(t),
    u = r ? de : 0;

  function c(n, a) {
    if (x) {
      var l = he(s);
      if (n !== parseInt(l.substring(1))) {
        var o = _e();
        ve(o), f.anchor = o, j(!1), f.ensure(n, a), j(!0);
        return
      }
    }
    f.ensure(n, a)
  }
  oe(() => {
    var n = !1;
    e((a, l = 0) => {
      n = !0, c(l, a)
    }), n || c(-1, null)
  }, u)
}

function G(t, e) {
  return t === e || (t == null ? void 0 : t[Q]) === e
}

function Ge(t = {}, e, r, s) {
  var f = be.r,
    u = J;
  return pe(() => {
    var c, n;
    return me(() => {
      c = n, n = [], z(() => {
        t !== r(...n) && (e(t, ...n), c && G(r(...c), t) && e(null, ...c))
      })
    }), () => {
      let a = u;
      for (; a !== f && a.parent !== null && a.parent.f & ge;) a = a.parent;
      const l = () => {
          n && G(r(...n), t) && e(null, ...n)
        },
        o = a.teardown;
      a.teardown = () => {
        l(), o == null || o()
      }
    }
  }), t
}
const Ue = {
  get(t, e) {
    if (!t.exclude.includes(e)) return t.props[e]
  },
  set(t, e) {
    return !1
  },
  getOwnPropertyDescriptor(t, e) {
    if (!t.exclude.includes(e) && e in t.props) return {
      enumerable: !0,
      configurable: !0,
      value: t.props[e]
    }
  },
  has(t, e) {
    return t.exclude.includes(e) ? !1 : e in t.props
  },
  ownKeys(t) {
    return Reflect.ownKeys(t.props).filter(e => !t.exclude.includes(e))
  }
};

function Ke(t, e, r) {
  return new Proxy({
    props: t,
    exclude: e
  }, Ue)
}

function We(t, e, r, s) {
  var k;
  var f = !Ie || (r & Oe) !== 0,
    u = (r & Ae) !== 0,
    c = (r & xe) !== 0,
    n = s,
    a = !0,
    l = () => (a && (a = !1, n = c ? z(s) : s), n);
  let o;
  if (u) {
    var m = Q in t || Be in t;
    o = ((k = Se(t, e)) == null ? void 0 : k.set) ?? (m && e in t ? h => t[e] = h : void 0)
  }
  var v, D = !1;
  u ? [v, D] = ke(() => t[e]) : v = t[e], v === void 0 && s !== void 0 && (v = l(), o && (f && Pe(), o(v)));
  var d;
  if (f ? d = () => {
      var h = t[e];
      return h === void 0 ? l() : (a = !0, h)
    } : d = () => {
      var h = t[e];
      return h !== void 0 && (n = void 0), h === void 0 ? n : h
    }, f && (r & Ee) === 0) return d;
  if (o) {
    var P = t.$$legacy;
    return (function(h, A) {
      return arguments.length > 0 ? ((!f || !A || P || D) && o(A ? d() : h), h) : d()
    })
  }
  var g = !1,
    w = ((r & Te) !== 0 ? De : Le)(() => (g = !1, d()));
  u && O(w);
  var V = J;
  return (function(h, A) {
    if (arguments.length > 0) {
      const N = A ? O(w) : f && u ? we(h) : h;
      return W(w, N), g = !0, n !== void 0 && (n = N), h
    }
    return ye && g || (V.f & Re) !== 0 ? w.v : O(w)
  })
}
const Ce = "modulepreload",
  $e = function(t, e) {
    return new URL(t, e).href
  },
  K = {},
  Ze = function(e, r, s) {
    let f = Promise.resolve();
    if (r && r.length > 0) {
      let c = function(o) {
        return Promise.all(o.map(m => Promise.resolve(m).then(v => ({
          status: "fulfilled",
          value: v
        }), v => ({
          status: "rejected",
          reason: v
        }))))
      };
      const n = document.getElementsByTagName("link"),
        a = document.querySelector("meta[property=csp-nonce]"),
        l = (a == null ? void 0 : a.nonce) || (a == null ? void 0 : a.getAttribute("nonce"));
      f = c(r.map(o => {
        if (o = $e(o, s), o in K) return;
        K[o] = !0;
        const m = o.endsWith(".css"),
          v = m ? '[rel="stylesheet"]' : "";
        if (!!s)
          for (let P = n.length - 1; P >= 0; P--) {
            const g = n[P];
            if (g.href === o && (!m || g.rel === "stylesheet")) return
          } else if (document.querySelector(`link[href="${o}"]${v}`)) return;
        const d = document.createElement("link");
        if (d.rel = m ? "stylesheet" : Ce, m || (d.as = "script"), d.crossOrigin = "", d.href = o, l && d.setAttribute("nonce", l), document.head.appendChild(d), m) return new Promise((P, g) => {
          d.addEventListener("load", P), d.addEventListener("error", () => g(new Error(`Unable to preload CSS for ${o}`)))
        })
      }))
    }

    function u(c) {
      const n = new Event("vite:preloadError", {
        cancelable: !0
      });
      if (n.payload = c, window.dispatchEvent(n), !n.defaultPrevented) throw c
    }
    return f.then(c => {
      for (const n of c || []) n.status === "rejected" && u(n.reason);
      return e().catch(u)
    })
  };
export {
  Ne as B, Ze as _, qe as a, Ge as b, je as i, We as p, Ke as r, Fe as s
};