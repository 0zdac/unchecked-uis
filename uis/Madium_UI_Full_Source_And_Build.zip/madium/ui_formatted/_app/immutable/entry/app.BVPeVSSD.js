const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["../nodes/0.-iIC8Q2B.js", "../chunks/DObtqm8W.js", "../chunks/BZGnCJ3u.js", "../chunks/ZpljUiKx.js", "../chunks/QxO3pMDe.js", "../assets/legacy.Bv8MCB7Q.css", "../assets/0.CTSS0nCd.css", "../nodes/1.BPwqts32.js", "../chunks/B6G6Pv_v.js", "../nodes/2.CsBCf2ka.js", "../assets/2.gsm9HUh5.css"]))) => i.map(i => d[i]);
var V = e => {
  throw TypeError(e)
};
var B = (e, t, r) => t.has(e) || V("Cannot " + r);
var i = (e, t, r) => (B(e, t, "read from private field"), r ? r.call(e) : t.get(e)),
  k = (e, t, r) => t.has(e) ? V("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, r),
  w = (e, t, r, n) => (B(e, t, "write to private field"), n ? n.call(e, r) : t.set(e, r), r);
import {
  B as X,
  p as A,
  i as j,
  b as C,
  _ as L
} from "../chunks/ZpljUiKx.js";
import {
  h as F,
  b as Z,
  d as p,
  E as $,
  e as tt,
  g as et,
  i as rt,
  j as H,
  H as at,
  k as st,
  l as T,
  L as nt,
  m as f,
  n as ot,
  o as ct,
  q as it,
  p as ut,
  u as dt,
  v as lt,
  w as mt,
  x as ft,
  f as O,
  s as _t,
  a as ht,
  y as S,
  c as vt,
  r as gt,
  t as yt,
  z as D
} from "../chunks/BZGnCJ3u.js";
import {
  h as bt,
  m as Et,
  u as Rt,
  a as E,
  c as I,
  f as Y,
  t as xt,
  s as Pt
} from "../chunks/DObtqm8W.js";

function M(e, t, r) {
  var n;
  F && (n = st, Z());
  var o = new X(e);
  p(() => {
    var c = t() ?? null;
    if (F) {
      var a = tt(n),
        s = a === at,
        m = c !== null;
      if (s !== m) {
        var R = et();
        rt(R), o.anchor = R, H(!1), o.ensure(c, c && (y => r(y, c))), H(!0);
        return
      }
    }
    o.ensure(c, c && (y => r(y, c)))
  }, $)
}

function Ot(e) {
  return class extends Tt {
    constructor(t) {
      super({
        component: e,
        ...t
      })
    }
  }
}
var _, d;
class Tt {
  constructor(t) {
    k(this, _);
    k(this, d);
    var c;
    var r = new Map,
      n = (a, s) => {
        var m = it(s, !1, !1);
        return r.set(a, m), m
      };
    const o = new Proxy({
      ...t.props || {},
      $$events: {}
    }, {
      get(a, s) {
        return f(r.get(s) ?? n(s, Reflect.get(a, s)))
      },
      has(a, s) {
        return s === nt ? !0 : (f(r.get(s) ?? n(s, Reflect.get(a, s))), Reflect.has(a, s))
      },
      set(a, s, m) {
        return T(r.get(s) ?? n(s, m), m), Reflect.set(a, s, m)
      }
    });
    w(this, d, (t.hydrate ? bt : Et)(t.component, {
      target: t.target,
      anchor: t.anchor,
      props: o,
      context: t.context,
      intro: t.intro ?? !1,
      recover: t.recover,
      transformError: t.transformError
    })), (!((c = t == null ? void 0 : t.props) != null && c.$$host) || t.sync === !1) && ot(), w(this, _, o.$$events);
    for (const a of Object.keys(i(this, d))) a === "$set" || a === "$destroy" || a === "$on" || ct(this, a, {
      get() {
        return i(this, d)[a]
      },
      set(s) {
        i(this, d)[a] = s
      },
      enumerable: !0
    });
    i(this, d).$set = a => {
      Object.assign(o, a)
    }, i(this, d).$destroy = () => {
      Rt(i(this, d))
    }
  }
  $set(t) {
    i(this, d).$set(t)
  }
  $on(t, r) {
    i(this, _)[t] = i(this, _)[t] || [];
    const n = (...o) => r.call(this, ...o);
    return i(this, _)[t].push(n), () => {
      i(this, _)[t] = i(this, _)[t].filter(o => o !== n)
    }
  }
  $destroy() {
    i(this, d).$destroy()
  }
}
_ = new WeakMap, d = new WeakMap;
const Mt = {};
var kt = Y('<div id="svelte-announcer" aria-live="assertive" aria-atomic="true" style="position: absolute; left: 0; top: 0; clip: rect(0 0 0 0); clip-path: inset(50%); overflow: hidden; white-space: nowrap; width: 1px; height: 1px"><!></div>'),
  wt = Y("<!> <!>", 1);

function At(e, t) {
  ut(t, !0);
  let r = A(t, "components", 23, () => []),
    n = A(t, "data_0", 3, null),
    o = A(t, "data_1", 3, null);
  dt(() => t.stores.page.set(t.page)), lt(() => {
    t.stores, t.page, t.constructors, r(), t.form, n(), o(), t.stores.page.notify()
  });
  let c = S(!1),
    a = S(!1),
    s = S(null);
  mt(() => {
    const u = t.stores.page.subscribe(() => {
      f(c) && (T(a, !0), ft().then(() => {
        T(s, document.title || "untitled page", !0)
      }))
    });
    return T(c, !0), u
  });
  const m = D(() => t.constructors[1]);
  var R = wt(),
    y = O(R);
  {
    var z = u => {
        const h = D(() => t.constructors[0]);
        var v = I(),
          x = O(v);
        M(x, () => f(h), (g, b) => {
          C(b(g, {
            get data() {
              return n()
            },
            get form() {
              return t.form
            },
            get params() {
              return t.page.params
            },
            children: (l, Ct) => {
              var N = I(),
                Q = O(N);
              M(Q, () => f(m), (U, W) => {
                C(W(U, {
                  get data() {
                    return o()
                  },
                  get form() {
                    return t.form
                  },
                  get params() {
                    return t.page.params
                  }
                }), P => r()[1] = P, () => {
                  var P;
                  return (P = r()) == null ? void 0 : P[1]
                })
              }), E(l, N)
            },
            $$slots: {
              default: !0
            }
          }), l => r()[0] = l, () => {
            var l;
            return (l = r()) == null ? void 0 : l[0]
          })
        }), E(u, v)
      },
      G = u => {
        const h = D(() => t.constructors[0]);
        var v = I(),
          x = O(v);
        M(x, () => f(h), (g, b) => {
          C(b(g, {
            get data() {
              return n()
            },
            get form() {
              return t.form
            },
            get params() {
              return t.page.params
            }
          }), l => r()[0] = l, () => {
            var l;
            return (l = r()) == null ? void 0 : l[0]
          })
        }), E(u, v)
      };
    j(y, u => {
      t.constructors[1] ? u(z) : u(G, -1)
    })
  }
  var J = _t(y, 2);
  {
    var K = u => {
      var h = kt(),
        v = vt(h);
      {
        var x = g => {
          var b = xt();
          yt(() => Pt(b, f(s))), E(g, b)
        };
        j(v, g => {
          f(a) && g(x)
        })
      }
      gt(h), E(u, h)
    };
    j(J, u => {
      f(c) && u(K)
    })
  }
  E(e, R), ht()
}
const Nt = Ot(At),
  Vt = [() => L(() => import("../nodes/0.-iIC8Q2B.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6]), import.meta.url), () => L(() => import("../nodes/1.BPwqts32.js"), __vite__mapDeps([7, 1, 2, 8]), import.meta.url), () => L(() => import("../nodes/2.CsBCf2ka.js"), __vite__mapDeps([9, 1, 2, 3, 4, 5, 10]), import.meta.url)],
  Bt = [],
  Ft = {
    "/": [2]
  },
  q = {
    handleError: (({
      error: e
    }) => {
      console.error(e)
    }),
    reroute: (() => {}),
    transport: {}
  },
  jt = Object.fromEntries(Object.entries(q.transport).map(([e, t]) => [e, t.decode])),
  Ht = Object.fromEntries(Object.entries(q.transport).map(([e, t]) => [e, t.encode])),
  Yt = !1,
  qt = (e, t) => jt[e](t);
export {
  qt as decode, jt as decoders, Ft as dictionary, Ht as encoders, Yt as hash, q as hooks, Mt as matchers, Vt as nodes, Nt as root, Bt as server_loads
};