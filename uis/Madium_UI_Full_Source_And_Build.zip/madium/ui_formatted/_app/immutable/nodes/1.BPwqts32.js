import {
  a as i,
  f as g,
  s as a
} from "../chunks/DObtqm8W.js";
import {
  p as v,
  f as d,
  t as l,
  a as _,
  c as o,
  r as p,
  s as x
} from "../chunks/BZGnCJ3u.js";
import {
  s as $,
  p as c
} from "../chunks/B6G6Pv_v.js";
const k = {
  get error() {
    return c.error
  },
  get status() {
    return c.status
  }
};
$.updated.check;
const m = k;
var b = g("<h1> </h1> <p> </p>", 1);

function w(f, n) {
  v(n, !0);
  var t = b(),
    r = d(t),
    u = o(r, !0);
  p(r);
  var e = x(r, 2),
    h = o(e, !0);
  p(e), l(() => {
    var s;
    a(u, m.status), a(h, (s = m.error) == null ? void 0 : s.message)
  }), i(f, t), _()
}
export {
  w as component
};