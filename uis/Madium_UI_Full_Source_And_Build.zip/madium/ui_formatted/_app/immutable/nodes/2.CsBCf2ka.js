import {
  d as Yt,
  b as d,
  a as n,
  e as yr,
  s as I,
  f as i,
  c as wr,
  r as Za,
  t as dr,
  g as wn
} from "../chunks/DObtqm8W.js";
import {
  h as kn,
  b as $n,
  aM as zn,
  d as Sn,
  p as Dt,
  l as s,
  aK as Ur,
  y as C,
  Z as Nt,
  f as Ge,
  c as r,
  m as e,
  s as a,
  r as t,
  t as y,
  a as Rt,
  z as A,
  v as Cr,
  w as Tr,
  am as Ae,
  C as Ra,
  a5 as va,
  aN as Cn,
  aO as Pn,
  aP as Ln,
  A as da,
  aQ as en,
  aR as tn,
  S as En,
  Q as Ua
} from "../chunks/BZGnCJ3u.js";
import {
  B as An,
  i as f,
  b as ta,
  p as Nr,
  s as $t,
  a as Br
} from "../chunks/ZpljUiKx.js";
import {
  H as Fe,
  I as z,
  X as Ta,
  s as me,
  f as Ir,
  m as ra,
  r as ur,
  d as Or,
  Y as rn,
  Z as Ia,
  _ as Mn,
  $ as an,
  a0 as Dn,
  a1 as Pr,
  a2 as Rn,
  a3 as nn,
  a4 as sn,
  a5 as on,
  a6 as In,
  n as Ze,
  E as Nn,
  F as Tn,
  i as ut,
  x as sr,
  a7 as ln,
  j as tr,
  G as cr,
  a8 as jn,
  a9 as Ba,
  N as Sr,
  aa as Fn,
  B as gt,
  ab as On,
  ac as Un,
  ad as Na,
  ae as cn,
  af as dn,
  ag as wa,
  A as ja,
  O as Kr,
  ah as xa,
  h as Zr,
  ai as Gr,
  aj as Bn,
  ak as Wa,
  al as Wn,
  am as Vn,
  p as un,
  an as ua,
  ao as Hn,
  ap as Va,
  aq as qn,
  J as Ha,
  ar as Kn,
  as as Gn,
  P as ha,
  at as lr,
  k as Yn,
  S as Gt,
  au as ea,
  av as pn,
  D as qa,
  T as ct,
  y as Xt,
  q as $a,
  aw as Sa,
  ax as Xn,
  ay as Ca,
  V as ya,
  v as Je,
  az as Jn,
  w as Pa,
  z as La,
  o as pa,
  Q as vn,
  L as xn,
  aA as Ea,
  b as Qn,
  aB as Zn,
  aC as ei,
  aD as ti,
  aE as mn,
  aF as ba,
  g as ri,
  C as ai,
  aG as Ka,
  aH as ca,
  aI as Aa,
  aJ as ni
} from "../chunks/QxO3pMDe.js";
const ii = Symbol("NaN");

function fn(l, o, x) {
  kn && $n();
  var v = new An(l),
    w = !zn();
  Sn(() => {
    var P = o();
    P !== P && (P = ii), w && P !== null && typeof P == "object" && (P = {}), v.ensure(P, x)
  })
}
var si = i('<input class="min-w-0 flex-1 rounded bg-bg-base px-1.5 text-[12px] text-text-primary outline-none ring-1 ring-inset ring-text-primary/25"/>'),
  oi = i('<span class="flex-1 truncate"> </span>'),
  li = i("<div><!> <!></div> <!>", 1);

function ci(l, o) {
  Dt(o, !0);
  let x = C(null);
  const v = Fe.subscribe(Z => {
    const Y = Z.files.find(re => re.id === Z.active);
    s(x, Y != null && Y.appDataPath ? Y.appDataPath.replace(/\\/g, "/").toLowerCase() : null, !0)
  });
  Ur(() => v());
  const w = A(() => e(x) === `${o.dir}/${o.entry.name??""}`.replace(/\\/g, "/").toLowerCase());
  let P = C(!1),
    c = C(null),
    g = C(""),
    S = C(!1),
    O = C(0),
    D = C(0),
    K = C(Nt([]));

  function xe() {
    s(g, o.entry.name ?? "", !0), s(P, !0), setTimeout(() => {
      var Y, re;
      (Y = e(c)) == null || Y.focus();
      const Z = e(g).lastIndexOf(".");
      (re = e(c)) == null || re.setSelectionRange(0, Z > 0 ? Z : e(g).length)
    }, 0)
  }
  const Q = Z => {
      Z.stopPropagation(), xe()
    },
    B = async () => {
      var re;
      s(P, !1);
      const Z = e(g).trim();
      if (!Z || Z === o.entry.name) return;
      const Y = `${o.dir}/${o.entry.name??""}`;
      await Rn(Y, `${o.dir}/${Z}`, {
        oldPathBaseDir: Pr.AppLocalData,
        newPathBaseDir: Pr.AppLocalData
      }), (re = o.onrenamed) == null || re.call(o)
    };
  async function ye() {
    try {
      await Dn(`${o.dir}/${o.entry.name??""}`, {
        baseDir: Pr.AppLocalData
      })
    } catch (Z) {
      console.error(`[scripts] delete failed: ${Z}`)
    }
  }
  async function we() {
    try {
      const Z = await rn(),
        Y = await Ia(Z, o.dir, o.entry.name ?? "");
      try {
        await Mn(Y)
      } catch {
        await an(await Ia(Z, o.dir))
      }
    } catch (Z) {
      console.error(`[scripts] open path failed: ${Z}`)
    }
  }

  function ue(Z) {
    Z.preventDefault(), Z.stopPropagation(), s(O, Math.min(Z.clientX, window.innerWidth - 210), !0), s(D, Math.min(Z.clientY, window.innerHeight - 200), !0), s(K, [{
      label: "Open",
      icon: "folder-open",
      action: () => Fe.open_app_file(`${o.dir}/${o.entry.name}`)
    }, {
      label: "Open path",
      icon: "dock",
      action: () => we()
    }, {
      label: "Rename…",
      icon: "pencil",
      action: () => xe()
    }, {
      separator: !0
    }, {
      label: "Delete",
      icon: "trash",
      danger: !0,
      action: () => ye()
    }], !0), s(S, !0)
  }
  const ke = Z => {
    Z.key === "Enter" && B(), Z.key === "Escape" && s(P, !1)
  };
  var U = li(),
    W = Ge(U),
    le = r(W);
  {
    let Z = A(() => e(w) ? "opacity-100" : "opacity-55");
    z(le, {
      name: "lua",
      size: 12,
      get class() {
        return `shrink-0 [filter:brightness(0)_invert(1)] ${e(Z)??""}`
      }
    })
  }
  var ee = a(le, 2);
  {
    var fe = Z => {
        var Y = si();
        ur(Y), ta(Y, re => s(c, re), () => e(c)), d("keydown", Y, ke), yr("blur", Y, B), d("click", Y, re => re.stopPropagation()), Or(Y, () => e(g), re => s(g, re)), n(Z, Y)
      },
      ie = Z => {
        var Y = oi(),
          re = r(Y, !0);
        t(Y), y(() => I(re, o.entry.name)), d("dblclick", Y, Q), n(Z, Y)
      };
    f(ee, Z => {
      e(P) ? Z(fe) : Z(ie, -1)
    })
  }
  t(W);
  var $e = a(W, 2);
  Ta($e, {
    get open() {
      return e(S)
    },
    get x() {
      return e(O)
    },
    get y() {
      return e(D)
    },
    get items() {
      return e(K)
    },
    onclose: () => s(S, !1)
  }), y(() => me(W, 1, `mx-1.5 flex h-[30px] items-center gap-1.5 rounded-[8px] pl-4 pr-2 text-[12px] font-medium cursor-pointer transition-colors
        ${e(w)?"bg-bg-active/70 text-text-primary":"text-text-secondary hover:bg-bg-active/40 hover:text-text-primary"}`)), d("click", W, () => Fe.open_app_file(`${o.dir}/${o.entry.name}`)), d("contextmenu", W, ue), Ir(1, W, () => ra, () => ({
    x: -100
  })), Ir(2, W, () => ra, () => ({
    x: -100
  })), n(l, U), Rt()
}
Yt(["click", "contextmenu", "keydown", "dblclick"]);
var di = i('<div style="overflow: hidden;"><!></div>'),
  ui = i('<div class="px-2 py-4 text-center text-xs text-text-muted"> </div>'),
  pi = i('<div class="flex flex-col"><!> <!></div>');

function vi(l, o) {
  Dt(o, !0);
  let x = Nr(o, "filter", 3, ""),
    v = Nr(o, "refresh", 3, 0),
    w = C(Nt([]));
  const P = new Set([".lua", ".luau", ".txt"]),
    c = B => B.isDirectory || P.has("." + (B.name ?? "").split(".").pop().toLowerCase()),
    g = A(() => x().trim() ? e(w).filter(B => c(B) && (B.name ?? "").toLowerCase().includes(x().toLowerCase())) : e(w).filter(c));
  Cr(() => {
    var B;
    (B = o.onresults) == null || B.call(o, e(g).length)
  }), Cr(() => {
    v(), S()
  });
  const S = async () => {
    try {
      await nn(o.dir, {
        baseDir: Pr.AppLocalData
      }) || await sn(o.dir, {
        recursive: !0,
        baseDir: Pr.AppLocalData
      });
      const B = await on(o.dir, {
          baseDir: Pr.AppLocalData
        }),
        ye = new Set(B.map(ue => ue.name)),
        we = new Set(e(w).map(ue => ue.name));
      s(w, [...e(w).filter(ue => ye.has(ue.name)), ...B.filter(ue => !we.has(ue.name))], !0)
    } catch (B) {
      console.error(B)
    }
  }, O = In(o.dir, async () => {
    await S()
  }, {
    recursive: !0,
    baseDir: Pr.AppLocalData
  });
  Tr(async () => {
    await S()
  }), Ur(() => {
    O.then(B => B()).catch(() => {})
  });
  var D = pi(),
    K = r(D);
  Ze(K, 25, () => e(g), B => B.name, (B, ye) => {
    var we = di(),
      ue = r(we);
    ci(ue, {
      get entry() {
        return e(ye)
      },
      get dir() {
        return o.dir
      },
      onrenamed: () => ({})
    }), t(we), Nn(we, () => Tn, null), n(B, we)
  });
  var xe = a(K, 2);
  {
    var Q = B => {
      var ye = ui(),
        we = r(ye, !0);
      t(ye), y(ue => I(we, ue), [() => x().trim() ? "No matches" : "No scripts yet"]), n(B, ye)
    };
    f(xe, B => {
      e(g).length === 0 && B(Q)
    })
  }
  t(D), n(l, D), Rt()
}
var xi = i('<div class="group/section mt-2 shrink-0 first:mt-1"><div class="mx-1.5 flex h-[30px] w-auto items-center gap-1.5 rounded-[8px] pl-2 pr-1.5"><button class="flex min-w-0 flex-1 items-center gap-1.5 text-left cursor-pointer"><!> <!> <span class="flex-1 truncate text-[12.5px] font-semibold text-text-secondary transition-colors group-hover/section:text-text-primary"> </span></button> <button class="grid size-[22px] shrink-0 place-items-center rounded-[6px] text-text-muted opacity-0 transition-[opacity,color] hover:text-text-primary group-hover/section:opacity-100 cursor-pointer" title="Refresh"><!></button></div> <div class="grid transition-[grid-template-rows] duration-(--motion-dur) ease-(--motion-ease)"><div class="overflow-hidden"><div class="pb-1"><!></div></div></div></div> <!>', 1);

function Ma(l, o) {
  Dt(o, !0);
  let x = Nr(o, "icon", 3, "folder"),
    v = Nr(o, "filter", 3, ""),
    w = C(!1),
    P = C(0),
    c = C(0);
  const g = A(() => v().trim().length > 0),
    S = A(() => e(g) ? e(P) > 0 : e(w));
  let O = C(!1),
    D = C(0),
    K = C(0),
    xe = C(Nt([]));
  async function Q() {
    await nn(o.dir, {
      baseDir: Pr.AppLocalData
    }) || await sn(o.dir, {
      recursive: !0,
      baseDir: Pr.AppLocalData
    })
  }
  async function B() {
    let L = new Set;
    try {
      L = new Set((await on(o.dir, {
        baseDir: Pr.AppLocalData
      })).map(Be => Be.name))
    } catch {}
    let ae = "New Script.lua",
      Me = 2;
    for (; L.has(ae);) ae = `New Script ${Me++}.lua`;
    return ae
  }
  async function ye() {
    try {
      await Q();
      const L = await B();
      await ln(`${o.dir}/${L}`, "", {
        baseDir: Pr.AppLocalData
      }), s(w, !0), await Fe.open_app_file(`${o.dir}/${L}`)
    } catch (L) {
      console.error(`[folder] create file failed: ${L}`)
    }
  }
  async function we() {
    try {
      await Q(), await an(await Ia(await rn(), o.dir))
    } catch (L) {
      console.error(`[folder] open folder failed: ${L}`)
    }
  }

  function ue(L) {
    L.preventDefault(), L.stopPropagation(), s(D, Math.min(L.clientX, window.innerWidth - 210), !0), s(K, Math.min(L.clientY, window.innerHeight - 200), !0), s(xe, [{
      label: "New file",
      icon: "file-plus",
      action: () => ye()
    }, {
      label: "Open folder",
      icon: "folder-open",
      action: () => we()
    }], !0), s(O, !0)
  }
  var ke = xi(),
    U = Ge(ke),
    W = r(U),
    le = r(W),
    ee = r(le);
  {
    let L = A(() => e(S) ? "rotate-90" : "");
    z(ee, {
      name: "chevron-right",
      size: 12,
      get class() {
        return `shrink-0 text-text-muted transition-transform duration-150 ${e(L)??""}`
      }
    })
  }
  var fe = a(ee, 2);
  {
    let L = A(() => x() === "lua" ? "[filter:brightness(0)_invert(1)] opacity-70 group-hover/section:opacity-100" : "text-text-secondary");
    z(fe, {
      get name() {
        return x()
      },
      size: 13,
      get class() {
        return `shrink-0 ${e(L)??""}`
      }
    })
  }
  var ie = a(fe, 2),
    $e = r(ie, !0);
  t(ie), t(le);
  var Z = a(le, 2),
    Y = r(Z);
  z(Y, {
    name: "refresh",
    size: 11
  }), t(Z), t(W);
  var re = a(W, 2),
    J = r(re),
    ve = r(J),
    ze = r(ve);
  vi(ze, {
    get dir() {
      return o.dir
    },
    get filter() {
      return v()
    },
    get refresh() {
      return e(c)
    },
    onresults: L => s(P, L, !0)
  }), t(ve), t(J), t(re), t(U);
  var k = a(U, 2);
  Ta(k, {
    get open() {
      return e(O)
    },
    get x() {
      return e(D)
    },
    get y() {
      return e(K)
    },
    get items() {
      return e(xe)
    },
    onclose: () => s(O, !1)
  }), y(() => {
    I($e, o.label), ut(Z, "aria-label", `Refresh ${o.label??""}`), sr(re, `grid-template-rows: ${e(S)?"1fr":"0fr"}`)
  }), d("click", le, () => s(w, !e(w))), d("contextmenu", le, ue), d("click", Z, () => s(c, e(c) + 1)), n(l, ke), Rt()
}
Yt(["click", "contextmenu"]);
const Ga = [{
    id: "infinite-yield",
    name: "Infinite Yield",
    description: "Popular admin command suite",
    url: "https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"
  }, {
    id: "dex",
    name: "Dex Explorer",
    description: "Game explorer & property editor",
    url: "https://raw.githubusercontent.com/infyiff/backup/main/dex.lua"
  }, {
    id: "simplespy",
    name: "SimpleSpy",
    description: "Remote spy",
    url: "https://raw.githubusercontent.com/exxtremestuffs/SimpleSpySource/master/SimpleSpy.lua"
  }, {
    id: "hydroxide",
    name: "Hydroxide",
    description: "Remote spy & explorer",
    url: "https://raw.githubusercontent.com/Upbolt/Hydroxide/revision/init.lua",
    content: ['local owner = "Upbolt"', 'local branch = "revision"', "", "local function webImport(file)", `	return loadstring(game:HttpGetAsync(("https://raw.githubusercontent.com/%s/Hydroxide/%s/%s.lua"):format(owner, branch, file)), file .. '.lua')()`, "end", "", 'webImport("init")', 'webImport("ui/main")'].join(`
`)
  }],
  mi = l => l.content ?? `loadstring(game:HttpGet("${l.url}"))()`;
var fi = i('<button class="mx-1.5 flex h-[30px] items-center gap-1.5 rounded-[8px] pl-4 pr-2 text-[12px] font-medium text-text-secondary hover:bg-bg-active/40 hover:text-text-primary cursor-pointer transition-colors"><!> <span class="truncate"> </span></button>'),
  gi = i('<div class="mx-1.5 rounded-[8px] pl-6 py-2 text-[11px] text-text-muted">No matches</div>'),
  bi = i('<div class="group/section mt-2 shrink-0 first:mt-1"><div class="mx-1.5 flex h-[30px] items-center gap-1.5 rounded-[8px] pl-2 pr-1.5"><button class="flex min-w-0 flex-1 items-center gap-1.5 text-left cursor-pointer"><!> <!> <span class="flex-1 truncate text-[12.5px] font-semibold text-text-secondary transition-colors group-hover/section:text-text-primary">Library</span></button></div> <div class="grid transition-[grid-template-rows] duration-(--motion-dur) ease-(--motion-ease)"><div class="overflow-hidden"><div class="flex flex-col pb-1"><!> <!></div></div></div></div>');

function _i(l, o) {
  Dt(o, !0);
  let x = Nr(o, "filter", 3, ""),
    v = C(!1);
  const w = A(() => x().trim() ? Ga.filter(U => U.name.toLowerCase().includes(x().toLowerCase())) : Ga),
    P = A(() => x().trim().length > 0),
    c = A(() => e(P) ? e(w).length > 0 : e(v));
  async function g(U) {
    await Fe.create_file_with_content(U.name, mi(U)), tr.goto("editor")
  }
  var S = bi(),
    O = r(S),
    D = r(O),
    K = r(D);
  {
    let U = A(() => e(c) ? "rotate-90" : "");
    z(K, {
      name: "chevron-right",
      size: 12,
      get class() {
        return `shrink-0 text-text-muted transition-transform duration-150 ${e(U)??""}`
      }
    })
  }
  var xe = a(K, 2);
  z(xe, {
    name: "book-open",
    size: 13,
    class: "shrink-0 text-text-secondary"
  }), Ae(2), t(D), t(O);
  var Q = a(O, 2),
    B = r(Q),
    ye = r(B),
    we = r(ye);
  Ze(we, 17, () => e(w), U => U.id, (U, W) => {
    var le = fi(),
      ee = r(le);
    z(ee, {
      name: "lua",
      size: 12,
      class: "shrink-0 [filter:brightness(0)_invert(1)] opacity-55"
    });
    var fe = a(ee, 2),
      ie = r(fe, !0);
    t(fe), t(le), y(() => {
      ut(le, "title", e(W).description), I(ie, e(W).name)
    }), d("click", le, () => g(e(W))), n(U, le)
  });
  var ue = a(we, 2);
  {
    var ke = U => {
      var W = gi();
      n(U, W)
    };
    f(ue, U => {
      e(w).length === 0 && U(ke)
    })
  }
  t(ye), t(B), t(Q), t(S), y(() => sr(Q, `grid-template-rows: ${e(c)?"1fr":"0fr"}`)), d("click", D, () => s(v, !e(v))), n(l, S), Rt()
}
Yt(["click"]);
var hi = i('<div class="h-full w-full flex flex-col flex-1 bg-transparent"><div class="relative flex-1 min-h-0 overflow-hidden bg-transparent"><div class="relative z-[1] w-full h-full min-h-0"></div></div></div>');

function yi(l, o) {
  Dt(o, !0);
  let x = C(null);
  Cr(() => {
    e(x) && Fe.mount(e(x))
  });
  let v = !1;
  Tr(() => {
    const g = cr.subscribe(S => {
      if (!S || Object.keys(S).length === 0) return;
      Fe.update_options({
        fontSize: S["editor.font_size"],
        fontFamily: S["editor.font_family"],
        fontLigatures: S["editor.ligatures"],
        tabSize: S["editor.tab_size"],
        smoothScrolling: S["editor.smooth_scrolling"],
        minimap: {
          enabled: S["editor.minimap"]
        },
        wordWrap: S["editor.word_wrap"] ? "on" : "off",
        lineNumbers: S["editor.line_numbers"] === !1 ? "off" : "on",
        lineHeight: S["editor.line_height"] ?? 22,
        cursorStyle: S["editor.cursor_style"] ?? "line",
        cursorBlinking: S["editor.cursor_blinking"] ?? "blink",
        stickyScroll: {
          enabled: S["editor.sticky_scroll"] === !0
        },
        scrollBeyondLastLine: S["editor.scroll_beyond_last_line"] !== !1,
        bracketPairColorization: {
          enabled: S["editor.bracket_colorization"] !== !1
        },
        renderWhitespace: S["editor.render_whitespace"] ?? "none"
      }), Fe.set_streamer_mode(S["editor.streamer_mode"] === !0);
      const O = S["editor.luau_lsp"] !== !1;
      O && !v ? (jn(), v = !0) : !O && v && (Ba(), v = !1)
    });
    return () => {
      g(), v && Ba()
    }
  });
  var w = hi(),
    P = r(w),
    c = r(P);
  ta(c, g => s(x, g), () => e(x)), t(P), t(w), n(l, w), Rt()
}
const gn = l => l.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "theme",
  wi = l => {
    const o = gn(l),
      x = wa();
    let v = o,
      w = 2;
    for (; x.has(v);) v = `${o}-${w++}`;
    return v
  };
async function ki(l, o, x) {
  const v = Ra(Sr),
    w = {
      v: 1,
      theme: {
        name: l,
        type: o,
        tokens: x
      },
      background: {
        opacity: v.opacity,
        blur: v.blur,
        fit: v.fit
      }
    },
    P = await Fn({
      defaultPath: `${gn(l)}.json`,
      filters: [{
        name: "constraintt.ez theme",
        extensions: ["json"]
      }]
    });
  if (P) try {
    await ln(P, JSON.stringify(w, null, 2)), gt.success("Theme exported", {
      message: l
    })
  } catch (c) {
    console.error(`[share] export failed: ${c}`), gt.error("Couldn't export theme", {
      message: String(c)
    })
  }
}
async function $i() {
  var o;
  const l = await On({
    multiple: !1,
    filters: [{
      name: "constraintt.ez theme",
      extensions: ["json"]
    }]
  });
  if (!l || Array.isArray(l)) return !1;
  try {
    const x = await Un(l),
      v = JSON.parse(x);
    if (!((o = v == null ? void 0 : v.theme) != null && o.tokens)) throw new Error("missing theme tokens");
    const w = v.theme,
      P = w.type === "light" ? "light" : "dark",
      c = Na(w.name || "Imported", P, w.tokens),
      g = wi(w.name || "imported");
    return cn(g, c), await dn(g, c), cr.register_user_theme(g, c), await cr.apply_theme(g), v.background && (typeof v.background.opacity == "number" && Sr.set_opacity(v.background.opacity), typeof v.background.blur == "number" && Sr.set_blur(v.background.blur), v.background.fit && Sr.set_fit(v.background.fit)), gt.success("Theme imported", {
      message: w.name || "Imported"
    }), !0
  } catch (x) {
    return console.error(`[share] import failed: ${x}`), gt.error("Couldn't import theme", {
      message: "The file isn't a valid constraintt.ez theme."
    }), !1
  }
}
var zi = i("<button> </button>"),
  Si = i('<div class="flex items-center gap-3"><div class="h-12 w-20 shrink-0 rounded-md border border-border-subtle bg-bg-elevated bg-cover bg-center"></div> <button class="h-8 px-3 rounded-md text-[13px] bg-bg-elevated text-text-primary hover:bg-active cursor-pointer">Change</button> <button class="h-8 px-3 rounded-md text-[13px] text-text-secondary hover:bg-active hover:text-text-primary cursor-pointer">Remove</button></div> <div class="mt-3 flex items-center justify-between gap-4 py-1.5"><span class="text-[13px] text-text-secondary">Opacity</span> <!></div> <div class="flex items-center justify-between gap-4 py-1.5"><span class="text-[13px] text-text-secondary">Blur</span> <!></div> <div class="flex items-center justify-between gap-4 py-1.5"><span class="text-[13px] text-text-secondary">Fit</span> <div class="flex flex-wrap justify-end gap-1"></div></div>', 1),
  Ci = i('<button class="flex items-center gap-1.5 h-8 px-3 rounded-md text-[13px] font-medium bg-bg-elevated text-text-primary hover:bg-active cursor-pointer"><!> Choose image</button> <p class="mt-2 text-xs text-text-muted">Show a background image behind the code editor only.</p>', 1),
  Pi = i('<div class="mt-5 border-t border-border-subtle pt-4"><p class="text-[11px] font-medium uppercase tracking-wide text-text-muted mb-2.5">Editor background</p> <!></div>');

function Li(l, o) {
  Dt(o, !1);
  const x = () => $t(Kr, "$editor_background", v),
    [v, w] = Br();
  ja();
  var P = Pi(),
    c = a(r(P), 2);
  {
    var g = O => {
        var D = Si(),
          K = Ge(D),
          xe = r(K),
          Q = a(xe, 2),
          B = a(Q, 2);
        t(K);
        var ye = a(K, 2),
          we = a(r(ye), 2);
        {
          let le = va(() => Math.round(x().opacity * 100));
          xa(we, {
            get value() {
              return e(le)
            },
            min: 5,
            max: 100,
            step: 5,
            unit: "%",
            oninput: ee => Kr.set_opacity(Number(ee.currentTarget.value) / 100),
            class: "w-44"
          })
        }
        t(ye);
        var ue = a(ye, 2),
          ke = a(r(ue), 2);
        xa(ke, {
          get value() {
            return x().blur
          },
          min: 0,
          max: 24,
          step: 1,
          unit: "px",
          oninput: le => Kr.set_blur(Number(le.currentTarget.value)),
          class: "w-44"
        }), t(ue);
        var U = a(ue, 2),
          W = a(r(U), 2);
        Ze(W, 5, () => Kr.fits, le => le, (le, ee) => {
          var fe = zi(),
            ie = r(fe, !0);
          t(fe), y(() => {
            me(fe, 1, `h-7 px-2 rounded-md text-xs capitalize cursor-pointer ${x().fit===e(ee)?"bg-bg-elevated text-text-primary":"text-text-muted hover:bg-active hover:text-text-primary"}`), I(ie, e(ee))
          }), d("click", fe, () => Kr.set_fit(e(ee))), n(le, fe)
        }), t(W), t(U), y(() => sr(xe, x().url ? `background-image:url("${x().url}")` : "")), d("click", Q, () => Kr.choose()), d("click", B, () => Kr.clear()), n(O, D)
      },
      S = O => {
        var D = Ci(),
          K = Ge(D),
          xe = r(K);
        z(xe, {
          name: "palette",
          size: 15
        }), Ae(), t(K), Ae(2), d("click", K, () => Kr.choose()), n(O, D)
      };
    f(c, O => {
      x().enabled ? O(g) : O(S, -1)
    })
  }
  t(P), n(l, P), Rt(), w()
}
Yt(["click"]);
var Ei = i('<div class="flex items-center gap-3"><div class="grid size-10 shrink-0 place-items-center rounded-md bg-bg-elevated"><!></div> <div class="min-w-0 flex-1"><div class="truncate text-[13px] text-text-primary"> </div> <div class="text-[11px] text-text-muted"> </div></div> <button class="grid size-8 place-items-center rounded-md bg-bg-elevated text-text-primary hover:bg-active cursor-pointer"><!></button> <button class="grid size-8 place-items-center rounded-md text-text-muted hover:bg-active hover:text-text-primary cursor-pointer" title="Remove"><!></button></div> <div class="mt-3 flex items-center justify-between gap-4 py-1.5"><span class="text-[13px] text-text-secondary">Volume</span> <!></div> <div class="flex items-center justify-between gap-4 py-1.5"><div class="flex flex-col gap-0.5 min-w-0"><span class="text-[13px] text-text-secondary">Only when focused</span> <span class="text-xs text-text-muted">Pause the music when the window loses focus.</span></div> <!></div> <button class="mt-2 h-8 px-3 rounded-md text-[13px] bg-bg-elevated text-text-primary hover:bg-active cursor-pointer">Change track</button>', 1),
  Ai = i('<button class="flex items-center gap-1.5 h-8 px-3 rounded-md text-[13px] font-medium bg-bg-elevated text-text-primary hover:bg-active cursor-pointer"><!> Choose audio file</button> <p class="mt-2 text-xs text-text-muted">Loops while madium is active.</p>', 1),
  Mi = i('<div class="mt-5 border-t border-border-subtle pt-4"><p class="text-[11px] font-medium uppercase tracking-wide text-text-muted mb-2.5">Music</p> <!></div>');

function Di(l, o) {
  Dt(o, !1);
  const x = () => $t(Zr, "$music", v),
    [v, w] = Br();
  ja();
  var P = Mi(),
    c = a(r(P), 2);
  {
    var g = O => {
        var D = Ei(),
          K = Ge(D),
          xe = r(K),
          Q = r(xe);
        z(Q, {
          name: "music",
          size: 18,
          class: "text-text-secondary"
        }), t(xe);
        var B = a(xe, 2),
          ye = r(B),
          we = r(ye, !0);
        t(ye);
        var ue = a(ye, 2),
          ke = r(ue, !0);
        t(ue), t(B);
        var U = a(B, 2),
          W = r(U);
        {
          let re = va(() => x().enabled ? "pause" : "play");
          z(W, {
            get name() {
              return e(re)
            },
            size: 14
          })
        }
        t(U);
        var le = a(U, 2),
          ee = r(le);
        z(ee, {
          name: "trash",
          size: 14
        }), t(le), t(K);
        var fe = a(K, 2),
          ie = a(r(fe), 2);
        {
          let re = va(() => Math.round(x().volume * 100));
          xa(ie, {
            get value() {
              return e(re)
            },
            min: 0,
            max: 100,
            step: 5,
            unit: "%",
            oninput: J => Zr.set_volume(Number(J.currentTarget.value) / 100),
            class: "w-44"
          })
        }
        t(fe);
        var $e = a(fe, 2),
          Z = a(r($e), 2);
        Gr(Z, {
          get checked() {
            return x().playWhenFocused
          },
          onchange: re => Zr.set_play_when_focused(re)
        }), t($e);
        var Y = a($e, 2);
        y(() => {
          I(we, x().name || "Track"), I(ke, x().enabled ? "Active" : "Paused"), ut(U, "title", x().enabled ? "Pause" : "Play")
        }), d("click", U, () => Zr.set_enabled(!x().enabled)), d("click", le, () => Zr.clear()), d("click", Y, () => Zr.choose()), n(O, D)
      },
      S = O => {
        var D = Ai(),
          K = Ge(D),
          xe = r(K);
        z(xe, {
          name: "music",
          size: 15
        }), Ae(), t(K), Ae(2), d("click", K, () => Zr.choose()), n(O, D)
      };
    f(c, O => {
      x().url ? O(g) : O(S, -1)
    })
  }
  t(P), n(l, P), Rt(), w()
}
Yt(["click"]);
var Ri = i('<span class="size-5 rounded-md border border-white/10"></span>'),
  Ii = i('<button aria-label="Export theme" class="grid size-6 place-items-center rounded-md bg-bg-surface/80 text-text-muted hover:text-text-primary hover:bg-active cursor-pointer"><!></button> <button aria-label="Duplicate theme" class="grid size-6 place-items-center rounded-md bg-bg-surface/80 text-text-muted hover:text-text-primary hover:bg-active cursor-pointer"><!></button>', 1),
  Ni = i('<button aria-label="Edit theme" class="grid size-6 place-items-center rounded-md bg-bg-surface/80 text-text-muted hover:text-text-primary hover:bg-active cursor-pointer"><!></button> <button aria-label="Delete theme" class="grid size-6 place-items-center rounded-md bg-bg-surface/80 text-text-muted hover:text-text-primary hover:bg-active cursor-pointer"><!></button>', 1),
  Ti = i('<div role="button" tabindex="0"><div class="flex gap-1 mb-2.5"></div> <div class="flex items-center justify-between gap-2"><span class="text-[13px] text-text-primary truncate"> </span> <!></div> <div class="absolute top-2 right-2 flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity"><!> <!></div></div>'),
  ji = i("<button> </button>"),
  Fi = i('<div class="flex items-center gap-3"><div class="h-12 w-20 shrink-0 rounded-md border border-border-subtle bg-bg-elevated bg-cover bg-center"></div> <button class="h-8 px-3 rounded-md text-[13px] bg-bg-elevated text-text-primary hover:bg-active cursor-pointer">Change</button> <button class="h-8 px-3 rounded-md text-[13px] text-text-secondary hover:bg-active hover:text-text-primary cursor-pointer">Remove</button></div> <div class="mt-3 flex items-center justify-between gap-4 py-1.5"><span class="text-[13px] text-text-secondary">Panel opacity</span> <!></div> <div class="flex items-center justify-between gap-4 py-1.5"><span class="text-[13px] text-text-secondary">Blur</span> <!></div> <div class="flex items-center justify-between gap-4 py-1.5"><span class="text-[13px] text-text-secondary">Fit</span> <div class="flex flex-wrap justify-end gap-1"></div></div>', 1),
  Oi = i('<button class="flex items-center gap-1.5 h-8 px-3 rounded-md text-[13px] font-medium bg-bg-elevated text-text-primary hover:bg-active cursor-pointer"><!> Choose image / GIF</button> <p class="mt-2 text-xs text-text-muted">Use a custom image or GIF as the app background.</p>', 1),
  Ui = i('<div class="flex items-center justify-between mb-4"><p class="text-[13px] text-text-muted">Pick a theme or build your own.</p> <div class="flex items-center gap-2"><button class="flex items-center gap-1.5 h-8 px-3 rounded-md text-[13px] font-medium bg-bg-elevated text-text-secondary hover:bg-active hover:text-text-primary cursor-pointer"><!> Import</button> <button class="flex items-center gap-1.5 h-8 px-3 rounded-md text-[13px] font-medium bg-bg-elevated text-text-primary hover:bg-active cursor-pointer"><!> New theme</button></div></div> <div class="grid grid-cols-2 gap-2.5"></div> <div class="mt-5 border-t border-border-subtle pt-4"><p class="text-[11px] font-medium uppercase tracking-wide text-text-muted mb-2.5">Background</p> <!></div> <div class="mt-5 border-t border-border-subtle pt-4"><p class="text-[11px] font-medium uppercase tracking-wide text-text-muted mb-2.5">Depth & texture</p> <div class="flex items-center justify-between gap-4 py-1.5"><div class="flex flex-col gap-0.5 min-w-0"><span class="text-[13px] text-text-secondary">Panel depth</span> <span class="text-xs text-text-muted">Subtle shadows and highlights so panels feel less flat.</span></div> <!></div> <div class="flex items-center justify-between gap-4 py-1.5"><div class="flex flex-col gap-0.5 min-w-0"><span class="text-[13px] text-text-secondary">Logo texture</span> <span class="text-xs text-text-muted">A faint, tiled constraintt.ez watermark behind the app.</span></div> <!></div></div> <!> <!>', 1),
  Bi = i('<div><span class="text-[13px] text-text-secondary"> </span> <div class="flex items-center gap-2"><input class="font-mono text-xs w-[88px] bg-input-bg border border-input-border rounded-md px-2 h-7 text-text-primary focus:outline-none focus:border-input-focus"/> <label class="relative size-7 rounded-md border border-border overflow-hidden cursor-pointer shrink-0"><input type="color" class="absolute -inset-1 opacity-0 cursor-pointer"/></label></div></div>'),
  Wi = i('<div class="mb-4"><p class="text-[11px] font-medium uppercase tracking-wide text-text-muted mb-1.5"> </p> <div class="rounded-lg border border-border-subtle overflow-hidden"></div></div>'),
  Vi = i('<div class="flex items-center gap-2 mb-5"><button aria-label="Back" class="grid size-8 place-items-center rounded-md text-text-muted hover:text-text-primary hover:bg-active cursor-pointer shrink-0"><!></button> <input placeholder="Theme name" class="flex-1 min-w-0 bg-input-bg border border-input-border rounded-md px-2.5 h-8 text-[13px] text-text-primary focus:outline-none focus:border-input-focus placeholder-text-muted"/> <div class="flex rounded-md border border-border-subtle p-0.5 shrink-0"><button>Dark</button> <button>Light</button></div> <button class="h-8 px-3 rounded-md text-[13px] text-text-secondary hover:text-text-primary hover:bg-active cursor-pointer shrink-0">Cancel</button> <button class="h-8 px-3.5 rounded-md text-[13px] font-medium bg-accent text-accent-fg hover:bg-accent-hover cursor-pointer shrink-0">Save</button></div> <!>', 1);

function Hi(l, o) {
  Dt(o, !0);
  const x = () => $t(Sr, "$background", v),
    [v, w] = Br();
  let P = C(Nt([])),
    c = C("default"),
    g = C(null),
    S = C(!0),
    O = C(!1);
  const D = cr.subscribe(k => {
    s(S, k["appearance.panel_depth"] !== !1), s(O, !!k["appearance.panel_texture"])
  });

  function K(k) {
    s(S, k, !0), cr.set_value("appearance.panel_depth", k), Ha(e(S), e(O))
  }

  function xe(k) {
    s(O, k, !0), cr.set_value("appearance.panel_texture", k), Ha(e(S), e(O))
  }

  function Q() {
    return [...wa().entries()].map(([k, L]) => ({
      id: k,
      name: L.name,
      type: L.type,
      tokens: L.tokens,
      builtin: Vn.has(k)
    }))
  }
  Tr(async () => {
    s(P, Q(), !0), s(c, await Bn("default"), !0)
  }), Ur(() => {
    e(g) && ye(), D()
  });

  function B(k) {
    const L = k.tokens;
    return L ? [L.bg, L.elevated, L.accent, L.text] : ["#0D0D0D", "#141414", "#FFFFFF", "#F5F5F7"]
  }

  function ye() {
    const k = wa().get(e(c));
    k && Wa.set(k), Wn(e(c))
  }

  function we(k) {
    const L = Na(k.name || "Custom", k.type, k.tokens);
    Wa.preview(L), Kn(L)
  }
  async function ue(k) {
    s(c, k, !0), await cr.apply_theme(k)
  }

  function ke() {
    s(g, {
      id: null,
      name: "Custom Theme",
      type: "dark",
      tokens: {
        ...Va
      }
    }, !0), we(e(g))
  }

  function U(k) {
    s(g, {
      id: null,
      name: `${k.name} Copy`,
      type: k.type,
      tokens: {
        ...k.tokens ?? Va
      }
    }, !0), we(e(g))
  }

  function W(k) {
    k.tokens && (s(g, {
      id: k.id,
      name: k.name,
      type: k.type,
      tokens: {
        ...k.tokens
      }
    }, !0), we(e(g)))
  }

  function le(k, L) {
    e(g) && (e(g).tokens[k] = L, we(e(g)))
  }

  function ee(k) {
    e(g) && (e(g).type = k, we(e(g)))
  }

  function fe(k) {
    e(g) && (e(g).name = k, we(e(g)))
  }

  function ie() {
    s(g, null), ye()
  }

  function $e(k) {
    var Oe;
    const L = k.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "theme",
      ae = wa();
    let Me = L,
      Be = 2;
    for (; ae.has(Me) && Me !== ((Oe = e(g)) == null ? void 0 : Oe.id);) Me = `${L}-${Be++}`;
    return Me
  }
  async function Z() {
    if (!e(g)) return;
    const k = e(g).id ?? $e(e(g).name),
      L = Na(e(g).name || "Custom", e(g).type, e(g).tokens);
    cn(k, L), await dn(k, L), cr.register_user_theme(k, L), await cr.apply_theme(k), s(c, k, !0), s(P, Q(), !0), s(g, null)
  }
  async function Y(k) {
    k.builtin || confirm(`Delete theme "${k.name}"?`) && (await qn(k.id), cr.unregister_theme(k.id), e(c) === k.id && await ue("default"), s(P, Q(), !0))
  }
  var re = wr(),
    J = Ge(re);
  {
    var ve = k => {
        var L = Ui(),
          ae = Ge(L),
          Me = a(r(ae), 2),
          Be = r(Me),
          Oe = r(Be);
        z(Oe, {
          name: "folder-open",
          size: 15
        }), Ae(), t(Be);
        var G = a(Be, 2),
          de = r(G);
        z(de, {
          name: "plus",
          size: 15
        }), Ae(), t(G), t(Me), t(ae);
        var Se = a(ae, 2);
        Ze(Se, 21, () => e(P), pe => pe.id, (pe, p) => {
          var u = Ti(),
            ge = r(u);
          Ze(ge, 21, () => B(e(p)), un, ($, X) => {
            var ne = Ri();
            y(() => sr(ne, `background:${e(X)??""}`)), n($, ne)
          }), t(ge);
          var be = a(ge, 2),
            Le = r(be),
            H = r(Le, !0);
          t(Le);
          var Ee = a(Le, 2);
          {
            var Te = $ => {
              z($, {
                name: "check",
                size: 15,
                class: "text-accent shrink-0"
              })
            };
            f(Ee, $ => {
              e(p).id === e(c) && $(Te)
            })
          }
          t(be);
          var et = a(be, 2),
            E = r(et);
          {
            var h = $ => {
              var X = Ii(),
                ne = Ge(X),
                T = r(ne);
              z(T, {
                name: "download",
                size: 13
              }), t(ne);
              var M = a(ne, 2),
                q = r(M);
              z(q, {
                name: "copy",
                size: 13
              }), t(M), d("click", ne, oe => {
                oe.stopPropagation(), ki(e(p).name, e(p).type, e(p).tokens)
              }), d("click", M, oe => {
                oe.stopPropagation(), U(e(p))
              }), n($, X)
            };
            f(E, $ => {
              e(p).tokens && $(h)
            })
          }
          var m = a(E, 2);
          {
            var b = $ => {
              var X = Ni(),
                ne = Ge(X),
                T = r(ne);
              z(T, {
                name: "pencil",
                size: 13
              }), t(ne);
              var M = a(ne, 2),
                q = r(M);
              z(q, {
                name: "trash",
                size: 13
              }), t(M), d("click", ne, oe => {
                oe.stopPropagation(), W(e(p))
              }), d("click", M, oe => {
                oe.stopPropagation(), Y(e(p))
              }), n($, X)
            };
            f(m, $ => {
              e(p).builtin || $(b)
            })
          }
          t(et), t(u), y(() => {
            me(u, 1, `group relative rounded-lg border p-3 cursor-pointer transition-colors
                    ${e(p).id===e(c)?"border-accent bg-bg-elevated":"border-border-subtle hover:border-border"}`), I(H, e(p).name)
          }), d("click", u, () => ue(e(p).id)), d("keydown", u, $ => {
            $.key === "Enter" && ue(e(p).id)
          }), n(pe, u)
        }), t(Se);
        var Pe = a(Se, 2),
          Ue = a(r(Pe), 2);
        {
          var He = pe => {
              var p = Fi(),
                u = Ge(p),
                ge = r(u),
                be = a(ge, 2),
                Le = a(be, 2);
              t(u);
              var H = a(u, 2),
                Ee = a(r(H), 2);
              {
                let m = A(() => Math.round(x().opacity * 100));
                xa(Ee, {
                  get value() {
                    return e(m)
                  },
                  min: 30,
                  max: 100,
                  step: 5,
                  unit: "%",
                  oninput: b => Sr.set_opacity(Number(b.currentTarget.value) / 100),
                  class: "w-44"
                })
              }
              t(H);
              var Te = a(H, 2),
                et = a(r(Te), 2);
              xa(et, {
                get value() {
                  return x().blur
                },
                min: 0,
                max: 24,
                step: 1,
                unit: "px",
                oninput: m => Sr.set_blur(Number(m.currentTarget.value)),
                class: "w-44"
              }), t(Te);
              var E = a(Te, 2),
                h = a(r(E), 2);
              Ze(h, 20, () => Gn, m => m, (m, b) => {
                var $ = ji(),
                  X = r($, !0);
                t($), y(() => {
                  me($, 1, `h-7 px-2 rounded-md text-xs capitalize cursor-pointer ${x().fit===b?"bg-bg-elevated text-text-primary":"text-text-muted hover:bg-active hover:text-text-primary"}`), I(X, b)
                }), d("click", $, () => Sr.set_fit(b)), n(m, $)
              }), t(h), t(E), y(() => sr(ge, x().url ? `background-image:url("${x().url}")` : "")), d("click", be, () => Sr.choose()), d("click", Le, () => Sr.clear()), n(pe, p)
            },
            We = pe => {
              var p = Oi(),
                u = Ge(p),
                ge = r(u);
              z(ge, {
                name: "palette",
                size: 15
              }), Ae(), t(u), Ae(2), d("click", u, () => Sr.choose()), n(pe, p)
            };
          f(Ue, pe => {
            x().enabled ? pe(He) : pe(We, -1)
          })
        }
        t(Pe);
        var je = a(Pe, 2),
          N = a(r(je), 2),
          Ye = a(r(N), 2);
        Gr(Ye, {
          get checked() {
            return e(S)
          },
          onchange: K
        }), t(N);
        var rt = a(N, 2),
          pt = a(r(rt), 2);
        Gr(pt, {
          get checked() {
            return e(O)
          },
          onchange: xe
        }), t(rt), t(je);
        var qe = a(je, 2);
        Li(qe, {});
        var at = a(qe, 2);
        Di(at, {}), d("click", Be, () => $i()), d("click", G, ke), n(k, L)
      },
      ze = k => {
        var L = Vi(),
          ae = Ge(L),
          Me = r(ae),
          Be = r(Me);
        z(Be, {
          name: "arrow-left",
          size: 16
        }), t(Me);
        var Oe = a(Me, 2);
        ur(Oe);
        var G = a(Oe, 2),
          de = r(G),
          Se = a(de, 2);
        t(G);
        var Pe = a(G, 2),
          Ue = a(Pe, 2);
        t(ae);
        var He = a(ae, 2);
        Ze(He, 17, () => Hn, We => We.label, (We, je) => {
          var N = Wi(),
            Ye = r(N),
            rt = r(Ye, !0);
          t(Ye);
          var pt = a(Ye, 2);
          Ze(pt, 23, () => e(je).tokens, qe => qe.key, (qe, at, pe) => {
            var p = Bi(),
              u = r(p),
              ge = r(u, !0);
            t(u);
            var be = a(u, 2),
              Le = r(be);
            ur(Le);
            var H = a(Le, 2),
              Ee = r(H);
            ur(Ee), t(H), t(be), t(p), y(() => {
              me(p, 1, `flex items-center justify-between px-3 h-11 ${e(pe)>0?"border-t border-border-subtle":""}`), I(ge, e(at).label), ua(Le, e(g).tokens[e(at).key]), sr(H, `background:${e(g).tokens[e(at).key]??""}`), ua(Ee, e(g).tokens[e(at).key])
            }), yr("blur", Le, Te => le(e(at).key, Te.currentTarget.value)), d("input", Ee, Te => le(e(at).key, Te.currentTarget.value)), n(qe, p)
          }), t(pt), t(N), y(() => I(rt, e(je).label)), n(We, N)
        }), y(() => {
          ua(Oe, e(g).name), me(de, 1, `px-2.5 h-7 rounded text-xs cursor-pointer ${e(g).type==="dark"?"bg-bg-elevated text-text-primary":"text-text-muted hover:text-text-primary"}`), me(Se, 1, `px-2.5 h-7 rounded text-xs cursor-pointer ${e(g).type==="light"?"bg-bg-elevated text-text-primary":"text-text-muted hover:text-text-primary"}`)
        }), d("click", Me, ie), d("input", Oe, We => fe(We.currentTarget.value)), d("click", de, () => ee("dark")), d("click", Se, () => ee("light")), d("click", Pe, ie), d("click", Ue, Z), n(k, L)
      };
    f(J, k => {
      e(g) ? k(ze, -1) : k(ve)
    })
  }
  n(l, re), Rt(), w()
}
Yt(["click", "keydown", "input"]);
var qi = i('<div class="flex flex-col gap-3"><div class="flex items-center justify-between gap-4 border-b border-border-subtle pb-3" style="display:flex !important; visibility:visible !important; opacity:1 !important"><div class="flex flex-col gap-0.5 min-w-0"><span class="text-[13px] text-text-primary">Enable custom CSS</span> <span class="text-xs text-text-muted">Inject your own styles to restyle the whole app. Applied on top of the active theme.</span></div> <!></div> <div class="flex items-center justify-between gap-3"><span class="text-xs text-text-muted">Target component classes; theme colours need <span class="font-mono text-text-secondary">:root</span> selectors.</span> <button style="display:inline-flex !important; visibility:visible !important; opacity:1 !important" class="flex items-center gap-1.5 h-8 px-3 rounded-md text-[13px] text-text-secondary hover:bg-active hover:text-text-primary cursor-pointer shrink-0"><!> Reset</button></div> <textarea spellcheck="false" style="display:block !important; visibility:visible !important; opacity:1 !important" class="h-80 w-full resize-none rounded-lg border border-input-border bg-input-bg p-3 font-mono text-[12px] leading-relaxed text-text-primary placeholder-text-muted focus:outline-none focus:border-input-focus"></textarea></div>');

function Ki(l, o) {
  Dt(o, !0);
  let x = C(!1),
    v = C("");
  const w = ha.subscribe(B => {
    s(x, B.enabled, !0), s(v, B.css, !0)
  });
  Ur(() => w());

  function P(B) {
    ha.set(B.currentTarget.value)
  }

  function c() {
    ha.clear(), gt.success("Custom CSS cleared")
  }
  var g = qi(),
    S = r(g),
    O = a(r(S), 2);
  Gr(O, {
    get checked() {
      return e(x)
    },
    onchange: B => ha.set_enabled(B)
  }), t(S);
  var D = a(S, 2),
    K = a(r(D), 2),
    xe = r(K);
  z(xe, {
    name: "trash",
    size: 14
  }), Ae(), t(K), t(D);
  var Q = a(D, 2);
  Cn(Q), ut(Q, "placeholder", `/* example */
.depth-card { border-radius: 0; }
.app-bg::after { background: rgba(0,0,0,.5); }`), t(g), y(() => ua(Q, e(v))), d("click", K, c), d("input", Q, P), n(l, g), Rt()
}
Yt(["click", "input"]);

function Gi() {
  return lr("exclude_from_defender")
}
var Yi = i(`<div class="flex flex-col gap-4"><div class="rounded-xl bg-bg-elevated p-4"><div class="flex items-center gap-2 text-[13px] font-semibold text-text-primary"><!> Windows Security</div> <p class="mt-2 text-xs leading-relaxed text-text-muted">Add the constraintt.ez folder to the Windows Defender exclusion list so its files aren't scanned or quarantined.
            This needs administrator approval, so a Windows prompt will appear.</p> <button class="mt-3 flex h-9 items-center gap-2 rounded-lg bg-accent px-3.5 text-[13px] font-semibold text-accent-fg hover:bg-accent-hover cursor-pointer disabled:opacity-50"><!> Exclude constraintt.ez from Defender</button></div> <div class="rounded-xl bg-bg-elevated p-4"><div class="flex items-center gap-2 text-[13px] font-semibold text-text-primary"><!> Getting started</div> <p class="mt-2 text-xs leading-relaxed text-text-muted">New to constraintt.ez? Replay the guided tour to walk through each tab.</p> <button class="mt-3 flex h-9 items-center gap-2 rounded-lg bg-accent px-3.5 text-[13px] font-semibold text-accent-fg hover:bg-accent-hover cursor-pointer"><!> Replay tutorial</button></div></div>`);

function Xi(l, o) {
  Dt(o, !0);
  let x = C(!1);
  const v = {
      added: "Excluded from Defender",
      already: "Already excluded",
      cancelled: "Cancelled",
      error: "Couldn't exclude"
    },
    w = {
      added: "success",
      already: "info",
      cancelled: "warning",
      error: "error"
    };
  async function P() {
    if (e(x)) return;
    s(x, !0);
    const ue = gt.loading("Requesting Defender exclusion…", {
      message: "Approve the Windows prompt."
    });
    try {
      const ke = await Gi();
      gt.update(ue, {
        type: w[ke.status],
        title: v[ke.status],
        message: ke.message
      })
    } catch (ke) {
      gt.update(ue, {
        type: "error",
        title: "Couldn't exclude",
        message: String(ke)
      })
    } finally {
      s(x, !1)
    }
  }
  var c = Yi(),
    g = r(c),
    S = r(g),
    O = r(S);
  z(O, {
    name: "shield",
    size: 15
  }), Ae(), t(S);
  var D = a(S, 4),
    K = r(D);
  z(K, {
    name: "shield",
    size: 14
  }), Ae(), t(D), t(g);
  var xe = a(g, 2),
    Q = r(xe),
    B = r(Q);
  z(B, {
    name: "info",
    size: 15
  }), Ae(), t(Q);
  var ye = a(Q, 4),
    we = r(ye);
  z(we, {
    name: "sparkles",
    size: 14
  }), Ae(), t(ye), t(xe), t(c), y(() => D.disabled = e(x)), d("click", D, P), d("click", ye, () => Yn.set(!0)), n(l, c), Rt()
}
Yt(["click"]);
var Ji = i('<div class="flex h-44 items-center justify-center gap-2 text-[13px] text-text-muted"><!> Checking the MCP installation…</div>'),
  Qi = i('<div class="rounded-xl bg-danger-surface p-4 text-[13px] text-danger ring-1 ring-inset ring-danger/20"> </div>'),
  Zi = i('<button class="flex h-9 shrink-0 items-center justify-center gap-2 rounded-lg bg-text-primary px-4 text-[12px] font-semibold text-bg-base hover:brightness-95 cursor-pointer transition-[filter] disabled:pointer-events-none disabled:opacity-50"><!> </button>'),
  es = i('<p class="mt-2 truncate text-[9.5px] text-danger"> </p>'),
  ts = i('<article><div class="flex items-start justify-between gap-3"><div class="grid size-10 shrink-0 place-items-center rounded-xl bg-bg-active text-text-primary ring-1 ring-inset ring-line/70 transition-transform duration-150 group-hover:scale-[1.03]"><!></div> <span><span></span> </span></div> <div class="mt-3 min-w-0"><div class="flex items-center gap-2"><h4 class="truncate text-[12.5px] font-semibold text-text-primary"> </h4> <span class="rounded bg-bg-active px-1.5 py-0.5 text-[8.5px] font-medium uppercase tracking-[0.06em] text-text-muted"> </span></div> <p class="mt-1 line-clamp-2 text-[10px] leading-relaxed text-text-muted"> </p></div> <div class="mt-auto pt-3"><button><!> </button></div> <!></article>'),
  rs = i('<div class="flex items-center gap-5 py-3.5"><div class="min-w-0 flex-1"><div class="text-[12.5px] font-semibold text-text-primary"> </div> <div class="mt-0.5 text-[11.5px] leading-relaxed text-text-muted"> </div></div> <div class="flex shrink-0 items-center gap-2"><!> <!></div></div>'),
  as = i('<div class="flex items-center gap-3 rounded-lg bg-bg-elevated p-3 ring-1 ring-inset ring-line/70"><div class="min-w-0 flex-1"><div class="text-[12px] font-semibold text-text-primary"> </div> <div class="mt-0.5 text-[10.5px] leading-relaxed text-text-muted"> </div></div> <div class="flex shrink-0 items-center gap-2"><!> <!></div></div>'),
  ns = i('<section class="overflow-hidden rounded-xl bg-bg-elevated ring-1 ring-inset ring-line/70"><div class="flex flex-wrap items-center gap-4 border-b border-line/60 px-4 py-3.5"><div class="grid size-9 shrink-0 place-items-center rounded-lg bg-bg-active text-text-primary ring-1 ring-inset ring-line/70"><!></div> <div class="min-w-0 flex-1"><h3 class="text-[13px] font-semibold text-text-primary">Choose your MCP client</h3> <p class="mt-0.5 text-[11px] text-text-muted">Select a client and constraintt.ez handles its setup.</p></div> <div class="flex items-center gap-3"><div class="text-right"><div class="text-[11px] font-semibold tabular-nums text-text-secondary"> </div> <div class="mt-0.5 text-[9.5px] text-text-muted"> </div></div> <button class="flex h-9 items-center gap-2 rounded-lg bg-text-primary px-4 text-[11.5px] font-semibold text-bg-base shadow-sm hover:-translate-y-px hover:brightness-95 hover:shadow-md cursor-pointer transition-[transform,filter,box-shadow] disabled:pointer-events-none disabled:translate-y-0 disabled:opacity-40 disabled:shadow-none"><!> Set up detected clients</button></div></div> <div class="h-0.5 bg-bg-base/50"><div class="h-full bg-success transition-[width] duration-300"></div></div> <div class="grid gap-2.5 p-3 sm:grid-cols-2 xl:grid-cols-4"></div></section> <section><div class="mb-2 flex items-center justify-between gap-3"><div><h3 class="text-[13px] font-semibold text-text-primary">What MCP clients can do</h3> <p class="mt-1 text-[12px] text-text-muted">Turn access on or off whenever you want.</p></div> <span class="rounded-full bg-bg-elevated px-2 py-0.5 text-[10.5px] font-medium text-text-muted ring-1 ring-inset ring-line"> </span></div> <div class="divide-y divide-line/50 rounded-xl bg-bg-elevated px-4 ring-1 ring-inset ring-line/70"></div></section> <section><div class="mb-3"><h3 class="text-[13px] font-semibold text-text-primary">Connection options</h3> <p class="mt-1 text-[12px] text-text-muted">Choose how constraintt.ez behaves while an MCP client is connected.</p></div> <div class="grid gap-2 sm:grid-cols-2"></div></section>', 1),
  is = i('<div class="flex flex-col gap-7"><section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-bg-elevated to-bg-base/70 p-5 ring-1 ring-inset ring-line/70"><div class="pointer-events-none absolute -right-12 -top-16 size-40 rounded-full bg-info-soft/35 blur-3xl"></div> <div class="relative flex flex-col gap-4 sm:flex-row sm:items-center"><div class="grid size-12 shrink-0 place-items-center rounded-2xl bg-bg-active text-text-primary ring-1 ring-inset ring-line"><!></div> <div class="min-w-0 flex-1"><div class="flex flex-wrap items-center gap-2"><h3 class="text-[15px] font-semibold text-text-primary">constraintt.ez MCP</h3> <span><span></span> </span></div> <p class="mt-1.5 max-w-2xl text-[12.5px] leading-relaxed text-text-muted">Connect MCP clients to constraintt.ez. Download it once, then choose a client below and press Set up.</p></div> <!></div></section> <!></div>');

function ss(l, o) {
  Dt(o, !0);
  const x = [{
      key: "runtime_execute",
      label: "Run code",
      description: "Let connected MCP clients run code in your selected game."
    }, {
      key: "runtime_inspect",
      label: "View game",
      description: "Let MCP clients view objects, scripts, and other game information."
    }, {
      key: "runtime_settings",
      label: "Change settings",
      description: "Let MCP clients change supported constraintt.ez options."
    }, {
      key: "runtime_files",
      label: "Use files",
      description: "Let MCP clients read and save scripts in constraintt.ez's folders."
    }, {
      key: "runtime_input",
      label: "Control the game",
      description: "Let MCP clients use the keyboard and mouse in Roblox."
    }, {
      key: "logs",
      label: "Read console",
      description: "Let MCP clients read recent Roblox output."
    }],
    v = [{
      key: "RedirectOutput",
      label: "Share output",
      description: "Show Roblox output in constraintt.ez and connected MCP clients."
    }, {
      key: "InternalUIEnabled",
      label: "In-game UI",
      description: "Keep the constraintt.ez interface visible inside Roblox."
    }, {
      key: "AntiAfkEnabled",
      label: "Anti-AFK",
      description: "Prevent idle disconnects while connected."
    }, {
      key: "RakNetEnabled",
      label: "Extra network support",
      description: "Enable constraintt.ez's optional network mode."
    }],
    w = {
      "claude-desktop": {
        icon: "app-window",
        kind: "Desktop"
      },
      "claude-code": {
        icon: "terminal",
        kind: "CLI"
      },
      cursor: {
        icon: "code",
        kind: "Editor"
      },
      codex: {
        icon: "sparkles",
        kind: "Agent"
      },
      vscode: {
        icon: "code",
        kind: "Editor"
      },
      gemini: {
        icon: "sparkles",
        kind: "CLI"
      },
      windsurf: {
        icon: "code",
        kind: "Editor"
      },
      opencode: {
        icon: "terminal",
        kind: "Agent"
      }
    };

  function P(J) {
    return w[J.id] ?? {
      icon: "terminal",
      kind: J.format
    }
  }
  let c = C(null),
    g = C(!0),
    S = C(!1),
    O = C(null),
    D = C(null),
    K = C(!1),
    xe = C(null);
  Tr(() => {
    Q()
  });
  async function Q() {
    s(g, !0), s(xe, null);
    try {
      s(c, await lr("get_mcp_info"), !0)
    } catch (J) {
      s(xe, String(J), !0)
    } finally {
      s(g, !1)
    }
  }
  async function B() {
    if (!e(S)) {
      s(S, !0);
      try {
        s(c, await lr("download_mcp_server"), !0), gt.success("constraintt.ez MCP installed", {
          message: "Choose an MCP client below and press Set up."
        })
      } catch (J) {
        gt.error("MCP download failed", {
          message: String(J)
        })
      } finally {
        s(S, !1)
      }
    }
  }
  async function ye(J, ve, ze) {
    if (!e(c) || e(O)) return;
    const k = e(c);
    s(c, {
      ...e(c),
      permissions: J,
      runtimeSettings: ve
    }, !0), s(O, ze, !0);
    try {
      s(c, await lr("save_mcp_config", {
        permissions: J,
        runtimeSettings: ve
      }), !0)
    } catch (L) {
      s(c, k, !0), gt.error("Couldn't save MCP settings", {
        message: String(L)
      })
    } finally {
      s(O, null)
    }
  }
  async function we(J) {
    var ve;
    if (!(!((ve = e(c)) != null && ve.available) || e(D) || e(K))) {
      s(D, J.id, !0);
      try {
        const ze = await lr("configure_mcp_client", {
          clientId: J.id
        });
        s(c, await lr("get_mcp_info"), !0), gt.success(ze.changed ? `${ze.name} configured` : `${ze.name} is ready`, {
          message: "Restart the app so it can connect to constraintt.ez."
        })
      } catch (ze) {
        gt.error(`${J.name} setup failed`, {
          message: String(ze)
        })
      } finally {
        s(D, null)
      }
    }
  }
  async function ue(J) {
    if (!(e(D) || e(K))) {
      s(D, J.id, !0);
      try {
        const ve = await lr("remove_mcp_client", {
          clientId: J.id
        });
        s(c, await lr("get_mcp_info"), !0), gt.success(ve.changed ? `MCP removed from ${ve.name}` : `${ve.name} was already disconnected`, {
          message: "Restart the client to finish disconnecting it from constraintt.ez."
        })
      } catch (ve) {
        gt.error(`${J.name} removal failed`, {
          message: String(ve)
        })
      } finally {
        s(D, null)
      }
    }
  }
  async function ke() {
    var k;
    if (!((k = e(c)) != null && k.available) || e(D) || e(K)) return;
    const J = e(c).clients.filter(L => L.detected && !L.configured);
    if (!J.length) {
      gt.success("Detected clients are ready");
      return
    }
    s(K, !0);
    let ve = 0;
    const ze = [];
    for (const L of J) {
      s(D, L.id, !0);
      try {
        await lr("configure_mcp_client", {
          clientId: L.id
        }), ve += 1
      } catch {
        ze.push(L.name)
      }
    }
    try {
      s(c, await lr("get_mcp_info"), !0), ve && gt.success(`${ve} client${ve===1?"":"s"} configured`, {
        message: "Restart each app so it can connect to constraintt.ez."
      }), ze.length && gt.error("Some clients need manual setup", {
        message: ze.join(", ")
      })
    } finally {
      s(D, null), s(K, !1)
    }
  }

  function U(J, ve) {
    e(c) && ye({
      ...e(c).permissions,
      [J]: ve
    }, e(c).runtimeSettings, J)
  }

  function W(J, ve) {
    e(c) && ye(e(c).permissions, {
      ...e(c).runtimeSettings,
      [J]: ve
    }, J)
  }
  const le = A(() => e(c) ? Object.values(e(c).permissions).filter(Boolean).length : 0),
    ee = A(() => e(c) ? e(c).clients.filter(J => J.detected).length : 0),
    fe = A(() => e(c) ? e(c).clients.filter(J => J.configured).length : 0);
  var ie = wr(),
    $e = Ge(ie);
  {
    var Z = J => {
        var ve = Ji(),
          ze = r(ve);
        Gt(ze, {
          size: 14
        }), Ae(), t(ve), n(J, ve)
      },
      Y = J => {
        var ve = Qi(),
          ze = r(ve, !0);
        t(ve), y(() => I(ze, e(xe))), n(J, ve)
      },
      re = J => {
        var ve = is(),
          ze = r(ve),
          k = a(r(ze), 2),
          L = r(k),
          ae = r(L);
        z(ae, {
          name: "plug",
          size: 21
        }), t(L);
        var Me = a(L, 2),
          Be = r(Me),
          Oe = a(r(Be), 2),
          G = r(Oe),
          de = a(G);
        t(Oe), t(Be), Ae(2), t(Me);
        var Se = a(Me, 2);
        {
          var Pe = We => {
            var je = Zi(),
              N = r(je);
            {
              var Ye = qe => {
                  Gt(qe, {
                    size: 12
                  })
                },
                rt = qe => {
                  z(qe, {
                    name: "download",
                    size: 13
                  })
                };
              f(N, qe => {
                e(S) ? qe(Ye) : qe(rt, -1)
              })
            }
            var pt = a(N);
            t(je), y(() => {
              je.disabled = e(S), I(pt, ` ${e(S)?"Downloading…":"Download"}`)
            }), d("click", je, B), n(We, je)
          };
          f(Se, We => {
            e(c).available || We(Pe)
          })
        }
        t(k), t(ze);
        var Ue = a(ze, 2);
        {
          var He = We => {
            var je = ns(),
              N = Ge(je),
              Ye = r(N),
              rt = r(Ye),
              pt = r(rt);
            z(pt, {
              name: "plug",
              size: 16
            }), t(rt);
            var qe = a(rt, 4),
              at = r(qe),
              pe = r(at),
              p = r(pe);
            t(pe);
            var u = a(pe, 2),
              ge = r(u);
            t(u), t(at);
            var be = a(at, 2),
              Le = r(be);
            {
              var H = M => {
                  Gt(M, {
                    size: 11
                  })
                },
                Ee = M => {
                  z(M, {
                    name: "sparkles",
                    size: 11
                  })
                };
              f(Le, M => {
                e(K) ? M(H) : M(Ee, -1)
              })
            }
            Ae(), t(be), t(qe), t(Ye);
            var Te = a(Ye, 2),
              et = r(Te);
            t(Te);
            var E = a(Te, 2);
            Ze(E, 21, () => e(c).clients, M => M.id, (M, q) => {
              const oe = A(() => P(e(q)));
              var j = ts(),
                V = r(j),
                De = r(V),
                tt = r(De);
              z(tt, {
                get name() {
                  return e(oe).icon
                },
                size: 18
              }), t(De);
              var Qe = a(De, 2),
                R = r(Qe),
                _e = a(R);
              t(Qe), t(V);
              var te = a(V, 2),
                he = r(te),
                Re = r(he),
                lt = r(Re, !0);
              t(Re);
              var dt = a(Re, 2),
                Tt = r(dt, !0);
              t(dt), t(he);
              var Ft = a(he, 2),
                jt = r(Ft, !0);
              t(Ft), t(te);
              var _t = a(te, 2),
                bt = r(_t),
                It = r(bt);
              {
                var Ke = zt => {
                    Gt(zt, {
                      size: 12
                    })
                  },
                  Mt = zt => {
                    {
                      let Jt = A(() => e(q).configured ? "trash" : "plug");
                      z(zt, {
                        get name() {
                          return e(Jt)
                        },
                        size: 12
                      })
                    }
                  };
                f(It, zt => {
                  e(D) === e(q).id ? zt(Ke) : zt(Mt, -1)
                })
              }
              var Ot = a(It);
              t(bt), t(_t);
              var Ut = a(_t, 2);
              {
                var ar = zt => {
                  var Jt = es(),
                    or = r(Jt, !0);
                  t(Jt), y(() => {
                    ut(Jt, "title", e(q).configError), I(or, e(q).configError)
                  }), n(zt, Jt)
                };
                f(Ut, zt => {
                  e(q).configError && zt(ar)
                })
              }
              t(j), y(() => {
                me(j, 1, `group flex min-h-[178px] flex-col rounded-xl bg-bg-base/35 p-3 ring-1 ring-inset transition-[background-color,box-shadow] hover:bg-bg-base/55 ${e(q).configured?"ring-success/25":"ring-line/70"}`), ut(De, "title", `${e(q).name} client`), me(Qe, 1, `flex shrink-0 items-center gap-1.5 rounded-full px-2 py-1 text-[9px] font-semibold ${e(q).configured?"bg-success-soft text-success":e(q).detected?"bg-info-soft text-info":"bg-bg-active text-text-muted"}`), me(R, 1, `size-1.5 rounded-full ${e(q).configured?"bg-success":e(q).detected?"bg-info":"bg-text-muted/50"}`), I(_e, ` ${e(q).configured?"Ready":e(q).detected?"Detected":"Available"}`), I(lt, e(q).name), I(Tt, e(oe).kind), I(jt, e(q).description), bt.disabled = e(K) || e(D) !== null, me(bt, 1, `flex h-9 w-full items-center justify-center gap-2 rounded-lg px-3 text-[11px] font-semibold shadow-sm cursor-pointer transition-[transform,filter,box-shadow,color,background-color] disabled:pointer-events-none disabled:translate-y-0 disabled:opacity-40 disabled:shadow-none ${e(q).configured?"bg-danger-soft text-danger ring-1 ring-inset ring-danger/20 hover:-translate-y-px hover:bg-danger/15 hover:shadow-md":"bg-text-primary text-bg-base hover:-translate-y-px hover:brightness-95 hover:shadow-md"}`), I(Ot, ` ${e(q).configured?"Remove MCP":"Set up client"}`)
              }), d("click", bt, () => e(q).configured ? ue(e(q)) : we(e(q))), n(M, j)
            }), t(E), t(N);
            var h = a(N, 2),
              m = r(h),
              b = a(r(m), 2),
              $ = r(b);
            t(b), t(m);
            var X = a(m, 2);
            Ze(X, 21, () => x, M => M.key, (M, q) => {
              var oe = rs(),
                j = r(oe),
                V = r(j),
                De = r(V, !0);
              t(V);
              var tt = a(V, 2),
                Qe = r(tt, !0);
              t(tt), t(j);
              var R = a(j, 2),
                _e = r(R);
              {
                var te = Re => {
                  Gt(Re, {
                    size: 11
                  })
                };
                f(_e, Re => {
                  e(O) === e(q).key && Re(te)
                })
              }
              var he = a(_e, 2);
              {
                let Re = A(() => !!e(c).permissions[e(q).key]),
                  lt = A(() => e(O) !== null);
                Gr(he, {
                  get checked() {
                    return e(Re)
                  },
                  get disabled() {
                    return e(lt)
                  },
                  onchange: dt => U(e(q).key, dt)
                })
              }
              t(R), t(oe), y(() => {
                I(De, e(q).label), I(Qe, e(q).description)
              }), n(M, oe)
            }), t(X), t(h);
            var ne = a(h, 2),
              T = a(r(ne), 2);
            Ze(T, 21, () => v, M => M.key, (M, q) => {
              var oe = as(),
                j = r(oe),
                V = r(j),
                De = r(V, !0);
              t(V);
              var tt = a(V, 2),
                Qe = r(tt, !0);
              t(tt), t(j);
              var R = a(j, 2),
                _e = r(R);
              {
                var te = Re => {
                  Gt(Re, {
                    size: 11
                  })
                };
                f(_e, Re => {
                  e(O) === e(q).key && Re(te)
                })
              }
              var he = a(_e, 2);
              {
                let Re = A(() => !!e(c).runtimeSettings[e(q).key]),
                  lt = A(() => e(O) !== null);
                Gr(he, {
                  get checked() {
                    return e(Re)
                  },
                  get disabled() {
                    return e(lt)
                  },
                  onchange: dt => W(e(q).key, dt)
                })
              }
              t(R), t(oe), y(() => {
                I(De, e(q).label), I(Qe, e(q).description)
              }), n(M, oe)
            }), t(T), t(ne), y(() => {
              I(p, `${e(fe)??""} of ${e(c).clients.length??""} ready`), I(ge, `${e(ee)??""} detected on this PC`), be.disabled = e(K) || e(D) !== null || e(ee) === 0, sr(et, `width:${e(c).clients.length?e(fe)/e(c).clients.length*100:0}%`), I($, `${e(le)??""}/${x.length??""}`)
            }), d("click", be, ke), n(We, je)
          };
          f(Ue, We => {
            e(c).available && We(He)
          })
        }
        t(ve), y(() => {
          me(Oe, 1, `flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-medium ring-1 ring-inset ${e(c).available?"bg-success-soft text-success ring-success/20":"bg-warning-soft text-warning ring-warning/20"}`), me(G, 1, `size-1.5 rounded-full ${e(c).available?"bg-success":"bg-warning"}`), I(de, ` ${e(c).available?"Ready":"Download needed"}`)
        }), n(J, ve)
      };
    f($e, J => {
      e(g) ? J(Z) : e(xe) ? J(Y, 1) : e(c) && J(re, 2)
    })
  }
  n(l, ie), Rt()
}
Yt(["click"]);
var os = i('<span class="rounded bg-bg-base/70 px-1.5 py-0.5 font-mono text-[8.5px] text-text-muted ring-1 ring-inset ring-line/60"> </span>'),
  ls = i('<section class="sticky top-5 overflow-hidden rounded-xl bg-bg-elevated ring-1 ring-inset ring-line/70"><div class="border-b border-line/60 px-3.5 py-2.5"><div class="flex flex-wrap items-center justify-between gap-2"><h3 class="text-[13px] font-semibold text-text-primary">Preview</h3> <div class="flex flex-wrap gap-1"></div></div> <p class="mt-1 text-[10.5px] leading-relaxed text-text-muted">A sample of how decompiled code looks with your current formatting and options.</p></div> <div class="max-h-[calc(100vh-210px)] overflow-auto bg-bg-base/65"><pre class="min-w-max p-3.5 font-mono text-[10.5px] leading-[1.55] text-text-secondary selection:bg-accent/25"><code> </code></pre></div></section>');

function cs(l, o) {
  Dt(o, !0);
  const x = ke => `Decompiler.${ke}`,
    v = (ke, U) => o.values[x(ke)] ?? U,
    w = (ke, U = !1) => !!v(ke, U),
    P = (ke, U) => String(v(ke, U)),
    c = (ke, U) => Number(v(ke, U));

  function g() {
    const ke = Math.min(16, Math.max(1, c("Formatting.IndentSize", 4))),
      U = P("Formatting.Indentation", "Spaces") === "Tabs" ? "	" : " ".repeat(ke),
      W = P("Formatting.Newlines", "Lf") === "CrLf" ? `\r
` : `
`,
      le = w("Formatting.TerminateStatements"),
      ee = T => `${T}${le?";":""}`,
      fe = P("Formatting.StringQuotes", "Automatic"),
      ie = T => {
        const M = fe === "Single" ? "'" : fe === "Double" ? '"' : T.includes('"') && !T.includes("'") ? "'" : '"',
          q = T.replaceAll("\\", "\\\\").replaceAll(M, `\\${M}`).replaceAll(`
`, "\\n");
        return `${M}${q}${M}`
      },
      $e = P("Formatting.TrailingCommas", "Multiline") === "Multiline" ? "," : "",
      Z = P("Formatting.TableBraces", "PadNonEmpty"),
      Y = (T, M = !1) => Z === "PadAlways" || !M && Z === "PadNonEmpty" ? `{ ${T} }` : `{${T}}`,
      re = Math.min(1e3, Math.max(0, c("Formatting.PreferredLineWidth", 120))),
      J = P("Formatting.TableLayout", "Automatic"),
      ve = P("Formatting.ArgumentLayout", "Automatic"),
      ze = Math.min(100, Math.max(0, c("Formatting.MaximumInlineArguments", 4))),
      k = J === "Expanded",
      L = ve === "Expanded",
      ae = ve === "Automatic",
      Me = w("Options.UseDebugSymbols", !0),
      Be = w("Options.InferDescriptiveLocals", !0),
      Oe = w("Options.AggressiveNames"),
      G = Me ? "VehicleController" : "v1",
      de = Be ? "inputState" : "arg3",
      Se = Oe ? "movementVector" : "moveVector",
      Pe = Me ? "vehicleSeat" : Be ? "seat" : "v2",
      He = `BaseCharacterController${P("Options.ModuleSuffix","m")}`,
      We = w("Options.RestoreTypeHints", !0),
      je = w("Options.SeparateLogicalSections", !0),
      N = [];
    if (N.push(ee(`local ContextActionService = game:GetService(${ie("ContextActionService")})`)), N.push(ee(`local ${He} = require(script.Parent:WaitForChild(${ie("BaseCharacterController")}))`)), N.push(ee(`local ${G} = setmetatable(${Y("",!0)}, ${He})`)), N.push(ee(`${G}.__index = ${G}`)), k) {
      N.push("local actions = {");
      const T = w("Options.EvaluateStaticStrings", !0) ? ie("VehicleThrottle") : `${ie("Vehicle")} .. ${ie("Throttle")}`;
      N.push(`${U}throttle = ${T}${$e}`), N.push(`${U}steer = ${ie("VehicleSteer")}${$e}`), N.push(ee("}"))
    } else {
      const T = w("Options.EvaluateStaticStrings", !0) ? ie("VehicleThrottle") : `${ie("Vehicle")} .. ${ie("Throttle")}`;
      N.push(ee(`local actions = ${Y(`throttle = ${T}, steer = ${ie("VehicleSteer")}`)}`))
    }
    const Ye = [ie("Accelerate"), ie('Brake "Reverse"'), ie("Steer")];
    if (J === "Compact") N.push(ee(`local inputNames = ${Y(Ye.join(", "))}`));
    else {
      N.push("local inputNames = {");
      for (const T of Ye) N.push(`${U}${T}${$e}`);
      N.push(ee("}"))
    }
    je && N.push(""), w("Options.AlignToOriginalLines") && N.push("", "", "");
    const rt = We ? [`${G}: table`, `${Se}: Vector3`, `${de}: Enum.UserInputState`] : [G, Se, de],
      pt = w("Options.PreferNamedFunctionSyntax", !0),
      qe = P("Formatting.AnnotationPlacement", "Inline"),
      at = w("Formatting.EmitFunctionAnnotations", !0),
      pe = at && w("Formatting.AnnotateFunctionNames", !0),
      p = at && w("Formatting.AnnotateSourceLines", !0),
      u = at && w("Formatting.AnnotateCapturedValues", !0);
    qe === "SeparateLines" && (pe && N.push("-- function: Update"), p && N.push("-- line: 135"));
    let ge = pt ? `function ${G}.Update(${rt.join(", ")})` : `${G}.Update = function(${rt.join(", ")})`;
    if (qe === "Inline" && (pe && (ge += " --[[ Update ]]"), p && (ge += " -- line: 135")), N.push(ge), u) {
      N.push(`${U}-- upvalues:`);
      const T = P("Formatting.CaptureDetail", "NameAndCaptureKind"),
        M = q => T === "NamesOnly" ? "" : ` (${q})`;
      N.push(`${U}--  [1] ContextActionService${M("copy")}`), N.push(`${U}--  [2] ${de}${M("ref")}`), N.push("")
    }
    const Le = Math.min(1e4, Math.max(0, c("Options.LocalLifetimeScopeThreshold", 0))) > 0;
    Le && N.push(`${U}do`);
    const H = Le ? U + U : U;
    N.push(`${H}${ee(`local ${Pe} = ${G}.vehicleSeat`)}`);
    const Ee = w("Options.RestoreTemplateStrings", !0) ? `\`Input rejected: {${de}.Name}\`` : `${ie("Input rejected: ")} .. ${de}.Name`;
    N.push(`${H}${ee(`local errorMessage = ${Ee}`)}`);
    const Te = `${Pe} and (${de} == Enum.UserInputState.Begin or ${de} == Enum.UserInputState.Change)`;
    w("Formatting.WrapConditions", !0) ? (N.push(`${H}if (`), N.push(`${H}${U}${Pe}`), N.push(`${H}${U}and (${de} == Enum.UserInputState.Begin`), N.push(`${H}${U}${U}or ${de} == Enum.UserInputState.Change)`), N.push(`${H}) then`)) : N.push(`${H}if ${Te} then`);
    const E = H + U;
    if (L || ae && 3 > ze) N.push(`${E}${Se} ${w("Options.RecoverCompoundAssignments",!0)?"+=":"="} Vector3.new(`), N.push(`${E}${U}${G}.steer,`), N.push(`${E}${U}0,`), N.push(`${E}${U}${G}.throttle${$e}`), N.push(`${E}${ee(")")}`);
    else {
      const T = `Vector3.new(${G}.steer, 0, ${G}.throttle)`,
        M = w("Options.RecoverCompoundAssignments", !0) ? `${Se} += ${T}` : `${Se} = ${Se} + ${T}`;
      N.push(`${E}${ee(M)}`)
    }
    P("Formatting.ElseIf", "Collapsed") === "Nested" ? (N.push(`${H}else`), N.push(`${E}if ${de} == Enum.UserInputState.Cancel then`), N.push(`${E}${U}${ee(`${Se} = Vector3.new(0, 0, 0)`)}`), N.push(`${E}end`)) : (N.push(`${H}elseif ${de} == Enum.UserInputState.Cancel then`), N.push(`${E}${ee(`${Se} = Vector3.new(0, 0, 0)`)}`)), N.push(`${H}end`), je && N.push("");
    const b = ["actions.steer", "function() end", "false", "Enum.KeyCode.A", "Enum.KeyCode.D", "Enum.KeyCode.Thumbstick1"],
      $ = `ContextActionService:BindAction(${b.join(", ")})`.length + H.length;
    if (L || ae && re > 0 && $ > re) {
      N.push(`${H}ContextActionService:BindAction(`);
      for (const [T, M] of b.entries()) {
        const q = T === b.length - 1 ? $e : ",";
        N.push(`${H}${U}${M}${q}`)
      }
      N.push(`${H}${ee(")")}`)
    } else N.push(`${H}${ee(`ContextActionService:BindAction(${b.join(", ")})`)}`);
    w("Options.FlattenTerminalBranches", !0) ? (N.push(`${H}if not ${Pe} then`), N.push(`${E}${ee(`return ${Se}, false, errorMessage`)}`), N.push(`${H}end`), N.push(`${H}${ee(`return ${Se}, true`)}`)) : (N.push(`${H}if ${Pe} then`), N.push(`${E}${ee(`return ${Se}, true`)}`), N.push(`${H}else`), N.push(`${E}${ee(`return ${Se}, false, errorMessage`)}`), N.push(`${H}end`)), Le && N.push(`${U}end`), N.push("end"), je && N.push(""), N.push(ee(`return ${G}`));
    const ne = N.join(W);
    return w("Formatting.EndWithNewline", !0) ? `${ne}${W}` : ne
  }
  const S = A(g),
    O = A(() => [P("Formatting.Indentation", "Spaces") === "Tabs" ? "Tabs" : `${c("Formatting.IndentSize",4)} spaces`, P("Formatting.Newlines", "Lf") === "CrLf" ? "CRLF" : "LF", c("Formatting.PreferredLineWidth", 120) === 0 ? "No width limit" : `${c("Formatting.PreferredLineWidth",120)} cols`, w("Formatting.EndWithNewline", !0) ? "Final newline" : "No final newline"]);
  var D = ls(),
    K = r(D),
    xe = r(K),
    Q = a(r(xe), 2);
  Ze(Q, 21, () => e(O), un, (ke, U) => {
    var W = os(),
      le = r(W, !0);
    t(W), y(() => I(le, e(U))), n(ke, W)
  }), t(Q), t(xe), Ae(2), t(K);
  var B = a(K, 2),
    ye = r(B),
    we = r(ye),
    ue = r(we, !0);
  t(we), t(ye), t(B), t(D), y(() => I(ue, e(S))), n(l, D), Rt()
}
const fa = Ln(null);

function Ya(l) {
  return l === null ? null : `0x${(l>>>0).toString(16).toUpperCase().padStart(8,"0")}`
}
const Da = {
  seed: fa,
  label: Pn(fa, Ya),
  async load() {
    try {
      const l = await lr("get_hwid_seed");
      return fa.set(l), l
    } catch (l) {
      return console.error(`[hwid] couldn't read the seed: ${l}`), fa.set(null), null
    }
  },
  async randomize() {
    try {
      const l = await lr("randomize_hwid_seed");
      return fa.set(l), gt.success("HWID seed randomized", {
        message: Ya(l) ?? void 0
      }), l
    } catch (l) {
      return console.error(`[hwid] randomize failed: ${l}`), gt.error("Couldn't randomize the HWID seed", {
        message: String(l)
      }), null
    }
  }
};
var ds = i('<span class="text-[12.5px] leading-relaxed text-text-muted"> </span>'),
  us = i('<input type="number"/>'),
  ps = i('<input type="text"/>'),
  vs = i('<span class="font-mono text-[11px] text-text-muted"> </span>'),
  xs = i('<div class="flex flex-col items-end gap-1.5"><button class="flex h-8 min-w-28 items-center justify-center gap-1.5 rounded-md bg-bg-elevated px-3 text-[12.5px] font-medium text-text-secondary ring-1 ring-inset ring-line cursor-pointer transition-colors hover:text-text-primary disabled:pointer-events-none disabled:opacity-50"><!> </button> <!></div>'),
  ms = i("<button> </button>"),
  fs = i('<div><div><span> </span> <!></div>  <div class="shrink-0 pt-0.5"><!></div></div>'),
  gs = i('<button class="grid size-4 place-items-center rounded text-text-muted hover:text-text-primary cursor-pointer" aria-label="Clear search"><!></button>'),
  bs = i('<button><!> <span class="text-[13px] font-medium"> </span></button>'),
  _s = i('<div class="flex flex-col gap-2 rounded-md bg-bg-elevated p-3 ring-1 ring-inset ring-line"><span class="text-[12px] font-medium text-text-primary">Reset all settings?</span> <span class="text-[11px] leading-relaxed text-text-muted">This will restore every setting to its default value.</span> <div class="mt-1 flex gap-2"><button class="flex-1 h-7 rounded text-[12px] text-text-muted hover:text-text-primary cursor-pointer transition-colors">Cancel</button> <button class="flex-1 h-7 rounded bg-text-primary text-[12px] font-medium text-bg-base hover:brightness-95 cursor-pointer transition-[filter]">Reset</button></div></div>'),
  hs = i('<button class="flex h-8 w-full items-center justify-center gap-2 rounded-md text-[12px] text-text-muted ring-1 ring-inset ring-line hover:text-text-primary hover:ring-text-primary/25 transition-[color,box-shadow] cursor-pointer"><!> Reset all settings</button>'),
  ys = i('<div class="py-16 text-center text-[13px] text-text-muted">No settings match your search.</div>'),
  ws = i('<section class="mb-8"><button class="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted hover:text-text-primary transition-colors cursor-pointer"><!> </button> <div class="flex flex-col divide-y divide-line/40"></div></section>'),
  ks = i('<div><div class="mb-8"><h2 class="text-[24px] font-semibold leading-none tracking-[-0.015em] text-text-primary">Search results</h2> <p class="mt-2.5 text-[13.5px] leading-relaxed text-text-muted"> <span class="font-semibold text-text-secondary"> </span></p></div> <!></div>'),
  $s = i('<p class="mt-2.5 text-[13.5px] leading-relaxed text-text-muted"> </p>'),
  zs = i('<div class="mb-10"><!></div>'),
  Ss = i('<section class="relative z-10 rounded-xl bg-bg-elevated/45 ring-1 ring-inset ring-line/70"><div class="border-b border-line/60 px-3.5 py-2.5"><h3 class="text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted"> </h3></div> <div class="divide-y divide-line/40 px-3.5"></div></section>'),
  Cs = i('<div class="grid items-start gap-3 xl:grid-cols-[repeat(3,minmax(0,1fr))_minmax(360px,1.18fr)]"><!> <!></div>'),
  Ps = i('<div class="flex flex-col divide-y divide-line/40"></div>'),
  Ls = i('<button class="mt-6 flex h-8 items-center gap-2 rounded-md px-3 text-[12.5px] text-text-muted hover:text-text-primary cursor-pointer transition-colors"><!> Reset all keybinds</button>'),
  Es = i("<!> <!> <!>", 1),
  As = i('<div><div><h2 class="text-[24px] font-semibold leading-none tracking-[-0.015em] text-text-primary"> </h2> <!></div> <!></div>'),
  Ms = i('<div class="flex h-full w-full bg-bg-base text-text-primary"><aside class="flex w-64 shrink-0 flex-col border-r border-line"><div class="flex shrink-0 flex-col gap-4 px-4 pt-5 pb-4"><button class="flex h-7 w-fit items-center gap-1.5 text-[12px] text-text-muted hover:text-text-primary transition-colors cursor-pointer"><!> </button> <h1 class="text-[22px] font-semibold leading-none tracking-[-0.02em] text-text-primary">Settings</h1> <label class="flex h-8 items-center gap-2 rounded-md bg-bg-elevated px-2.5 ring-1 ring-inset ring-line/60 focus-within:ring-text-primary/25 transition-[box-shadow]"><!> <input placeholder="Search settings" class="min-w-0 flex-1 bg-transparent text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none"/> <!></label></div> <nav class="flex min-h-0 flex-1 flex-col gap-0.5 overflow-y-auto px-2 pb-3"></nav> <div class="shrink-0 border-t border-line p-3"><!></div></aside> <div class="min-h-0 flex-1 overflow-y-auto"><div><!></div></div></div>');

function Ds(l, o) {
  Dt(o, !0);
  const x = () => $t(P, "$hwid_label", v),
    [v, w] = Br(),
    P = Da.label;
  let c = Nr(o, "backLabel", 3, "Editor"),
    g = C(Nt({})),
    S = C(Nt(ea[0].id)),
    O = C(null),
    D = C(""),
    K = C(!1);
  const xe = cr.subscribe(pe => {
    s(g, pe, !0)
  });
  Ur(() => xe()), Tr(() => {
    Da.load()
  });

  function Q(pe, p) {
    cr.set_value(pe, p)
  }

  function B(pe, p, u, ge) {
    const be = Number(p);
    Number.isFinite(be) && Q(pe, Math.min(ge, Math.max(u, be)))
  }
  async function ye(pe) {
    if (s(S, pe, !0), s(D, ""), pe === "decompiler") try {
      await lr("request_executor_settings")
    } catch (p) {
      console.error(`[decompiler] couldn't request current settings: ${p}`)
    }
  }
  let we = C(null);
  const ue = {
    randomize_hwid: () => Da.randomize()
  };
  async function ke(pe, p) {
    if (!e(we)) {
      s(we, pe, !0);
      try {
        await ue[p]()
      } finally {
        s(we, null)
      }
    }
  }

  function U() {
    const pe = ea.find(p => p.id === "keybinds");
    for (const p of (pe == null ? void 0 : pe.settings) ?? []) Q(p.key, p.default)
  }

  function W() {
    for (const pe of ea)
      for (const p of pe.settings) Q(p.key, p.default);
    s(K, !1)
  }

  function le(pe) {
    s(O, pe, !0)
  }

  function ee(pe, p) {
    if (e(O) !== p) return;
    pe.preventDefault();
    const u = [];
    pe.ctrlKey && u.push("Ctrl"), pe.shiftKey && u.push("Shift"), pe.altKey && u.push("Alt"), pe.metaKey && u.push("Meta");
    const ge = pe.key;
    ["Control", "Shift", "Alt", "Meta"].includes(ge) || (u.push(ge === " " ? "Space" : ge.length === 1 ? ge.toUpperCase() : ge), Q(p, u.join("+")), s(O, null))
  }
  const fe = {
      general: {
        title: "General",
        hint: "Core app behavior, startup, performance."
      },
      client: {
        title: "Client",
        hint: "How the injected client behaves in Roblox."
      },
      decompiler: {
        title: "Decompiler",
        hint: "Control how decompiled scripts are recovered and formatted."
      },
      editor: {
        title: "Editor",
        hint: "Text editor, font, and editing behavior."
      },
      appearance: {
        title: "Appearance",
        hint: "Theme, colors, and visual settings."
      },
      custom_css: {
        title: "Custom CSS",
        hint: "Personal interface styles."
      },
      mcp: {
        title: "MCP server",
        hint: "Connect AI clients and control which constraintt.ez tools they can use."
      },
      keybinds: {
        title: "Keybinds",
        hint: "Keyboard shortcuts."
      },
      system: {
        title: "System",
        hint: "Maintenance, defender, and help."
      }
    },
    ie = A(() => ea.find(pe => pe.id === e(S))),
    $e = A(() => fe[e(ie).id] ?? {
      title: e(ie).label,
      hint: ""
    }),
    Z = A(() => [{
      title: "Recovery",
      settings: e(ie).id === "decompiler" ? e(ie).settings.slice(0, 13) : []
    }, {
      title: "Output",
      settings: e(ie).id === "decompiler" ? e(ie).settings.slice(13, 24) : []
    }, {
      title: "Style",
      settings: e(ie).id === "decompiler" ? e(ie).settings.slice(24) : []
    }]),
    Y = A(() => e(D).trim().toLowerCase()),
    re = A(() => e(Y).length >= 2),
    J = A(() => e(re) ? ea.flatMap(pe => pe.settings.filter(p => {
      var u;
      return p.label.toLowerCase().includes(e(Y)) || (((u = p.description) == null ? void 0 : u.toLowerCase().includes(e(Y))) ?? !1) || p.key.toLowerCase().includes(e(Y))
    }).map(p => ({
      category: pe,
      setting: p
    }))) : []),
    ve = A(() => () => {
      const pe = new Map;
      for (const p of e(J)) {
        const u = pe.get(p.category.id) ?? [];
        u.push(p), pe.set(p.category.id, u)
      }
      return [...pe.entries()].map(([p, u]) => ({
        category: ea.find(ge => ge.id === p),
        hits: u
      }))
    });
  var ze = Ms();
  {
    const pe = (p, u = da, ge) => {
      let be = va(() => en(ge == null ? void 0 : ge(), !1));
      var Le = fs(),
        H = r(Le),
        Ee = r(H),
        Te = r(Ee, !0);
      t(Ee);
      var et = a(Ee, 2);
      {
        var E = j => {
          var V = ds(),
            De = r(V, !0);
          t(V), y(() => I(De, u().description)), n(j, V)
        };
        f(et, j => {
          u().description && !e(be) && j(E)
        })
      }
      t(H);
      var h = a(H, 2),
        m = r(h);
      {
        var b = j => {
            const V = A(() => !!e(g)[u().key]);
            Gr(j, {
              get checked() {
                return e(V)
              },
              onchange: De => Q(u().key, De)
            })
          },
          $ = j => {
            qa(j, {
              get value() {
                return e(g)[u().key]
              },
              get options() {
                return u().option.options
              },
              onchange: V => Q(u().key, V)
            })
          },
          X = j => {
            {
              let V = A(() => u().option.options());
              qa(j, {
                get value() {
                  return e(g)[u().key]
                },
                get options() {
                  return e(V)
                },
                onchange: De => Q(u().key, De)
              })
            }
          },
          ne = j => {
            const V = A(() => e(g)[u().key]);
            {
              let De = A(() => u().option.unit ?? ""),
                tt = A(() => e(be) ? "w-28" : "w-44");
              xa(j, {
                get value() {
                  return e(V)
                },
                get min() {
                  return u().option.min
                },
                get max() {
                  return u().option.max
                },
                get step() {
                  return u().option.step
                },
                get unit() {
                  return e(De)
                },
                oninput: Qe => Q(u().key, Number(Qe.currentTarget.value)),
                get class() {
                  return e(tt)
                }
              })
            }
          },
          T = j => {
            var V = us();
            ur(V), y(() => {
              ua(V, e(g)[u().key]), ut(V, "min", u().option.min), ut(V, "max", u().option.max), ut(V, "step", u().option.step ?? 1), me(V, 1, `h-7 rounded-md bg-bg-elevated px-2 font-mono text-[11.5px] text-text-primary ring-1 ring-inset ring-line focus:outline-none focus:ring-text-primary/25 transition-[box-shadow] ${e(be)?"w-20":"w-32"}`)
            }), yr("blur", V, De => B(u().key, De.currentTarget.value, u().option.min, u().option.max)), n(j, V)
          },
          M = j => {
            var V = ps();
            ur(V), y(() => {
              ua(V, e(g)[u().key]), ut(V, "placeholder", u().option.placeholder), me(V, 1, `h-7 rounded-md bg-bg-elevated px-2 text-[12px] text-text-primary placeholder:text-text-muted ring-1 ring-inset ring-line focus:outline-none focus:ring-text-primary/25 transition-[box-shadow] ${e(be)?"w-24":"w-48"}`)
            }), yr("blur", V, De => Q(u().key, De.currentTarget.value)), n(j, V)
          },
          q = j => {
            const V = A(() => e(we) === u().key);
            var De = xs(),
              tt = r(De),
              Qe = r(tt);
            {
              var R = Re => {
                Gt(Re, {
                  size: 12
                })
              };
              f(Qe, Re => {
                e(V) && Re(R)
              })
            }
            var _e = a(Qe);
            t(tt);
            var te = a(tt, 2);
            {
              var he = Re => {
                var lt = vs(),
                  dt = r(lt);
                t(lt), y(() => I(dt, `Current seed: ${x()??""}`)), n(Re, lt)
              };
              f(te, Re => {
                u().option.action === "randomize_hwid" && x() && Re(he)
              })
            }
            t(De), y(() => {
              tt.disabled = e(V), I(_e, ` ${u().option.label??""}`)
            }), d("click", tt, () => ke(u().key, u().option.action)), n(j, De)
          },
          oe = j => {
            const V = A(() => e(O) === u().key);
            var De = ms(),
              tt = r(De, !0);
            t(De), y(() => {
              me(De, 1, `min-w-28 h-8 px-3 rounded-md font-mono text-[11.5px] text-center cursor-pointer transition-colors
                            ${e(V)?"bg-bg-elevated text-text-primary ring-1 ring-inset ring-text-primary/40":"bg-bg-elevated text-text-secondary ring-1 ring-inset ring-line hover:text-text-primary"}`), I(tt, e(V) ? "Press keys" : e(g)[u().key])
            }), d("click", De, () => le(u().key)), d("keydown", De, Qe => ee(Qe, u().key)), yr("blur", De, () => s(O, null)), n(j, De)
          };
        f(m, j => {
          u().option.type === "toggle" ? j(b) : u().option.type === "dropdown" ? j($, 1) : u().option.type === "dynamic" ? j(X, 2) : u().option.type === "slider" ? j(ne, 3) : u().option.type === "number" ? j(T, 4) : u().option.type === "text" ? j(M, 5) : u().option.type === "action" ? j(q, 6) : u().option.type === "keybind" && j(oe, 7)
        })
      }
      t(h), t(Le), y(() => {
        me(Le, 1, `flex items-start justify-between ${e(be)?"gap-3 py-2.5":"gap-8 py-4"}
                ${u().option.type==="toggle"?"cursor-pointer select-none":""}`), me(H, 1, `flex min-w-0 flex-1 flex-col ${e(be)?"gap-0.5":"gap-1"}`), ut(H, "title", e(be) ? u().description : void 0), me(Ee, 1, `font-semibold text-text-primary ${e(be)?"text-[12px] leading-tight":"text-[13.5px]"}`), I(Te, u().label)
      }), d("click", Le, function(...j) {
        var V;
        (V = u().option.type === "toggle" ? () => Q(u().key, !e(g)[u().key]) : void 0) == null || V.apply(this, j)
      }), d("click", h, j => j.stopPropagation()), n(p, Le)
    };
    var k = r(ze),
      L = r(k),
      ae = r(L),
      Me = r(ae);
    z(Me, {
      name: "arrow-left",
      size: 12,
      class: "shrink-0"
    });
    var Be = a(Me);
    t(ae);
    var Oe = a(ae, 4),
      G = r(Oe);
    z(G, {
      name: "search",
      size: 13,
      class: "shrink-0 text-text-muted"
    });
    var de = a(G, 2);
    ur(de);
    var Se = a(de, 2);
    {
      var Pe = p => {
        var u = gs(),
          ge = r(u);
        z(ge, {
          name: "x",
          size: 11
        }), t(u), d("click", u, () => s(D, "")), n(p, u)
      };
      f(Se, p => {
        e(D) && p(Pe)
      })
    }
    t(Oe), t(L);
    var Ue = a(L, 2);
    Ze(Ue, 21, () => ea, p => p.id, (p, u) => {
      const ge = A(() => !e(re) && e(S) === e(u).id);
      var be = bs(),
        Le = r(be);
      z(Le, {
        get name() {
          return e(u).icon
        },
        size: 15,
        class: "shrink-0"
      });
      var H = a(Le, 2),
        Ee = r(H, !0);
      t(H), t(be), y(() => {
        var Te;
        me(be, 1, `flex items-center gap-2.5 rounded-[8px] px-2.5 py-2 text-left cursor-pointer transition-[background-color,color] duration-[120ms]
                        ${e(ge)?"bg-bg-elevated text-text-primary":"text-text-muted hover:text-text-primary"}`), I(Ee, ((Te = fe[e(u).id]) == null ? void 0 : Te.title) ?? e(u).label)
      }), d("click", be, () => ye(e(u).id)), n(p, be)
    }), t(Ue);
    var He = a(Ue, 2),
      We = r(He);
    {
      var je = p => {
          var u = _s(),
            ge = a(r(u), 4),
            be = r(ge),
            Le = a(be, 2);
          t(ge), t(u), d("click", be, () => s(K, !1)), d("click", Le, W), n(p, u)
        },
        N = p => {
          var u = hs(),
            ge = r(u);
          z(ge, {
            name: "refresh",
            size: 12
          }), Ae(), t(u), d("click", u, () => s(K, !0)), n(p, u)
        };
      f(We, p => {
        e(K) ? p(je) : p(N, -1)
      })
    }
    t(He), t(k);
    var Ye = a(k, 2),
      rt = r(Ye),
      pt = r(rt);
    {
      var qe = p => {
          var u = ks(),
            ge = r(u),
            be = a(r(ge), 2),
            Le = r(be),
            H = a(Le),
            Ee = r(H);
          t(H), t(be), t(ge);
          var Te = a(ge, 2);
          {
            var et = h => {
                var m = ys();
                n(h, m)
              },
              E = h => {
                var m = wr(),
                  b = Ge(m);
                Ze(b, 17, () => e(ve)(), $ => $.category.id, ($, X) => {
                  var ne = ws(),
                    T = r(ne),
                    M = r(T);
                  z(M, {
                    get name() {
                      return e(X).category.icon
                    },
                    size: 12
                  });
                  var q = a(M);
                  t(T);
                  var oe = a(T, 2);
                  Ze(oe, 21, () => e(X).hits, j => j.setting.key, (j, V) => {
                    pe(j, () => e(V).setting)
                  }), t(oe), t(ne), y(() => {
                    var j;
                    return I(q, ` ${((j=fe[e(X).category.id])==null?void 0:j.title)??e(X).category.label??""}`)
                  }), d("click", T, () => ye(e(X).category.id)), n($, ne)
                }), n(h, m)
              };
            f(Te, h => {
              e(J).length === 0 ? h(et) : h(E, -1)
            })
          }
          t(u), y(() => {
            I(Le, `${e(J).length??""} match${e(J).length===1?"":"es"} for `), I(Ee, `“${e(D)??""}”`)
          }), Ir(1, u, () => ra, () => ({
            y: 8
          })), n(p, u)
        },
        at = p => {
          var u = wr(),
            ge = Ge(u);
          fn(ge, () => e(ie).id, be => {
            var Le = As(),
              H = r(Le),
              Ee = r(H),
              Te = r(Ee, !0);
            t(Ee);
            var et = a(Ee, 2);
            {
              var E = ne => {
                var T = $s(),
                  M = r(T, !0);
                t(T), y(() => I(M, e($e).hint)), n(ne, T)
              };
              f(et, ne => {
                e($e).hint && ne(E)
              })
            }
            t(H);
            var h = a(H, 2);
            {
              var m = ne => {
                  Ki(ne, {})
                },
                b = ne => {
                  ss(ne, {})
                },
                $ = ne => {
                  Xi(ne, {})
                },
                X = ne => {
                  var T = Es(),
                    M = Ge(T);
                  {
                    var q = Qe => {
                      var R = zs(),
                        _e = r(R);
                      Hi(_e, {}), t(R), n(Qe, R)
                    };
                    f(M, Qe => {
                      e(ie).id === "appearance" && Qe(q)
                    })
                  }
                  var oe = a(M, 2);
                  {
                    var j = Qe => {
                        var R = Cs(),
                          _e = r(R);
                        Ze(_e, 17, () => e(Z), he => he.title, (he, Re) => {
                          var lt = Ss(),
                            dt = r(lt),
                            Tt = r(dt),
                            Ft = r(Tt, !0);
                          t(Tt), t(dt);
                          var jt = a(dt, 2);
                          Ze(jt, 21, () => e(Re).settings, _t => _t.key, (_t, bt) => {
                            pe(_t, () => e(bt), () => !0)
                          }), t(jt), t(lt), y(() => I(Ft, e(Re).title)), n(he, lt)
                        });
                        var te = a(_e, 2);
                        cs(te, {
                          get values() {
                            return e(g)
                          }
                        }), t(R), n(Qe, R)
                      },
                      V = Qe => {
                        var R = Ps();
                        Ze(R, 21, () => e(ie).settings, _e => _e.key, (_e, te) => {
                          pe(_e, () => e(te))
                        }), t(R), n(Qe, R)
                      };
                    f(oe, Qe => {
                      e(ie).id === "decompiler" ? Qe(j) : e(ie).settings.length > 0 && Qe(V, 1)
                    })
                  }
                  var De = a(oe, 2);
                  {
                    var tt = Qe => {
                      var R = Ls(),
                        _e = r(R);
                      z(_e, {
                        name: "refresh",
                        size: 13
                      }), Ae(), t(R), d("click", R, U), n(Qe, R)
                    };
                    f(De, Qe => {
                      e(ie).id === "keybinds" && e(ie).settings.length > 0 && Qe(tt)
                    })
                  }
                  n(ne, T)
                };
              f(h, ne => {
                e(ie).id === "custom_css" ? ne(m) : e(ie).id === "mcp" ? ne(b, 1) : e(ie).id === "system" ? ne($, 2) : ne(X, -1)
              })
            }
            t(Le), y(() => {
              me(H, 1, pn(e(ie).id === "decompiler" ? "mb-5" : "mb-8")), I(Te, e($e).title)
            }), Ir(1, Le, () => ra, () => ({
              y: 8
            })), n(be, Le)
          }), n(p, u)
        };
      f(pt, p => {
        e(re) ? p(qe) : p(at, -1)
      })
    }
    t(rt), t(Ye), t(ze), y(() => {
      I(Be, ` ${c()??""}`), me(rt, 1, `mx-auto w-full pb-20 ${e(S)==="decompiler"?"max-w-[1680px] px-6 pt-7":e(S)==="mcp"?"max-w-4xl px-10 pt-12":"max-w-2xl px-10 pt-12"}`)
    }), d("click", ae, () => {
      var p;
      return (p = o.onback) == null ? void 0 : p.call(o)
    }), Or(de, () => e(D), p => s(D, p))
  }
  n(l, ze), Rt(), w()
}
Yt(["click", "keydown"]);
var Rs = i('<span class="rounded bg-bg-active px-1.5 py-0.5 text-[10px] font-medium text-text-secondary ring-1 ring-inset ring-line"> </span>'),
  Is = i('<button class="grid size-7 place-items-center rounded-md text-text-muted hover:text-text-primary cursor-pointer" aria-label="Close clients panel"><!></button>'),
  Ns = i('<div class="flex h-full flex-col items-center justify-center gap-3 px-6 text-center text-text-muted"><!> <p class="text-[13px] text-text-secondary">No Roblox clients running</p> <p class="text-[12px] text-text-muted">Launch Roblox — it attaches to constraintt.ez on its own.</p> <button class="mt-1 flex h-8 items-center gap-1.5 rounded-md bg-text-primary px-3 text-[12.5px] font-medium text-bg-base cursor-pointer transition-[filter] hover:brightness-95 disabled:pointer-events-none disabled:opacity-50"><!> Launch Roblox</button></div>'),
  Ts = i('<button class="text-[12px] text-text-secondary hover:text-text-primary cursor-pointer transition-colors"> </button>'),
  js = i('<img alt="" class="size-full object-cover"/>'),
  Fs = i('<span class="shrink-0 rounded bg-success-soft px-1.5 py-px text-[10px] font-medium text-success ring-1 ring-inset ring-success/25">Attached</span>'),
  Os = i('<button aria-label="Close this client" class="grid size-7 place-items-center rounded-md text-text-muted opacity-0 transition-opacity duration-[140ms] hover:text-danger cursor-pointer group-hover:opacity-100"><!></button>'),
  Us = i('<li class="group flex items-center gap-3 rounded-md bg-bg-elevated p-2.5 pr-2 ring-1 ring-inset ring-line/60"><div class="grid size-9 shrink-0 place-items-center overflow-hidden rounded-full bg-bg-base ring-1 ring-inset ring-line"><!></div> <div class="min-w-0 flex-1"><div class="flex items-center gap-1.5"><span class="truncate text-[12.5px] font-medium text-text-primary"> </span> <!></div> <div class="mt-0.5 flex items-center gap-1.5 text-[11px] text-text-muted"><span></span> <span> </span> <span class="text-text-muted/50">·</span> <span class="truncate"> </span> <span class="text-text-muted/50">·</span> <span class="shrink-0 tabular-nums"> </span></div></div> <div class="flex shrink-0 items-center gap-1"><!> <!></div></li>'),
  Bs = i('<button class="mt-1 flex items-center justify-center gap-1.5 py-1 text-[12px] text-text-muted hover:text-danger cursor-pointer transition-colors"><!> Close all clients</button>'),
  Ws = i('<div class="flex flex-col gap-3 px-3 py-3"><div class="flex items-center justify-between px-1"><span class="text-[11px] text-text-muted">Scripts run on the selected clients.</span> <!></div> <ul class="flex flex-col gap-1.5"></ul> <!></div>'),
  Vs = i('<main class="flex h-full min-h-0 flex-col bg-bg-base text-text-primary"><header class="flex h-11 shrink-0 items-center gap-2 border-b border-line px-4"><h1 class="flex-1 text-[13px] font-semibold tracking-tight">Clients</h1> <!> <!></header> <div class="min-h-0 flex-1 overflow-y-auto"><!></div></main>');

function Hs(l, o) {
  Dt(o, !0);
  const x = () => $t(g, "$instances", P),
    v = () => $t(S, "$executeTargets", P),
    w = () => $t(O, "$launching", P),
    [P, c] = Br(),
    g = Xt.instances,
    S = Xt.executeTargets,
    O = $a.launching;
  let D = C(Nt(Date.now())),
    K = C(Nt(new Set)),
    xe = null;
  Tr(() => {
    xe = setInterval(() => s(D, Date.now(), !0), 1e3)
  }), Ur(() => {
    xe && clearInterval(xe)
  });
  const Q = A(() => x().length > 0 && x().every($e => v().has($e.pid)));

  function B($e) {
    s(K, new Set(e(K)).add($e), !0)
  }

  function ye($e) {
    const Z = Math.max(0, Math.floor($e / 1e3)),
      Y = Math.floor(Z / 3600),
      re = Math.floor(Z % 3600 / 60);
    return Y > 0 ? `${Y}h ${re}m` : re > 0 ? `${re}m` : `${Z%60}s`
  }
  var we = Vs(),
    ue = r(we),
    ke = a(r(ue), 2);
  {
    var U = $e => {
      var Z = Rs(),
        Y = r(Z, !0);
      t(Z), y(() => I(Y, x().length)), n($e, Z)
    };
    f(ke, $e => {
      x().length > 0 && $e(U)
    })
  }
  var W = a(ke, 2);
  ct(W, {
    label: "Close panel",
    children: ($e, Z) => {
      var Y = Is(),
        re = r(Y);
      z(re, {
        name: "x",
        size: 13
      }), t(Y), d("click", Y, () => {
        var J;
        return (J = o.onclose) == null ? void 0 : J.call(o)
      }), n($e, Y)
    },
    $$slots: {
      default: !0
    }
  }), t(ue);
  var le = a(ue, 2),
    ee = r(le);
  {
    var fe = $e => {
        var Z = Ns(),
          Y = r(Z);
        z(Y, {
          name: "roblox",
          size: 28,
          class: "text-text-muted"
        });
        var re = a(Y, 6),
          J = r(re);
        {
          var ve = k => {
              Gt(k, {
                size: 12
              })
            },
            ze = k => {
              z(k, {
                name: "rocket",
                size: 12
              })
            };
          f(J, k => {
            w() ? k(ve) : k(ze, -1)
          })
        }
        Ae(), t(re), t(Z), y(() => re.disabled = w()), d("click", re, () => $a.launch()), n($e, Z)
      },
      ie = $e => {
        var Z = Ws(),
          Y = r(Z),
          re = a(r(Y), 2);
        {
          var J = L => {
            var ae = Ts(),
              Me = r(ae, !0);
            t(ae), y(() => I(Me, e(Q) ? "Clear" : "Select all")), d("click", ae, () => e(Q) ? Xt.deselect_all() : Xt.select_all()), n(L, ae)
          };
          f(re, L => {
            x().length >= 2 && L(J)
          })
        }
        t(Y);
        var ve = a(Y, 2);
        Ze(ve, 5, x, L => L.pid, (L, ae) => {
          var Me = Us(),
            Be = r(Me),
            Oe = r(Be);
          {
            var G = H => {
                var Ee = js();
                y(Te => ut(Ee, "src", Te), [() => Xt.avatar(e(ae))]), yr("error", Ee, () => B(e(ae).pid)), Za(Ee), n(H, Ee)
              },
              de = A(() => Xt.avatar(e(ae)) && !e(K).has(e(ae).pid)),
              Se = H => {
                z(H, {
                  name: "roblox",
                  size: 15,
                  class: "text-text-secondary"
                })
              };
            f(Oe, H => {
              e(de) ? H(G) : H(Se, -1)
            })
          }
          t(Be);
          var Pe = a(Be, 2),
            Ue = r(Pe),
            He = r(Ue),
            We = r(He, !0);
          t(He);
          var je = a(He, 2);
          {
            var N = H => {
              {
                let Ee = A(() => e(ae).client_version ? ` · client ${e(ae).client_version}` : "");
                ct(H, {
                  get label() {
                    return `constraintt.ez is attached${e(Ee)??""}`
                  },
                  children: (Te, et) => {
                    var E = Fs();
                    n(Te, E)
                  },
                  $$slots: {
                    default: !0
                  }
                })
              }
            };
            f(je, H => {
              e(ae).attached && H(N)
            })
          }
          t(Ue);
          var Ye = a(Ue, 2),
            rt = r(Ye),
            pt = a(rt, 2),
            qe = r(pt, !0);
          t(pt);
          var at = a(pt, 4),
            pe = r(at, !0);
          t(at);
          var p = a(at, 4),
            u = r(p, !0);
          t(p), t(Ye), t(Pe);
          var ge = a(Pe, 2),
            be = r(ge);
          {
            let H = A(() => v().has(e(ae).pid) ? "Receives scripts" : "Skipped when executing");
            ct(be, {
              get label() {
                return e(H)
              },
              children: (Ee, Te) => {
                {
                  let et = A(() => v().has(e(ae).pid));
                  Gr(Ee, {
                    get checked() {
                      return e(et)
                    },
                    onchange: () => Xt.toggle_execute_target(e(ae).pid)
                  })
                }
              },
              $$slots: {
                default: !0
              }
            })
          }
          var Le = a(be, 2);
          ct(Le, {
            label: "Close client",
            children: (H, Ee) => {
              var Te = Os(),
                et = r(Te);
              z(et, {
                name: "screen-share-off",
                size: 13
              }), t(Te), d("click", Te, () => Xt.kill(e(ae).pid)), n(H, Te)
            },
            $$slots: {
              default: !0
            }
          }), t(ge), t(Me), y((H, Ee, Te) => {
            I(We, H), me(rt, 1, `size-1.5 rounded-full ${e(ae).in_game?"bg-success":"bg-text-muted/60"}`), I(qe, e(ae).in_game ? "In game" : "Menu"), I(pe, Ee), I(u, Te)
          }, [() => Xt.title(e(ae)), () => Xt.subtitle(e(ae)), () => ye(e(D) - e(ae).start_time * 1e3)]), n(L, Me)
        }), t(ve);
        var ze = a(ve, 2);
        {
          var k = L => {
            var ae = Bs(),
              Me = r(ae);
            z(Me, {
              name: "screen-share-off",
              size: 12
            }), Ae(), t(ae), d("click", ae, () => Xt.kill_all()), n(L, ae)
          };
          f(ze, L => {
            x().length > 1 && L(k)
          })
        }
        t(Z), Ir(1, Z, () => ra, () => ({
          y: 8
        })), n($e, Z)
      };
    f(ee, $e => {
      x().length === 0 ? $e(fe) : $e(ie, -1)
    })
  }
  t(le), t(we), n(l, we), Rt(), c()
}
Yt(["click"]);
const qs = "https://rscripts.net/api/v2/scripts",
  Ks = l => {
    const o = !!l.rawScript && /^https?:\/\//i.test(l.rawScript);
    return {
      _id: `rscripts:${l._id}`,
      title: l.title,
      views: l.views ?? 0,
      likes: l.likes ?? 0,
      private: l.private,
      verified: l.verified,
      keySystem: l.keySystem,
      patched: l.patched,
      game: l.game,
      image: l.image,
      user: l.user,
      content: o ? void 0 : l.script ?? l.rawScript,
      rawUrl: o ? l.rawScript : void 0
    }
  },
  Gs = {
    id: "rscripts",
    label: "Rscripts",
    logo: "/providers/rscripts.svg",
    sorts: [{
      label: "Latest",
      value: "date"
    }, {
      label: "Views",
      value: "views"
    }, {
      label: "Likes",
      value: "likes"
    }],
    async fetchScripts({
      page: l,
      query: o,
      sort: x,
      dir: v
    }) {
      var S, O;
      const w = new URLSearchParams({
        page: String(l),
        orderBy: x ?? "date",
        sort: v ?? "desc"
      });
      o && w.set("q", o);
      const P = await fetch(`${qs}?${w}`);
      if (!P.ok) throw new Error(`rscripts ${P.status}`);
      const c = await P.json();
      return {
        scripts: (Array.isArray(c == null ? void 0 : c.scripts) ? c.scripts : []).map(Ks),
        page: ((S = c == null ? void 0 : c.info) == null ? void 0 : S.currentPage) ?? l,
        totalPages: ((O = c == null ? void 0 : c.info) == null ? void 0 : O.maxPages) ?? 1
      }
    }
  },
  bn = l => lr("hub_fetch", {
    url: l
  }),
  Ys = async l => JSON.parse(await bn(l)), Xa = async l => {
    if (l.content) return l.content;
    if (!l.rawUrl) return "";
    try {
      const o = await fetch(l.rawUrl);
      if (o.ok) return await o.text()
    } catch {}
    try {
      return await bn(l.rawUrl)
    } catch {
      return ""
    }
  }, Ja = (l, o) => {
    if (l) return /^https?:\/\//i.test(l) ? l : o.replace(/\/+$/, "") + "/" + l.replace(/^\/+/, "")
  }, ka = "https://scriptblox.com", Xs = l => {
    var o;
    return {
      _id: `scriptblox:${l._id}`,
      title: l.title,
      views: l.views ?? 0,
      likes: 0,
      verified: l.verified,
      keySystem: l.key,
      patched: l.isPatched,
      game: l.game ? {
        name: l.game.name,
        imgurl: Ja(l.game.imageUrl, ka)
      } : void 0,
      image: Ja(l.image, ka),
      user: (o = l.owner) != null && o.username ? {
        username: l.owner.username
      } : void 0,
      content: l.script,
      rawUrl: !l.script && l.slug ? `${ka}/raw/${l.slug}` : void 0
    }
  }, Js = {
    id: "scriptblox",
    label: "ScriptBlox",
    logo: "/providers/scriptblox.svg",
    sorts: [],
    async fetchScripts({
      page: l,
      query: o
    }) {
      const x = o ? `/api/script/search?q=${encodeURIComponent(o)}&page=${l}` : `/api/script/fetch?page=${l}`,
        v = await fetch(`${ka}${x}`);
      if (!v.ok) throw new Error(`scriptblox ${v.status}`);
      const w = await v.json(),
        P = (w == null ? void 0 : w.result) ?? {};
      return {
        scripts: (Array.isArray(P.scripts) ? P.scripts : []).map(Xs),
        page: l,
        totalPages: P.totalPages ?? 1
      }
    }
  }, Qs = "https://robloxscripts.com/api/v1/scripts", Zs = l => {
    var o;
    return {
      _id: `robloxscripts:${l.id}`,
      title: l.title,
      views: l.views ?? 0,
      likes: l.likes ?? 0,
      keySystem: l.key,
      patched: l.isPatched,
      game: l.game ? {
        name: l.game.name
      } : void 0,
      image: l.image,
      user: (o = l.author) != null && o.username ? {
        username: l.author.username
      } : void 0,
      content: l.script || void 0,
      rawUrl: l.script ? void 0 : l.rawScriptUrl
    }
  }, eo = {
    id: "robloxscripts",
    label: "RobloxScripts",
    logo: "/providers/robloxscripts.png",
    sorts: [],
    async fetchScripts({
      page: l,
      query: o
    }) {
      var c, g;
      const x = new URLSearchParams({
        page: String(l)
      });
      o && x.set("q", o);
      const v = await fetch(`${Qs}?${x}`);
      if (!v.ok) throw new Error(`robloxscripts ${v.status}`);
      const w = await v.json();
      return {
        scripts: (Array.isArray(w == null ? void 0 : w.data) ? w.data : []).map(Zs),
        page: ((c = w == null ? void 0 : w.pagination) == null ? void 0 : c.page) ?? l,
        totalPages: ((g = w == null ? void 0 : w.pagination) == null ? void 0 : g.pages) ?? 1
      }
    }
  }, to = "https://api.haxhell.com/api/v1/scripts", ro = l => {
    var o, x, v, w, P, c, g, S, O, D, K;
    return {
      _id: `haxhell:${l.id}`,
      title: l.title,
      views: ((o = l.stats) == null ? void 0 : o.views) ?? 0,
      likes: ((x = l.stats) == null ? void 0 : x.likes) ?? 0,
      verified: (v = l.flags) == null ? void 0 : v.verified,
      keySystem: (w = l.flags) == null ? void 0 : w.keySystem,
      patched: (P = l.flags) == null ? void 0 : P.patched,
      game: (c = l.game) != null && c.name ? {
        name: l.game.name,
        imgurl: ((g = l.media) == null ? void 0 : g.thumbnailUrl) ?? l.game.thumbnailUrl ?? l.game.iconUrl ?? void 0
      } : void 0,
      image: ((S = l.media) == null ? void 0 : S.thumbnailUrl) ?? ((O = l.game) == null ? void 0 : O.thumbnailUrl) ?? void 0,
      user: (D = l.author) != null && D.username ? {
        username: l.author.username
      } : void 0,
      rawUrl: (K = l.links) == null ? void 0 : K.raw
    }
  }, ao = {
    id: "haxhell",
    label: "HaxHell",
    logo: "/providers/haxhell.ico",
    sorts: [],
    async fetchScripts({
      page: l,
      query: o
    }) {
      var P, c;
      const x = new URLSearchParams({
        page: String(l)
      });
      o && x.set("q", o);
      const v = await Ys(`${to}?${x}`);
      return {
        scripts: (Array.isArray(v == null ? void 0 : v.data) ? v.data : []).map(ro),
        page: ((P = v == null ? void 0 : v.pagination) == null ? void 0 : P.page) ?? l,
        totalPages: ((c = v == null ? void 0 : v.pagination) == null ? void 0 : c.totalPages) ?? 1
      }
    }
  }, za = [Gs, Js, eo, ao], Qa = l => za.find(o => o.id === l) ?? za[0];
var no = i('<img alt="" class="thumb-img absolute inset-0 size-full object-cover opacity-90 transition-[transform,opacity,filter] duration-[400ms] ease-out group-hover:scale-[1.04] group-hover:opacity-100 svelte-bbme0z"/>'),
  io = i('<div class="thumb-placeholder absolute inset-0 flex flex-col items-center justify-center gap-1.5 text-text-muted/60"><!> <span class="max-w-full truncate px-3 text-[10px] font-semibold text-text-muted/50"> </span></div>'),
  so = i('<span class="badge badge-key svelte-bbme0z"><!>Key</span>'),
  oo = i('<span class="badge badge-verified svelte-bbme0z"><!>Verified</span>'),
  lo = i('<div class="pointer-events-none absolute left-2 top-2 z-[2] flex flex-wrap gap-1.5"><!> <!></div>'),
  co = i('<span class="badge badge-patched pointer-events-none absolute right-2 bottom-2 z-[2] svelte-bbme0z">Patched</span>'),
  uo = i('<div class="absolute inset-0 z-[3] grid place-items-center rounded-[14px] bg-bg-base/70 backdrop-blur-sm"><!></div>'),
  po = i('<button aria-label="Execute" class="grid size-[22px] place-items-center rounded text-text-muted transition-colors hover:text-text-primary cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"><svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M5 4.5a1 1 0 0 1 1.5-.866l13 7.5a1 1 0 0 1 0 1.732l-13 7.5A1 1 0 0 1 5 19.5z"></path></svg></button>'),
  vo = i('<button aria-label="Open in editor" class="grid size-[22px] place-items-center rounded text-text-muted transition-colors hover:text-text-primary cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"><!></button>'),
  xo = i('<div role="button" tabindex="0"><div class="card-thumb relative aspect-[16/9] w-full shrink-0 overflow-hidden rounded-[14px] bg-bg-elevated svelte-bbme0z"><!> <!> <!> <!></div> <div class="flex min-w-0 flex-col gap-0.5 pt-2 pr-1"><span class="truncate text-[10.5px] font-semibold text-text-muted"> </span> <span class="truncate text-[13px] font-semibold text-text-primary leading-snug"> </span> <div class="mt-1 flex items-center gap-2"><span class="min-w-0 flex-1 flex items-center gap-2 text-[10.5px] text-text-muted"><span class="flex items-center gap-1"><!> <span class="tabular-nums"> </span></span> <span class="opacity-40">·</span> <span class="flex items-center gap-1"><!> <span class="tabular-nums"> </span></span></span> <div class="flex shrink-0 items-center gap-1"><!> <!></div></div></div></div>');

function mo(l, o) {
  Dt(o, !0);
  let x = Nr(o, "loading", 3, !1),
    v = C(!1);
  const w = A(() => {
      var G;
      return (((G = o.script.game) == null ? void 0 : G.imgurl) || o.script.image) && !e(v)
    }),
    P = A(() => {
      var G;
      return ((G = o.script.game) == null ? void 0 : G.name) ?? "Universal"
    });
  var c = xo();
  let g;
  var S = r(c),
    O = r(S);
  {
    var D = G => {
        var de = no();
        y(() => {
          var Se, Pe;
          return ut(de, "src", (Se = o.script.game) != null && Se.imgurl ? (Pe = o.script.game) == null ? void 0 : Pe.imgurl : o.script.image)
        }), yr("error", de, () => s(v, !0)), Za(de), n(G, de)
      },
      K = G => {
        var de = io(),
          Se = r(de);
        z(Se, {
          name: "file-code",
          size: 22,
          class: "opacity-40"
        });
        var Pe = a(Se, 2),
          Ue = r(Pe, !0);
        t(Pe), t(de), y(() => I(Ue, e(P))), n(G, de)
      };
    f(O, G => {
      e(w) ? G(D) : G(K, -1)
    })
  }
  var xe = a(O, 2);
  {
    var Q = G => {
      var de = lo(),
        Se = r(de);
      {
        var Pe = We => {
          var je = so(),
            N = r(je);
          z(N, {
            name: "key",
            size: 9
          }), Ae(), t(je), n(We, je)
        };
        f(Se, We => {
          o.script.keySystem && We(Pe)
        })
      }
      var Ue = a(Se, 2);
      {
        var He = We => {
          var je = oo(),
            N = r(je);
          z(N, {
            name: "check",
            size: 9
          }), Ae(), t(je), n(We, je)
        };
        f(Ue, We => {
          o.script.verified && We(He)
        })
      }
      t(de), n(G, de)
    };
    f(xe, G => {
      (o.script.verified || o.script.keySystem) && G(Q)
    })
  }
  var B = a(xe, 2);
  {
    var ye = G => {
      var de = co();
      n(G, de)
    };
    f(B, G => {
      o.script.patched && G(ye)
    })
  }
  var we = a(B, 2);
  {
    var ue = G => {
      var de = uo(),
        Se = r(de);
      Gt(Se, {
        size: 18
      }), t(de), n(G, de)
    };
    f(we, G => {
      x() && G(ue)
    })
  }
  t(S);
  var ke = a(S, 2),
    U = r(ke),
    W = r(U, !0);
  t(U);
  var le = a(U, 2),
    ee = r(le, !0);
  t(le);
  var fe = a(le, 2),
    ie = r(fe),
    $e = r(ie),
    Z = r($e);
  z(Z, {
    name: "eye",
    size: 10,
    class: "opacity-70"
  });
  var Y = a(Z, 2),
    re = r(Y, !0);
  t(Y), t($e);
  var J = a($e, 4),
    ve = r(J);
  z(ve, {
    name: "heart",
    size: 10,
    class: "opacity-70"
  });
  var ze = a(ve, 2),
    k = r(ze, !0);
  t(ze), t(J), t(ie);
  var L = a(ie, 2),
    ae = r(L);
  {
    var Me = G => {
      ct(G, {
        label: "Execute",
        children: (de, Se) => {
          var Pe = po();
          y(() => Pe.disabled = x()), d("click", Pe, Ue => {
            var He;
            Ue.stopPropagation(), (He = o.onrun) == null || He.call(o)
          }), n(de, Pe)
        },
        $$slots: {
          default: !0
        }
      })
    };
    f(ae, G => {
      o.onrun && G(Me)
    })
  }
  var Be = a(ae, 2);
  {
    var Oe = G => {
      ct(G, {
        label: "Open in editor",
        children: (de, Se) => {
          var Pe = vo(),
            Ue = r(Pe);
          z(Ue, {
            name: "folder-open",
            size: 11
          }), t(Pe), y(() => Pe.disabled = x()), d("click", Pe, He => {
            var We;
            He.stopPropagation(), (We = o.onopen) == null || We.call(o)
          }), n(de, Pe)
        },
        $$slots: {
          default: !0
        }
      })
    };
    f(Be, G => {
      o.onopen && G(Oe)
    })
  }
  t(L), t(fe), t(ke), t(c), y((G, de) => {
    g = me(c, 1, "card group relative flex min-w-0 flex-col text-left cursor-pointer transition-transform duration-[180ms] ease-out svelte-bbme0z", null, g, {
      "card-patched": o.script.patched
    }), I(W, e(P)), I(ee, o.script.title), I(re, G), I(k, de)
  }, [() => o.script.views.toLocaleString(), () => o.script.likes.toLocaleString()]), d("click", c, function(...G) {
    var de;
    (de = o.onclick) == null || de.apply(this, G)
  }), d("keydown", c, G => {
    var de;
    (G.key === "Enter" || G.key === " ") && ((de = o.onclick) == null || de.call(o))
  }), n(l, c), Rt()
}
Yt(["click", "keydown"]);
var fo = i('<span class="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-r-full bg-text-primary"></span>'),
  go = i('<img alt="" width="14" height="14" class="size-[14px] shrink-0 rounded-[3px] object-contain" draggable="false"/>'),
  bo = i('<button><!> <!> <span class="flex-1 truncate"> </span></button>'),
  _o = i('<button><span><!></span> <span class="flex-1 truncate"> </span></button>'),
  ho = i('<span class="size-[6px] rounded-full bg-bg-base"></span>'),
  yo = i('<button><span><!></span> <span class="flex-1 truncate"> </span> <!></button>'),
  wo = i('<div class="flex flex-col gap-1"><div class="flex h-6 items-center px-2 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-text-muted">Sort by</div> <!></div>'),
  ko = i('<button class="mt-auto flex h-7 items-center justify-center gap-1.5 rounded text-[12px] text-text-muted hover:text-text-primary transition-colors cursor-pointer"><!> Reset all</button>'),
  $o = i('<button class="grid size-5 place-items-center rounded text-text-muted hover:text-text-primary cursor-pointer" aria-label="Clear search"><!></button>'),
  zo = i('<span class="tabular-nums"><!></span>'),
  So = i('<button aria-label="Refresh" class="grid size-8 place-items-center rounded text-text-muted hover:text-text-primary cursor-pointer transition-colors"><!></button>'),
  Co = i('<div class="flex h-full flex-col items-center justify-center gap-3 text-text-muted"><!> <span class="text-[12px]"> </span></div>'),
  Po = i('<div class="flex h-full flex-col items-center justify-center gap-3 px-6 text-center text-text-muted"><div class="grid size-11 place-items-center rounded-[10px] bg-bg-elevated ring-1 ring-inset ring-line"><!></div> <p class="text-[13px] text-text-secondary"> </p> <!></div>'),
  Lo = i('<button class="text-[12px] text-text-muted hover:text-text-primary transition-colors cursor-pointer">Reset filters</button>'),
  Eo = i('<div class="flex h-full flex-col items-center justify-center gap-3 px-6 text-center text-text-muted"><div class="grid size-11 place-items-center rounded-[10px] bg-bg-elevated ring-1 ring-inset ring-line"><!></div> <p class="text-[13px] text-text-secondary"> </p> <!></div>'),
  Ao = i('<div class="flex items-center gap-2 text-[12px]"><!> Loading more…</div>'),
  Mo = i('<div class="mt-6 flex h-10 items-center justify-center text-text-muted"><!></div>'),
  Do = i('<div class="mt-6 py-4 text-center text-[11px] text-text-muted/60">End of results</div>'),
  Ro = i('<div class="grid gap-3" style="grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));"></div> <!>', 1),
  Io = i(`<div class="flex items-start justify-between gap-3"><div class="flex min-w-0 flex-col gap-1.5"><span class="text-[15px] font-semibold tracking-tight text-text-primary">Run or Edit</span> <span class="text-[12px] leading-relaxed text-text-muted">This script comes from a community source. Executing it runs untrusted code — review it first if you don't recognise the author.</span></div> <!></div> <div class="flex justify-end gap-2"><!> <!></div>`, 1),
  No = i('<div class="flex h-full w-full min-h-0 bg-bg-base text-text-primary" style="overflow:hidden;contain:paint;"><aside class="flex w-56 shrink-0 flex-col gap-5 overflow-y-auto border-r border-line px-3 py-4"><div class="flex flex-col gap-1"><div class="flex h-6 items-center px-2 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-text-muted">Sources</div> <!></div> <div class="flex flex-col gap-1"><div class="flex h-6 items-center px-2 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-text-muted">Filters</div> <!></div> <!> <!></aside> <section class="relative flex min-w-0 flex-1 flex-col"><header class="flex h-11 shrink-0 items-center gap-3 border-b border-line px-4"><div class="flex h-8 flex-1 items-center gap-2 rounded-md bg-bg-elevated px-2.5 ring-1 ring-inset ring-line/60 focus-within:ring-text-primary/25 transition-[box-shadow]"><!> <input class="min-w-0 flex-1 bg-transparent text-[12.5px] text-text-primary placeholder:text-text-muted focus:outline-none"/> <!></div> <div class="hidden shrink-0 items-center gap-2 text-[11px] text-text-muted sm:flex"><!></div> <!></header> <div class="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-4 pt-4 pb-20"><!></div></section> <!></div>');

function To(l, o) {
  Dt(o, !0);
  let x = C(Nt([])),
    v = C(1),
    w = C(!0),
    P = C(!1),
    c = C(null),
    g = C(null),
    S = C(null),
    O = C(Nt(za[0].id)),
    D = C(""),
    K = C("date"),
    xe = C("desc"),
    Q = C(1),
    B = C(Nt(new Set)),
    ye = null,
    we = 0,
    ue = null,
    ke = C(null);
  const U = A(() => Qa(e(O))),
    W = A(() => e(Q) < e(v)),
    le = async (m = !1) => {
      const b = ++we;
      m ? s(P, !0) : s(w, !0), s(c, null);
      try {
        const $ = await e(U).fetchScripts({
          page: e(Q),
          query: e(D) || void 0,
          sort: e(K),
          dir: e(xe)
        });
        if (b !== we) return;
        s(x, m ? [...e(x), ...$.scripts] : $.scripts, !0), s(v, Math.max(1, $.totalPages), !0)
      } catch {
        if (b !== we) return;
        m || s(c, "Failed to load scripts. Check your connection and try again.")
      } finally {
        b === we && (s(w, !1), s(P, !1))
      }
    }, ee = () => {
      s(Q, 1), s(x, [], !0), s(v, 1), le(!1)
    }, fe = async () => {
      e(w) || e(P) || e(c) || !e(W) || (s(Q, e(Q) + 1), await le(!0))
    }, ie = m => {
      var $;
      if (m === e(O)) return;
      s(O, m, !0);
      const b = Qa(m);
      b.sorts.some(X => X.value === e(K)) || s(K, (($ = b.sorts[0]) == null ? void 0 : $.value) ?? "date", !0), s(xe, "desc"), ee()
    }, $e = () => {
      ye && clearTimeout(ye), ye = setTimeout(ee, 400)
    }, Z = m => {
      e(K) === m ? s(xe, e(xe) === "desc" ? "asc" : "desc", !0) : (s(K, m, !0), s(xe, "desc")), ee()
    }, Y = m => {
      const b = new Set(e(B));
      b.has(m) ? b.delete(m) : b.add(m), s(B, b, !0)
    }, re = () => {
      s(B, new Set, !0), s(D, ""), ee()
    }, J = async m => {
      if (!e(g)) {
        s(g, m._id, !0), s(S, null);
        try {
          const b = await Xa(m);
          tr.goto("editor"), await Fe.create_file_with_content(m.title, b)
        } catch {
          tr.goto("editor"), await Fe.create_file(m.title)
        } finally {
          s(g, null)
        }
      }
    }, ve = async m => {
      if (!e(g)) {
        s(g, m._id, !0), s(S, null);
        try {
          const b = await Xa(m);
          await Xt.execute_in_targets(b)
        } catch {} finally {
          s(g, null)
        }
      }
    }, ze = [{
      key: "verified",
      label: "Verified only",
      predicate: m => !!m.verified
    }, {
      key: "no_key",
      label: "No key system",
      predicate: m => !m.keySystem
    }, {
      key: "not_patched",
      label: "Not patched",
      predicate: m => !m.patched
    }], k = A(() => e(x).filter(m => {
      for (const b of ze)
        if (e(B).has(b.key) && !b.predicate(m)) return !1;
      return !0
    })), L = A(() => e(B).size > 0 || !!e(D)), ae = A(() => e(k).length), Me = A(() => e(x).length);
  Tr(() => (le(!1), () => ue == null ? void 0 : ue.disconnect())), Cr(() => {
    if (ue == null || ue.disconnect(), !!e(ke)) return ue = new IntersectionObserver(m => {
      var b;
      (b = m[0]) != null && b.isIntersecting && fe()
    }, {
      rootMargin: "400px 0px"
    }), ue.observe(e(ke)), () => ue == null ? void 0 : ue.disconnect()
  });
  var Be = No(),
    Oe = r(Be),
    G = r(Oe),
    de = a(r(G), 2);
  Ze(de, 17, () => za, m => m.id, (m, b) => {
    var $ = bo(),
      X = r($);
    {
      var ne = V => {
        var De = fo();
        n(V, De)
      };
      f(X, V => {
        e(O) === e(b).id && V(ne)
      })
    }
    var T = a(X, 2);
    {
      var M = V => {
          var De = go();
          y(() => ut(De, "src", e(b).logo)), n(V, De)
        },
        q = V => {
          z(V, {
            name: "cloud",
            size: 14,
            class: "shrink-0"
          })
        };
      f(T, V => {
        e(b).logo ? V(M) : V(q, -1)
      })
    }
    var oe = a(T, 2),
      j = r(oe, !0);
    t(oe), t($), y(() => {
      me($, 1, `group relative flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left transition-colors cursor-pointer
                        ${e(O)===e(b).id?"text-text-primary":"text-text-muted hover:text-text-primary"}`), I(j, e(b).label)
    }), d("click", $, () => ie(e(b).id)), n(m, $)
  }), t(G);
  var Se = a(G, 2),
    Pe = a(r(Se), 2);
  Ze(Pe, 17, () => ze, m => m.key, (m, b) => {
    const $ = A(() => e(B).has(e(b).key));
    var X = _o(),
      ne = r(X),
      T = r(ne);
    {
      var M = j => {
        z(j, {
          name: "check",
          size: 10
        })
      };
      f(T, j => {
        e($) && j(M)
      })
    }
    t(ne);
    var q = a(ne, 2),
      oe = r(q, !0);
    t(q), t(X), y(() => {
      me(X, 1, `group flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left transition-colors cursor-pointer
                        ${e($)?"text-text-primary":"text-text-muted hover:text-text-primary"}`), me(ne, 1, `grid size-[14px] shrink-0 place-items-center rounded-[3px] transition-[background-color,box-shadow]
                            ${e($)?"bg-text-primary text-bg-base":"ring-1 ring-inset ring-line"}`), I(oe, e(b).label)
    }), d("click", X, () => Y(e(b).key)), n(m, X)
  }), t(Se);
  var Ue = a(Se, 2);
  {
    var He = m => {
      var b = wo(),
        $ = a(r(b), 2);
      Ze($, 17, () => e(U).sorts, X => X.value, (X, ne) => {
        const T = A(() => e(K) === e(ne).value);
        var M = yo(),
          q = r(M),
          oe = r(q);
        {
          var j = R => {
            var _e = ho();
            n(R, _e)
          };
          f(oe, R => {
            e(T) && R(j)
          })
        }
        t(q);
        var V = a(q, 2),
          De = r(V, !0);
        t(V);
        var tt = a(V, 2);
        {
          var Qe = R => {
            {
              let _e = A(() => e(xe) === "desc" ? "arrow-down" : "arrow-up");
              z(R, {
                get name() {
                  return e(_e)
                },
                size: 12,
                class: "text-text-muted"
              })
            }
          };
          f(tt, R => {
            e(T) && R(Qe)
          })
        }
        t(M), y(() => {
          me(M, 1, `group flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left transition-colors cursor-pointer
                            ${e(T)?"text-text-primary":"text-text-muted hover:text-text-primary"}`), me(q, 1, `grid size-[14px] shrink-0 place-items-center rounded-full transition-[background-color,box-shadow]
                                ${e(T)?"bg-text-primary":"ring-1 ring-inset ring-line"}`), I(De, e(ne).label)
        }), d("click", M, () => Z(e(ne).value)), n(X, M)
      }), t(b), n(m, b)
    };
    f(Ue, m => {
      e(U).sorts.length && m(He)
    })
  }
  var We = a(Ue, 2);
  {
    var je = m => {
      var b = ko(),
        $ = r(b);
      z($, {
        name: "refresh",
        size: 11
      }), Ae(), t(b), d("click", b, re), n(m, b)
    };
    f(We, m => {
      e(L) && m(je)
    })
  }
  t(Oe);
  var N = a(Oe, 2),
    Ye = r(N),
    rt = r(Ye),
    pt = r(rt);
  z(pt, {
    name: "search",
    size: 13,
    class: "shrink-0 text-text-muted"
  });
  var qe = a(pt, 2);
  ur(qe);
  var at = a(qe, 2);
  {
    var pe = m => {
      var b = $o(),
        $ = r(b);
      z($, {
        name: "x",
        size: 12
      }), t(b), d("click", b, () => {
        s(D, ""), $e()
      }), n(m, b)
    };
    f(at, m => {
      e(D) && m(pe)
    })
  }
  t(rt);
  var p = a(rt, 2),
    u = r(p);
  {
    var ge = m => {
      var b = zo(),
        $ = r(b);
      {
        var X = T => {
            var M = dr();
            y(() => I(M, `${e(ae)??""} of ${e(Me)??""}`)), n(T, M)
          },
          ne = T => {
            var M = dr();
            y(() => I(M, `${e(Me)??""} results`)), n(T, M)
          };
        f($, T => {
          e(L) && e(ae) !== e(Me) ? T(X) : T(ne, -1)
        })
      }
      t(b), n(m, b)
    };
    f(u, m => {
      !e(w) && !e(c) && m(ge)
    })
  }
  t(p);
  var be = a(p, 2);
  ct(be, {
    label: "Refresh",
    children: (m, b) => {
      var $ = So(),
        X = r($);
      z(X, {
        name: "refresh",
        size: 13
      }), t($), d("click", $, le), n(m, $)
    },
    $$slots: {
      default: !0
    }
  }), t(Ye);
  var Le = a(Ye, 2),
    H = r(Le);
  {
    var Ee = m => {
        var b = Co(),
          $ = r(b);
        Gt($, {
          size: 18
        });
        var X = a($, 2),
          ne = r(X);
        t(X), t(b), y(() => I(ne, `Loading ${e(U).label??""}…`)), n(m, b)
      },
      Te = m => {
        var b = Po(),
          $ = r(b),
          X = r($);
        z(X, {
          name: "alert-circle",
          size: 20,
          class: "text-danger"
        }), t($);
        var ne = a($, 2),
          T = r(ne, !0);
        t(ne);
        var M = a(ne, 2);
        Ca(M, {
          onclick: ee,
          children: (q, oe) => {
            Ae();
            var j = dr("Try again");
            n(q, j)
          },
          $$slots: {
            default: !0
          }
        }), t(b), y(() => I(T, e(c))), n(m, b)
      },
      et = m => {
        var b = Eo(),
          $ = r(b),
          X = r($);
        z(X, {
          name: "inbox",
          size: 20
        }), t($);
        var ne = a($, 2),
          T = r(ne, !0);
        t(ne);
        var M = a(ne, 2);
        {
          var q = oe => {
            var j = Lo();
            d("click", j, re), n(oe, j)
          };
          f(M, oe => {
            e(L) && oe(q)
          })
        }
        t(b), y(() => I(T, e(L) ? "Nothing matches these filters" : "No scripts found")), n(m, b)
      },
      E = m => {
        var b = Ro(),
          $ = Ge(b);
        Ze($, 21, () => e(k), M => M._id, (M, q) => {
          {
            let oe = A(() => e(g) === e(q)._id);
            mo(M, {
              get script() {
                return e(q)
              },
              get loading() {
                return e(oe)
              },
              onclick: () => s(S, e(q), !0),
              onrun: () => ve(e(q)),
              onopen: () => J(e(q))
            })
          }
        }), t($);
        var X = a($, 2);
        {
          var ne = M => {
              var q = Mo(),
                oe = r(q);
              {
                var j = V => {
                  var De = Ao(),
                    tt = r(De);
                  Gt(tt, {
                    size: 13
                  }), Ae(), t(De), n(V, De)
                };
                f(oe, V => {
                  e(P) && V(j)
                })
              }
              t(q), ta(q, V => s(ke, V), () => e(ke)), n(M, q)
            },
            T = M => {
              var q = Do();
              n(M, q)
            };
          f(X, M => {
            e(W) ? M(ne) : e(x).length > 0 && M(T, 1)
          })
        }
        Ir(1, $, () => ra, () => ({
          y: 8
        })), n(m, b)
      };
    f(H, m => {
      e(w) ? m(Ee) : e(c) ? m(Te, 1) : e(k).length === 0 ? m(et, 2) : m(E, -1)
    })
  }
  t(Le), t(N);
  var h = a(N, 2);
  {
    let m = A(() => !!e(S));
    Sa(h, {
      get open() {
        return e(m)
      },
      onclose: () => s(S, null),
      class: "w-full max-w-96 p-5 flex flex-col gap-4",
      children: (b, $) => {
        var X = Io(),
          ne = Ge(X),
          T = a(r(ne), 2);
        Xn(T, {
          name: "x",
          onclick: () => s(S, null),
          title: "Close"
        }), t(ne);
        var M = a(ne, 2),
          q = r(M);
        Ca(q, {
          onclick: () => J(e(S)),
          children: (j, V) => {
            Ae();
            var De = dr("Open in editor");
            n(j, De)
          },
          $$slots: {
            default: !0
          }
        });
        var oe = a(q, 2);
        Ca(oe, {
          variant: "primary",
          onclick: () => ve(e(S)),
          children: (j, V) => {
            Ae();
            var De = dr("Execute now");
            n(j, De)
          },
          $$slots: {
            default: !0
          }
        }), t(M), n(b, X)
      },
      $$slots: {
        default: !0
      }
    })
  }
  t(Be), y(() => ut(qe, "placeholder", `Search ${e(U).label??""}…`)), d("input", qe, $e), Or(qe, () => e(D), m => s(D, m)), n(l, Be), Rt()
}
Yt(["click", "input"]);
var jo = i('<div class="flex flex-col gap-4"><div class="flex items-start gap-3"><div class="grid size-9 shrink-0 place-items-center rounded-md bg-bg-active text-text-primary ring-1 ring-inset ring-line"><!></div> <div class="flex flex-col gap-1 min-w-0"><span class="text-[14px] font-semibold tracking-tight text-text-primary">Roblox is open</span> <span class="text-[13px] leading-relaxed text-text-muted">Execute your primary script <span class="font-semibold text-text-secondary"> </span>?</span></div></div> <div class="flex justify-end gap-2"><button class="h-8 rounded-md px-3 text-[13px] text-text-muted hover:text-text-primary transition-colors cursor-pointer">No</button> <button class="h-8 rounded-md bg-text-primary px-3.5 text-[13px] font-medium text-bg-base hover:brightness-95 transition-[filter] cursor-pointer">Execute</button></div></div>');

function Fo(l, o) {
  Dt(o, !1);
  const x = () => $t(P, "$prompt", v),
    [v, w] = Br(),
    P = ya.prompt;
  ja();
  {
    let c = va(() => !!x());
    Sa(l, {
      get open() {
        return e(c)
      },
      onclose: () => ya.dismiss(),
      class: "w-[360px] max-w-[88%] p-5",
      children: (g, S) => {
        var O = jo(),
          D = r(O),
          K = r(D),
          xe = r(K);
        z(xe, {
          name: "play",
          size: 16
        }), t(K);
        var Q = a(K, 2),
          B = a(r(Q), 2),
          ye = a(r(B)),
          we = r(ye, !0);
        t(ye), Ae(), t(B), t(Q), t(D);
        var ue = a(D, 2),
          ke = r(ue),
          U = a(ke, 2);
        t(ue), t(O), y(() => {
          var W;
          return I(we, (W = x()) == null ? void 0 : W.name)
        }), d("click", ke, () => ya.dismiss()), d("click", U, () => ya.run_primary()), n(g, O)
      },
      $$slots: {
        default: !0
      }
    })
  }
  Rt(), w()
}
Yt(["click"]);
const ga = (l, o = da, x = da, v) => {
  let w = va(() => en(v == null ? void 0 : v(), ""));
  var P = wr(),
    c = Ge(P);
  {
    var g = O => {
        z(O, {
          name: "roblox",
          get size() {
            return x()
          },
          get class() {
            return `shrink-0 ${e(w)??""}`
          }
        })
      },
      S = O => {
        var D = Oo();
        y(() => {
          ut(D, "src", `/launchers/${o()??""}.png`), sr(D, `width:${x()??""}px;height:${x()??""}px`), me(D, 1, `shrink-0 rounded object-contain ${e(w)??""}`)
        }), n(O, D)
      };
    f(c, O => {
      o() === "roblox" ? O(g) : O(S, -1)
    })
  }
  n(l, P)
};
var Oo = i('<img alt=""/>'),
  Uo = i('<span class="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-r-full bg-text-primary"></span>'),
  Bo = i('<span class="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-r-full bg-text-primary"></span>'),
  Wo = i('<button><!> <!> <span class="flex-1 truncate"> </span> <span class="text-[11px] tabular-nums text-text-muted"> </span></button>'),
  Vo = i('<span class="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-r-full bg-text-primary"></span>'),
  Ho = i('<button><!> <span class="flex-1 truncate"> </span> <span class="text-[11px] tabular-nums text-text-muted"> </span></button>'),
  qo = i('<div class="mt-5 flex flex-col gap-1"><div class="flex h-6 items-center px-2 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-text-muted">Filter by launcher</div> <button><!> <!> <span class="flex-1 truncate">All launchers</span> <span class="text-[11px] tabular-nums text-text-muted"> </span></button> <!></div> <div class="mt-5 flex flex-col gap-1"><div class="flex h-6 items-center px-2 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-text-muted">constraintt.ez</div> <!></div> <div class="mt-5 flex flex-col gap-1"><div class="flex h-6 items-center px-2 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-text-muted">Show only</div> <button><span><!></span> <span class="flex-1 truncate">Running</span></button> <button><span><!></span> <span class="flex-1 truncate">Latest</span></button></div>', 1),
  Ko = i('<span class="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-r-full bg-text-primary"></span>'),
  Go = i('<button><!> <span class="flex-1 truncate"> </span> <span class="text-[11px] tabular-nums text-text-muted"> </span></button>'),
  Yo = i('<div class="mt-5 flex flex-col gap-1"><div class="flex h-6 items-center px-2 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-text-muted">Status</div> <!></div>'),
  Xo = i('<button class="flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left text-text-muted hover:text-text-primary cursor-pointer transition-colors"><!> <span>Reset filters</span></button>'),
  Jo = i('<button class="grid size-5 place-items-center rounded text-text-muted hover:text-text-primary cursor-pointer" aria-label="Clear search"><!></button>'),
  Qo = i("<button><!> </button>"),
  Zo = i('<div class="flex gap-0.5"></div>'),
  el = i('<button class="flex h-9 shrink-0 items-center gap-1.5 rounded-md px-3.5 text-[13px] font-medium text-text-muted hover:text-text-primary cursor-pointer transition-colors"><!> Cancel</button>'),
  tl = i('<button class="flex h-9 shrink-0 items-center gap-1.5 rounded-md bg-text-primary px-4 text-[13px] font-medium text-bg-base hover:brightness-95 cursor-pointer transition-[filter] disabled:pointer-events-none disabled:opacity-40"><!> Download</button>'),
  rl = i("<button>Recommended</button>"),
  al = i('<span class="text-text-muted/40">·</span> <button>Latest</button>', 1),
  nl = i('<span class="text-text-muted/40">·</span> <button>Beta</button>', 1),
  il = i('<div class="flex items-center gap-1 text-[11.5px] text-text-muted"><span class="mr-1">Presets:</span> <!> <!> <!></div>'),
  sl = i("<!> Extracting…", 1),
  ol = i('<span class="tabular-nums"> </span>'),
  ll = i('<span class="truncate opacity-60"> </span>'),
  cl = i('<div class="flex flex-col gap-1.5"><div class="h-1 w-full overflow-hidden rounded-full bg-bg-active"><div class="h-full rounded-full bg-text-primary transition-[width] duration-150"></div></div> <div class="flex items-center justify-between gap-2 text-[11px] text-text-muted"><span class="flex min-w-0 items-center gap-1.5"><!> <!></span> <span class="shrink-0 tabular-nums"> </span></div></div>'),
  dl = i('<div class="flex items-center gap-2 text-[12px] text-danger"><!> </div>'),
  ul = i('<div class="flex flex-col items-center gap-3 rounded-[10px] bg-bg-elevated py-14 text-center ring-1 ring-inset ring-line/60"><!> <p class="text-[13px] text-text-secondary">No Roblox versions installed yet</p> <p class="text-[11.5px] text-text-muted">Install a version above to get started.</p></div>'),
  pl = i('<div class="flex flex-col items-center gap-2 rounded-[10px] bg-bg-elevated py-10 text-center ring-1 ring-inset ring-line/60"><p class="text-[12.5px] text-text-muted">No versions match these filters.</p> <button class="text-[12px] text-text-muted hover:text-text-primary transition-colors cursor-pointer">Reset filters</button></div>'),
  vl = i('<div class="mb-1.5 flex items-center gap-1.5 px-1"><!> <span class="text-[10.5px] font-semibold uppercase tracking-[0.06em] text-text-muted"> </span> <span class="text-[10.5px] text-text-muted/60 tabular-nums"> </span></div>'),
  xl = i('<span class="flex shrink-0 items-center gap-1 rounded bg-success-soft px-1.5 py-px text-[10px] font-medium text-success ring-1 ring-inset ring-success/25"><!> Patched</span>'),
  ml = i('<span class="flex shrink-0 items-center gap-1 rounded bg-bg-active px-1.5 py-px text-[10px] font-medium text-text-secondary ring-1 ring-inset ring-line"><span class="size-1 rounded-full bg-success"></span> Running</span>'),
  fl = i('<span class="shrink-0 rounded bg-bg-active px-1.5 py-px text-[10px] font-medium text-text-secondary ring-1 ring-inset ring-line">Latest</span>'),
  gl = i('<span class="flex shrink-0 items-center gap-1 rounded bg-warning-soft px-1.5 py-px text-[10px] font-medium text-warning ring-1 ring-inset ring-warning/25"><!> Unsupported</span>'),
  bl = i("<!> Downloading", 1),
  _l = i("<!> Download compatible", 1),
  hl = i('<button class="flex h-8 items-center gap-1.5 rounded-md bg-text-primary px-3 text-[12px] font-medium text-bg-base hover:brightness-95 cursor-pointer transition-[filter] disabled:pointer-events-none disabled:opacity-40"><!></button>'),
  yl = i('<span class="flex h-8 items-center gap-1.5 rounded-md bg-bg-base px-2.5 text-[12px] font-medium text-text-muted ring-1 ring-inset ring-line"><!> Patching</span>'),
  wl = i('<button class="flex h-8 items-center gap-1.5 rounded-md bg-text-primary px-3 text-[12px] font-medium text-bg-base hover:brightness-95 cursor-pointer transition-[filter] disabled:pointer-events-none disabled:opacity-40"><!> Patch</button>'),
  kl = i('<span class="flex h-8 items-center gap-1.5 rounded-md bg-bg-base px-2.5 text-[12px] font-medium text-text-muted ring-1 ring-inset ring-line"><!> Launching</span>'),
  $l = i("<button><!> Launch</button>"),
  zl = i('<button aria-label="Unpatch version" class="grid size-8 shrink-0 place-items-center rounded-md text-text-muted opacity-0 hover:text-text-primary cursor-pointer transition-[opacity,color] group-hover:opacity-100"><!></button>'),
  Sl = i('<button aria-label="Uninstall version" class="grid size-8 shrink-0 place-items-center rounded-md text-text-muted opacity-0 hover:text-danger cursor-pointer transition-[opacity,color] group-hover:opacity-100"><!></button>'),
  Cl = i('<li><div class="grid size-9 shrink-0 place-items-center rounded-md bg-bg-base ring-1 ring-inset ring-line"><!></div> <div class="min-w-0 flex-1"><div class="flex items-center gap-2"><span class="truncate text-[13px] font-semibold text-text-primary"> </span> <!> <!> <!></div> <button title="Open install folder" class="block max-w-full truncate text-left font-mono text-[11px] text-text-muted hover:text-text-secondary cursor-pointer transition-colors"> <!></button></div> <div class="flex shrink-0 items-center gap-1.5"><!> <!> <!> <!></div></li>'),
  Pl = i('<div><!> <ul class="flex flex-col gap-1.5"></ul></div>'),
  Ll = i('<div class="flex flex-col gap-4"></div>'),
  El = i('<header class="flex h-11 shrink-0 items-center gap-3 border-b border-line px-4"><div class="flex h-8 flex-1 items-center gap-2 rounded-md bg-bg-elevated px-2.5 ring-1 ring-inset ring-line/60 focus-within:ring-text-primary/25 transition-[box-shadow]"><!> <input placeholder="Search version hash…" class="min-w-0 flex-1 bg-transparent text-[12.5px] text-text-primary placeholder:text-text-muted focus:outline-none"/> <!></div> <div class="hidden shrink-0 items-center gap-2 text-[11px] text-text-muted sm:flex"><span class="tabular-nums"><!></span></div></header> <div class="flex-1 min-h-0 overflow-y-auto"><div class="mx-auto flex max-w-3xl flex-col gap-8 px-8 pt-8 pb-16"><section class="flex flex-col gap-3"><div class="flex items-baseline justify-between gap-3"><h2 class="text-[13px] font-semibold text-text-primary">Install a Roblox version</h2> <!></div> <div class="flex items-center gap-2"><input placeholder="version-…" class="h-9 min-w-0 flex-1 rounded-md bg-bg-elevated px-3 font-mono text-[13px] text-text-primary placeholder:text-text-muted ring-1 ring-inset ring-line/60 focus:outline-none focus:ring-2 focus:ring-input-focus disabled:opacity-50 transition-[box-shadow]"/> <!></div> <!> <!> <!></section> <section><div class="mb-3 flex items-center gap-2"><!> <h2 class="text-[11px] font-semibold uppercase tracking-[0.08em] text-text-muted">Installed versions</h2></div> <!></section></div></div>', 1),
  Al = i('<button class="text-[12px] text-text-muted hover:text-text-primary transition-colors cursor-pointer">Show all</button>'),
  Ml = i('<div class="flex flex-col items-center gap-3 py-14 text-center"><!> <p class="text-[13px] text-text-secondary">No launcher clients here</p> <!></div>'),
  Dl = i('Latest release <span class="font-mono"> </span>', 1),
  Rl = i('<button class="grid size-8 place-items-center rounded-md text-text-muted hover:text-text-primary cursor-pointer transition-colors"><!></button>'),
  Il = i('<button class="grid size-8 place-items-center rounded-md text-text-muted hover:text-danger cursor-pointer transition-colors"><!></button>'),
  Nl = i('<span class="ml-2 text-[11.5px] text-text-muted">Installed</span>'),
  Tl = i('<button class="ml-1 flex h-8 items-center gap-1.5 rounded-md bg-text-primary px-3 text-[12px] font-medium text-bg-base hover:brightness-95 cursor-pointer transition-[filter] disabled:opacity-50 disabled:pointer-events-none"><!> Install</button>'),
  jl = i('<li><!> <div class="min-w-0 flex-1"><div class="truncate text-[13.5px] font-semibold text-text-primary"> </div> <div class="mt-0.5 truncate text-[11.5px] text-text-muted"><!></div></div> <div class="flex shrink-0 items-center gap-1"><!> <!></div></li>'),
  Fl = i('<ul class="flex flex-col"></ul>'),
  Ol = i('<header class="flex h-11 shrink-0 items-center gap-3 border-b border-line px-4"><span class="text-[13px] font-semibold text-text-primary">Roblox launchers</span> <span class="text-[12px] text-text-muted">·</span> <span class="text-[12px] text-text-muted"> </span> <div class="flex-1"></div></header> <div class="flex-1 min-h-0 overflow-y-auto"><div class="mx-auto flex max-w-3xl flex-col gap-6 px-8 pt-8 pb-16"><p class="text-[12.5px] leading-relaxed text-text-muted">Launcher clients wrap Roblox with extra features. Install one, then pick it when downloading a version.</p> <!></div></div>', 1),
  Ul = i('<div class="flex flex-col gap-4"><div class="flex flex-col gap-1.5"><span class="text-[14px] font-semibold tracking-tight text-text-primary"> </span> <span class="text-[12.5px] leading-relaxed text-text-muted">This removes <span class="font-semibold text-text-secondary"> </span> and every Roblox version installed through it. <span class="font-semibold text-text-secondary">This action cannot be undone.</span></span></div> <div class="flex justify-end gap-2"><button class="h-8 rounded-md px-3 text-[13px] text-text-muted hover:text-text-primary transition-colors cursor-pointer">Cancel</button> <button class="h-8 rounded-md bg-danger px-3.5 text-[13px] font-medium text-white hover:brightness-110 transition-[filter] cursor-pointer">Uninstall</button></div></div>'),
  Bl = i('<div class="flex h-full w-full min-h-0 bg-bg-base text-text-primary" style="overflow:hidden;contain:paint;"><aside class="flex w-56 shrink-0 flex-col overflow-y-auto border-r border-line px-3 py-4"><div class="flex gap-0.5 rounded-[8px] bg-bg-elevated p-0.5 ring-1 ring-inset ring-line/60"><button><!> Versions</button> <button><!> Launchers</button></div> <!> <div class="flex-1"></div> <div class="flex flex-col gap-1"><div class="flex h-6 items-center px-2 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-text-muted">Actions</div> <!> <button class="flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left text-text-muted hover:text-text-primary cursor-pointer transition-colors"><!> <span>Refresh</span></button> <button class="flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left text-text-muted hover:text-danger cursor-pointer transition-colors"><!> <span>Kill Roblox</span></button></div></aside> <section class="flex min-w-0 flex-1 flex-col"><!></section> <!></div>');

function Wl(l, o) {
  Dt(o, !0);
  const x = () => $t(ke, "$supported", B),
    v = () => $t(Z, "$download", B),
    w = () => $t(fe, "$clients", B),
    P = () => $t(le, "$launchers", B),
    c = () => $t(we, "$installed", B),
    g = () => $t(W, "$running", B),
    S = () => $t(ue, "$latest", B),
    O = () => $t(ee, "$channels", B),
    D = () => $t($e, "$launching", B),
    K = () => $t(Be, "$patch_state", B),
    xe = () => $t(U, "$supported_file", B),
    Q = () => $t(ie, "$installing", B),
    [B, ye] = Br(),
    we = Je.installed,
    ue = Je.latest,
    ke = Je.supported,
    U = Je.supported_file,
    W = Je.running,
    le = Je.launchers,
    ee = Je.channels,
    fe = Je.clients,
    ie = Je.installing,
    $e = Je.launching,
    Z = Je.download;
  let Y = C("versions"),
    re = C(""),
    J = C(!1),
    ve = C("roblox"),
    ze = C(""),
    k = C("all"),
    L = C(!1),
    ae = C(!1),
    Me = C("all");
  const Be = La.state;
  let Oe = C("all"),
    G = C(null);
  Tr(() => {
    Je.init_events(), Je.refresh(), Je.load_latest(), Je.load_supported(), Je.load_running(), Je.load_launchers(), Je.load_channels(), Je.load_clients()
  }), Ur(() => Je.dispose());

  function de(R) {
    R && s(re, R, !0)
  }

  function Se(R) {
    return !!R && e(re).trim() === R
  }
  async function Pe() {
    const R = e(re).trim();
    if (!R) return;
    s(J, !0);
    const _e = await Je.validate(R);
    if (s(J, !1), !_e) {
      Je.download.update(te => ({
        ...te,
        error: "Unknown or invalid version"
      })), gt.error("Invalid version", {
        message: "That version hash couldn't be found on the Roblox CDN."
      });
      return
    }
    gt.info("Starting download", {
      message: R
    }), Je.start_download(R, e(ve))
  }
  async function Ue(R) {
    const _e = x();
    !_e || !Pa(_e) || v().active || (gt.info("Downloading the latest compatible Roblox", {
      message: _e
    }), await Je.start_download(_e, R))
  }

  function He(R) {
    var _e, te;
    return ((_e = w().find(he => he.id === R)) == null ? void 0 : _e.label) ?? ((te = P().find(he => he.id === R)) == null ? void 0 : te.label) ?? R
  }

  function We() {
    s(k, "all"), s(L, !1), s(ae, !1), s(Me, "all"), s(ze, "")
  }
  const je = A(() => c().filter(R => !(e(k) !== "all" && R.launcher !== e(k) || e(L) && R.id !== g() || e(ae) && R.id !== S() || e(Me) === "patched" && !R.patched || e(Me) === "unpatched" && R.patched || e(ze).trim() && !R.id.toLowerCase().includes(e(ze).toLowerCase())))),
    N = A(() => c().filter(R => R.patched).length),
    Ye = A(() => {
      const R = new Map;
      for (const _e of e(je)) {
        const te = R.get(_e.launcher) ?? [];
        te.push(_e), R.set(_e.launcher, te)
      }
      for (const _e of R.values()) _e.sort((te, he) => te.id.localeCompare(he.id));
      return [...R.entries()].sort((_e, te) => _e[0].localeCompare(te[0]))
    }),
    rt = A(() => [...new Set(c().map(R => R.launcher))]),
    pt = A(() => {
      const R = new Map;
      for (const _e of c()) R.set(_e.launcher, (R.get(_e.launcher) ?? 0) + 1);
      return R
    }),
    qe = A(() => v().total > 0 ? Math.min(100, Math.round(v().downloaded / v().total * 100)) : 0),
    at = R => (R / 1048576).toFixed(1),
    pe = A(() => e(k) !== "all" || e(L) || e(ae) || e(Me) !== "all" || !!e(ze).trim()),
    p = A(() => w().filter(R => R.installed).length),
    u = A(() => w().filter(R => !R.installed && R.installable).length),
    ge = A(() => w().filter(R => !(e(Oe) === "installed" && !R.installed || e(Oe) === "installable" && (R.installed || !R.installable))));
  var be = Bl(),
    Le = r(be),
    H = r(Le),
    Ee = r(H),
    Te = r(Ee);
  z(Te, {
    name: "box",
    size: 12
  }), Ae(), t(Ee);
  var et = a(Ee, 2),
    E = r(et);
  z(E, {
    name: "app-window",
    size: 12
  }), Ae(), t(et), t(H);
  var h = a(H, 2);
  {
    var m = R => {
        var _e = qo(),
          te = Ge(_e),
          he = a(r(te), 2),
          Re = r(he);
        {
          var lt = yt => {
            var Bt = Uo();
            n(yt, Bt)
          };
          f(Re, yt => {
            e(k) === "all" && yt(lt)
          })
        }
        var dt = a(Re, 2);
        z(dt, {
          name: "box",
          size: 12,
          class: "shrink-0"
        });
        var Tt = a(dt, 4),
          Ft = r(Tt, !0);
        t(Tt), t(he);
        var jt = a(he, 2);
        Ze(jt, 16, () => e(rt), yt => yt, (yt, Bt) => {
          const fr = A(() => e(k) === Bt);
          var Wt = Wo(),
            nr = r(Wt);
          {
            var gr = nt => {
              var vt = Bo();
              n(nt, vt)
            };
            f(nr, nt => {
              e(fr) && nt(gr)
            })
          }
          var pr = a(nr, 2);
          ga(pr, () => Bt, () => 14);
          var br = a(pr, 2),
            vr = r(br, !0);
          t(br);
          var kr = a(br, 2),
            xr = r(kr, !0);
          t(kr), t(Wt), y((nt, vt) => {
            me(Wt, 1, `group relative flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left transition-colors cursor-pointer
                            ${e(fr)?"text-text-primary":"text-text-muted hover:text-text-primary"}`), I(vr, nt), I(xr, vt)
          }, [() => He(Bt), () => e(pt).get(Bt) ?? 0]), d("click", Wt, () => s(k, Bt, !0)), n(yt, Wt)
        }), t(te);
        var _t = a(te, 2),
          bt = a(r(_t), 2);
        Ze(bt, 1, () => [{
          id: "all",
          label: "All versions",
          count: c().length
        }, {
          id: "patched",
          label: "Patched",
          count: e(N)
        }, {
          id: "unpatched",
          label: "Not patched",
          count: c().length - e(N)
        }], yt => yt.id, (yt, Bt) => {
          const fr = A(() => e(Me) === e(Bt).id);
          var Wt = Ho(),
            nr = r(Wt);
          {
            var gr = xr => {
              var nt = Vo();
              n(xr, nt)
            };
            f(nr, xr => {
              e(fr) && xr(gr)
            })
          }
          var pr = a(nr, 2),
            br = r(pr, !0);
          t(pr);
          var vr = a(pr, 2),
            kr = r(vr, !0);
          t(vr), t(Wt), y(() => {
            me(Wt, 1, `relative flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left transition-colors cursor-pointer
                            ${e(fr)?"text-text-primary":"text-text-muted hover:text-text-primary"}`), I(br, e(Bt).label), I(kr, e(Bt).count)
          }), d("click", Wt, () => s(Me, e(Bt).id, !0)), n(yt, Wt)
        }), t(_t);
        var It = a(_t, 2),
          Ke = a(r(It), 2),
          Mt = r(Ke),
          Ot = r(Mt);
        {
          var Ut = yt => {
            z(yt, {
              name: "check",
              size: 10
            })
          };
          f(Ot, yt => {
            e(L) && yt(Ut)
          })
        }
        t(Mt), Ae(2), t(Ke);
        var ar = a(Ke, 2),
          zt = r(ar),
          Jt = r(zt);
        {
          var or = yt => {
            z(yt, {
              name: "check",
              size: 10
            })
          };
          f(Jt, yt => {
            e(ae) && yt(or)
          })
        }
        t(zt), Ae(2), t(ar), t(It), y(() => {
          me(he, 1, `group relative flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left transition-colors cursor-pointer
                        ${e(k)==="all"?"text-text-primary":"text-text-muted hover:text-text-primary"}`), I(Ft, c().length), me(Ke, 1, `flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left transition-colors cursor-pointer
                        ${e(L)?"text-text-primary":"text-text-muted hover:text-text-primary"}`), me(Mt, 1, `grid size-[14px] shrink-0 place-items-center rounded-[3px] transition-[background-color]
                        ${e(L)?"bg-text-primary text-bg-base":"ring-1 ring-inset ring-line"}`), me(ar, 1, `flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left transition-colors cursor-pointer
                        ${e(ae)?"text-text-primary":"text-text-muted hover:text-text-primary"}`), me(zt, 1, `grid size-[14px] shrink-0 place-items-center rounded-[3px] transition-[background-color]
                        ${e(ae)?"bg-text-primary text-bg-base":"ring-1 ring-inset ring-line"}`)
        }), d("click", he, () => s(k, "all")), d("click", Ke, () => s(L, !e(L))), d("click", ar, () => s(ae, !e(ae))), n(R, _e)
      },
      b = R => {
        var _e = Yo(),
          te = a(r(_e), 2);
        Ze(te, 1, () => [{
          id: "all",
          label: "All",
          count: w().length
        }, {
          id: "installed",
          label: "Installed",
          count: e(p)
        }, {
          id: "installable",
          label: "Installable",
          count: e(u)
        }], he => he.id, (he, Re) => {
          const lt = A(() => e(Oe) === e(Re).id);
          var dt = Go(),
            Tt = r(dt);
          {
            var Ft = Ke => {
              var Mt = Ko();
              n(Ke, Mt)
            };
            f(Tt, Ke => {
              e(lt) && Ke(Ft)
            })
          }
          var jt = a(Tt, 2),
            _t = r(jt, !0);
          t(jt);
          var bt = a(jt, 2),
            It = r(bt, !0);
          t(bt), t(dt), y(() => {
            me(dt, 1, `group relative flex h-8 items-center gap-2.5 rounded px-2 text-[13px] text-left transition-colors cursor-pointer
                            ${e(lt)?"text-text-primary":"text-text-muted hover:text-text-primary"}`), I(_t, e(Re).label), I(It, e(Re).count)
          }), d("click", dt, () => s(Oe, e(Re).id, !0)), n(he, dt)
        }), t(_e), n(R, _e)
      };
    f(h, R => {
      e(Y) === "versions" ? R(m) : R(b, -1)
    })
  }
  var $ = a(h, 4),
    X = a(r($), 2);
  {
    var ne = R => {
      var _e = Xo(),
        te = r(_e);
      z(te, {
        name: "refresh",
        size: 13,
        class: "shrink-0"
      }), Ae(2), t(_e), d("click", _e, We), n(R, _e)
    };
    f(X, R => {
      e(Y) === "versions" && e(pe) && R(ne)
    })
  }
  var T = a(X, 2),
    M = r(T);
  z(M, {
    name: "rotate-cw",
    size: 13,
    class: "shrink-0"
  }), Ae(2), t(T);
  var q = a(T, 2),
    oe = r(q);
  z(oe, {
    name: "power",
    size: 13,
    class: "shrink-0"
  }), Ae(2), t(q), t($), t(Le);
  var j = a(Le, 2),
    V = r(j);
  {
    var De = R => {
        var _e = El(),
          te = Ge(_e),
          he = r(te),
          Re = r(he);
        z(Re, {
          name: "search",
          size: 13,
          class: "shrink-0 text-text-muted"
        });
        var lt = a(Re, 2);
        ur(lt);
        var dt = a(lt, 2);
        {
          var Tt = Ce => {
            var Ie = Jo(),
              xt = r(Ie);
            z(xt, {
              name: "x",
              size: 12
            }), t(Ie), d("click", Ie, () => s(ze, "")), n(Ce, Ie)
          };
          f(dt, Ce => {
            e(ze) && Ce(Tt)
          })
        }
        t(he);
        var Ft = a(he, 2),
          jt = r(Ft),
          _t = r(jt);
        {
          var bt = Ce => {
              var Ie = dr();
              y(() => I(Ie, `${e(je).length??""} of ${c().length??""}`)), n(Ce, Ie)
            },
            It = Ce => {
              var Ie = dr();
              y(() => I(Ie, `${c().length??""} installed`)), n(Ce, Ie)
            };
          f(_t, Ce => {
            e(pe) && e(je).length !== c().length ? Ce(bt) : Ce(It, -1)
          })
        }
        t(jt), t(Ft), t(te);
        var Ke = a(te, 2),
          Mt = r(Ke),
          Ot = r(Mt),
          Ut = r(Ot),
          ar = a(r(Ut), 2);
        {
          var zt = Ce => {
            var Ie = Zo();
            Ze(Ie, 5, P, xt => xt.id, (xt, Ct) => {
              var Ht = Qo(),
                kt = r(Ht);
              ga(kt, () => e(Ct).id, () => 12);
              var $r = a(kt);
              t(Ht), y(() => {
                me(Ht, 1, `flex h-6 items-center gap-1.5 rounded px-2 text-[11.5px] transition-colors cursor-pointer ${e(ve)===e(Ct).id?"text-text-primary":"text-text-muted hover:text-text-primary"}`), I($r, ` ${e(Ct).label??""}`)
              }), d("click", Ht, () => s(ve, e(Ct).id, !0)), n(xt, Ht)
            }), t(Ie), n(Ce, Ie)
          };
          f(ar, Ce => {
            P().length > 1 && Ce(zt)
          })
        }
        t(Ut);
        var Jt = a(Ut, 2),
          or = r(Jt);
        ur(or);
        var yt = a(or, 2);
        {
          var Bt = Ce => {
              var Ie = el(),
                xt = r(Ie);
              z(xt, {
                name: "x",
                size: 13
              }), Ae(), t(Ie), d("click", Ie, () => Je.cancel()), n(Ce, Ie)
            },
            fr = Ce => {
              var Ie = tl(),
                xt = r(Ie);
              {
                var Ct = kt => {
                    Gt(kt, {
                      size: 13
                    })
                  },
                  Ht = kt => {
                    z(kt, {
                      name: "download",
                      size: 13
                    })
                  };
                f(xt, kt => {
                  e(J) ? kt(Ct) : kt(Ht, -1)
                })
              }
              Ae(), t(Ie), y(kt => Ie.disabled = kt, [() => !e(re).trim()]), d("click", Ie, Pe), n(Ce, Ie)
            };
          f(yt, Ce => {
            v().active ? Ce(Bt) : Ce(fr, -1)
          })
        }
        t(Jt);
        var Wt = a(Jt, 2);
        {
          var nr = Ce => {
            var Ie = il(),
              xt = a(r(Ie), 2);
            {
              var Ct = Qt => {
                  var St = rl();
                  y(Pt => {
                    ut(St, "title", x()), me(St, 1, `rounded px-1.5 py-0.5 transition-colors cursor-pointer ${Pt??""}`)
                  }, [() => Se(x()) ? "text-text-primary" : "hover:text-text-primary"]), d("click", St, () => de(x())), n(Qt, St)
                },
                Ht = A(() => Pa(x()));
              f(xt, Qt => {
                e(Ht) && Qt(Ct)
              })
            }
            var kt = a(xt, 2);
            {
              var $r = Qt => {
                const St = A(() => {
                  var Lt;
                  return ((Lt = O()) == null ? void 0 : Lt.live) ?? S()
                });
                var Pt = al(),
                  ot = a(Ge(Pt), 2);
                y(Lt => {
                  ut(ot, "title", e(St) ?? ""), me(ot, 1, `rounded px-1.5 py-0.5 transition-colors cursor-pointer ${Lt??""}`)
                }, [() => Se(e(St)) ? "text-text-primary" : "hover:text-text-primary"]), d("click", ot, () => de(e(St))), n(Qt, Pt)
              };
              f(kt, Qt => {
                var St;
                ((St = O()) != null && St.live || S()) && Qt($r)
              })
            }
            var Er = a(kt, 2);
            {
              var Wr = Qt => {
                var St = nl(),
                  Pt = a(Ge(St), 2);
                y(ot => {
                  ut(Pt, "title", O().beta), me(Pt, 1, `rounded px-1.5 py-0.5 transition-colors cursor-pointer ${ot??""}`)
                }, [() => Se(O().beta) ? "text-text-primary" : "hover:text-text-primary"]), d("click", Pt, () => de(O().beta)), n(Qt, St)
              };
              f(Er, Qt => {
                var St;
                (St = O()) != null && St.beta && Qt(Wr)
              })
            }
            t(Ie), n(Ce, Ie)
          };
          f(Wt, Ce => {
            v().active || Ce(nr)
          })
        }
        var gr = a(Wt, 2);
        {
          var pr = Ce => {
            var Ie = cl(),
              xt = r(Ie),
              Ct = r(xt);
            t(xt);
            var Ht = a(xt, 2),
              kt = r(Ht),
              $r = r(kt);
            {
              var Er = Lt => {
                  var qt = sl(),
                    zr = Ge(qt);
                  Gt(zr, {
                    size: 11
                  }), Ae(), n(Lt, qt)
                },
                Wr = Lt => {
                  var qt = ol(),
                    zr = r(qt);
                  t(qt), y((_, se) => I(zr, `${_??""} / ${se??""} MB`), [() => at(v().downloaded), () => at(v().total)]), n(Lt, qt)
                };
              f($r, Lt => {
                v().phase === "extract" ? Lt(Er) : Lt(Wr, -1)
              })
            }
            var Qt = a($r, 2);
            {
              var St = Lt => {
                var qt = ll(),
                  zr = r(qt);
                t(qt), y(() => I(zr, `· ${v().package??""}`)), n(Lt, qt)
              };
              f(Qt, Lt => {
                v().package && Lt(St)
              })
            }
            t(kt);
            var Pt = a(kt, 2),
              ot = r(Pt);
            t(Pt), t(Ht), t(Ie), y(() => {
              sr(Ct, `width:${e(qe)??""}%`), I(ot, `${e(qe)??""}%`)
            }), n(Ce, Ie)
          };
          f(gr, Ce => {
            v().active && Ce(pr)
          })
        }
        var br = a(gr, 2);
        {
          var vr = Ce => {
            var Ie = dl(),
              xt = r(Ie);
            z(xt, {
              name: "alert-circle",
              size: 13,
              class: "shrink-0"
            });
            var Ct = a(xt);
            t(Ie), y(() => I(Ct, ` ${v().error??""}`)), n(Ce, Ie)
          };
          f(br, Ce => {
            v().error && !v().active && Ce(vr)
          })
        }
        t(Ot);
        var kr = a(Ot, 2),
          xr = r(kr),
          nt = r(xr);
        z(nt, {
          name: "box",
          size: 12,
          class: "text-text-muted"
        }), Ae(2), t(xr);
        var vt = a(xr, 2);
        {
          var _r = Ce => {
              var Ie = ul(),
                xt = r(Ie);
              z(xt, {
                name: "inbox",
                size: 22,
                class: "text-text-muted"
              }), Ae(4), t(Ie), n(Ce, Ie)
            },
            Vt = Ce => {
              var Ie = pl(),
                xt = a(r(Ie), 2);
              t(Ie), d("click", xt, We), n(Ce, Ie)
            },
            Lr = Ce => {
              var Ie = Ll();
              Ze(Ie, 21, () => e(Ye), ([xt, Ct]) => xt, (xt, Ct) => {
                var Ht = A(() => tn(e(Ct), 2));
                let kt = () => e(Ht)[0],
                  $r = () => e(Ht)[1];
                var Er = Pl(),
                  Wr = r(Er);
                {
                  var Qt = Pt => {
                    var ot = vl(),
                      Lt = r(ot);
                    ga(Lt, kt, () => 11);
                    var qt = a(Lt, 2),
                      zr = r(qt, !0);
                    t(qt);
                    var _ = a(qt, 2),
                      se = r(_, !0);
                    t(_), t(ot), y(F => {
                      I(zr, F), I(se, $r().length)
                    }, [() => He(kt())]), n(Pt, ot)
                  };
                  f(Wr, Pt => {
                    e(k) === "all" && e(rt).length > 1 && Pt(Qt)
                  })
                }
                var St = a(Wr, 2);
                Ze(St, 21, $r, Pt => Pt.id, (Pt, ot) => {
                  const Lt = A(() => e(ot).id === g()),
                    qt = A(() => e(ot).id === S()),
                    zr = A(() => D().has(Je.launch_key(e(ot)))),
                    _ = A(() => K().active === `${e(ot).launcher}:${e(ot).id}`),
                    se = A(() => Jn(e(ot), x(), xe()));
                  var F = Cl(),
                    Ne = r(F),
                    ce = r(Ne);
                  ga(ce, kt, () => 18), t(Ne);
                  var Xe = a(Ne, 2),
                    ht = r(Xe),
                    Zt = r(ht),
                    Kt = r(Zt, !0);
                  t(Zt);
                  var hr = a(Zt, 2);
                  {
                    var mr = Ve => {
                      var st = xl(),
                        At = r(st);
                      z(At, {
                        name: "check",
                        size: 9
                      }), Ae(), t(st), n(Ve, st)
                    };
                    f(hr, Ve => {
                      e(ot).patched && Ve(mr)
                    })
                  }
                  var Ar = a(hr, 2);
                  {
                    var Mr = Ve => {
                        var st = ml();
                        n(Ve, st)
                      },
                      Vr = Ve => {
                        var st = fl();
                        n(Ve, st)
                      };
                    f(Ar, Ve => {
                      e(Lt) ? Ve(Mr) : e(qt) && Ve(Vr, 1)
                    })
                  }
                  var aa = a(Ar, 2);
                  {
                    var na = Ve => {
                      {
                        let st = A(() => xe() ?? x());
                        ct(Ve, {
                          get label() {
                            return `constraintt.ez supports Roblox ${e(st)??""} — this build can't be patched`
                          },
                          children: (At, rr) => {
                            var ir = gl(),
                              Rr = r(ir);
                            z(Rr, {
                              name: "alert-triangle",
                              size: 9
                            }), Ae(), t(ir), n(At, ir)
                          },
                          $$slots: {
                            default: !0
                          }
                        })
                      }
                    };
                    f(aa, Ve => {
                      e(se) === !1 && Ve(na)
                    })
                  }
                  t(ht);
                  var Yr = a(ht, 2),
                    Hr = r(Yr, !0),
                    ia = a(Hr);
                  {
                    var sa = Ve => {
                      var st = dr();
                      y(() => I(st, `· ${e(ot).file_version??""}`)), n(Ve, st)
                    };
                    f(ia, Ve => {
                      e(ot).file_version && Ve(sa)
                    })
                  }
                  t(Yr), t(Xe);
                  var oa = a(Xe, 2),
                    mt = r(oa);
                  {
                    var jr = Ve => {
                        ct(Ve, {
                          get label() {
                            return `Download Roblox ${xe()??""}, the build this constraintt.ez release supports`
                          },
                          children: (st, At) => {
                            var rr = hl(),
                              ir = r(rr);
                            {
                              var Rr = qr => {
                                  var Xr = bl(),
                                    Jr = Ge(Xr);
                                  Gt(Jr, {
                                    size: 11
                                  }), Ae(), n(qr, Xr)
                                },
                                _a = qr => {
                                  var Xr = _l(),
                                    Jr = Ge(Xr);
                                  z(Jr, {
                                    name: "download",
                                    size: 11
                                  }), Ae(), n(qr, Xr)
                                };
                              f(ir, qr => {
                                v().active && v().version === x() ? qr(Rr) : qr(_a, -1)
                              })
                            }
                            t(rr), y(() => rr.disabled = v().active || K().active !== null), d("click", rr, () => Ue(e(ot).launcher)), n(st, rr)
                          },
                          $$slots: {
                            default: !0
                          }
                        })
                      },
                      Dr = A(() => e(se) === !1 && Pa(x())),
                      ma = Ve => {
                        var st = yl(),
                          At = r(st);
                        Gt(At, {
                          size: 12
                        }), Ae(), t(st), n(Ve, st)
                      },
                      ft = Ve => {
                        {
                          let st = A(() => e(se) === !1 ? `constraintt.ez supports Roblox ${xe()}, this build is ${e(ot).file_version}` : "Install the constraintt.ez files into this build");
                          ct(Ve, {
                            get label() {
                              return e(st)
                            },
                            children: (At, rr) => {
                              var ir = wl(),
                                Rr = r(ir);
                              z(Rr, {
                                name: "download",
                                size: 11
                              }), Ae(), t(ir), y(() => ir.disabled = K().active !== null || e(se) === !1), d("click", ir, () => La.patch(e(ot))), n(At, ir)
                            },
                            $$slots: {
                              default: !0
                            }
                          })
                        }
                      };
                    f(mt, Ve => {
                      e(Dr) ? Ve(jr) : e(_) ? Ve(ma, 1) : e(ot).patched || Ve(ft, 2)
                    })
                  }
                  var Et = a(mt, 2);
                  {
                    var it = Ve => {
                        var st = kl(),
                          At = r(st);
                        Gt(At, {
                          size: 12
                        }), Ae(), t(st), n(Ve, st)
                      },
                      wt = Ve => {
                        var st = $l(),
                          At = r(st);
                        z(At, {
                          name: "play",
                          size: 11
                        }), Ae(), t(st), y(() => me(st, 1, `flex h-8 items-center gap-1.5 rounded-md px-3 text-[12px] font-medium cursor-pointer transition-[filter,color]
                                                                    ${e(ot).patched?"bg-text-primary text-bg-base hover:brightness-95":"text-text-secondary ring-1 ring-inset ring-line hover:text-text-primary"}`)), d("click", st, () => Je.launch(e(ot))), n(Ve, st)
                      };
                    f(Et, Ve => {
                      e(zr) ? Ve(it) : Ve(wt, -1)
                    })
                  }
                  var er = a(Et, 2);
                  {
                    var Fr = Ve => {
                      ct(Ve, {
                        label: "Restore original files",
                        children: (st, At) => {
                          var rr = zl(),
                            ir = r(rr);
                          z(ir, {
                            name: "rotate-cw",
                            size: 13
                          }), t(rr), d("click", rr, () => La.unpatch(e(ot))), n(st, rr)
                        },
                        $$slots: {
                          default: !0
                        }
                      })
                    };
                    f(er, Ve => {
                      e(ot).patched && Ve(Fr)
                    })
                  }
                  var la = a(er, 2);
                  ct(la, {
                    label: "Uninstall",
                    children: (Ve, st) => {
                      var At = Sl(),
                        rr = r(At);
                      z(rr, {
                        name: "trash",
                        size: 13
                      }), t(At), d("click", At, () => Je.remove(e(ot))), n(Ve, At)
                    },
                    $$slots: {
                      default: !0
                    }
                  }), t(oa), t(F), y(Ve => {
                    me(F, 1, `group flex items-center gap-3 rounded-[10px] bg-bg-elevated p-3 ring-1 ring-inset transition-[box-shadow] duration-[140ms] ${e(Lt)?"ring-success/40":"ring-line/60"}`), I(Kt, Ve), I(Hr, e(ot).id)
                  }, [() => He(kt())]), d("click", Yr, () => Je.open_path(e(ot))), n(Pt, F)
                }), t(St), t(Er), n(xt, Er)
              }), t(Ie), n(Ce, Ie)
            };
          f(vt, Ce => {
            c().length === 0 ? Ce(_r) : e(je).length === 0 ? Ce(Vt, 1) : Ce(Lr, -1)
          })
        }
        t(kr), t(Mt), t(Ke), y(() => or.disabled = v().active), Or(lt, () => e(ze), Ce => s(ze, Ce)), Or(or, () => e(re), Ce => s(re, Ce)), n(R, _e)
      },
      tt = R => {
        var _e = Ol(),
          te = Ge(_e),
          he = a(r(te), 4),
          Re = r(he);
        t(he), Ae(2), t(te);
        var lt = a(te, 2),
          dt = r(lt),
          Tt = a(r(dt), 2);
        {
          var Ft = _t => {
              var bt = Ml(),
                It = r(bt);
              z(It, {
                name: "inbox",
                size: 22,
                class: "text-text-muted"
              });
              var Ke = a(It, 4);
              {
                var Mt = Ot => {
                  var Ut = Al();
                  d("click", Ut, () => s(Oe, "all")), n(Ot, Ut)
                };
                f(Ke, Ot => {
                  e(Oe) !== "all" && Ot(Mt)
                })
              }
              t(bt), n(_t, bt)
            },
            jt = _t => {
              var bt = Fl();
              Ze(bt, 23, () => e(ge), It => It.id, (It, Ke, Mt) => {
                var Ot = jl(),
                  Ut = r(Ot);
                ga(Ut, () => e(Ke).id, () => 22);
                var ar = a(Ut, 2),
                  zt = r(ar),
                  Jt = r(zt, !0);
                t(zt);
                var or = a(zt, 2),
                  yt = r(or);
                {
                  var Bt = nt => {
                      var vt = dr("Installed · ready as launch target");
                      n(nt, vt)
                    },
                    fr = nt => {
                      var vt = Dl(),
                        _r = a(Ge(vt)),
                        Vt = r(_r, !0);
                      t(_r), y(() => I(Vt, e(Ke).latest_tag)), n(nt, vt)
                    },
                    Wt = nt => {
                      var vt = dr("Available to install");
                      n(nt, vt)
                    },
                    nr = nt => {
                      var vt = dr("Not available");
                      n(nt, vt)
                    };
                  f(yt, nt => {
                    e(Ke).installed ? nt(Bt) : e(Ke).latest_tag ? nt(fr, 1) : e(Ke).installable ? nt(Wt, 2) : nt(nr, -1)
                  })
                }
                t(or), t(ar);
                var gr = a(ar, 2),
                  pr = r(gr);
                {
                  var br = nt => {
                    ct(nt, {
                      label: "Visit website",
                      children: (vt, _r) => {
                        var Vt = Rl(),
                          Lr = r(Vt);
                        z(Lr, {
                          name: "external-link",
                          size: 13
                        }), t(Vt), y(() => ut(Vt, "aria-label", `Visit ${e(Ke).label??""} website`)), d("click", Vt, () => pa(e(Ke).website)), n(vt, Vt)
                      },
                      $$slots: {
                        default: !0
                      }
                    })
                  };
                  f(pr, nt => {
                    e(Ke).website && nt(br)
                  })
                }
                var vr = a(pr, 2);
                {
                  var kr = nt => {
                      var vt = wr(),
                        _r = Ge(vt);
                      {
                        var Vt = Ce => {
                            ct(Ce, {
                              get label() {
                                return `Uninstall ${e(Ke).label??""}`
                              },
                              children: (Ie, xt) => {
                                var Ct = Il(),
                                  Ht = r(Ct);
                                z(Ht, {
                                  name: "trash",
                                  size: 13
                                }), t(Ct), y(() => ut(Ct, "aria-label", `Uninstall ${e(Ke).label??""}`)), d("click", Ct, () => s(G, e(Ke), !0)), n(Ie, Ct)
                              },
                              $$slots: {
                                default: !0
                              }
                            })
                          },
                          Lr = Ce => {
                            var Ie = Nl();
                            n(Ce, Ie)
                          };
                        f(_r, Ce => {
                          e(Ke).uninstallable ? Ce(Vt) : Ce(Lr, -1)
                        })
                      }
                      n(nt, vt)
                    },
                    xr = nt => {
                      var vt = Tl(),
                        _r = r(vt);
                      {
                        var Vt = Ce => {
                            Gt(Ce, {
                              size: 12
                            })
                          },
                          Lr = Ce => {
                            z(Ce, {
                              name: "download",
                              size: 12
                            })
                          };
                        f(_r, Ce => {
                          Q() === e(Ke).id ? Ce(Vt) : Ce(Lr, -1)
                        })
                      }
                      Ae(), t(vt), y(() => {
                        vt.disabled = Q() !== null, ut(vt, "title", `Install ${e(Ke).label??""}`)
                      }), d("click", vt, () => Je.install_client(e(Ke).id)), n(nt, vt)
                    };
                  f(vr, nt => {
                    e(Ke).installed ? nt(kr) : e(Ke).installable && nt(xr, 1)
                  })
                }
                t(gr), t(Ot), y(() => {
                  me(Ot, 1, `flex items-center gap-3 py-3.5 ${e(Mt)>0?"border-t border-line/40":""}`), I(Jt, e(Ke).label)
                }), n(It, Ot)
              }), t(bt), n(_t, bt)
            };
          f(Tt, _t => {
            e(ge).length === 0 ? _t(Ft) : _t(jt, -1)
          })
        }
        t(dt), t(lt), y(() => I(Re, `${e(p)??""} installed · ${e(u)??""} available`)), n(R, _e)
      };
    f(V, R => {
      e(Y) === "versions" ? R(De) : R(tt, -1)
    })
  }
  t(j);
  var Qe = a(j, 2);
  {
    let R = A(() => e(G) !== null);
    Sa(Qe, {
      get open() {
        return e(R)
      },
      onclose: () => s(G, null),
      class: "w-[380px] max-w-[88%] p-5",
      children: (_e, te) => {
        var he = Ul(),
          Re = r(he),
          lt = r(Re),
          dt = r(lt);
        t(lt);
        var Tt = a(lt, 2),
          Ft = a(r(Tt)),
          jt = r(Ft, !0);
        t(Ft), Ae(2), t(Tt), t(Re);
        var _t = a(Re, 2),
          bt = r(_t),
          It = a(bt, 2);
        t(_t), t(he), y(() => {
          var Ke, Mt;
          I(dt, `Uninstall ${((Ke=e(G))==null?void 0:Ke.label)??""}?`), I(jt, (Mt = e(G)) == null ? void 0 : Mt.label)
        }), d("click", bt, () => s(G, null)), d("click", It, () => {
          var Mt;
          const Ke = (Mt = e(G)) == null ? void 0 : Mt.id;
          s(G, null), Ke && Je.uninstall_client(Ke)
        }), n(_e, he)
      },
      $$slots: {
        default: !0
      }
    })
  }
  t(be), y(() => {
    me(Ee, 1, `flex h-7 flex-1 items-center justify-center gap-1.5 rounded-[6px] text-[12px] font-medium transition-colors cursor-pointer
                    ${e(Y)==="versions"?"bg-bg-active text-text-primary":"text-text-muted hover:text-text-primary"}`), me(et, 1, `flex h-7 flex-1 items-center justify-center gap-1.5 rounded-[6px] text-[12px] font-medium transition-colors cursor-pointer
                    ${e(Y)==="launchers"?"bg-bg-active text-text-primary":"text-text-muted hover:text-text-primary"}`)
  }), d("click", Ee, () => s(Y, "versions")), d("click", et, () => s(Y, "launchers")), d("click", T, () => {
    Je.refresh(), Je.load_running(), Je.load_clients()
  }), d("click", q, () => Je.kill()), n(l, be), Rt(), ye()
}
Yt(["click"]);
var Vl = i('<div class="flex shrink-0 flex-col items-end gap-1 rounded-[10px] bg-bg-elevated px-3.5 py-2.5 ring-1 ring-inset ring-line/60"><span class="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-[0.08em] text-text-muted"><!> Key</span> <span><!></span></div>'),
  Hl = i('<div class="flex flex-col gap-0.5 pr-16"><h2 class="text-[14px] font-semibold tracking-tight text-text-primary">New script</h2> <p class="text-[12.5px] text-text-muted">Start with a blank file.</p></div>'),
  ql = i('<div class="flex flex-col gap-0.5 pr-16"><h2 class="text-[14px] font-semibold tracking-tight text-text-primary">Script Hub</h2> <p class="text-[12.5px] text-text-muted">Browse community scripts.</p></div>'),
  Kl = i('<div class="flex flex-col gap-0.5 pr-16"><h2 class="text-[14px] font-semibold tracking-tight text-text-primary"> </h2> <p class="text-[12.5px] text-text-muted"> </p></div>'),
  Gl = i('<p class="py-2 text-[13px] text-text-muted">No scripts run yet.</p>'),
  Yl = i('<li><button class="group flex w-full items-center gap-3 py-2 text-left transition-colors cursor-pointer text-text-secondary hover:text-text-primary"><!> <span class="min-w-0 flex-1 truncate text-[13px]"> </span> <span class="shrink-0 text-[11px] text-text-muted"> </span></button></li>'),
  Xl = i('<ul class="flex flex-col"></ul>'),
  Jl = i(`<div class="welcome-root h-full overflow-y-auto bg-bg-base"><div class="mx-auto max-w-[900px] px-12 py-14"><header class="mb-12 flex items-center gap-5"><div class="text-text-primary"><!></div> <div class="min-w-0 flex-1"><h1 class="text-[32px] font-semibold leading-none tracking-[-0.02em] text-text-primary">Welcome to constraintt.ez</h1> <p class="mt-2 text-[14px] text-text-muted"> </p></div> <!></header> <div class="grid gap-2"><!> <!> <!></div> <div class="mt-10 grid gap-x-10 gap-y-8 md:grid-cols-2"><section><h3 class="mb-3 text-[11px] font-semibold uppercase tracking-[0.1em] text-text-muted">Quick actions</h3> <ul class="flex flex-col"><li><button class="group flex w-full items-center gap-3 py-2 text-left transition-colors cursor-pointer text-text-secondary hover:text-text-primary"><!> <span class="flex-1 text-[13px]">Open file…</span> <span class="hidden font-mono text-[11px] text-text-muted sm:inline">Ctrl+O</span></button></li> <li><button class="group flex w-full items-center gap-3 py-2 text-left transition-colors cursor-pointer text-text-secondary hover:text-text-primary"><!> <span class="flex-1 text-[13px]">Appearance & themes</span></button></li> <li><button class="group flex w-full items-center gap-3 py-2 text-left transition-colors cursor-pointer text-text-secondary hover:text-text-primary"><span class="size-3.5 shrink-0 bg-text-muted transition-colors group-hover:bg-text-primary [mask:url('/discord.svg')_center/contain_no-repeat]"></span> <span class="flex-1 text-[13px]">Join the Discord</span></button></li></ul></section> <section><h3 class="mb-3 text-[11px] font-semibold uppercase tracking-[0.1em] text-text-muted">Recent</h3> <!></section></div> <p class="mt-12 text-[12px] leading-relaxed text-text-muted">Community, updates and support live in the <button class="font-medium text-text-secondary underline decoration-text-muted/40 underline-offset-2 hover:text-text-primary hover:decoration-text-primary/50 transition-colors cursor-pointer">Discord</button>.
            If you paid for this software, you have been scammed.</p></div></div>`);

function Ql(l, o) {
  Dt(o, !0);
  const x = () => $t(O, "$license_status", v),
    [v, w] = Br();
  let P = C(Nt([])),
    c = C(Nt([])),
    g = C(null),
    S = C(!1);
  const O = Qn.status;
  let D = C(Nt(Date.now())),
    K = null;
  const xe = A(() => {
      var p;
      return Zn((p = x()) == null ? void 0 : p.expires_at, e(D))
    }),
    Q = A(() => {
      var p;
      return ti((p = x()) == null ? void 0 : p.expires_at)
    }),
    B = vn.subscribe(p => s(P, p, !0)),
    ye = Je.installed.subscribe(p => s(c, p, !0)),
    we = Je.supported.subscribe(p => s(g, p, !0));
  Tr(async () => {
    K = setInterval(() => s(D, Date.now(), !0), 3e4), await Je.refresh(), e(g) || await Je.load_supported()
  }), Ur(() => {
    B(), ye(), we(), K && clearInterval(K)
  });
  const ue = A(() => e(P).slice(0, 4)),
    ke = A(() => e(g) ? e(c).find(p => p.id === e(g)) ?? e(c)[0] ?? null : e(c)[0] ?? null);
  async function U() {
    if (!(e(S) || !e(ke))) {
      s(S, !0);
      try {
        await Je.launch(e(ke))
      } finally {
        s(S, !1)
      }
    }
  }
  async function W() {
    try {
      await pa("discord://-/invite/olemad")
    } catch {
      await pa("https://discord.gg/olemad")
    }
  }

  function le(p) {
    const u = new Date(p).getTime();
    if (Number.isNaN(u)) return "";
    const ge = Date.now() - u,
      be = Math.floor(ge / 6e4);
    if (be < 1) return "just now";
    if (be < 60) return `${be}m ago`;
    const Le = Math.floor(be / 60);
    if (Le < 24) return `${Le}h ago`;
    const H = Math.floor(Le / 24);
    return H < 7 ? `${H}d ago` : new Date(p).toLocaleDateString()
  }
  var ee = Jl(),
    fe = r(ee),
    ie = r(fe),
    $e = r(ie),
    Z = r($e);
  xn(Z, {
    size: 48
  }), t($e);
  var Y = a($e, 2),
    re = a(r(Y), 2),
    J = r(re);
  t(re), t(Y);
  var ve = a(Y, 2);
  {
    var ze = p => {
      const u = A(() => x().valid);
      {
        let ge = A(() => e(u) ? e(Q) ? `Expires ${e(Q)}` : "This key has no expiry date" : ei(x().reason) || "Your key couldn't be verified");
        ct(p, {
          get label() {
            return e(ge)
          },
          side: "bottom",
          children: (be, Le) => {
            var H = Vl(),
              Ee = r(H),
              Te = r(Ee);
            z(Te, {
              name: "key",
              size: 11
            }), Ae(), t(Ee);
            var et = a(Ee, 2),
              E = r(et);
            {
              var h = $ => {
                  var X = dr("Invalid");
                  n($, X)
                },
                m = $ => {
                  var X = dr();
                  y(() => I(X, `${e(xe)??""} left`)), n($, X)
                },
                b = $ => {
                  var X = dr("Lifetime");
                  n($, X)
                };
              f(E, $ => {
                e(u) ? e(xe) ? $(m, 1) : $(b, -1) : $(h)
              })
            }
            t(et), t(H), y(() => me(et, 1, `text-[13px] font-semibold ${e(u)?"text-text-primary":"text-danger"}`)), n(be, H)
          },
          $$slots: {
            default: !0
          }
        })
      }
    };
    f(ve, p => {
      x() && p(ze)
    })
  }
  t(ie);
  var k = a(ie, 2),
    L = r(k);
  Ea(L, {
    interactive: !0,
    get onclick() {
      return o.onnew
    },
    padding: "md",
    decoration: "file-code",
    children: (p, u) => {
      var ge = Hl();
      n(p, ge)
    },
    $$slots: {
      default: !0
    }
  });
  var ae = a(L, 2);
  Ea(ae, {
    interactive: !0,
    get onclick() {
      return o.onhub
    },
    padding: "md",
    decoration: "cloud",
    children: (p, u) => {
      var ge = ql();
      n(p, ge)
    },
    $$slots: {
      default: !0
    }
  });
  var Me = a(ae, 2);
  {
    let p = A(() => e(S) || !e(ke));
    Ea(Me, {
      interactive: !0,
      onclick: U,
      padding: "md",
      get disabled() {
        return e(p)
      },
      decoration: "roblox",
      children: (u, ge) => {
        var be = Kl(),
          Le = r(be),
          H = r(Le, !0);
        t(Le);
        var Ee = a(Le, 2),
          Te = r(Ee, !0);
        t(Ee), t(be), y(() => {
          I(H, e(S) ? "Launching…" : "Launch Roblox"), I(Te, e(ke) ? e(ke).id : "No versions installed")
        }), n(u, be)
      },
      $$slots: {
        default: !0
      }
    })
  }
  t(k);
  var Be = a(k, 2),
    Oe = r(Be),
    G = a(r(Oe), 2),
    de = r(G),
    Se = r(de),
    Pe = r(Se);
  z(Pe, {
    name: "folder-open",
    size: 14,
    class: "shrink-0 text-text-muted transition-colors group-hover:text-text-primary"
  }), Ae(4), t(Se), t(de);
  var Ue = a(de, 2),
    He = r(Ue),
    We = r(He);
  z(We, {
    name: "palette",
    size: 14,
    class: "shrink-0 text-text-muted transition-colors group-hover:text-text-primary"
  }), Ae(2), t(He), t(Ue);
  var je = a(Ue, 2),
    N = r(je);
  t(je), t(G), t(Oe);
  var Ye = a(Oe, 2),
    rt = a(r(Ye), 2);
  {
    var pt = p => {
        var u = Gl();
        n(p, u)
      },
      qe = p => {
        var u = Xl();
        Ze(u, 21, () => e(ue), ge => ge.id, (ge, be) => {
          var Le = Yl(),
            H = r(Le),
            Ee = r(H);
          z(Ee, {
            name: "file-code",
            size: 13,
            class: "shrink-0 text-text-muted"
          });
          var Te = a(Ee, 2),
            et = r(Te, !0);
          t(Te);
          var E = a(Te, 2),
            h = r(E, !0);
          t(E), t(H), t(Le), y(m => {
            I(et, e(be).name), I(h, m)
          }, [() => le(e(be).time)]), d("click", H, () => o.onopenrecent(e(be))), n(ge, Le)
        }), t(u), n(p, u)
      };
    f(rt, p => {
      e(ue).length === 0 ? p(pt) : p(qe, -1)
    })
  }
  t(Ye), t(Be);
  var at = a(Be, 2),
    pe = a(r(at));
  Ae(), t(at), t(fe), t(ee), y(() => I(J, `Roblox execution, refined  ·  ${e(c).length??""} version${e(c).length===1?"":"s"} installed`)), d("click", Se, function(...p) {
    var u;
    (u = o.onopen) == null || u.apply(this, p)
  }), d("click", He, () => {
    var p;
    return (p = o.onsettings) == null ? void 0 : p.call(o)
  }), d("click", N, W), d("click", pe, W), n(l, ee), Rt(), w()
}
Yt(["click"]);
var Zl = i("<span> </span>"),
  ec = i('<span class="text-text-muted"> </span>'),
  tc = i('<span class="text-text-muted"></span>'),
  rc = i('<div><span class="text-warning"> </span><span class="text-text-muted"></span><!><span class="text-text-muted">,</span></div>'),
  ac = i('<div class="pl-4"></div><span class="text-text-muted"></span>', 1),
  nc = i('<button class="cursor-pointer select-none text-text-muted transition-colors hover:text-text-primary"><span class="inline-block w-3 text-center"> </span> </button><!>', 1),
  ic = i("<!><!>", 1);

function _n(l, o) {
  Dt(o, !0);
  let x = Nr(o, "depth", 3, 0);

  function v(W) {
    if (typeof W != "string") return W;
    const le = W.trim();
    if (!(le.startsWith("{") && le.endsWith("}") || le.startsWith("[") && le.endsWith("]"))) return W;
    try {
      const fe = JSON.parse(le);
      return fe !== null && typeof fe == "object" ? fe : W
    } catch {
      return W
    }
  }

  function w(W) {
    if (W === null || typeof W != "object" || Array.isArray(W)) return null;
    const le = Object.keys(W);
    if (!le.includes("keys") || !le.every(ie => ie === "value" || ie === "keys")) return null;
    const ee = W,
      fe = ee.keys;
    return fe === null || typeof fe != "object" ? null : {
      label: typeof ee.value == "string" ? ee.value : null,
      table: fe
    }
  }
  const P = A(() => v(o.value)),
    c = A(() => w(e(P))),
    g = A(() => e(c) ? e(c).table : e(P)),
    S = A(() => {
      var W;
      return ((W = e(c)) == null ? void 0 : W.label) ?? null
    }),
    O = A(() => e(g) !== null && typeof e(g) == "object"),
    D = W => /^\d+$/.test(W),
    K = A(() => {
      if (Array.isArray(e(g))) return e(g).map((ee, fe) => [String(fe + 1), ee, !0]);
      if (!e(O)) return [];
      const W = [],
        le = [];
      for (const [ee, fe] of Object.entries(e(g)))(D(ee) ? W : le).push([ee, fe, D(ee)]);
      return W.sort((ee, fe) => Number(ee[0]) - Number(fe[0])), [...W, ...le]
    }),
    xe = A(() => e(O) && e(K).length === 0);
  let Q = C(Nt(En(() => x() === 0)));

  function B(W) {
    return typeof W == "string" ? "text-success" : typeof W == "number" ? "text-info" : typeof W == "boolean" ? "text-warning" : "text-text-muted"
  }

  function ye(W) {
    return typeof W == "string" ? `"${W}"` : W == null ? "nil" : String(W)
  }
  var we = wr(),
    ue = Ge(we);
  {
    var ke = W => {
        var le = Zl(),
          ee = r(le, !0);
        t(le), y((fe, ie) => {
          me(le, 1, fe), I(ee, ie)
        }, [() => pn(B(e(g))), () => ye(e(g))]), n(W, le)
      },
      U = W => {
        var le = ic(),
          ee = Ge(le);
        {
          var fe = Y => {
            var re = ec(),
              J = r(re, !0);
            t(re), y(() => I(J, `${e(S)} `)), n(Y, re)
          };
          f(ee, Y => {
            e(S) && Y(fe)
          })
        }
        var ie = a(ee);
        {
          var $e = Y => {
              var re = tc();
              re.textContent = "{}", n(Y, re)
            },
            Z = Y => {
              var re = nc(),
                J = Ge(re),
                ve = r(J),
                ze = r(ve, !0);
              t(ve);
              var k = a(ve, 1, !0);
              t(J);
              var L = a(J);
              {
                var ae = Me => {
                  var Be = ac(),
                    Oe = Ge(Be);
                  Ze(Oe, 21, () => e(K), ([de, Se, Pe]) => de, (de, Se) => {
                    var Pe = A(() => tn(e(Se), 3));
                    let Ue = () => e(Pe)[0],
                      He = () => e(Pe)[1],
                      We = () => e(Pe)[2];
                    var je = rc(),
                      N = r(je),
                      Ye = r(N);
                    t(N);
                    var rt = a(N);
                    rt.textContent = " = ";
                    var pt = a(rt);
                    {
                      let qe = A(() => x() + 1);
                      _n(pt, {
                        get value() {
                          return He()
                        },
                        get depth() {
                          return e(qe)
                        }
                      })
                    }
                    Ae(), t(je), y(() => I(Ye, `[${(We()?Ue():`"${Ue()}"`)??""}]`)), n(de, je)
                  }), t(Oe);
                  var G = a(Oe);
                  G.textContent = "}", n(Me, Be)
                };
                f(L, Me => {
                  e(Q) && Me(ae)
                })
              }
              y(() => {
                ut(J, "aria-expanded", e(Q)), ut(J, "aria-label", e(Q) ? "Collapse table" : "Expand table"), I(ze, e(Q) ? "▾" : "▸"), I(k, e(Q) ? "{" : "{ … }")
              }), d("click", J, () => s(Q, !e(Q))), n(Y, re)
            };
          f(ie, Y => {
            e(xe) ? Y($e) : Y(Z, -1)
          })
        }
        n(W, le)
      };
    f(ue, W => {
      e(O) ? W(U, -1) : W(ke)
    })
  }
  n(l, we), Rt()
}
Yt(["click"]);
var sc = i('<span class="pointer-events-none absolute inset-x-0 bottom-0 h-[2px] bg-text-primary z-10"></span>'),
  oc = i('<span class="pointer-events-none absolute inset-y-1 left-0 z-10 w-0.5 rounded-full bg-text-primary"></span>'),
  lc = i('<span class="absolute inset-x-1 top-0 h-0.5 rounded-full"></span>'),
  cc = i('<input class="min-w-0 flex-1 rounded bg-bg-elevated px-1 text-[12px] text-text-primary outline-none ring-1 ring-inset ring-line"/>'),
  dc = i('<span class="min-w-0 flex-1 truncate"> </span>'),
  uc = i('<span class="pointer-events-none absolute inset-y-1 right-0 z-10 w-0.5 rounded-full bg-text-primary"></span>'),
  pc = i('<div role="tab" tabindex="0"><!> <!> <!> <!> <!> <button aria-label="close tab"><!></button> <!></div>'),
  vc = i('<input class="w-20 min-w-0 rounded bg-bg-active px-1 text-[12px] text-text-primary outline-none"/>'),
  xc = i('<span class="max-w-24 truncate"> </span>'),
  mc = i('<div role="button" tabindex="0" class="flex h-10 shrink-0 items-center gap-1.5 px-2.5 text-[12px] font-medium cursor-pointer hover:text-text-primary"><span class="size-2 shrink-0 rounded-full"></span> <!> <span class="text-text-muted"> </span> <!></div>'),
  fc = i('<span class="pointer-events-none absolute inset-x-0 bottom-0 h-[2px] bg-text-primary z-10"></span>'),
  gc = i('<div role="tab" tabindex="0" title="Home"><!> <!> <span class="truncate">Home</span> <button aria-label="close home tab"><!></button></div>'),
  bc = i("<!> <!>", 1),
  _c = i('<button class="mx-2 grid size-7 shrink-0 self-center place-items-center rounded text-text-muted hover:text-text-primary cursor-pointer transition-colors"><!></button>'),
  hc = i('<div class="relative flex h-9 shrink-0 items-stretch border-b border-line bg-bg-base"><div class="scrollbar-none flex min-w-0 flex-1 items-stretch overflow-x-auto overflow-y-hidden"><!> <!> <!></div> <!> <div class="tab-scrollbar absolute inset-x-0 bottom-0 overflow-x-auto overflow-y-hidden"><div class="h-px"></div></div></div> <!>', 1);

function yc(l, o) {
  Dt(o, !0);
  const x = (E, h = da, m = da) => {
      var b = pc(),
        $ = r(b);
      {
        var X = te => {
          var he = sc();
          n(te, he)
        };
        f($, te => {
          h().id === e(g) && !P() && te(X)
        })
      }
      var ne = a($, 2);
      {
        var T = te => {
          var he = oc();
          n(te, he)
        };
        f(ne, te => {
          e(Ue) === h().id && e(He) && te(T)
        })
      }
      var M = a(ne, 2);
      {
        var q = te => {
          var he = lc();
          y(() => sr(he, `background:${m()??""}`)), n(te, he)
        };
        f(M, te => {
          m() && te(q)
        })
      }
      var oe = a(M, 2);
      {
        let te = A(() => h().primary ? "play" : h().pinned ? "star" : "lua"),
          he = A(() => h().primary || h().pinned ? "" : `[filter:brightness(0)_invert(1)] ${h().id===e(g)&&!P()?"opacity-100":"opacity-55 group-hover:opacity-100"}`);
        z(oe, {
          get name() {
            return e(te)
          },
          size: 13,
          get class() {
            return `shrink-0 ${e(he)??""}`
          }
        })
      }
      var j = a(oe, 2);
      {
        var V = te => {
            var he = cc();
            ur(he), ba(he, Re => re == null ? void 0 : re(Re)), Ua(() => Or(he, () => e(W), Re => s(W, Re))), d("click", he, Re => Re.stopPropagation()), d("keydown", he, Re => {
              Re.key === "Enter" ? ee() : Re.key === "Escape" && s(U, null)
            }), yr("blur", he, ee), n(te, he)
          },
          De = te => {
            var he = dc(),
              Re = r(he, !0);
            t(he), y(() => I(Re, h().name)), d("dblclick", he, () => le(h())), n(te, he)
          };
        f(j, te => {
          e(U) === h().id ? te(V) : te(De, -1)
        })
      }
      var tt = a(j, 2),
        Qe = r(tt);
      z(Qe, {
        name: "x",
        size: 11
      }), t(tt);
      var R = a(tt, 2);
      {
        var _e = te => {
          var he = uc();
          n(te, he)
        };
        f(R, te => {
          e(Ue) === h().id && !e(He) && te(_e)
        })
      }
      t(b), y(() => {
        ut(b, "data-tab-id", h().id), me(b, 1, `tab-pill group relative flex h-9 min-w-0 max-w-52 shrink-0 items-center gap-2 px-3 text-[12px] transition-colors cursor-pointer select-none
            ${h().id===e(g)&&!P()?"text-text-primary":"text-text-muted hover:text-text-primary"}
            ${e(Pe)&&e(Se)===h().id?"opacity-40":""}`), ut(b, "aria-selected", h().id === e(g)), ut(b, "title", h().name), me(tt, 1, `grid size-4 shrink-0 place-items-center rounded text-text-muted transition-[opacity,color] hover:text-text-primary ${h().id===e(g)&&!P()?"opacity-100":"opacity-0 group-hover:opacity-100"} cursor-pointer`)
      }), d("pointerdown", b, te => Ye(te, h())), d("click", b, () => {
        if (We) {
          We = !1;
          return
        }
        o.onswitch(h())
      }), d("keydown", b, te => {
        (te.key === "Enter" || te.key === " ") && o.onswitch(h())
      }), d("mousedown", b, te => {
        te.button === 1 && o.onclose(te, h())
      }), d("contextmenu", b, te => J(te, h())), d("pointerdown", tt, te => te.stopPropagation()), d("click", tt, te => o.onclose(te, h())), Ir(3, b, () => mn, () => ({
        axis: "x"
      })), n(E, b)
    },
    v = (E, h = da) => {
      var m = mc(),
        b = r(m),
        $ = a(b, 2);
      {
        var X = oe => {
            var j = vc();
            ur(j), ba(j, V => re == null ? void 0 : re(V)), Ua(() => Or(j, () => e(ie), V => s(ie, V))), d("click", j, V => V.stopPropagation()), d("keydown", j, V => {
              V.key === "Enter" ? Z() : V.key === "Escape" && s(fe, null)
            }), yr("blur", j, Z), n(oe, j)
          },
          ne = oe => {
            var j = xc(),
              V = r(j, !0);
            t(j), y(() => {
              sr(j, `color:${h().color??""}`), I(V, h().name)
            }), d("dblclick", j, () => $e(h().id, h().name)), n(oe, j)
          };
        f($, oe => {
          e(fe) === h().id ? oe(X) : oe(ne, -1)
        })
      }
      var T = a($, 2),
        M = r(T, !0);
      t(T);
      var q = a(T, 2);
      {
        let oe = A(() => h().collapsed ? "chevron-right" : "chevron-down");
        z(q, {
          get name() {
            return e(oe)
          },
          size: 12,
          class: "text-text-muted"
        })
      }
      t(m), y(oe => {
        ut(m, "title", h().name), sr(b, `background:${h().color??""}`), I(M, oe)
      }, [() => Q(h().id).length]), d("click", m, () => {
        if (e(fe) === h().id) return;
        const oe = Q(h().id),
          j = oe.some(V => V.id === e(g));
        Fe.toggle_group_collapsed(h().id), h().collapsed && !j && oe.length > 0 && o.onswitch(oe[0])
      }), d("keydown", m, oe => {
        oe.key === "Enter" && Fe.toggle_group_collapsed(h().id)
      }), d("contextmenu", m, oe => ve(oe, h())), n(E, m)
    };
  let w = Nr(o, "welcome", 3, !1),
    P = Nr(o, "welcomeActive", 3, !1),
    c = C(Nt([])),
    g = C(null),
    S = C(Nt([]));
  const O = Fe.subscribe(E => {
    s(c, E.files, !0), s(g, E.active, !0), s(S, E.groups, !0)
  });
  Ur(() => O());
  const D = ["#C98A8A", "#D9A662", "#8FBF9A", "#8AA8C9", "#B39BC9", "#C9A0B8", "#8FBFB3", "#A8A29A"],
    K = (E, h) => (h.pinned ? 1 : 0) - (E.pinned ? 1 : 0),
    xe = A(() => [...e(c)].filter(E => !E.groupId).sort(K)),
    Q = E => [...e(c)].filter(h => h.groupId === E).sort(K);
  let B = C(!1),
    ye = C(0),
    we = C(0),
    ue = C(Nt([]));

  function ke(E, h) {
    E.preventDefault(), E.stopPropagation(), s(ye, Math.min(E.clientX, window.innerWidth - 210), !0), s(we, Math.min(E.clientY, window.innerHeight - 280), !0), s(ue, h, !0), s(B, !0)
  }
  let U = C(null),
    W = C("");

  function le(E) {
    s(U, E.id, !0), s(W, E.name, !0)
  }

  function ee() {
    e(U) && Fe.rename_tab(e(U), e(W)), s(U, null)
  }
  let fe = C(null),
    ie = C("");

  function $e(E, h) {
    s(fe, E, !0), s(ie, h, !0)
  }

  function Z() {
    e(fe) && Fe.rename_group(e(fe), e(ie).trim() || "Group"), s(fe, null)
  }

  function Y(E) {
    const h = D[e(S).length % D.length],
      m = Fe.create_group("Group", h);
    Fe.set_tab_group(E.id, m), $e(m, "Group")
  }

  function re(E) {
    E.focus(), E.select()
  }

  function J(E, h) {
    const m = [...e(S).map(X => ({
        label: X.name,
        swatch: X.color,
        action: () => Fe.set_tab_group(h.id, X.id)
      })), {
        separator: !0
      }, {
        label: "New group…",
        icon: "folder-plus",
        action: () => Y(h)
      }],
      b = [{
        label: "Scripts",
        icon: "folder",
        action: () => Fe.save_to_dir(h.id, "Scripts")
      }, {
        label: "Workspace",
        icon: "folder",
        action: () => Fe.save_to_dir(h.id, "Workspace")
      }, {
        label: "Auto Execute",
        icon: "folder",
        action: () => Fe.save_to_dir(h.id, "AutoExecute")
      }],
      $ = [{
        label: "Rename…",
        icon: "pencil",
        action: () => le(h)
      }, {
        label: h.primary ? "Remove primary" : "Set as primary",
        icon: "play",
        action: () => Fe.set_primary(h.id)
      }, {
        label: h.pinned ? "Unpin tab" : "Pin tab",
        icon: "pin",
        action: () => Fe.toggle_pin(h.id)
      }, {
        separator: !0
      }, {
        label: "Save to folder",
        icon: "save",
        submenu: b
      }, {
        label: "Add to group",
        icon: "folder",
        submenu: m
      }];
    h.groupId && $.push({
      label: "Remove from group",
      action: () => Fe.set_tab_group(h.id, null)
    }), $.push({
      separator: !0
    }, {
      label: "Close tab",
      icon: "x",
      danger: !0,
      action: () => o.onclose(E, h)
    }), ke(E, $)
  }

  function ve(E, h) {
    const m = D.map($ => ({
        label: $,
        swatch: $,
        action: () => Fe.recolor_group(h.id, $)
      })),
      b = [{
        label: h.collapsed ? "Expand" : "Collapse",
        icon: h.collapsed ? "chevron-down" : "chevron-up",
        action: () => Fe.toggle_group_collapsed(h.id)
      }, {
        label: "Rename…",
        icon: "pencil",
        action: () => $e(h.id, h.name)
      }, {
        label: "Recolor",
        icon: "palette",
        submenu: m
      }, {
        separator: !0
      }, {
        label: "Delete group",
        icon: "trash",
        danger: !0,
        action: () => Fe.delete_group(h.id)
      }];
    ke(E, b)
  }
  let ze, k, L, ae = !1,
    Me = C(!1);

  function Be() {
    !ze || !L || (L.style.width = ze.scrollWidth + "px", s(Me, ze.scrollWidth > ze.clientWidth))
  }
  Cr(() => {
    e(c).length, e(S).length, Be()
  }), Cr(() => (window.addEventListener("resize", Be), () => window.removeEventListener("resize", Be)));

  function Oe() {
    ae || (ae = !0, k.scrollLeft = ze.scrollLeft, ae = !1)
  }

  function G() {
    ae || (ae = !0, ze.scrollLeft = k.scrollLeft, ae = !1)
  }

  function de(E) {
    Math.abs(E.deltaY) <= Math.abs(E.deltaX) || (E.preventDefault(), ze.scrollLeft += E.deltaY)
  }
  let Se = C(null),
    Pe = C(!1),
    Ue = C(null),
    He = C(!0),
    We = !1,
    je = 0,
    N = null;

  function Ye(E, h) {
    E.button !== 0 || e(U) === h.id || (s(Se, h.id, !0), s(Pe, !1), je = E.clientX, N = E.currentTarget, N.setPointerCapture(E.pointerId), window.addEventListener("pointermove", rt), window.addEventListener("pointerup", qe), window.addEventListener("pointercancel", qe))
  }

  function rt(E) {
    if (e(Se)) {
      if (!e(Pe)) {
        if (Math.abs(E.clientX - je) < 6) return;
        s(Pe, !0), document.body.style.cursor = "grabbing", document.body.style.userSelect = "none"
      }
      pt(E.clientX)
    }
  }

  function pt(E) {
    const h = Array.from(document.querySelectorAll(".tab-pill"));
    s(Ue, null);
    for (const b of h) {
      const $ = b.getBoundingClientRect();
      if (E < $.left + $.width / 2) {
        const X = b.dataset.tabId ?? null;
        X && X !== e(Se) && (s(Ue, X, !0), s(He, !0));
        return
      }
    }
    const m = h[h.length - 1];
    if (m) {
      const b = m.dataset.tabId ?? null;
      b && b !== e(Se) && (s(Ue, b, !0), s(He, !1))
    }
  }

  function qe() {
    window.removeEventListener("pointermove", rt), window.removeEventListener("pointerup", qe), window.removeEventListener("pointercancel", qe), document.body.style.cursor = "", document.body.style.userSelect = "", e(Pe) && e(Se) && e(Ue) && (Fe.reorder_tab(e(Se), e(Ue), e(He)), We = !0), s(Se, null), s(Pe, !1), s(Ue, null)
  }
  var at = hc(),
    pe = Ge(at),
    p = r(pe),
    u = r(p);
  {
    var ge = E => {
      var h = gc(),
        m = r(h);
      {
        var b = T => {
          var M = fc();
          n(T, M)
        };
        f(m, T => {
          P() && T(b)
        })
      }
      var $ = a(m, 2);
      z($, {
        name: "house",
        size: 13,
        class: "shrink-0"
      });
      var X = a($, 4),
        ne = r(X);
      z(ne, {
        name: "x",
        size: 11
      }), t(X), t(h), y(() => {
        ut(h, "aria-selected", P()), me(h, 1, `group relative flex h-9 shrink-0 items-center gap-2 px-3 text-[12px] transition-colors cursor-pointer
                        ${P()?"text-text-primary":"text-text-muted hover:text-text-primary"}`), me(X, 1, `grid size-4 shrink-0 place-items-center rounded text-text-muted transition-[opacity,color] hover:text-text-primary ${e(c).length>0?"opacity-100":"opacity-0 pointer-events-none"} cursor-pointer`)
      }), d("click", h, () => {
        var T;
        return (T = o.onwelcome) == null ? void 0 : T.call(o)
      }), d("mousedown", h, T => {
        var M;
        T.button === 1 && (T.preventDefault(), (M = o.onclosewelcome) == null || M.call(o))
      }), d("keydown", h, T => {
        var M;
        (T.key === "Enter" || T.key === " ") && ((M = o.onwelcome) == null || M.call(o))
      }), d("click", X, T => {
        var M;
        T.stopPropagation(), (M = o.onclosewelcome) == null || M.call(o)
      }), n(E, h)
    };
    f(u, E => {
      w() && E(ge)
    })
  }
  var be = a(u, 2);
  Ze(be, 17, () => e(xe), E => E.id, (E, h) => {
    x(E, () => e(h), () => null)
  });
  var Le = a(be, 2);
  Ze(Le, 17, () => e(S), E => E.id, (E, h) => {
    var m = bc(),
      b = Ge(m);
    v(b, () => e(h));
    var $ = a(b, 2);
    {
      var X = T => {
          var M = wr(),
            q = Ge(M);
          Ze(q, 17, () => Q(e(h).id).filter(oe => oe.id === e(g)), oe => oe.id, (oe, j) => {
            x(oe, () => e(j), () => e(h).color)
          }), n(T, M)
        },
        ne = T => {
          var M = wr(),
            q = Ge(M);
          Ze(q, 17, () => Q(e(h).id), oe => oe.id, (oe, j) => {
            x(oe, () => e(j), () => e(h).color)
          }), n(T, M)
        };
      f($, T => {
        e(h).collapsed ? T(X) : T(ne, -1)
      })
    }
    n(E, m)
  }), t(p), ta(p, E => ze = E, () => ze);
  var H = a(p, 2);
  ct(H, {
    label: "New script",
    children: (E, h) => {
      var m = _c(),
        b = r(m);
      z(b, {
        name: "plus",
        size: 13
      }), t(m), d("click", m, function(...$) {
        var X;
        (X = o.onnew) == null || X.apply(this, $)
      }), n(E, m)
    },
    $$slots: {
      default: !0
    }
  });
  var Ee = a(H, 2),
    Te = r(Ee);
  ta(Te, E => L = E, () => L), t(Ee), ta(Ee, E => k = E, () => k), t(pe);
  var et = a(pe, 2);
  Ta(et, {
    get open() {
      return e(B)
    },
    get x() {
      return e(ye)
    },
    get y() {
      return e(we)
    },
    get items() {
      return e(ue)
    },
    onclose: () => s(B, !1)
  }), y(() => sr(Ee, `height:${e(Me)?"5px":"0px"};transition:height 0.15s`)), yr("wheel", p, de), yr("scroll", p, Oe), yr("scroll", Ee, G), n(l, at), Rt()
}
Yt(["pointerdown", "click", "keydown", "mousedown", "contextmenu", "dblclick"]);

function wc(l) {
  const o = l.key;
  if (["Control", "Shift", "Alt", "Meta"].includes(o)) return "";
  const x = [];
  return l.ctrlKey && x.push("Ctrl"), l.shiftKey && x.push("Shift"), l.altKey && x.push("Alt"), l.metaKey && x.push("Meta"), x.push(o === " " ? "Space" : o.length === 1 ? o.toUpperCase() : o), x.join("+")
}
var kc = i("<button><span></span> <!></button>"),
  $c = i('<button class="grid h-[50px] w-full place-items-center text-text-secondary opacity-55 hover:opacity-100 cursor-pointer transition-opacity duration-[140ms]" aria-label="Settings"><!></button>'),
  zc = i(`<button class="grid h-[50px] w-full place-items-center text-text-secondary opacity-55 hover:opacity-100 cursor-pointer transition-opacity duration-[140ms]" aria-label="Open Discord"><span class="size-[18px] bg-current [mask:url('/discord.svg')_center/contain_no-repeat]"></span></button>`),
  Sc = i('<button class="grid h-[50px] w-full place-items-center text-text-secondary opacity-55 hover:opacity-100 cursor-pointer transition-opacity duration-[140ms]" aria-label="Open YouTube"><!></button>'),
  Cc = i('<button aria-label="New script" class="grid size-6 place-items-center rounded text-text-muted transition-colors hover:text-text-primary cursor-pointer"><!></button>'),
  Pc = i('<button class="grid size-4 place-items-center rounded-full text-text-muted hover:text-text-primary cursor-pointer" aria-label="Clear search"><!></button>'),
  Lc = i('<aside><div role="separator" aria-label="Resize sidebar"></div> <div class="flex shrink-0 flex-col gap-2 pl-4 pr-2 pt-2.5 pb-2"><div class="flex h-8 items-center justify-between gap-2"><span class="text-[17px] font-bold leading-none tracking-[-0.02em] text-text-primary">Explorer</span> <div class="flex items-center gap-1"><!></div></div> <div class="mr-1 flex h-[34px] items-center gap-2 rounded-[10px] bg-bg-elevated px-3 transition-[background-color] focus-within:bg-bg-active/70"><!> <input placeholder="Search files..." class="min-w-0 flex-1 bg-transparent text-[12.5px] text-text-primary placeholder:text-text-muted focus:outline-none"/> <!></div></div> <div class="flex min-h-0 flex-1 flex-col overflow-y-auto pb-2"><!> <!> <!> <!></div></aside>'),
  Ec = i('<button aria-label="Open file" class="grid size-7 place-items-center rounded text-text-muted transition-colors duration-[120ms] hover:text-text-primary cursor-pointer"><!></button>'),
  Ac = i('<button aria-label="Save" class="grid size-7 place-items-center rounded text-text-muted transition-colors duration-[120ms] hover:text-text-primary cursor-pointer disabled:pointer-events-none disabled:opacity-40"><!></button>'),
  Mc = i('<button aria-label="Find" class="grid size-7 place-items-center rounded text-text-muted transition-colors duration-[120ms] hover:text-text-primary cursor-pointer disabled:pointer-events-none disabled:opacity-40"><!></button>'),
  Dc = i('<button aria-label="Clear editor" class="grid size-7 place-items-center rounded text-text-muted transition-colors duration-[120ms] hover:text-text-primary cursor-pointer disabled:pointer-events-none disabled:opacity-40"><!></button>'),
  Rc = i('<button aria-label="Console"><!></button>'),
  Ic = i('<button aria-label="Clients"><!></button>'),
  Nc = i(`<button class="flex h-7 items-center gap-1.5 rounded-md px-2 text-[12px] font-medium text-text-secondary
								ring-1 ring-inset ring-line transition-colors duration-[120ms] cursor-pointer
								hover:text-text-primary disabled:pointer-events-none disabled:opacity-50"><!> Launch</button>`),
  Tc = wn('<svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M5 4.5a1 1 0 0 1 1.5-.866l13 7.5a1 1 0 0 1 0 1.732l-13 7.5A1 1 0 0 1 5 19.5z"></path></svg>'),
  jc = i('<div class="editor-welcome-layer absolute inset-0 z-10 bg-bg-base"><!></div>'),
  Fc = i('<span class="text-[11px] text-text-muted tabular-nums"> </span>'),
  Oc = i('<button aria-label="Filter level"><!></button>'),
  Uc = i("<button> </button>"),
  Bc = i('<div class="absolute right-0 top-full z-50 mt-1 min-w-28 rounded-md bg-bg-elevated ring-1 ring-inset ring-line p-1 shadow-(--shadow-medium)"></div>'),
  Wc = i('<button aria-label="Toggle auto-scroll"><!></button>'),
  Vc = i('<button aria-label="Copy console output" class="grid size-6 place-items-center rounded text-text-muted hover:text-text-primary cursor-pointer transition-colors disabled:pointer-events-none disabled:opacity-40"><!></button>'),
  Hc = i('<button aria-label="Clear console" class="grid size-6 place-items-center rounded text-text-muted hover:text-text-primary cursor-pointer transition-colors"><!></button>'),
  qc = i('<button aria-label="Hide console" class="grid size-6 place-items-center rounded text-text-muted hover:text-text-primary cursor-pointer transition-colors"><!></button>'),
  Kc = i('<div class="flex h-full flex-col items-center justify-center text-center"><div class="text-[12px] text-text-muted"> </div> <div class="mt-1 text-[11px] text-text-muted/60">Redirected print, warn and runtime errors will appear here.</div></div>'),
  Gc = i(" <!>", 1),
  Yc = i('<div><span class="shrink-0 select-none text-text-muted/60 tabular-nums"> </span> <span><!></span> <span> <!></span> <button aria-label="Copy line" class="mt-[2px] grid size-[15px] shrink-0 place-items-center rounded text-text-muted opacity-0 transition-opacity hover:text-text-primary cursor-pointer group-hover/line:opacity-100"><!></button></div>'),
  Xc = i('<div class="flex shrink-0 flex-col overflow-hidden border-t border-line bg-bg-base"><div class="h-[3px] w-full shrink-0 cursor-ns-resize hover:bg-text-primary/8 active:bg-text-primary/16 transition-colors" role="separator" aria-label="Resize console"></div> <div class="flex h-9 shrink-0 items-center gap-3 border-b border-line px-3"><span class="text-[10.5px] font-semibold uppercase tracking-[0.1em] text-text-muted">Console</span> <!> <div class="flex-1"></div> <div class="flex h-6 items-center gap-1.5 rounded bg-bg-elevated px-2 ring-1 ring-inset ring-line/60 focus-within:ring-text-primary/25 transition-[box-shadow]"><!> <input placeholder="Search…" class="w-28 min-w-0 bg-transparent text-[11px] text-text-primary placeholder:text-text-muted focus:outline-none"/></div> <div class="relative"><!> <!></div> <!> <!> <!> <!></div> <div class="min-h-0 flex-1 select-text overflow-y-auto px-3 py-2 font-mono text-[12px] leading-[1.65]"><!></div></div>'),
  Jc = i('<div class="min-h-0 flex-1 overflow-hidden"><!></div>'),
  Qc = i('<button type="button" class="absolute inset-0 z-[24] backdrop-blur-sm bg-black/10 cursor-default" aria-label="Close clients panel"></button> <div class="absolute right-0 inset-y-0 z-[25] flex w-[300px] flex-col overflow-hidden border-l border-line bg-bg-surface"><!></div>', 1),
  Zc = i('<div class="absolute inset-0 z-30 bg-bg-base" style="overflow:hidden;contain:paint;"><!></div>'),
  ed = i('<span>Luau</span> <span class="text-line">·</span> <span>UTF-8</span> <span class="text-line">·</span> <span>Spaces: 4</span>', 1),
  td = i('<div class="flex flex-col gap-4"><div class="flex flex-col gap-1"><span class="text-[14px] font-semibold text-text-primary">Close tab?</span> <span class="text-[13px] text-text-muted"> </span></div> <div class="flex justify-end gap-2"><button class="h-8 rounded-md px-3 text-[13px] text-text-muted hover:text-text-primary transition-colors cursor-pointer">Cancel</button> <button class="h-8 rounded-md bg-text-primary px-3.5 text-[13px] font-medium text-bg-base hover:brightness-95 transition-[filter] cursor-pointer">Close</button></div></div>'),
  rd = i(`<main class="app-shell absolute inset-0 z-10 flex flex-col overflow-hidden bg-bg-base text-text-primary"><header data-tauri-drag-region="" role="presentation" class="app-titlebar relative flex h-9 shrink-0 items-center border-b border-line bg-bg-base pr-0"><div data-tauri-drag-region="" class="flex w-[60px] shrink-0 items-center justify-center text-text-primary"><!></div> <div data-tauri-drag-region="" class="titlebar-drag-region pointer-events-none absolute inset-x-0 flex justify-center"><span class="text-[12px] font-medium text-text-muted">constraintt.ez</span></div> <div data-tauri-drag-region="" class="titlebar-drag-region flex-1 self-stretch"></div> <!></header> <div class="workbench-shell relative flex min-h-0 flex-1 bg-bg-base"><div><aside class="flex w-[60px] shrink-0 flex-col items-stretch border-r border-line bg-bg-base"><nav class="flex flex-col"></nav> <div class="mt-auto flex flex-col"><!> <!> <!></div></aside> <div><!> <section class="flex min-w-0 flex-1 flex-col bg-bg-base"><div><!> <div class="flex h-11 shrink-0 items-center gap-0.5 border-b border-line bg-bg-base px-3"><!> <!> <div class="mx-1.5 h-4 w-px bg-line"></div> <!> <!> <div class="flex-1"></div> <!> <!> <div class="mx-1.5 h-4 w-px bg-line"></div> <button><span></span> </button> <!> <div class="mx-1 h-4 w-px bg-line"></div> <button class="flex h-7 items-center gap-1.5 rounded-md bg-text-primary pl-2 pr-2.5 text-[12px] font-medium text-bg-base
							transition-[filter,opacity] duration-[120ms] ease-out cursor-pointer
							hover:brightness-95 active:brightness-90
							disabled:pointer-events-none disabled:opacity-50"><!> Run</button></div> <div class="editor-stage relative flex min-h-0 flex-1 flex-col overflow-hidden"><div class="editor-bg"></div> <div class="relative min-h-0 flex-1 overflow-hidden"><div><!></div> <!></div></div> <!></div> <!></section></div></div> <!> <!></div> <footer class="flex h-[22px] shrink-0 items-center gap-3 border-t border-line bg-bg-base px-3 text-[11px] text-text-muted"><div class="flex-1"></div> <!></footer> <!> <!></main>`);

function od(l, o) {
  Dt(o, !0);
  const x = () => $t(O, "$roblox_instances", c),
    v = () => $t(tr, "$current_page", c),
    w = () => $t(ca, "$console_open", c),
    P = () => $t(We, "$launching", c),
    [c, g] = Br(),
    S = ri(),
    O = Xt.instances;
  let D = C(Nt([])),
    K = C(null),
    xe = C(!0),
    Q = C(!0);
  const B = A(() => e(xe) && e(Q));
  let ye = C(""),
    we = C(null),
    ue = C(null),
    ke = C(!0),
    U = C(!0),
    W = C(!0),
    le = C(!0),
    ee = C(!0),
    fe = C(!0),
    ie = C("right"),
    $e = C(224),
    Z = C(192);

  function Y(_) {
    _.preventDefault();
    const se = _.clientY,
      F = e(Z);

    function Ne(Xe) {
      const ht = se - Xe.clientY;
      s(Z, Math.max(80, Math.min(600, F + ht)), !0)
    }

    function ce() {
      window.removeEventListener("mousemove", Ne), window.removeEventListener("mouseup", ce)
    }
    window.addEventListener("mousemove", Ne), window.addEventListener("mouseup", ce)
  }

  function re(_) {
    _.preventDefault();
    const se = _.clientX,
      F = e($e);

    function Ne(Xe) {
      const ht = e(ie) === "right" ? se - Xe.clientX : Xe.clientX - se,
        Zt = Math.max(140, Math.min(480, F + ht));
      s($e, Zt, !0)
    }

    function ce() {
      cr.set_value("workbench.sidebar_width", e($e)), window.removeEventListener("mousemove", Ne), window.removeEventListener("mouseup", ce)
    }
    window.addEventListener("mousemove", Ne), window.addEventListener("mouseup", ce)
  }
  let J = C(Nt({})),
    ve = C(!1),
    ze = C(!0),
    k = C(Nt([])),
    L = C(""),
    ae = C(!0),
    Me = C(null),
    Be = C("all"),
    Oe = C(!1);
  Tr(() => {
    const _ = Fe.subscribe(ce => {
      s(D, ce.files, !0), s(K, ce.active, !0)
    });
    let se = 0;
    const F = Ka.subscribe(ce => {
        const Xe = ce.length > se;
        se = ce.length, s(k, ce, !0), e(ze) && Xe && ca.set(!0)
      }),
      Ne = cr.subscribe(ce => {
        s(J, ce ?? {}, !0), s(ke, (ce == null ? void 0 : ce["editor.confirm_close"]) !== !1), s(U, (ce == null ? void 0 : ce["window.show_explorer"]) !== !1), s(W, (ce == null ? void 0 : ce["explorer.show_library"]) !== !1), s(le, (ce == null ? void 0 : ce["explorer.show_scripts"]) !== !1), s(ee, (ce == null ? void 0 : ce["explorer.show_workspace"]) !== !1), s(fe, (ce == null ? void 0 : ce["explorer.show_autoexec"]) !== !1), s(ie, (ce == null ? void 0 : ce["workbench.sidebar_position"]) ?? "right", !0), s($e, Number((ce == null ? void 0 : ce["workbench.sidebar_width"]) ?? 224), !0), s(ze, (ce == null ? void 0 : ce["console.auto_open"]) !== !1)
      });
    return Fe.on_close_request(ce => {
      const Xe = e(D).find(ht => ht.id === ce);
      Xe && u(Xe)
    }), window.addEventListener("keydown", de), Xt.init_events(), () => {
      _(), F(), Ne(), window.removeEventListener("keydown", de), Xt.dispose()
    }
  });
  const G = [{
    key: "keybind.execute",
    run: () => m()
  }, {
    key: "keybind.new_script",
    run: () => et()
  }, {
    key: "keybind.open_file",
    run: () => E()
  }, {
    key: "keybind.save",
    run: () => b()
  }, {
    key: "keybind.save_as",
    run: () => Fe.save_file_as()
  }, {
    key: "keybind.close_tab",
    run: () => {
      const _ = Fe.get_active_file();
      _ && u(_)
    }
  }, {
    key: "keybind.next_tab",
    run: () => Fe.cycle_tab(1)
  }, {
    key: "keybind.find",
    run: () => Fe.toggle_find()
  }, {
    key: "keybind.toggle_console",
    run: () => ca.update(_ => !_)
  }, {
    key: "keybind.open_settings",
    run: () => tr.goto("settings")
  }];

  function de(_) {
    const se = wc(_);
    if (se) {
      for (const F of G)
        if (e(J)[F.key] === se) {
          _.preventDefault(), F.run();
          return
        }
    }
  }
  const Se = A(() => e(D).find(_ => _.id === e(K)) ?? null),
    Pe = A(() => e(Q) || e(D).length === 0),
    Ue = A(() => x().length),
    He = A(() => x().filter(_ => _.attached).length),
    We = $a.launching,
    je = A(() => e(Ue) === 0 ? "No client" : e(He) === 0 ? e(Ue) === 1 ? "1 client · attaching" : `${e(Ue)} clients · attaching` : e(He) === 1 ? "1 attached" : `${e(He)} attached`),
    N = [{
      page: "editor",
      icon: "file-code",
      label: "Editor"
    }, {
      page: "script_hub",
      icon: "cloud",
      label: "Hub"
    }, {
      page: "versions",
      icon: "download",
      label: "Versions"
    }];
  let Ye = C(!1);
  Cr(() => {
    v() !== "editor" && s(Ye, !1)
  });
  const rt = {
    editor: "Editor",
    clients: "Clients",
    script_hub: "Hub",
    versions: "Versions",
    settings: "Settings"
  };
  let pt = C("editor");
  Cr(() => {
    v() !== "settings" && s(pt, v(), !0)
  });

  function qe() {
    requestAnimationFrame(() => {
      Fe.force_layout(), requestAnimationFrame(() => {
        Fe.force_layout(), Fe.focus()
      })
    })
  }
  const at = A(() => `${e(D).map(_=>_.id).join("|")}::${e(K)??""}`);
  Cr(() => {
    e(at), v() === "editor" && qe()
  });
  async function pe() {
    await S.isMaximized() ? await S.unmaximize() : await S.maximize()
  }

  function p(_) {
    const se = _.target;
    se instanceof HTMLElement && (se.closest("button, input, textarea, select, a, [role='tab']") || S.startDragging())
  }

  function u(_) {
    e(ke) ? (s(ue, _, !0), s(we, _, !0)) : Fe.close_file(_.id)
  }

  function ge(_, se) {
    _.stopPropagation(), u(se)
  }

  function be() {
    const _ = e(we);
    s(we, null), _ && Fe.close_file(_.id)
  }

  function Le() {
    s(we, null)
  }

  function H(_) {
    s(Q, !1), Fe.switch_to(_.id), tr.goto("editor")
  }

  function Ee() {
    s(xe, !0), s(Q, !0), tr.goto("editor")
  }

  function Te() {
    if (e(D).length === 0) return;
    s(xe, !1), s(Q, !1);
    const _ = e(D).find(se => se.id === e(K)) ?? e(D)[0];
    _ && Fe.switch_to(_.id), tr.goto("editor")
  }
  Cr(() => {
    e(D).length === 0 && (s(xe, !0), s(Q, !0))
  });
  async function et() {
    s(Q, !1), await Fe.create_file(), tr.goto("editor"), qe()
  }
  async function E() {
    s(Q, !1), await Fe.open_file_dialog(), tr.goto("editor")
  }
  async function h(_) {
    s(Q, !1), await Fe.create_file_with_content(_.name, _.content), tr.goto("editor")
  }
  async function m() {
    if (e(ve)) return;
    const _ = Fe.get_active_file();
    if (!_) {
      gt.warning("Open a script before executing");
      return
    }
    const se = [...Ra(Xt.executeTargets)],
      F = Ra(Xt.instances).map(Xe => Xe.pid),
      Ne = se.length > 0 ? se : F;
    if (Ne.length === 0) {
      gt.warning("No Roblox client is running", {
        message: "Launch Roblox first."
      });
      return
    }
    s(ve, !0), tr.goto("editor");
    const ce = Fe.get_active_content();
    vn.add({
      name: _.name,
      content: ce
    });
    try {
      await Promise.all(Ne.map(Xe => Xt.execute(Xe, ce)))
    } catch (Xe) {
      gt.error("Execution failed", {
        message: String(Xe)
      })
    } finally {
      s(ve, !1)
    }
  }
  async function b() {
    try {
      await Fe.save_file()
    } catch (_) {
      gt.error("Couldn't save file", {
        message: String(_)
      })
    }
  }

  function $() {
    Ka.clear(), ca.set(!0)
  }

  function X(_) {
    const se = _.data === void 0 ? "" : ` ${JSON.stringify(_.data,null,2)}`;
    return `[${_.time}] ${_.message}${se}`
  }
  async function ne(_, se) {
    if (_) try {
      await navigator.clipboard.writeText(_), gt.success(se)
    } catch {
      const F = document.createElement("textarea");
      F.value = _, F.style.position = "fixed", F.style.opacity = "0", document.body.appendChild(F), F.select();
      const Ne = document.execCommand("copy");
      F.remove(), Ne ? gt.success(se) : gt.error("Couldn't copy to the clipboard")
    }
  }
  const T = _ => ne(X(_), "Line copied"),
    M = () => ne(e(V).map(X).join(`
`), "Console output copied");
  async function q(_) {
    try {
      await pa(`discord://-/invite/${_}`)
    } catch {
      await pa(`https://discord.gg/${_}`)
    }
  }
  const oe = {
      log: {
        text: "text-text-primary",
        row: "",
        icon: null
      },
      info: {
        text: "text-info",
        row: "",
        icon: "info"
      },
      warn: {
        text: "text-warning",
        row: "bg-warning-soft",
        icon: "alert-triangle"
      },
      error: {
        text: "text-danger",
        row: "bg-danger-soft",
        icon: "x-circle"
      }
    },
    j = [{
      value: "all",
      label: "All"
    }, {
      value: "log",
      label: "Log"
    }, {
      value: "info",
      label: "Info"
    }, {
      value: "warn",
      label: "Warning"
    }, {
      value: "error",
      label: "Error"
    }];
  Cr(() => {
    e(k).length, !(!e(ae) || !e(Me)) && requestAnimationFrame(() => {
      e(Me) && (e(Me).scrollTop = e(Me).scrollHeight)
    })
  });
  const V = A(() => e(k).filter(_ => !(e(Be) !== "all" && _.level !== e(Be) || e(L) && !_.message.toLowerCase().includes(e(L).toLowerCase()))));
  var De = rd(),
    tt = r(De),
    Qe = r(tt),
    R = r(Qe);
  xn(R, {
    size: 20
  }), t(Qe);
  var _e = a(Qe, 6);
  ai(_e, {}), t(tt);
  var te = a(tt, 2),
    he = r(te);
  let Re;
  var lt = r(he),
    dt = r(lt);
  Ze(dt, 21, () => N, _ => _.page, (_, se) => {
    ct(_, {
      get label() {
        return e(se).label
      },
      side: "right",
      children: (F, Ne) => {
        var ce = kc(),
          Xe = r(ce),
          ht = a(Xe, 2);
        z(ht, {
          get name() {
            return e(se).icon
          },
          size: 19
        }), t(ce), y(() => {
          me(ce, 1, `group relative grid h-[50px] w-full place-items-center cursor-pointer
							transition-[color,opacity] duration-[140ms] ease-out
							${v()===e(se).page?"text-text-primary opacity-100":"text-text-secondary opacity-55 hover:opacity-100"}`), ut(ce, "aria-label", e(se).label), me(Xe, 1, `pointer-events-none absolute left-0 top-1/2 -translate-y-1/2 w-[2px] rounded-r-full bg-text-primary
								transition-[transform,opacity] duration-[180ms] ease-out
								${v()===e(se).page?"h-6 opacity-100 scale-y-100":"h-4 opacity-0 scale-y-50 group-hover:opacity-40 group-hover:scale-y-75"}`)
        }), d("click", ce, () => tr.goto(e(se).page)), n(F, ce)
      },
      $$slots: {
        default: !0
      }
    })
  }), t(dt);
  var Tt = a(dt, 2),
    Ft = r(Tt);
  ct(Ft, {
    label: "Settings",
    side: "right",
    children: (_, se) => {
      var F = $c(),
        Ne = r(F);
      z(Ne, {
        name: "settings",
        size: 18
      }), t(F), d("click", F, () => tr.goto("settings")), n(_, F)
    },
    $$slots: {
      default: !0
    }
  });
  var jt = a(Ft, 2);
  ct(jt, {
    label: "Discord",
    side: "right",
    children: (_, se) => {
      var F = zc();
      d("click", F, () => q("olemad")), n(_, F)
    },
    $$slots: {
      default: !0
    }
  });
  var _t = a(jt, 2);
  ct(_t, {
    label: "YouTube",
    side: "right",
    children: (_, se) => {
      var F = Sc(),
        Ne = r(F);
      z(Ne, {
        name: "youtube",
        size: 18
      }), t(F), d("click", F, () => pa("https://www.youtube.com/@constraintt.ezGG")), n(_, F)
    },
    $$slots: {
      default: !0
    }
  }), t(Tt), t(lt);
  var bt = a(lt, 2);
  let It;
  var Ke = r(bt);
  {
    var Mt = _ => {
      var se = Lc(),
        F = r(se),
        Ne = a(F, 2),
        ce = r(Ne),
        Xe = a(r(ce), 2),
        ht = r(Xe);
      ct(ht, {
        label: "New script",
        children: (mt, jr) => {
          var Dr = Cc(),
            ma = r(Dr);
          z(ma, {
            name: "plus",
            size: 14
          }), t(Dr), d("click", Dr, et), n(mt, Dr)
        },
        $$slots: {
          default: !0
        }
      }), t(Xe), t(ce);
      var Zt = a(ce, 2),
        Kt = r(Zt);
      z(Kt, {
        name: "search",
        size: 12,
        class: "shrink-0 text-text-muted"
      });
      var hr = a(Kt, 2);
      ur(hr);
      var mr = a(hr, 2);
      {
        var Ar = mt => {
          var jr = Pc(),
            Dr = r(jr);
          z(Dr, {
            name: "x",
            size: 10
          }), t(jr), d("click", jr, () => s(ye, "")), n(mt, jr)
        };
        f(mr, mt => {
          e(ye) && mt(Ar)
        })
      }
      t(Zt), t(Ne);
      var Mr = a(Ne, 2),
        Vr = r(Mr);
      {
        var aa = mt => {
          _i(mt, {
            get filter() {
              return e(ye)
            }
          })
        };
        f(Vr, mt => {
          e(W) && mt(aa)
        })
      }
      var na = a(Vr, 2);
      {
        var Yr = mt => {
          Ma(mt, {
            dir: "Scripts",
            label: "Scripts",
            icon: "lua",
            get filter() {
              return e(ye)
            }
          })
        };
        f(na, mt => {
          e(le) && mt(Yr)
        })
      }
      var Hr = a(na, 2);
      {
        var ia = mt => {
          Ma(mt, {
            dir: "Workspace",
            label: "Workspace",
            icon: "box",
            get filter() {
              return e(ye)
            }
          })
        };
        f(Hr, mt => {
          e(ee) && mt(ia)
        })
      }
      var sa = a(Hr, 2);
      {
        var oa = mt => {
          Ma(mt, {
            dir: "AutoExecute",
            label: "Auto Execute",
            icon: "rotate-cw",
            get filter() {
              return e(ye)
            }
          })
        };
        f(sa, mt => {
          e(fe) && mt(oa)
        })
      }
      t(Mr), t(se), y(() => {
        me(se, 1, `relative flex shrink-0 flex-col bg-bg-base ${e(ie)==="right"?"border-l":"border-r"} border-line`), sr(se, `width:${e($e)??""}px`), me(F, 1, `absolute inset-y-0 z-10 w-1 cursor-col-resize hover:bg-text-primary/10 active:bg-text-primary/20 transition-colors ${e(ie)==="right"?"left-0":"right-0"}`)
      }), d("mousedown", F, re), Or(hr, () => e(ye), mt => s(ye, mt)), n(_, se)
    };
    f(Ke, _ => {
      v() === "editor" && e(U) && _(Mt)
    })
  }
  var Ot = a(Ke, 2),
    Ut = r(Ot),
    ar = r(Ut);
  yc(ar, {
    onswitch: H,
    onclose: ge,
    onnew: et,
    get welcome() {
      return e(xe)
    },
    get welcomeActive() {
      return e(B)
    },
    onwelcome: Ee,
    onclosewelcome: Te
  });
  var zt = a(ar, 2),
    Jt = r(zt);
  ct(Jt, {
    label: "Open file",
    children: (_, se) => {
      var F = Ec(),
        Ne = r(F);
      z(Ne, {
        name: "folder-open",
        size: 14
      }), t(F), d("click", F, E), n(_, F)
    },
    $$slots: {
      default: !0
    }
  });
  var or = a(Jt, 2);
  ct(or, {
    label: "Save",
    children: (_, se) => {
      var F = Ac(),
        Ne = r(F);
      z(Ne, {
        name: "save",
        size: 14
      }), t(F), y(() => F.disabled = e(Pe)), d("click", F, b), n(_, F)
    },
    $$slots: {
      default: !0
    }
  });
  var yt = a(or, 4);
  ct(yt, {
    label: "Find",
    children: (_, se) => {
      var F = Mc(),
        Ne = r(F);
      z(Ne, {
        name: "search",
        size: 14
      }), t(F), y(() => F.disabled = e(Pe)), d("click", F, () => Fe.toggle_find()), n(_, F)
    },
    $$slots: {
      default: !0
    }
  });
  var Bt = a(yt, 2);
  ct(Bt, {
    label: "Clear editor",
    children: (_, se) => {
      var F = Dc(),
        Ne = r(F);
      z(Ne, {
        name: "trash",
        size: 14
      }), t(F), y(() => F.disabled = e(Pe)), d("click", F, () => Fe.clear_content()), n(_, F)
    },
    $$slots: {
      default: !0
    }
  });
  var fr = a(Bt, 4);
  ct(fr, {
    label: "Console",
    children: (_, se) => {
      var F = Rc(),
        Ne = r(F);
      z(Ne, {
        name: "terminal",
        size: 14
      }), t(F), y(() => {
        F.disabled = e(Pe), me(F, 1, `grid size-7 place-items-center rounded transition-colors duration-[120ms] cursor-pointer disabled:pointer-events-none disabled:opacity-40 ${w()?"text-text-primary":"text-text-muted hover:text-text-primary"}`)
      }), d("click", F, () => ca.set(!w())), n(_, F)
    },
    $$slots: {
      default: !0
    }
  });
  var Wt = a(fr, 2);
  ct(Wt, {
    label: "Clients",
    children: (_, se) => {
      var F = Ic(),
        Ne = r(F);
      z(Ne, {
        name: "roblox",
        size: 15
      }), t(F), y(() => me(F, 1, `grid size-7 place-items-center rounded transition-colors duration-[120ms] cursor-pointer ${e(Ye)?"text-text-primary":"text-text-muted hover:text-text-primary"}`)), d("click", F, () => s(Ye, !e(Ye))), n(_, F)
    },
    $$slots: {
      default: !0
    }
  });
  var nr = a(Wt, 4),
    gr = r(nr),
    pr = a(gr);
  t(nr);
  var br = a(nr, 2);
  ct(br, {
    label: "Launch a constraintt.ez-patched Roblox",
    children: (_, se) => {
      var F = Nc(),
        Ne = r(F);
      {
        var ce = ht => {
            Gt(ht, {
              size: 11
            })
          },
          Xe = ht => {
            z(ht, {
              name: "rocket",
              size: 11
            })
          };
        f(Ne, ht => {
          P() ? ht(ce) : ht(Xe, -1)
        })
      }
      Ae(), t(F), y(() => F.disabled = P()), d("click", F, () => $a.launch()), n(_, F)
    },
    $$slots: {
      default: !0
    }
  });
  var vr = a(br, 4),
    kr = r(vr);
  {
    var xr = _ => {
        Gt(_, {
          size: 12
        })
      },
      nt = _ => {
        var se = Tc();
        n(_, se)
      };
    f(kr, _ => {
      e(ve) ? _(xr) : _(nt, -1)
    })
  }
  Ae(), t(vr), t(zt);
  var vt = a(zt, 2),
    _r = a(r(vt), 2),
    Vt = r(_r);
  let Lr;
  var Ce = r(Vt);
  yi(Ce, {}), t(Vt);
  var Ie = a(Vt, 2);
  {
    var xt = _ => {
      var se = jc(),
        F = r(se);
      Ql(F, {
        onnew: et,
        onopen: E,
        onhub: () => tr.goto("script_hub"),
        onopenrecent: h,
        onsettings: () => tr.goto("settings")
      }), t(se), n(_, se)
    };
    f(Ie, _ => {
      e(B) && _(xt)
    })
  }
  t(_r), t(vt);
  var Ct = a(vt, 2);
  {
    var Ht = _ => {
      var se = wr(),
        F = Ge(se);
      {
        var Ne = ce => {
          var Xe = Xc(),
            ht = r(Xe),
            Zt = a(ht, 2),
            Kt = a(r(Zt), 2);
          {
            var hr = ft => {
              var Et = Fc(),
                it = r(Et, !0);
              t(Et), y(() => I(it, e(k).length)), n(ft, Et)
            };
            f(Kt, ft => {
              e(k).length > 0 && ft(hr)
            })
          }
          var mr = a(Kt, 4),
            Ar = r(mr);
          z(Ar, {
            name: "search",
            size: 11,
            class: "shrink-0 text-text-muted"
          });
          var Mr = a(Ar, 2);
          ur(Mr), t(mr);
          var Vr = a(mr, 2),
            aa = r(Vr);
          ct(aa, {
            label: "Filter level",
            children: (ft, Et) => {
              var it = Oc(),
                wt = r(it);
              z(wt, {
                name: "filter",
                size: 12
              }), t(it), y(() => me(it, 1, `grid size-6 place-items-center rounded transition-colors cursor-pointer ${e(Be)==="all"?"text-text-muted hover:text-text-primary":"text-text-primary"}`)), d("click", it, () => s(Oe, !e(Oe))), n(ft, it)
            },
            $$slots: {
              default: !0
            }
          });
          var na = a(aa, 2);
          {
            var Yr = ft => {
              var Et = Bc();
              Ze(Et, 21, () => j, it => it.value, (it, wt) => {
                var er = Uc(),
                  Fr = r(er, !0);
                t(er), y(() => {
                  me(er, 1, `flex w-full items-center rounded px-2 py-1 text-left text-[12px] cursor-pointer ${e(Be)===e(wt).value?"text-text-primary":"text-text-muted hover:text-text-primary"}`), I(Fr, e(wt).label)
                }), d("click", er, () => {
                  s(Be, e(wt).value, !0), s(Oe, !1)
                }), n(it, er)
              }), t(Et), n(ft, Et)
            };
            f(na, ft => {
              e(Oe) && ft(Yr)
            })
          }
          t(Vr);
          var Hr = a(Vr, 2);
          {
            let ft = A(() => e(ae) ? "Auto-scroll on" : "Auto-scroll off");
            ct(Hr, {
              get label() {
                return e(ft)
              },
              children: (Et, it) => {
                var wt = Wc(),
                  er = r(wt);
                z(er, {
                  name: "arrow-down",
                  size: 12
                }), t(wt), y(() => {
                  ut(wt, "aria-pressed", e(ae)), me(wt, 1, `grid size-6 place-items-center rounded transition-colors cursor-pointer ${e(ae)?"text-text-primary":"text-text-muted hover:text-text-primary"}`)
                }), d("click", wt, () => s(ae, !e(ae))), n(Et, wt)
              },
              $$slots: {
                default: !0
              }
            })
          }
          var ia = a(Hr, 2);
          ct(ia, {
            label: "Copy output",
            children: (ft, Et) => {
              var it = Vc(),
                wt = r(it);
              z(wt, {
                name: "copy",
                size: 12
              }), t(it), y(() => it.disabled = e(V).length === 0), d("click", it, M), n(ft, it)
            },
            $$slots: {
              default: !0
            }
          });
          var sa = a(ia, 2);
          ct(sa, {
            label: "Clear console",
            children: (ft, Et) => {
              var it = Hc(),
                wt = r(it);
              z(wt, {
                name: "trash",
                size: 12
              }), t(it), d("click", it, $), n(ft, it)
            },
            $$slots: {
              default: !0
            }
          });
          var oa = a(sa, 2);
          ct(oa, {
            label: "Hide console",
            children: (ft, Et) => {
              var it = qc(),
                wt = r(it);
              z(wt, {
                name: "x",
                size: 12
              }), t(it), d("click", it, () => ca.set(!1)), n(ft, it)
            },
            $$slots: {
              default: !0
            }
          }), t(Zt);
          var mt = a(Zt, 2),
            jr = r(mt);
          {
            var Dr = ft => {
                var Et = Kc(),
                  it = r(Et),
                  wt = r(it, !0);
                t(it), Ae(2), t(Et), y(() => I(wt, e(k).length === 0 ? "No console output yet" : "No matching output")), n(ft, Et)
              },
              ma = ft => {
                var Et = wr(),
                  it = Ge(Et);
                Ze(it, 17, () => e(V), wt => wt.id, (wt, er) => {
                  const Fr = A(() => oe[e(er).level]);
                  var la = Yc(),
                    Ve = r(la),
                    st = r(Ve, !0);
                  t(Ve);
                  var At = a(Ve, 2),
                    rr = r(At);
                  {
                    var ir = Qr => {
                      z(Qr, {
                        get name() {
                          return e(Fr).icon
                        },
                        size: 12
                      })
                    };
                    f(rr, Qr => {
                      e(Fr).icon && Qr(ir)
                    })
                  }
                  t(At);
                  var Rr = a(At, 2),
                    _a = r(Rr, !0),
                    qr = a(_a);
                  {
                    var Xr = Qr => {
                      var Fa = Gc(),
                        Oa = Ge(Fa, !0);
                      Oa.nodeValue = " ";
                      var yn = a(Oa);
                      _n(yn, {
                        get value() {
                          return e(er).data
                        }
                      }), n(Qr, Fa)
                    };
                    f(qr, Qr => {
                      e(er).data !== void 0 && Qr(Xr)
                    })
                  }
                  t(Rr);
                  var Jr = a(Rr, 2),
                    hn = r(Jr);
                  z(hn, {
                    name: "copy",
                    size: 11
                  }), t(Jr), t(la), y(() => {
                    me(la, 1, `group/line -mx-1.5 flex items-start gap-2 rounded-[3px] px-1.5 py-px ${e(Fr).row??""}`), I(st, e(er).time), me(At, 1, `mt-[3px] grid size-[13px] shrink-0 place-items-center ${e(Fr).text??""}`), me(Rr, 1, `min-w-0 flex-1 whitespace-pre-wrap break-words ${e(Fr).text??""}`), I(_a, e(er).message)
                  }), d("click", Jr, () => T(e(er))), n(wt, la)
                }), n(ft, Et)
              };
            f(jr, ft => {
              e(V).length === 0 ? ft(Dr) : ft(ma, -1)
            })
          }
          t(mt), ta(mt, ft => s(Me, ft), () => e(Me)), t(Xe), y(() => sr(Xe, `height:${e(Z)??""}px`)), d("mousedown", ht, Y), Or(Mr, () => e(L), ft => s(L, ft)), Ir(3, Xe, () => mn), n(ce, Xe)
        };
        f(F, ce => {
          w() && ce(Ne)
        })
      }
      n(_, se)
    };
    f(Ct, _ => {
      e(D).length > 0 && !e(B) && _(Ht)
    })
  }
  t(Ut), ba(Ut, (_, se) => {
    var F;
    return (F = Aa) == null ? void 0 : F(_, se)
  }, () => v() === "editor");
  var kt = a(Ut, 2);
  {
    var $r = _ => {
      var se = wr(),
        F = Ge(se);
      fn(F, v, Ne => {
        var ce = Jc(),
          Xe = r(ce);
        {
          var ht = Kt => {
              To(Kt, {})
            },
            Zt = Kt => {
              Wl(Kt, {})
            };
          f(Xe, Kt => {
            v() === "script_hub" ? Kt(ht) : v() === "versions" && Kt(Zt, 1)
          })
        }
        t(ce), ba(ce, (Kt, hr) => {
          var mr;
          return (mr = Aa) == null ? void 0 : mr(Kt, hr)
        }, () => !0), n(Ne, ce)
      }), n(_, se)
    };
    f(kt, _ => {
      v() !== "editor" && v() !== "settings" && v() !== "clients" && _($r)
    })
  }
  t(Ot), t(bt), t(he);
  var Er = a(he, 2);
  {
    var Wr = _ => {
      var se = Qc(),
        F = Ge(se),
        Ne = a(F, 2),
        ce = r(Ne);
      Hs(ce, {
        onclose: () => s(Ye, !1)
      }), t(Ne), d("click", F, () => s(Ye, !1)), Ir(3, F, () => ni), Ir(3, Ne, () => ra, () => ({
        x: 1
      })), n(_, se)
    };
    f(Er, _ => {
      e(Ye) && _(Wr)
    })
  }
  var Qt = a(Er, 2);
  {
    var St = _ => {
      var se = Zc(),
        F = r(se);
      Ds(F, {
        onback: () => tr.goto(e(pt)),
        get backLabel() {
          return rt[e(pt)]
        }
      }), t(se), ba(se, (Ne, ce) => {
        var Xe;
        return (Xe = Aa) == null ? void 0 : Xe(Ne, ce)
      }, () => !0), n(_, se)
    };
    f(Qt, _ => {
      v() === "settings" && _(St)
    })
  }
  t(te);
  var Pt = a(te, 2),
    ot = a(r(Pt), 2);
  {
    var Lt = _ => {
      var se = ed();
      Ae(8), n(_, se)
    };
    f(ot, _ => {
      e(Se) && _(Lt)
    })
  }
  t(Pt);
  var qt = a(Pt, 2);
  Fo(qt, {});
  var zr = a(qt, 2);
  {
    let _ = A(() => e(we) !== null);
    Sa(zr, {
      get open() {
        return e(_)
      },
      onclose: Le,
      class: "w-[360px] max-w-[88%] p-4",
      children: (se, F) => {
        var Ne = td(),
          ce = r(Ne),
          Xe = a(r(ce), 2),
          ht = r(Xe, !0);
        t(Xe), t(ce);
        var Zt = a(ce, 2),
          Kt = r(Zt),
          hr = a(Kt, 2);
        t(Zt), t(Ne), y(() => {
          var mr, Ar, Mr;
          return I(ht, (mr = e(ue)) != null && mr.dirty ? `"${(Ar=e(ue))==null?void 0:Ar.name}.lua" has unsaved changes that will be lost.` : `Close "${(Mr=e(ue))==null?void 0:Mr.name}.lua"?`)
        }), d("click", Kt, Le), d("click", hr, be), n(se, Ne)
      },
      $$slots: {
        default: !0
      }
    })
  }
  t(De), y(() => {
    Re = me(he, 1, "flex min-w-0 flex-1", null, Re, {
      hidden: v() === "settings"
    }), It = me(bt, 1, "content-panel flex min-w-0 flex-1 overflow-hidden", null, It, {
      "flex-row-reverse": e(ie) === "right"
    }), me(Ut, 1, `min-h-0 flex-1 flex-col ${v()==="editor"?"flex":"hidden"}`), me(nr, 1, `flex h-7 items-center gap-1.5 rounded px-2 text-[12px] font-medium
							transition-colors duration-[120ms] cursor-pointer
							${e(He)>0?"text-success":"text-text-muted hover:text-text-primary"}`), me(gr, 1, `size-1.5 rounded-full ${e(He)>0?"bg-success":e(Ue)>0?"bg-warning":"bg-text-muted/50"}`), I(pr, ` ${e(je)??""}`), vr.disabled = e(ve) || e(Pe), Lr = me(Vt, 1, "absolute inset-0", null, Lr, {
      "pointer-events-none": e(B),
      "opacity-0": e(B)
    }), ut(Vt, "aria-hidden", e(B))
  }), d("mousedown", tt, p), d("dblclick", tt, pe), d("click", nr, () => s(Ye, !0)), d("click", vr, m), n(l, De), Rt(), g()
}
Yt(["mousedown", "dblclick", "click"]);
export {
  od as component
};