var hh = Object.defineProperty;
var dh = (Ye, ze, He) => ze in Ye ? hh(Ye, ze, {
  enumerable: !0,
  configurable: !0,
  writable: !0,
  value: He
}) : Ye[ze] = He;
var Qe = (Ye, ze, He) => dh(Ye, typeof ze != "symbol" ? ze + "" : ze, He);
(function() {
  "use strict";
  var Oe, ao, oo, lo, uo, he, Q;
  class Ye {
    constructor() {
      this.listeners = [], this.unexpectedErrorHandler = function(e) {
        setTimeout(() => {
          throw e.stack ? at.isErrorNoTelemetry(e) ? new at(e.message + `

` + e.stack) : new Error(e.message + `

` + e.stack) : e
        }, 0)
      }
    }
    emit(e) {
      this.listeners.forEach(n => {
        n(e)
      })
    }
    onUnexpectedError(e) {
      this.unexpectedErrorHandler(e), this.emit(e)
    }
    onUnexpectedExternalError(e) {
      this.unexpectedErrorHandler(e)
    }
  }
  const ze = new Ye;

  function He(t) {
    co(t) || ze.onUnexpectedError(t)
  }

  function Cn(t) {
    if (t instanceof Error) {
      const {
        name: e,
        message: n,
        cause: i
      } = t, r = t.stacktrace || t.stack;
      return {
        $isError: !0,
        name: e,
        message: n,
        stack: r,
        noTelemetry: at.isErrorNoTelemetry(t),
        cause: i ? Cn(i) : void 0,
        code: t.code
      }
    }
    return t
  }
  const En = "Canceled";

  function co(t) {
    return t instanceof Ui ? !0 : t instanceof Error && t.name === En && t.message === En
  }
  class Ui extends Error {
    constructor() {
      super(En), this.name = this.message
    }
  }
  class at extends Error {
    constructor(e) {
      super(e), this.name = "CodeExpectedError"
    }
    static fromError(e) {
      if (e instanceof at) return e;
      const n = new at;
      return n.message = e.message, n.stack = e.stack, n
    }
    static isErrorNoTelemetry(e) {
      return e.name === "CodeExpectedError"
    }
  }
  class ue extends Error {
    constructor(e) {
      super(e || "An unexpected bug occurred."), Object.setPrototypeOf(this, ue.prototype)
    }
  }

  function ho(t, e = "Unreachable") {
    throw new Error(e)
  }

  function mo(t, e = "unexpected state") {
    if (!t) throw typeof e == "string" ? new ue(`Assertion Failed: ${e}`) : e
  }

  function $t(t) {
    if (!t()) {
      debugger;
      t(), He(new ue("Assertion Failed"))
    }
  }

  function Pi(t, e) {
    let n = 0;
    for (; n < t.length - 1;) {
      const i = t[n],
        r = t[n + 1];
      if (!e(i, r)) return !1;
      n++
    }
    return !0
  }

  function fo(t) {
    return typeof t == "string"
  }

  function po(t) {
    return !!t && typeof t[Symbol.iterator] == "function"
  }
  var Gt;
  (function(t) {
    function e(b) {
      return !!b && typeof b == "object" && typeof b[Symbol.iterator] == "function"
    }
    t.is = e;
    const n = Object.freeze([]);

    function i() {
      return n
    }
    t.empty = i;

    function* r(b) {
      yield b
    }
    t.single = r;

    function s(b) {
      return e(b) ? b : r(b)
    }
    t.wrap = s;

    function a(b) {
      return b || n
    }
    t.from = a;

    function* l(b) {
      for (let g = b.length - 1; g >= 0; g--) yield b[g]
    }
    t.reverse = l;

    function o(b) {
      return !b || b[Symbol.iterator]().next().done === !0
    }
    t.isEmpty = o;

    function u(b) {
      return b[Symbol.iterator]().next().value
    }
    t.first = u;

    function c(b, g) {
      let _ = 0;
      for (const N of b)
        if (g(N, _++)) return !0;
      return !1
    }
    t.some = c;

    function d(b, g) {
      let _ = 0;
      for (const N of b)
        if (!g(N, _++)) return !1;
      return !0
    }
    t.every = d;

    function m(b, g) {
      for (const _ of b)
        if (g(_)) return _
    }
    t.find = m;

    function* f(b, g) {
      for (const _ of b) g(_) && (yield _)
    }
    t.filter = f;

    function* w(b, g) {
      let _ = 0;
      for (const N of b) yield g(N, _++)
    }
    t.map = w;

    function* p(b, g) {
      let _ = 0;
      for (const N of b) yield* g(N, _++)
    }
    t.flatMap = p;

    function* x(...b) {
      for (const g of b) po(g) ? yield* g: yield g
    }
    t.concat = x;

    function T(b, g, _) {
      let N = _;
      for (const S of b) N = g(N, S);
      return N
    }
    t.reduce = T;

    function y(b) {
      let g = 0;
      for (const _ of b) g++;
      return g
    }
    t.length = y;

    function* L(b, g, _ = b.length) {
      for (g < -b.length && (g = 0), g < 0 && (g += b.length), _ < 0 ? _ += b.length : _ > b.length && (_ = b.length); g < _; g++) yield b[g]
    }
    t.slice = L;

    function I(b, g = Number.POSITIVE_INFINITY) {
      const _ = [];
      if (g === 0) return [_, b];
      const N = b[Symbol.iterator]();
      for (let S = 0; S < g; S++) {
        const v = N.next();
        if (v.done) return [_, t.empty()];
        _.push(v.value)
      }
      return [_, {
        [Symbol.iterator]() {
          return N
        }
      }]
    }
    t.consume = I;
    async function H(b) {
      const g = [];
      for await (const _ of b) g.push(_);
      return g
    }
    t.asyncToArray = H;
    async function P(b) {
      let g = [];
      for await (const _ of b) g = g.concat(_);
      return g
    }
    t.asyncToArrayFlat = P
  })(Gt || (Gt = {}));

  function mh(t, e) {}

  function Wi(t) {
    if (Gt.is(t)) {
      const e = [];
      for (const n of t)
        if (n) try {
          n.dispose()
        } catch (i) {
          e.push(i)
        }
      if (e.length === 1) throw e[0];
      if (e.length > 1) throw new AggregateError(e, "Encountered errors while disposing of store");
      return Array.isArray(t) ? [] : t
    } else if (t) return t.dispose(), t
  }

  function go(...t) {
    return Xt(() => Wi(t))
  }
  class bo {
    constructor(e) {
      this._isDisposed = !1, this._fn = e
    }
    dispose() {
      if (!this._isDisposed) {
        if (!this._fn) throw new Error("Unbound disposable context: Need to use an arrow function to preserve the value of this");
        this._isDisposed = !0, this._fn()
      }
    }
  }

  function Xt(t) {
    return new bo(t)
  }
  const Tn = class Tn {
    constructor() {
      this._toDispose = new Set, this._isDisposed = !1
    }
    dispose() {
      this._isDisposed || (this._isDisposed = !0, this.clear())
    }
    get isDisposed() {
      return this._isDisposed
    }
    clear() {
      if (this._toDispose.size !== 0) try {
        Wi(this._toDispose)
      } finally {
        this._toDispose.clear()
      }
    }
    add(e) {
      if (!e || e === Ze.None) return e;
      if (e === this) throw new Error("Cannot register a disposable on itself!");
      return this._isDisposed ? Tn.DISABLE_DISPOSED_WARNING || console.warn(new Error("Trying to add a disposable to a DisposableStore that has already been disposed of. The added object will be leaked!").stack) : this._toDispose.add(e), e
    }
    delete(e) {
      if (e) {
        if (e === this) throw new Error("Cannot dispose a disposable on itself!");
        this._toDispose.delete(e), e.dispose()
      }
    }
  };
  Tn.DISABLE_DISPOSED_WARNING = !1;
  let Lt = Tn;
  const zi = class zi {
    constructor() {
      this._store = new Lt, this._store
    }
    dispose() {
      this._store.dispose()
    }
    _register(e) {
      if (e === this) throw new Error("Cannot register a disposable on itself!");
      return this._store.add(e)
    }
  };
  zi.None = Object.freeze({
    dispose() {}
  });
  let Ze = zi,
    te = (Oe = class {
      constructor(e) {
        this.element = e, this.next = Oe.Undefined, this.prev = Oe.Undefined
      }
    }, Oe.Undefined = new Oe(void 0), Oe);
  class wo {
    constructor() {
      this._first = te.Undefined, this._last = te.Undefined, this._size = 0
    }
    get size() {
      return this._size
    }
    isEmpty() {
      return this._first === te.Undefined
    }
    clear() {
      let e = this._first;
      for (; e !== te.Undefined;) {
        const n = e.next;
        e.prev = te.Undefined, e.next = te.Undefined, e = n
      }
      this._first = te.Undefined, this._last = te.Undefined, this._size = 0
    }
    unshift(e) {
      return this._insert(e, !1)
    }
    push(e) {
      return this._insert(e, !0)
    }
    _insert(e, n) {
      const i = new te(e);
      if (this._first === te.Undefined) this._first = i, this._last = i;
      else if (n) {
        const s = this._last;
        this._last = i, i.prev = s, s.next = i
      } else {
        const s = this._first;
        this._first = i, i.next = s, s.prev = i
      }
      this._size += 1;
      let r = !1;
      return () => {
        r || (r = !0, this._remove(i))
      }
    }
    shift() {
      if (this._first !== te.Undefined) {
        const e = this._first.element;
        return this._remove(this._first), e
      }
    }
    pop() {
      if (this._last !== te.Undefined) {
        const e = this._last.element;
        return this._remove(this._last), e
      }
    }
    _remove(e) {
      if (e.prev !== te.Undefined && e.next !== te.Undefined) {
        const n = e.prev;
        n.next = e.next, e.next.prev = n
      } else e.prev === te.Undefined && e.next === te.Undefined ? (this._first = te.Undefined, this._last = te.Undefined) : e.next === te.Undefined ? (this._last = this._last.prev, this._last.next = te.Undefined) : e.prev === te.Undefined && (this._first = this._first.next, this._first.prev = te.Undefined);
      this._size -= 1
    }*[Symbol.iterator]() {
      let e = this._first;
      for (; e !== te.Undefined;) yield e.element, e = e.next
    }
  }
  const _o = globalThis.performance.now.bind(globalThis.performance);
  class Jt {
    static create(e) {
      return new Jt(e)
    }
    constructor(e) {
      this._now = e === !1 ? Date.now : _o, this._startTime = this._now(), this._stopTime = -1
    }
    stop() {
      this._stopTime = this._now()
    }
    reset() {
      this._startTime = this._now(), this._stopTime = -1
    }
    elapsed() {
      return this._stopTime !== -1 ? this._stopTime - this._startTime : this._now() - this._startTime
    }
  }
  var Rn;
  (function(t) {
    t.None = () => Ze.None;

    function e(v, A) {
      return m(v, () => {}, 0, void 0, !0, void 0, A)
    }
    t.defer = e;

    function n(v) {
      return (A, D = null, k) => {
        let E = !1,
          M;
        return M = v(W => {
          if (!E) return M ? M.dispose() : E = !0, A.call(D, W)
        }, null, k), E && M.dispose(), M
      }
    }
    t.once = n;

    function i(v, A) {
      return t.once(t.filter(v, A))
    }
    t.onceIf = i;

    function r(v, A, D) {
      return c((k, E = null, M) => v(W => k.call(E, A(W)), null, M), D)
    }
    t.map = r;

    function s(v, A, D) {
      return c((k, E = null, M) => v(W => {
        A(W), k.call(E, W)
      }, null, M), D)
    }
    t.forEach = s;

    function a(v, A, D) {
      return c((k, E = null, M) => v(W => A(W) && k.call(E, W), null, M), D)
    }
    t.filter = a;

    function l(v) {
      return v
    }
    t.signal = l;

    function o(...v) {
      return (A, D = null, k) => {
        const E = go(...v.map(M => M(W => A.call(D, W))));
        return d(E, k)
      }
    }
    t.any = o;

    function u(v, A, D, k) {
      let E = D;
      return r(v, M => (E = A(E, M), E), k)
    }
    t.reduce = u;

    function c(v, A) {
      let D;
      const k = {
          onWillAddFirstListener() {
            D = v(E.fire, E)
          },
          onDidRemoveLastListener() {
            D == null || D.dispose()
          }
        },
        E = new Re(k);
      return A == null || A.add(E), E.event
    }

    function d(v, A) {
      return A instanceof Array ? A.push(v) : A && A.add(v), v
    }

    function m(v, A, D = 100, k = !1, E = !1, M, W) {
      let F, U, O, Z = 0,
        Y;
      const xe = {
          leakWarningThreshold: M,
          onWillAddFirstListener() {
            F = v(uh => {
              Z++, U = A(U, uh), k && !O && (Ee.fire(U), U = void 0), Y = () => {
                const ch = U;
                U = void 0, O = void 0, (!k || Z > 1) && Ee.fire(ch), Z = 0
              }, typeof D == "number" ? (O && clearTimeout(O), O = setTimeout(Y, D)) : O === void 0 && (O = null, queueMicrotask(Y))
            })
          },
          onWillRemoveListener() {
            E && Z > 0 && (Y == null || Y())
          },
          onDidRemoveLastListener() {
            Y = void 0, F.dispose()
          }
        },
        Ee = new Re(xe);
      return W == null || W.add(Ee), Ee.event
    }
    t.debounce = m;

    function f(v, A = 0, D) {
      return t.debounce(v, (k, E) => k ? (k.push(E), k) : [E], A, void 0, !0, void 0, D)
    }
    t.accumulate = f;

    function w(v, A = (k, E) => k === E, D) {
      let k = !0,
        E;
      return a(v, M => {
        const W = k || !A(M, E);
        return k = !1, E = M, W
      }, D)
    }
    t.latch = w;

    function p(v, A, D) {
      return [t.filter(v, A, D), t.filter(v, k => !A(k), D)]
    }
    t.split = p;

    function x(v, A = !1, D = [], k) {
      let E = D.slice(),
        M = v(U => {
          E ? E.push(U) : F.fire(U)
        });
      k && k.add(M);
      const W = () => {
          E == null || E.forEach(U => F.fire(U)), E = null
        },
        F = new Re({
          onWillAddFirstListener() {
            M || (M = v(U => F.fire(U)), k && k.add(M))
          },
          onDidAddFirstListener() {
            E && (A ? setTimeout(W) : W())
          },
          onDidRemoveLastListener() {
            M && M.dispose(), M = null
          }
        });
      return k && k.add(F), F.event
    }
    t.buffer = x;

    function T(v, A) {
      return (k, E, M) => {
        const W = A(new L);
        return v(function(F) {
          const U = W.evaluate(F);
          U !== y && k.call(E, U)
        }, void 0, M)
      }
    }
    t.chain = T;
    const y = Symbol("HaltChainable");
    class L {
      constructor() {
        this.steps = []
      }
      map(A) {
        return this.steps.push(A), this
      }
      forEach(A) {
        return this.steps.push(D => (A(D), D)), this
      }
      filter(A) {
        return this.steps.push(D => A(D) ? D : y), this
      }
      reduce(A, D) {
        let k = D;
        return this.steps.push(E => (k = A(k, E), k)), this
      }
      latch(A = (D, k) => D === k) {
        let D = !0,
          k;
        return this.steps.push(E => {
          const M = D || !A(E, k);
          return D = !1, k = E, M ? E : y
        }), this
      }
      evaluate(A) {
        for (const D of this.steps)
          if (A = D(A), A === y) break;
        return A
      }
    }

    function I(v, A, D = k => k) {
      const k = (...F) => W.fire(D(...F)),
        E = () => v.on(A, k),
        M = () => v.removeListener(A, k),
        W = new Re({
          onWillAddFirstListener: E,
          onDidRemoveLastListener: M
        });
      return W.event
    }
    t.fromNodeEventEmitter = I;

    function H(v, A, D = k => k) {
      const k = (...F) => W.fire(D(...F)),
        E = () => v.addEventListener(A, k),
        M = () => v.removeEventListener(A, k),
        W = new Re({
          onWillAddFirstListener: E,
          onDidRemoveLastListener: M
        });
      return W.event
    }
    t.fromDOMEventEmitter = H;

    function P(v, A) {
      let D;
      const k = new Promise((E, M) => {
        const W = n(v)(E, null, A);
        D = () => W.dispose()
      });
      return k.cancel = D, k
    }
    t.toPromise = P;

    function b(v, A) {
      return v(D => A.fire(D))
    }
    t.forward = b;

    function g(v, A, D) {
      return A(D), v(k => A(k))
    }
    t.runAndSubscribe = g;
    class _ {
      constructor(A, D) {
        this._observable = A, this._counter = 0, this._hasChanged = !1;
        const k = {
          onWillAddFirstListener: () => {
            A.addObserver(this), this._observable.reportChanges()
          },
          onDidRemoveLastListener: () => {
            A.removeObserver(this)
          }
        };
        this.emitter = new Re(k), D && D.add(this.emitter)
      }
      beginUpdate(A) {
        this._counter++
      }
      handlePossibleChange(A) {}
      handleChange(A, D) {
        this._hasChanged = !0
      }
      endUpdate(A) {
        this._counter--, this._counter === 0 && (this._observable.reportChanges(), this._hasChanged && (this._hasChanged = !1, this.emitter.fire(this._observable.get())))
      }
    }

    function N(v, A) {
      return new _(v, A).emitter.event
    }
    t.fromObservable = N;

    function S(v) {
      return (A, D, k) => {
        let E = 0,
          M = !1;
        const W = {
          beginUpdate() {
            E++
          },
          endUpdate() {
            E--, E === 0 && (v.reportChanges(), M && (M = !1, A.call(D)))
          },
          handlePossibleChange() {},
          handleChange() {
            M = !0
          }
        };
        v.addObserver(W), v.reportChanges();
        const F = {
          dispose() {
            v.removeObserver(W)
          }
        };
        return k instanceof Lt ? k.add(F) : Array.isArray(k) && k.push(F), F
      }
    }
    t.fromObservableLight = S
  })(Rn || (Rn = {}));
  const xt = class xt {
    constructor(e) {
      this.listenerCount = 0, this.invocationCount = 0, this.elapsedOverall = 0, this.durations = [], this.name = `${e}_${xt._idPool++}`, xt.all.add(this)
    }
    start(e) {
      this._stopWatch = new Jt, this.listenerCount = e
    }
    stop() {
      if (this._stopWatch) {
        const e = this._stopWatch.elapsed();
        this.durations.push(e), this.elapsedOverall += e, this.invocationCount += 1, this._stopWatch = void 0
      }
    }
  };
  xt.all = new Set, xt._idPool = 0;
  let Dn = xt,
    vo = -1;
  const xn = class xn {
    constructor(e, n, i = (xn._idPool++).toString(16).padStart(3, "0")) {
      this._errorHandler = e, this.threshold = n, this.name = i, this._warnCountdown = 0
    }
    dispose() {
      var e;
      (e = this._stacks) == null || e.clear()
    }
    check(e, n) {
      const i = this.threshold;
      if (i <= 0 || n < i) return;
      this._stacks || (this._stacks = new Map);
      const r = this._stacks.get(e.value) || 0;
      if (this._stacks.set(e.value, r + 1), this._warnCountdown -= 1, this._warnCountdown <= 0) {
        this._warnCountdown = i * .5;
        const [s, a] = this.getMostFrequentStack(), l = `[${this.name}] potential listener LEAK detected, having ${n} listeners already. MOST frequent listener (${a}):`;
        console.warn(l), console.warn(s);
        const o = new yo(l, s);
        this._errorHandler(o)
      }
      return () => {
        const s = this._stacks.get(e.value) || 0;
        this._stacks.set(e.value, s - 1)
      }
    }
    getMostFrequentStack() {
      if (!this._stacks) return;
      let e, n = 0;
      for (const [i, r] of this._stacks)(!e || n < r) && (e = [i, r], n = r);
      return e
    }
  };
  xn._idPool = 1;
  let Mn = xn;
  class Nn {
    static create() {
      const e = new Error;
      return new Nn(e.stack ?? "")
    }
    constructor(e) {
      this.value = e
    }
    print() {
      console.warn(this.value.split(`
`).slice(2).join(`
`))
    }
  }
  class yo extends Error {
    constructor(e, n) {
      super(e), this.name = "ListenerLeakError", this.stack = n
    }
  }
  class To extends Error {
    constructor(e, n) {
      super(e), this.name = "ListenerRefusalError", this.stack = n
    }
  }
  class In {
    constructor(e) {
      this.value = e
    }
  }
  const xo = 2;
  class Re {
    constructor(e) {
      var n, i, r, s;
      this._size = 0, this._options = e, this._leakageMon = (n = this._options) != null && n.leakWarningThreshold ? new Mn((e == null ? void 0 : e.onListenerError) ?? He, ((i = this._options) == null ? void 0 : i.leakWarningThreshold) ?? vo) : void 0, this._perfMon = (r = this._options) != null && r._profName ? new Dn(this._options._profName) : void 0, this._deliveryQueue = (s = this._options) == null ? void 0 : s.deliveryQueue
    }
    dispose() {
      var e, n, i, r;
      this._disposed || (this._disposed = !0, ((e = this._deliveryQueue) == null ? void 0 : e.current) === this && this._deliveryQueue.reset(), this._listeners && (this._listeners = void 0, this._size = 0), (i = (n = this._options) == null ? void 0 : n.onDidRemoveLastListener) == null || i.call(n), (r = this._leakageMon) == null || r.dispose())
    }
    get event() {
      return this._event ?? (this._event = (e, n, i) => {
        var l, o, u, c, d, m, f;
        if (this._leakageMon && this._size > this._leakageMon.threshold ** 2) {
          const w = `[${this._leakageMon.name}] REFUSES to accept new listeners because it exceeded its threshold by far (${this._size} vs ${this._leakageMon.threshold})`;
          console.warn(w);
          const p = this._leakageMon.getMostFrequentStack() ?? ["UNKNOWN stack", -1],
            x = new To(`${w}. HINT: Stack shows most frequent listener (${p[1]}-times)`, p[0]);
          return (((l = this._options) == null ? void 0 : l.onListenerError) || He)(x), Ze.None
        }
        if (this._disposed) return Ze.None;
        n && (e = e.bind(n));
        const r = new In(e);
        let s;
        this._leakageMon && this._size >= Math.ceil(this._leakageMon.threshold * .2) && (r.stack = Nn.create(), s = this._leakageMon.check(r.stack, this._size + 1)), this._listeners ? this._listeners instanceof In ? (this._deliveryQueue ?? (this._deliveryQueue = new ko), this._listeners = [this._listeners, r]) : this._listeners.push(r) : ((u = (o = this._options) == null ? void 0 : o.onWillAddFirstListener) == null || u.call(o, this), this._listeners = r, (d = (c = this._options) == null ? void 0 : c.onDidAddFirstListener) == null || d.call(c, this)), (f = (m = this._options) == null ? void 0 : m.onDidAddListener) == null || f.call(m, this), this._size++;
        const a = Xt(() => {
          s == null || s(), this._removeListener(r)
        });
        return i instanceof Lt ? i.add(a) : Array.isArray(i) && i.push(a), a
      }), this._event
    }
    _removeListener(e) {
      var s, a, l, o;
      if ((a = (s = this._options) == null ? void 0 : s.onWillRemoveListener) == null || a.call(s, this), !this._listeners) return;
      if (this._size === 1) {
        this._listeners = void 0, (o = (l = this._options) == null ? void 0 : l.onDidRemoveLastListener) == null || o.call(l, this), this._size = 0;
        return
      }
      const n = this._listeners,
        i = n.indexOf(e);
      if (i === -1) throw console.log("disposed?", this._disposed), console.log("size?", this._size), console.log("arr?", JSON.stringify(this._listeners)), new Error("Attempted to dispose unknown listener");
      this._size--, n[i] = void 0;
      const r = this._deliveryQueue.current === this;
      if (this._size * xo <= n.length) {
        let u = 0;
        for (let c = 0; c < n.length; c++) n[c] ? n[u++] = n[c] : r && u < this._deliveryQueue.end && (this._deliveryQueue.end--, u < this._deliveryQueue.i && this._deliveryQueue.i--);
        n.length = u
      }
    }
    _deliver(e, n) {
      var r;
      if (!e) return;
      const i = ((r = this._options) == null ? void 0 : r.onListenerError) || He;
      if (!i) {
        e.value(n);
        return
      }
      try {
        e.value(n)
      } catch (s) {
        i(s)
      }
    }
    _deliverQueue(e) {
      const n = e.current._listeners;
      for (; e.i < e.end;) this._deliver(n[e.i++], e.value);
      e.reset()
    }
    fire(e) {
      var n, i, r, s;
      if ((n = this._deliveryQueue) != null && n.current && (this._deliverQueue(this._deliveryQueue), (i = this._perfMon) == null || i.stop()), (r = this._perfMon) == null || r.start(this._size), this._listeners)
        if (this._listeners instanceof In) this._deliver(this._listeners, e);
        else {
          const a = this._deliveryQueue;
          a.enqueue(this, e, this._listeners.length), this._deliverQueue(a)
        }(s = this._perfMon) == null || s.stop()
    }
    hasListeners() {
      return this._size > 0
    }
  }
  class ko {
    constructor() {
      this.i = -1, this.end = 0
    }
    enqueue(e, n, i) {
      this.i = 0, this.end = i, this.current = e, this.value = n
    }
    reset() {
      this.i = this.end, this.current = void 0, this.value = void 0
    }
  }

  function So() {
    return globalThis._VSCODE_NLS_MESSAGES
  }

  function Fi() {
    return globalThis._VSCODE_NLS_LANGUAGE
  }
  const Ao = Fi() === "pseudo" || typeof document < "u" && document.location && typeof document.location.hash == "string" && document.location.hash.indexOf("pseudo=true") >= 0;

  function Bi(t, e) {
    let n;
    return e.length === 0 ? n = t : n = t.replace(/\{(\d+)\}/g, (i, r) => {
      const s = r[0],
        a = e[s];
      let l = i;
      return typeof a == "string" ? l = a : (typeof a == "number" || typeof a == "boolean" || a === void 0 || a === null) && (l = String(a)), l
    }), Ao && (n = "［" + n.replace(/[aouei]/g, "$&$&") + "］"), n
  }

  function q(t, e, ...n) {
    return Bi(typeof t == "number" ? Lo(t, e) : e, n)
  }

  function Lo(t, e) {
    var i;
    const n = (i = So()) == null ? void 0 : i[t];
    if (typeof n != "string") {
      if (typeof e == "string") return e;
      throw new Error(`!!! NLS MISSING: ${t} !!!`)
    }
    return n
  }
  const ot = "en";
  let zn = !1,
    Hn = !1,
    Un = !1,
    Qt, Pn = ot,
    qi = ot,
    Co, ke;
  const Ke = globalThis;
  let ae;
  typeof Ke.vscode < "u" && typeof Ke.vscode.process < "u" ? ae = Ke.vscode.process : typeof process < "u" && typeof((ao = process == null ? void 0 : process.versions) == null ? void 0 : ao.node) == "string" && (ae = process);
  const Eo = typeof((oo = ae == null ? void 0 : ae.versions) == null ? void 0 : oo.electron) == "string" && (ae == null ? void 0 : ae.type) === "renderer";
  if (typeof ae == "object") {
    zn = ae.platform === "win32", Hn = ae.platform === "darwin", Un = ae.platform === "linux", Un && ae.env.SNAP && ae.env.SNAP_REVISION, ae.env.CI || ae.env.BUILD_ARTIFACTSTAGINGDIRECTORY || ae.env.GITHUB_WORKSPACE, Qt = ot, Pn = ot;
    const t = ae.env.VSCODE_NLS_CONFIG;
    if (t) try {
      const e = JSON.parse(t);
      Qt = e.userLocale, qi = e.osLocale, Pn = e.resolvedLanguage || ot, Co = (lo = e.languagePack) == null ? void 0 : lo.translationsConfigFile
    } catch {}
  } else typeof navigator == "object" && !Eo ? (ke = navigator.userAgent, zn = ke.indexOf("Windows") >= 0, Hn = ke.indexOf("Macintosh") >= 0, (ke.indexOf("Macintosh") >= 0 || ke.indexOf("iPad") >= 0 || ke.indexOf("iPhone") >= 0) && navigator.maxTouchPoints && navigator.maxTouchPoints > 0, Un = ke.indexOf("Linux") >= 0, (ke == null ? void 0 : ke.indexOf("Mobi")) >= 0, Pn = Fi() || ot, Qt = navigator.language.toLowerCase(), qi = Qt) : console.error("Unable to resolve platform.");
  const Ct = zn,
    Ro = Hn,
    De = ke,
    Do = typeof Ke.postMessage == "function" && !Ke.importScripts;
  (() => {
    if (Do) {
      const t = [];
      Ke.addEventListener("message", n => {
        if (n.data && n.data.vscodeScheduleAsyncWork)
          for (let i = 0, r = t.length; i < r; i++) {
            const s = t[i];
            if (s.id === n.data.vscodeScheduleAsyncWork) {
              t.splice(i, 1), s.callback();
              return
            }
          }
      });
      let e = 0;
      return n => {
        const i = ++e;
        t.push({
          id: i,
          callback: n
        }), Ke.postMessage({
          vscodeScheduleAsyncWork: i
        }, "*")
      }
    }
    return t => setTimeout(t)
  })();
  const Mo = !!(De && De.indexOf("Chrome") >= 0);
  De && De.indexOf("Firefox") >= 0, !Mo && De && De.indexOf("Safari") >= 0, De && De.indexOf("Edg/") >= 0, De && De.indexOf("Android") >= 0;

  function No(t) {
    return t
  }
  class Io {
    constructor(e, n) {
      this.lastCache = void 0, this.lastArgKey = void 0, typeof e == "function" ? (this._fn = e, this._computeKey = No) : (this._fn = n, this._computeKey = e.getCacheKey)
    }
    get(e) {
      const n = this._computeKey(e);
      return this.lastArgKey !== n && (this.lastArgKey = n, this.lastCache = this._fn(e)), this.lastCache
    }
  }
  var et;
  (function(t) {
    t[t.Uninitialized = 0] = "Uninitialized", t[t.Running = 1] = "Running", t[t.Completed = 2] = "Completed"
  })(et || (et = {}));
  class Wn {
    constructor(e) {
      this.executor = e, this._state = et.Uninitialized
    }
    get value() {
      if (this._state === et.Uninitialized) {
        this._state = et.Running;
        try {
          this._value = this.executor()
        } catch (e) {
          this._error = e
        } finally {
          this._state = et.Completed
        }
      } else if (this._state === et.Running) throw new Error("Cannot read the value of a lazy that is being initialized");
      if (this._error) throw this._error;
      return this._value
    }
    get rawValue() {
      return this._value
    }
  }

  function zo(t) {
    return t.replace(/[\\\{\}\*\+\?\|\^\$\.\[\]\(\)]/g, "\\$&")
  }

  function Ho(t) {
    return t.source === "^" || t.source === "^$" || t.source === "$" || t.source === "^\\s*$" ? !1 : !!(t.exec("") && t.lastIndex === 0)
  }

  function Uo(t) {
    return t.split(/\r\n|\r|\n/)
  }

  function Po(t) {
    for (let e = 0, n = t.length; e < n; e++) {
      const i = t.charCodeAt(e);
      if (i !== 32 && i !== 9) return e
    }
    return -1
  }

  function Wo(t, e = t.length - 1) {
    for (let n = e; n >= 0; n--) {
      const i = t.charCodeAt(n);
      if (i !== 32 && i !== 9) return n
    }
    return -1
  }

  function Oi(t) {
    return t >= 65 && t <= 90
  }

  function Fo(t, e) {
    const n = Math.min(t.length, e.length);
    let i;
    for (i = 0; i < n; i++)
      if (t.charCodeAt(i) !== e.charCodeAt(i)) return i;
    return n
  }

  function Bo(t, e) {
    const n = Math.min(t.length, e.length);
    let i;
    const r = t.length - 1,
      s = e.length - 1;
    for (i = 0; i < n; i++)
      if (t.charCodeAt(r - i) !== e.charCodeAt(s - i)) return i;
    return n
  }

  function Fn(t) {
    return 55296 <= t && t <= 56319
  }

  function qo(t) {
    return 56320 <= t && t <= 57343
  }

  function Oo(t, e) {
    return (t - 55296 << 10) + (e - 56320) + 65536
  }

  function Vo(t, e, n) {
    const i = t.charCodeAt(n);
    if (Fn(i) && n + 1 < e) {
      const r = t.charCodeAt(n + 1);
      if (qo(r)) return Oo(i, r)
    }
    return i
  }
  const jo = /^[\t\n\r\x20-\x7E]*$/;

  function $o(t) {
    return jo.test(t)
  }
  const Ie = class Ie {
    static getInstance(e) {
      return Ie.cache.get(Array.from(e))
    }
    static getLocales() {
      return Ie._locales.value
    }
    constructor(e) {
      this.confusableDictionary = e
    }
    isAmbiguous(e) {
      return this.confusableDictionary.has(e)
    }
    getPrimaryConfusable(e) {
      return this.confusableDictionary.get(e)
    }
    getConfusableCodePoints() {
      return new Set(this.confusableDictionary.keys())
    }
  };
  Ie.ambiguousCharacterData = new Wn(() => JSON.parse('{"_common":[8232,32,8233,32,5760,32,8192,32,8193,32,8194,32,8195,32,8196,32,8197,32,8198,32,8200,32,8201,32,8202,32,8287,32,8199,32,8239,32,2042,95,65101,95,65102,95,65103,95,8208,45,8209,45,8210,45,65112,45,1748,45,8259,45,727,45,8722,45,10134,45,11450,45,1549,44,1643,44,184,44,42233,44,894,59,2307,58,2691,58,1417,58,1795,58,1796,58,5868,58,65072,58,6147,58,6153,58,8282,58,1475,58,760,58,42889,58,8758,58,720,58,42237,58,451,33,11601,33,660,63,577,63,2429,63,5038,63,42731,63,119149,46,8228,46,1793,46,1794,46,42510,46,68176,46,1632,46,1776,46,42232,46,1373,96,65287,96,8219,96,1523,96,8242,96,1370,96,8175,96,65344,96,900,96,8189,96,8125,96,8127,96,8190,96,697,96,884,96,712,96,714,96,715,96,756,96,699,96,701,96,700,96,702,96,42892,96,1497,96,2036,96,2037,96,5194,96,5836,96,94033,96,94034,96,65339,91,10088,40,10098,40,12308,40,64830,40,65341,93,10089,41,10099,41,12309,41,64831,41,10100,123,119060,123,10101,125,65342,94,8270,42,1645,42,8727,42,66335,42,5941,47,8257,47,8725,47,8260,47,9585,47,10187,47,10744,47,119354,47,12755,47,12339,47,11462,47,20031,47,12035,47,65340,92,65128,92,8726,92,10189,92,10741,92,10745,92,119311,92,119355,92,12756,92,20022,92,12034,92,42872,38,708,94,710,94,5869,43,10133,43,66203,43,8249,60,10094,60,706,60,119350,60,5176,60,5810,60,5120,61,11840,61,12448,61,42239,61,8250,62,10095,62,707,62,119351,62,5171,62,94015,62,8275,126,732,126,8128,126,8764,126,65372,124,65293,45,118002,50,120784,50,120794,50,120804,50,120814,50,120824,50,130034,50,42842,50,423,50,1000,50,42564,50,5311,50,42735,50,119302,51,118003,51,120785,51,120795,51,120805,51,120815,51,120825,51,130035,51,42923,51,540,51,439,51,42858,51,11468,51,1248,51,94011,51,71882,51,118004,52,120786,52,120796,52,120806,52,120816,52,120826,52,130036,52,5070,52,71855,52,118005,53,120787,53,120797,53,120807,53,120817,53,120827,53,130037,53,444,53,71867,53,118006,54,120788,54,120798,54,120808,54,120818,54,120828,54,130038,54,11474,54,5102,54,71893,54,119314,55,118007,55,120789,55,120799,55,120809,55,120819,55,120829,55,130039,55,66770,55,71878,55,2819,56,2538,56,2666,56,125131,56,118008,56,120790,56,120800,56,120810,56,120820,56,120830,56,130040,56,547,56,546,56,66330,56,2663,57,2920,57,2541,57,3437,57,118009,57,120791,57,120801,57,120811,57,120821,57,120831,57,130041,57,42862,57,11466,57,71884,57,71852,57,71894,57,9082,97,65345,97,119834,97,119886,97,119938,97,119990,97,120042,97,120094,97,120146,97,120198,97,120250,97,120302,97,120354,97,120406,97,120458,97,593,97,945,97,120514,97,120572,97,120630,97,120688,97,120746,97,65313,65,117974,65,119808,65,119860,65,119912,65,119964,65,120016,65,120068,65,120120,65,120172,65,120224,65,120276,65,120328,65,120380,65,120432,65,913,65,120488,65,120546,65,120604,65,120662,65,120720,65,5034,65,5573,65,42222,65,94016,65,66208,65,119835,98,119887,98,119939,98,119991,98,120043,98,120095,98,120147,98,120199,98,120251,98,120303,98,120355,98,120407,98,120459,98,388,98,5071,98,5234,98,5551,98,65314,66,8492,66,117975,66,119809,66,119861,66,119913,66,120017,66,120069,66,120121,66,120173,66,120225,66,120277,66,120329,66,120381,66,120433,66,42932,66,914,66,120489,66,120547,66,120605,66,120663,66,120721,66,5108,66,5623,66,42192,66,66178,66,66209,66,66305,66,65347,99,8573,99,119836,99,119888,99,119940,99,119992,99,120044,99,120096,99,120148,99,120200,99,120252,99,120304,99,120356,99,120408,99,120460,99,7428,99,1010,99,11429,99,43951,99,66621,99,128844,67,71913,67,71922,67,65315,67,8557,67,8450,67,8493,67,117976,67,119810,67,119862,67,119914,67,119966,67,120018,67,120174,67,120226,67,120278,67,120330,67,120382,67,120434,67,1017,67,11428,67,5087,67,42202,67,66210,67,66306,67,66581,67,66844,67,8574,100,8518,100,119837,100,119889,100,119941,100,119993,100,120045,100,120097,100,120149,100,120201,100,120253,100,120305,100,120357,100,120409,100,120461,100,1281,100,5095,100,5231,100,42194,100,8558,68,8517,68,117977,68,119811,68,119863,68,119915,68,119967,68,120019,68,120071,68,120123,68,120175,68,120227,68,120279,68,120331,68,120383,68,120435,68,5024,68,5598,68,5610,68,42195,68,8494,101,65349,101,8495,101,8519,101,119838,101,119890,101,119942,101,120046,101,120098,101,120150,101,120202,101,120254,101,120306,101,120358,101,120410,101,120462,101,43826,101,1213,101,8959,69,65317,69,8496,69,117978,69,119812,69,119864,69,119916,69,120020,69,120072,69,120124,69,120176,69,120228,69,120280,69,120332,69,120384,69,120436,69,917,69,120492,69,120550,69,120608,69,120666,69,120724,69,11577,69,5036,69,42224,69,71846,69,71854,69,66182,69,119839,102,119891,102,119943,102,119995,102,120047,102,120099,102,120151,102,120203,102,120255,102,120307,102,120359,102,120411,102,120463,102,43829,102,42905,102,383,102,7837,102,1412,102,119315,70,8497,70,117979,70,119813,70,119865,70,119917,70,120021,70,120073,70,120125,70,120177,70,120229,70,120281,70,120333,70,120385,70,120437,70,42904,70,988,70,120778,70,5556,70,42205,70,71874,70,71842,70,66183,70,66213,70,66853,70,65351,103,8458,103,119840,103,119892,103,119944,103,120048,103,120100,103,120152,103,120204,103,120256,103,120308,103,120360,103,120412,103,120464,103,609,103,7555,103,397,103,1409,103,117980,71,119814,71,119866,71,119918,71,119970,71,120022,71,120074,71,120126,71,120178,71,120230,71,120282,71,120334,71,120386,71,120438,71,1292,71,5056,71,5107,71,42198,71,65352,104,8462,104,119841,104,119945,104,119997,104,120049,104,120101,104,120153,104,120205,104,120257,104,120309,104,120361,104,120413,104,120465,104,1211,104,1392,104,5058,104,65320,72,8459,72,8460,72,8461,72,117981,72,119815,72,119867,72,119919,72,120023,72,120179,72,120231,72,120283,72,120335,72,120387,72,120439,72,919,72,120494,72,120552,72,120610,72,120668,72,120726,72,11406,72,5051,72,5500,72,42215,72,66255,72,731,105,9075,105,65353,105,8560,105,8505,105,8520,105,119842,105,119894,105,119946,105,119998,105,120050,105,120102,105,120154,105,120206,105,120258,105,120310,105,120362,105,120414,105,120466,105,120484,105,618,105,617,105,953,105,8126,105,890,105,120522,105,120580,105,120638,105,120696,105,120754,105,1110,105,42567,105,1231,105,43893,105,5029,105,71875,105,65354,106,8521,106,119843,106,119895,106,119947,106,119999,106,120051,106,120103,106,120155,106,120207,106,120259,106,120311,106,120363,106,120415,106,120467,106,1011,106,1112,106,65322,74,117983,74,119817,74,119869,74,119921,74,119973,74,120025,74,120077,74,120129,74,120181,74,120233,74,120285,74,120337,74,120389,74,120441,74,42930,74,895,74,1032,74,5035,74,5261,74,42201,74,119844,107,119896,107,119948,107,120000,107,120052,107,120104,107,120156,107,120208,107,120260,107,120312,107,120364,107,120416,107,120468,107,8490,75,65323,75,117984,75,119818,75,119870,75,119922,75,119974,75,120026,75,120078,75,120130,75,120182,75,120234,75,120286,75,120338,75,120390,75,120442,75,922,75,120497,75,120555,75,120613,75,120671,75,120729,75,11412,75,5094,75,5845,75,42199,75,66840,75,1472,108,8739,73,9213,73,65512,73,1633,108,1777,73,66336,108,125127,108,118001,108,120783,73,120793,73,120803,73,120813,73,120823,73,130033,73,65321,73,8544,73,8464,73,8465,73,117982,108,119816,73,119868,73,119920,73,120024,73,120128,73,120180,73,120232,73,120284,73,120336,73,120388,73,120440,73,65356,108,8572,73,8467,108,119845,108,119897,108,119949,108,120001,108,120053,108,120105,73,120157,73,120209,73,120261,73,120313,73,120365,73,120417,73,120469,73,448,73,120496,73,120554,73,120612,73,120670,73,120728,73,11410,73,1030,73,1216,73,1493,108,1503,108,1575,108,126464,108,126592,108,65166,108,65165,108,1994,108,11599,73,5825,73,42226,73,93992,73,66186,124,66313,124,119338,76,8556,76,8466,76,117985,76,119819,76,119871,76,119923,76,120027,76,120079,76,120131,76,120183,76,120235,76,120287,76,120339,76,120391,76,120443,76,11472,76,5086,76,5290,76,42209,76,93974,76,71843,76,71858,76,66587,76,66854,76,65325,77,8559,77,8499,77,117986,77,119820,77,119872,77,119924,77,120028,77,120080,77,120132,77,120184,77,120236,77,120288,77,120340,77,120392,77,120444,77,924,77,120499,77,120557,77,120615,77,120673,77,120731,77,1018,77,11416,77,5047,77,5616,77,5846,77,42207,77,66224,77,66321,77,119847,110,119899,110,119951,110,120003,110,120055,110,120107,110,120159,110,120211,110,120263,110,120315,110,120367,110,120419,110,120471,110,1400,110,1404,110,65326,78,8469,78,117987,78,119821,78,119873,78,119925,78,119977,78,120029,78,120081,78,120185,78,120237,78,120289,78,120341,78,120393,78,120445,78,925,78,120500,78,120558,78,120616,78,120674,78,120732,78,11418,78,42208,78,66835,78,3074,111,3202,111,3330,111,3458,111,2406,111,2662,111,2790,111,3046,111,3174,111,3302,111,3430,111,3664,111,3792,111,4160,111,1637,111,1781,111,65359,111,8500,111,119848,111,119900,111,119952,111,120056,111,120108,111,120160,111,120212,111,120264,111,120316,111,120368,111,120420,111,120472,111,7439,111,7441,111,43837,111,959,111,120528,111,120586,111,120644,111,120702,111,120760,111,963,111,120532,111,120590,111,120648,111,120706,111,120764,111,11423,111,4351,111,1413,111,1505,111,1607,111,126500,111,126564,111,126596,111,65259,111,65260,111,65258,111,65257,111,1726,111,64428,111,64429,111,64427,111,64426,111,1729,111,64424,111,64425,111,64423,111,64422,111,1749,111,3360,111,4125,111,66794,111,71880,111,71895,111,66604,111,1984,79,2534,79,2918,79,12295,79,70864,79,71904,79,118000,79,120782,79,120792,79,120802,79,120812,79,120822,79,130032,79,65327,79,117988,79,119822,79,119874,79,119926,79,119978,79,120030,79,120082,79,120134,79,120186,79,120238,79,120290,79,120342,79,120394,79,120446,79,927,79,120502,79,120560,79,120618,79,120676,79,120734,79,11422,79,1365,79,11604,79,4816,79,2848,79,66754,79,42227,79,71861,79,66194,79,66219,79,66564,79,66838,79,9076,112,65360,112,119849,112,119901,112,119953,112,120005,112,120057,112,120109,112,120161,112,120213,112,120265,112,120317,112,120369,112,120421,112,120473,112,961,112,120530,112,120544,112,120588,112,120602,112,120646,112,120660,112,120704,112,120718,112,120762,112,120776,112,11427,112,65328,80,8473,80,117989,80,119823,80,119875,80,119927,80,119979,80,120031,80,120083,80,120187,80,120239,80,120291,80,120343,80,120395,80,120447,80,929,80,120504,80,120562,80,120620,80,120678,80,120736,80,11426,80,5090,80,5229,80,42193,80,66197,80,119850,113,119902,113,119954,113,120006,113,120058,113,120110,113,120162,113,120214,113,120266,113,120318,113,120370,113,120422,113,120474,113,1307,113,1379,113,1382,113,8474,81,117990,81,119824,81,119876,81,119928,81,119980,81,120032,81,120084,81,120188,81,120240,81,120292,81,120344,81,120396,81,120448,81,11605,81,119851,114,119903,114,119955,114,120007,114,120059,114,120111,114,120163,114,120215,114,120267,114,120319,114,120371,114,120423,114,120475,114,43847,114,43848,114,7462,114,11397,114,43905,114,119318,82,8475,82,8476,82,8477,82,117991,82,119825,82,119877,82,119929,82,120033,82,120189,82,120241,82,120293,82,120345,82,120397,82,120449,82,422,82,5025,82,5074,82,66740,82,5511,82,42211,82,94005,82,65363,115,119852,115,119904,115,119956,115,120008,115,120060,115,120112,115,120164,115,120216,115,120268,115,120320,115,120372,115,120424,115,120476,115,42801,115,445,115,1109,115,43946,115,71873,115,66632,115,65331,83,117992,83,119826,83,119878,83,119930,83,119982,83,120034,83,120086,83,120138,83,120190,83,120242,83,120294,83,120346,83,120398,83,120450,83,1029,83,1359,83,5077,83,5082,83,42210,83,94010,83,66198,83,66592,83,119853,116,119905,116,119957,116,120009,116,120061,116,120113,116,120165,116,120217,116,120269,116,120321,116,120373,116,120425,116,120477,116,8868,84,10201,84,128872,84,65332,84,117993,84,119827,84,119879,84,119931,84,119983,84,120035,84,120087,84,120139,84,120191,84,120243,84,120295,84,120347,84,120399,84,120451,84,932,84,120507,84,120565,84,120623,84,120681,84,120739,84,11430,84,5026,84,42196,84,93962,84,71868,84,66199,84,66225,84,66325,84,119854,117,119906,117,119958,117,120010,117,120062,117,120114,117,120166,117,120218,117,120270,117,120322,117,120374,117,120426,117,120478,117,42911,117,7452,117,43854,117,43858,117,651,117,965,117,120534,117,120592,117,120650,117,120708,117,120766,117,1405,117,66806,117,71896,117,8746,85,8899,85,117994,85,119828,85,119880,85,119932,85,119984,85,120036,85,120088,85,120140,85,120192,85,120244,85,120296,85,120348,85,120400,85,120452,85,1357,85,4608,85,66766,85,5196,85,42228,85,94018,85,71864,85,8744,118,8897,118,65366,118,8564,118,119855,118,119907,118,119959,118,120011,118,120063,118,120115,118,120167,118,120219,118,120271,118,120323,118,120375,118,120427,118,120479,118,7456,118,957,118,120526,118,120584,118,120642,118,120700,118,120758,118,1141,118,1496,118,71430,118,43945,118,71872,118,119309,86,1639,86,1783,86,8548,86,117995,86,119829,86,119881,86,119933,86,119985,86,120037,86,120089,86,120141,86,120193,86,120245,86,120297,86,120349,86,120401,86,120453,86,1140,86,11576,86,5081,86,5167,86,42719,86,42214,86,93960,86,71840,86,66845,86,623,119,119856,119,119908,119,119960,119,120012,119,120064,119,120116,119,120168,119,120220,119,120272,119,120324,119,120376,119,120428,119,120480,119,7457,119,1121,119,1309,119,1377,119,71434,119,71438,119,71439,119,43907,119,71910,87,71919,87,117996,87,119830,87,119882,87,119934,87,119986,87,120038,87,120090,87,120142,87,120194,87,120246,87,120298,87,120350,87,120402,87,120454,87,1308,87,5043,87,5076,87,42218,87,5742,120,10539,120,10540,120,10799,120,65368,120,8569,120,119857,120,119909,120,119961,120,120013,120,120065,120,120117,120,120169,120,120221,120,120273,120,120325,120,120377,120,120429,120,120481,120,5441,120,5501,120,5741,88,9587,88,66338,88,71916,88,65336,88,8553,88,117997,88,119831,88,119883,88,119935,88,119987,88,120039,88,120091,88,120143,88,120195,88,120247,88,120299,88,120351,88,120403,88,120455,88,42931,88,935,88,120510,88,120568,88,120626,88,120684,88,120742,88,11436,88,11613,88,5815,88,42219,88,66192,88,66228,88,66327,88,66855,88,611,121,7564,121,65369,121,119858,121,119910,121,119962,121,120014,121,120066,121,120118,121,120170,121,120222,121,120274,121,120326,121,120378,121,120430,121,120482,121,655,121,7935,121,43866,121,947,121,8509,121,120516,121,120574,121,120632,121,120690,121,120748,121,1199,121,4327,121,71900,121,65337,89,117998,89,119832,89,119884,89,119936,89,119988,89,120040,89,120092,89,120144,89,120196,89,120248,89,120300,89,120352,89,120404,89,120456,89,933,89,978,89,120508,89,120566,89,120624,89,120682,89,120740,89,11432,89,1198,89,5033,89,5053,89,42220,89,94019,89,71844,89,66226,89,119859,122,119911,122,119963,122,120015,122,120067,122,120119,122,120171,122,120223,122,120275,122,120327,122,120379,122,120431,122,120483,122,7458,122,43923,122,71876,122,71909,90,66293,90,65338,90,8484,90,8488,90,117999,90,119833,90,119885,90,119937,90,119989,90,120041,90,120197,90,120249,90,120301,90,120353,90,120405,90,120457,90,918,90,120493,90,120551,90,120609,90,120667,90,120725,90,5059,90,42204,90,71849,90,65282,34,65283,35,65284,36,65285,37,65286,38,65290,42,65291,43,65294,46,65295,47,65296,48,65298,50,65299,51,65300,52,65301,53,65302,54,65303,55,65304,56,65305,57,65308,60,65309,61,65310,62,65312,64,65316,68,65318,70,65319,71,65324,76,65329,81,65330,82,65333,85,65334,86,65335,87,65343,95,65346,98,65348,100,65350,102,65355,107,65357,109,65358,110,65361,113,65362,114,65364,116,65365,117,65367,119,65370,122,65371,123,65373,125,119846,109],"_default":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8217,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"cs":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"de":[65374,126,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"es":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"fr":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"it":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"ja":[8211,45,8218,44,65281,33,8216,96,8245,96,180,96,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65292,44,65297,49,65307,59],"ko":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"pl":[65374,126,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"pt-BR":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"qps-ploc":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"ru":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,305,105,921,73,1009,112,215,120,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"tr":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"zh-hans":[160,32,65374,126,8218,44,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65297,49],"zh-hant":[8211,45,65374,126,8218,44,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89]}')), Ie.cache = new Io({
    getCacheKey: JSON.stringify
  }, e => {
    function n(c) {
      const d = new Map;
      for (let m = 0; m < c.length; m += 2) d.set(c[m], c[m + 1]);
      return d
    }

    function i(c, d) {
      const m = new Map(c);
      for (const [f, w] of d) m.set(f, w);
      return m
    }

    function r(c, d) {
      if (!c) return d;
      const m = new Map;
      for (const [f, w] of c) d.has(f) && m.set(f, w);
      return m
    }
    const s = Ie.ambiguousCharacterData.value;
    let a = e.filter(c => !c.startsWith("_") && Object.hasOwn(s, c));
    a.length === 0 && (a = ["_default"]);
    let l;
    for (const c of a) {
      const d = n(s[c]);
      l = r(l, d)
    }
    const o = n(s._common),
      u = i(o, l);
    return new Ie(u)
  }), Ie._locales = new Wn(() => Object.keys(Ie.ambiguousCharacterData.value).filter(e => !e.startsWith("_")));
  let Et = Ie;
  const kt = class kt {
    static getRawData() {
      return JSON.parse('{"_common":[11,12,13,127,847,1564,4447,4448,6068,6069,6155,6156,6157,6158,7355,7356,8192,8193,8194,8195,8196,8197,8198,8199,8200,8201,8202,8204,8205,8206,8207,8234,8235,8236,8237,8238,8239,8287,8288,8289,8290,8291,8292,8293,8294,8295,8296,8297,8298,8299,8300,8301,8302,8303,10240,12644,65024,65025,65026,65027,65028,65029,65030,65031,65032,65033,65034,65035,65036,65037,65038,65039,65279,65440,65520,65521,65522,65523,65524,65525,65526,65527,65528,65532,78844,119155,119156,119157,119158,119159,119160,119161,119162,917504,917505,917506,917507,917508,917509,917510,917511,917512,917513,917514,917515,917516,917517,917518,917519,917520,917521,917522,917523,917524,917525,917526,917527,917528,917529,917530,917531,917532,917533,917534,917535,917536,917537,917538,917539,917540,917541,917542,917543,917544,917545,917546,917547,917548,917549,917550,917551,917552,917553,917554,917555,917556,917557,917558,917559,917560,917561,917562,917563,917564,917565,917566,917567,917568,917569,917570,917571,917572,917573,917574,917575,917576,917577,917578,917579,917580,917581,917582,917583,917584,917585,917586,917587,917588,917589,917590,917591,917592,917593,917594,917595,917596,917597,917598,917599,917600,917601,917602,917603,917604,917605,917606,917607,917608,917609,917610,917611,917612,917613,917614,917615,917616,917617,917618,917619,917620,917621,917622,917623,917624,917625,917626,917627,917628,917629,917630,917631,917760,917761,917762,917763,917764,917765,917766,917767,917768,917769,917770,917771,917772,917773,917774,917775,917776,917777,917778,917779,917780,917781,917782,917783,917784,917785,917786,917787,917788,917789,917790,917791,917792,917793,917794,917795,917796,917797,917798,917799,917800,917801,917802,917803,917804,917805,917806,917807,917808,917809,917810,917811,917812,917813,917814,917815,917816,917817,917818,917819,917820,917821,917822,917823,917824,917825,917826,917827,917828,917829,917830,917831,917832,917833,917834,917835,917836,917837,917838,917839,917840,917841,917842,917843,917844,917845,917846,917847,917848,917849,917850,917851,917852,917853,917854,917855,917856,917857,917858,917859,917860,917861,917862,917863,917864,917865,917866,917867,917868,917869,917870,917871,917872,917873,917874,917875,917876,917877,917878,917879,917880,917881,917882,917883,917884,917885,917886,917887,917888,917889,917890,917891,917892,917893,917894,917895,917896,917897,917898,917899,917900,917901,917902,917903,917904,917905,917906,917907,917908,917909,917910,917911,917912,917913,917914,917915,917916,917917,917918,917919,917920,917921,917922,917923,917924,917925,917926,917927,917928,917929,917930,917931,917932,917933,917934,917935,917936,917937,917938,917939,917940,917941,917942,917943,917944,917945,917946,917947,917948,917949,917950,917951,917952,917953,917954,917955,917956,917957,917958,917959,917960,917961,917962,917963,917964,917965,917966,917967,917968,917969,917970,917971,917972,917973,917974,917975,917976,917977,917978,917979,917980,917981,917982,917983,917984,917985,917986,917987,917988,917989,917990,917991,917992,917993,917994,917995,917996,917997,917998,917999],"cs":[173,8203,12288],"de":[173,8203,12288],"es":[8203,12288],"fr":[173,8203,12288],"it":[160,173,12288],"ja":[173],"ko":[173,12288],"pl":[173,8203,12288],"pt-BR":[173,8203,12288],"qps-ploc":[160,173,8203,12288],"ru":[173,12288],"tr":[160,173,8203,12288],"zh-hans":[160,173,8203,12288],"zh-hant":[173,12288]}')
    }
    static getData() {
      return this._data || (this._data = new Set([...Object.values(kt.getRawData())].flat())), this._data
    }
    static isInvisibleCharacter(e) {
      return kt.getData().has(e)
    }
    static get codePoints() {
      return kt.getData()
    }
  };
  kt._data = void 0;
  let Rt = kt;
  const Bn = "default",
    Go = "$initialize";
  class Xo {
    constructor(e, n, i, r, s) {
      this.vsWorker = e, this.req = n, this.channel = i, this.method = r, this.args = s, this.type = 0
    }
  }
  class Vi {
    constructor(e, n, i, r) {
      this.vsWorker = e, this.seq = n, this.res = i, this.err = r, this.type = 1
    }
  }
  class Jo {
    constructor(e, n, i, r, s) {
      this.vsWorker = e, this.req = n, this.channel = i, this.eventName = r, this.arg = s, this.type = 2
    }
  }
  class Qo {
    constructor(e, n, i) {
      this.vsWorker = e, this.req = n, this.event = i, this.type = 3
    }
  }
  class Yo {
    constructor(e, n) {
      this.vsWorker = e, this.req = n, this.type = 4
    }
  }
  class Zo {
    constructor(e) {
      this._workerId = -1, this._handler = e, this._lastSentReq = 0, this._pendingReplies = Object.create(null), this._pendingEmitters = new Map, this._pendingEvents = new Map
    }
    setWorkerId(e) {
      this._workerId = e
    }
    async sendMessage(e, n, i) {
      const r = String(++this._lastSentReq);
      return new Promise((s, a) => {
        this._pendingReplies[r] = {
          resolve: s,
          reject: a
        }, this._send(new Xo(this._workerId, r, e, n, i))
      })
    }
    listen(e, n, i) {
      let r = null;
      const s = new Re({
        onWillAddFirstListener: () => {
          r = String(++this._lastSentReq), this._pendingEmitters.set(r, s), this._send(new Jo(this._workerId, r, e, n, i))
        },
        onDidRemoveLastListener: () => {
          this._pendingEmitters.delete(r), this._send(new Yo(this._workerId, r)), r = null
        }
      });
      return s.event
    }
    handleMessage(e) {
      !e || !e.vsWorker || this._workerId !== -1 && e.vsWorker !== this._workerId || this._handleMessage(e)
    }
    createProxyToRemoteChannel(e, n) {
      const i = {
        get: (r, s) => (typeof s == "string" && !r[s] && ($i(s) ? r[s] = a => this.listen(e, s, a) : ji(s) ? r[s] = this.listen(e, s, void 0) : s.charCodeAt(0) === 36 && (r[s] = async (...a) => (await (n == null ? void 0 : n()), this.sendMessage(e, s, a)))), r[s])
      };
      return new Proxy(Object.create(null), i)
    }
    _handleMessage(e) {
      switch (e.type) {
        case 1:
          return this._handleReplyMessage(e);
        case 0:
          return this._handleRequestMessage(e);
        case 2:
          return this._handleSubscribeEventMessage(e);
        case 3:
          return this._handleEventMessage(e);
        case 4:
          return this._handleUnsubscribeEventMessage(e)
      }
    }
    _handleReplyMessage(e) {
      if (!this._pendingReplies[e.seq]) {
        console.warn("Got reply to unknown seq");
        return
      }
      const n = this._pendingReplies[e.seq];
      if (delete this._pendingReplies[e.seq], e.err) {
        let i = e.err;
        if (e.err.$isError) {
          const r = new Error;
          r.name = e.err.name, r.message = e.err.message, r.stack = e.err.stack, i = r
        }
        n.reject(i);
        return
      }
      n.resolve(e.res)
    }
    _handleRequestMessage(e) {
      const n = e.req;
      this._handler.handleMessage(e.channel, e.method, e.args).then(r => {
        this._send(new Vi(this._workerId, n, r, void 0))
      }, r => {
        r.detail instanceof Error && (r.detail = Cn(r.detail)), this._send(new Vi(this._workerId, n, void 0, Cn(r)))
      })
    }
    _handleSubscribeEventMessage(e) {
      const n = e.req,
        i = this._handler.handleEvent(e.channel, e.eventName, e.arg)(r => {
          this._send(new Qo(this._workerId, n, r))
        });
      this._pendingEvents.set(n, i)
    }
    _handleEventMessage(e) {
      if (!this._pendingEmitters.has(e.req)) {
        console.warn("Got event for unknown req");
        return
      }
      this._pendingEmitters.get(e.req).fire(e.event)
    }
    _handleUnsubscribeEventMessage(e) {
      if (!this._pendingEvents.has(e.req)) {
        console.warn("Got unsubscribe for unknown req");
        return
      }
      this._pendingEvents.get(e.req).dispose(), this._pendingEvents.delete(e.req)
    }
    _send(e) {
      const n = [];
      if (e.type === 0)
        for (let i = 0; i < e.args.length; i++) {
          const r = e.args[i];
          r instanceof ArrayBuffer && n.push(r)
        } else e.type === 1 && e.res instanceof ArrayBuffer && n.push(e.res);
      this._handler.sendMessage(e, n)
    }
  }

  function ji(t) {
    return t[0] === "o" && t[1] === "n" && Oi(t.charCodeAt(2))
  }

  function $i(t) {
    return /^onDynamic/.test(t) && Oi(t.charCodeAt(9))
  }
  class Ko {
    constructor(e, n) {
      this._localChannels = new Map, this._remoteChannels = new Map, this._protocol = new Zo({
        sendMessage: (i, r) => {
          e(i, r)
        },
        handleMessage: (i, r, s) => this._handleMessage(i, r, s),
        handleEvent: (i, r, s) => this._handleEvent(i, r, s)
      }), this.requestHandler = n(this)
    }
    onmessage(e) {
      this._protocol.handleMessage(e)
    }
    _handleMessage(e, n, i) {
      if (e === Bn && n === Go) return this.initialize(i[0]);
      const r = e === Bn ? this.requestHandler : this._localChannels.get(e);
      if (!r) return Promise.reject(new Error(`Missing channel ${e} on worker thread`));
      const s = r[n];
      if (typeof s != "function") return Promise.reject(new Error(`Missing method ${n} on worker thread channel ${e}`));
      try {
        return Promise.resolve(s.apply(r, i))
      } catch (a) {
        return Promise.reject(a)
      }
    }
    _handleEvent(e, n, i) {
      const r = e === Bn ? this.requestHandler : this._localChannels.get(e);
      if (!r) throw new Error(`Missing channel ${e} on worker thread`);
      if ($i(n)) {
        const s = r[n];
        if (typeof s != "function") throw new Error(`Missing dynamic event ${n} on request handler.`);
        const a = s.call(r, i);
        if (typeof a != "function") throw new Error(`Missing dynamic event ${n} on request handler.`);
        return a
      }
      if (ji(n)) {
        const s = r[n];
        if (typeof s != "function") throw new Error(`Missing event ${n} on request handler.`);
        return s
      }
      throw new Error(`Malformed event name ${n}`)
    }
    getChannel(e) {
      if (!this._remoteChannels.has(e)) {
        const n = this._protocol.createProxyToRemoteChannel(e);
        this._remoteChannels.set(e, n)
      }
      return this._remoteChannels.get(e)
    }
    async initialize(e) {
      this._protocol.setWorkerId(e)
    }
  }
  let Gi = !1;

  function el(t) {
    if (Gi) throw new Error("WebWorker already initialized!");
    Gi = !0;
    const e = new Ko(n => globalThis.postMessage(n), n => t(n));
    return globalThis.onmessage = n => {
      e.onmessage(n.data)
    }, e
  }
  class Ve {
    constructor(e, n, i, r) {
      this.originalStart = e, this.originalLength = n, this.modifiedStart = i, this.modifiedLength = r
    }
    getOriginalEnd() {
      return this.originalStart + this.originalLength
    }
    getModifiedEnd() {
      return this.modifiedStart + this.modifiedLength
    }
  }
  new Wn(() => new Uint8Array(256));

  function Xi(t, e) {
    return (e << 5) - e + t | 0
  }

  function tl(t, e) {
    e = Xi(149417, e);
    for (let n = 0, i = t.length; n < i; n++) e = Xi(t.charCodeAt(n), e);
    return e
  }
  class Ji {
    constructor(e) {
      this.source = e
    }
    getElements() {
      const e = this.source,
        n = new Int32Array(e.length);
      for (let i = 0, r = e.length; i < r; i++) n[i] = e.charCodeAt(i);
      return n
    }
  }

  function nl(t, e, n) {
    return new je(new Ji(t), new Ji(e)).ComputeDiff(n).changes
  }
  class lt {
    static Assert(e, n) {
      if (!e) throw new Error(n)
    }
  }
  class ut {
    static Copy(e, n, i, r, s) {
      for (let a = 0; a < s; a++) i[r + a] = e[n + a]
    }
    static Copy2(e, n, i, r, s) {
      for (let a = 0; a < s; a++) i[r + a] = e[n + a]
    }
  }
  class Qi {
    constructor() {
      this.m_changes = [], this.m_originalStart = 1073741824, this.m_modifiedStart = 1073741824, this.m_originalCount = 0, this.m_modifiedCount = 0
    }
    MarkNextChange() {
      (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.m_changes.push(new Ve(this.m_originalStart, this.m_originalCount, this.m_modifiedStart, this.m_modifiedCount)), this.m_originalCount = 0, this.m_modifiedCount = 0, this.m_originalStart = 1073741824, this.m_modifiedStart = 1073741824
    }
    AddOriginalElement(e, n) {
      this.m_originalStart = Math.min(this.m_originalStart, e), this.m_modifiedStart = Math.min(this.m_modifiedStart, n), this.m_originalCount++
    }
    AddModifiedElement(e, n) {
      this.m_originalStart = Math.min(this.m_originalStart, e), this.m_modifiedStart = Math.min(this.m_modifiedStart, n), this.m_modifiedCount++
    }
    getChanges() {
      return (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.MarkNextChange(), this.m_changes
    }
    getReverseChanges() {
      return (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.MarkNextChange(), this.m_changes.reverse(), this.m_changes
    }
  }
  class je {
    constructor(e, n, i = null) {
      this.ContinueProcessingPredicate = i, this._originalSequence = e, this._modifiedSequence = n;
      const [r, s, a] = je._getElements(e), [l, o, u] = je._getElements(n);
      this._hasStrings = a && u, this._originalStringElements = r, this._originalElementsOrHash = s, this._modifiedStringElements = l, this._modifiedElementsOrHash = o, this.m_forwardHistory = [], this.m_reverseHistory = []
    }
    static _isStringArray(e) {
      return e.length > 0 && typeof e[0] == "string"
    }
    static _getElements(e) {
      const n = e.getElements();
      if (je._isStringArray(n)) {
        const i = new Int32Array(n.length);
        for (let r = 0, s = n.length; r < s; r++) i[r] = tl(n[r], 0);
        return [n, i, !0]
      }
      return n instanceof Int32Array ? [
        [], n, !1
      ] : [
        [], new Int32Array(n), !1
      ]
    }
    ElementsAreEqual(e, n) {
      return this._originalElementsOrHash[e] !== this._modifiedElementsOrHash[n] ? !1 : this._hasStrings ? this._originalStringElements[e] === this._modifiedStringElements[n] : !0
    }
    ElementsAreStrictEqual(e, n) {
      if (!this.ElementsAreEqual(e, n)) return !1;
      const i = je._getStrictElement(this._originalSequence, e),
        r = je._getStrictElement(this._modifiedSequence, n);
      return i === r
    }
    static _getStrictElement(e, n) {
      return typeof e.getStrictElement == "function" ? e.getStrictElement(n) : null
    }
    OriginalElementsAreEqual(e, n) {
      return this._originalElementsOrHash[e] !== this._originalElementsOrHash[n] ? !1 : this._hasStrings ? this._originalStringElements[e] === this._originalStringElements[n] : !0
    }
    ModifiedElementsAreEqual(e, n) {
      return this._modifiedElementsOrHash[e] !== this._modifiedElementsOrHash[n] ? !1 : this._hasStrings ? this._modifiedStringElements[e] === this._modifiedStringElements[n] : !0
    }
    ComputeDiff(e) {
      return this._ComputeDiff(0, this._originalElementsOrHash.length - 1, 0, this._modifiedElementsOrHash.length - 1, e)
    }
    _ComputeDiff(e, n, i, r, s) {
      const a = [!1];
      let l = this.ComputeDiffRecursive(e, n, i, r, a);
      return s && (l = this.PrettifyChanges(l)), {
        quitEarly: a[0],
        changes: l
      }
    }
    ComputeDiffRecursive(e, n, i, r, s) {
      for (s[0] = !1; e <= n && i <= r && this.ElementsAreEqual(e, i);) e++, i++;
      for (; n >= e && r >= i && this.ElementsAreEqual(n, r);) n--, r--;
      if (e > n || i > r) {
        let d;
        return i <= r ? (lt.Assert(e === n + 1, "originalStart should only be one more than originalEnd"), d = [new Ve(e, 0, i, r - i + 1)]) : e <= n ? (lt.Assert(i === r + 1, "modifiedStart should only be one more than modifiedEnd"), d = [new Ve(e, n - e + 1, i, 0)]) : (lt.Assert(e === n + 1, "originalStart should only be one more than originalEnd"), lt.Assert(i === r + 1, "modifiedStart should only be one more than modifiedEnd"), d = []), d
      }
      const a = [0],
        l = [0],
        o = this.ComputeRecursionPoint(e, n, i, r, a, l, s),
        u = a[0],
        c = l[0];
      if (o !== null) return o;
      if (!s[0]) {
        const d = this.ComputeDiffRecursive(e, u, i, c, s);
        let m = [];
        return s[0] ? m = [new Ve(u + 1, n - (u + 1) + 1, c + 1, r - (c + 1) + 1)] : m = this.ComputeDiffRecursive(u + 1, n, c + 1, r, s), this.ConcatenateChanges(d, m)
      }
      return [new Ve(e, n - e + 1, i, r - i + 1)]
    }
    WALKTRACE(e, n, i, r, s, a, l, o, u, c, d, m, f, w, p, x, T, y) {
      let L = null,
        I = null,
        H = new Qi,
        P = n,
        b = i,
        g = f[0] - x[0] - r,
        _ = -1073741824,
        N = this.m_forwardHistory.length - 1;
      do {
        const S = g + e;
        S === P || S < b && u[S - 1] < u[S + 1] ? (d = u[S + 1], w = d - g - r, d < _ && H.MarkNextChange(), _ = d, H.AddModifiedElement(d + 1, w), g = S + 1 - e) : (d = u[S - 1] + 1, w = d - g - r, d < _ && H.MarkNextChange(), _ = d - 1, H.AddOriginalElement(d, w + 1), g = S - 1 - e), N >= 0 && (u = this.m_forwardHistory[N], e = u[0], P = 1, b = u.length - 1)
      } while (--N >= -1);
      if (L = H.getReverseChanges(), y[0]) {
        let S = f[0] + 1,
          v = x[0] + 1;
        if (L !== null && L.length > 0) {
          const A = L[L.length - 1];
          S = Math.max(S, A.getOriginalEnd()), v = Math.max(v, A.getModifiedEnd())
        }
        I = [new Ve(S, m - S + 1, v, p - v + 1)]
      } else {
        H = new Qi, P = a, b = l, g = f[0] - x[0] - o, _ = 1073741824, N = T ? this.m_reverseHistory.length - 1 : this.m_reverseHistory.length - 2;
        do {
          const S = g + s;
          S === P || S < b && c[S - 1] >= c[S + 1] ? (d = c[S + 1] - 1, w = d - g - o, d > _ && H.MarkNextChange(), _ = d + 1, H.AddOriginalElement(d + 1, w + 1), g = S + 1 - s) : (d = c[S - 1], w = d - g - o, d > _ && H.MarkNextChange(), _ = d, H.AddModifiedElement(d + 1, w + 1), g = S - 1 - s), N >= 0 && (c = this.m_reverseHistory[N], s = c[0], P = 1, b = c.length - 1)
        } while (--N >= -1);
        I = H.getChanges()
      }
      return this.ConcatenateChanges(L, I)
    }
    ComputeRecursionPoint(e, n, i, r, s, a, l) {
      let o = 0,
        u = 0,
        c = 0,
        d = 0,
        m = 0,
        f = 0;
      e--, i--, s[0] = 0, a[0] = 0, this.m_forwardHistory = [], this.m_reverseHistory = [];
      const w = n - e + (r - i),
        p = w + 1,
        x = new Int32Array(p),
        T = new Int32Array(p),
        y = r - i,
        L = n - e,
        I = e - i,
        H = n - r,
        b = (L - y) % 2 === 0;
      x[y] = e, T[L] = n, l[0] = !1;
      for (let g = 1; g <= w / 2 + 1; g++) {
        let _ = 0,
          N = 0;
        c = this.ClipDiagonalBound(y - g, g, y, p), d = this.ClipDiagonalBound(y + g, g, y, p);
        for (let v = c; v <= d; v += 2) {
          v === c || v < d && x[v - 1] < x[v + 1] ? o = x[v + 1] : o = x[v - 1] + 1, u = o - (v - y) - I;
          const A = o;
          for (; o < n && u < r && this.ElementsAreEqual(o + 1, u + 1);) o++, u++;
          if (x[v] = o, o + u > _ + N && (_ = o, N = u), !b && Math.abs(v - L) <= g - 1 && o >= T[v]) return s[0] = o, a[0] = u, A <= T[v] && g <= 1448 ? this.WALKTRACE(y, c, d, I, L, m, f, H, x, T, o, n, s, u, r, a, b, l) : null
        }
        const S = (_ - e + (N - i) - g) / 2;
        if (this.ContinueProcessingPredicate !== null && !this.ContinueProcessingPredicate(_, S)) return l[0] = !0, s[0] = _, a[0] = N, S > 0 && g <= 1448 ? this.WALKTRACE(y, c, d, I, L, m, f, H, x, T, o, n, s, u, r, a, b, l) : (e++, i++, [new Ve(e, n - e + 1, i, r - i + 1)]);
        m = this.ClipDiagonalBound(L - g, g, L, p), f = this.ClipDiagonalBound(L + g, g, L, p);
        for (let v = m; v <= f; v += 2) {
          v === m || v < f && T[v - 1] >= T[v + 1] ? o = T[v + 1] - 1 : o = T[v - 1], u = o - (v - L) - H;
          const A = o;
          for (; o > e && u > i && this.ElementsAreEqual(o, u);) o--, u--;
          if (T[v] = o, b && Math.abs(v - y) <= g && o <= x[v]) return s[0] = o, a[0] = u, A >= x[v] && g <= 1448 ? this.WALKTRACE(y, c, d, I, L, m, f, H, x, T, o, n, s, u, r, a, b, l) : null
        }
        if (g <= 1447) {
          let v = new Int32Array(d - c + 2);
          v[0] = y - c + 1, ut.Copy2(x, c, v, 1, d - c + 1), this.m_forwardHistory.push(v), v = new Int32Array(f - m + 2), v[0] = L - m + 1, ut.Copy2(T, m, v, 1, f - m + 1), this.m_reverseHistory.push(v)
        }
      }
      return this.WALKTRACE(y, c, d, I, L, m, f, H, x, T, o, n, s, u, r, a, b, l)
    }
    PrettifyChanges(e) {
      for (let n = 0; n < e.length; n++) {
        const i = e[n],
          r = n < e.length - 1 ? e[n + 1].originalStart : this._originalElementsOrHash.length,
          s = n < e.length - 1 ? e[n + 1].modifiedStart : this._modifiedElementsOrHash.length,
          a = i.originalLength > 0,
          l = i.modifiedLength > 0;
        for (; i.originalStart + i.originalLength < r && i.modifiedStart + i.modifiedLength < s && (!a || this.OriginalElementsAreEqual(i.originalStart, i.originalStart + i.originalLength)) && (!l || this.ModifiedElementsAreEqual(i.modifiedStart, i.modifiedStart + i.modifiedLength));) {
          const u = this.ElementsAreStrictEqual(i.originalStart, i.modifiedStart);
          if (this.ElementsAreStrictEqual(i.originalStart + i.originalLength, i.modifiedStart + i.modifiedLength) && !u) break;
          i.originalStart++, i.modifiedStart++
        }
        const o = [null];
        if (n < e.length - 1 && this.ChangesOverlap(e[n], e[n + 1], o)) {
          e[n] = o[0], e.splice(n + 1, 1), n--;
          continue
        }
      }
      for (let n = e.length - 1; n >= 0; n--) {
        const i = e[n];
        let r = 0,
          s = 0;
        if (n > 0) {
          const d = e[n - 1];
          r = d.originalStart + d.originalLength, s = d.modifiedStart + d.modifiedLength
        }
        const a = i.originalLength > 0,
          l = i.modifiedLength > 0;
        let o = 0,
          u = this._boundaryScore(i.originalStart, i.originalLength, i.modifiedStart, i.modifiedLength);
        for (let d = 1;; d++) {
          const m = i.originalStart - d,
            f = i.modifiedStart - d;
          if (m < r || f < s || a && !this.OriginalElementsAreEqual(m, m + i.originalLength) || l && !this.ModifiedElementsAreEqual(f, f + i.modifiedLength)) break;
          const p = (m === r && f === s ? 5 : 0) + this._boundaryScore(m, i.originalLength, f, i.modifiedLength);
          p > u && (u = p, o = d)
        }
        i.originalStart -= o, i.modifiedStart -= o;
        const c = [null];
        if (n > 0 && this.ChangesOverlap(e[n - 1], e[n], c)) {
          e[n - 1] = c[0], e.splice(n, 1), n++;
          continue
        }
      }
      if (this._hasStrings)
        for (let n = 1, i = e.length; n < i; n++) {
          const r = e[n - 1],
            s = e[n],
            a = s.originalStart - r.originalStart - r.originalLength,
            l = r.originalStart,
            o = s.originalStart + s.originalLength,
            u = o - l,
            c = r.modifiedStart,
            d = s.modifiedStart + s.modifiedLength,
            m = d - c;
          if (a < 5 && u < 20 && m < 20) {
            const f = this._findBetterContiguousSequence(l, u, c, m, a);
            if (f) {
              const [w, p] = f;
              (w !== r.originalStart + r.originalLength || p !== r.modifiedStart + r.modifiedLength) && (r.originalLength = w - r.originalStart, r.modifiedLength = p - r.modifiedStart, s.originalStart = w + a, s.modifiedStart = p + a, s.originalLength = o - s.originalStart, s.modifiedLength = d - s.modifiedStart)
            }
          }
        }
      return e
    }
    _findBetterContiguousSequence(e, n, i, r, s) {
      if (n < s || r < s) return null;
      const a = e + n - s + 1,
        l = i + r - s + 1;
      let o = 0,
        u = 0,
        c = 0;
      for (let d = e; d < a; d++)
        for (let m = i; m < l; m++) {
          const f = this._contiguousSequenceScore(d, m, s);
          f > 0 && f > o && (o = f, u = d, c = m)
        }
      return o > 0 ? [u, c] : null
    }
    _contiguousSequenceScore(e, n, i) {
      let r = 0;
      for (let s = 0; s < i; s++) {
        if (!this.ElementsAreEqual(e + s, n + s)) return 0;
        r += this._originalStringElements[e + s].length
      }
      return r
    }
    _OriginalIsBoundary(e) {
      return e <= 0 || e >= this._originalElementsOrHash.length - 1 ? !0 : this._hasStrings && /^\s*$/.test(this._originalStringElements[e])
    }
    _OriginalRegionIsBoundary(e, n) {
      if (this._OriginalIsBoundary(e) || this._OriginalIsBoundary(e - 1)) return !0;
      if (n > 0) {
        const i = e + n;
        if (this._OriginalIsBoundary(i - 1) || this._OriginalIsBoundary(i)) return !0
      }
      return !1
    }
    _ModifiedIsBoundary(e) {
      return e <= 0 || e >= this._modifiedElementsOrHash.length - 1 ? !0 : this._hasStrings && /^\s*$/.test(this._modifiedStringElements[e])
    }
    _ModifiedRegionIsBoundary(e, n) {
      if (this._ModifiedIsBoundary(e) || this._ModifiedIsBoundary(e - 1)) return !0;
      if (n > 0) {
        const i = e + n;
        if (this._ModifiedIsBoundary(i - 1) || this._ModifiedIsBoundary(i)) return !0
      }
      return !1
    }
    _boundaryScore(e, n, i, r) {
      const s = this._OriginalRegionIsBoundary(e, n) ? 1 : 0,
        a = this._ModifiedRegionIsBoundary(i, r) ? 1 : 0;
      return s + a
    }
    ConcatenateChanges(e, n) {
      const i = [];
      if (e.length === 0 || n.length === 0) return n.length > 0 ? n : e;
      if (this.ChangesOverlap(e[e.length - 1], n[0], i)) {
        const r = new Array(e.length + n.length - 1);
        return ut.Copy(e, 0, r, 0, e.length - 1), r[e.length - 1] = i[0], ut.Copy(n, 1, r, e.length, n.length - 1), r
      } else {
        const r = new Array(e.length + n.length);
        return ut.Copy(e, 0, r, 0, e.length), ut.Copy(n, 0, r, e.length, n.length), r
      }
    }
    ChangesOverlap(e, n, i) {
      if (lt.Assert(e.originalStart <= n.originalStart, "Left change is not less than or equal to right change"), lt.Assert(e.modifiedStart <= n.modifiedStart, "Left change is not less than or equal to right change"), e.originalStart + e.originalLength >= n.originalStart || e.modifiedStart + e.modifiedLength >= n.modifiedStart) {
        const r = e.originalStart;
        let s = e.originalLength;
        const a = e.modifiedStart;
        let l = e.modifiedLength;
        return e.originalStart + e.originalLength >= n.originalStart && (s = n.originalStart + n.originalLength - e.originalStart), e.modifiedStart + e.modifiedLength >= n.modifiedStart && (l = n.modifiedStart + n.modifiedLength - e.modifiedStart), i[0] = new Ve(r, s, a, l), !0
      } else return i[0] = null, !1
    }
    ClipDiagonalBound(e, n, i, r) {
      if (e >= 0 && e < r) return e;
      const s = i,
        a = r - i - 1,
        l = n % 2 === 0;
      if (e < 0) {
        const o = s % 2 === 0;
        return l === o ? 0 : 1
      } else {
        const o = a % 2 === 0;
        return l === o ? r - 1 : r - 2
      }
    }
  }
  let K = class st {
      constructor(e, n) {
        this.lineNumber = e, this.column = n
      }
      with(e = this.lineNumber, n = this.column) {
        return e === this.lineNumber && n === this.column ? this : new st(e, n)
      }
      delta(e = 0, n = 0) {
        return this.with(Math.max(1, this.lineNumber + e), Math.max(1, this.column + n))
      }
      equals(e) {
        return st.equals(this, e)
      }
      static equals(e, n) {
        return !e && !n ? !0 : !!e && !!n && e.lineNumber === n.lineNumber && e.column === n.column
      }
      isBefore(e) {
        return st.isBefore(this, e)
      }
      static isBefore(e, n) {
        return e.lineNumber < n.lineNumber ? !0 : n.lineNumber < e.lineNumber ? !1 : e.column < n.column
      }
      isBeforeOrEqual(e) {
        return st.isBeforeOrEqual(this, e)
      }
      static isBeforeOrEqual(e, n) {
        return e.lineNumber < n.lineNumber ? !0 : n.lineNumber < e.lineNumber ? !1 : e.column <= n.column
      }
      static compare(e, n) {
        const i = e.lineNumber | 0,
          r = n.lineNumber | 0;
        if (i === r) {
          const s = e.column | 0,
            a = n.column | 0;
          return s - a
        }
        return i - r
      }
      clone() {
        return new st(this.lineNumber, this.column)
      }
      toString() {
        return "(" + this.lineNumber + "," + this.column + ")"
      }
      static lift(e) {
        return new st(e.lineNumber, e.column)
      }
      static isIPosition(e) {
        return !!e && typeof e.lineNumber == "number" && typeof e.column == "number"
      }
      toJSON() {
        return {
          lineNumber: this.lineNumber,
          column: this.column
        }
      }
    },
    j = class re {
      constructor(e, n, i, r) {
        e > i || e === i && n > r ? (this.startLineNumber = i, this.startColumn = r, this.endLineNumber = e, this.endColumn = n) : (this.startLineNumber = e, this.startColumn = n, this.endLineNumber = i, this.endColumn = r)
      }
      isEmpty() {
        return re.isEmpty(this)
      }
      static isEmpty(e) {
        return e.startLineNumber === e.endLineNumber && e.startColumn === e.endColumn
      }
      containsPosition(e) {
        return re.containsPosition(this, e)
      }
      static containsPosition(e, n) {
        return !(n.lineNumber < e.startLineNumber || n.lineNumber > e.endLineNumber || n.lineNumber === e.startLineNumber && n.column < e.startColumn || n.lineNumber === e.endLineNumber && n.column > e.endColumn)
      }
      static strictContainsPosition(e, n) {
        return !(n.lineNumber < e.startLineNumber || n.lineNumber > e.endLineNumber || n.lineNumber === e.startLineNumber && n.column <= e.startColumn || n.lineNumber === e.endLineNumber && n.column >= e.endColumn)
      }
      containsRange(e) {
        return re.containsRange(this, e)
      }
      static containsRange(e, n) {
        return !(n.startLineNumber < e.startLineNumber || n.endLineNumber < e.startLineNumber || n.startLineNumber > e.endLineNumber || n.endLineNumber > e.endLineNumber || n.startLineNumber === e.startLineNumber && n.startColumn < e.startColumn || n.endLineNumber === e.endLineNumber && n.endColumn > e.endColumn)
      }
      strictContainsRange(e) {
        return re.strictContainsRange(this, e)
      }
      static strictContainsRange(e, n) {
        return !(n.startLineNumber < e.startLineNumber || n.endLineNumber < e.startLineNumber || n.startLineNumber > e.endLineNumber || n.endLineNumber > e.endLineNumber || n.startLineNumber === e.startLineNumber && n.startColumn <= e.startColumn || n.endLineNumber === e.endLineNumber && n.endColumn >= e.endColumn)
      }
      plusRange(e) {
        return re.plusRange(this, e)
      }
      static plusRange(e, n) {
        let i, r, s, a;
        return n.startLineNumber < e.startLineNumber ? (i = n.startLineNumber, r = n.startColumn) : n.startLineNumber === e.startLineNumber ? (i = n.startLineNumber, r = Math.min(n.startColumn, e.startColumn)) : (i = e.startLineNumber, r = e.startColumn), n.endLineNumber > e.endLineNumber ? (s = n.endLineNumber, a = n.endColumn) : n.endLineNumber === e.endLineNumber ? (s = n.endLineNumber, a = Math.max(n.endColumn, e.endColumn)) : (s = e.endLineNumber, a = e.endColumn), new re(i, r, s, a)
      }
      intersectRanges(e) {
        return re.intersectRanges(this, e)
      }
      static intersectRanges(e, n) {
        let i = e.startLineNumber,
          r = e.startColumn,
          s = e.endLineNumber,
          a = e.endColumn;
        const l = n.startLineNumber,
          o = n.startColumn,
          u = n.endLineNumber,
          c = n.endColumn;
        return i < l ? (i = l, r = o) : i === l && (r = Math.max(r, o)), s > u ? (s = u, a = c) : s === u && (a = Math.min(a, c)), i > s || i === s && r > a ? null : new re(i, r, s, a)
      }
      equalsRange(e) {
        return re.equalsRange(this, e)
      }
      static equalsRange(e, n) {
        return !e && !n ? !0 : !!e && !!n && e.startLineNumber === n.startLineNumber && e.startColumn === n.startColumn && e.endLineNumber === n.endLineNumber && e.endColumn === n.endColumn
      }
      getEndPosition() {
        return re.getEndPosition(this)
      }
      static getEndPosition(e) {
        return new K(e.endLineNumber, e.endColumn)
      }
      getStartPosition() {
        return re.getStartPosition(this)
      }
      static getStartPosition(e) {
        return new K(e.startLineNumber, e.startColumn)
      }
      toString() {
        return "[" + this.startLineNumber + "," + this.startColumn + " -> " + this.endLineNumber + "," + this.endColumn + "]"
      }
      setEndPosition(e, n) {
        return new re(this.startLineNumber, this.startColumn, e, n)
      }
      setStartPosition(e, n) {
        return new re(e, n, this.endLineNumber, this.endColumn)
      }
      collapseToStart() {
        return re.collapseToStart(this)
      }
      static collapseToStart(e) {
        return new re(e.startLineNumber, e.startColumn, e.startLineNumber, e.startColumn)
      }
      collapseToEnd() {
        return re.collapseToEnd(this)
      }
      static collapseToEnd(e) {
        return new re(e.endLineNumber, e.endColumn, e.endLineNumber, e.endColumn)
      }
      delta(e) {
        return new re(this.startLineNumber + e, this.startColumn, this.endLineNumber + e, this.endColumn)
      }
      isSingleLine() {
        return this.startLineNumber === this.endLineNumber
      }
      static fromPositions(e, n = e) {
        return new re(e.lineNumber, e.column, n.lineNumber, n.column)
      }
      static lift(e) {
        return e ? new re(e.startLineNumber, e.startColumn, e.endLineNumber, e.endColumn) : null
      }
      static isIRange(e) {
        return !!e && typeof e.startLineNumber == "number" && typeof e.startColumn == "number" && typeof e.endLineNumber == "number" && typeof e.endColumn == "number"
      }
      static areIntersectingOrTouching(e, n) {
        return !(e.endLineNumber < n.startLineNumber || e.endLineNumber === n.startLineNumber && e.endColumn < n.startColumn || n.endLineNumber < e.startLineNumber || n.endLineNumber === e.startLineNumber && n.endColumn < e.startColumn)
      }
      static areIntersecting(e, n) {
        return !(e.endLineNumber < n.startLineNumber || e.endLineNumber === n.startLineNumber && e.endColumn <= n.startColumn || n.endLineNumber < e.startLineNumber || n.endLineNumber === e.startLineNumber && n.endColumn <= e.startColumn)
      }
      static areOnlyIntersecting(e, n) {
        return !(e.endLineNumber < n.startLineNumber - 1 || e.endLineNumber === n.startLineNumber && e.endColumn < n.startColumn - 1 || n.endLineNumber < e.startLineNumber - 1 || n.endLineNumber === e.startLineNumber && n.endColumn < e.startColumn - 1)
      }
      static compareRangesUsingStarts(e, n) {
        if (e && n) {
          const s = e.startLineNumber | 0,
            a = n.startLineNumber | 0;
          if (s === a) {
            const l = e.startColumn | 0,
              o = n.startColumn | 0;
            if (l === o) {
              const u = e.endLineNumber | 0,
                c = n.endLineNumber | 0;
              if (u === c) {
                const d = e.endColumn | 0,
                  m = n.endColumn | 0;
                return d - m
              }
              return u - c
            }
            return l - o
          }
          return s - a
        }
        return (e ? 1 : 0) - (n ? 1 : 0)
      }
      static compareRangesUsingEnds(e, n) {
        return e.endLineNumber === n.endLineNumber ? e.endColumn === n.endColumn ? e.startLineNumber === n.startLineNumber ? e.startColumn - n.startColumn : e.startLineNumber - n.startLineNumber : e.endColumn - n.endColumn : e.endLineNumber - n.endLineNumber
      }
      static spansMultipleLines(e) {
        return e.endLineNumber > e.startLineNumber
      }
      toJSON() {
        return this
      }
    };

  function Yi(t) {
    return t < 0 ? 0 : t > 255 ? 255 : t | 0
  }

  function ct(t) {
    return t < 0 ? 0 : t > 4294967295 ? 4294967295 : t | 0
  }
  class qn {
    constructor(e) {
      const n = Yi(e);
      this._defaultValue = n, this._asciiMap = qn._createAsciiMap(n), this._map = new Map
    }
    static _createAsciiMap(e) {
      const n = new Uint8Array(256);
      return n.fill(e), n
    }
    set(e, n) {
      const i = Yi(n);
      e >= 0 && e < 256 ? this._asciiMap[e] = i : this._map.set(e, i)
    }
    get(e) {
      return e >= 0 && e < 256 ? this._asciiMap[e] : this._map.get(e) || this._defaultValue
    }
    clear() {
      this._asciiMap.fill(this._defaultValue), this._map.clear()
    }
  }
  class il {
    constructor(e, n, i) {
      const r = new Uint8Array(e * n);
      for (let s = 0, a = e * n; s < a; s++) r[s] = i;
      this._data = r, this.rows = e, this.cols = n
    }
    get(e, n) {
      return this._data[e * this.cols + n]
    }
    set(e, n, i) {
      this._data[e * this.cols + n] = i
    }
  }
  class rl {
    constructor(e) {
      let n = 0,
        i = 0;
      for (let s = 0, a = e.length; s < a; s++) {
        const [l, o, u] = e[s];
        o > n && (n = o), l > i && (i = l), u > i && (i = u)
      }
      n++, i++;
      const r = new il(i, n, 0);
      for (let s = 0, a = e.length; s < a; s++) {
        const [l, o, u] = e[s];
        r.set(l, o, u)
      }
      this._states = r, this._maxCharCode = n
    }
    nextState(e, n) {
      return n < 0 || n >= this._maxCharCode ? 0 : this._states.get(e, n)
    }
  }
  let On = null;

  function sl() {
    return On === null && (On = new rl([
      [1, 104, 2],
      [1, 72, 2],
      [1, 102, 6],
      [1, 70, 6],
      [2, 116, 3],
      [2, 84, 3],
      [3, 116, 4],
      [3, 84, 4],
      [4, 112, 5],
      [4, 80, 5],
      [5, 115, 9],
      [5, 83, 9],
      [5, 58, 10],
      [6, 105, 7],
      [6, 73, 7],
      [7, 108, 8],
      [7, 76, 8],
      [8, 101, 9],
      [8, 69, 9],
      [9, 58, 10],
      [10, 47, 11],
      [11, 47, 12]
    ])), On
  }
  let Dt = null;

  function al() {
    if (Dt === null) {
      Dt = new qn(0);
      const t = ` 	<>'"、。｡､，．：；‘〈「『〔（［｛｢｣｝］）〕』」〉’｀～…|`;
      for (let n = 0; n < t.length; n++) Dt.set(t.charCodeAt(n), 1);
      const e = ".,;:";
      for (let n = 0; n < e.length; n++) Dt.set(e.charCodeAt(n), 2)
    }
    return Dt
  }
  class Yt {
    static _createLink(e, n, i, r, s) {
      let a = s - 1;
      do {
        const l = n.charCodeAt(a);
        if (e.get(l) !== 2) break;
        a--
      } while (a > r);
      if (r > 0) {
        const l = n.charCodeAt(r - 1),
          o = n.charCodeAt(a);
        (l === 40 && o === 41 || l === 91 && o === 93 || l === 123 && o === 125) && a--
      }
      return {
        range: {
          startLineNumber: i,
          startColumn: r + 1,
          endLineNumber: i,
          endColumn: a + 2
        },
        url: n.substring(r, a + 1)
      }
    }
    static computeLinks(e, n = sl()) {
      const i = al(),
        r = [];
      for (let s = 1, a = e.getLineCount(); s <= a; s++) {
        const l = e.getLineContent(s),
          o = l.length;
        let u = 0,
          c = 0,
          d = 0,
          m = 1,
          f = !1,
          w = !1,
          p = !1,
          x = !1;
        for (; u < o;) {
          let T = !1;
          const y = l.charCodeAt(u);
          if (m === 13) {
            let L;
            switch (y) {
              case 40:
                f = !0, L = 0;
                break;
              case 41:
                L = f ? 0 : 1;
                break;
              case 91:
                p = !0, w = !0, L = 0;
                break;
              case 93:
                p = !1, L = w ? 0 : 1;
                break;
              case 123:
                x = !0, L = 0;
                break;
              case 125:
                L = x ? 0 : 1;
                break;
              case 39:
              case 34:
              case 96:
                d === y ? L = 1 : d === 39 || d === 34 || d === 96 ? L = 0 : L = 1;
                break;
              case 42:
                L = d === 42 ? 1 : 0;
                break;
              case 32:
                L = p ? 0 : 1;
                break;
              default:
                L = i.get(y)
            }
            L === 1 && (r.push(Yt._createLink(i, l, s, c, u)), T = !0)
          } else if (m === 12) {
            let L;
            y === 91 ? (w = !0, L = 0) : L = i.get(y), L === 1 ? T = !0 : m = 13
          } else m = n.nextState(m, y), m === 0 && (T = !0);
          T && (m = 1, f = !1, w = !1, x = !1, c = u + 1, d = y), u++
        }
        m === 13 && r.push(Yt._createLink(i, l, s, c, o))
      }
      return r
    }
  }

  function ol(t) {
    return !t || typeof t.getLineCount != "function" || typeof t.getLineContent != "function" ? [] : Yt.computeLinks(t)
  }
  const kn = class kn {
    constructor() {
      this._defaultValueSet = [
        ["true", "false"],
        ["True", "False"],
        ["Private", "Public", "Friend", "ReadOnly", "Partial", "Protected", "WriteOnly"],
        ["public", "protected", "private"]
      ]
    }
    navigateValueSet(e, n, i, r, s) {
      if (e && n) {
        const a = this.doNavigateValueSet(n, s);
        if (a) return {
          range: e,
          value: a
        }
      }
      if (i && r) {
        const a = this.doNavigateValueSet(r, s);
        if (a) return {
          range: i,
          value: a
        }
      }
      return null
    }
    doNavigateValueSet(e, n) {
      const i = this.numberReplace(e, n);
      return i !== null ? i : this.textReplace(e, n)
    }
    numberReplace(e, n) {
      const i = Math.pow(10, e.length - (e.lastIndexOf(".") + 1));
      let r = Number(e);
      const s = parseFloat(e);
      return !isNaN(r) && !isNaN(s) && r === s ? r === 0 && !n ? null : (r = Math.floor(r * i), r += n ? i : -i, String(r / i)) : null
    }
    textReplace(e, n) {
      return this.valueSetsReplace(this._defaultValueSet, e, n)
    }
    valueSetsReplace(e, n, i) {
      let r = null;
      for (let s = 0, a = e.length; r === null && s < a; s++) r = this.valueSetReplace(e[s], n, i);
      return r
    }
    valueSetReplace(e, n, i) {
      let r = e.indexOf(n);
      return r >= 0 ? (r += i ? 1 : -1, r < 0 ? r = e.length - 1 : r %= e.length, e[r]) : null
    }
  };
  kn.INSTANCE = new kn;
  let Vn = kn;
  const Zi = Object.freeze(function(t, e) {
    const n = setTimeout(t.bind(e), 0);
    return {
      dispose() {
        clearTimeout(n)
      }
    }
  });
  var Zt;
  (function(t) {
    function e(n) {
      return n === t.None || n === t.Cancelled || n instanceof Kt ? !0 : !n || typeof n != "object" ? !1 : typeof n.isCancellationRequested == "boolean" && typeof n.onCancellationRequested == "function"
    }
    t.isCancellationToken = e, t.None = Object.freeze({
      isCancellationRequested: !1,
      onCancellationRequested: Rn.None
    }), t.Cancelled = Object.freeze({
      isCancellationRequested: !0,
      onCancellationRequested: Zi
    })
  })(Zt || (Zt = {}));
  class Kt {
    constructor() {
      this._isCancelled = !1, this._emitter = null
    }
    cancel() {
      this._isCancelled || (this._isCancelled = !0, this._emitter && (this._emitter.fire(void 0), this.dispose()))
    }
    get isCancellationRequested() {
      return this._isCancelled
    }
    get onCancellationRequested() {
      return this._isCancelled ? Zi : (this._emitter || (this._emitter = new Re), this._emitter.event)
    }
    dispose() {
      this._emitter && (this._emitter.dispose(), this._emitter = null)
    }
  }
  class ll {
    constructor(e) {
      this._token = void 0, this._parentListener = void 0, this._parentListener = e && e.onCancellationRequested(this.cancel, this)
    }
    get token() {
      return this._token || (this._token = new Kt), this._token
    }
    cancel() {
      this._token ? this._token instanceof Kt && this._token.cancel() : this._token = Zt.Cancelled
    }
    dispose(e = !1) {
      var n;
      e && this.cancel(), (n = this._parentListener) == null || n.dispose(), this._token ? this._token instanceof Kt && this._token.dispose() : this._token = Zt.None
    }
  }
  class jn {
    constructor() {
      this._keyCodeToStr = [], this._strToKeyCode = Object.create(null)
    }
    define(e, n) {
      this._keyCodeToStr[e] = n, this._strToKeyCode[n.toLowerCase()] = e
    }
    keyCodeToStr(e) {
      return this._keyCodeToStr[e]
    }
    strToKeyCode(e) {
      return this._strToKeyCode[e.toLowerCase()] || 0
    }
  }
  const en = new jn,
    $n = new jn,
    Gn = new jn,
    ul = new Array(230),
    cl = Object.create(null),
    hl = Object.create(null);
  (function() {
    const e = [
        [1, 0, "None", 0, "unknown", 0, "VK_UNKNOWN", "", ""],
        [1, 1, "Hyper", 0, "", 0, "", "", ""],
        [1, 2, "Super", 0, "", 0, "", "", ""],
        [1, 3, "Fn", 0, "", 0, "", "", ""],
        [1, 4, "FnLock", 0, "", 0, "", "", ""],
        [1, 5, "Suspend", 0, "", 0, "", "", ""],
        [1, 6, "Resume", 0, "", 0, "", "", ""],
        [1, 7, "Turbo", 0, "", 0, "", "", ""],
        [1, 8, "Sleep", 0, "", 0, "VK_SLEEP", "", ""],
        [1, 9, "WakeUp", 0, "", 0, "", "", ""],
        [0, 10, "KeyA", 31, "A", 65, "VK_A", "", ""],
        [0, 11, "KeyB", 32, "B", 66, "VK_B", "", ""],
        [0, 12, "KeyC", 33, "C", 67, "VK_C", "", ""],
        [0, 13, "KeyD", 34, "D", 68, "VK_D", "", ""],
        [0, 14, "KeyE", 35, "E", 69, "VK_E", "", ""],
        [0, 15, "KeyF", 36, "F", 70, "VK_F", "", ""],
        [0, 16, "KeyG", 37, "G", 71, "VK_G", "", ""],
        [0, 17, "KeyH", 38, "H", 72, "VK_H", "", ""],
        [0, 18, "KeyI", 39, "I", 73, "VK_I", "", ""],
        [0, 19, "KeyJ", 40, "J", 74, "VK_J", "", ""],
        [0, 20, "KeyK", 41, "K", 75, "VK_K", "", ""],
        [0, 21, "KeyL", 42, "L", 76, "VK_L", "", ""],
        [0, 22, "KeyM", 43, "M", 77, "VK_M", "", ""],
        [0, 23, "KeyN", 44, "N", 78, "VK_N", "", ""],
        [0, 24, "KeyO", 45, "O", 79, "VK_O", "", ""],
        [0, 25, "KeyP", 46, "P", 80, "VK_P", "", ""],
        [0, 26, "KeyQ", 47, "Q", 81, "VK_Q", "", ""],
        [0, 27, "KeyR", 48, "R", 82, "VK_R", "", ""],
        [0, 28, "KeyS", 49, "S", 83, "VK_S", "", ""],
        [0, 29, "KeyT", 50, "T", 84, "VK_T", "", ""],
        [0, 30, "KeyU", 51, "U", 85, "VK_U", "", ""],
        [0, 31, "KeyV", 52, "V", 86, "VK_V", "", ""],
        [0, 32, "KeyW", 53, "W", 87, "VK_W", "", ""],
        [0, 33, "KeyX", 54, "X", 88, "VK_X", "", ""],
        [0, 34, "KeyY", 55, "Y", 89, "VK_Y", "", ""],
        [0, 35, "KeyZ", 56, "Z", 90, "VK_Z", "", ""],
        [0, 36, "Digit1", 22, "1", 49, "VK_1", "", ""],
        [0, 37, "Digit2", 23, "2", 50, "VK_2", "", ""],
        [0, 38, "Digit3", 24, "3", 51, "VK_3", "", ""],
        [0, 39, "Digit4", 25, "4", 52, "VK_4", "", ""],
        [0, 40, "Digit5", 26, "5", 53, "VK_5", "", ""],
        [0, 41, "Digit6", 27, "6", 54, "VK_6", "", ""],
        [0, 42, "Digit7", 28, "7", 55, "VK_7", "", ""],
        [0, 43, "Digit8", 29, "8", 56, "VK_8", "", ""],
        [0, 44, "Digit9", 30, "9", 57, "VK_9", "", ""],
        [0, 45, "Digit0", 21, "0", 48, "VK_0", "", ""],
        [1, 46, "Enter", 3, "Enter", 13, "VK_RETURN", "", ""],
        [1, 47, "Escape", 9, "Escape", 27, "VK_ESCAPE", "", ""],
        [1, 48, "Backspace", 1, "Backspace", 8, "VK_BACK", "", ""],
        [1, 49, "Tab", 2, "Tab", 9, "VK_TAB", "", ""],
        [1, 50, "Space", 10, "Space", 32, "VK_SPACE", "", ""],
        [0, 51, "Minus", 88, "-", 189, "VK_OEM_MINUS", "-", "OEM_MINUS"],
        [0, 52, "Equal", 86, "=", 187, "VK_OEM_PLUS", "=", "OEM_PLUS"],
        [0, 53, "BracketLeft", 92, "[", 219, "VK_OEM_4", "[", "OEM_4"],
        [0, 54, "BracketRight", 94, "]", 221, "VK_OEM_6", "]", "OEM_6"],
        [0, 55, "Backslash", 93, "\\", 220, "VK_OEM_5", "\\", "OEM_5"],
        [0, 56, "IntlHash", 0, "", 0, "", "", ""],
        [0, 57, "Semicolon", 85, ";", 186, "VK_OEM_1", ";", "OEM_1"],
        [0, 58, "Quote", 95, "'", 222, "VK_OEM_7", "'", "OEM_7"],
        [0, 59, "Backquote", 91, "`", 192, "VK_OEM_3", "`", "OEM_3"],
        [0, 60, "Comma", 87, ",", 188, "VK_OEM_COMMA", ",", "OEM_COMMA"],
        [0, 61, "Period", 89, ".", 190, "VK_OEM_PERIOD", ".", "OEM_PERIOD"],
        [0, 62, "Slash", 90, "/", 191, "VK_OEM_2", "/", "OEM_2"],
        [1, 63, "CapsLock", 8, "CapsLock", 20, "VK_CAPITAL", "", ""],
        [1, 64, "F1", 59, "F1", 112, "VK_F1", "", ""],
        [1, 65, "F2", 60, "F2", 113, "VK_F2", "", ""],
        [1, 66, "F3", 61, "F3", 114, "VK_F3", "", ""],
        [1, 67, "F4", 62, "F4", 115, "VK_F4", "", ""],
        [1, 68, "F5", 63, "F5", 116, "VK_F5", "", ""],
        [1, 69, "F6", 64, "F6", 117, "VK_F6", "", ""],
        [1, 70, "F7", 65, "F7", 118, "VK_F7", "", ""],
        [1, 71, "F8", 66, "F8", 119, "VK_F8", "", ""],
        [1, 72, "F9", 67, "F9", 120, "VK_F9", "", ""],
        [1, 73, "F10", 68, "F10", 121, "VK_F10", "", ""],
        [1, 74, "F11", 69, "F11", 122, "VK_F11", "", ""],
        [1, 75, "F12", 70, "F12", 123, "VK_F12", "", ""],
        [1, 76, "PrintScreen", 0, "", 0, "", "", ""],
        [1, 77, "ScrollLock", 84, "ScrollLock", 145, "VK_SCROLL", "", ""],
        [1, 78, "Pause", 7, "PauseBreak", 19, "VK_PAUSE", "", ""],
        [1, 79, "Insert", 19, "Insert", 45, "VK_INSERT", "", ""],
        [1, 80, "Home", 14, "Home", 36, "VK_HOME", "", ""],
        [1, 81, "PageUp", 11, "PageUp", 33, "VK_PRIOR", "", ""],
        [1, 82, "Delete", 20, "Delete", 46, "VK_DELETE", "", ""],
        [1, 83, "End", 13, "End", 35, "VK_END", "", ""],
        [1, 84, "PageDown", 12, "PageDown", 34, "VK_NEXT", "", ""],
        [1, 85, "ArrowRight", 17, "RightArrow", 39, "VK_RIGHT", "Right", ""],
        [1, 86, "ArrowLeft", 15, "LeftArrow", 37, "VK_LEFT", "Left", ""],
        [1, 87, "ArrowDown", 18, "DownArrow", 40, "VK_DOWN", "Down", ""],
        [1, 88, "ArrowUp", 16, "UpArrow", 38, "VK_UP", "Up", ""],
        [1, 89, "NumLock", 83, "NumLock", 144, "VK_NUMLOCK", "", ""],
        [1, 90, "NumpadDivide", 113, "NumPad_Divide", 111, "VK_DIVIDE", "", ""],
        [1, 91, "NumpadMultiply", 108, "NumPad_Multiply", 106, "VK_MULTIPLY", "", ""],
        [1, 92, "NumpadSubtract", 111, "NumPad_Subtract", 109, "VK_SUBTRACT", "", ""],
        [1, 93, "NumpadAdd", 109, "NumPad_Add", 107, "VK_ADD", "", ""],
        [1, 94, "NumpadEnter", 3, "", 0, "", "", ""],
        [1, 95, "Numpad1", 99, "NumPad1", 97, "VK_NUMPAD1", "", ""],
        [1, 96, "Numpad2", 100, "NumPad2", 98, "VK_NUMPAD2", "", ""],
        [1, 97, "Numpad3", 101, "NumPad3", 99, "VK_NUMPAD3", "", ""],
        [1, 98, "Numpad4", 102, "NumPad4", 100, "VK_NUMPAD4", "", ""],
        [1, 99, "Numpad5", 103, "NumPad5", 101, "VK_NUMPAD5", "", ""],
        [1, 100, "Numpad6", 104, "NumPad6", 102, "VK_NUMPAD6", "", ""],
        [1, 101, "Numpad7", 105, "NumPad7", 103, "VK_NUMPAD7", "", ""],
        [1, 102, "Numpad8", 106, "NumPad8", 104, "VK_NUMPAD8", "", ""],
        [1, 103, "Numpad9", 107, "NumPad9", 105, "VK_NUMPAD9", "", ""],
        [1, 104, "Numpad0", 98, "NumPad0", 96, "VK_NUMPAD0", "", ""],
        [1, 105, "NumpadDecimal", 112, "NumPad_Decimal", 110, "VK_DECIMAL", "", ""],
        [0, 106, "IntlBackslash", 97, "OEM_102", 226, "VK_OEM_102", "", ""],
        [1, 107, "ContextMenu", 58, "ContextMenu", 93, "", "", ""],
        [1, 108, "Power", 0, "", 0, "", "", ""],
        [1, 109, "NumpadEqual", 0, "", 0, "", "", ""],
        [1, 110, "F13", 71, "F13", 124, "VK_F13", "", ""],
        [1, 111, "F14", 72, "F14", 125, "VK_F14", "", ""],
        [1, 112, "F15", 73, "F15", 126, "VK_F15", "", ""],
        [1, 113, "F16", 74, "F16", 127, "VK_F16", "", ""],
        [1, 114, "F17", 75, "F17", 128, "VK_F17", "", ""],
        [1, 115, "F18", 76, "F18", 129, "VK_F18", "", ""],
        [1, 116, "F19", 77, "F19", 130, "VK_F19", "", ""],
        [1, 117, "F20", 78, "F20", 131, "VK_F20", "", ""],
        [1, 118, "F21", 79, "F21", 132, "VK_F21", "", ""],
        [1, 119, "F22", 80, "F22", 133, "VK_F22", "", ""],
        [1, 120, "F23", 81, "F23", 134, "VK_F23", "", ""],
        [1, 121, "F24", 82, "F24", 135, "VK_F24", "", ""],
        [1, 122, "Open", 0, "", 0, "", "", ""],
        [1, 123, "Help", 0, "", 0, "", "", ""],
        [1, 124, "Select", 0, "", 0, "", "", ""],
        [1, 125, "Again", 0, "", 0, "", "", ""],
        [1, 126, "Undo", 0, "", 0, "", "", ""],
        [1, 127, "Cut", 0, "", 0, "", "", ""],
        [1, 128, "Copy", 0, "", 0, "", "", ""],
        [1, 129, "Paste", 0, "", 0, "", "", ""],
        [1, 130, "Find", 0, "", 0, "", "", ""],
        [1, 131, "AudioVolumeMute", 117, "AudioVolumeMute", 173, "VK_VOLUME_MUTE", "", ""],
        [1, 132, "AudioVolumeUp", 118, "AudioVolumeUp", 175, "VK_VOLUME_UP", "", ""],
        [1, 133, "AudioVolumeDown", 119, "AudioVolumeDown", 174, "VK_VOLUME_DOWN", "", ""],
        [1, 134, "NumpadComma", 110, "NumPad_Separator", 108, "VK_SEPARATOR", "", ""],
        [0, 135, "IntlRo", 115, "ABNT_C1", 193, "VK_ABNT_C1", "", ""],
        [1, 136, "KanaMode", 0, "", 0, "", "", ""],
        [0, 137, "IntlYen", 0, "", 0, "", "", ""],
        [1, 138, "Convert", 0, "", 0, "", "", ""],
        [1, 139, "NonConvert", 0, "", 0, "", "", ""],
        [1, 140, "Lang1", 0, "", 0, "", "", ""],
        [1, 141, "Lang2", 0, "", 0, "", "", ""],
        [1, 142, "Lang3", 0, "", 0, "", "", ""],
        [1, 143, "Lang4", 0, "", 0, "", "", ""],
        [1, 144, "Lang5", 0, "", 0, "", "", ""],
        [1, 145, "Abort", 0, "", 0, "", "", ""],
        [1, 146, "Props", 0, "", 0, "", "", ""],
        [1, 147, "NumpadParenLeft", 0, "", 0, "", "", ""],
        [1, 148, "NumpadParenRight", 0, "", 0, "", "", ""],
        [1, 149, "NumpadBackspace", 0, "", 0, "", "", ""],
        [1, 150, "NumpadMemoryStore", 0, "", 0, "", "", ""],
        [1, 151, "NumpadMemoryRecall", 0, "", 0, "", "", ""],
        [1, 152, "NumpadMemoryClear", 0, "", 0, "", "", ""],
        [1, 153, "NumpadMemoryAdd", 0, "", 0, "", "", ""],
        [1, 154, "NumpadMemorySubtract", 0, "", 0, "", "", ""],
        [1, 155, "NumpadClear", 131, "Clear", 12, "VK_CLEAR", "", ""],
        [1, 156, "NumpadClearEntry", 0, "", 0, "", "", ""],
        [1, 0, "", 5, "Ctrl", 17, "VK_CONTROL", "", ""],
        [1, 0, "", 4, "Shift", 16, "VK_SHIFT", "", ""],
        [1, 0, "", 6, "Alt", 18, "VK_MENU", "", ""],
        [1, 0, "", 57, "Meta", 91, "VK_COMMAND", "", ""],
        [1, 157, "ControlLeft", 5, "", 0, "VK_LCONTROL", "", ""],
        [1, 158, "ShiftLeft", 4, "", 0, "VK_LSHIFT", "", ""],
        [1, 159, "AltLeft", 6, "", 0, "VK_LMENU", "", ""],
        [1, 160, "MetaLeft", 57, "", 0, "VK_LWIN", "", ""],
        [1, 161, "ControlRight", 5, "", 0, "VK_RCONTROL", "", ""],
        [1, 162, "ShiftRight", 4, "", 0, "VK_RSHIFT", "", ""],
        [1, 163, "AltRight", 6, "", 0, "VK_RMENU", "", ""],
        [1, 164, "MetaRight", 57, "", 0, "VK_RWIN", "", ""],
        [1, 165, "BrightnessUp", 0, "", 0, "", "", ""],
        [1, 166, "BrightnessDown", 0, "", 0, "", "", ""],
        [1, 167, "MediaPlay", 0, "", 0, "", "", ""],
        [1, 168, "MediaRecord", 0, "", 0, "", "", ""],
        [1, 169, "MediaFastForward", 0, "", 0, "", "", ""],
        [1, 170, "MediaRewind", 0, "", 0, "", "", ""],
        [1, 171, "MediaTrackNext", 124, "MediaTrackNext", 176, "VK_MEDIA_NEXT_TRACK", "", ""],
        [1, 172, "MediaTrackPrevious", 125, "MediaTrackPrevious", 177, "VK_MEDIA_PREV_TRACK", "", ""],
        [1, 173, "MediaStop", 126, "MediaStop", 178, "VK_MEDIA_STOP", "", ""],
        [1, 174, "Eject", 0, "", 0, "", "", ""],
        [1, 175, "MediaPlayPause", 127, "MediaPlayPause", 179, "VK_MEDIA_PLAY_PAUSE", "", ""],
        [1, 176, "MediaSelect", 128, "LaunchMediaPlayer", 181, "VK_MEDIA_LAUNCH_MEDIA_SELECT", "", ""],
        [1, 177, "LaunchMail", 129, "LaunchMail", 180, "VK_MEDIA_LAUNCH_MAIL", "", ""],
        [1, 178, "LaunchApp2", 130, "LaunchApp2", 183, "VK_MEDIA_LAUNCH_APP2", "", ""],
        [1, 179, "LaunchApp1", 0, "", 0, "VK_MEDIA_LAUNCH_APP1", "", ""],
        [1, 180, "SelectTask", 0, "", 0, "", "", ""],
        [1, 181, "LaunchScreenSaver", 0, "", 0, "", "", ""],
        [1, 182, "BrowserSearch", 120, "BrowserSearch", 170, "VK_BROWSER_SEARCH", "", ""],
        [1, 183, "BrowserHome", 121, "BrowserHome", 172, "VK_BROWSER_HOME", "", ""],
        [1, 184, "BrowserBack", 122, "BrowserBack", 166, "VK_BROWSER_BACK", "", ""],
        [1, 185, "BrowserForward", 123, "BrowserForward", 167, "VK_BROWSER_FORWARD", "", ""],
        [1, 186, "BrowserStop", 0, "", 0, "VK_BROWSER_STOP", "", ""],
        [1, 187, "BrowserRefresh", 0, "", 0, "VK_BROWSER_REFRESH", "", ""],
        [1, 188, "BrowserFavorites", 0, "", 0, "VK_BROWSER_FAVORITES", "", ""],
        [1, 189, "ZoomToggle", 0, "", 0, "", "", ""],
        [1, 190, "MailReply", 0, "", 0, "", "", ""],
        [1, 191, "MailForward", 0, "", 0, "", "", ""],
        [1, 192, "MailSend", 0, "", 0, "", "", ""],
        [1, 0, "", 114, "KeyInComposition", 229, "", "", ""],
        [1, 0, "", 116, "ABNT_C2", 194, "VK_ABNT_C2", "", ""],
        [1, 0, "", 96, "OEM_8", 223, "VK_OEM_8", "", ""],
        [1, 0, "", 0, "", 0, "VK_KANA", "", ""],
        [1, 0, "", 0, "", 0, "VK_HANGUL", "", ""],
        [1, 0, "", 0, "", 0, "VK_JUNJA", "", ""],
        [1, 0, "", 0, "", 0, "VK_FINAL", "", ""],
        [1, 0, "", 0, "", 0, "VK_HANJA", "", ""],
        [1, 0, "", 0, "", 0, "VK_KANJI", "", ""],
        [1, 0, "", 0, "", 0, "VK_CONVERT", "", ""],
        [1, 0, "", 0, "", 0, "VK_NONCONVERT", "", ""],
        [1, 0, "", 0, "", 0, "VK_ACCEPT", "", ""],
        [1, 0, "", 0, "", 0, "VK_MODECHANGE", "", ""],
        [1, 0, "", 0, "", 0, "VK_SELECT", "", ""],
        [1, 0, "", 0, "", 0, "VK_PRINT", "", ""],
        [1, 0, "", 0, "", 0, "VK_EXECUTE", "", ""],
        [1, 0, "", 0, "", 0, "VK_SNAPSHOT", "", ""],
        [1, 0, "", 0, "", 0, "VK_HELP", "", ""],
        [1, 0, "", 0, "", 0, "VK_APPS", "", ""],
        [1, 0, "", 0, "", 0, "VK_PROCESSKEY", "", ""],
        [1, 0, "", 0, "", 0, "VK_PACKET", "", ""],
        [1, 0, "", 0, "", 0, "VK_DBE_SBCSCHAR", "", ""],
        [1, 0, "", 0, "", 0, "VK_DBE_DBCSCHAR", "", ""],
        [1, 0, "", 0, "", 0, "VK_ATTN", "", ""],
        [1, 0, "", 0, "", 0, "VK_CRSEL", "", ""],
        [1, 0, "", 0, "", 0, "VK_EXSEL", "", ""],
        [1, 0, "", 0, "", 0, "VK_EREOF", "", ""],
        [1, 0, "", 0, "", 0, "VK_PLAY", "", ""],
        [1, 0, "", 0, "", 0, "VK_ZOOM", "", ""],
        [1, 0, "", 0, "", 0, "VK_NONAME", "", ""],
        [1, 0, "", 0, "", 0, "VK_PA1", "", ""],
        [1, 0, "", 0, "", 0, "VK_OEM_CLEAR", "", ""]
      ],
      n = [],
      i = [];
    for (const r of e) {
      const [s, a, l, o, u, c, d, m, f] = r;
      if (i[a] || (i[a] = !0, cl[l] = a, hl[l.toLowerCase()] = a), !n[o]) {
        if (n[o] = !0, !u) throw new Error(`String representation missing for key code ${o} around scan code ${l}`);
        en.define(o, u), $n.define(o, m || u), Gn.define(o, f || m || u)
      }
      c && (ul[c] = o)
    }
  })();
  var Ki;
  (function(t) {
    function e(l) {
      return en.keyCodeToStr(l)
    }
    t.toString = e;

    function n(l) {
      return en.strToKeyCode(l)
    }
    t.fromString = n;

    function i(l) {
      return $n.keyCodeToStr(l)
    }
    t.toUserSettingsUS = i;

    function r(l) {
      return Gn.keyCodeToStr(l)
    }
    t.toUserSettingsGeneral = r;

    function s(l) {
      return $n.strToKeyCode(l) || Gn.strToKeyCode(l)
    }
    t.fromUserSettings = s;

    function a(l) {
      if (l >= 98 && l <= 113) return null;
      switch (l) {
        case 16:
          return "Up";
        case 18:
          return "Down";
        case 15:
          return "Left";
        case 17:
          return "Right"
      }
      return en.keyCodeToStr(l)
    }
    t.toElectronAccelerator = a
  })(Ki || (Ki = {}));

  function dl(t, e) {
    const n = (e & 65535) << 16 >>> 0;
    return (t | n) >>> 0
  }
  var er = {};
  let ht;
  const Xn = globalThis.vscode;
  if (typeof Xn < "u" && typeof Xn.process < "u") {
    const t = Xn.process;
    ht = {
      get platform() {
        return t.platform
      },
      get arch() {
        return t.arch
      },
      get env() {
        return t.env
      },
      cwd() {
        return t.cwd()
      }
    }
  } else typeof process < "u" && typeof((uo = process == null ? void 0 : process.versions) == null ? void 0 : uo.node) == "string" ? ht = {
    get platform() {
      return process.platform
    },
    get arch() {
      return process.arch
    },
    get env() {
      return er
    },
    cwd() {
      return er.VSCODE_CWD || process.cwd()
    }
  } : ht = {
    get platform() {
      return Ct ? "win32" : Ro ? "darwin" : "linux"
    },
    get arch() {},
    get env() {
      return {}
    },
    cwd() {
      return "/"
    }
  };
  const tn = ht.cwd,
    ml = ht.env,
    fl = ht.platform,
    pl = 65,
    gl = 97,
    bl = 90,
    wl = 122,
    tt = 46,
    oe = 47,
    de = 92,
    Ue = 58,
    _l = 63;
  class tr extends Error {
    constructor(e, n, i) {
      let r;
      typeof n == "string" && n.indexOf("not ") === 0 ? (r = "must not be", n = n.replace(/^not /, "")) : r = "must be";
      const s = e.indexOf(".") !== -1 ? "property" : "argument";
      let a = `The "${e}" ${s} ${r} of type ${n}`;
      a += `. Received type ${typeof i}`, super(a), this.code = "ERR_INVALID_ARG_TYPE"
    }
  }

  function vl(t, e) {
    if (t === null || typeof t != "object") throw new tr(e, "Object", t)
  }

  function ie(t, e) {
    if (typeof t != "string") throw new tr(e, "string", t)
  }
  const $e = fl === "win32";

  function $(t) {
    return t === oe || t === de
  }

  function Jn(t) {
    return t === oe
  }

  function Pe(t) {
    return t >= pl && t <= bl || t >= gl && t <= wl
  }

  function nn(t, e, n, i) {
    let r = "",
      s = 0,
      a = -1,
      l = 0,
      o = 0;
    for (let u = 0; u <= t.length; ++u) {
      if (u < t.length) o = t.charCodeAt(u);
      else {
        if (i(o)) break;
        o = oe
      }
      if (i(o)) {
        if (!(a === u - 1 || l === 1))
          if (l === 2) {
            if (r.length < 2 || s !== 2 || r.charCodeAt(r.length - 1) !== tt || r.charCodeAt(r.length - 2) !== tt) {
              if (r.length > 2) {
                const c = r.lastIndexOf(n);
                c === -1 ? (r = "", s = 0) : (r = r.slice(0, c), s = r.length - 1 - r.lastIndexOf(n)), a = u, l = 0;
                continue
              } else if (r.length !== 0) {
                r = "", s = 0, a = u, l = 0;
                continue
              }
            }
            e && (r += r.length > 0 ? `${n}..` : "..", s = 2)
          } else r.length > 0 ? r += `${n}${t.slice(a+1,u)}` : r = t.slice(a + 1, u), s = u - a - 1;
        a = u, l = 0
      } else o === tt && l !== -1 ? ++l : l = -1
    }
    return r
  }

  function yl(t) {
    return t ? `${t[0]==="."?"":"."}${t}` : ""
  }

  function nr(t, e) {
    vl(e, "pathObject");
    const n = e.dir || e.root,
      i = e.base || `${e.name||""}${yl(e.ext)}`;
    return n ? n === e.root ? `${n}${i}` : `${n}${t}${i}` : i
  }
  const ce = {
      resolve(...t) {
        let e = "",
          n = "",
          i = !1;
        for (let r = t.length - 1; r >= -1; r--) {
          let s;
          if (r >= 0) {
            if (s = t[r], ie(s, `paths[${r}]`), s.length === 0) continue
          } else e.length === 0 ? s = tn() : (s = ml[`=${e}`] || tn(), (s === void 0 || s.slice(0, 2).toLowerCase() !== e.toLowerCase() && s.charCodeAt(2) === de) && (s = `${e}\\`));
          const a = s.length;
          let l = 0,
            o = "",
            u = !1;
          const c = s.charCodeAt(0);
          if (a === 1) $(c) && (l = 1, u = !0);
          else if ($(c))
            if (u = !0, $(s.charCodeAt(1))) {
              let d = 2,
                m = d;
              for (; d < a && !$(s.charCodeAt(d));) d++;
              if (d < a && d !== m) {
                const f = s.slice(m, d);
                for (m = d; d < a && $(s.charCodeAt(d));) d++;
                if (d < a && d !== m) {
                  for (m = d; d < a && !$(s.charCodeAt(d));) d++;
                  (d === a || d !== m) && (o = `\\\\${f}\\${s.slice(m,d)}`, l = d)
                }
              }
            } else l = 1;
          else Pe(c) && s.charCodeAt(1) === Ue && (o = s.slice(0, 2), l = 2, a > 2 && $(s.charCodeAt(2)) && (u = !0, l = 3));
          if (o.length > 0)
            if (e.length > 0) {
              if (o.toLowerCase() !== e.toLowerCase()) continue
            } else e = o;
          if (i) {
            if (e.length > 0) break
          } else if (n = `${s.slice(l)}\\${n}`, i = u, u && e.length > 0) break
        }
        return n = nn(n, !i, "\\", $), i ? `${e}\\${n}` : `${e}${n}` || "."
      },
      normalize(t) {
        ie(t, "path");
        const e = t.length;
        if (e === 0) return ".";
        let n = 0,
          i, r = !1;
        const s = t.charCodeAt(0);
        if (e === 1) return Jn(s) ? "\\" : t;
        if ($(s))
          if (r = !0, $(t.charCodeAt(1))) {
            let l = 2,
              o = l;
            for (; l < e && !$(t.charCodeAt(l));) l++;
            if (l < e && l !== o) {
              const u = t.slice(o, l);
              for (o = l; l < e && $(t.charCodeAt(l));) l++;
              if (l < e && l !== o) {
                for (o = l; l < e && !$(t.charCodeAt(l));) l++;
                if (l === e) return `\\\\${u}\\${t.slice(o)}\\`;
                l !== o && (i = `\\\\${u}\\${t.slice(o,l)}`, n = l)
              }
            }
          } else n = 1;
        else Pe(s) && t.charCodeAt(1) === Ue && (i = t.slice(0, 2), n = 2, e > 2 && $(t.charCodeAt(2)) && (r = !0, n = 3));
        let a = n < e ? nn(t.slice(n), !r, "\\", $) : "";
        if (a.length === 0 && !r && (a = "."), a.length > 0 && $(t.charCodeAt(e - 1)) && (a += "\\"), !r && i === void 0 && t.includes(":")) {
          if (a.length >= 2 && Pe(a.charCodeAt(0)) && a.charCodeAt(1) === Ue) return `.\\${a}`;
          let l = t.indexOf(":");
          do
            if (l === e - 1 || $(t.charCodeAt(l + 1))) return `.\\${a}`; while ((l = t.indexOf(":", l + 1)) !== -1)
        }
        return i === void 0 ? r ? `\\${a}` : a : r ? `${i}\\${a}` : `${i}${a}`
      },
      isAbsolute(t) {
        ie(t, "path");
        const e = t.length;
        if (e === 0) return !1;
        const n = t.charCodeAt(0);
        return $(n) || e > 2 && Pe(n) && t.charCodeAt(1) === Ue && $(t.charCodeAt(2))
      },
      join(...t) {
        if (t.length === 0) return ".";
        let e, n;
        for (let s = 0; s < t.length; ++s) {
          const a = t[s];
          ie(a, "path"), a.length > 0 && (e === void 0 ? e = n = a : e += `\\${a}`)
        }
        if (e === void 0) return ".";
        let i = !0,
          r = 0;
        if (typeof n == "string" && $(n.charCodeAt(0))) {
          ++r;
          const s = n.length;
          s > 1 && $(n.charCodeAt(1)) && (++r, s > 2 && ($(n.charCodeAt(2)) ? ++r : i = !1))
        }
        if (i) {
          for (; r < e.length && $(e.charCodeAt(r));) r++;
          r >= 2 && (e = `\\${e.slice(r)}`)
        }
        return ce.normalize(e)
      },
      relative(t, e) {
        if (ie(t, "from"), ie(e, "to"), t === e) return "";
        const n = ce.resolve(t),
          i = ce.resolve(e);
        if (n === i || (t = n.toLowerCase(), e = i.toLowerCase(), t === e)) return "";
        if (n.length !== t.length || i.length !== e.length) {
          const w = n.split("\\"),
            p = i.split("\\");
          w[w.length - 1] === "" && w.pop(), p[p.length - 1] === "" && p.pop();
          const x = w.length,
            T = p.length,
            y = x < T ? x : T;
          let L;
          for (L = 0; L < y && w[L].toLowerCase() === p[L].toLowerCase(); L++);
          return L === 0 ? i : L === y ? T > y ? p.slice(L).join("\\") : x > y ? "..\\".repeat(x - 1 - L) + ".." : "" : "..\\".repeat(x - L) + p.slice(L).join("\\")
        }
        let r = 0;
        for (; r < t.length && t.charCodeAt(r) === de;) r++;
        let s = t.length;
        for (; s - 1 > r && t.charCodeAt(s - 1) === de;) s--;
        const a = s - r;
        let l = 0;
        for (; l < e.length && e.charCodeAt(l) === de;) l++;
        let o = e.length;
        for (; o - 1 > l && e.charCodeAt(o - 1) === de;) o--;
        const u = o - l,
          c = a < u ? a : u;
        let d = -1,
          m = 0;
        for (; m < c; m++) {
          const w = t.charCodeAt(r + m);
          if (w !== e.charCodeAt(l + m)) break;
          w === de && (d = m)
        }
        if (m !== c) {
          if (d === -1) return i
        } else {
          if (u > c) {
            if (e.charCodeAt(l + m) === de) return i.slice(l + m + 1);
            if (m === 2) return i.slice(l + m)
          }
          a > c && (t.charCodeAt(r + m) === de ? d = m : m === 2 && (d = 3)), d === -1 && (d = 0)
        }
        let f = "";
        for (m = r + d + 1; m <= s; ++m)(m === s || t.charCodeAt(m) === de) && (f += f.length === 0 ? ".." : "\\..");
        return l += d, f.length > 0 ? `${f}${i.slice(l,o)}` : (i.charCodeAt(l) === de && ++l, i.slice(l, o))
      },
      toNamespacedPath(t) {
        if (typeof t != "string" || t.length === 0) return t;
        const e = ce.resolve(t);
        if (e.length <= 2) return t;
        if (e.charCodeAt(0) === de) {
          if (e.charCodeAt(1) === de) {
            const n = e.charCodeAt(2);
            if (n !== _l && n !== tt) return `\\\\?\\UNC\\${e.slice(2)}`
          }
        } else if (Pe(e.charCodeAt(0)) && e.charCodeAt(1) === Ue && e.charCodeAt(2) === de) return `\\\\?\\${e}`;
        return e
      },
      dirname(t) {
        ie(t, "path");
        const e = t.length;
        if (e === 0) return ".";
        let n = -1,
          i = 0;
        const r = t.charCodeAt(0);
        if (e === 1) return $(r) ? t : ".";
        if ($(r)) {
          if (n = i = 1, $(t.charCodeAt(1))) {
            let l = 2,
              o = l;
            for (; l < e && !$(t.charCodeAt(l));) l++;
            if (l < e && l !== o) {
              for (o = l; l < e && $(t.charCodeAt(l));) l++;
              if (l < e && l !== o) {
                for (o = l; l < e && !$(t.charCodeAt(l));) l++;
                if (l === e) return t;
                l !== o && (n = i = l + 1)
              }
            }
          }
        } else Pe(r) && t.charCodeAt(1) === Ue && (n = e > 2 && $(t.charCodeAt(2)) ? 3 : 2, i = n);
        let s = -1,
          a = !0;
        for (let l = e - 1; l >= i; --l)
          if ($(t.charCodeAt(l))) {
            if (!a) {
              s = l;
              break
            }
          } else a = !1;
        if (s === -1) {
          if (n === -1) return ".";
          s = n
        }
        return t.slice(0, s)
      },
      basename(t, e) {
        e !== void 0 && ie(e, "suffix"), ie(t, "path");
        let n = 0,
          i = -1,
          r = !0,
          s;
        if (t.length >= 2 && Pe(t.charCodeAt(0)) && t.charCodeAt(1) === Ue && (n = 2), e !== void 0 && e.length > 0 && e.length <= t.length) {
          if (e === t) return "";
          let a = e.length - 1,
            l = -1;
          for (s = t.length - 1; s >= n; --s) {
            const o = t.charCodeAt(s);
            if ($(o)) {
              if (!r) {
                n = s + 1;
                break
              }
            } else l === -1 && (r = !1, l = s + 1), a >= 0 && (o === e.charCodeAt(a) ? --a === -1 && (i = s) : (a = -1, i = l))
          }
          return n === i ? i = l : i === -1 && (i = t.length), t.slice(n, i)
        }
        for (s = t.length - 1; s >= n; --s)
          if ($(t.charCodeAt(s))) {
            if (!r) {
              n = s + 1;
              break
            }
          } else i === -1 && (r = !1, i = s + 1);
        return i === -1 ? "" : t.slice(n, i)
      },
      extname(t) {
        ie(t, "path");
        let e = 0,
          n = -1,
          i = 0,
          r = -1,
          s = !0,
          a = 0;
        t.length >= 2 && t.charCodeAt(1) === Ue && Pe(t.charCodeAt(0)) && (e = i = 2);
        for (let l = t.length - 1; l >= e; --l) {
          const o = t.charCodeAt(l);
          if ($(o)) {
            if (!s) {
              i = l + 1;
              break
            }
            continue
          }
          r === -1 && (s = !1, r = l + 1), o === tt ? n === -1 ? n = l : a !== 1 && (a = 1) : n !== -1 && (a = -1)
        }
        return n === -1 || r === -1 || a === 0 || a === 1 && n === r - 1 && n === i + 1 ? "" : t.slice(n, r)
      },
      format: nr.bind(null, "\\"),
      parse(t) {
        ie(t, "path");
        const e = {
          root: "",
          dir: "",
          base: "",
          ext: "",
          name: ""
        };
        if (t.length === 0) return e;
        const n = t.length;
        let i = 0,
          r = t.charCodeAt(0);
        if (n === 1) return $(r) ? (e.root = e.dir = t, e) : (e.base = e.name = t, e);
        if ($(r)) {
          if (i = 1, $(t.charCodeAt(1))) {
            let d = 2,
              m = d;
            for (; d < n && !$(t.charCodeAt(d));) d++;
            if (d < n && d !== m) {
              for (m = d; d < n && $(t.charCodeAt(d));) d++;
              if (d < n && d !== m) {
                for (m = d; d < n && !$(t.charCodeAt(d));) d++;
                d === n ? i = d : d !== m && (i = d + 1)
              }
            }
          }
        } else if (Pe(r) && t.charCodeAt(1) === Ue) {
          if (n <= 2) return e.root = e.dir = t, e;
          if (i = 2, $(t.charCodeAt(2))) {
            if (n === 3) return e.root = e.dir = t, e;
            i = 3
          }
        }
        i > 0 && (e.root = t.slice(0, i));
        let s = -1,
          a = i,
          l = -1,
          o = !0,
          u = t.length - 1,
          c = 0;
        for (; u >= i; --u) {
          if (r = t.charCodeAt(u), $(r)) {
            if (!o) {
              a = u + 1;
              break
            }
            continue
          }
          l === -1 && (o = !1, l = u + 1), r === tt ? s === -1 ? s = u : c !== 1 && (c = 1) : s !== -1 && (c = -1)
        }
        return l !== -1 && (s === -1 || c === 0 || c === 1 && s === l - 1 && s === a + 1 ? e.base = e.name = t.slice(a, l) : (e.name = t.slice(a, s), e.base = t.slice(a, l), e.ext = t.slice(s, l))), a > 0 && a !== i ? e.dir = t.slice(0, a - 1) : e.dir = e.root, e
      },
      sep: "\\",
      delimiter: ";",
      win32: null,
      posix: null
    },
    Tl = (() => {
      if ($e) {
        const t = /\\/g;
        return () => {
          const e = tn().replace(t, "/");
          return e.slice(e.indexOf("/"))
        }
      }
      return () => tn()
    })(),
    me = {
      resolve(...t) {
        let e = "",
          n = !1;
        for (let i = t.length - 1; i >= 0 && !n; i--) {
          const r = t[i];
          ie(r, `paths[${i}]`), r.length !== 0 && (e = `${r}/${e}`, n = r.charCodeAt(0) === oe)
        }
        if (!n) {
          const i = Tl();
          e = `${i}/${e}`, n = i.charCodeAt(0) === oe
        }
        return e = nn(e, !n, "/", Jn), n ? `/${e}` : e.length > 0 ? e : "."
      },
      normalize(t) {
        if (ie(t, "path"), t.length === 0) return ".";
        const e = t.charCodeAt(0) === oe,
          n = t.charCodeAt(t.length - 1) === oe;
        return t = nn(t, !e, "/", Jn), t.length === 0 ? e ? "/" : n ? "./" : "." : (n && (t += "/"), e ? `/${t}` : t)
      },
      isAbsolute(t) {
        return ie(t, "path"), t.length > 0 && t.charCodeAt(0) === oe
      },
      join(...t) {
        if (t.length === 0) return ".";
        const e = [];
        for (let n = 0; n < t.length; ++n) {
          const i = t[n];
          ie(i, "path"), i.length > 0 && e.push(i)
        }
        return e.length === 0 ? "." : me.normalize(e.join("/"))
      },
      relative(t, e) {
        if (ie(t, "from"), ie(e, "to"), t === e || (t = me.resolve(t), e = me.resolve(e), t === e)) return "";
        const n = 1,
          i = t.length,
          r = i - n,
          s = 1,
          a = e.length - s,
          l = r < a ? r : a;
        let o = -1,
          u = 0;
        for (; u < l; u++) {
          const d = t.charCodeAt(n + u);
          if (d !== e.charCodeAt(s + u)) break;
          d === oe && (o = u)
        }
        if (u === l)
          if (a > l) {
            if (e.charCodeAt(s + u) === oe) return e.slice(s + u + 1);
            if (u === 0) return e.slice(s + u)
          } else r > l && (t.charCodeAt(n + u) === oe ? o = u : u === 0 && (o = 0));
        let c = "";
        for (u = n + o + 1; u <= i; ++u)(u === i || t.charCodeAt(u) === oe) && (c += c.length === 0 ? ".." : "/..");
        return `${c}${e.slice(s+o)}`
      },
      toNamespacedPath(t) {
        return t
      },
      dirname(t) {
        if (ie(t, "path"), t.length === 0) return ".";
        const e = t.charCodeAt(0) === oe;
        let n = -1,
          i = !0;
        for (let r = t.length - 1; r >= 1; --r)
          if (t.charCodeAt(r) === oe) {
            if (!i) {
              n = r;
              break
            }
          } else i = !1;
        return n === -1 ? e ? "/" : "." : e && n === 1 ? "//" : t.slice(0, n)
      },
      basename(t, e) {
        e !== void 0 && ie(e, "suffix"), ie(t, "path");
        let n = 0,
          i = -1,
          r = !0,
          s;
        if (e !== void 0 && e.length > 0 && e.length <= t.length) {
          if (e === t) return "";
          let a = e.length - 1,
            l = -1;
          for (s = t.length - 1; s >= 0; --s) {
            const o = t.charCodeAt(s);
            if (o === oe) {
              if (!r) {
                n = s + 1;
                break
              }
            } else l === -1 && (r = !1, l = s + 1), a >= 0 && (o === e.charCodeAt(a) ? --a === -1 && (i = s) : (a = -1, i = l))
          }
          return n === i ? i = l : i === -1 && (i = t.length), t.slice(n, i)
        }
        for (s = t.length - 1; s >= 0; --s)
          if (t.charCodeAt(s) === oe) {
            if (!r) {
              n = s + 1;
              break
            }
          } else i === -1 && (r = !1, i = s + 1);
        return i === -1 ? "" : t.slice(n, i)
      },
      extname(t) {
        ie(t, "path");
        let e = -1,
          n = 0,
          i = -1,
          r = !0,
          s = 0;
        for (let a = t.length - 1; a >= 0; --a) {
          const l = t[a];
          if (l === "/") {
            if (!r) {
              n = a + 1;
              break
            }
            continue
          }
          i === -1 && (r = !1, i = a + 1), l === "." ? e === -1 ? e = a : s !== 1 && (s = 1) : e !== -1 && (s = -1)
        }
        return e === -1 || i === -1 || s === 0 || s === 1 && e === i - 1 && e === n + 1 ? "" : t.slice(e, i)
      },
      format: nr.bind(null, "/"),
      parse(t) {
        ie(t, "path");
        const e = {
          root: "",
          dir: "",
          base: "",
          ext: "",
          name: ""
        };
        if (t.length === 0) return e;
        const n = t.charCodeAt(0) === oe;
        let i;
        n ? (e.root = "/", i = 1) : i = 0;
        let r = -1,
          s = 0,
          a = -1,
          l = !0,
          o = t.length - 1,
          u = 0;
        for (; o >= i; --o) {
          const c = t.charCodeAt(o);
          if (c === oe) {
            if (!l) {
              s = o + 1;
              break
            }
            continue
          }
          a === -1 && (l = !1, a = o + 1), c === tt ? r === -1 ? r = o : u !== 1 && (u = 1) : r !== -1 && (u = -1)
        }
        if (a !== -1) {
          const c = s === 0 && n ? 1 : s;
          r === -1 || u === 0 || u === 1 && r === a - 1 && r === s + 1 ? e.base = e.name = t.slice(c, a) : (e.name = t.slice(c, r), e.base = t.slice(c, a), e.ext = t.slice(r, a))
        }
        return s > 0 ? e.dir = t.slice(0, s - 1) : n && (e.dir = "/"), e
      },
      sep: "/",
      delimiter: ":",
      win32: null,
      posix: null
    };
  me.win32 = ce.win32 = ce, me.posix = ce.posix = me, $e ? ce.normalize : me.normalize, $e ? ce.resolve : me.resolve, $e ? ce.relative : me.relative, $e ? ce.dirname : me.dirname, $e ? ce.basename : me.basename, $e ? ce.extname : me.extname, $e ? ce.sep : me.sep;
  const xl = /^\w[\w\d+.-]*$/,
    kl = /^\//,
    Sl = /^\/\//;

  function Al(t, e) {
    if (!t.scheme && e) throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${t.authority}", path: "${t.path}", query: "${t.query}", fragment: "${t.fragment}"}`);
    if (t.scheme && !xl.test(t.scheme)) throw new Error("[UriError]: Scheme contains illegal characters.");
    if (t.path) {
      if (t.authority) {
        if (!kl.test(t.path)) throw new Error('[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash ("/") character')
      } else if (Sl.test(t.path)) throw new Error('[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters ("//")')
    }
  }

  function Ll(t, e) {
    return !t && !e ? "file" : t
  }

  function Cl(t, e) {
    switch (t) {
      case "https":
      case "http":
      case "file":
        e ? e[0] !== Se && (e = Se + e) : e = Se;
        break
    }
    return e
  }
  const ee = "",
    Se = "/",
    El = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
  let Qn = class Ln {
    static isUri(e) {
      return e instanceof Ln ? !0 : !e || typeof e != "object" ? !1 : typeof e.authority == "string" && typeof e.fragment == "string" && typeof e.path == "string" && typeof e.query == "string" && typeof e.scheme == "string" && typeof e.fsPath == "string" && typeof e.with == "function" && typeof e.toString == "function"
    }
    constructor(e, n, i, r, s, a = !1) {
      typeof e == "object" ? (this.scheme = e.scheme || ee, this.authority = e.authority || ee, this.path = e.path || ee, this.query = e.query || ee, this.fragment = e.fragment || ee) : (this.scheme = Ll(e, a), this.authority = n || ee, this.path = Cl(this.scheme, i || ee), this.query = r || ee, this.fragment = s || ee, Al(this, a))
    }
    get fsPath() {
      return Yn(this, !1)
    }
    with(e) {
      if (!e) return this;
      let {
        scheme: n,
        authority: i,
        path: r,
        query: s,
        fragment: a
      } = e;
      return n === void 0 ? n = this.scheme : n === null && (n = ee), i === void 0 ? i = this.authority : i === null && (i = ee), r === void 0 ? r = this.path : r === null && (r = ee), s === void 0 ? s = this.query : s === null && (s = ee), a === void 0 ? a = this.fragment : a === null && (a = ee), n === this.scheme && i === this.authority && r === this.path && s === this.query && a === this.fragment ? this : new dt(n, i, r, s, a)
    }
    static parse(e, n = !1) {
      const i = El.exec(e);
      return i ? new dt(i[2] || ee, rn(i[4] || ee), rn(i[5] || ee), rn(i[7] || ee), rn(i[9] || ee), n) : new dt(ee, ee, ee, ee, ee)
    }
    static file(e) {
      let n = ee;
      if (Ct && (e = e.replace(/\\/g, Se)), e[0] === Se && e[1] === Se) {
        const i = e.indexOf(Se, 2);
        i === -1 ? (n = e.substring(2), e = Se) : (n = e.substring(2, i), e = e.substring(i) || Se)
      }
      return new dt("file", n, e, ee, ee)
    }
    static from(e, n) {
      return new dt(e.scheme, e.authority, e.path, e.query, e.fragment, n)
    }
    static joinPath(e, ...n) {
      if (!e.path) throw new Error("[UriError]: cannot call joinPath on URI without path");
      let i;
      return Ct && e.scheme === "file" ? i = Ln.file(ce.join(Yn(e, !0), ...n)).path : i = me.join(e.path, ...n), e.with({
        path: i
      })
    }
    toString(e = !1) {
      return Zn(this, e)
    }
    toJSON() {
      return this
    }
    static revive(e) {
      if (e) {
        if (e instanceof Ln) return e;
        {
          const n = new dt(e);
          return n._formatted = e.external ?? null, n._fsPath = e._sep === ir ? e.fsPath ?? null : null, n
        }
      } else return e
    }
  };
  const ir = Ct ? 1 : void 0;
  class dt extends Qn {
    constructor() {
      super(...arguments), this._formatted = null, this._fsPath = null
    }
    get fsPath() {
      return this._fsPath || (this._fsPath = Yn(this, !1)), this._fsPath
    }
    toString(e = !1) {
      return e ? Zn(this, !0) : (this._formatted || (this._formatted = Zn(this, !1)), this._formatted)
    }
    toJSON() {
      const e = {
        $mid: 1
      };
      return this._fsPath && (e.fsPath = this._fsPath, e._sep = ir), this._formatted && (e.external = this._formatted), this.path && (e.path = this.path), this.scheme && (e.scheme = this.scheme), this.authority && (e.authority = this.authority), this.query && (e.query = this.query), this.fragment && (e.fragment = this.fragment), e
    }
  }
  const rr = {
    58: "%3A",
    47: "%2F",
    63: "%3F",
    35: "%23",
    91: "%5B",
    93: "%5D",
    64: "%40",
    33: "%21",
    36: "%24",
    38: "%26",
    39: "%27",
    40: "%28",
    41: "%29",
    42: "%2A",
    43: "%2B",
    44: "%2C",
    59: "%3B",
    61: "%3D",
    32: "%20"
  };

  function sr(t, e, n) {
    let i, r = -1;
    for (let s = 0; s < t.length; s++) {
      const a = t.charCodeAt(s);
      if (a >= 97 && a <= 122 || a >= 65 && a <= 90 || a >= 48 && a <= 57 || a === 45 || a === 46 || a === 95 || a === 126 || e && a === 47 || n && a === 91 || n && a === 93 || n && a === 58) r !== -1 && (i += encodeURIComponent(t.substring(r, s)), r = -1), i !== void 0 && (i += t.charAt(s));
      else {
        i === void 0 && (i = t.substr(0, s));
        const l = rr[a];
        l !== void 0 ? (r !== -1 && (i += encodeURIComponent(t.substring(r, s)), r = -1), i += l) : r === -1 && (r = s)
      }
    }
    return r !== -1 && (i += encodeURIComponent(t.substring(r))), i !== void 0 ? i : t
  }

  function Rl(t) {
    let e;
    for (let n = 0; n < t.length; n++) {
      const i = t.charCodeAt(n);
      i === 35 || i === 63 ? (e === void 0 && (e = t.substr(0, n)), e += rr[i]) : e !== void 0 && (e += t[n])
    }
    return e !== void 0 ? e : t
  }

  function Yn(t, e) {
    let n;
    return t.authority && t.path.length > 1 && t.scheme === "file" ? n = `//${t.authority}${t.path}` : t.path.charCodeAt(0) === 47 && (t.path.charCodeAt(1) >= 65 && t.path.charCodeAt(1) <= 90 || t.path.charCodeAt(1) >= 97 && t.path.charCodeAt(1) <= 122) && t.path.charCodeAt(2) === 58 ? e ? n = t.path.substr(1) : n = t.path[1].toLowerCase() + t.path.substr(2) : n = t.path, Ct && (n = n.replace(/\//g, "\\")), n
  }

  function Zn(t, e) {
    const n = e ? Rl : sr;
    let i = "",
      {
        scheme: r,
        authority: s,
        path: a,
        query: l,
        fragment: o
      } = t;
    if (r && (i += r, i += ":"), (s || r === "file") && (i += Se, i += Se), s) {
      let u = s.indexOf("@");
      if (u !== -1) {
        const c = s.substr(0, u);
        s = s.substr(u + 1), u = c.lastIndexOf(":"), u === -1 ? i += n(c, !1, !1) : (i += n(c.substr(0, u), !1, !1), i += ":", i += n(c.substr(u + 1), !1, !0)), i += "@"
      }
      s = s.toLowerCase(), u = s.lastIndexOf(":"), u === -1 ? i += n(s, !1, !0) : (i += n(s.substr(0, u), !1, !0), i += s.substr(u))
    }
    if (a) {
      if (a.length >= 3 && a.charCodeAt(0) === 47 && a.charCodeAt(2) === 58) {
        const u = a.charCodeAt(1);
        u >= 65 && u <= 90 && (a = `/${String.fromCharCode(u+32)}:${a.substr(3)}`)
      } else if (a.length >= 2 && a.charCodeAt(1) === 58) {
        const u = a.charCodeAt(0);
        u >= 65 && u <= 90 && (a = `${String.fromCharCode(u+32)}:${a.substr(2)}`)
      }
      i += n(a, !0, !1)
    }
    return l && (i += "?", i += n(l, !1, !1)), o && (i += "#", i += e ? o : sr(o, !1, !1)), i
  }

  function ar(t) {
    try {
      return decodeURIComponent(t)
    } catch {
      return t.length > 3 ? t.substr(0, 3) + ar(t.substr(3)) : t
    }
  }
  const or = /(%[0-9A-Za-z][0-9A-Za-z])+/g;

  function rn(t) {
    return t.match(or) ? t.replace(or, e => ar(e)) : t
  }
  class ge extends j {
    constructor(e, n, i, r) {
      super(e, n, i, r), this.selectionStartLineNumber = e, this.selectionStartColumn = n, this.positionLineNumber = i, this.positionColumn = r
    }
    toString() {
      return "[" + this.selectionStartLineNumber + "," + this.selectionStartColumn + " -> " + this.positionLineNumber + "," + this.positionColumn + "]"
    }
    equalsSelection(e) {
      return ge.selectionsEqual(this, e)
    }
    static selectionsEqual(e, n) {
      return e.selectionStartLineNumber === n.selectionStartLineNumber && e.selectionStartColumn === n.selectionStartColumn && e.positionLineNumber === n.positionLineNumber && e.positionColumn === n.positionColumn
    }
    getDirection() {
      return this.selectionStartLineNumber === this.startLineNumber && this.selectionStartColumn === this.startColumn ? 0 : 1
    }
    setEndPosition(e, n) {
      return this.getDirection() === 0 ? new ge(this.startLineNumber, this.startColumn, e, n) : new ge(e, n, this.startLineNumber, this.startColumn)
    }
    getPosition() {
      return new K(this.positionLineNumber, this.positionColumn)
    }
    getSelectionStart() {
      return new K(this.selectionStartLineNumber, this.selectionStartColumn)
    }
    setStartPosition(e, n) {
      return this.getDirection() === 0 ? new ge(e, n, this.endLineNumber, this.endColumn) : new ge(this.endLineNumber, this.endColumn, e, n)
    }
    static fromPositions(e, n = e) {
      return new ge(e.lineNumber, e.column, n.lineNumber, n.column)
    }
    static fromRange(e, n) {
      return n === 0 ? new ge(e.startLineNumber, e.startColumn, e.endLineNumber, e.endColumn) : new ge(e.endLineNumber, e.endColumn, e.startLineNumber, e.startColumn)
    }
    static liftSelection(e) {
      return new ge(e.selectionStartLineNumber, e.selectionStartColumn, e.positionLineNumber, e.positionColumn)
    }
    static selectionsArrEqual(e, n) {
      if (e && !n || !e && n) return !1;
      if (!e && !n) return !0;
      if (e.length !== n.length) return !1;
      for (let i = 0, r = e.length; i < r; i++)
        if (!this.selectionsEqual(e[i], n[i])) return !1;
      return !0
    }
    static isISelection(e) {
      return !!e && typeof e.selectionStartLineNumber == "number" && typeof e.selectionStartColumn == "number" && typeof e.positionLineNumber == "number" && typeof e.positionColumn == "number"
    }
    static createWithDirection(e, n, i, r, s) {
      return s === 0 ? new ge(e, n, i, r) : new ge(i, r, e, n)
    }
  }
  const lr = Object.create(null);

  function h(t, e) {
    if (fo(e)) {
      const n = lr[e];
      if (n === void 0) throw new Error(`${t} references an unknown codicon: ${e}`);
      e = n
    }
    return lr[t] = e, {
      id: t
    }
  }
  const Dl = {
      add: h("add", 6e4),
      plus: h("plus", 6e4),
      gistNew: h("gist-new", 6e4),
      repoCreate: h("repo-create", 6e4),
      lightbulb: h("lightbulb", 60001),
      lightBulb: h("light-bulb", 60001),
      repo: h("repo", 60002),
      repoDelete: h("repo-delete", 60002),
      gistFork: h("gist-fork", 60003),
      repoForked: h("repo-forked", 60003),
      gitPullRequest: h("git-pull-request", 60004),
      gitPullRequestAbandoned: h("git-pull-request-abandoned", 60004),
      recordKeys: h("record-keys", 60005),
      keyboard: h("keyboard", 60005),
      tag: h("tag", 60006),
      gitPullRequestLabel: h("git-pull-request-label", 60006),
      tagAdd: h("tag-add", 60006),
      tagRemove: h("tag-remove", 60006),
      person: h("person", 60007),
      personFollow: h("person-follow", 60007),
      personOutline: h("person-outline", 60007),
      personFilled: h("person-filled", 60007),
      sourceControl: h("source-control", 60008),
      mirror: h("mirror", 60009),
      mirrorPublic: h("mirror-public", 60009),
      star: h("star", 60010),
      starAdd: h("star-add", 60010),
      starDelete: h("star-delete", 60010),
      starEmpty: h("star-empty", 60010),
      comment: h("comment", 60011),
      commentAdd: h("comment-add", 60011),
      alert: h("alert", 60012),
      warning: h("warning", 60012),
      search: h("search", 60013),
      searchSave: h("search-save", 60013),
      logOut: h("log-out", 60014),
      signOut: h("sign-out", 60014),
      logIn: h("log-in", 60015),
      signIn: h("sign-in", 60015),
      eye: h("eye", 60016),
      eyeUnwatch: h("eye-unwatch", 60016),
      eyeWatch: h("eye-watch", 60016),
      circleFilled: h("circle-filled", 60017),
      primitiveDot: h("primitive-dot", 60017),
      closeDirty: h("close-dirty", 60017),
      debugBreakpoint: h("debug-breakpoint", 60017),
      debugBreakpointDisabled: h("debug-breakpoint-disabled", 60017),
      debugHint: h("debug-hint", 60017),
      terminalDecorationSuccess: h("terminal-decoration-success", 60017),
      primitiveSquare: h("primitive-square", 60018),
      edit: h("edit", 60019),
      pencil: h("pencil", 60019),
      info: h("info", 60020),
      issueOpened: h("issue-opened", 60020),
      gistPrivate: h("gist-private", 60021),
      gitForkPrivate: h("git-fork-private", 60021),
      lock: h("lock", 60021),
      mirrorPrivate: h("mirror-private", 60021),
      close: h("close", 60022),
      removeClose: h("remove-close", 60022),
      x: h("x", 60022),
      repoSync: h("repo-sync", 60023),
      sync: h("sync", 60023),
      clone: h("clone", 60024),
      desktopDownload: h("desktop-download", 60024),
      beaker: h("beaker", 60025),
      microscope: h("microscope", 60025),
      vm: h("vm", 60026),
      deviceDesktop: h("device-desktop", 60026),
      file: h("file", 60027),
      more: h("more", 60028),
      ellipsis: h("ellipsis", 60028),
      kebabHorizontal: h("kebab-horizontal", 60028),
      mailReply: h("mail-reply", 60029),
      reply: h("reply", 60029),
      organization: h("organization", 60030),
      organizationFilled: h("organization-filled", 60030),
      organizationOutline: h("organization-outline", 60030),
      newFile: h("new-file", 60031),
      fileAdd: h("file-add", 60031),
      newFolder: h("new-folder", 60032),
      fileDirectoryCreate: h("file-directory-create", 60032),
      trash: h("trash", 60033),
      trashcan: h("trashcan", 60033),
      history: h("history", 60034),
      clock: h("clock", 60034),
      folder: h("folder", 60035),
      fileDirectory: h("file-directory", 60035),
      symbolFolder: h("symbol-folder", 60035),
      logoGithub: h("logo-github", 60036),
      markGithub: h("mark-github", 60036),
      github: h("github", 60036),
      terminal: h("terminal", 60037),
      console: h("console", 60037),
      repl: h("repl", 60037),
      zap: h("zap", 60038),
      symbolEvent: h("symbol-event", 60038),
      error: h("error", 60039),
      stop: h("stop", 60039),
      variable: h("variable", 60040),
      symbolVariable: h("symbol-variable", 60040),
      array: h("array", 60042),
      symbolArray: h("symbol-array", 60042),
      symbolModule: h("symbol-module", 60043),
      symbolPackage: h("symbol-package", 60043),
      symbolNamespace: h("symbol-namespace", 60043),
      symbolObject: h("symbol-object", 60043),
      symbolMethod: h("symbol-method", 60044),
      symbolFunction: h("symbol-function", 60044),
      symbolConstructor: h("symbol-constructor", 60044),
      symbolBoolean: h("symbol-boolean", 60047),
      symbolNull: h("symbol-null", 60047),
      symbolNumeric: h("symbol-numeric", 60048),
      symbolNumber: h("symbol-number", 60048),
      symbolStructure: h("symbol-structure", 60049),
      symbolStruct: h("symbol-struct", 60049),
      symbolParameter: h("symbol-parameter", 60050),
      symbolTypeParameter: h("symbol-type-parameter", 60050),
      symbolKey: h("symbol-key", 60051),
      symbolText: h("symbol-text", 60051),
      symbolReference: h("symbol-reference", 60052),
      goToFile: h("go-to-file", 60052),
      symbolEnum: h("symbol-enum", 60053),
      symbolValue: h("symbol-value", 60053),
      symbolRuler: h("symbol-ruler", 60054),
      symbolUnit: h("symbol-unit", 60054),
      activateBreakpoints: h("activate-breakpoints", 60055),
      archive: h("archive", 60056),
      arrowBoth: h("arrow-both", 60057),
      arrowDown: h("arrow-down", 60058),
      arrowLeft: h("arrow-left", 60059),
      arrowRight: h("arrow-right", 60060),
      arrowSmallDown: h("arrow-small-down", 60061),
      arrowSmallLeft: h("arrow-small-left", 60062),
      arrowSmallRight: h("arrow-small-right", 60063),
      arrowSmallUp: h("arrow-small-up", 60064),
      arrowUp: h("arrow-up", 60065),
      bell: h("bell", 60066),
      bold: h("bold", 60067),
      book: h("book", 60068),
      bookmark: h("bookmark", 60069),
      debugBreakpointConditionalUnverified: h("debug-breakpoint-conditional-unverified", 60070),
      debugBreakpointConditional: h("debug-breakpoint-conditional", 60071),
      debugBreakpointConditionalDisabled: h("debug-breakpoint-conditional-disabled", 60071),
      debugBreakpointDataUnverified: h("debug-breakpoint-data-unverified", 60072),
      debugBreakpointData: h("debug-breakpoint-data", 60073),
      debugBreakpointDataDisabled: h("debug-breakpoint-data-disabled", 60073),
      debugBreakpointLogUnverified: h("debug-breakpoint-log-unverified", 60074),
      debugBreakpointLog: h("debug-breakpoint-log", 60075),
      debugBreakpointLogDisabled: h("debug-breakpoint-log-disabled", 60075),
      briefcase: h("briefcase", 60076),
      broadcast: h("broadcast", 60077),
      browser: h("browser", 60078),
      bug: h("bug", 60079),
      calendar: h("calendar", 60080),
      caseSensitive: h("case-sensitive", 60081),
      check: h("check", 60082),
      checklist: h("checklist", 60083),
      chevronDown: h("chevron-down", 60084),
      chevronLeft: h("chevron-left", 60085),
      chevronRight: h("chevron-right", 60086),
      chevronUp: h("chevron-up", 60087),
      chromeClose: h("chrome-close", 60088),
      chromeMaximize: h("chrome-maximize", 60089),
      chromeMinimize: h("chrome-minimize", 60090),
      chromeRestore: h("chrome-restore", 60091),
      circleOutline: h("circle-outline", 60092),
      circle: h("circle", 60092),
      debugBreakpointUnverified: h("debug-breakpoint-unverified", 60092),
      terminalDecorationIncomplete: h("terminal-decoration-incomplete", 60092),
      circleSlash: h("circle-slash", 60093),
      circuitBoard: h("circuit-board", 60094),
      clearAll: h("clear-all", 60095),
      clippy: h("clippy", 60096),
      closeAll: h("close-all", 60097),
      cloudDownload: h("cloud-download", 60098),
      cloudUpload: h("cloud-upload", 60099),
      code: h("code", 60100),
      collapseAll: h("collapse-all", 60101),
      colorMode: h("color-mode", 60102),
      commentDiscussion: h("comment-discussion", 60103),
      creditCard: h("credit-card", 60105),
      dash: h("dash", 60108),
      dashboard: h("dashboard", 60109),
      database: h("database", 60110),
      debugContinue: h("debug-continue", 60111),
      debugDisconnect: h("debug-disconnect", 60112),
      debugPause: h("debug-pause", 60113),
      debugRestart: h("debug-restart", 60114),
      debugStart: h("debug-start", 60115),
      debugStepInto: h("debug-step-into", 60116),
      debugStepOut: h("debug-step-out", 60117),
      debugStepOver: h("debug-step-over", 60118),
      debugStop: h("debug-stop", 60119),
      debug: h("debug", 60120),
      deviceCameraVideo: h("device-camera-video", 60121),
      deviceCamera: h("device-camera", 60122),
      deviceMobile: h("device-mobile", 60123),
      diffAdded: h("diff-added", 60124),
      diffIgnored: h("diff-ignored", 60125),
      diffModified: h("diff-modified", 60126),
      diffRemoved: h("diff-removed", 60127),
      diffRenamed: h("diff-renamed", 60128),
      diff: h("diff", 60129),
      diffSidebyside: h("diff-sidebyside", 60129),
      discard: h("discard", 60130),
      editorLayout: h("editor-layout", 60131),
      emptyWindow: h("empty-window", 60132),
      exclude: h("exclude", 60133),
      extensions: h("extensions", 60134),
      eyeClosed: h("eye-closed", 60135),
      fileBinary: h("file-binary", 60136),
      fileCode: h("file-code", 60137),
      fileMedia: h("file-media", 60138),
      filePdf: h("file-pdf", 60139),
      fileSubmodule: h("file-submodule", 60140),
      fileSymlinkDirectory: h("file-symlink-directory", 60141),
      fileSymlinkFile: h("file-symlink-file", 60142),
      fileZip: h("file-zip", 60143),
      files: h("files", 60144),
      filter: h("filter", 60145),
      flame: h("flame", 60146),
      foldDown: h("fold-down", 60147),
      foldUp: h("fold-up", 60148),
      fold: h("fold", 60149),
      folderActive: h("folder-active", 60150),
      folderOpened: h("folder-opened", 60151),
      gear: h("gear", 60152),
      gift: h("gift", 60153),
      gistSecret: h("gist-secret", 60154),
      gist: h("gist", 60155),
      gitCommit: h("git-commit", 60156),
      gitCompare: h("git-compare", 60157),
      compareChanges: h("compare-changes", 60157),
      gitMerge: h("git-merge", 60158),
      githubAction: h("github-action", 60159),
      githubAlt: h("github-alt", 60160),
      globe: h("globe", 60161),
      grabber: h("grabber", 60162),
      graph: h("graph", 60163),
      gripper: h("gripper", 60164),
      heart: h("heart", 60165),
      home: h("home", 60166),
      horizontalRule: h("horizontal-rule", 60167),
      hubot: h("hubot", 60168),
      inbox: h("inbox", 60169),
      issueReopened: h("issue-reopened", 60171),
      issues: h("issues", 60172),
      italic: h("italic", 60173),
      jersey: h("jersey", 60174),
      json: h("json", 60175),
      kebabVertical: h("kebab-vertical", 60176),
      key: h("key", 60177),
      law: h("law", 60178),
      lightbulbAutofix: h("lightbulb-autofix", 60179),
      linkExternal: h("link-external", 60180),
      link: h("link", 60181),
      listOrdered: h("list-ordered", 60182),
      listUnordered: h("list-unordered", 60183),
      liveShare: h("live-share", 60184),
      loading: h("loading", 60185),
      location: h("location", 60186),
      mailRead: h("mail-read", 60187),
      mail: h("mail", 60188),
      markdown: h("markdown", 60189),
      megaphone: h("megaphone", 60190),
      mention: h("mention", 60191),
      milestone: h("milestone", 60192),
      gitPullRequestMilestone: h("git-pull-request-milestone", 60192),
      mortarBoard: h("mortar-board", 60193),
      move: h("move", 60194),
      multipleWindows: h("multiple-windows", 60195),
      mute: h("mute", 60196),
      noNewline: h("no-newline", 60197),
      note: h("note", 60198),
      octoface: h("octoface", 60199),
      openPreview: h("open-preview", 60200),
      package: h("package", 60201),
      paintcan: h("paintcan", 60202),
      pin: h("pin", 60203),
      play: h("play", 60204),
      run: h("run", 60204),
      plug: h("plug", 60205),
      preserveCase: h("preserve-case", 60206),
      preview: h("preview", 60207),
      project: h("project", 60208),
      pulse: h("pulse", 60209),
      question: h("question", 60210),
      quote: h("quote", 60211),
      radioTower: h("radio-tower", 60212),
      reactions: h("reactions", 60213),
      references: h("references", 60214),
      refresh: h("refresh", 60215),
      regex: h("regex", 60216),
      remoteExplorer: h("remote-explorer", 60217),
      remote: h("remote", 60218),
      remove: h("remove", 60219),
      replaceAll: h("replace-all", 60220),
      replace: h("replace", 60221),
      repoClone: h("repo-clone", 60222),
      repoForcePush: h("repo-force-push", 60223),
      repoPull: h("repo-pull", 60224),
      repoPush: h("repo-push", 60225),
      report: h("report", 60226),
      requestChanges: h("request-changes", 60227),
      rocket: h("rocket", 60228),
      rootFolderOpened: h("root-folder-opened", 60229),
      rootFolder: h("root-folder", 60230),
      rss: h("rss", 60231),
      ruby: h("ruby", 60232),
      saveAll: h("save-all", 60233),
      saveAs: h("save-as", 60234),
      save: h("save", 60235),
      screenFull: h("screen-full", 60236),
      screenNormal: h("screen-normal", 60237),
      searchStop: h("search-stop", 60238),
      server: h("server", 60240),
      settingsGear: h("settings-gear", 60241),
      settings: h("settings", 60242),
      shield: h("shield", 60243),
      smiley: h("smiley", 60244),
      sortPrecedence: h("sort-precedence", 60245),
      splitHorizontal: h("split-horizontal", 60246),
      splitVertical: h("split-vertical", 60247),
      squirrel: h("squirrel", 60248),
      starFull: h("star-full", 60249),
      starHalf: h("star-half", 60250),
      symbolClass: h("symbol-class", 60251),
      symbolColor: h("symbol-color", 60252),
      symbolConstant: h("symbol-constant", 60253),
      symbolEnumMember: h("symbol-enum-member", 60254),
      symbolField: h("symbol-field", 60255),
      symbolFile: h("symbol-file", 60256),
      symbolInterface: h("symbol-interface", 60257),
      symbolKeyword: h("symbol-keyword", 60258),
      symbolMisc: h("symbol-misc", 60259),
      symbolOperator: h("symbol-operator", 60260),
      symbolProperty: h("symbol-property", 60261),
      wrench: h("wrench", 60261),
      wrenchSubaction: h("wrench-subaction", 60261),
      symbolSnippet: h("symbol-snippet", 60262),
      tasklist: h("tasklist", 60263),
      telescope: h("telescope", 60264),
      textSize: h("text-size", 60265),
      threeBars: h("three-bars", 60266),
      thumbsdown: h("thumbsdown", 60267),
      thumbsup: h("thumbsup", 60268),
      tools: h("tools", 60269),
      triangleDown: h("triangle-down", 60270),
      triangleLeft: h("triangle-left", 60271),
      triangleRight: h("triangle-right", 60272),
      triangleUp: h("triangle-up", 60273),
      twitter: h("twitter", 60274),
      unfold: h("unfold", 60275),
      unlock: h("unlock", 60276),
      unmute: h("unmute", 60277),
      unverified: h("unverified", 60278),
      verified: h("verified", 60279),
      versions: h("versions", 60280),
      vmActive: h("vm-active", 60281),
      vmOutline: h("vm-outline", 60282),
      vmRunning: h("vm-running", 60283),
      watch: h("watch", 60284),
      whitespace: h("whitespace", 60285),
      wholeWord: h("whole-word", 60286),
      window: h("window", 60287),
      wordWrap: h("word-wrap", 60288),
      zoomIn: h("zoom-in", 60289),
      zoomOut: h("zoom-out", 60290),
      listFilter: h("list-filter", 60291),
      listFlat: h("list-flat", 60292),
      listSelection: h("list-selection", 60293),
      selection: h("selection", 60293),
      listTree: h("list-tree", 60294),
      debugBreakpointFunctionUnverified: h("debug-breakpoint-function-unverified", 60295),
      debugBreakpointFunction: h("debug-breakpoint-function", 60296),
      debugBreakpointFunctionDisabled: h("debug-breakpoint-function-disabled", 60296),
      debugStackframeActive: h("debug-stackframe-active", 60297),
      circleSmallFilled: h("circle-small-filled", 60298),
      debugStackframeDot: h("debug-stackframe-dot", 60298),
      terminalDecorationMark: h("terminal-decoration-mark", 60298),
      debugStackframe: h("debug-stackframe", 60299),
      debugStackframeFocused: h("debug-stackframe-focused", 60299),
      debugBreakpointUnsupported: h("debug-breakpoint-unsupported", 60300),
      symbolString: h("symbol-string", 60301),
      debugReverseContinue: h("debug-reverse-continue", 60302),
      debugStepBack: h("debug-step-back", 60303),
      debugRestartFrame: h("debug-restart-frame", 60304),
      debugAlt: h("debug-alt", 60305),
      callIncoming: h("call-incoming", 60306),
      callOutgoing: h("call-outgoing", 60307),
      menu: h("menu", 60308),
      expandAll: h("expand-all", 60309),
      feedback: h("feedback", 60310),
      gitPullRequestReviewer: h("git-pull-request-reviewer", 60310),
      groupByRefType: h("group-by-ref-type", 60311),
      ungroupByRefType: h("ungroup-by-ref-type", 60312),
      account: h("account", 60313),
      gitPullRequestAssignee: h("git-pull-request-assignee", 60313),
      bellDot: h("bell-dot", 60314),
      debugConsole: h("debug-console", 60315),
      library: h("library", 60316),
      output: h("output", 60317),
      runAll: h("run-all", 60318),
      syncIgnored: h("sync-ignored", 60319),
      pinned: h("pinned", 60320),
      githubInverted: h("github-inverted", 60321),
      serverProcess: h("server-process", 60322),
      serverEnvironment: h("server-environment", 60323),
      pass: h("pass", 60324),
      issueClosed: h("issue-closed", 60324),
      stopCircle: h("stop-circle", 60325),
      playCircle: h("play-circle", 60326),
      record: h("record", 60327),
      debugAltSmall: h("debug-alt-small", 60328),
      vmConnect: h("vm-connect", 60329),
      cloud: h("cloud", 60330),
      merge: h("merge", 60331),
      export: h("export", 60332),
      graphLeft: h("graph-left", 60333),
      magnet: h("magnet", 60334),
      notebook: h("notebook", 60335),
      redo: h("redo", 60336),
      checkAll: h("check-all", 60337),
      pinnedDirty: h("pinned-dirty", 60338),
      passFilled: h("pass-filled", 60339),
      circleLargeFilled: h("circle-large-filled", 60340),
      circleLarge: h("circle-large", 60341),
      circleLargeOutline: h("circle-large-outline", 60341),
      combine: h("combine", 60342),
      gather: h("gather", 60342),
      table: h("table", 60343),
      variableGroup: h("variable-group", 60344),
      typeHierarchy: h("type-hierarchy", 60345),
      typeHierarchySub: h("type-hierarchy-sub", 60346),
      typeHierarchySuper: h("type-hierarchy-super", 60347),
      gitPullRequestCreate: h("git-pull-request-create", 60348),
      runAbove: h("run-above", 60349),
      runBelow: h("run-below", 60350),
      notebookTemplate: h("notebook-template", 60351),
      debugRerun: h("debug-rerun", 60352),
      workspaceTrusted: h("workspace-trusted", 60353),
      workspaceUntrusted: h("workspace-untrusted", 60354),
      workspaceUnknown: h("workspace-unknown", 60355),
      terminalCmd: h("terminal-cmd", 60356),
      terminalDebian: h("terminal-debian", 60357),
      terminalLinux: h("terminal-linux", 60358),
      terminalPowershell: h("terminal-powershell", 60359),
      terminalTmux: h("terminal-tmux", 60360),
      terminalUbuntu: h("terminal-ubuntu", 60361),
      terminalBash: h("terminal-bash", 60362),
      arrowSwap: h("arrow-swap", 60363),
      copy: h("copy", 60364),
      personAdd: h("person-add", 60365),
      filterFilled: h("filter-filled", 60366),
      wand: h("wand", 60367),
      debugLineByLine: h("debug-line-by-line", 60368),
      inspect: h("inspect", 60369),
      layers: h("layers", 60370),
      layersDot: h("layers-dot", 60371),
      layersActive: h("layers-active", 60372),
      compass: h("compass", 60373),
      compassDot: h("compass-dot", 60374),
      compassActive: h("compass-active", 60375),
      azure: h("azure", 60376),
      issueDraft: h("issue-draft", 60377),
      gitPullRequestClosed: h("git-pull-request-closed", 60378),
      gitPullRequestDraft: h("git-pull-request-draft", 60379),
      debugAll: h("debug-all", 60380),
      debugCoverage: h("debug-coverage", 60381),
      runErrors: h("run-errors", 60382),
      folderLibrary: h("folder-library", 60383),
      debugContinueSmall: h("debug-continue-small", 60384),
      beakerStop: h("beaker-stop", 60385),
      graphLine: h("graph-line", 60386),
      graphScatter: h("graph-scatter", 60387),
      pieChart: h("pie-chart", 60388),
      bracket: h("bracket", 60175),
      bracketDot: h("bracket-dot", 60389),
      bracketError: h("bracket-error", 60390),
      lockSmall: h("lock-small", 60391),
      azureDevops: h("azure-devops", 60392),
      verifiedFilled: h("verified-filled", 60393),
      newline: h("newline", 60394),
      layout: h("layout", 60395),
      layoutActivitybarLeft: h("layout-activitybar-left", 60396),
      layoutActivitybarRight: h("layout-activitybar-right", 60397),
      layoutPanelLeft: h("layout-panel-left", 60398),
      layoutPanelCenter: h("layout-panel-center", 60399),
      layoutPanelJustify: h("layout-panel-justify", 60400),
      layoutPanelRight: h("layout-panel-right", 60401),
      layoutPanel: h("layout-panel", 60402),
      layoutSidebarLeft: h("layout-sidebar-left", 60403),
      layoutSidebarRight: h("layout-sidebar-right", 60404),
      layoutStatusbar: h("layout-statusbar", 60405),
      layoutMenubar: h("layout-menubar", 60406),
      layoutCentered: h("layout-centered", 60407),
      target: h("target", 60408),
      indent: h("indent", 60409),
      recordSmall: h("record-small", 60410),
      errorSmall: h("error-small", 60411),
      terminalDecorationError: h("terminal-decoration-error", 60411),
      arrowCircleDown: h("arrow-circle-down", 60412),
      arrowCircleLeft: h("arrow-circle-left", 60413),
      arrowCircleRight: h("arrow-circle-right", 60414),
      arrowCircleUp: h("arrow-circle-up", 60415),
      layoutSidebarRightOff: h("layout-sidebar-right-off", 60416),
      layoutPanelOff: h("layout-panel-off", 60417),
      layoutSidebarLeftOff: h("layout-sidebar-left-off", 60418),
      blank: h("blank", 60419),
      heartFilled: h("heart-filled", 60420),
      map: h("map", 60421),
      mapHorizontal: h("map-horizontal", 60421),
      foldHorizontal: h("fold-horizontal", 60421),
      mapFilled: h("map-filled", 60422),
      mapHorizontalFilled: h("map-horizontal-filled", 60422),
      foldHorizontalFilled: h("fold-horizontal-filled", 60422),
      circleSmall: h("circle-small", 60423),
      bellSlash: h("bell-slash", 60424),
      bellSlashDot: h("bell-slash-dot", 60425),
      commentUnresolved: h("comment-unresolved", 60426),
      gitPullRequestGoToChanges: h("git-pull-request-go-to-changes", 60427),
      gitPullRequestNewChanges: h("git-pull-request-new-changes", 60428),
      searchFuzzy: h("search-fuzzy", 60429),
      commentDraft: h("comment-draft", 60430),
      send: h("send", 60431),
      sparkle: h("sparkle", 60432),
      insert: h("insert", 60433),
      mic: h("mic", 60434),
      thumbsdownFilled: h("thumbsdown-filled", 60435),
      thumbsupFilled: h("thumbsup-filled", 60436),
      coffee: h("coffee", 60437),
      snake: h("snake", 60438),
      game: h("game", 60439),
      vr: h("vr", 60440),
      chip: h("chip", 60441),
      piano: h("piano", 60442),
      music: h("music", 60443),
      micFilled: h("mic-filled", 60444),
      repoFetch: h("repo-fetch", 60445),
      copilot: h("copilot", 60446),
      lightbulbSparkle: h("lightbulb-sparkle", 60447),
      robot: h("robot", 60448),
      sparkleFilled: h("sparkle-filled", 60449),
      diffSingle: h("diff-single", 60450),
      diffMultiple: h("diff-multiple", 60451),
      surroundWith: h("surround-with", 60452),
      share: h("share", 60453),
      gitStash: h("git-stash", 60454),
      gitStashApply: h("git-stash-apply", 60455),
      gitStashPop: h("git-stash-pop", 60456),
      vscode: h("vscode", 60457),
      vscodeInsiders: h("vscode-insiders", 60458),
      codeOss: h("code-oss", 60459),
      runCoverage: h("run-coverage", 60460),
      runAllCoverage: h("run-all-coverage", 60461),
      coverage: h("coverage", 60462),
      githubProject: h("github-project", 60463),
      mapVertical: h("map-vertical", 60464),
      foldVertical: h("fold-vertical", 60464),
      mapVerticalFilled: h("map-vertical-filled", 60465),
      foldVerticalFilled: h("fold-vertical-filled", 60465),
      goToSearch: h("go-to-search", 60466),
      percentage: h("percentage", 60467),
      sortPercentage: h("sort-percentage", 60467),
      attach: h("attach", 60468),
      goToEditingSession: h("go-to-editing-session", 60469),
      editSession: h("edit-session", 60470),
      codeReview: h("code-review", 60471),
      copilotWarning: h("copilot-warning", 60472),
      python: h("python", 60473),
      copilotLarge: h("copilot-large", 60474),
      copilotWarningLarge: h("copilot-warning-large", 60475),
      keyboardTab: h("keyboard-tab", 60476),
      copilotBlocked: h("copilot-blocked", 60477),
      copilotNotConnected: h("copilot-not-connected", 60478),
      flag: h("flag", 60479),
      lightbulbEmpty: h("lightbulb-empty", 60480),
      symbolMethodArrow: h("symbol-method-arrow", 60481),
      copilotUnavailable: h("copilot-unavailable", 60482),
      repoPinned: h("repo-pinned", 60483),
      keyboardTabAbove: h("keyboard-tab-above", 60484),
      keyboardTabBelow: h("keyboard-tab-below", 60485),
      gitPullRequestDone: h("git-pull-request-done", 60486),
      mcp: h("mcp", 60487),
      extensionsLarge: h("extensions-large", 60488),
      layoutPanelDock: h("layout-panel-dock", 60489),
      layoutSidebarLeftDock: h("layout-sidebar-left-dock", 60490),
      layoutSidebarRightDock: h("layout-sidebar-right-dock", 60491),
      copilotInProgress: h("copilot-in-progress", 60492),
      copilotError: h("copilot-error", 60493),
      copilotSuccess: h("copilot-success", 60494),
      chatSparkle: h("chat-sparkle", 60495),
      searchSparkle: h("search-sparkle", 60496),
      editSparkle: h("edit-sparkle", 60497),
      copilotSnooze: h("copilot-snooze", 60498),
      sendToRemoteAgent: h("send-to-remote-agent", 60499),
      commentDiscussionSparkle: h("comment-discussion-sparkle", 60500),
      chatSparkleWarning: h("chat-sparkle-warning", 60501),
      chatSparkleError: h("chat-sparkle-error", 60502),
      collection: h("collection", 60503),
      newCollection: h("new-collection", 60504),
      thinking: h("thinking", 60505),
      build: h("build", 60506),
      commentDiscussionQuote: h("comment-discussion-quote", 60507),
      cursor: h("cursor", 60508),
      eraser: h("eraser", 60509),
      fileText: h("file-text", 60510),
      gitLens: h("git-lens", 60511),
      quotes: h("quotes", 60512),
      rename: h("rename", 60513),
      runWithDeps: h("run-with-deps", 60514),
      debugConnected: h("debug-connected", 60515),
      strikethrough: h("strikethrough", 60516),
      openInProduct: h("open-in-product", 60517),
      indexZero: h("index-zero", 60518),
      agent: h("agent", 60519),
      editCode: h("edit-code", 60520),
      repoSelected: h("repo-selected", 60521),
      skip: h("skip", 60522),
      mergeInto: h("merge-into", 60523),
      gitBranchChanges: h("git-branch-changes", 60524),
      gitBranchStagedChanges: h("git-branch-staged-changes", 60525),
      gitBranchConflicts: h("git-branch-conflicts", 60526),
      gitBranch: h("git-branch", 60527),
      gitBranchCreate: h("git-branch-create", 60527),
      gitBranchDelete: h("git-branch-delete", 60527),
      searchLarge: h("search-large", 60528),
      terminalGitBash: h("terminal-git-bash", 60529)
    },
    Ml = {
      dialogError: h("dialog-error", "error"),
      dialogWarning: h("dialog-warning", "warning"),
      dialogInfo: h("dialog-info", "info"),
      dialogClose: h("dialog-close", "close"),
      treeItemExpanded: h("tree-item-expanded", "chevron-down"),
      treeFilterOnTypeOn: h("tree-filter-on-type-on", "list-filter"),
      treeFilterOnTypeOff: h("tree-filter-on-type-off", "list-selection"),
      treeFilterClear: h("tree-filter-clear", "close"),
      treeItemLoading: h("tree-item-loading", "loading"),
      menuSelection: h("menu-selection", "check"),
      menuSubmenu: h("menu-submenu", "chevron-right"),
      menuBarMore: h("menubar-more", "more"),
      scrollbarButtonLeft: h("scrollbar-button-left", "triangle-left"),
      scrollbarButtonRight: h("scrollbar-button-right", "triangle-right"),
      scrollbarButtonUp: h("scrollbar-button-up", "triangle-up"),
      scrollbarButtonDown: h("scrollbar-button-down", "triangle-down"),
      toolBarMore: h("toolbar-more", "more"),
      quickInputBack: h("quick-input-back", "arrow-left"),
      dropDownButton: h("drop-down-button", 60084),
      symbolCustomColor: h("symbol-customcolor", 60252),
      exportIcon: h("export", 60332),
      workspaceUnspecified: h("workspace-unspecified", 60355),
      newLine: h("newline", 60394),
      thumbsDownFilled: h("thumbsdown-filled", 60435),
      thumbsUpFilled: h("thumbsup-filled", 60436),
      gitFetch: h("git-fetch", 60445),
      lightbulbSparkleAutofix: h("lightbulb-sparkle-autofix", 60447),
      debugBreakpointPending: h("debug-breakpoint-pending", 60377)
    },
    B = {
      ...Dl,
      ...Ml
    };
  class Nl {
    constructor() {
      this._tokenizationSupports = new Map, this._factories = new Map, this._onDidChange = new Re, this.onDidChange = this._onDidChange.event, this._colorMap = null
    }
    handleChange(e) {
      this._onDidChange.fire({
        changedLanguages: e,
        changedColorMap: !1
      })
    }
    register(e, n) {
      return this._tokenizationSupports.set(e, n), this.handleChange([e]), Xt(() => {
        this._tokenizationSupports.get(e) === n && (this._tokenizationSupports.delete(e), this.handleChange([e]))
      })
    }
    get(e) {
      return this._tokenizationSupports.get(e) || null
    }
    registerFactory(e, n) {
      var r;
      (r = this._factories.get(e)) == null || r.dispose();
      const i = new Il(this, e, n);
      return this._factories.set(e, i), Xt(() => {
        const s = this._factories.get(e);
        !s || s !== i || (this._factories.delete(e), s.dispose())
      })
    }
    async getOrCreate(e) {
      const n = this.get(e);
      if (n) return n;
      const i = this._factories.get(e);
      return !i || i.isResolved ? null : (await i.resolve(), this.get(e))
    }
    isResolved(e) {
      if (this.get(e)) return !0;
      const i = this._factories.get(e);
      return !!(!i || i.isResolved)
    }
    setColorMap(e) {
      this._colorMap = e, this._onDidChange.fire({
        changedLanguages: Array.from(this._tokenizationSupports.keys()),
        changedColorMap: !0
      })
    }
    getColorMap() {
      return this._colorMap
    }
    getDefaultBackground() {
      return this._colorMap && this._colorMap.length > 2 ? this._colorMap[2] : null
    }
  }
  class Il extends Ze {
    get isResolved() {
      return this._isResolved
    }
    constructor(e, n, i) {
      super(), this._registry = e, this._languageId = n, this._factory = i, this._isDisposed = !1, this._resolvePromise = null, this._isResolved = !1
    }
    dispose() {
      this._isDisposed = !0, super.dispose()
    }
    async resolve() {
      return this._resolvePromise || (this._resolvePromise = this._create()), this._resolvePromise
    }
    async _create() {
      const e = await this._factory.tokenizationSupport;
      this._isResolved = !0, e && !this._isDisposed && this._register(this._registry.register(this._languageId, e))
    }
  }
  class zl {
    constructor(e, n, i) {
      this.offset = e, this.type = n, this.language = i, this._tokenBrand = void 0
    }
    toString() {
      return "(" + this.offset + ", " + this.type + ")"
    }
  }
  var ur;
  (function(t) {
    t[t.Increase = 0] = "Increase", t[t.Decrease = 1] = "Decrease"
  })(ur || (ur = {}));
  var cr;
  (function(t) {
    const e = new Map;
    e.set(0, B.symbolMethod), e.set(1, B.symbolFunction), e.set(2, B.symbolConstructor), e.set(3, B.symbolField), e.set(4, B.symbolVariable), e.set(5, B.symbolClass), e.set(6, B.symbolStruct), e.set(7, B.symbolInterface), e.set(8, B.symbolModule), e.set(9, B.symbolProperty), e.set(10, B.symbolEvent), e.set(11, B.symbolOperator), e.set(12, B.symbolUnit), e.set(13, B.symbolValue), e.set(15, B.symbolEnum), e.set(14, B.symbolConstant), e.set(15, B.symbolEnum), e.set(16, B.symbolEnumMember), e.set(17, B.symbolKeyword), e.set(28, B.symbolSnippet), e.set(18, B.symbolText), e.set(19, B.symbolColor), e.set(20, B.symbolFile), e.set(21, B.symbolReference), e.set(22, B.symbolCustomColor), e.set(23, B.symbolFolder), e.set(24, B.symbolTypeParameter), e.set(25, B.account), e.set(26, B.issues), e.set(27, B.tools);

    function n(a) {
      let l = e.get(a);
      return l || (console.info("No codicon found for CompletionItemKind " + a), l = B.symbolProperty), l
    }
    t.toIcon = n;

    function i(a) {
      switch (a) {
        case 0:
          return q(728, "Method");
        case 1:
          return q(729, "Function");
        case 2:
          return q(730, "Constructor");
        case 3:
          return q(731, "Field");
        case 4:
          return q(732, "Variable");
        case 5:
          return q(733, "Class");
        case 6:
          return q(734, "Struct");
        case 7:
          return q(735, "Interface");
        case 8:
          return q(736, "Module");
        case 9:
          return q(737, "Property");
        case 10:
          return q(738, "Event");
        case 11:
          return q(739, "Operator");
        case 12:
          return q(740, "Unit");
        case 13:
          return q(741, "Value");
        case 14:
          return q(742, "Constant");
        case 15:
          return q(743, "Enum");
        case 16:
          return q(744, "Enum Member");
        case 17:
          return q(745, "Keyword");
        case 18:
          return q(746, "Text");
        case 19:
          return q(747, "Color");
        case 20:
          return q(748, "File");
        case 21:
          return q(749, "Reference");
        case 22:
          return q(750, "Custom Color");
        case 23:
          return q(751, "Folder");
        case 24:
          return q(752, "Type Parameter");
        case 25:
          return q(753, "User");
        case 26:
          return q(754, "Issue");
        case 27:
          return q(755, "Tool");
        case 28:
          return q(756, "Snippet");
        default:
          return ""
      }
    }
    t.toLabel = i;
    const r = new Map;
    r.set("method", 0), r.set("function", 1), r.set("constructor", 2), r.set("field", 3), r.set("variable", 4), r.set("class", 5), r.set("struct", 6), r.set("interface", 7), r.set("module", 8), r.set("property", 9), r.set("event", 10), r.set("operator", 11), r.set("unit", 12), r.set("value", 13), r.set("constant", 14), r.set("enum", 15), r.set("enum-member", 16), r.set("enumMember", 16), r.set("keyword", 17), r.set("snippet", 28), r.set("text", 18), r.set("color", 19), r.set("file", 20), r.set("reference", 21), r.set("customcolor", 22), r.set("folder", 23), r.set("type-parameter", 24), r.set("typeParameter", 24), r.set("account", 25), r.set("issue", 26), r.set("tool", 27);

    function s(a, l) {
      let o = r.get(a);
      return typeof o > "u" && !l && (o = 9), o
    }
    t.fromString = s
  })(cr || (cr = {}));
  var hr;
  (function(t) {
    t[t.Automatic = 0] = "Automatic", t[t.Explicit = 1] = "Explicit"
  })(hr || (hr = {}));
  var dr;
  (function(t) {
    t[t.Code = 1] = "Code", t[t.Label = 2] = "Label"
  })(dr || (dr = {}));
  var mr;
  (function(t) {
    t[t.Accepted = 0] = "Accepted", t[t.Rejected = 1] = "Rejected", t[t.Ignored = 2] = "Ignored"
  })(mr || (mr = {}));
  var fr;
  (function(t) {
    t[t.Automatic = 0] = "Automatic", t[t.PasteAs = 1] = "PasteAs"
  })(fr || (fr = {}));
  var pr;
  (function(t) {
    t[t.Invoke = 1] = "Invoke", t[t.TriggerCharacter = 2] = "TriggerCharacter", t[t.ContentChange = 3] = "ContentChange"
  })(pr || (pr = {}));
  var gr;
  (function(t) {
    t[t.Text = 0] = "Text", t[t.Read = 1] = "Read", t[t.Write = 2] = "Write"
  })(gr || (gr = {})), q(757, "array"), q(758, "boolean"), q(759, "class"), q(760, "constant"), q(761, "constructor"), q(762, "enumeration"), q(763, "enumeration member"), q(764, "event"), q(765, "field"), q(766, "file"), q(767, "function"), q(768, "interface"), q(769, "key"), q(770, "method"), q(771, "module"), q(772, "namespace"), q(773, "null"), q(774, "number"), q(775, "object"), q(776, "operator"), q(777, "package"), q(778, "property"), q(779, "string"), q(780, "struct"), q(781, "type parameter"), q(782, "variable");
  var br;
  (function(t) {
    const e = new Map;
    e.set(0, B.symbolFile), e.set(1, B.symbolModule), e.set(2, B.symbolNamespace), e.set(3, B.symbolPackage), e.set(4, B.symbolClass), e.set(5, B.symbolMethod), e.set(6, B.symbolProperty), e.set(7, B.symbolField), e.set(8, B.symbolConstructor), e.set(9, B.symbolEnum), e.set(10, B.symbolInterface), e.set(11, B.symbolFunction), e.set(12, B.symbolVariable), e.set(13, B.symbolConstant), e.set(14, B.symbolString), e.set(15, B.symbolNumber), e.set(16, B.symbolBoolean), e.set(17, B.symbolArray), e.set(18, B.symbolObject), e.set(19, B.symbolKey), e.set(20, B.symbolNull), e.set(21, B.symbolEnumMember), e.set(22, B.symbolStruct), e.set(23, B.symbolEvent), e.set(24, B.symbolOperator), e.set(25, B.symbolTypeParameter);

    function n(s) {
      let a = e.get(s);
      return a || (console.info("No codicon found for SymbolKind " + s), a = B.symbolProperty), a
    }
    t.toIcon = n;
    const i = new Map;
    i.set(0, 20), i.set(1, 8), i.set(2, 8), i.set(3, 8), i.set(4, 5), i.set(5, 0), i.set(6, 9), i.set(7, 3), i.set(8, 2), i.set(9, 15), i.set(10, 7), i.set(11, 1), i.set(12, 4), i.set(13, 14), i.set(14, 18), i.set(15, 13), i.set(16, 13), i.set(17, 13), i.set(18, 13), i.set(19, 17), i.set(20, 13), i.set(21, 16), i.set(22, 6), i.set(23, 10), i.set(24, 11), i.set(25, 24);

    function r(s) {
      let a = i.get(s);
      return a === void 0 && (console.info("No completion kind found for SymbolKind " + s), a = 20), a
    }
    t.toCompletionKind = r
  })(br || (br = {}));
  let ph = (he = class {
    static fromValue(e) {
      switch (e) {
        case "comment":
          return he.Comment;
        case "imports":
          return he.Imports;
        case "region":
          return he.Region
      }
      return new he(e)
    }
    constructor(e) {
      this.value = e
    }
  }, he.Comment = new he("comment"), he.Imports = new he("imports"), he.Region = new he("region"), he);
  var wr;
  (function(t) {
    t[t.AIGenerated = 1] = "AIGenerated"
  })(wr || (wr = {}));
  var _r;
  (function(t) {
    t[t.Invoke = 0] = "Invoke", t[t.Automatic = 1] = "Automatic"
  })(_r || (_r = {}));
  var vr;
  (function(t) {
    function e(n) {
      return !n || typeof n != "object" ? !1 : typeof n.id == "string" && typeof n.title == "string"
    }
    t.is = e
  })(vr || (vr = {}));
  var yr;
  (function(t) {
    t[t.Type = 1] = "Type", t[t.Parameter = 2] = "Parameter"
  })(yr || (yr = {})), new Nl;
  var Tr;
  (function(t) {
    t[t.Unknown = 0] = "Unknown", t[t.Disabled = 1] = "Disabled", t[t.Enabled = 2] = "Enabled"
  })(Tr || (Tr = {}));
  var xr;
  (function(t) {
    t[t.Invoke = 1] = "Invoke", t[t.Auto = 2] = "Auto"
  })(xr || (xr = {}));
  var kr;
  (function(t) {
    t[t.None = 0] = "None", t[t.KeepWhitespace = 1] = "KeepWhitespace", t[t.InsertAsSnippet = 4] = "InsertAsSnippet"
  })(kr || (kr = {}));
  var Sr;
  (function(t) {
    t[t.Method = 0] = "Method", t[t.Function = 1] = "Function", t[t.Constructor = 2] = "Constructor", t[t.Field = 3] = "Field", t[t.Variable = 4] = "Variable", t[t.Class = 5] = "Class", t[t.Struct = 6] = "Struct", t[t.Interface = 7] = "Interface", t[t.Module = 8] = "Module", t[t.Property = 9] = "Property", t[t.Event = 10] = "Event", t[t.Operator = 11] = "Operator", t[t.Unit = 12] = "Unit", t[t.Value = 13] = "Value", t[t.Constant = 14] = "Constant", t[t.Enum = 15] = "Enum", t[t.EnumMember = 16] = "EnumMember", t[t.Keyword = 17] = "Keyword", t[t.Text = 18] = "Text", t[t.Color = 19] = "Color", t[t.File = 20] = "File", t[t.Reference = 21] = "Reference", t[t.Customcolor = 22] = "Customcolor", t[t.Folder = 23] = "Folder", t[t.TypeParameter = 24] = "TypeParameter", t[t.User = 25] = "User", t[t.Issue = 26] = "Issue", t[t.Tool = 27] = "Tool", t[t.Snippet = 28] = "Snippet"
  })(Sr || (Sr = {}));
  var Ar;
  (function(t) {
    t[t.Deprecated = 1] = "Deprecated"
  })(Ar || (Ar = {}));
  var Lr;
  (function(t) {
    t[t.Invoke = 0] = "Invoke", t[t.TriggerCharacter = 1] = "TriggerCharacter", t[t.TriggerForIncompleteCompletions = 2] = "TriggerForIncompleteCompletions"
  })(Lr || (Lr = {}));
  var Cr;
  (function(t) {
    t[t.EXACT = 0] = "EXACT", t[t.ABOVE = 1] = "ABOVE", t[t.BELOW = 2] = "BELOW"
  })(Cr || (Cr = {}));
  var Er;
  (function(t) {
    t[t.NotSet = 0] = "NotSet", t[t.ContentFlush = 1] = "ContentFlush", t[t.RecoverFromMarkers = 2] = "RecoverFromMarkers", t[t.Explicit = 3] = "Explicit", t[t.Paste = 4] = "Paste", t[t.Undo = 5] = "Undo", t[t.Redo = 6] = "Redo"
  })(Er || (Er = {}));
  var Rr;
  (function(t) {
    t[t.LF = 1] = "LF", t[t.CRLF = 2] = "CRLF"
  })(Rr || (Rr = {}));
  var Dr;
  (function(t) {
    t[t.Text = 0] = "Text", t[t.Read = 1] = "Read", t[t.Write = 2] = "Write"
  })(Dr || (Dr = {}));
  var Mr;
  (function(t) {
    t[t.None = 0] = "None", t[t.Keep = 1] = "Keep", t[t.Brackets = 2] = "Brackets", t[t.Advanced = 3] = "Advanced", t[t.Full = 4] = "Full"
  })(Mr || (Mr = {}));
  var Nr;
  (function(t) {
    t[t.acceptSuggestionOnCommitCharacter = 0] = "acceptSuggestionOnCommitCharacter", t[t.acceptSuggestionOnEnter = 1] = "acceptSuggestionOnEnter", t[t.accessibilitySupport = 2] = "accessibilitySupport", t[t.accessibilityPageSize = 3] = "accessibilityPageSize", t[t.allowOverflow = 4] = "allowOverflow", t[t.allowVariableLineHeights = 5] = "allowVariableLineHeights", t[t.allowVariableFonts = 6] = "allowVariableFonts", t[t.allowVariableFontsInAccessibilityMode = 7] = "allowVariableFontsInAccessibilityMode", t[t.ariaLabel = 8] = "ariaLabel", t[t.ariaRequired = 9] = "ariaRequired", t[t.autoClosingBrackets = 10] = "autoClosingBrackets", t[t.autoClosingComments = 11] = "autoClosingComments", t[t.screenReaderAnnounceInlineSuggestion = 12] = "screenReaderAnnounceInlineSuggestion", t[t.autoClosingDelete = 13] = "autoClosingDelete", t[t.autoClosingOvertype = 14] = "autoClosingOvertype", t[t.autoClosingQuotes = 15] = "autoClosingQuotes", t[t.autoIndent = 16] = "autoIndent", t[t.autoIndentOnPaste = 17] = "autoIndentOnPaste", t[t.autoIndentOnPasteWithinString = 18] = "autoIndentOnPasteWithinString", t[t.automaticLayout = 19] = "automaticLayout", t[t.autoSurround = 20] = "autoSurround", t[t.bracketPairColorization = 21] = "bracketPairColorization", t[t.guides = 22] = "guides", t[t.codeLens = 23] = "codeLens", t[t.codeLensFontFamily = 24] = "codeLensFontFamily", t[t.codeLensFontSize = 25] = "codeLensFontSize", t[t.colorDecorators = 26] = "colorDecorators", t[t.colorDecoratorsLimit = 27] = "colorDecoratorsLimit", t[t.columnSelection = 28] = "columnSelection", t[t.comments = 29] = "comments", t[t.contextmenu = 30] = "contextmenu", t[t.copyWithSyntaxHighlighting = 31] = "copyWithSyntaxHighlighting", t[t.cursorBlinking = 32] = "cursorBlinking", t[t.cursorSmoothCaretAnimation = 33] = "cursorSmoothCaretAnimation", t[t.cursorStyle = 34] = "cursorStyle", t[t.cursorSurroundingLines = 35] = "cursorSurroundingLines", t[t.cursorSurroundingLinesStyle = 36] = "cursorSurroundingLinesStyle", t[t.cursorWidth = 37] = "cursorWidth", t[t.cursorHeight = 38] = "cursorHeight", t[t.disableLayerHinting = 39] = "disableLayerHinting", t[t.disableMonospaceOptimizations = 40] = "disableMonospaceOptimizations", t[t.domReadOnly = 41] = "domReadOnly", t[t.dragAndDrop = 42] = "dragAndDrop", t[t.dropIntoEditor = 43] = "dropIntoEditor", t[t.editContext = 44] = "editContext", t[t.emptySelectionClipboard = 45] = "emptySelectionClipboard", t[t.experimentalGpuAcceleration = 46] = "experimentalGpuAcceleration", t[t.experimentalWhitespaceRendering = 47] = "experimentalWhitespaceRendering", t[t.extraEditorClassName = 48] = "extraEditorClassName", t[t.fastScrollSensitivity = 49] = "fastScrollSensitivity", t[t.find = 50] = "find", t[t.fixedOverflowWidgets = 51] = "fixedOverflowWidgets", t[t.folding = 52] = "folding", t[t.foldingStrategy = 53] = "foldingStrategy", t[t.foldingHighlight = 54] = "foldingHighlight", t[t.foldingImportsByDefault = 55] = "foldingImportsByDefault", t[t.foldingMaximumRegions = 56] = "foldingMaximumRegions", t[t.unfoldOnClickAfterEndOfLine = 57] = "unfoldOnClickAfterEndOfLine", t[t.fontFamily = 58] = "fontFamily", t[t.fontInfo = 59] = "fontInfo", t[t.fontLigatures = 60] = "fontLigatures", t[t.fontSize = 61] = "fontSize", t[t.fontWeight = 62] = "fontWeight", t[t.fontVariations = 63] = "fontVariations", t[t.formatOnPaste = 64] = "formatOnPaste", t[t.formatOnType = 65] = "formatOnType", t[t.glyphMargin = 66] = "glyphMargin", t[t.gotoLocation = 67] = "gotoLocation", t[t.hideCursorInOverviewRuler = 68] = "hideCursorInOverviewRuler", t[t.hover = 69] = "hover", t[t.inDiffEditor = 70] = "inDiffEditor", t[t.inlineSuggest = 71] = "inlineSuggest", t[t.letterSpacing = 72] = "letterSpacing", t[t.lightbulb = 73] = "lightbulb", t[t.lineDecorationsWidth = 74] = "lineDecorationsWidth", t[t.lineHeight = 75] = "lineHeight", t[t.lineNumbers = 76] = "lineNumbers", t[t.lineNumbersMinChars = 77] = "lineNumbersMinChars", t[t.linkedEditing = 78] = "linkedEditing", t[t.links = 79] = "links", t[t.matchBrackets = 80] = "matchBrackets", t[t.minimap = 81] = "minimap", t[t.mouseStyle = 82] = "mouseStyle", t[t.mouseWheelScrollSensitivity = 83] = "mouseWheelScrollSensitivity", t[t.mouseWheelZoom = 84] = "mouseWheelZoom", t[t.multiCursorMergeOverlapping = 85] = "multiCursorMergeOverlapping", t[t.multiCursorModifier = 86] = "multiCursorModifier", t[t.mouseMiddleClickAction = 87] = "mouseMiddleClickAction", t[t.multiCursorPaste = 88] = "multiCursorPaste", t[t.multiCursorLimit = 89] = "multiCursorLimit", t[t.occurrencesHighlight = 90] = "occurrencesHighlight", t[t.occurrencesHighlightDelay = 91] = "occurrencesHighlightDelay", t[t.overtypeCursorStyle = 92] = "overtypeCursorStyle", t[t.overtypeOnPaste = 93] = "overtypeOnPaste", t[t.overviewRulerBorder = 94] = "overviewRulerBorder", t[t.overviewRulerLanes = 95] = "overviewRulerLanes", t[t.padding = 96] = "padding", t[t.pasteAs = 97] = "pasteAs", t[t.parameterHints = 98] = "parameterHints", t[t.peekWidgetDefaultFocus = 99] = "peekWidgetDefaultFocus", t[t.placeholder = 100] = "placeholder", t[t.definitionLinkOpensInPeek = 101] = "definitionLinkOpensInPeek", t[t.quickSuggestions = 102] = "quickSuggestions", t[t.quickSuggestionsDelay = 103] = "quickSuggestionsDelay", t[t.readOnly = 104] = "readOnly", t[t.readOnlyMessage = 105] = "readOnlyMessage", t[t.renameOnType = 106] = "renameOnType", t[t.renderRichScreenReaderContent = 107] = "renderRichScreenReaderContent", t[t.renderControlCharacters = 108] = "renderControlCharacters", t[t.renderFinalNewline = 109] = "renderFinalNewline", t[t.renderLineHighlight = 110] = "renderLineHighlight", t[t.renderLineHighlightOnlyWhenFocus = 111] = "renderLineHighlightOnlyWhenFocus", t[t.renderValidationDecorations = 112] = "renderValidationDecorations", t[t.renderWhitespace = 113] = "renderWhitespace", t[t.revealHorizontalRightPadding = 114] = "revealHorizontalRightPadding", t[t.roundedSelection = 115] = "roundedSelection", t[t.rulers = 116] = "rulers", t[t.scrollbar = 117] = "scrollbar", t[t.scrollBeyondLastColumn = 118] = "scrollBeyondLastColumn", t[t.scrollBeyondLastLine = 119] = "scrollBeyondLastLine", t[t.scrollPredominantAxis = 120] = "scrollPredominantAxis", t[t.selectionClipboard = 121] = "selectionClipboard", t[t.selectionHighlight = 122] = "selectionHighlight", t[t.selectionHighlightMaxLength = 123] = "selectionHighlightMaxLength", t[t.selectionHighlightMultiline = 124] = "selectionHighlightMultiline", t[t.selectOnLineNumbers = 125] = "selectOnLineNumbers", t[t.showFoldingControls = 126] = "showFoldingControls", t[t.showUnused = 127] = "showUnused", t[t.snippetSuggestions = 128] = "snippetSuggestions", t[t.smartSelect = 129] = "smartSelect", t[t.smoothScrolling = 130] = "smoothScrolling", t[t.stickyScroll = 131] = "stickyScroll", t[t.stickyTabStops = 132] = "stickyTabStops", t[t.stopRenderingLineAfter = 133] = "stopRenderingLineAfter", t[t.suggest = 134] = "suggest", t[t.suggestFontSize = 135] = "suggestFontSize", t[t.suggestLineHeight = 136] = "suggestLineHeight", t[t.suggestOnTriggerCharacters = 137] = "suggestOnTriggerCharacters", t[t.suggestSelection = 138] = "suggestSelection", t[t.tabCompletion = 139] = "tabCompletion", t[t.tabIndex = 140] = "tabIndex", t[t.trimWhitespaceOnDelete = 141] = "trimWhitespaceOnDelete", t[t.unicodeHighlighting = 142] = "unicodeHighlighting", t[t.unusualLineTerminators = 143] = "unusualLineTerminators", t[t.useShadowDOM = 144] = "useShadowDOM", t[t.useTabStops = 145] = "useTabStops", t[t.wordBreak = 146] = "wordBreak", t[t.wordSegmenterLocales = 147] = "wordSegmenterLocales", t[t.wordSeparators = 148] = "wordSeparators", t[t.wordWrap = 149] = "wordWrap", t[t.wordWrapBreakAfterCharacters = 150] = "wordWrapBreakAfterCharacters", t[t.wordWrapBreakBeforeCharacters = 151] = "wordWrapBreakBeforeCharacters", t[t.wordWrapColumn = 152] = "wordWrapColumn", t[t.wordWrapOverride1 = 153] = "wordWrapOverride1", t[t.wordWrapOverride2 = 154] = "wordWrapOverride2", t[t.wrappingIndent = 155] = "wrappingIndent", t[t.wrappingStrategy = 156] = "wrappingStrategy", t[t.showDeprecated = 157] = "showDeprecated", t[t.inertialScroll = 158] = "inertialScroll", t[t.inlayHints = 159] = "inlayHints", t[t.wrapOnEscapedLineFeeds = 160] = "wrapOnEscapedLineFeeds", t[t.effectiveCursorStyle = 161] = "effectiveCursorStyle", t[t.editorClassName = 162] = "editorClassName", t[t.pixelRatio = 163] = "pixelRatio", t[t.tabFocusMode = 164] = "tabFocusMode", t[t.layoutInfo = 165] = "layoutInfo", t[t.wrappingInfo = 166] = "wrappingInfo", t[t.defaultColorDecorators = 167] = "defaultColorDecorators", t[t.colorDecoratorsActivatedOn = 168] = "colorDecoratorsActivatedOn", t[t.inlineCompletionsAccessibilityVerbose = 169] = "inlineCompletionsAccessibilityVerbose", t[t.effectiveEditContext = 170] = "effectiveEditContext", t[t.scrollOnMiddleClick = 171] = "scrollOnMiddleClick", t[t.effectiveAllowVariableFonts = 172] = "effectiveAllowVariableFonts"
  })(Nr || (Nr = {}));
  var Ir;
  (function(t) {
    t[t.TextDefined = 0] = "TextDefined", t[t.LF = 1] = "LF", t[t.CRLF = 2] = "CRLF"
  })(Ir || (Ir = {}));
  var zr;
  (function(t) {
    t[t.LF = 0] = "LF", t[t.CRLF = 1] = "CRLF"
  })(zr || (zr = {}));
  var Hr;
  (function(t) {
    t[t.Left = 1] = "Left", t[t.Center = 2] = "Center", t[t.Right = 3] = "Right"
  })(Hr || (Hr = {}));
  var Ur;
  (function(t) {
    t[t.Increase = 0] = "Increase", t[t.Decrease = 1] = "Decrease"
  })(Ur || (Ur = {}));
  var Pr;
  (function(t) {
    t[t.None = 0] = "None", t[t.Indent = 1] = "Indent", t[t.IndentOutdent = 2] = "IndentOutdent", t[t.Outdent = 3] = "Outdent"
  })(Pr || (Pr = {}));
  var Wr;
  (function(t) {
    t[t.Both = 0] = "Both", t[t.Right = 1] = "Right", t[t.Left = 2] = "Left", t[t.None = 3] = "None"
  })(Wr || (Wr = {}));
  var Fr;
  (function(t) {
    t[t.Type = 1] = "Type", t[t.Parameter = 2] = "Parameter"
  })(Fr || (Fr = {}));
  var Br;
  (function(t) {
    t[t.Accepted = 0] = "Accepted", t[t.Rejected = 1] = "Rejected", t[t.Ignored = 2] = "Ignored"
  })(Br || (Br = {}));
  var qr;
  (function(t) {
    t[t.Code = 1] = "Code", t[t.Label = 2] = "Label"
  })(qr || (qr = {}));
  var Or;
  (function(t) {
    t[t.Automatic = 0] = "Automatic", t[t.Explicit = 1] = "Explicit"
  })(Or || (Or = {}));
  var Kn;
  (function(t) {
    t[t.DependsOnKbLayout = -1] = "DependsOnKbLayout", t[t.Unknown = 0] = "Unknown", t[t.Backspace = 1] = "Backspace", t[t.Tab = 2] = "Tab", t[t.Enter = 3] = "Enter", t[t.Shift = 4] = "Shift", t[t.Ctrl = 5] = "Ctrl", t[t.Alt = 6] = "Alt", t[t.PauseBreak = 7] = "PauseBreak", t[t.CapsLock = 8] = "CapsLock", t[t.Escape = 9] = "Escape", t[t.Space = 10] = "Space", t[t.PageUp = 11] = "PageUp", t[t.PageDown = 12] = "PageDown", t[t.End = 13] = "End", t[t.Home = 14] = "Home", t[t.LeftArrow = 15] = "LeftArrow", t[t.UpArrow = 16] = "UpArrow", t[t.RightArrow = 17] = "RightArrow", t[t.DownArrow = 18] = "DownArrow", t[t.Insert = 19] = "Insert", t[t.Delete = 20] = "Delete", t[t.Digit0 = 21] = "Digit0", t[t.Digit1 = 22] = "Digit1", t[t.Digit2 = 23] = "Digit2", t[t.Digit3 = 24] = "Digit3", t[t.Digit4 = 25] = "Digit4", t[t.Digit5 = 26] = "Digit5", t[t.Digit6 = 27] = "Digit6", t[t.Digit7 = 28] = "Digit7", t[t.Digit8 = 29] = "Digit8", t[t.Digit9 = 30] = "Digit9", t[t.KeyA = 31] = "KeyA", t[t.KeyB = 32] = "KeyB", t[t.KeyC = 33] = "KeyC", t[t.KeyD = 34] = "KeyD", t[t.KeyE = 35] = "KeyE", t[t.KeyF = 36] = "KeyF", t[t.KeyG = 37] = "KeyG", t[t.KeyH = 38] = "KeyH", t[t.KeyI = 39] = "KeyI", t[t.KeyJ = 40] = "KeyJ", t[t.KeyK = 41] = "KeyK", t[t.KeyL = 42] = "KeyL", t[t.KeyM = 43] = "KeyM", t[t.KeyN = 44] = "KeyN", t[t.KeyO = 45] = "KeyO", t[t.KeyP = 46] = "KeyP", t[t.KeyQ = 47] = "KeyQ", t[t.KeyR = 48] = "KeyR", t[t.KeyS = 49] = "KeyS", t[t.KeyT = 50] = "KeyT", t[t.KeyU = 51] = "KeyU", t[t.KeyV = 52] = "KeyV", t[t.KeyW = 53] = "KeyW", t[t.KeyX = 54] = "KeyX", t[t.KeyY = 55] = "KeyY", t[t.KeyZ = 56] = "KeyZ", t[t.Meta = 57] = "Meta", t[t.ContextMenu = 58] = "ContextMenu", t[t.F1 = 59] = "F1", t[t.F2 = 60] = "F2", t[t.F3 = 61] = "F3", t[t.F4 = 62] = "F4", t[t.F5 = 63] = "F5", t[t.F6 = 64] = "F6", t[t.F7 = 65] = "F7", t[t.F8 = 66] = "F8", t[t.F9 = 67] = "F9", t[t.F10 = 68] = "F10", t[t.F11 = 69] = "F11", t[t.F12 = 70] = "F12", t[t.F13 = 71] = "F13", t[t.F14 = 72] = "F14", t[t.F15 = 73] = "F15", t[t.F16 = 74] = "F16", t[t.F17 = 75] = "F17", t[t.F18 = 76] = "F18", t[t.F19 = 77] = "F19", t[t.F20 = 78] = "F20", t[t.F21 = 79] = "F21", t[t.F22 = 80] = "F22", t[t.F23 = 81] = "F23", t[t.F24 = 82] = "F24", t[t.NumLock = 83] = "NumLock", t[t.ScrollLock = 84] = "ScrollLock", t[t.Semicolon = 85] = "Semicolon", t[t.Equal = 86] = "Equal", t[t.Comma = 87] = "Comma", t[t.Minus = 88] = "Minus", t[t.Period = 89] = "Period", t[t.Slash = 90] = "Slash", t[t.Backquote = 91] = "Backquote", t[t.BracketLeft = 92] = "BracketLeft", t[t.Backslash = 93] = "Backslash", t[t.BracketRight = 94] = "BracketRight", t[t.Quote = 95] = "Quote", t[t.OEM_8 = 96] = "OEM_8", t[t.IntlBackslash = 97] = "IntlBackslash", t[t.Numpad0 = 98] = "Numpad0", t[t.Numpad1 = 99] = "Numpad1", t[t.Numpad2 = 100] = "Numpad2", t[t.Numpad3 = 101] = "Numpad3", t[t.Numpad4 = 102] = "Numpad4", t[t.Numpad5 = 103] = "Numpad5", t[t.Numpad6 = 104] = "Numpad6", t[t.Numpad7 = 105] = "Numpad7", t[t.Numpad8 = 106] = "Numpad8", t[t.Numpad9 = 107] = "Numpad9", t[t.NumpadMultiply = 108] = "NumpadMultiply", t[t.NumpadAdd = 109] = "NumpadAdd", t[t.NUMPAD_SEPARATOR = 110] = "NUMPAD_SEPARATOR", t[t.NumpadSubtract = 111] = "NumpadSubtract", t[t.NumpadDecimal = 112] = "NumpadDecimal", t[t.NumpadDivide = 113] = "NumpadDivide", t[t.KEY_IN_COMPOSITION = 114] = "KEY_IN_COMPOSITION", t[t.ABNT_C1 = 115] = "ABNT_C1", t[t.ABNT_C2 = 116] = "ABNT_C2", t[t.AudioVolumeMute = 117] = "AudioVolumeMute", t[t.AudioVolumeUp = 118] = "AudioVolumeUp", t[t.AudioVolumeDown = 119] = "AudioVolumeDown", t[t.BrowserSearch = 120] = "BrowserSearch", t[t.BrowserHome = 121] = "BrowserHome", t[t.BrowserBack = 122] = "BrowserBack", t[t.BrowserForward = 123] = "BrowserForward", t[t.MediaTrackNext = 124] = "MediaTrackNext", t[t.MediaTrackPrevious = 125] = "MediaTrackPrevious", t[t.MediaStop = 126] = "MediaStop", t[t.MediaPlayPause = 127] = "MediaPlayPause", t[t.LaunchMediaPlayer = 128] = "LaunchMediaPlayer", t[t.LaunchMail = 129] = "LaunchMail", t[t.LaunchApp2 = 130] = "LaunchApp2", t[t.Clear = 131] = "Clear", t[t.MAX_VALUE = 132] = "MAX_VALUE"
  })(Kn || (Kn = {}));
  var ei;
  (function(t) {
    t[t.Hint = 1] = "Hint", t[t.Info = 2] = "Info", t[t.Warning = 4] = "Warning", t[t.Error = 8] = "Error"
  })(ei || (ei = {}));
  var ti;
  (function(t) {
    t[t.Unnecessary = 1] = "Unnecessary", t[t.Deprecated = 2] = "Deprecated"
  })(ti || (ti = {}));
  var Vr;
  (function(t) {
    t[t.Inline = 1] = "Inline", t[t.Gutter = 2] = "Gutter"
  })(Vr || (Vr = {}));
  var jr;
  (function(t) {
    t[t.Normal = 1] = "Normal", t[t.Underlined = 2] = "Underlined"
  })(jr || (jr = {}));
  var $r;
  (function(t) {
    t[t.UNKNOWN = 0] = "UNKNOWN", t[t.TEXTAREA = 1] = "TEXTAREA", t[t.GUTTER_GLYPH_MARGIN = 2] = "GUTTER_GLYPH_MARGIN", t[t.GUTTER_LINE_NUMBERS = 3] = "GUTTER_LINE_NUMBERS", t[t.GUTTER_LINE_DECORATIONS = 4] = "GUTTER_LINE_DECORATIONS", t[t.GUTTER_VIEW_ZONE = 5] = "GUTTER_VIEW_ZONE", t[t.CONTENT_TEXT = 6] = "CONTENT_TEXT", t[t.CONTENT_EMPTY = 7] = "CONTENT_EMPTY", t[t.CONTENT_VIEW_ZONE = 8] = "CONTENT_VIEW_ZONE", t[t.CONTENT_WIDGET = 9] = "CONTENT_WIDGET", t[t.OVERVIEW_RULER = 10] = "OVERVIEW_RULER", t[t.SCROLLBAR = 11] = "SCROLLBAR", t[t.OVERLAY_WIDGET = 12] = "OVERLAY_WIDGET", t[t.OUTSIDE_EDITOR = 13] = "OUTSIDE_EDITOR"
  })($r || ($r = {}));
  var Gr;
  (function(t) {
    t[t.AIGenerated = 1] = "AIGenerated"
  })(Gr || (Gr = {}));
  var Xr;
  (function(t) {
    t[t.Invoke = 0] = "Invoke", t[t.Automatic = 1] = "Automatic"
  })(Xr || (Xr = {}));
  var Jr;
  (function(t) {
    t[t.TOP_RIGHT_CORNER = 0] = "TOP_RIGHT_CORNER", t[t.BOTTOM_RIGHT_CORNER = 1] = "BOTTOM_RIGHT_CORNER", t[t.TOP_CENTER = 2] = "TOP_CENTER"
  })(Jr || (Jr = {}));
  var Qr;
  (function(t) {
    t[t.Left = 1] = "Left", t[t.Center = 2] = "Center", t[t.Right = 4] = "Right", t[t.Full = 7] = "Full"
  })(Qr || (Qr = {}));
  var Yr;
  (function(t) {
    t[t.Word = 0] = "Word", t[t.Line = 1] = "Line", t[t.Suggest = 2] = "Suggest"
  })(Yr || (Yr = {}));
  var Zr;
  (function(t) {
    t[t.Left = 0] = "Left", t[t.Right = 1] = "Right", t[t.None = 2] = "None", t[t.LeftOfInjectedText = 3] = "LeftOfInjectedText", t[t.RightOfInjectedText = 4] = "RightOfInjectedText"
  })(Zr || (Zr = {}));
  var Kr;
  (function(t) {
    t[t.Off = 0] = "Off", t[t.On = 1] = "On", t[t.Relative = 2] = "Relative", t[t.Interval = 3] = "Interval", t[t.Custom = 4] = "Custom"
  })(Kr || (Kr = {}));
  var es;
  (function(t) {
    t[t.None = 0] = "None", t[t.Text = 1] = "Text", t[t.Blocks = 2] = "Blocks"
  })(es || (es = {}));
  var ts;
  (function(t) {
    t[t.Smooth = 0] = "Smooth", t[t.Immediate = 1] = "Immediate"
  })(ts || (ts = {}));
  var ns;
  (function(t) {
    t[t.Auto = 1] = "Auto", t[t.Hidden = 2] = "Hidden", t[t.Visible = 3] = "Visible"
  })(ns || (ns = {}));
  var ni;
  (function(t) {
    t[t.LTR = 0] = "LTR", t[t.RTL = 1] = "RTL"
  })(ni || (ni = {}));
  var is;
  (function(t) {
    t.Off = "off", t.OnCode = "onCode", t.On = "on"
  })(is || (is = {}));
  var rs;
  (function(t) {
    t[t.Invoke = 1] = "Invoke", t[t.TriggerCharacter = 2] = "TriggerCharacter", t[t.ContentChange = 3] = "ContentChange"
  })(rs || (rs = {}));
  var ss;
  (function(t) {
    t[t.File = 0] = "File", t[t.Module = 1] = "Module", t[t.Namespace = 2] = "Namespace", t[t.Package = 3] = "Package", t[t.Class = 4] = "Class", t[t.Method = 5] = "Method", t[t.Property = 6] = "Property", t[t.Field = 7] = "Field", t[t.Constructor = 8] = "Constructor", t[t.Enum = 9] = "Enum", t[t.Interface = 10] = "Interface", t[t.Function = 11] = "Function", t[t.Variable = 12] = "Variable", t[t.Constant = 13] = "Constant", t[t.String = 14] = "String", t[t.Number = 15] = "Number", t[t.Boolean = 16] = "Boolean", t[t.Array = 17] = "Array", t[t.Object = 18] = "Object", t[t.Key = 19] = "Key", t[t.Null = 20] = "Null", t[t.EnumMember = 21] = "EnumMember", t[t.Struct = 22] = "Struct", t[t.Event = 23] = "Event", t[t.Operator = 24] = "Operator", t[t.TypeParameter = 25] = "TypeParameter"
  })(ss || (ss = {}));
  var as;
  (function(t) {
    t[t.Deprecated = 1] = "Deprecated"
  })(as || (as = {}));
  var os;
  (function(t) {
    t[t.LTR = 0] = "LTR", t[t.RTL = 1] = "RTL"
  })(os || (os = {}));
  var ls;
  (function(t) {
    t[t.Hidden = 0] = "Hidden", t[t.Blink = 1] = "Blink", t[t.Smooth = 2] = "Smooth", t[t.Phase = 3] = "Phase", t[t.Expand = 4] = "Expand", t[t.Solid = 5] = "Solid"
  })(ls || (ls = {}));
  var us;
  (function(t) {
    t[t.Line = 1] = "Line", t[t.Block = 2] = "Block", t[t.Underline = 3] = "Underline", t[t.LineThin = 4] = "LineThin", t[t.BlockOutline = 5] = "BlockOutline", t[t.UnderlineThin = 6] = "UnderlineThin"
  })(us || (us = {}));
  var cs;
  (function(t) {
    t[t.AlwaysGrowsWhenTypingAtEdges = 0] = "AlwaysGrowsWhenTypingAtEdges", t[t.NeverGrowsWhenTypingAtEdges = 1] = "NeverGrowsWhenTypingAtEdges", t[t.GrowsOnlyWhenTypingBefore = 2] = "GrowsOnlyWhenTypingBefore", t[t.GrowsOnlyWhenTypingAfter = 3] = "GrowsOnlyWhenTypingAfter"
  })(cs || (cs = {}));
  var hs;
  (function(t) {
    t[t.None = 0] = "None", t[t.Same = 1] = "Same", t[t.Indent = 2] = "Indent", t[t.DeepIndent = 3] = "DeepIndent"
  })(hs || (hs = {}));
  const St = class St {
    static chord(e, n) {
      return dl(e, n)
    }
  };
  St.CtrlCmd = 2048, St.Shift = 1024, St.Alt = 512, St.WinCtrl = 256;
  let ii = St;

  function Hl() {
    return {
      editor: void 0,
      languages: void 0,
      CancellationTokenSource: ll,
      Emitter: Re,
      KeyCode: Kn,
      KeyMod: ii,
      Position: K,
      Range: j,
      Selection: ge,
      SelectionDirection: ni,
      MarkerSeverity: ei,
      MarkerTag: ti,
      Uri: Qn,
      Token: zl
    }
  }
  var ds;
  class Ul {
    constructor() {
      this[ds] = "LinkedMap", this._map = new Map, this._head = void 0, this._tail = void 0, this._size = 0, this._state = 0
    }
    clear() {
      this._map.clear(), this._head = void 0, this._tail = void 0, this._size = 0, this._state++
    }
    isEmpty() {
      return !this._head && !this._tail
    }
    get size() {
      return this._size
    }
    get first() {
      var e;
      return (e = this._head) == null ? void 0 : e.value
    }
    get last() {
      var e;
      return (e = this._tail) == null ? void 0 : e.value
    }
    has(e) {
      return this._map.has(e)
    }
    get(e, n = 0) {
      const i = this._map.get(e);
      if (i) return n !== 0 && this.touch(i, n), i.value
    }
    set(e, n, i = 0) {
      let r = this._map.get(e);
      if (r) r.value = n, i !== 0 && this.touch(r, i);
      else {
        switch (r = {
            key: e,
            value: n,
            next: void 0,
            previous: void 0
          }, i) {
          case 0:
            this.addItemLast(r);
            break;
          case 1:
            this.addItemFirst(r);
            break;
          case 2:
            this.addItemLast(r);
            break;
          default:
            this.addItemLast(r);
            break
        }
        this._map.set(e, r), this._size++
      }
      return this
    }
    delete(e) {
      return !!this.remove(e)
    }
    remove(e) {
      const n = this._map.get(e);
      if (n) return this._map.delete(e), this.removeItem(n), this._size--, n.value
    }
    shift() {
      if (!this._head && !this._tail) return;
      if (!this._head || !this._tail) throw new Error("Invalid list");
      const e = this._head;
      return this._map.delete(e.key), this.removeItem(e), this._size--, e.value
    }
    forEach(e, n) {
      const i = this._state;
      let r = this._head;
      for (; r;) {
        if (n ? e.bind(n)(r.value, r.key, this) : e(r.value, r.key, this), this._state !== i) throw new Error("LinkedMap got modified during iteration.");
        r = r.next
      }
    }
    keys() {
      const e = this,
        n = this._state;
      let i = this._head;
      const r = {
        [Symbol.iterator]() {
          return r
        },
        next() {
          if (e._state !== n) throw new Error("LinkedMap got modified during iteration.");
          if (i) {
            const s = {
              value: i.key,
              done: !1
            };
            return i = i.next, s
          } else return {
            value: void 0,
            done: !0
          }
        }
      };
      return r
    }
    values() {
      const e = this,
        n = this._state;
      let i = this._head;
      const r = {
        [Symbol.iterator]() {
          return r
        },
        next() {
          if (e._state !== n) throw new Error("LinkedMap got modified during iteration.");
          if (i) {
            const s = {
              value: i.value,
              done: !1
            };
            return i = i.next, s
          } else return {
            value: void 0,
            done: !0
          }
        }
      };
      return r
    }
    entries() {
      const e = this,
        n = this._state;
      let i = this._head;
      const r = {
        [Symbol.iterator]() {
          return r
        },
        next() {
          if (e._state !== n) throw new Error("LinkedMap got modified during iteration.");
          if (i) {
            const s = {
              value: [i.key, i.value],
              done: !1
            };
            return i = i.next, s
          } else return {
            value: void 0,
            done: !0
          }
        }
      };
      return r
    } [(ds = Symbol.toStringTag, Symbol.iterator)]() {
      return this.entries()
    }
    trimOld(e) {
      if (e >= this.size) return;
      if (e === 0) {
        this.clear();
        return
      }
      let n = this._head,
        i = this.size;
      for (; n && i > e;) this._map.delete(n.key), n = n.next, i--;
      this._head = n, this._size = i, n && (n.previous = void 0), this._state++
    }
    trimNew(e) {
      if (e >= this.size) return;
      if (e === 0) {
        this.clear();
        return
      }
      let n = this._tail,
        i = this.size;
      for (; n && i > e;) this._map.delete(n.key), n = n.previous, i--;
      this._tail = n, this._size = i, n && (n.next = void 0), this._state++
    }
    addItemFirst(e) {
      if (!this._head && !this._tail) this._tail = e;
      else if (this._head) e.next = this._head, this._head.previous = e;
      else throw new Error("Invalid list");
      this._head = e, this._state++
    }
    addItemLast(e) {
      if (!this._head && !this._tail) this._head = e;
      else if (this._tail) e.previous = this._tail, this._tail.next = e;
      else throw new Error("Invalid list");
      this._tail = e, this._state++
    }
    removeItem(e) {
      if (e === this._head && e === this._tail) this._head = void 0, this._tail = void 0;
      else if (e === this._head) {
        if (!e.next) throw new Error("Invalid list");
        e.next.previous = void 0, this._head = e.next
      } else if (e === this._tail) {
        if (!e.previous) throw new Error("Invalid list");
        e.previous.next = void 0, this._tail = e.previous
      } else {
        const n = e.next,
          i = e.previous;
        if (!n || !i) throw new Error("Invalid list");
        n.previous = i, i.next = n
      }
      e.next = void 0, e.previous = void 0, this._state++
    }
    touch(e, n) {
      if (!this._head || !this._tail) throw new Error("Invalid list");
      if (!(n !== 1 && n !== 2)) {
        if (n === 1) {
          if (e === this._head) return;
          const i = e.next,
            r = e.previous;
          e === this._tail ? (r.next = void 0, this._tail = r) : (i.previous = r, r.next = i), e.previous = void 0, e.next = this._head, this._head.previous = e, this._head = e, this._state++
        } else if (n === 2) {
          if (e === this._tail) return;
          const i = e.next,
            r = e.previous;
          e === this._head ? (i.previous = void 0, this._head = i) : (i.previous = r, r.next = i), e.next = void 0, e.previous = this._tail, this._tail.next = e, this._tail = e, this._state++
        }
      }
    }
    toJSON() {
      const e = [];
      return this.forEach((n, i) => {
        e.push([i, n])
      }), e
    }
    fromJSON(e) {
      this.clear();
      for (const [n, i] of e) this.set(n, i)
    }
  }
  class Pl extends Ul {
    constructor(e, n = 1) {
      super(), this._limit = e, this._ratio = Math.min(Math.max(0, n), 1)
    }
    get limit() {
      return this._limit
    }
    set limit(e) {
      this._limit = e, this.checkTrim()
    }
    get(e, n = 2) {
      return super.get(e, n)
    }
    peek(e) {
      return super.get(e, 0)
    }
    set(e, n) {
      return super.set(e, n, 2), this
    }
    checkTrim() {
      this.size > this._limit && this.trim(Math.round(this._limit * this._ratio))
    }
  }
  class Wl extends Pl {
    constructor(e, n = 1) {
      super(e, n)
    }
    trim(e) {
      this.trimOld(e)
    }
    set(e, n) {
      return super.set(e, n), this.checkTrim(), this
    }
  }
  class Fl {
    constructor() {
      this.map = new Map
    }
    add(e, n) {
      let i = this.map.get(e);
      i || (i = new Set, this.map.set(e, i)), i.add(n)
    }
    delete(e, n) {
      const i = this.map.get(e);
      i && (i.delete(n), i.size === 0 && this.map.delete(e))
    }
    forEach(e, n) {
      const i = this.map.get(e);
      i && i.forEach(n)
    }
  }
  new Wl(10);
  var ms;
  (function(t) {
    t[t.Left = 1] = "Left", t[t.Center = 2] = "Center", t[t.Right = 4] = "Right", t[t.Full = 7] = "Full"
  })(ms || (ms = {}));
  var fs;
  (function(t) {
    t[t.Left = 1] = "Left", t[t.Center = 2] = "Center", t[t.Right = 3] = "Right"
  })(fs || (fs = {}));
  var ps;
  (function(t) {
    t[t.LTR = 0] = "LTR", t[t.RTL = 1] = "RTL"
  })(ps || (ps = {}));
  var gs;
  (function(t) {
    t[t.Both = 0] = "Both", t[t.Right = 1] = "Right", t[t.Left = 2] = "Left", t[t.None = 3] = "None"
  })(gs || (gs = {}));

  function Bl(t) {
    if (!t || t.length === 0) return !1;
    for (let e = 0, n = t.length; e < n; e++) {
      const i = t.charCodeAt(e);
      if (i === 10) return !0;
      if (i === 92) {
        if (e++, e >= n) break;
        const r = t.charCodeAt(e);
        if (r === 110 || r === 114 || r === 87) return !0
      }
    }
    return !1
  }

  function ql(t, e, n, i, r) {
    if (i === 0) return !0;
    const s = e.charCodeAt(i - 1);
    if (t.get(s) !== 0 || s === 13 || s === 10) return !0;
    if (r > 0) {
      const a = e.charCodeAt(i);
      if (t.get(a) !== 0) return !0
    }
    return !1
  }

  function Ol(t, e, n, i, r) {
    if (i + r === n) return !0;
    const s = e.charCodeAt(i + r);
    if (t.get(s) !== 0 || s === 13 || s === 10) return !0;
    if (r > 0) {
      const a = e.charCodeAt(i + r - 1);
      if (t.get(a) !== 0) return !0
    }
    return !1
  }

  function Vl(t, e, n, i, r) {
    return ql(t, e, n, i, r) && Ol(t, e, n, i, r)
  }
  class jl {
    constructor(e, n) {
      this._wordSeparators = e, this._searchRegex = n, this._prevMatchStartIndex = -1, this._prevMatchLength = 0
    }
    reset(e) {
      this._searchRegex.lastIndex = e, this._prevMatchStartIndex = -1, this._prevMatchLength = 0
    }
    next(e) {
      const n = e.length;
      let i;
      do {
        if (this._prevMatchStartIndex + this._prevMatchLength === n || (i = this._searchRegex.exec(e), !i)) return null;
        const r = i.index,
          s = i[0].length;
        if (r === this._prevMatchStartIndex && s === this._prevMatchLength) {
          if (s === 0) {
            Vo(e, n, this._searchRegex.lastIndex) > 65535 ? this._searchRegex.lastIndex += 2 : this._searchRegex.lastIndex += 1;
            continue
          }
          return null
        }
        if (this._prevMatchStartIndex = r, this._prevMatchLength = s, !this._wordSeparators || Vl(this._wordSeparators, e, n, r, s)) return i
      } while (i);
      return null
    }
  }
  const $l = "`~!@#$%^&*()-=+[{]}\\|;:'\",.<>/?";

  function Gl(t = "") {
    let e = "(-?\\d*\\.\\d\\w*)|([^";
    for (const n of $l) t.indexOf(n) >= 0 || (e += "\\" + n);
    return e += "\\s]+)", new RegExp(e, "g")
  }
  const bs = Gl();

  function ws(t) {
    let e = bs;
    if (t && t instanceof RegExp)
      if (t.global) e = t;
      else {
        let n = "g";
        t.ignoreCase && (n += "i"), t.multiline && (n += "m"), t.unicode && (n += "u"), e = new RegExp(t.source, n)
      } return e.lastIndex = 0, e
  }
  const _s = new wo;
  _s.unshift({
    maxLen: 1e3,
    windowSize: 15,
    timeBudget: 150
  });

  function ri(t, e, n, i, r) {
    if (e = ws(e), r || (r = Gt.first(_s)), n.length > r.maxLen) {
      let u = t - r.maxLen / 2;
      return u < 0 ? u = 0 : i += u, n = n.substring(u, t + r.maxLen / 2), ri(t, e, n, i, r)
    }
    const s = Date.now(),
      a = t - 1 - i;
    let l = -1,
      o = null;
    for (let u = 1; !(Date.now() - s >= r.timeBudget); u++) {
      const c = a - r.windowSize * u;
      e.lastIndex = Math.max(0, c);
      const d = Xl(e, n, a, l);
      if (!d && o || (o = d, c <= 0)) break;
      l = c
    }
    if (o) {
      const u = {
        word: o[0],
        startColumn: i + 1 + o.index,
        endColumn: i + 1 + o.index + o[0].length
      };
      return e.lastIndex = 0, u
    }
    return null
  }

  function Xl(t, e, n, i) {
    let r;
    for (; r = t.exec(e);) {
      const s = r.index || 0;
      if (s <= n && t.lastIndex >= n) return r;
      if (i > 0 && s > i) return null
    }
    return null
  }
  class Jl {
    static computeUnicodeHighlights(e, n, i) {
      const r = i ? i.startLineNumber : 1,
        s = i ? i.endLineNumber : e.getLineCount(),
        a = new vs(n),
        l = a.getCandidateCodePoints();
      let o;
      l === "allNonBasicAscii" ? o = new RegExp("[^\\t\\n\\r\\x20-\\x7E]", "g") : o = new RegExp(`${Ql(Array.from(l))}`, "g");
      const u = new jl(null, o),
        c = [];
      let d = !1,
        m, f = 0,
        w = 0,
        p = 0;
      e: for (let x = r, T = s; x <= T; x++) {
        const y = e.getLineContent(x),
          L = y.length;
        u.reset(0);
        do
          if (m = u.next(y), m) {
            let I = m.index,
              H = m.index + m[0].length;
            if (I > 0) {
              const _ = y.charCodeAt(I - 1);
              Fn(_) && I--
            }
            if (H + 1 < L) {
              const _ = y.charCodeAt(H - 1);
              Fn(_) && H++
            }
            const P = y.substring(I, H);
            let b = ri(I + 1, bs, y, 0);
            b && b.endColumn <= I + 1 && (b = null);
            const g = a.shouldHighlightNonBasicASCII(P, b ? b.word : null);
            if (g !== 0) {
              if (g === 3 ? f++ : g === 2 ? w++ : g === 1 ? p++ : ho(), c.length >= 1e3) {
                d = !0;
                break e
              }
              c.push(new j(x, I + 1, x, H + 1))
            }
          } while (m)
      }
      return {
        ranges: c,
        hasMore: d,
        ambiguousCharacterCount: f,
        invisibleCharacterCount: w,
        nonBasicAsciiCharacterCount: p
      }
    }
    static computeUnicodeHighlightReason(e, n) {
      const i = new vs(n);
      switch (i.shouldHighlightNonBasicASCII(e, null)) {
        case 0:
          return null;
        case 2:
          return {
            kind: 1
          };
        case 3: {
          const s = e.codePointAt(0),
            a = i.ambiguousCharacters.getPrimaryConfusable(s),
            l = Et.getLocales().filter(o => !Et.getInstance(new Set([...n.allowedLocales, o])).isAmbiguous(s));
          return {
            kind: 0,
            confusableWith: String.fromCodePoint(a),
            notAmbiguousInLocales: l
          }
        }
        case 1:
          return {
            kind: 2
          }
      }
    }
  }

  function Ql(t, e) {
    return `[${zo(t.map(i=>String.fromCodePoint(i)).join(""))}]`
  }
  class vs {
    constructor(e) {
      this.options = e, this.allowedCodePoints = new Set(e.allowedCodePoints), this.ambiguousCharacters = Et.getInstance(new Set(e.allowedLocales))
    }
    getCandidateCodePoints() {
      if (this.options.nonBasicASCII) return "allNonBasicAscii";
      const e = new Set;
      if (this.options.invisibleCharacters)
        for (const n of Rt.codePoints) ys(String.fromCodePoint(n)) || e.add(n);
      if (this.options.ambiguousCharacters)
        for (const n of this.ambiguousCharacters.getConfusableCodePoints()) e.add(n);
      for (const n of this.allowedCodePoints) e.delete(n);
      return e
    }
    shouldHighlightNonBasicASCII(e, n) {
      const i = e.codePointAt(0);
      if (this.allowedCodePoints.has(i)) return 0;
      if (this.options.nonBasicASCII) return 1;
      let r = !1,
        s = !1;
      if (n)
        for (const a of n) {
          const l = a.codePointAt(0),
            o = $o(a);
          r = r || o, !o && !this.ambiguousCharacters.isAmbiguous(l) && !Rt.isInvisibleCharacter(l) && (s = !0)
        }
      return !r && s ? 0 : this.options.invisibleCharacters && !ys(e) && Rt.isInvisibleCharacter(i) ? 2 : this.options.ambiguousCharacters && this.ambiguousCharacters.isAmbiguous(i) ? 3 : 0
    }
  }

  function ys(t) {
    return t === " " || t === `
` || t === "	"
  }
  class sn {
    constructor(e, n, i) {
      this.changes = e, this.moves = n, this.hitTimeout = i
    }
  }
  class Yl {
    constructor(e, n) {
      this.lineRangeMapping = e, this.changes = n
    }
  }

  function Zl(t, e, n = (i, r) => i === r) {
    if (t === e) return !0;
    if (!t || !e || t.length !== e.length) return !1;
    for (let i = 0, r = t.length; i < r; i++)
      if (!n(t[i], e[i])) return !1;
    return !0
  }

  function* Kl(t, e) {
    let n, i;
    for (const r of t) i !== void 0 && e(i, r) ? n.push(r) : (n && (yield n), n = [r]), i = r;
    n && (yield n)
  }

  function eu(t, e) {
    for (let n = 0; n <= t.length; n++) e(n === 0 ? void 0 : t[n - 1], n === t.length ? void 0 : t[n])
  }

  function tu(t, e) {
    for (let n = 0; n < t.length; n++) e(n === 0 ? void 0 : t[n - 1], t[n], n + 1 === t.length ? void 0 : t[n + 1])
  }

  function nu(t, e) {
    for (const n of e) t.push(n)
  }
  var si;
  (function(t) {
    function e(s) {
      return s < 0
    }
    t.isLessThan = e;

    function n(s) {
      return s <= 0
    }
    t.isLessThanOrEqual = n;

    function i(s) {
      return s > 0
    }
    t.isGreaterThan = i;

    function r(s) {
      return s === 0
    }
    t.isNeitherLessOrGreaterThan = r, t.greaterThan = 1, t.lessThan = -1, t.neitherLessOrGreaterThan = 0
  })(si || (si = {}));

  function Mt(t, e) {
    return (n, i) => e(t(n), t(i))
  }
  const Nt = (t, e) => t - e;

  function iu(t) {
    return (e, n) => -t(e, n)
  }
  const At = class At {
    constructor(e) {
      this.iterate = e
    }
    toArray() {
      const e = [];
      return this.iterate(n => (e.push(n), !0)), e
    }
    filter(e) {
      return new At(n => this.iterate(i => e(i) ? n(i) : !0))
    }
    map(e) {
      return new At(n => this.iterate(i => n(e(i))))
    }
    findLast(e) {
      let n;
      return this.iterate(i => (e(i) && (n = i), !0)), n
    }
    findLastMaxBy(e) {
      let n, i = !0;
      return this.iterate(r => ((i || si.isGreaterThan(e(r, n))) && (i = !1, n = r), !0)), n
    }
  };
  At.empty = new At(e => {});
  let Ts = At;
  class G {
    static fromTo(e, n) {
      return new G(e, n)
    }
    static addRange(e, n) {
      let i = 0;
      for (; i < n.length && n[i].endExclusive < e.start;) i++;
      let r = i;
      for (; r < n.length && n[r].start <= e.endExclusive;) r++;
      if (i === r) n.splice(i, 0, e);
      else {
        const s = Math.min(e.start, n[i].start),
          a = Math.max(e.endExclusive, n[r - 1].endExclusive);
        n.splice(i, r - i, new G(s, a))
      }
    }
    static tryCreate(e, n) {
      if (!(e > n)) return new G(e, n)
    }
    static ofLength(e) {
      return new G(0, e)
    }
    static ofStartAndLength(e, n) {
      return new G(e, e + n)
    }
    static emptyAt(e) {
      return new G(e, e)
    }
    constructor(e, n) {
      if (this.start = e, this.endExclusive = n, e > n) throw new ue(`Invalid range: ${this.toString()}`)
    }
    get isEmpty() {
      return this.start === this.endExclusive
    }
    delta(e) {
      return new G(this.start + e, this.endExclusive + e)
    }
    deltaStart(e) {
      return new G(this.start + e, this.endExclusive)
    }
    deltaEnd(e) {
      return new G(this.start, this.endExclusive + e)
    }
    get length() {
      return this.endExclusive - this.start
    }
    toString() {
      return `[${this.start}, ${this.endExclusive})`
    }
    equals(e) {
      return this.start === e.start && this.endExclusive === e.endExclusive
    }
    contains(e) {
      return this.start <= e && e < this.endExclusive
    }
    join(e) {
      return new G(Math.min(this.start, e.start), Math.max(this.endExclusive, e.endExclusive))
    }
    intersect(e) {
      const n = Math.max(this.start, e.start),
        i = Math.min(this.endExclusive, e.endExclusive);
      if (n <= i) return new G(n, i)
    }
    intersectionLength(e) {
      const n = Math.max(this.start, e.start),
        i = Math.min(this.endExclusive, e.endExclusive);
      return Math.max(0, i - n)
    }
    intersects(e) {
      const n = Math.max(this.start, e.start),
        i = Math.min(this.endExclusive, e.endExclusive);
      return n < i
    }
    intersectsOrTouches(e) {
      const n = Math.max(this.start, e.start),
        i = Math.min(this.endExclusive, e.endExclusive);
      return n <= i
    }
    isBefore(e) {
      return this.endExclusive <= e.start
    }
    isAfter(e) {
      return this.start >= e.endExclusive
    }
    slice(e) {
      return e.slice(this.start, this.endExclusive)
    }
    substring(e) {
      return e.substring(this.start, this.endExclusive)
    }
    clip(e) {
      if (this.isEmpty) throw new ue(`Invalid clipping range: ${this.toString()}`);
      return Math.max(this.start, Math.min(this.endExclusive - 1, e))
    }
    clipCyclic(e) {
      if (this.isEmpty) throw new ue(`Invalid clipping range: ${this.toString()}`);
      return e < this.start ? this.endExclusive - (this.start - e) % this.length : e >= this.endExclusive ? this.start + (e - this.start) % this.length : e
    }
    forEach(e) {
      for (let n = this.start; n < this.endExclusive; n++) e(n)
    }
    joinRightTouching(e) {
      if (this.endExclusive !== e.start) throw new ue(`Invalid join: ${this.toString()} and ${e.toString()}`);
      return new G(this.start, e.endExclusive)
    }
  }

  function mt(t, e) {
    const n = ft(t, e);
    return n === -1 ? void 0 : t[n]
  }

  function ft(t, e, n = 0, i = t.length) {
    let r = n,
      s = i;
    for (; r < s;) {
      const a = Math.floor((r + s) / 2);
      e(t[a]) ? r = a + 1 : s = a
    }
    return r - 1
  }

  function ru(t, e) {
    const n = ai(t, e);
    return n === t.length ? void 0 : t[n]
  }

  function ai(t, e, n = 0, i = t.length) {
    let r = n,
      s = i;
    for (; r < s;) {
      const a = Math.floor((r + s) / 2);
      e(t[a]) ? s = a : r = a + 1
    }
    return r
  }
  const Sn = class Sn {
    constructor(e) {
      this._array = e, this._findLastMonotonousLastIdx = 0
    }
    findLastMonotonous(e) {
      if (Sn.assertInvariants) {
        if (this._prevFindLastPredicate) {
          for (const i of this._array)
            if (this._prevFindLastPredicate(i) && !e(i)) throw new Error("MonotonousArray: current predicate must be weaker than (or equal to) the previous predicate.")
        }
        this._prevFindLastPredicate = e
      }
      const n = ft(this._array, e, this._findLastMonotonousLastIdx);
      return this._findLastMonotonousLastIdx = n + 1, n === -1 ? void 0 : this._array[n]
    }
  };
  Sn.assertInvariants = !1;
  let an = Sn;
  const _e = class _e {
    static ofLength(e, n) {
      return new _e(e, e + n)
    }
    static fromRange(e) {
      return new _e(e.startLineNumber, e.endLineNumber)
    }
    static fromRangeInclusive(e) {
      return new _e(e.startLineNumber, e.endLineNumber + 1)
    }
    static joinMany(e) {
      if (e.length === 0) return [];
      let n = new Me(e[0].slice());
      for (let i = 1; i < e.length; i++) n = n.getUnion(new Me(e[i].slice()));
      return n.ranges
    }
    static join(e) {
      if (e.length === 0) throw new ue("lineRanges cannot be empty");
      let n = e[0].startLineNumber,
        i = e[0].endLineNumberExclusive;
      for (let r = 1; r < e.length; r++) n = Math.min(n, e[r].startLineNumber), i = Math.max(i, e[r].endLineNumberExclusive);
      return new _e(n, i)
    }
    static deserialize(e) {
      return new _e(e[0], e[1])
    }
    constructor(e, n) {
      if (e > n) throw new ue(`startLineNumber ${e} cannot be after endLineNumberExclusive ${n}`);
      this.startLineNumber = e, this.endLineNumberExclusive = n
    }
    contains(e) {
      return this.startLineNumber <= e && e < this.endLineNumberExclusive
    }
    get isEmpty() {
      return this.startLineNumber === this.endLineNumberExclusive
    }
    delta(e) {
      return new _e(this.startLineNumber + e, this.endLineNumberExclusive + e)
    }
    deltaLength(e) {
      return new _e(this.startLineNumber, this.endLineNumberExclusive + e)
    }
    get length() {
      return this.endLineNumberExclusive - this.startLineNumber
    }
    join(e) {
      return new _e(Math.min(this.startLineNumber, e.startLineNumber), Math.max(this.endLineNumberExclusive, e.endLineNumberExclusive))
    }
    toString() {
      return `[${this.startLineNumber},${this.endLineNumberExclusive})`
    }
    intersect(e) {
      const n = Math.max(this.startLineNumber, e.startLineNumber),
        i = Math.min(this.endLineNumberExclusive, e.endLineNumberExclusive);
      if (n <= i) return new _e(n, i)
    }
    intersectsStrict(e) {
      return this.startLineNumber < e.endLineNumberExclusive && e.startLineNumber < this.endLineNumberExclusive
    }
    intersectsOrTouches(e) {
      return this.startLineNumber <= e.endLineNumberExclusive && e.startLineNumber <= this.endLineNumberExclusive
    }
    equals(e) {
      return this.startLineNumber === e.startLineNumber && this.endLineNumberExclusive === e.endLineNumberExclusive
    }
    toInclusiveRange() {
      return this.isEmpty ? null : new j(this.startLineNumber, 1, this.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER)
    }
    toExclusiveRange() {
      return new j(this.startLineNumber, 1, this.endLineNumberExclusive, 1)
    }
    mapToLineArray(e) {
      const n = [];
      for (let i = this.startLineNumber; i < this.endLineNumberExclusive; i++) n.push(e(i));
      return n
    }
    forEach(e) {
      for (let n = this.startLineNumber; n < this.endLineNumberExclusive; n++) e(n)
    }
    serialize() {
      return [this.startLineNumber, this.endLineNumberExclusive]
    }
    toOffsetRange() {
      return new G(this.startLineNumber - 1, this.endLineNumberExclusive - 1)
    }
    addMargin(e, n) {
      return new _e(this.startLineNumber - e, this.endLineNumberExclusive + n)
    }
  };
  _e.compareByStart = Mt(e => e.startLineNumber, Nt);
  let X = _e;
  class Me {
    constructor(e = []) {
      this._normalizedRanges = e
    }
    get ranges() {
      return this._normalizedRanges
    }
    addRange(e) {
      if (e.length === 0) return;
      const n = ai(this._normalizedRanges, r => r.endLineNumberExclusive >= e.startLineNumber),
        i = ft(this._normalizedRanges, r => r.startLineNumber <= e.endLineNumberExclusive) + 1;
      if (n === i) this._normalizedRanges.splice(n, 0, e);
      else if (n === i - 1) {
        const r = this._normalizedRanges[n];
        this._normalizedRanges[n] = r.join(e)
      } else {
        const r = this._normalizedRanges[n].join(this._normalizedRanges[i - 1]).join(e);
        this._normalizedRanges.splice(n, i - n, r)
      }
    }
    contains(e) {
      const n = mt(this._normalizedRanges, i => i.startLineNumber <= e);
      return !!n && n.endLineNumberExclusive > e
    }
    intersects(e) {
      const n = mt(this._normalizedRanges, i => i.startLineNumber < e.endLineNumberExclusive);
      return !!n && n.endLineNumberExclusive > e.startLineNumber
    }
    getUnion(e) {
      if (this._normalizedRanges.length === 0) return e;
      if (e._normalizedRanges.length === 0) return this;
      const n = [];
      let i = 0,
        r = 0,
        s = null;
      for (; i < this._normalizedRanges.length || r < e._normalizedRanges.length;) {
        let a = null;
        if (i < this._normalizedRanges.length && r < e._normalizedRanges.length) {
          const l = this._normalizedRanges[i],
            o = e._normalizedRanges[r];
          l.startLineNumber < o.startLineNumber ? (a = l, i++) : (a = o, r++)
        } else i < this._normalizedRanges.length ? (a = this._normalizedRanges[i], i++) : (a = e._normalizedRanges[r], r++);
        s === null ? s = a : s.endLineNumberExclusive >= a.startLineNumber ? s = new X(s.startLineNumber, Math.max(s.endLineNumberExclusive, a.endLineNumberExclusive)) : (n.push(s), s = a)
      }
      return s !== null && n.push(s), new Me(n)
    }
    subtractFrom(e) {
      const n = ai(this._normalizedRanges, a => a.endLineNumberExclusive >= e.startLineNumber),
        i = ft(this._normalizedRanges, a => a.startLineNumber <= e.endLineNumberExclusive) + 1;
      if (n === i) return new Me([e]);
      const r = [];
      let s = e.startLineNumber;
      for (let a = n; a < i; a++) {
        const l = this._normalizedRanges[a];
        l.startLineNumber > s && r.push(new X(s, l.startLineNumber)), s = l.endLineNumberExclusive
      }
      return s < e.endLineNumberExclusive && r.push(new X(s, e.endLineNumberExclusive)), new Me(r)
    }
    toString() {
      return this._normalizedRanges.map(e => e.toString()).join(", ")
    }
    getIntersection(e) {
      const n = [];
      let i = 0,
        r = 0;
      for (; i < this._normalizedRanges.length && r < e._normalizedRanges.length;) {
        const s = this._normalizedRanges[i],
          a = e._normalizedRanges[r],
          l = s.intersect(a);
        l && !l.isEmpty && n.push(l), s.endLineNumberExclusive < a.endLineNumberExclusive ? i++ : r++
      }
      return new Me(n)
    }
    getWithDelta(e) {
      return new Me(this._normalizedRanges.map(n => n.delta(e)))
    }
  }
  const Ce = class Ce {
    static betweenPositions(e, n) {
      return e.lineNumber === n.lineNumber ? new Ce(0, n.column - e.column) : new Ce(n.lineNumber - e.lineNumber, n.column - 1)
    }
    static fromPosition(e) {
      return new Ce(e.lineNumber - 1, e.column - 1)
    }
    static ofRange(e) {
      return Ce.betweenPositions(e.getStartPosition(), e.getEndPosition())
    }
    static ofText(e) {
      let n = 0,
        i = 0;
      for (const r of e) r === `
` ? (n++, i = 0) : i++;
      return new Ce(n, i)
    }
    constructor(e, n) {
      this.lineCount = e, this.columnCount = n
    }
    isGreaterThanOrEqualTo(e) {
      return this.lineCount !== e.lineCount ? this.lineCount > e.lineCount : this.columnCount >= e.columnCount
    }
    add(e) {
      return e.lineCount === 0 ? new Ce(this.lineCount, this.columnCount + e.columnCount) : new Ce(this.lineCount + e.lineCount, e.columnCount)
    }
    createRange(e) {
      return this.lineCount === 0 ? new j(e.lineNumber, e.column, e.lineNumber, e.column + this.columnCount) : new j(e.lineNumber, e.column, e.lineNumber + this.lineCount, this.columnCount + 1)
    }
    toRange() {
      return new j(1, 1, this.lineCount + 1, this.columnCount + 1)
    }
    toLineRange() {
      return X.ofLength(1, this.lineCount + 1)
    }
    addToPosition(e) {
      return this.lineCount === 0 ? new K(e.lineNumber, e.column + this.columnCount) : new K(e.lineNumber + this.lineCount, this.columnCount + 1)
    }
    toString() {
      return `${this.lineCount},${this.columnCount}`
    }
  };
  Ce.zero = new Ce(0, 0);
  let It = Ce;
  class su {
    getOffsetRange(e) {
      return new G(this.getOffset(e.getStartPosition()), this.getOffset(e.getEndPosition()))
    }
    getRange(e) {
      return j.fromPositions(this.getPosition(e.start), this.getPosition(e.endExclusive))
    }
    getStringReplacement(e) {
      return new pt.deps.StringReplacement(this.getOffsetRange(e.range), e.text)
    }
    getTextReplacement(e) {
      return new pt.deps.TextReplacement(this.getRange(e.replaceRange), e.newText)
    }
    getTextEdit(e) {
      const n = e.replacements.map(i => this.getTextReplacement(i));
      return new pt.deps.TextEdit(n)
    }
  }
  const Hi = class Hi {
    static get deps() {
      if (!this._deps) throw new Error("Dependencies not set. Call _setDependencies first.");
      return this._deps
    }
  };
  Hi._deps = void 0;
  let pt = Hi;
  class au extends su {
    constructor(e) {
      super(), this.text = e, this.lineStartOffsetByLineIdx = [], this.lineEndOffsetByLineIdx = [], this.lineStartOffsetByLineIdx.push(0);
      for (let n = 0; n < e.length; n++) e.charAt(n) === `
` && (this.lineStartOffsetByLineIdx.push(n + 1), n > 0 && e.charAt(n - 1) === "\r" ? this.lineEndOffsetByLineIdx.push(n - 1) : this.lineEndOffsetByLineIdx.push(n));
      this.lineEndOffsetByLineIdx.push(e.length)
    }
    getOffset(e) {
      const n = this._validatePosition(e);
      return this.lineStartOffsetByLineIdx[n.lineNumber - 1] + n.column - 1
    }
    _validatePosition(e) {
      if (e.lineNumber < 1) return new K(1, 1);
      const n = this.textLength.lineCount + 1;
      if (e.lineNumber > n) {
        const r = this.getLineLength(n);
        return new K(n, r + 1)
      }
      if (e.column < 1) return new K(e.lineNumber, 1);
      const i = this.getLineLength(e.lineNumber);
      return e.column - 1 > i ? new K(e.lineNumber, i + 1) : e
    }
    getPosition(e) {
      const n = ft(this.lineStartOffsetByLineIdx, s => s <= e),
        i = n + 1,
        r = e - this.lineStartOffsetByLineIdx[n] + 1;
      return new K(i, r)
    }
    get textLength() {
      const e = this.lineStartOffsetByLineIdx.length - 1;
      return new pt.deps.TextLength(e, this.text.length - this.lineStartOffsetByLineIdx[e])
    }
    getLineLength(e) {
      return this.lineEndOffsetByLineIdx[e - 1] - this.lineStartOffsetByLineIdx[e - 1]
    }
  }
  class ou {
    constructor() {
      this._transformer = void 0
    }
    get endPositionExclusive() {
      return this.length.addToPosition(new K(1, 1))
    }
    get lineRange() {
      return this.length.toLineRange()
    }
    getValue() {
      return this.getValueOfRange(this.length.toRange())
    }
    getValueOfOffsetRange(e) {
      return this.getValueOfRange(this.getTransformer().getRange(e))
    }
    getLineLength(e) {
      return this.getValueOfRange(new j(e, 1, e, Number.MAX_SAFE_INTEGER)).length
    }
    getTransformer() {
      return this._transformer || (this._transformer = new au(this.getValue())), this._transformer
    }
    getLineAt(e) {
      return this.getValueOfRange(new j(e, 1, e, Number.MAX_SAFE_INTEGER))
    }
  }
  class lu extends ou {
    constructor(e, n) {
      mo(n >= 1), super(), this._getLineContent = e, this._lineCount = n
    }
    getValueOfRange(e) {
      if (e.startLineNumber === e.endLineNumber) return this._getLineContent(e.startLineNumber).substring(e.startColumn - 1, e.endColumn - 1);
      let n = this._getLineContent(e.startLineNumber).substring(e.startColumn - 1);
      for (let i = e.startLineNumber + 1; i < e.endLineNumber; i++) n += `
` + this._getLineContent(i);
      return n += `
` + this._getLineContent(e.endLineNumber).substring(0, e.endColumn - 1), n
    }
    getLineLength(e) {
      return this._getLineContent(e).length
    }
    get length() {
      const e = this._getLineContent(this._lineCount);
      return new It(this._lineCount - 1, e.length)
    }
  }
  class on extends lu {
    constructor(e) {
      super(n => e[n - 1], e.length)
    }
  }
  class Ge {
    static joinReplacements(e, n) {
      if (e.length === 0) throw new ue;
      if (e.length === 1) return e[0];
      const i = e[0].range.getStartPosition(),
        r = e[e.length - 1].range.getEndPosition();
      let s = "";
      for (let a = 0; a < e.length; a++) {
        const l = e[a];
        if (s += l.text, a < e.length - 1) {
          const o = e[a + 1],
            u = j.fromPositions(l.range.getEndPosition(), o.range.getStartPosition()),
            c = n.getValueOfRange(u);
          s += c
        }
      }
      return new Ge(j.fromPositions(i, r), s)
    }
    static fromStringReplacement(e, n) {
      return new Ge(n.getTransformer().getRange(e.replaceRange), e.newText)
    }
    static delete(e) {
      return new Ge(e, "")
    }
    constructor(e, n) {
      this.range = e, this.text = n
    }
    get isEmpty() {
      return this.range.isEmpty() && this.text.length === 0
    }
    static equals(e, n) {
      return e.range.equalsRange(n.range) && e.text === n.text
    }
    equals(e) {
      return Ge.equals(this, e)
    }
    removeCommonPrefixAndSuffix(e) {
      return this.removeCommonPrefix(e).removeCommonSuffix(e)
    }
    removeCommonPrefix(e) {
      const n = e.getValueOfRange(this.range).replaceAll(`\r
`, `
`),
        i = this.text.replaceAll(`\r
`, `
`),
        r = Fo(n, i),
        s = It.ofText(n.substring(0, r)).addToPosition(this.range.getStartPosition()),
        a = i.substring(r),
        l = j.fromPositions(s, this.range.getEndPosition());
      return new Ge(l, a)
    }
    removeCommonSuffix(e) {
      const n = e.getValueOfRange(this.range).replaceAll(`\r
`, `
`),
        i = this.text.replaceAll(`\r
`, `
`),
        r = Bo(n, i),
        s = It.ofText(n.substring(0, n.length - r)).addToPosition(this.range.getStartPosition()),
        a = i.substring(0, i.length - r),
        l = j.fromPositions(this.range.getStartPosition(), s);
      return new Ge(l, a)
    }
    toString() {
      const e = this.range.getStartPosition(),
        n = this.range.getEndPosition();
      return `(${e.lineNumber},${e.column} -> ${n.lineNumber},${n.column}): "${this.text}"`
    }
  }
  class ve {
    static inverse(e, n, i) {
      const r = [];
      let s = 1,
        a = 1;
      for (const o of e) {
        const u = new ve(new X(s, o.original.startLineNumber), new X(a, o.modified.startLineNumber));
        u.modified.isEmpty || r.push(u), s = o.original.endLineNumberExclusive, a = o.modified.endLineNumberExclusive
      }
      const l = new ve(new X(s, n + 1), new X(a, i + 1));
      return l.modified.isEmpty || r.push(l), r
    }
    static clip(e, n, i) {
      const r = [];
      for (const s of e) {
        const a = s.original.intersect(n),
          l = s.modified.intersect(i);
        a && !a.isEmpty && l && !l.isEmpty && r.push(new ve(a, l))
      }
      return r
    }
    constructor(e, n) {
      this.original = e, this.modified = n
    }
    toString() {
      return `{${this.original.toString()}->${this.modified.toString()}}`
    }
    flip() {
      return new ve(this.modified, this.original)
    }
    join(e) {
      return new ve(this.original.join(e.original), this.modified.join(e.modified))
    }
    toRangeMapping() {
      const e = this.original.toInclusiveRange(),
        n = this.modified.toInclusiveRange();
      if (e && n) return new ye(e, n);
      if (this.original.startLineNumber === 1 || this.modified.startLineNumber === 1) {
        if (!(this.modified.startLineNumber === 1 && this.original.startLineNumber === 1)) throw new ue("not a valid diff");
        return new ye(new j(this.original.startLineNumber, 1, this.original.endLineNumberExclusive, 1), new j(this.modified.startLineNumber, 1, this.modified.endLineNumberExclusive, 1))
      } else return new ye(new j(this.original.startLineNumber - 1, Number.MAX_SAFE_INTEGER, this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), new j(this.modified.startLineNumber - 1, Number.MAX_SAFE_INTEGER, this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER))
    }
    toRangeMapping2(e, n) {
      if (xs(this.original.endLineNumberExclusive, e) && xs(this.modified.endLineNumberExclusive, n)) return new ye(new j(this.original.startLineNumber, 1, this.original.endLineNumberExclusive, 1), new j(this.modified.startLineNumber, 1, this.modified.endLineNumberExclusive, 1));
      if (!this.original.isEmpty && !this.modified.isEmpty) return new ye(j.fromPositions(new K(this.original.startLineNumber, 1), gt(new K(this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), e)), j.fromPositions(new K(this.modified.startLineNumber, 1), gt(new K(this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), n)));
      if (this.original.startLineNumber > 1 && this.modified.startLineNumber > 1) return new ye(j.fromPositions(gt(new K(this.original.startLineNumber - 1, Number.MAX_SAFE_INTEGER), e), gt(new K(this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), e)), j.fromPositions(gt(new K(this.modified.startLineNumber - 1, Number.MAX_SAFE_INTEGER), n), gt(new K(this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), n)));
      throw new ue
    }
  }

  function gt(t, e) {
    if (t.lineNumber < 1) return new K(1, 1);
    if (t.lineNumber > e.length) return new K(e.length, e[e.length - 1].length + 1);
    const n = e[t.lineNumber - 1];
    return t.column > n.length + 1 ? new K(t.lineNumber, n.length + 1) : t
  }

  function xs(t, e) {
    return t >= 1 && t <= e.length
  }
  class We extends ve {
    static fromRangeMappings(e) {
      const n = X.join(e.map(r => X.fromRangeInclusive(r.originalRange))),
        i = X.join(e.map(r => X.fromRangeInclusive(r.modifiedRange)));
      return new We(n, i, e)
    }
    constructor(e, n, i) {
      super(e, n), this.innerChanges = i
    }
    flip() {
      var e;
      return new We(this.modified, this.original, (e = this.innerChanges) == null ? void 0 : e.map(n => n.flip()))
    }
    withInnerChangesFromLineRanges() {
      return new We(this.original, this.modified, [this.toRangeMapping()])
    }
  }
  class ye {
    static fromEdit(e) {
      const n = e.getNewRanges();
      return e.replacements.map((r, s) => new ye(r.range, n[s]))
    }
    static assertSorted(e) {
      for (let n = 1; n < e.length; n++) {
        const i = e[n - 1],
          r = e[n];
        if (!(i.originalRange.getEndPosition().isBeforeOrEqual(r.originalRange.getStartPosition()) && i.modifiedRange.getEndPosition().isBeforeOrEqual(r.modifiedRange.getStartPosition()))) throw new ue("Range mappings must be sorted")
      }
    }
    constructor(e, n) {
      this.originalRange = e, this.modifiedRange = n
    }
    toString() {
      return `{${this.originalRange.toString()}->${this.modifiedRange.toString()}}`
    }
    flip() {
      return new ye(this.modifiedRange, this.originalRange)
    }
    toTextEdit(e) {
      const n = e.getValueOfRange(this.modifiedRange);
      return new Ge(this.originalRange, n)
    }
  }

  function ks(t, e, n, i = !1) {
    const r = [];
    for (const s of Kl(t.map(a => uu(a, e, n)), (a, l) => a.original.intersectsOrTouches(l.original) || a.modified.intersectsOrTouches(l.modified))) {
      const a = s[0],
        l = s[s.length - 1];
      r.push(new We(a.original.join(l.original), a.modified.join(l.modified), s.map(o => o.innerChanges[0])))
    }
    return $t(() => !i && r.length > 0 && (r[0].modified.startLineNumber !== r[0].original.startLineNumber || n.length.lineCount - r[r.length - 1].modified.endLineNumberExclusive !== e.length.lineCount - r[r.length - 1].original.endLineNumberExclusive) ? !1 : Pi(r, (s, a) => a.original.startLineNumber - s.original.endLineNumberExclusive === a.modified.startLineNumber - s.modified.endLineNumberExclusive && s.original.endLineNumberExclusive < a.original.startLineNumber && s.modified.endLineNumberExclusive < a.modified.startLineNumber)), r
  }

  function uu(t, e, n) {
    let i = 0,
      r = 0;
    t.modifiedRange.endColumn === 1 && t.originalRange.endColumn === 1 && t.originalRange.startLineNumber + i <= t.originalRange.endLineNumber && t.modifiedRange.startLineNumber + i <= t.modifiedRange.endLineNumber && (r = -1), t.modifiedRange.startColumn - 1 >= n.getLineLength(t.modifiedRange.startLineNumber) && t.originalRange.startColumn - 1 >= e.getLineLength(t.originalRange.startLineNumber) && t.originalRange.startLineNumber <= t.originalRange.endLineNumber + r && t.modifiedRange.startLineNumber <= t.modifiedRange.endLineNumber + r && (i = 1);
    const s = new X(t.originalRange.startLineNumber + i, t.originalRange.endLineNumber + 1 + r),
      a = new X(t.modifiedRange.startLineNumber + i, t.modifiedRange.endLineNumber + 1 + r);
    return new We(s, a, [t])
  }
  const cu = 3;
  class hu {
    computeDiff(e, n, i) {
      var o;
      const s = new fu(e, n, {
          maxComputationTime: i.maxComputationTimeMs,
          shouldIgnoreTrimWhitespace: i.ignoreTrimWhitespace,
          shouldComputeCharChanges: !0,
          shouldMakePrettyDiff: !0,
          shouldPostProcessCharChanges: !0
        }).computeDiff(),
        a = [];
      let l = null;
      for (const u of s.changes) {
        let c;
        u.originalEndLineNumber === 0 ? c = new X(u.originalStartLineNumber + 1, u.originalStartLineNumber + 1) : c = new X(u.originalStartLineNumber, u.originalEndLineNumber + 1);
        let d;
        u.modifiedEndLineNumber === 0 ? d = new X(u.modifiedStartLineNumber + 1, u.modifiedStartLineNumber + 1) : d = new X(u.modifiedStartLineNumber, u.modifiedEndLineNumber + 1);
        let m = new We(c, d, (o = u.charChanges) == null ? void 0 : o.map(f => new ye(new j(f.originalStartLineNumber, f.originalStartColumn, f.originalEndLineNumber, f.originalEndColumn), new j(f.modifiedStartLineNumber, f.modifiedStartColumn, f.modifiedEndLineNumber, f.modifiedEndColumn))));
        l && (l.modified.endLineNumberExclusive === m.modified.startLineNumber || l.original.endLineNumberExclusive === m.original.startLineNumber) && (m = new We(l.original.join(m.original), l.modified.join(m.modified), l.innerChanges && m.innerChanges ? l.innerChanges.concat(m.innerChanges) : void 0), a.pop()), a.push(m), l = m
      }
      return $t(() => Pi(a, (u, c) => c.original.startLineNumber - u.original.endLineNumberExclusive === c.modified.startLineNumber - u.modified.endLineNumberExclusive && u.original.endLineNumberExclusive < c.original.startLineNumber && u.modified.endLineNumberExclusive < c.modified.startLineNumber)), new sn(a, [], s.quitEarly)
    }
  }

  function Ss(t, e, n, i) {
    return new je(t, e, n).ComputeDiff(i)
  }
  let As = class {
    constructor(e) {
      const n = [],
        i = [];
      for (let r = 0, s = e.length; r < s; r++) n[r] = oi(e[r], 1), i[r] = li(e[r], 1);
      this.lines = e, this._startColumns = n, this._endColumns = i
    }
    getElements() {
      const e = [];
      for (let n = 0, i = this.lines.length; n < i; n++) e[n] = this.lines[n].substring(this._startColumns[n] - 1, this._endColumns[n] - 1);
      return e
    }
    getStrictElement(e) {
      return this.lines[e]
    }
    getStartLineNumber(e) {
      return e + 1
    }
    getEndLineNumber(e) {
      return e + 1
    }
    createCharSequence(e, n, i) {
      const r = [],
        s = [],
        a = [];
      let l = 0;
      for (let o = n; o <= i; o++) {
        const u = this.lines[o],
          c = e ? this._startColumns[o] : 1,
          d = e ? this._endColumns[o] : u.length + 1;
        for (let m = c; m < d; m++) r[l] = u.charCodeAt(m - 1), s[l] = o + 1, a[l] = m, l++;
        !e && o < i && (r[l] = 10, s[l] = o + 1, a[l] = u.length + 1, l++)
      }
      return new du(r, s, a)
    }
  };
  class du {
    constructor(e, n, i) {
      this._charCodes = e, this._lineNumbers = n, this._columns = i
    }
    toString() {
      return "[" + this._charCodes.map((e, n) => (e === 10 ? "\\n" : String.fromCharCode(e)) + `-(${this._lineNumbers[n]},${this._columns[n]})`).join(", ") + "]"
    }
    _assertIndex(e, n) {
      if (e < 0 || e >= n.length) throw new Error("Illegal index")
    }
    getElements() {
      return this._charCodes
    }
    getStartLineNumber(e) {
      return e > 0 && e === this._lineNumbers.length ? this.getEndLineNumber(e - 1) : (this._assertIndex(e, this._lineNumbers), this._lineNumbers[e])
    }
    getEndLineNumber(e) {
      return e === -1 ? this.getStartLineNumber(e + 1) : (this._assertIndex(e, this._lineNumbers), this._charCodes[e] === 10 ? this._lineNumbers[e] + 1 : this._lineNumbers[e])
    }
    getStartColumn(e) {
      return e > 0 && e === this._columns.length ? this.getEndColumn(e - 1) : (this._assertIndex(e, this._columns), this._columns[e])
    }
    getEndColumn(e) {
      return e === -1 ? this.getStartColumn(e + 1) : (this._assertIndex(e, this._columns), this._charCodes[e] === 10 ? 1 : this._columns[e] + 1)
    }
  }
  class bt {
    constructor(e, n, i, r, s, a, l, o) {
      this.originalStartLineNumber = e, this.originalStartColumn = n, this.originalEndLineNumber = i, this.originalEndColumn = r, this.modifiedStartLineNumber = s, this.modifiedStartColumn = a, this.modifiedEndLineNumber = l, this.modifiedEndColumn = o
    }
    static createFromDiffChange(e, n, i) {
      const r = n.getStartLineNumber(e.originalStart),
        s = n.getStartColumn(e.originalStart),
        a = n.getEndLineNumber(e.originalStart + e.originalLength - 1),
        l = n.getEndColumn(e.originalStart + e.originalLength - 1),
        o = i.getStartLineNumber(e.modifiedStart),
        u = i.getStartColumn(e.modifiedStart),
        c = i.getEndLineNumber(e.modifiedStart + e.modifiedLength - 1),
        d = i.getEndColumn(e.modifiedStart + e.modifiedLength - 1);
      return new bt(r, s, a, l, o, u, c, d)
    }
  }

  function mu(t) {
    if (t.length <= 1) return t;
    const e = [t[0]];
    let n = e[0];
    for (let i = 1, r = t.length; i < r; i++) {
      const s = t[i],
        a = s.originalStart - (n.originalStart + n.originalLength),
        l = s.modifiedStart - (n.modifiedStart + n.modifiedLength);
      Math.min(a, l) < cu ? (n.originalLength = s.originalStart + s.originalLength - n.originalStart, n.modifiedLength = s.modifiedStart + s.modifiedLength - n.modifiedStart) : (e.push(s), n = s)
    }
    return e
  }
  class zt {
    constructor(e, n, i, r, s) {
      this.originalStartLineNumber = e, this.originalEndLineNumber = n, this.modifiedStartLineNumber = i, this.modifiedEndLineNumber = r, this.charChanges = s
    }
    static createFromDiffResult(e, n, i, r, s, a, l) {
      let o, u, c, d, m;
      if (n.originalLength === 0 ? (o = i.getStartLineNumber(n.originalStart) - 1, u = 0) : (o = i.getStartLineNumber(n.originalStart), u = i.getEndLineNumber(n.originalStart + n.originalLength - 1)), n.modifiedLength === 0 ? (c = r.getStartLineNumber(n.modifiedStart) - 1, d = 0) : (c = r.getStartLineNumber(n.modifiedStart), d = r.getEndLineNumber(n.modifiedStart + n.modifiedLength - 1)), a && n.originalLength > 0 && n.originalLength < 20 && n.modifiedLength > 0 && n.modifiedLength < 20 && s()) {
        const f = i.createCharSequence(e, n.originalStart, n.originalStart + n.originalLength - 1),
          w = r.createCharSequence(e, n.modifiedStart, n.modifiedStart + n.modifiedLength - 1);
        if (f.getElements().length > 0 && w.getElements().length > 0) {
          let p = Ss(f, w, s, !0).changes;
          l && (p = mu(p)), m = [];
          for (let x = 0, T = p.length; x < T; x++) m.push(bt.createFromDiffChange(p[x], f, w))
        }
      }
      return new zt(o, u, c, d, m)
    }
  }
  class fu {
    constructor(e, n, i) {
      this.shouldComputeCharChanges = i.shouldComputeCharChanges, this.shouldPostProcessCharChanges = i.shouldPostProcessCharChanges, this.shouldIgnoreTrimWhitespace = i.shouldIgnoreTrimWhitespace, this.shouldMakePrettyDiff = i.shouldMakePrettyDiff, this.originalLines = e, this.modifiedLines = n, this.original = new As(e), this.modified = new As(n), this.continueLineDiff = Ls(i.maxComputationTime), this.continueCharDiff = Ls(i.maxComputationTime === 0 ? 0 : Math.min(i.maxComputationTime, 5e3))
    }
    computeDiff() {
      if (this.original.lines.length === 1 && this.original.lines[0].length === 0) return this.modified.lines.length === 1 && this.modified.lines[0].length === 0 ? {
        quitEarly: !1,
        changes: []
      } : {
        quitEarly: !1,
        changes: [{
          originalStartLineNumber: 1,
          originalEndLineNumber: 1,
          modifiedStartLineNumber: 1,
          modifiedEndLineNumber: this.modified.lines.length,
          charChanges: void 0
        }]
      };
      if (this.modified.lines.length === 1 && this.modified.lines[0].length === 0) return {
        quitEarly: !1,
        changes: [{
          originalStartLineNumber: 1,
          originalEndLineNumber: this.original.lines.length,
          modifiedStartLineNumber: 1,
          modifiedEndLineNumber: 1,
          charChanges: void 0
        }]
      };
      const e = Ss(this.original, this.modified, this.continueLineDiff, this.shouldMakePrettyDiff),
        n = e.changes,
        i = e.quitEarly;
      if (this.shouldIgnoreTrimWhitespace) {
        const l = [];
        for (let o = 0, u = n.length; o < u; o++) l.push(zt.createFromDiffResult(this.shouldIgnoreTrimWhitespace, n[o], this.original, this.modified, this.continueCharDiff, this.shouldComputeCharChanges, this.shouldPostProcessCharChanges));
        return {
          quitEarly: i,
          changes: l
        }
      }
      const r = [];
      let s = 0,
        a = 0;
      for (let l = -1, o = n.length; l < o; l++) {
        const u = l + 1 < o ? n[l + 1] : null,
          c = u ? u.originalStart : this.originalLines.length,
          d = u ? u.modifiedStart : this.modifiedLines.length;
        for (; s < c && a < d;) {
          const m = this.originalLines[s],
            f = this.modifiedLines[a];
          if (m !== f) {
            {
              let w = oi(m, 1),
                p = oi(f, 1);
              for (; w > 1 && p > 1;) {
                const x = m.charCodeAt(w - 2),
                  T = f.charCodeAt(p - 2);
                if (x !== T) break;
                w--, p--
              }(w > 1 || p > 1) && this._pushTrimWhitespaceCharChange(r, s + 1, 1, w, a + 1, 1, p)
            } {
              let w = li(m, 1),
                p = li(f, 1);
              const x = m.length + 1,
                T = f.length + 1;
              for (; w < x && p < T;) {
                const y = m.charCodeAt(w - 1),
                  L = m.charCodeAt(p - 1);
                if (y !== L) break;
                w++, p++
              }(w < x || p < T) && this._pushTrimWhitespaceCharChange(r, s + 1, w, x, a + 1, p, T)
            }
          }
          s++, a++
        }
        u && (r.push(zt.createFromDiffResult(this.shouldIgnoreTrimWhitespace, u, this.original, this.modified, this.continueCharDiff, this.shouldComputeCharChanges, this.shouldPostProcessCharChanges)), s += u.originalLength, a += u.modifiedLength)
      }
      return {
        quitEarly: i,
        changes: r
      }
    }
    _pushTrimWhitespaceCharChange(e, n, i, r, s, a, l) {
      if (this._mergeTrimWhitespaceCharChange(e, n, i, r, s, a, l)) return;
      let o;
      this.shouldComputeCharChanges && (o = [new bt(n, i, n, r, s, a, s, l)]), e.push(new zt(n, n, s, s, o))
    }
    _mergeTrimWhitespaceCharChange(e, n, i, r, s, a, l) {
      const o = e.length;
      if (o === 0) return !1;
      const u = e[o - 1];
      return u.originalEndLineNumber === 0 || u.modifiedEndLineNumber === 0 ? !1 : u.originalEndLineNumber === n && u.modifiedEndLineNumber === s ? (this.shouldComputeCharChanges && u.charChanges && u.charChanges.push(new bt(n, i, n, r, s, a, s, l)), !0) : u.originalEndLineNumber + 1 === n && u.modifiedEndLineNumber + 1 === s ? (u.originalEndLineNumber = n, u.modifiedEndLineNumber = s, this.shouldComputeCharChanges && u.charChanges && u.charChanges.push(new bt(n, i, n, r, s, a, s, l)), !0) : !1
    }
  }

  function oi(t, e) {
    const n = Po(t);
    return n === -1 ? e : n + 1
  }

  function li(t, e) {
    const n = Wo(t);
    return n === -1 ? e : n + 2
  }

  function Ls(t) {
    if (t === 0) return () => !0;
    const e = Date.now();
    return () => Date.now() - e < t
  }
  class Fe {
    static trivial(e, n) {
      return new Fe([new ne(G.ofLength(e.length), G.ofLength(n.length))], !1)
    }
    static trivialTimedOut(e, n) {
      return new Fe([new ne(G.ofLength(e.length), G.ofLength(n.length))], !0)
    }
    constructor(e, n) {
      this.diffs = e, this.hitTimeout = n
    }
  }
  class ne {
    static invert(e, n) {
      const i = [];
      return eu(e, (r, s) => {
        i.push(ne.fromOffsetPairs(r ? r.getEndExclusives() : Be.zero, s ? s.getStarts() : new Be(n, (r ? r.seq2Range.endExclusive - r.seq1Range.endExclusive : 0) + n)))
      }), i
    }
    static fromOffsetPairs(e, n) {
      return new ne(new G(e.offset1, n.offset1), new G(e.offset2, n.offset2))
    }
    static assertSorted(e) {
      let n;
      for (const i of e) {
        if (n && !(n.seq1Range.endExclusive <= i.seq1Range.start && n.seq2Range.endExclusive <= i.seq2Range.start)) throw new ue("Sequence diffs must be sorted");
        n = i
      }
    }
    constructor(e, n) {
      this.seq1Range = e, this.seq2Range = n
    }
    swap() {
      return new ne(this.seq2Range, this.seq1Range)
    }
    toString() {
      return `${this.seq1Range} <-> ${this.seq2Range}`
    }
    join(e) {
      return new ne(this.seq1Range.join(e.seq1Range), this.seq2Range.join(e.seq2Range))
    }
    delta(e) {
      return e === 0 ? this : new ne(this.seq1Range.delta(e), this.seq2Range.delta(e))
    }
    deltaStart(e) {
      return e === 0 ? this : new ne(this.seq1Range.deltaStart(e), this.seq2Range.deltaStart(e))
    }
    deltaEnd(e) {
      return e === 0 ? this : new ne(this.seq1Range.deltaEnd(e), this.seq2Range.deltaEnd(e))
    }
    intersect(e) {
      const n = this.seq1Range.intersect(e.seq1Range),
        i = this.seq2Range.intersect(e.seq2Range);
      if (!(!n || !i)) return new ne(n, i)
    }
    getStarts() {
      return new Be(this.seq1Range.start, this.seq2Range.start)
    }
    getEndExclusives() {
      return new Be(this.seq1Range.endExclusive, this.seq2Range.endExclusive)
    }
  }
  const it = class it {
    constructor(e, n) {
      this.offset1 = e, this.offset2 = n
    }
    toString() {
      return `${this.offset1} <-> ${this.offset2}`
    }
    delta(e) {
      return e === 0 ? this : new it(this.offset1 + e, this.offset2 + e)
    }
    equals(e) {
      return this.offset1 === e.offset1 && this.offset2 === e.offset2
    }
  };
  it.zero = new it(0, 0), it.max = new it(Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
  let Be = it;
  const An = class An {
    isValid() {
      return !0
    }
  };
  An.instance = new An;
  let Ht = An;
  class pu {
    constructor(e) {
      if (this.timeout = e, this.startTime = Date.now(), this.valid = !0, e <= 0) throw new ue("timeout must be positive")
    }
    isValid() {
      return !(Date.now() - this.startTime < this.timeout) && this.valid && (this.valid = !1), this.valid
    }
  }
  class ui {
    constructor(e, n) {
      this.width = e, this.height = n, this.array = [], this.array = new Array(e * n)
    }
    get(e, n) {
      return this.array[e + n * this.width]
    }
    set(e, n, i) {
      this.array[e + n * this.width] = i
    }
  }

  function ci(t) {
    return t === 32 || t === 9
  }
  const Vt = class Vt {
    static getKey(e) {
      let n = this.chrKeys.get(e);
      return n === void 0 && (n = this.chrKeys.size, this.chrKeys.set(e, n)), n
    }
    constructor(e, n, i) {
      this.range = e, this.lines = n, this.source = i, this.histogram = [];
      let r = 0;
      for (let s = e.startLineNumber - 1; s < e.endLineNumberExclusive - 1; s++) {
        const a = n[s];
        for (let o = 0; o < a.length; o++) {
          r++;
          const u = a[o],
            c = Vt.getKey(u);
          this.histogram[c] = (this.histogram[c] || 0) + 1
        }
        r++;
        const l = Vt.getKey(`
`);
        this.histogram[l] = (this.histogram[l] || 0) + 1
      }
      this.totalCount = r
    }
    computeSimilarity(e) {
      let n = 0;
      const i = Math.max(this.histogram.length, e.histogram.length);
      for (let r = 0; r < i; r++) n += Math.abs((this.histogram[r] ?? 0) - (e.histogram[r] ?? 0));
      return 1 - n / (this.totalCount + e.totalCount)
    }
  };
  Vt.chrKeys = new Map;
  let ln = Vt;
  class gu {
    compute(e, n, i = Ht.instance, r) {
      if (e.length === 0 || n.length === 0) return Fe.trivial(e, n);
      const s = new ui(e.length, n.length),
        a = new ui(e.length, n.length),
        l = new ui(e.length, n.length);
      for (let w = 0; w < e.length; w++)
        for (let p = 0; p < n.length; p++) {
          if (!i.isValid()) return Fe.trivialTimedOut(e, n);
          const x = w === 0 ? 0 : s.get(w - 1, p),
            T = p === 0 ? 0 : s.get(w, p - 1);
          let y;
          e.getElement(w) === n.getElement(p) ? (w === 0 || p === 0 ? y = 0 : y = s.get(w - 1, p - 1), w > 0 && p > 0 && a.get(w - 1, p - 1) === 3 && (y += l.get(w - 1, p - 1)), y += r ? r(w, p) : 1) : y = -1;
          const L = Math.max(x, T, y);
          if (L === y) {
            const I = w > 0 && p > 0 ? l.get(w - 1, p - 1) : 0;
            l.set(w, p, I + 1), a.set(w, p, 3)
          } else L === x ? (l.set(w, p, 0), a.set(w, p, 1)) : L === T && (l.set(w, p, 0), a.set(w, p, 2));
          s.set(w, p, L)
        }
      const o = [];
      let u = e.length,
        c = n.length;

      function d(w, p) {
        (w + 1 !== u || p + 1 !== c) && o.push(new ne(new G(w + 1, u), new G(p + 1, c))), u = w, c = p
      }
      let m = e.length - 1,
        f = n.length - 1;
      for (; m >= 0 && f >= 0;) a.get(m, f) === 3 ? (d(m, f), m--, f--) : a.get(m, f) === 1 ? m-- : f--;
      return d(-1, -1), o.reverse(), new Fe(o, !1)
    }
  }
  class Cs {
    compute(e, n, i = Ht.instance) {
      if (e.length === 0 || n.length === 0) return Fe.trivial(e, n);
      const r = e,
        s = n;

      function a(p, x) {
        for (; p < r.length && x < s.length && r.getElement(p) === s.getElement(x);) p++, x++;
        return p
      }
      let l = 0;
      const o = new bu;
      o.set(0, a(0, 0));
      const u = new wu;
      u.set(0, o.get(0) === 0 ? null : new Es(null, 0, 0, o.get(0)));
      let c = 0;
      e: for (;;) {
        if (l++, !i.isValid()) return Fe.trivialTimedOut(r, s);
        const p = -Math.min(l, s.length + l % 2),
          x = Math.min(l, r.length + l % 2);
        for (c = p; c <= x; c += 2) {
          const T = c === x ? -1 : o.get(c + 1),
            y = c === p ? -1 : o.get(c - 1) + 1,
            L = Math.min(Math.max(T, y), r.length),
            I = L - c;
          if (L > r.length || I > s.length) continue;
          const H = a(L, I);
          o.set(c, H);
          const P = L === T ? u.get(c + 1) : u.get(c - 1);
          if (u.set(c, H !== L ? new Es(P, L, I, H - L) : P), o.get(c) === r.length && o.get(c) - c === s.length) break e
        }
      }
      let d = u.get(c);
      const m = [];
      let f = r.length,
        w = s.length;
      for (;;) {
        const p = d ? d.x + d.length : 0,
          x = d ? d.y + d.length : 0;
        if ((p !== f || x !== w) && m.push(new ne(new G(p, f), new G(x, w))), !d) break;
        f = d.x, w = d.y, d = d.prev
      }
      return m.reverse(), new Fe(m, !1)
    }
  }
  class Es {
    constructor(e, n, i, r) {
      this.prev = e, this.x = n, this.y = i, this.length = r
    }
  }
  class bu {
    constructor() {
      this.positiveArr = new Int32Array(10), this.negativeArr = new Int32Array(10)
    }
    get(e) {
      return e < 0 ? (e = -e - 1, this.negativeArr[e]) : this.positiveArr[e]
    }
    set(e, n) {
      if (e < 0) {
        if (e = -e - 1, e >= this.negativeArr.length) {
          const i = this.negativeArr;
          this.negativeArr = new Int32Array(i.length * 2), this.negativeArr.set(i)
        }
        this.negativeArr[e] = n
      } else {
        if (e >= this.positiveArr.length) {
          const i = this.positiveArr;
          this.positiveArr = new Int32Array(i.length * 2), this.positiveArr.set(i)
        }
        this.positiveArr[e] = n
      }
    }
  }
  class wu {
    constructor() {
      this.positiveArr = [], this.negativeArr = []
    }
    get(e) {
      return e < 0 ? (e = -e - 1, this.negativeArr[e]) : this.positiveArr[e]
    }
    set(e, n) {
      e < 0 ? (e = -e - 1, this.negativeArr[e] = n) : this.positiveArr[e] = n
    }
  }
  class un {
    constructor(e, n, i) {
      this.lines = e, this.range = n, this.considerWhitespaceChanges = i, this.elements = [], this.firstElementOffsetByLineIdx = [], this.lineStartOffsets = [], this.trimmedWsLengthsByLineIdx = [], this.firstElementOffsetByLineIdx.push(0);
      for (let r = this.range.startLineNumber; r <= this.range.endLineNumber; r++) {
        let s = e[r - 1],
          a = 0;
        r === this.range.startLineNumber && this.range.startColumn > 1 && (a = this.range.startColumn - 1, s = s.substring(a)), this.lineStartOffsets.push(a);
        let l = 0;
        if (!i) {
          const u = s.trimStart();
          l = s.length - u.length, s = u.trimEnd()
        }
        this.trimmedWsLengthsByLineIdx.push(l);
        const o = r === this.range.endLineNumber ? Math.min(this.range.endColumn - 1 - a - l, s.length) : s.length;
        for (let u = 0; u < o; u++) this.elements.push(s.charCodeAt(u));
        r < this.range.endLineNumber && (this.elements.push(10), this.firstElementOffsetByLineIdx.push(this.elements.length))
      }
    }
    toString() {
      return `Slice: "${this.text}"`
    }
    get text() {
      return this.getText(new G(0, this.length))
    }
    getText(e) {
      return this.elements.slice(e.start, e.endExclusive).map(n => String.fromCharCode(n)).join("")
    }
    getElement(e) {
      return this.elements[e]
    }
    get length() {
      return this.elements.length
    }
    getBoundaryScore(e) {
      const n = Ms(e > 0 ? this.elements[e - 1] : -1),
        i = Ms(e < this.elements.length ? this.elements[e] : -1);
      if (n === 7 && i === 8) return 0;
      if (n === 8) return 150;
      let r = 0;
      return n !== i && (r += 10, n === 0 && i === 1 && (r += 1)), r += Ds(n), r += Ds(i), r
    }
    translateOffset(e, n = "right") {
      const i = ft(this.firstElementOffsetByLineIdx, s => s <= e),
        r = e - this.firstElementOffsetByLineIdx[i];
      return new K(this.range.startLineNumber + i, 1 + this.lineStartOffsets[i] + r + (r === 0 && n === "left" ? 0 : this.trimmedWsLengthsByLineIdx[i]))
    }
    translateRange(e) {
      const n = this.translateOffset(e.start, "right"),
        i = this.translateOffset(e.endExclusive, "left");
      return i.isBefore(n) ? j.fromPositions(i, i) : j.fromPositions(n, i)
    }
    findWordContaining(e) {
      if (e < 0 || e >= this.elements.length || !wt(this.elements[e])) return;
      let n = e;
      for (; n > 0 && wt(this.elements[n - 1]);) n--;
      let i = e;
      for (; i < this.elements.length && wt(this.elements[i]);) i++;
      return new G(n, i)
    }
    findSubWordContaining(e) {
      if (e < 0 || e >= this.elements.length || !wt(this.elements[e])) return;
      let n = e;
      for (; n > 0 && wt(this.elements[n - 1]) && !Rs(this.elements[n]);) n--;
      let i = e;
      for (; i < this.elements.length && wt(this.elements[i]) && !Rs(this.elements[i]);) i++;
      return new G(n, i)
    }
    countLinesIn(e) {
      return this.translateOffset(e.endExclusive).lineNumber - this.translateOffset(e.start).lineNumber
    }
    isStronglyEqual(e, n) {
      return this.elements[e] === this.elements[n]
    }
    extendToFullLines(e) {
      const n = mt(this.firstElementOffsetByLineIdx, r => r <= e.start) ?? 0,
        i = ru(this.firstElementOffsetByLineIdx, r => e.endExclusive <= r) ?? this.elements.length;
      return new G(n, i)
    }
  }

  function wt(t) {
    return t >= 97 && t <= 122 || t >= 65 && t <= 90 || t >= 48 && t <= 57
  }

  function Rs(t) {
    return t >= 65 && t <= 90
  }
  const _u = {
    0: 0,
    1: 0,
    2: 0,
    3: 10,
    4: 2,
    5: 30,
    6: 3,
    7: 10,
    8: 10
  };

  function Ds(t) {
    return _u[t]
  }

  function Ms(t) {
    return t === 10 ? 8 : t === 13 ? 7 : ci(t) ? 6 : t >= 97 && t <= 122 ? 0 : t >= 65 && t <= 90 ? 1 : t >= 48 && t <= 57 ? 2 : t === -1 ? 3 : t === 44 || t === 59 ? 5 : 4
  }

  function vu(t, e, n, i, r, s) {
    let {
      moves: a,
      excludedChanges: l
    } = Tu(t, e, n, s);
    if (!s.isValid()) return [];
    const o = t.filter(c => !l.has(c)),
      u = xu(o, i, r, e, n, s);
    return nu(a, u), a = ku(a), a = a.filter(c => {
      const d = c.original.toOffsetRange().slice(e).map(f => f.trim());
      return d.join(`
`).length >= 15 && yu(d, f => f.length >= 2) >= 2
    }), a = Su(t, a), a
  }

  function yu(t, e) {
    let n = 0;
    for (const i of t) e(i) && n++;
    return n
  }

  function Tu(t, e, n, i) {
    const r = [],
      s = t.filter(o => o.modified.isEmpty && o.original.length >= 3).map(o => new ln(o.original, e, o)),
      a = new Set(t.filter(o => o.original.isEmpty && o.modified.length >= 3).map(o => new ln(o.modified, n, o))),
      l = new Set;
    for (const o of s) {
      let u = -1,
        c;
      for (const d of a) {
        const m = o.computeSimilarity(d);
        m > u && (u = m, c = d)
      }
      if (u > .9 && c && (a.delete(c), r.push(new ve(o.range, c.range)), l.add(o.source), l.add(c.source)), !i.isValid()) return {
        moves: r,
        excludedChanges: l
      }
    }
    return {
      moves: r,
      excludedChanges: l
    }
  }

  function xu(t, e, n, i, r, s) {
    const a = [],
      l = new Fl;
    for (const m of t)
      for (let f = m.original.startLineNumber; f < m.original.endLineNumberExclusive - 2; f++) {
        const w = `${e[f-1]}:${e[f+1-1]}:${e[f+2-1]}`;
        l.add(w, {
          range: new X(f, f + 3)
        })
      }
    const o = [];
    t.sort(Mt(m => m.modified.startLineNumber, Nt));
    for (const m of t) {
      let f = [];
      for (let w = m.modified.startLineNumber; w < m.modified.endLineNumberExclusive - 2; w++) {
        const p = `${n[w-1]}:${n[w+1-1]}:${n[w+2-1]}`,
          x = new X(w, w + 3),
          T = [];
        l.forEach(p, ({
          range: y
        }) => {
          for (const I of f)
            if (I.originalLineRange.endLineNumberExclusive + 1 === y.endLineNumberExclusive && I.modifiedLineRange.endLineNumberExclusive + 1 === x.endLineNumberExclusive) {
              I.originalLineRange = new X(I.originalLineRange.startLineNumber, y.endLineNumberExclusive), I.modifiedLineRange = new X(I.modifiedLineRange.startLineNumber, x.endLineNumberExclusive), T.push(I);
              return
            } const L = {
            modifiedLineRange: x,
            originalLineRange: y
          };
          o.push(L), T.push(L)
        }), f = T
      }
      if (!s.isValid()) return []
    }
    o.sort(iu(Mt(m => m.modifiedLineRange.length, Nt)));
    const u = new Me,
      c = new Me;
    for (const m of o) {
      const f = m.modifiedLineRange.startLineNumber - m.originalLineRange.startLineNumber,
        w = u.subtractFrom(m.modifiedLineRange),
        p = c.subtractFrom(m.originalLineRange).getWithDelta(f),
        x = w.getIntersection(p);
      for (const T of x.ranges) {
        if (T.length < 3) continue;
        const y = T,
          L = T.delta(-f);
        a.push(new ve(L, y)), u.addRange(y), c.addRange(L)
      }
    }
    a.sort(Mt(m => m.original.startLineNumber, Nt));
    const d = new an(t);
    for (let m = 0; m < a.length; m++) {
      const f = a[m],
        w = d.findLastMonotonous(P => P.original.startLineNumber <= f.original.startLineNumber),
        p = mt(t, P => P.modified.startLineNumber <= f.modified.startLineNumber),
        x = Math.max(f.original.startLineNumber - w.original.startLineNumber, f.modified.startLineNumber - p.modified.startLineNumber),
        T = d.findLastMonotonous(P => P.original.startLineNumber < f.original.endLineNumberExclusive),
        y = mt(t, P => P.modified.startLineNumber < f.modified.endLineNumberExclusive),
        L = Math.max(T.original.endLineNumberExclusive - f.original.endLineNumberExclusive, y.modified.endLineNumberExclusive - f.modified.endLineNumberExclusive);
      let I;
      for (I = 0; I < x; I++) {
        const P = f.original.startLineNumber - I - 1,
          b = f.modified.startLineNumber - I - 1;
        if (P > i.length || b > r.length || u.contains(b) || c.contains(P) || !Ns(i[P - 1], r[b - 1], s)) break
      }
      I > 0 && (c.addRange(new X(f.original.startLineNumber - I, f.original.startLineNumber)), u.addRange(new X(f.modified.startLineNumber - I, f.modified.startLineNumber)));
      let H;
      for (H = 0; H < L; H++) {
        const P = f.original.endLineNumberExclusive + H,
          b = f.modified.endLineNumberExclusive + H;
        if (P > i.length || b > r.length || u.contains(b) || c.contains(P) || !Ns(i[P - 1], r[b - 1], s)) break
      }
      H > 0 && (c.addRange(new X(f.original.endLineNumberExclusive, f.original.endLineNumberExclusive + H)), u.addRange(new X(f.modified.endLineNumberExclusive, f.modified.endLineNumberExclusive + H))), (I > 0 || H > 0) && (a[m] = new ve(new X(f.original.startLineNumber - I, f.original.endLineNumberExclusive + H), new X(f.modified.startLineNumber - I, f.modified.endLineNumberExclusive + H)))
    }
    return a
  }

  function Ns(t, e, n) {
    if (t.trim() === e.trim()) return !0;
    if (t.length > 300 && e.length > 300) return !1;
    const r = new Cs().compute(new un([t], new j(1, 1, 1, t.length), !1), new un([e], new j(1, 1, 1, e.length), !1), n);
    let s = 0;
    const a = ne.invert(r.diffs, t.length);
    for (const c of a) c.seq1Range.forEach(d => {
      ci(t.charCodeAt(d)) || s++
    });

    function l(c) {
      let d = 0;
      for (let m = 0; m < t.length; m++) ci(c.charCodeAt(m)) || d++;
      return d
    }
    const o = l(t.length > e.length ? t : e);
    return s / o > .6 && o > 10
  }

  function ku(t) {
    if (t.length === 0) return t;
    t.sort(Mt(n => n.original.startLineNumber, Nt));
    const e = [t[0]];
    for (let n = 1; n < t.length; n++) {
      const i = e[e.length - 1],
        r = t[n],
        s = r.original.startLineNumber - i.original.endLineNumberExclusive,
        a = r.modified.startLineNumber - i.modified.endLineNumberExclusive;
      if (s >= 0 && a >= 0 && s + a <= 2) {
        e[e.length - 1] = i.join(r);
        continue
      }
      e.push(r)
    }
    return e
  }

  function Su(t, e) {
    const n = new an(t);
    return e = e.filter(i => {
      const r = n.findLastMonotonous(l => l.original.startLineNumber < i.original.endLineNumberExclusive) || new ve(new X(1, 1), new X(1, 1)),
        s = mt(t, l => l.modified.startLineNumber < i.modified.endLineNumberExclusive);
      return r !== s
    }), e
  }

  function Is(t, e, n) {
    let i = n;
    return i = zs(t, e, i), i = zs(t, e, i), i = Au(t, e, i), i
  }

  function zs(t, e, n) {
    if (n.length === 0) return n;
    const i = [];
    i.push(n[0]);
    for (let s = 1; s < n.length; s++) {
      const a = i[i.length - 1];
      let l = n[s];
      if (l.seq1Range.isEmpty || l.seq2Range.isEmpty) {
        const o = l.seq1Range.start - a.seq1Range.endExclusive;
        let u;
        for (u = 1; u <= o && !(t.getElement(l.seq1Range.start - u) !== t.getElement(l.seq1Range.endExclusive - u) || e.getElement(l.seq2Range.start - u) !== e.getElement(l.seq2Range.endExclusive - u)); u++);
        if (u--, u === o) {
          i[i.length - 1] = new ne(new G(a.seq1Range.start, l.seq1Range.endExclusive - o), new G(a.seq2Range.start, l.seq2Range.endExclusive - o));
          continue
        }
        l = l.delta(-u)
      }
      i.push(l)
    }
    const r = [];
    for (let s = 0; s < i.length - 1; s++) {
      const a = i[s + 1];
      let l = i[s];
      if (l.seq1Range.isEmpty || l.seq2Range.isEmpty) {
        const o = a.seq1Range.start - l.seq1Range.endExclusive;
        let u;
        for (u = 0; u < o && !(!t.isStronglyEqual(l.seq1Range.start + u, l.seq1Range.endExclusive + u) || !e.isStronglyEqual(l.seq2Range.start + u, l.seq2Range.endExclusive + u)); u++);
        if (u === o) {
          i[s + 1] = new ne(new G(l.seq1Range.start + o, a.seq1Range.endExclusive), new G(l.seq2Range.start + o, a.seq2Range.endExclusive));
          continue
        }
        u > 0 && (l = l.delta(u))
      }
      r.push(l)
    }
    return i.length > 0 && r.push(i[i.length - 1]), r
  }

  function Au(t, e, n) {
    if (!t.getBoundaryScore || !e.getBoundaryScore) return n;
    for (let i = 0; i < n.length; i++) {
      const r = i > 0 ? n[i - 1] : void 0,
        s = n[i],
        a = i + 1 < n.length ? n[i + 1] : void 0,
        l = new G(r ? r.seq1Range.endExclusive + 1 : 0, a ? a.seq1Range.start - 1 : t.length),
        o = new G(r ? r.seq2Range.endExclusive + 1 : 0, a ? a.seq2Range.start - 1 : e.length);
      s.seq1Range.isEmpty ? n[i] = Hs(s, t, e, l, o) : s.seq2Range.isEmpty && (n[i] = Hs(s.swap(), e, t, o, l).swap())
    }
    return n
  }

  function Hs(t, e, n, i, r) {
    let a = 1;
    for (; t.seq1Range.start - a >= i.start && t.seq2Range.start - a >= r.start && n.isStronglyEqual(t.seq2Range.start - a, t.seq2Range.endExclusive - a) && a < 100;) a++;
    a--;
    let l = 0;
    for (; t.seq1Range.start + l < i.endExclusive && t.seq2Range.endExclusive + l < r.endExclusive && n.isStronglyEqual(t.seq2Range.start + l, t.seq2Range.endExclusive + l) && l < 100;) l++;
    if (a === 0 && l === 0) return t;
    let o = 0,
      u = -1;
    for (let c = -a; c <= l; c++) {
      const d = t.seq2Range.start + c,
        m = t.seq2Range.endExclusive + c,
        f = t.seq1Range.start + c,
        w = e.getBoundaryScore(f) + n.getBoundaryScore(d) + n.getBoundaryScore(m);
      w > u && (u = w, o = c)
    }
    return t.delta(o)
  }

  function Lu(t, e, n) {
    const i = [];
    for (const r of n) {
      const s = i[i.length - 1];
      if (!s) {
        i.push(r);
        continue
      }
      r.seq1Range.start - s.seq1Range.endExclusive <= 2 || r.seq2Range.start - s.seq2Range.endExclusive <= 2 ? i[i.length - 1] = new ne(s.seq1Range.join(r.seq1Range), s.seq2Range.join(r.seq2Range)) : i.push(r)
    }
    return i
  }

  function Us(t, e, n, i, r = !1) {
    const s = ne.invert(n, t.length),
      a = [];
    let l = new Be(0, 0);

    function o(c, d) {
      if (c.offset1 < l.offset1 || c.offset2 < l.offset2) return;
      const m = i(t, c.offset1),
        f = i(e, c.offset2);
      if (!m || !f) return;
      let w = new ne(m, f);
      const p = w.intersect(d);
      let x = p.seq1Range.length,
        T = p.seq2Range.length;
      for (; s.length > 0;) {
        const y = s[0];
        if (!(y.seq1Range.intersects(w.seq1Range) || y.seq2Range.intersects(w.seq2Range))) break;
        const I = i(t, y.seq1Range.start),
          H = i(e, y.seq2Range.start),
          P = new ne(I, H),
          b = P.intersect(y);
        if (x += b.seq1Range.length, T += b.seq2Range.length, w = w.join(P), w.seq1Range.endExclusive >= y.seq1Range.endExclusive) s.shift();
        else break
      }(r && x + T < w.seq1Range.length + w.seq2Range.length || x + T < (w.seq1Range.length + w.seq2Range.length) * 2 / 3) && a.push(w), l = w.getEndExclusives()
    }
    for (; s.length > 0;) {
      const c = s.shift();
      c.seq1Range.isEmpty || (o(c.getStarts(), c), o(c.getEndExclusives().delta(-1), c))
    }
    return Cu(n, a)
  }

  function Cu(t, e) {
    const n = [];
    for (; t.length > 0 || e.length > 0;) {
      const i = t[0],
        r = e[0];
      let s;
      i && (!r || i.seq1Range.start < r.seq1Range.start) ? s = t.shift() : s = e.shift(), n.length > 0 && n[n.length - 1].seq1Range.endExclusive >= s.seq1Range.start ? n[n.length - 1] = n[n.length - 1].join(s) : n.push(s)
    }
    return n
  }

  function Eu(t, e, n) {
    let i = n;
    if (i.length === 0) return i;
    let r = 0,
      s;
    do {
      s = !1;
      const a = [i[0]];
      for (let l = 1; l < i.length; l++) {
        let c = function(m, f) {
          const w = new G(u.seq1Range.endExclusive, o.seq1Range.start);
          return t.getText(w).replace(/\s/g, "").length <= 4 && (m.seq1Range.length + m.seq2Range.length > 5 || f.seq1Range.length + f.seq2Range.length > 5)
        };
        const o = i[l],
          u = a[a.length - 1];
        c(u, o) ? (s = !0, a[a.length - 1] = a[a.length - 1].join(o)) : a.push(o)
      }
      i = a
    } while (r++ < 10 && s);
    return i
  }

  function Ru(t, e, n) {
    let i = n;
    if (i.length === 0) return i;
    let r = 0,
      s;
    do {
      s = !1;
      const l = [i[0]];
      for (let o = 1; o < i.length; o++) {
        let d = function(f, w) {
          const p = new G(c.seq1Range.endExclusive, u.seq1Range.start);
          if (t.countLinesIn(p) > 5 || p.length > 500) return !1;
          const T = t.getText(p).trim();
          if (T.length > 20 || T.split(/\r\n|\r|\n/).length > 1) return !1;
          const y = t.countLinesIn(f.seq1Range),
            L = f.seq1Range.length,
            I = e.countLinesIn(f.seq2Range),
            H = f.seq2Range.length,
            P = t.countLinesIn(w.seq1Range),
            b = w.seq1Range.length,
            g = e.countLinesIn(w.seq2Range),
            _ = w.seq2Range.length,
            N = 130;

          function S(v) {
            return Math.min(v, N)
          }
          return Math.pow(Math.pow(S(y * 40 + L), 1.5) + Math.pow(S(I * 40 + H), 1.5), 1.5) + Math.pow(Math.pow(S(P * 40 + b), 1.5) + Math.pow(S(g * 40 + _), 1.5), 1.5) > (N ** 1.5) ** 1.5 * 1.3
        };
        const u = i[o],
          c = l[l.length - 1];
        d(c, u) ? (s = !0, l[l.length - 1] = l[l.length - 1].join(u)) : l.push(u)
      }
      i = l
    } while (r++ < 10 && s);
    const a = [];
    return tu(i, (l, o, u) => {
      let c = o;

      function d(T) {
        return T.length > 0 && T.trim().length <= 3 && o.seq1Range.length + o.seq2Range.length > 100
      }
      const m = t.extendToFullLines(o.seq1Range),
        f = t.getText(new G(m.start, o.seq1Range.start));
      d(f) && (c = c.deltaStart(-f.length));
      const w = t.getText(new G(o.seq1Range.endExclusive, m.endExclusive));
      d(w) && (c = c.deltaEnd(w.length));
      const p = ne.fromOffsetPairs(l ? l.getEndExclusives() : Be.zero, u ? u.getStarts() : Be.max),
        x = c.intersect(p);
      a.length > 0 && x.getStarts().equals(a[a.length - 1].getEndExclusives()) ? a[a.length - 1] = a[a.length - 1].join(x) : a.push(x)
    }), a
  }
  class Ps {
    constructor(e, n) {
      this.trimmedHash = e, this.lines = n
    }
    getElement(e) {
      return this.trimmedHash[e]
    }
    get length() {
      return this.trimmedHash.length
    }
    getBoundaryScore(e) {
      const n = e === 0 ? 0 : Ws(this.lines[e - 1]),
        i = e === this.lines.length ? 0 : Ws(this.lines[e]);
      return 1e3 - (n + i)
    }
    getText(e) {
      return this.lines.slice(e.start, e.endExclusive).join(`
`)
    }
    isStronglyEqual(e, n) {
      return this.lines[e] === this.lines[n]
    }
  }

  function Ws(t) {
    let e = 0;
    for (; e < t.length && (t.charCodeAt(e) === 32 || t.charCodeAt(e) === 9);) e++;
    return e
  }
  class Du {
    constructor() {
      this.dynamicProgrammingDiffing = new gu, this.myersDiffingAlgorithm = new Cs
    }
    computeDiff(e, n, i) {
      if (e.length <= 1 && Zl(e, n, (b, g) => b === g)) return new sn([], [], !1);
      if (e.length === 1 && e[0].length === 0 || n.length === 1 && n[0].length === 0) return new sn([new We(new X(1, e.length + 1), new X(1, n.length + 1), [new ye(new j(1, 1, e.length, e[e.length - 1].length + 1), new j(1, 1, n.length, n[n.length - 1].length + 1))])], [], !1);
      const r = i.maxComputationTimeMs === 0 ? Ht.instance : new pu(i.maxComputationTimeMs),
        s = !i.ignoreTrimWhitespace,
        a = new Map;

      function l(b) {
        let g = a.get(b);
        return g === void 0 && (g = a.size, a.set(b, g)), g
      }
      const o = e.map(b => l(b.trim())),
        u = n.map(b => l(b.trim())),
        c = new Ps(o, e),
        d = new Ps(u, n),
        m = c.length + d.length < 1700 ? this.dynamicProgrammingDiffing.compute(c, d, r, (b, g) => e[b] === n[g] ? n[g].length === 0 ? .1 : 1 + Math.log(1 + n[g].length) : .99) : this.myersDiffingAlgorithm.compute(c, d, r);
      let f = m.diffs,
        w = m.hitTimeout;
      f = Is(c, d, f), f = Eu(c, d, f);
      const p = [],
        x = b => {
          if (s)
            for (let g = 0; g < b; g++) {
              const _ = T + g,
                N = y + g;
              if (e[_] !== n[N]) {
                const S = this.refineDiff(e, n, new ne(new G(_, _ + 1), new G(N, N + 1)), r, s, i);
                for (const v of S.mappings) p.push(v);
                S.hitTimeout && (w = !0)
              }
            }
        };
      let T = 0,
        y = 0;
      for (const b of f) {
        $t(() => b.seq1Range.start - T === b.seq2Range.start - y);
        const g = b.seq1Range.start - T;
        x(g), T = b.seq1Range.endExclusive, y = b.seq2Range.endExclusive;
        const _ = this.refineDiff(e, n, b, r, s, i);
        _.hitTimeout && (w = !0);
        for (const N of _.mappings) p.push(N)
      }
      x(e.length - T);
      const L = new on(e),
        I = new on(n),
        H = ks(p, L, I);
      let P = [];
      return i.computeMoves && (P = this.computeMoves(H, e, n, o, u, r, s, i)), $t(() => {
        function b(_, N) {
          if (_.lineNumber < 1 || _.lineNumber > N.length) return !1;
          const S = N[_.lineNumber - 1];
          return !(_.column < 1 || _.column > S.length + 1)
        }

        function g(_, N) {
          return !(_.startLineNumber < 1 || _.startLineNumber > N.length + 1 || _.endLineNumberExclusive < 1 || _.endLineNumberExclusive > N.length + 1)
        }
        for (const _ of H) {
          if (!_.innerChanges) return !1;
          for (const N of _.innerChanges)
            if (!(b(N.modifiedRange.getStartPosition(), n) && b(N.modifiedRange.getEndPosition(), n) && b(N.originalRange.getStartPosition(), e) && b(N.originalRange.getEndPosition(), e))) return !1;
          if (!g(_.modified, n) || !g(_.original, e)) return !1
        }
        return !0
      }), new sn(H, P, w)
    }
    computeMoves(e, n, i, r, s, a, l, o) {
      return vu(e, n, i, r, s, a).map(d => {
        const m = this.refineDiff(n, i, new ne(d.original.toOffsetRange(), d.modified.toOffsetRange()), a, l, o),
          f = ks(m.mappings, new on(n), new on(i), !0);
        return new Yl(d, f)
      })
    }
    refineDiff(e, n, i, r, s, a) {
      const o = Mu(i).toRangeMapping2(e, n),
        u = new un(e, o.originalRange, s),
        c = new un(n, o.modifiedRange, s),
        d = u.length + c.length < 500 ? this.dynamicProgrammingDiffing.compute(u, c, r) : this.myersDiffingAlgorithm.compute(u, c, r);
      let m = d.diffs;
      return m = Is(u, c, m), m = Us(u, c, m, (w, p) => w.findWordContaining(p)), a.extendToSubwords && (m = Us(u, c, m, (w, p) => w.findSubWordContaining(p), !0)), m = Lu(u, c, m), m = Ru(u, c, m), {
        mappings: m.map(w => new ye(u.translateRange(w.seq1Range), c.translateRange(w.seq2Range))),
        hitTimeout: d.hitTimeout
      }
    }
  }

  function Mu(t) {
    return new ve(new X(t.seq1Range.start + 1, t.seq1Range.endExclusive + 1), new X(t.seq2Range.start + 1, t.seq2Range.endExclusive + 1))
  }
  const Fs = {
    getLegacy: () => new hu,
    getDefault: () => new Du
  };

  function Xe(t, e) {
    const n = Math.pow(10, e);
    return Math.round(t * n) / n
  }
  class C {
    constructor(e, n, i, r = 1) {
      this._rgbaBrand = void 0, this.r = Math.min(255, Math.max(0, e)) | 0, this.g = Math.min(255, Math.max(0, n)) | 0, this.b = Math.min(255, Math.max(0, i)) | 0, this.a = Xe(Math.max(Math.min(1, r), 0), 3)
    }
    static equals(e, n) {
      return e.r === n.r && e.g === n.g && e.b === n.b && e.a === n.a
    }
  }
  class Te {
    constructor(e, n, i, r) {
      this._hslaBrand = void 0, this.h = Math.max(Math.min(360, e), 0) | 0, this.s = Xe(Math.max(Math.min(1, n), 0), 3), this.l = Xe(Math.max(Math.min(1, i), 0), 3), this.a = Xe(Math.max(Math.min(1, r), 0), 3)
    }
    static equals(e, n) {
      return e.h === n.h && e.s === n.s && e.l === n.l && e.a === n.a
    }
    static fromRGBA(e) {
      const n = e.r / 255,
        i = e.g / 255,
        r = e.b / 255,
        s = e.a,
        a = Math.max(n, i, r),
        l = Math.min(n, i, r);
      let o = 0,
        u = 0;
      const c = (l + a) / 2,
        d = a - l;
      if (d > 0) {
        switch (u = Math.min(c <= .5 ? d / (2 * c) : d / (2 - 2 * c), 1), a) {
          case n:
            o = (i - r) / d + (i < r ? 6 : 0);
            break;
          case i:
            o = (r - n) / d + 2;
            break;
          case r:
            o = (n - i) / d + 4;
            break
        }
        o *= 60, o = Math.round(o)
      }
      return new Te(o, u, c, s)
    }
    static _hue2rgb(e, n, i) {
      return i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6 ? e + (n - e) * 6 * i : i < 1 / 2 ? n : i < 2 / 3 ? e + (n - e) * (2 / 3 - i) * 6 : e
    }
    static toRGBA(e) {
      const n = e.h / 360,
        {
          s: i,
          l: r,
          a: s
        } = e;
      let a, l, o;
      if (i === 0) a = l = o = r;
      else {
        const u = r < .5 ? r * (1 + i) : r + i - r * i,
          c = 2 * r - u;
        a = Te._hue2rgb(c, u, n + 1 / 3), l = Te._hue2rgb(c, u, n), o = Te._hue2rgb(c, u, n - 1 / 3)
      }
      return new C(Math.round(a * 255), Math.round(l * 255), Math.round(o * 255), s)
    }
  }
  class _t {
    constructor(e, n, i, r) {
      this._hsvaBrand = void 0, this.h = Math.max(Math.min(360, e), 0) | 0, this.s = Xe(Math.max(Math.min(1, n), 0), 3), this.v = Xe(Math.max(Math.min(1, i), 0), 3), this.a = Xe(Math.max(Math.min(1, r), 0), 3)
    }
    static equals(e, n) {
      return e.h === n.h && e.s === n.s && e.v === n.v && e.a === n.a
    }
    static fromRGBA(e) {
      const n = e.r / 255,
        i = e.g / 255,
        r = e.b / 255,
        s = Math.max(n, i, r),
        a = Math.min(n, i, r),
        l = s - a,
        o = s === 0 ? 0 : l / s;
      let u;
      return l === 0 ? u = 0 : s === n ? u = ((i - r) / l % 6 + 6) % 6 : s === i ? u = (r - n) / l + 2 : u = (n - i) / l + 4, new _t(Math.round(u * 60), o, s, e.a)
    }
    static toRGBA(e) {
      const {
        h: n,
        s: i,
        v: r,
        a: s
      } = e, a = r * i, l = a * (1 - Math.abs(n / 60 % 2 - 1)), o = r - a;
      let [u, c, d] = [0, 0, 0];
      return n < 60 ? (u = a, c = l) : n < 120 ? (u = l, c = a) : n < 180 ? (c = a, d = l) : n < 240 ? (c = l, d = a) : n < 300 ? (u = l, d = a) : n <= 360 && (u = a, d = l), u = Math.round((u + o) * 255), c = Math.round((c + o) * 255), d = Math.round((d + o) * 255), new C(u, c, d, s)
    }
  }
  let cn = (Q = class {
    static fromHex(e) {
      return Q.Format.CSS.parseHex(e) || Q.red
    }
    static equals(e, n) {
      return !e && !n ? !0 : !e || !n ? !1 : e.equals(n)
    }
    get hsla() {
      return this._hsla ? this._hsla : Te.fromRGBA(this.rgba)
    }
    get hsva() {
      return this._hsva ? this._hsva : _t.fromRGBA(this.rgba)
    }
    constructor(e) {
      if (e)
        if (e instanceof C) this.rgba = e;
        else if (e instanceof Te) this._hsla = e, this.rgba = Te.toRGBA(e);
      else if (e instanceof _t) this._hsva = e, this.rgba = _t.toRGBA(e);
      else throw new Error("Invalid color ctor argument");
      else throw new Error("Color needs a value")
    }
    equals(e) {
      return !!e && C.equals(this.rgba, e.rgba) && Te.equals(this.hsla, e.hsla) && _t.equals(this.hsva, e.hsva)
    }
    getRelativeLuminance() {
      const e = Q._relativeLuminanceForComponent(this.rgba.r),
        n = Q._relativeLuminanceForComponent(this.rgba.g),
        i = Q._relativeLuminanceForComponent(this.rgba.b),
        r = .2126 * e + .7152 * n + .0722 * i;
      return Xe(r, 4)
    }
    static _relativeLuminanceForComponent(e) {
      const n = e / 255;
      return n <= .03928 ? n / 12.92 : Math.pow((n + .055) / 1.055, 2.4)
    }
    isLighter() {
      return (this.rgba.r * 299 + this.rgba.g * 587 + this.rgba.b * 114) / 1e3 >= 128
    }
    isLighterThan(e) {
      const n = this.getRelativeLuminance(),
        i = e.getRelativeLuminance();
      return n > i
    }
    isDarkerThan(e) {
      const n = this.getRelativeLuminance(),
        i = e.getRelativeLuminance();
      return n < i
    }
    lighten(e) {
      return new Q(new Te(this.hsla.h, this.hsla.s, this.hsla.l + this.hsla.l * e, this.hsla.a))
    }
    darken(e) {
      return new Q(new Te(this.hsla.h, this.hsla.s, this.hsla.l - this.hsla.l * e, this.hsla.a))
    }
    transparent(e) {
      const {
        r: n,
        g: i,
        b: r,
        a: s
      } = this.rgba;
      return new Q(new C(n, i, r, s * e))
    }
    isTransparent() {
      return this.rgba.a === 0
    }
    isOpaque() {
      return this.rgba.a === 1
    }
    opposite() {
      return new Q(new C(255 - this.rgba.r, 255 - this.rgba.g, 255 - this.rgba.b, this.rgba.a))
    }
    mix(e, n = .5) {
      const i = Math.min(Math.max(n, 0), 1),
        r = this.rgba,
        s = e.rgba,
        a = r.r + (s.r - r.r) * i,
        l = r.g + (s.g - r.g) * i,
        o = r.b + (s.b - r.b) * i,
        u = r.a + (s.a - r.a) * i;
      return new Q(new C(a, l, o, u))
    }
    makeOpaque(e) {
      if (this.isOpaque() || e.rgba.a !== 1) return this;
      const {
        r: n,
        g: i,
        b: r,
        a: s
      } = this.rgba;
      return new Q(new C(e.rgba.r - s * (e.rgba.r - n), e.rgba.g - s * (e.rgba.g - i), e.rgba.b - s * (e.rgba.b - r), 1))
    }
    toString() {
      return this._toString || (this._toString = Q.Format.CSS.format(this)), this._toString
    }
    toNumber32Bit() {
      return this._toNumber32Bit || (this._toNumber32Bit = (this.rgba.r << 24 | this.rgba.g << 16 | this.rgba.b << 8 | this.rgba.a * 255 << 0) >>> 0), this._toNumber32Bit
    }
    static getLighterColor(e, n, i) {
      if (e.isLighterThan(n)) return e;
      i = i || .5;
      const r = e.getRelativeLuminance(),
        s = n.getRelativeLuminance();
      return i = i * (s - r) / s, e.lighten(i)
    }
    static getDarkerColor(e, n, i) {
      if (e.isDarkerThan(n)) return e;
      i = i || .5;
      const r = e.getRelativeLuminance(),
        s = n.getRelativeLuminance();
      return i = i * (r - s) / r, e.darken(i)
    }
  }, Q.white = new Q(new C(255, 255, 255, 1)), Q.black = new Q(new C(0, 0, 0, 1)), Q.red = new Q(new C(255, 0, 0, 1)), Q.blue = new Q(new C(0, 0, 255, 1)), Q.green = new Q(new C(0, 255, 0, 1)), Q.cyan = new Q(new C(0, 255, 255, 1)), Q.lightgrey = new Q(new C(211, 211, 211, 1)), Q.transparent = new Q(new C(0, 0, 0, 0)), Q);
  (function(t) {
    (function(e) {
      (function(n) {
        function i(p) {
          return p.rgba.a === 1 ? `rgb(${p.rgba.r}, ${p.rgba.g}, ${p.rgba.b})` : t.Format.CSS.formatRGBA(p)
        }
        n.formatRGB = i;

        function r(p) {
          return `rgba(${p.rgba.r}, ${p.rgba.g}, ${p.rgba.b}, ${+p.rgba.a.toFixed(2)})`
        }
        n.formatRGBA = r;

        function s(p) {
          return p.hsla.a === 1 ? `hsl(${p.hsla.h}, ${Math.round(p.hsla.s*100)}%, ${Math.round(p.hsla.l*100)}%)` : t.Format.CSS.formatHSLA(p)
        }
        n.formatHSL = s;

        function a(p) {
          return `hsla(${p.hsla.h}, ${Math.round(p.hsla.s*100)}%, ${Math.round(p.hsla.l*100)}%, ${p.hsla.a.toFixed(2)})`
        }
        n.formatHSLA = a;

        function l(p) {
          const x = p.toString(16);
          return x.length !== 2 ? "0" + x : x
        }

        function o(p) {
          return `#${l(p.rgba.r)}${l(p.rgba.g)}${l(p.rgba.b)}`
        }
        n.formatHex = o;

        function u(p, x = !1) {
          return x && p.rgba.a === 1 ? t.Format.CSS.formatHex(p) : `#${l(p.rgba.r)}${l(p.rgba.g)}${l(p.rgba.b)}${l(Math.round(p.rgba.a*255))}`
        }
        n.formatHexA = u;

        function c(p) {
          return p.isOpaque() ? t.Format.CSS.formatHex(p) : t.Format.CSS.formatRGBA(p)
        }
        n.format = c;

        function d(p) {
          var x, T, y, L, I, H, P;
          if (p === "transparent") return t.transparent;
          if (p.startsWith("#")) return f(p);
          if (p.startsWith("rgba(")) {
            const b = p.match(/rgba\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+), *(?<a>(?:\+|-)?\d+(\.\d+)?)\)/);
            if (!b) throw new Error("Invalid color format " + p);
            const g = parseInt(((x = b.groups) == null ? void 0 : x.r) ?? "0"),
              _ = parseInt(((T = b.groups) == null ? void 0 : T.g) ?? "0"),
              N = parseInt(((y = b.groups) == null ? void 0 : y.b) ?? "0"),
              S = parseFloat(((L = b.groups) == null ? void 0 : L.a) ?? "0");
            return new t(new C(g, _, N, S))
          }
          if (p.startsWith("rgb(")) {
            const b = p.match(/rgb\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+)\)/);
            if (!b) throw new Error("Invalid color format " + p);
            const g = parseInt(((I = b.groups) == null ? void 0 : I.r) ?? "0"),
              _ = parseInt(((H = b.groups) == null ? void 0 : H.g) ?? "0"),
              N = parseInt(((P = b.groups) == null ? void 0 : P.b) ?? "0");
            return new t(new C(g, _, N))
          }
          return m(p)
        }
        n.parse = d;

        function m(p) {
          switch (p) {
            case "aliceblue":
              return new t(new C(240, 248, 255, 1));
            case "antiquewhite":
              return new t(new C(250, 235, 215, 1));
            case "aqua":
              return new t(new C(0, 255, 255, 1));
            case "aquamarine":
              return new t(new C(127, 255, 212, 1));
            case "azure":
              return new t(new C(240, 255, 255, 1));
            case "beige":
              return new t(new C(245, 245, 220, 1));
            case "bisque":
              return new t(new C(255, 228, 196, 1));
            case "black":
              return new t(new C(0, 0, 0, 1));
            case "blanchedalmond":
              return new t(new C(255, 235, 205, 1));
            case "blue":
              return new t(new C(0, 0, 255, 1));
            case "blueviolet":
              return new t(new C(138, 43, 226, 1));
            case "brown":
              return new t(new C(165, 42, 42, 1));
            case "burlywood":
              return new t(new C(222, 184, 135, 1));
            case "cadetblue":
              return new t(new C(95, 158, 160, 1));
            case "chartreuse":
              return new t(new C(127, 255, 0, 1));
            case "chocolate":
              return new t(new C(210, 105, 30, 1));
            case "coral":
              return new t(new C(255, 127, 80, 1));
            case "cornflowerblue":
              return new t(new C(100, 149, 237, 1));
            case "cornsilk":
              return new t(new C(255, 248, 220, 1));
            case "crimson":
              return new t(new C(220, 20, 60, 1));
            case "cyan":
              return new t(new C(0, 255, 255, 1));
            case "darkblue":
              return new t(new C(0, 0, 139, 1));
            case "darkcyan":
              return new t(new C(0, 139, 139, 1));
            case "darkgoldenrod":
              return new t(new C(184, 134, 11, 1));
            case "darkgray":
              return new t(new C(169, 169, 169, 1));
            case "darkgreen":
              return new t(new C(0, 100, 0, 1));
            case "darkgrey":
              return new t(new C(169, 169, 169, 1));
            case "darkkhaki":
              return new t(new C(189, 183, 107, 1));
            case "darkmagenta":
              return new t(new C(139, 0, 139, 1));
            case "darkolivegreen":
              return new t(new C(85, 107, 47, 1));
            case "darkorange":
              return new t(new C(255, 140, 0, 1));
            case "darkorchid":
              return new t(new C(153, 50, 204, 1));
            case "darkred":
              return new t(new C(139, 0, 0, 1));
            case "darksalmon":
              return new t(new C(233, 150, 122, 1));
            case "darkseagreen":
              return new t(new C(143, 188, 143, 1));
            case "darkslateblue":
              return new t(new C(72, 61, 139, 1));
            case "darkslategray":
              return new t(new C(47, 79, 79, 1));
            case "darkslategrey":
              return new t(new C(47, 79, 79, 1));
            case "darkturquoise":
              return new t(new C(0, 206, 209, 1));
            case "darkviolet":
              return new t(new C(148, 0, 211, 1));
            case "deeppink":
              return new t(new C(255, 20, 147, 1));
            case "deepskyblue":
              return new t(new C(0, 191, 255, 1));
            case "dimgray":
              return new t(new C(105, 105, 105, 1));
            case "dimgrey":
              return new t(new C(105, 105, 105, 1));
            case "dodgerblue":
              return new t(new C(30, 144, 255, 1));
            case "firebrick":
              return new t(new C(178, 34, 34, 1));
            case "floralwhite":
              return new t(new C(255, 250, 240, 1));
            case "forestgreen":
              return new t(new C(34, 139, 34, 1));
            case "fuchsia":
              return new t(new C(255, 0, 255, 1));
            case "gainsboro":
              return new t(new C(220, 220, 220, 1));
            case "ghostwhite":
              return new t(new C(248, 248, 255, 1));
            case "gold":
              return new t(new C(255, 215, 0, 1));
            case "goldenrod":
              return new t(new C(218, 165, 32, 1));
            case "gray":
              return new t(new C(128, 128, 128, 1));
            case "green":
              return new t(new C(0, 128, 0, 1));
            case "greenyellow":
              return new t(new C(173, 255, 47, 1));
            case "grey":
              return new t(new C(128, 128, 128, 1));
            case "honeydew":
              return new t(new C(240, 255, 240, 1));
            case "hotpink":
              return new t(new C(255, 105, 180, 1));
            case "indianred":
              return new t(new C(205, 92, 92, 1));
            case "indigo":
              return new t(new C(75, 0, 130, 1));
            case "ivory":
              return new t(new C(255, 255, 240, 1));
            case "khaki":
              return new t(new C(240, 230, 140, 1));
            case "lavender":
              return new t(new C(230, 230, 250, 1));
            case "lavenderblush":
              return new t(new C(255, 240, 245, 1));
            case "lawngreen":
              return new t(new C(124, 252, 0, 1));
            case "lemonchiffon":
              return new t(new C(255, 250, 205, 1));
            case "lightblue":
              return new t(new C(173, 216, 230, 1));
            case "lightcoral":
              return new t(new C(240, 128, 128, 1));
            case "lightcyan":
              return new t(new C(224, 255, 255, 1));
            case "lightgoldenrodyellow":
              return new t(new C(250, 250, 210, 1));
            case "lightgray":
              return new t(new C(211, 211, 211, 1));
            case "lightgreen":
              return new t(new C(144, 238, 144, 1));
            case "lightgrey":
              return new t(new C(211, 211, 211, 1));
            case "lightpink":
              return new t(new C(255, 182, 193, 1));
            case "lightsalmon":
              return new t(new C(255, 160, 122, 1));
            case "lightseagreen":
              return new t(new C(32, 178, 170, 1));
            case "lightskyblue":
              return new t(new C(135, 206, 250, 1));
            case "lightslategray":
              return new t(new C(119, 136, 153, 1));
            case "lightslategrey":
              return new t(new C(119, 136, 153, 1));
            case "lightsteelblue":
              return new t(new C(176, 196, 222, 1));
            case "lightyellow":
              return new t(new C(255, 255, 224, 1));
            case "lime":
              return new t(new C(0, 255, 0, 1));
            case "limegreen":
              return new t(new C(50, 205, 50, 1));
            case "linen":
              return new t(new C(250, 240, 230, 1));
            case "magenta":
              return new t(new C(255, 0, 255, 1));
            case "maroon":
              return new t(new C(128, 0, 0, 1));
            case "mediumaquamarine":
              return new t(new C(102, 205, 170, 1));
            case "mediumblue":
              return new t(new C(0, 0, 205, 1));
            case "mediumorchid":
              return new t(new C(186, 85, 211, 1));
            case "mediumpurple":
              return new t(new C(147, 112, 219, 1));
            case "mediumseagreen":
              return new t(new C(60, 179, 113, 1));
            case "mediumslateblue":
              return new t(new C(123, 104, 238, 1));
            case "mediumspringgreen":
              return new t(new C(0, 250, 154, 1));
            case "mediumturquoise":
              return new t(new C(72, 209, 204, 1));
            case "mediumvioletred":
              return new t(new C(199, 21, 133, 1));
            case "midnightblue":
              return new t(new C(25, 25, 112, 1));
            case "mintcream":
              return new t(new C(245, 255, 250, 1));
            case "mistyrose":
              return new t(new C(255, 228, 225, 1));
            case "moccasin":
              return new t(new C(255, 228, 181, 1));
            case "navajowhite":
              return new t(new C(255, 222, 173, 1));
            case "navy":
              return new t(new C(0, 0, 128, 1));
            case "oldlace":
              return new t(new C(253, 245, 230, 1));
            case "olive":
              return new t(new C(128, 128, 0, 1));
            case "olivedrab":
              return new t(new C(107, 142, 35, 1));
            case "orange":
              return new t(new C(255, 165, 0, 1));
            case "orangered":
              return new t(new C(255, 69, 0, 1));
            case "orchid":
              return new t(new C(218, 112, 214, 1));
            case "palegoldenrod":
              return new t(new C(238, 232, 170, 1));
            case "palegreen":
              return new t(new C(152, 251, 152, 1));
            case "paleturquoise":
              return new t(new C(175, 238, 238, 1));
            case "palevioletred":
              return new t(new C(219, 112, 147, 1));
            case "papayawhip":
              return new t(new C(255, 239, 213, 1));
            case "peachpuff":
              return new t(new C(255, 218, 185, 1));
            case "peru":
              return new t(new C(205, 133, 63, 1));
            case "pink":
              return new t(new C(255, 192, 203, 1));
            case "plum":
              return new t(new C(221, 160, 221, 1));
            case "powderblue":
              return new t(new C(176, 224, 230, 1));
            case "purple":
              return new t(new C(128, 0, 128, 1));
            case "rebeccapurple":
              return new t(new C(102, 51, 153, 1));
            case "red":
              return new t(new C(255, 0, 0, 1));
            case "rosybrown":
              return new t(new C(188, 143, 143, 1));
            case "royalblue":
              return new t(new C(65, 105, 225, 1));
            case "saddlebrown":
              return new t(new C(139, 69, 19, 1));
            case "salmon":
              return new t(new C(250, 128, 114, 1));
            case "sandybrown":
              return new t(new C(244, 164, 96, 1));
            case "seagreen":
              return new t(new C(46, 139, 87, 1));
            case "seashell":
              return new t(new C(255, 245, 238, 1));
            case "sienna":
              return new t(new C(160, 82, 45, 1));
            case "silver":
              return new t(new C(192, 192, 192, 1));
            case "skyblue":
              return new t(new C(135, 206, 235, 1));
            case "slateblue":
              return new t(new C(106, 90, 205, 1));
            case "slategray":
              return new t(new C(112, 128, 144, 1));
            case "slategrey":
              return new t(new C(112, 128, 144, 1));
            case "snow":
              return new t(new C(255, 250, 250, 1));
            case "springgreen":
              return new t(new C(0, 255, 127, 1));
            case "steelblue":
              return new t(new C(70, 130, 180, 1));
            case "tan":
              return new t(new C(210, 180, 140, 1));
            case "teal":
              return new t(new C(0, 128, 128, 1));
            case "thistle":
              return new t(new C(216, 191, 216, 1));
            case "tomato":
              return new t(new C(255, 99, 71, 1));
            case "turquoise":
              return new t(new C(64, 224, 208, 1));
            case "violet":
              return new t(new C(238, 130, 238, 1));
            case "wheat":
              return new t(new C(245, 222, 179, 1));
            case "white":
              return new t(new C(255, 255, 255, 1));
            case "whitesmoke":
              return new t(new C(245, 245, 245, 1));
            case "yellow":
              return new t(new C(255, 255, 0, 1));
            case "yellowgreen":
              return new t(new C(154, 205, 50, 1));
            default:
              return null
          }
        }

        function f(p) {
          const x = p.length;
          if (x === 0 || p.charCodeAt(0) !== 35) return null;
          if (x === 7) {
            const T = 16 * w(p.charCodeAt(1)) + w(p.charCodeAt(2)),
              y = 16 * w(p.charCodeAt(3)) + w(p.charCodeAt(4)),
              L = 16 * w(p.charCodeAt(5)) + w(p.charCodeAt(6));
            return new t(new C(T, y, L, 1))
          }
          if (x === 9) {
            const T = 16 * w(p.charCodeAt(1)) + w(p.charCodeAt(2)),
              y = 16 * w(p.charCodeAt(3)) + w(p.charCodeAt(4)),
              L = 16 * w(p.charCodeAt(5)) + w(p.charCodeAt(6)),
              I = 16 * w(p.charCodeAt(7)) + w(p.charCodeAt(8));
            return new t(new C(T, y, L, I / 255))
          }
          if (x === 4) {
            const T = w(p.charCodeAt(1)),
              y = w(p.charCodeAt(2)),
              L = w(p.charCodeAt(3));
            return new t(new C(16 * T + T, 16 * y + y, 16 * L + L))
          }
          if (x === 5) {
            const T = w(p.charCodeAt(1)),
              y = w(p.charCodeAt(2)),
              L = w(p.charCodeAt(3)),
              I = w(p.charCodeAt(4));
            return new t(new C(16 * T + T, 16 * y + y, 16 * L + L, (16 * I + I) / 255))
          }
          return null
        }
        n.parseHex = f;

        function w(p) {
          switch (p) {
            case 48:
              return 0;
            case 49:
              return 1;
            case 50:
              return 2;
            case 51:
              return 3;
            case 52:
              return 4;
            case 53:
              return 5;
            case 54:
              return 6;
            case 55:
              return 7;
            case 56:
              return 8;
            case 57:
              return 9;
            case 97:
              return 10;
            case 65:
              return 10;
            case 98:
              return 11;
            case 66:
              return 11;
            case 99:
              return 12;
            case 67:
              return 12;
            case 100:
              return 13;
            case 68:
              return 13;
            case 101:
              return 14;
            case 69:
              return 14;
            case 102:
              return 15;
            case 70:
              return 15
          }
          return 0
        }
      })(e.CSS || (e.CSS = {}))
    })(t.Format || (t.Format = {}))
  })(cn || (cn = {}));

  function Bs(t) {
    const e = [];
    for (const n of t) {
      const i = Number(n);
      (i || i === 0 && n.replace(/\s/g, "") !== "") && e.push(i)
    }
    return e
  }

  function hi(t, e, n, i) {
    return {
      red: t / 255,
      blue: n / 255,
      green: e / 255,
      alpha: i
    }
  }

  function Ut(t, e) {
    const n = e.index,
      i = e[0].length;
    if (n === void 0) return;
    const r = t.positionAt(n);
    return {
      startLineNumber: r.lineNumber,
      startColumn: r.column,
      endLineNumber: r.lineNumber,
      endColumn: r.column + i
    }
  }

  function Nu(t, e) {
    if (!t) return;
    const n = cn.Format.CSS.parseHex(e);
    if (n) return {
      range: t,
      color: hi(n.rgba.r, n.rgba.g, n.rgba.b, n.rgba.a)
    }
  }

  function qs(t, e, n) {
    if (!t || e.length !== 1) return;
    const r = e[0].values(),
      s = Bs(r);
    return {
      range: t,
      color: hi(s[0], s[1], s[2], n ? s[3] : 1)
    }
  }

  function Os(t, e, n) {
    if (!t || e.length !== 1) return;
    const r = e[0].values(),
      s = Bs(r),
      a = new cn(new Te(s[0], s[1] / 100, s[2] / 100, n ? s[3] : 1));
    return {
      range: t,
      color: hi(a.rgba.r, a.rgba.g, a.rgba.b, a.rgba.a)
    }
  }

  function Pt(t, e) {
    return typeof t == "string" ? [...t.matchAll(e)] : t.findMatches(e)
  }

  function Iu(t) {
    const e = [],
      n = new RegExp(`\\b(rgb|rgba|hsl|hsla)(\\([0-9\\s,.\\%]*\\))|^(#)([A-Fa-f0-9]{3})\\b|^(#)([A-Fa-f0-9]{4})\\b|^(#)([A-Fa-f0-9]{6})\\b|^(#)([A-Fa-f0-9]{8})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{3})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{4})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{6})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{8})\\b`, "gm"),
      i = Pt(t, n);
    if (i.length > 0)
      for (const r of i) {
        const s = r.filter(u => u !== void 0),
          a = s[1],
          l = s[2];
        if (!l) continue;
        let o;
        if (a === "rgb") {
          const u = /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*\)$/gm;
          o = qs(Ut(t, r), Pt(l, u), !1)
        } else if (a === "rgba") {
          const u = /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(0[.][0-9]+|[.][0-9]+|[01][.]|[01])\s*\)$/gm;
          o = qs(Ut(t, r), Pt(l, u), !0)
        } else if (a === "hsl") {
          const u = /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*\)$/gm;
          o = Os(Ut(t, r), Pt(l, u), !1)
        } else if (a === "hsla") {
          const u = /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(0[.][0-9]+|[.][0-9]+|[01][.]0*|[01])\s*\)$/gm;
          o = Os(Ut(t, r), Pt(l, u), !0)
        } else a === "#" && (o = Nu(Ut(t, r), a + l));
        o && e.push(o)
      }
    return e
  }

  function zu(t) {
    return !t || typeof t.getValue != "function" || typeof t.positionAt != "function" ? [] : Iu(t)
  }
  const Hu = /^-+|-+$/g,
    Vs = 100,
    Uu = 5;

  function Pu(t, e) {
    var i;
    let n = [];
    if (e.findRegionSectionHeaders && ((i = e.foldingRules) != null && i.markers)) {
      const r = Wu(t, e);
      n = n.concat(r)
    }
    if (e.findMarkSectionHeaders) {
      const r = Fu(t, e);
      n = n.concat(r)
    }
    return n
  }

  function Wu(t, e) {
    const n = [],
      i = t.getLineCount();
    for (let r = 1; r <= i; r++) {
      const s = t.getLineContent(r),
        a = s.match(e.foldingRules.markers.start);
      if (a) {
        const l = {
          startLineNumber: r,
          startColumn: a[0].length + 1,
          endLineNumber: r,
          endColumn: s.length + 1
        };
        if (l.endColumn > l.startColumn) {
          const o = {
            range: l,
            ...Bu(s.substring(a[0].length)),
            shouldBeInComments: !1
          };
          (o.text || o.hasSeparatorLine) && n.push(o)
        }
      }
    }
    return n
  }

  function Fu(t, e) {
    const n = [],
      i = t.getLineCount();
    if (!e.markSectionHeaderRegex || e.markSectionHeaderRegex.trim() === "") return n;
    const r = Bl(e.markSectionHeaderRegex),
      s = new RegExp(e.markSectionHeaderRegex, `gdm${r?"s":""}`);
    if (Ho(s)) return n;
    for (let a = 1; a <= i; a += Vs - Uu) {
      const l = Math.min(a + Vs - 1, i),
        o = [];
      for (let d = a; d <= l; d++) o.push(t.getLineContent(d));
      const u = o.join(`
`);
      s.lastIndex = 0;
      let c;
      for (;
        (c = s.exec(u)) !== null;) {
        const d = u.substring(0, c.index),
          m = (d.match(/\n/g) || []).length,
          f = a + m,
          w = c[0].split(`
`),
          p = w.length,
          x = f + p - 1,
          T = d.lastIndexOf(`
`) + 1,
          y = c.index - T + 1,
          L = w[w.length - 1],
          I = p === 1 ? y + c[0].length : L.length + 1,
          H = {
            startLineNumber: f,
            startColumn: y,
            endLineNumber: x,
            endColumn: I
          },
          P = (c.groups ?? {}).label ?? "",
          b = ((c.groups ?? {}).separator ?? "") !== "",
          g = {
            range: H,
            text: P,
            hasSeparatorLine: b,
            shouldBeInComments: !0
          };
        (g.text || g.hasSeparatorLine) && (n.length === 0 || n[n.length - 1].range.endLineNumber < g.range.startLineNumber) && n.push(g), s.lastIndex = c.index + c[0].length
      }
    }
    return n
  }

  function Bu(t) {
    t = t.trim();
    const e = t.startsWith("-");
    return t = t.replace(Hu, ""), {
      text: t,
      hasSeparatorLine: e
    }
  }
  class qu {
    get isRejected() {
      var e;
      return ((e = this.outcome) == null ? void 0 : e.outcome) === 1
    }
    get isSettled() {
      return !!this.outcome
    }
    constructor() {
      this.p = new Promise((e, n) => {
        this.completeCallback = e, this.errorCallback = n
      })
    }
    complete(e) {
      return this.isSettled ? Promise.resolve() : new Promise(n => {
        this.completeCallback(e), this.outcome = {
          outcome: 0,
          value: e
        }, n()
      })
    }
    error(e) {
      return this.isSettled ? Promise.resolve() : new Promise(n => {
        this.errorCallback(e), this.outcome = {
          outcome: 1,
          value: e
        }, n()
      })
    }
    cancel() {
      return this.error(new Ui)
    }
  }
  var js;
  (function(t) {
    async function e(i) {
      let r;
      const s = await Promise.all(i.map(a => a.then(l => l, l => {
        r || (r = l)
      })));
      if (typeof r < "u") throw r;
      return s
    }
    t.settled = e;

    function n(i) {
      return new Promise(async (r, s) => {
        try {
          await i(r, s)
        } catch (a) {
          s(a)
        }
      })
    }
    t.withAsyncBody = n
  })(js || (js = {}));
  class Ou {
    constructor() {
      this._unsatisfiedConsumers = [], this._unconsumedValues = []
    }
    get hasFinalValue() {
      return !!this._finalValue
    }
    produce(e) {
      if (this._ensureNoFinalValue(), this._unsatisfiedConsumers.length > 0) {
        const n = this._unsatisfiedConsumers.shift();
        this._resolveOrRejectDeferred(n, e)
      } else this._unconsumedValues.push(e)
    }
    produceFinal(e) {
      this._ensureNoFinalValue(), this._finalValue = e;
      for (const n of this._unsatisfiedConsumers) this._resolveOrRejectDeferred(n, e);
      this._unsatisfiedConsumers.length = 0
    }
    _ensureNoFinalValue() {
      if (this._finalValue) throw new ue("ProducerConsumer: cannot produce after final value has been set")
    }
    _resolveOrRejectDeferred(e, n) {
      n.ok ? e.complete(n.value) : e.error(n.error)
    }
    consume() {
      if (this._unconsumedValues.length > 0 || this._finalValue) {
        const e = this._unconsumedValues.length > 0 ? this._unconsumedValues.shift() : this._finalValue;
        return e.ok ? Promise.resolve(e.value) : Promise.reject(e.error)
      } else {
        const e = new qu;
        return this._unsatisfiedConsumers.push(e), e.p
      }
    }
  }
  const pe = class pe {
    constructor(e, n) {
      this._onReturn = n, this._producerConsumer = new Ou, this._iterator = {
        next: () => this._producerConsumer.consume(),
        return: () => {
          var i;
          return (i = this._onReturn) == null || i.call(this), Promise.resolve({
            done: !0,
            value: void 0
          })
        },
        throw: async i => (this._finishError(i), {
          done: !0,
          value: void 0
        })
      }, queueMicrotask(async () => {
        const i = e({
          emitOne: r => this._producerConsumer.produce({
            ok: !0,
            value: {
              done: !1,
              value: r
            }
          }),
          emitMany: r => {
            for (const s of r) this._producerConsumer.produce({
              ok: !0,
              value: {
                done: !1,
                value: s
              }
            })
          },
          reject: r => this._finishError(r)
        });
        if (!this._producerConsumer.hasFinalValue) try {
          await i, this._finishOk()
        } catch (r) {
          this._finishError(r)
        }
      })
    }
    static fromArray(e) {
      return new pe(n => {
        n.emitMany(e)
      })
    }
    static fromPromise(e) {
      return new pe(async n => {
        n.emitMany(await e)
      })
    }
    static fromPromisesResolveOrder(e) {
      return new pe(async n => {
        await Promise.all(e.map(async i => n.emitOne(await i)))
      })
    }
    static merge(e) {
      return new pe(async n => {
        await Promise.all(e.map(async i => {
          for await (const r of i) n.emitOne(r)
        }))
      })
    }
    static map(e, n) {
      return new pe(async i => {
        for await (const r of e) i.emitOne(n(r))
      })
    }
    map(e) {
      return pe.map(this, e)
    }
    static coalesce(e) {
      return pe.filter(e, n => !!n)
    }
    coalesce() {
      return pe.coalesce(this)
    }
    static filter(e, n) {
      return new pe(async i => {
        for await (const r of e) n(r) && i.emitOne(r)
      })
    }
    filter(e) {
      return pe.filter(this, e)
    }
    _finishOk() {
      this._producerConsumer.hasFinalValue || this._producerConsumer.produceFinal({
        ok: !0,
        value: {
          done: !0,
          value: void 0
        }
      })
    }
    _finishError(e) {
      this._producerConsumer.hasFinalValue || this._producerConsumer.produceFinal({
        ok: !1,
        error: e
      })
    } [Symbol.asyncIterator]() {
      return this._iterator
    }
  };
  pe.EMPTY = pe.fromArray([]);
  let $s = pe;
  class Vu {
    constructor(e) {
      this.values = e, this.prefixSum = new Uint32Array(e.length), this.prefixSumValidIndex = new Int32Array(1), this.prefixSumValidIndex[0] = -1
    }
    insertValues(e, n) {
      e = ct(e);
      const i = this.values,
        r = this.prefixSum,
        s = n.length;
      return s === 0 ? !1 : (this.values = new Uint32Array(i.length + s), this.values.set(i.subarray(0, e), 0), this.values.set(i.subarray(e), e + s), this.values.set(n, e), e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), this.prefixSum = new Uint32Array(this.values.length), this.prefixSumValidIndex[0] >= 0 && this.prefixSum.set(r.subarray(0, this.prefixSumValidIndex[0] + 1)), !0)
    }
    setValue(e, n) {
      return e = ct(e), n = ct(n), this.values[e] === n ? !1 : (this.values[e] = n, e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), !0)
    }
    removeValues(e, n) {
      e = ct(e), n = ct(n);
      const i = this.values,
        r = this.prefixSum;
      if (e >= i.length) return !1;
      const s = i.length - e;
      return n >= s && (n = s), n === 0 ? !1 : (this.values = new Uint32Array(i.length - n), this.values.set(i.subarray(0, e), 0), this.values.set(i.subarray(e + n), e), this.prefixSum = new Uint32Array(this.values.length), e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), this.prefixSumValidIndex[0] >= 0 && this.prefixSum.set(r.subarray(0, this.prefixSumValidIndex[0] + 1)), !0)
    }
    getTotalSum() {
      return this.values.length === 0 ? 0 : this._getPrefixSum(this.values.length - 1)
    }
    getPrefixSum(e) {
      return e < 0 ? 0 : (e = ct(e), this._getPrefixSum(e))
    }
    _getPrefixSum(e) {
      if (e <= this.prefixSumValidIndex[0]) return this.prefixSum[e];
      let n = this.prefixSumValidIndex[0] + 1;
      n === 0 && (this.prefixSum[0] = this.values[0], n++), e >= this.values.length && (e = this.values.length - 1);
      for (let i = n; i <= e; i++) this.prefixSum[i] = this.prefixSum[i - 1] + this.values[i];
      return this.prefixSumValidIndex[0] = Math.max(this.prefixSumValidIndex[0], e), this.prefixSum[e]
    }
    getIndexOf(e) {
      e = Math.floor(e), this.getTotalSum();
      let n = 0,
        i = this.values.length - 1,
        r = 0,
        s = 0,
        a = 0;
      for (; n <= i;)
        if (r = n + (i - n) / 2 | 0, s = this.prefixSum[r], a = s - this.values[r], e < a) i = r - 1;
        else if (e >= s) n = r + 1;
      else break;
      return new ju(r, e - a)
    }
  }
  class ju {
    constructor(e, n) {
      this.index = e, this.remainder = n, this._prefixSumIndexOfResultBrand = void 0, this.index = e, this.remainder = n
    }
  }
  class $u {
    constructor(e, n, i, r) {
      this._uri = e, this._lines = n, this._eol = i, this._versionId = r, this._lineStarts = null, this._cachedTextValue = null
    }
    dispose() {
      this._lines.length = 0
    }
    get version() {
      return this._versionId
    }
    getText() {
      return this._cachedTextValue === null && (this._cachedTextValue = this._lines.join(this._eol)), this._cachedTextValue
    }
    onEvents(e) {
      e.eol && e.eol !== this._eol && (this._eol = e.eol, this._lineStarts = null);
      const n = e.changes;
      for (const i of n) this._acceptDeleteRange(i.range), this._acceptInsertText(new K(i.range.startLineNumber, i.range.startColumn), i.text);
      this._versionId = e.versionId, this._cachedTextValue = null
    }
    _ensureLineStarts() {
      if (!this._lineStarts) {
        const e = this._eol.length,
          n = this._lines.length,
          i = new Uint32Array(n);
        for (let r = 0; r < n; r++) i[r] = this._lines[r].length + e;
        this._lineStarts = new Vu(i)
      }
    }
    _setLineText(e, n) {
      this._lines[e] = n, this._lineStarts && this._lineStarts.setValue(e, this._lines[e].length + this._eol.length)
    }
    _acceptDeleteRange(e) {
      if (e.startLineNumber === e.endLineNumber) {
        if (e.startColumn === e.endColumn) return;
        this._setLineText(e.startLineNumber - 1, this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) + this._lines[e.startLineNumber - 1].substring(e.endColumn - 1));
        return
      }
      this._setLineText(e.startLineNumber - 1, this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) + this._lines[e.endLineNumber - 1].substring(e.endColumn - 1)), this._lines.splice(e.startLineNumber, e.endLineNumber - e.startLineNumber), this._lineStarts && this._lineStarts.removeValues(e.startLineNumber, e.endLineNumber - e.startLineNumber)
    }
    _acceptInsertText(e, n) {
      if (n.length === 0) return;
      const i = Uo(n);
      if (i.length === 1) {
        this._setLineText(e.lineNumber - 1, this._lines[e.lineNumber - 1].substring(0, e.column - 1) + i[0] + this._lines[e.lineNumber - 1].substring(e.column - 1));
        return
      }
      i[i.length - 1] += this._lines[e.lineNumber - 1].substring(e.column - 1), this._setLineText(e.lineNumber - 1, this._lines[e.lineNumber - 1].substring(0, e.column - 1) + i[0]);
      const r = new Uint32Array(i.length - 1);
      for (let s = 1; s < i.length; s++) this._lines.splice(e.lineNumber + s - 1, 0, i[s]), r[s - 1] = i[s].length + this._eol.length;
      this._lineStarts && this._lineStarts.insertValues(e.lineNumber, r)
    }
  }
  class Gu {
    constructor() {
      this._models = Object.create(null)
    }
    getModel(e) {
      return this._models[e]
    }
    getModels() {
      const e = [];
      return Object.keys(this._models).forEach(n => e.push(this._models[n])), e
    }
    $acceptNewModel(e) {
      this._models[e.url] = new Xu(Qn.parse(e.url), e.lines, e.EOL, e.versionId)
    }
    $acceptModelChanged(e, n) {
      if (!this._models[e]) return;
      this._models[e].onEvents(n)
    }
    $acceptRemovedModel(e) {
      this._models[e] && delete this._models[e]
    }
  }
  class Xu extends $u {
    get uri() {
      return this._uri
    }
    get eol() {
      return this._eol
    }
    getValue() {
      return this.getText()
    }
    findMatches(e) {
      const n = [];
      for (let i = 0; i < this._lines.length; i++) {
        const r = this._lines[i],
          s = this.offsetAt(new K(i + 1, 1)),
          a = r.matchAll(e);
        for (const l of a)(l.index || l.index === 0) && (l.index = l.index + s), n.push(l)
      }
      return n
    }
    getLinesContent() {
      return this._lines.slice(0)
    }
    getLineCount() {
      return this._lines.length
    }
    getLineContent(e) {
      return this._lines[e - 1]
    }
    getWordAtPosition(e, n) {
      const i = ri(e.column, ws(n), this._lines[e.lineNumber - 1], 0);
      return i ? new j(e.lineNumber, i.startColumn, e.lineNumber, i.endColumn) : null
    }
    words(e) {
      const n = this._lines,
        i = this._wordenize.bind(this);
      let r = 0,
        s = "",
        a = 0,
        l = [];
      return {
        *[Symbol.iterator]() {
          for (;;)
            if (a < l.length) {
              const o = s.substring(l[a].start, l[a].end);
              a += 1, yield o
            } else if (r < n.length) s = n[r], l = i(s, e), a = 0, r += 1;
          else break
        }
      }
    }
    getLineWords(e, n) {
      const i = this._lines[e - 1],
        r = this._wordenize(i, n),
        s = [];
      for (const a of r) s.push({
        word: i.substring(a.start, a.end),
        startColumn: a.start + 1,
        endColumn: a.end + 1
      });
      return s
    }
    _wordenize(e, n) {
      const i = [];
      let r;
      for (n.lastIndex = 0;
        (r = n.exec(e)) && r[0].length !== 0;) i.push({
        start: r.index,
        end: r.index + r[0].length
      });
      return i
    }
    getValueInRange(e) {
      if (e = this._validateRange(e), e.startLineNumber === e.endLineNumber) return this._lines[e.startLineNumber - 1].substring(e.startColumn - 1, e.endColumn - 1);
      const n = this._eol,
        i = e.startLineNumber - 1,
        r = e.endLineNumber - 1,
        s = [];
      s.push(this._lines[i].substring(e.startColumn - 1));
      for (let a = i + 1; a < r; a++) s.push(this._lines[a]);
      return s.push(this._lines[r].substring(0, e.endColumn - 1)), s.join(n)
    }
    offsetAt(e) {
      return e = this._validatePosition(e), this._ensureLineStarts(), this._lineStarts.getPrefixSum(e.lineNumber - 2) + (e.column - 1)
    }
    positionAt(e) {
      e = Math.floor(e), e = Math.max(0, e), this._ensureLineStarts();
      const n = this._lineStarts.getIndexOf(e),
        i = this._lines[n.index].length;
      return {
        lineNumber: 1 + n.index,
        column: 1 + Math.min(n.remainder, i)
      }
    }
    _validateRange(e) {
      const n = this._validatePosition({
          lineNumber: e.startLineNumber,
          column: e.startColumn
        }),
        i = this._validatePosition({
          lineNumber: e.endLineNumber,
          column: e.endColumn
        });
      return n.lineNumber !== e.startLineNumber || n.column !== e.startColumn || i.lineNumber !== e.endLineNumber || i.column !== e.endColumn ? {
        startLineNumber: n.lineNumber,
        startColumn: n.column,
        endLineNumber: i.lineNumber,
        endColumn: i.column
      } : e
    }
    _validatePosition(e) {
      if (!K.isIPosition(e)) throw new Error("bad position");
      let {
        lineNumber: n,
        column: i
      } = e, r = !1;
      if (n < 1) n = 1, i = 1, r = !0;
      else if (n > this._lines.length) n = this._lines.length, i = this._lines[n - 1].length + 1, r = !0;
      else {
        const s = this._lines[n - 1].length + 1;
        i < 1 ? (i = 1, r = !0) : i > s && (i = s, r = !0)
      }
      return r ? {
        lineNumber: n,
        column: i
      } : e
    }
  }
  const rt = class rt {
    constructor(e = null) {
      this._foreignModule = e, this._requestHandlerBrand = void 0, this._workerTextModelSyncServer = new Gu
    }
    dispose() {}
    async $ping() {
      return "pong"
    }
    _getModel(e) {
      return this._workerTextModelSyncServer.getModel(e)
    }
    getModels() {
      return this._workerTextModelSyncServer.getModels()
    }
    $acceptNewModel(e) {
      this._workerTextModelSyncServer.$acceptNewModel(e)
    }
    $acceptModelChanged(e, n) {
      this._workerTextModelSyncServer.$acceptModelChanged(e, n)
    }
    $acceptRemovedModel(e) {
      this._workerTextModelSyncServer.$acceptRemovedModel(e)
    }
    async $computeUnicodeHighlights(e, n, i) {
      const r = this._getModel(e);
      return r ? Jl.computeUnicodeHighlights(r, n, i) : {
        ranges: [],
        hasMore: !1,
        ambiguousCharacterCount: 0,
        invisibleCharacterCount: 0,
        nonBasicAsciiCharacterCount: 0
      }
    }
    async $findSectionHeaders(e, n) {
      const i = this._getModel(e);
      return i ? Pu(i, n) : []
    }
    async $computeDiff(e, n, i, r) {
      const s = this._getModel(e),
        a = this._getModel(n);
      return !s || !a ? null : rt.computeDiff(s, a, i, r)
    }
    static computeDiff(e, n, i, r) {
      const s = r === "advanced" ? Fs.getDefault() : Fs.getLegacy(),
        a = e.getLinesContent(),
        l = n.getLinesContent(),
        o = s.computeDiff(a, l, i),
        u = o.changes.length > 0 ? !1 : this._modelsAreIdentical(e, n);

      function c(d) {
        return d.map(m => {
          var f;
          return [m.original.startLineNumber, m.original.endLineNumberExclusive, m.modified.startLineNumber, m.modified.endLineNumberExclusive, (f = m.innerChanges) == null ? void 0 : f.map(w => [w.originalRange.startLineNumber, w.originalRange.startColumn, w.originalRange.endLineNumber, w.originalRange.endColumn, w.modifiedRange.startLineNumber, w.modifiedRange.startColumn, w.modifiedRange.endLineNumber, w.modifiedRange.endColumn])]
        })
      }
      return {
        identical: u,
        quitEarly: o.hitTimeout,
        changes: c(o.changes),
        moves: o.moves.map(d => [d.lineRangeMapping.original.startLineNumber, d.lineRangeMapping.original.endLineNumberExclusive, d.lineRangeMapping.modified.startLineNumber, d.lineRangeMapping.modified.endLineNumberExclusive, c(d.changes)])
      }
    }
    static _modelsAreIdentical(e, n) {
      const i = e.getLineCount(),
        r = n.getLineCount();
      if (i !== r) return !1;
      for (let s = 1; s <= i; s++) {
        const a = e.getLineContent(s),
          l = n.getLineContent(s);
        if (a !== l) return !1
      }
      return !0
    }
    async $computeMoreMinimalEdits(e, n, i) {
      const r = this._getModel(e);
      if (!r) return n;
      const s = [];
      let a;
      n = n.slice(0).sort((o, u) => {
        if (o.range && u.range) return j.compareRangesUsingStarts(o.range, u.range);
        const c = o.range ? 0 : 1,
          d = u.range ? 0 : 1;
        return c - d
      });
      let l = 0;
      for (let o = 1; o < n.length; o++) j.getEndPosition(n[l].range).equals(j.getStartPosition(n[o].range)) ? (n[l].range = j.fromPositions(j.getStartPosition(n[l].range), j.getEndPosition(n[o].range)), n[l].text += n[o].text) : (l++, n[l] = n[o]);
      n.length = l + 1;
      for (let {
          range: o,
          text: u,
          eol: c
        }
        of n) {
        if (typeof c == "number" && (a = c), j.isEmpty(o) && !u) continue;
        const d = r.getValueInRange(o);
        if (u = u.replace(/\r\n|\n|\r/g, r.eol), d === u) continue;
        if (Math.max(u.length, d.length) > rt._diffLimit) {
          s.push({
            range: o,
            text: u
          });
          continue
        }
        const m = nl(d, u, i),
          f = r.offsetAt(j.lift(o).getStartPosition());
        for (const w of m) {
          const p = r.positionAt(f + w.originalStart),
            x = r.positionAt(f + w.originalStart + w.originalLength),
            T = {
              text: u.substr(w.modifiedStart, w.modifiedLength),
              range: {
                startLineNumber: p.lineNumber,
                startColumn: p.column,
                endLineNumber: x.lineNumber,
                endColumn: x.column
              }
            };
          r.getValueInRange(T.range) !== T.text && s.push(T)
        }
      }
      return typeof a == "number" && s.push({
        eol: a,
        text: "",
        range: {
          startLineNumber: 0,
          startColumn: 0,
          endLineNumber: 0,
          endColumn: 0
        }
      }), s
    }
    async $computeLinks(e) {
      const n = this._getModel(e);
      return n ? ol(n) : null
    }
    async $computeDefaultDocumentColors(e) {
      const n = this._getModel(e);
      return n ? zu(n) : null
    }
    async $textualSuggest(e, n, i, r) {
      const s = new Jt,
        a = new RegExp(i, r),
        l = new Set;
      e: for (const o of e) {
        const u = this._getModel(o);
        if (u) {
          for (const c of u.words(a))
            if (!(c === n || !isNaN(Number(c))) && (l.add(c), l.size > rt._suggestionsLimit)) break e
        }
      }
      return {
        words: Array.from(l),
        duration: s.elapsed()
      }
    }
    async $computeWordRanges(e, n, i, r) {
      const s = this._getModel(e);
      if (!s) return Object.create(null);
      const a = new RegExp(i, r),
        l = Object.create(null);
      for (let o = n.startLineNumber; o < n.endLineNumber; o++) {
        const u = s.getLineWords(o, a);
        for (const c of u) {
          if (!isNaN(Number(c.word))) continue;
          let d = l[c.word];
          d || (d = [], l[c.word] = d), d.push({
            startLineNumber: o,
            startColumn: c.startColumn,
            endLineNumber: o,
            endColumn: c.endColumn
          })
        }
      }
      return l
    }
    async $navigateValueSet(e, n, i, r, s) {
      const a = this._getModel(e);
      if (!a) return null;
      const l = new RegExp(r, s);
      n.startColumn === n.endColumn && (n = {
        startLineNumber: n.startLineNumber,
        startColumn: n.startColumn,
        endLineNumber: n.endLineNumber,
        endColumn: n.endColumn + 1
      });
      const o = a.getValueInRange(n),
        u = a.getWordAtPosition({
          lineNumber: n.startLineNumber,
          column: n.startColumn
        }, l);
      if (!u) return null;
      const c = a.getValueInRange(u);
      return Vn.INSTANCE.navigateValueSet(n, o, u, c, i)
    }
    $fmr(e, n) {
      if (!this._foreignModule || typeof this._foreignModule[e] != "function") return Promise.reject(new Error("Missing requestHandler or method: " + e));
      try {
        return Promise.resolve(this._foreignModule[e].apply(this._foreignModule, n))
      } catch (i) {
        return Promise.reject(i)
      }
    }
  };
  rt._diffLimit = 1e5, rt._suggestionsLimit = 1e4;
  let di = rt;
  typeof importScripts == "function" && (globalThis.monaco = Hl());
  const jt = class jt {
    static getChannel(e) {
      return e.getChannel(jt.CHANNEL_NAME)
    }
    static setChannel(e, n) {
      e.setChannel(jt.CHANNEL_NAME, n)
    }
  };
  jt.CHANNEL_NAME = "editorWorkerHost";
  let mi = jt;

  function Ju(t) {
    let e;
    const n = el(i => {
      const r = mi.getChannel(i),
        a = {
          host: new Proxy({}, {
            get(l, o, u) {
              if (o !== "then") {
                if (typeof o != "string") throw new Error("Not supported");
                return (...c) => r.$fhr(o, c)
              }
            }
          }),
          getMirrorModels: () => n.requestHandler.getModels()
        };
      return e = t(a), new di(e)
    });
    return e
  }

  function Qu(t) {
    self.onmessage = e => {
      Ju(n => t(n, e.data))
    }
  }

  function Ae(...t) {
    const e = t[0];
    let n, i, r;
    if (typeof e == "string") n = e, i = e, t.splice(0, 1), r = !t || typeof t[0] != "object" ? t : t[0];
    else if (e instanceof Array) {
      const s = t.slice(1);
      if (e.length !== s.length + 1) throw new Error("expected a string as the first argument to l10n.t");
      let a = e[0];
      for (let l = 1; l < e.length; l++) a += `{${l-1}}` + e[l];
      return Ae(a, ...s)
    } else i = e.message, n = i, e.comment && e.comment.length > 0 && (n += `/${Array.isArray(e.comment)?e.comment.join(""):e.comment}`), r = e.args ?? {};
    return Zu(i, r)
  }
  var Yu = /{([^}]+)}/g;

  function Zu(t, e) {
    return Object.keys(e).length === 0 ? t : t.replace(Yu, (n, i) => e[i] ?? n)
  }
  var Gs;
  (function(t) {
    function e(n) {
      return typeof n == "string"
    }
    t.is = e
  })(Gs || (Gs = {}));
  var fi;
  (function(t) {
    function e(n) {
      return typeof n == "string"
    }
    t.is = e
  })(fi || (fi = {}));
  var Xs;
  (function(t) {
    t.MIN_VALUE = -2147483648, t.MAX_VALUE = 2147483647;

    function e(n) {
      return typeof n == "number" && t.MIN_VALUE <= n && n <= t.MAX_VALUE
    }
    t.is = e
  })(Xs || (Xs = {}));
  var hn;
  (function(t) {
    t.MIN_VALUE = 0, t.MAX_VALUE = 2147483647;

    function e(n) {
      return typeof n == "number" && t.MIN_VALUE <= n && n <= t.MAX_VALUE
    }
    t.is = e
  })(hn || (hn = {}));
  var se;
  (function(t) {
    function e(i, r) {
      return i === Number.MAX_VALUE && (i = hn.MAX_VALUE), r === Number.MAX_VALUE && (r = hn.MAX_VALUE), {
        line: i,
        character: r
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.objectLiteral(r) && R.uinteger(r.line) && R.uinteger(r.character)
    }
    t.is = n
  })(se || (se = {}));
  var J;
  (function(t) {
    function e(i, r, s, a) {
      if (R.uinteger(i) && R.uinteger(r) && R.uinteger(s) && R.uinteger(a)) return {
        start: se.create(i, r),
        end: se.create(s, a)
      };
      if (se.is(i) && se.is(r)) return {
        start: i,
        end: r
      };
      throw new Error(`Range#create called with invalid arguments[${i}, ${r}, ${s}, ${a}]`)
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.objectLiteral(r) && se.is(r.start) && se.is(r.end)
    }
    t.is = n
  })(J || (J = {}));
  var dn;
  (function(t) {
    function e(i, r) {
      return {
        uri: i,
        range: r
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.objectLiteral(r) && J.is(r.range) && (R.string(r.uri) || R.undefined(r.uri))
    }
    t.is = n
  })(dn || (dn = {}));
  var Js;
  (function(t) {
    function e(i, r, s, a) {
      return {
        targetUri: i,
        targetRange: r,
        targetSelectionRange: s,
        originSelectionRange: a
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.objectLiteral(r) && J.is(r.targetRange) && R.string(r.targetUri) && J.is(r.targetSelectionRange) && (J.is(r.originSelectionRange) || R.undefined(r.originSelectionRange))
    }
    t.is = n
  })(Js || (Js = {}));
  var pi;
  (function(t) {
    function e(i, r, s, a) {
      return {
        red: i,
        green: r,
        blue: s,
        alpha: a
      }
    }
    t.create = e;

    function n(i) {
      const r = i;
      return R.objectLiteral(r) && R.numberRange(r.red, 0, 1) && R.numberRange(r.green, 0, 1) && R.numberRange(r.blue, 0, 1) && R.numberRange(r.alpha, 0, 1)
    }
    t.is = n
  })(pi || (pi = {}));
  var Qs;
  (function(t) {
    function e(i, r) {
      return {
        range: i,
        color: r
      }
    }
    t.create = e;

    function n(i) {
      const r = i;
      return R.objectLiteral(r) && J.is(r.range) && pi.is(r.color)
    }
    t.is = n
  })(Qs || (Qs = {}));
  var Ys;
  (function(t) {
    function e(i, r, s) {
      return {
        label: i,
        textEdit: r,
        additionalTextEdits: s
      }
    }
    t.create = e;

    function n(i) {
      const r = i;
      return R.objectLiteral(r) && R.string(r.label) && (R.undefined(r.textEdit) || le.is(r)) && (R.undefined(r.additionalTextEdits) || R.typedArray(r.additionalTextEdits, le.is))
    }
    t.is = n
  })(Ys || (Ys = {}));
  var mn;
  (function(t) {
    t.Comment = "comment", t.Imports = "imports", t.Region = "region"
  })(mn || (mn = {}));
  var Zs;
  (function(t) {
    function e(i, r, s, a, l, o) {
      const u = {
        startLine: i,
        endLine: r
      };
      return R.defined(s) && (u.startCharacter = s), R.defined(a) && (u.endCharacter = a), R.defined(l) && (u.kind = l), R.defined(o) && (u.collapsedText = o), u
    }
    t.create = e;

    function n(i) {
      const r = i;
      return R.objectLiteral(r) && R.uinteger(r.startLine) && R.uinteger(r.startLine) && (R.undefined(r.startCharacter) || R.uinteger(r.startCharacter)) && (R.undefined(r.endCharacter) || R.uinteger(r.endCharacter)) && (R.undefined(r.kind) || R.string(r.kind))
    }
    t.is = n
  })(Zs || (Zs = {}));
  var gi;
  (function(t) {
    function e(i, r) {
      return {
        location: i,
        message: r
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && dn.is(r.location) && R.string(r.message)
    }
    t.is = n
  })(gi || (gi = {}));
  var Ks;
  (function(t) {
    t.Error = 1, t.Warning = 2, t.Information = 3, t.Hint = 4
  })(Ks || (Ks = {}));
  var ea;
  (function(t) {
    t.Unnecessary = 1, t.Deprecated = 2
  })(ea || (ea = {}));
  var ta;
  (function(t) {
    function e(n) {
      const i = n;
      return R.objectLiteral(i) && R.string(i.href)
    }
    t.is = e
  })(ta || (ta = {}));
  var fn;
  (function(t) {
    function e(i, r, s, a, l, o) {
      let u = {
        range: i,
        message: r
      };
      return R.defined(s) && (u.severity = s), R.defined(a) && (u.code = a), R.defined(l) && (u.source = l), R.defined(o) && (u.relatedInformation = o), u
    }
    t.create = e;

    function n(i) {
      var r;
      let s = i;
      return R.defined(s) && J.is(s.range) && R.string(s.message) && (R.number(s.severity) || R.undefined(s.severity)) && (R.integer(s.code) || R.string(s.code) || R.undefined(s.code)) && (R.undefined(s.codeDescription) || R.string((r = s.codeDescription) === null || r === void 0 ? void 0 : r.href)) && (R.string(s.source) || R.undefined(s.source)) && (R.undefined(s.relatedInformation) || R.typedArray(s.relatedInformation, gi.is))
    }
    t.is = n
  })(fn || (fn = {}));
  var vt;
  (function(t) {
    function e(i, r, ...s) {
      let a = {
        title: i,
        command: r
      };
      return R.defined(s) && s.length > 0 && (a.arguments = s), a
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && R.string(r.title) && R.string(r.command)
    }
    t.is = n
  })(vt || (vt = {}));
  var le;
  (function(t) {
    function e(s, a) {
      return {
        range: s,
        newText: a
      }
    }
    t.replace = e;

    function n(s, a) {
      return {
        range: {
          start: s,
          end: s
        },
        newText: a
      }
    }
    t.insert = n;

    function i(s) {
      return {
        range: s,
        newText: ""
      }
    }
    t.del = i;

    function r(s) {
      const a = s;
      return R.objectLiteral(a) && R.string(a.newText) && J.is(a.range)
    }
    t.is = r
  })(le || (le = {}));
  var bi;
  (function(t) {
    function e(i, r, s) {
      const a = {
        label: i
      };
      return r !== void 0 && (a.needsConfirmation = r), s !== void 0 && (a.description = s), a
    }
    t.create = e;

    function n(i) {
      const r = i;
      return R.objectLiteral(r) && R.string(r.label) && (R.boolean(r.needsConfirmation) || r.needsConfirmation === void 0) && (R.string(r.description) || r.description === void 0)
    }
    t.is = n
  })(bi || (bi = {}));
  var yt;
  (function(t) {
    function e(n) {
      const i = n;
      return R.string(i)
    }
    t.is = e
  })(yt || (yt = {}));
  var na;
  (function(t) {
    function e(s, a, l) {
      return {
        range: s,
        newText: a,
        annotationId: l
      }
    }
    t.replace = e;

    function n(s, a, l) {
      return {
        range: {
          start: s,
          end: s
        },
        newText: a,
        annotationId: l
      }
    }
    t.insert = n;

    function i(s, a) {
      return {
        range: s,
        newText: "",
        annotationId: a
      }
    }
    t.del = i;

    function r(s) {
      const a = s;
      return le.is(a) && (bi.is(a.annotationId) || yt.is(a.annotationId))
    }
    t.is = r
  })(na || (na = {}));
  var wi;
  (function(t) {
    function e(i, r) {
      return {
        textDocument: i,
        edits: r
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && xi.is(r.textDocument) && Array.isArray(r.edits)
    }
    t.is = n
  })(wi || (wi = {}));
  var _i;
  (function(t) {
    function e(i, r, s) {
      let a = {
        kind: "create",
        uri: i
      };
      return r !== void 0 && (r.overwrite !== void 0 || r.ignoreIfExists !== void 0) && (a.options = r), s !== void 0 && (a.annotationId = s), a
    }
    t.create = e;

    function n(i) {
      let r = i;
      return r && r.kind === "create" && R.string(r.uri) && (r.options === void 0 || (r.options.overwrite === void 0 || R.boolean(r.options.overwrite)) && (r.options.ignoreIfExists === void 0 || R.boolean(r.options.ignoreIfExists))) && (r.annotationId === void 0 || yt.is(r.annotationId))
    }
    t.is = n
  })(_i || (_i = {}));
  var vi;
  (function(t) {
    function e(i, r, s, a) {
      let l = {
        kind: "rename",
        oldUri: i,
        newUri: r
      };
      return s !== void 0 && (s.overwrite !== void 0 || s.ignoreIfExists !== void 0) && (l.options = s), a !== void 0 && (l.annotationId = a), l
    }
    t.create = e;

    function n(i) {
      let r = i;
      return r && r.kind === "rename" && R.string(r.oldUri) && R.string(r.newUri) && (r.options === void 0 || (r.options.overwrite === void 0 || R.boolean(r.options.overwrite)) && (r.options.ignoreIfExists === void 0 || R.boolean(r.options.ignoreIfExists))) && (r.annotationId === void 0 || yt.is(r.annotationId))
    }
    t.is = n
  })(vi || (vi = {}));
  var yi;
  (function(t) {
    function e(i, r, s) {
      let a = {
        kind: "delete",
        uri: i
      };
      return r !== void 0 && (r.recursive !== void 0 || r.ignoreIfNotExists !== void 0) && (a.options = r), s !== void 0 && (a.annotationId = s), a
    }
    t.create = e;

    function n(i) {
      let r = i;
      return r && r.kind === "delete" && R.string(r.uri) && (r.options === void 0 || (r.options.recursive === void 0 || R.boolean(r.options.recursive)) && (r.options.ignoreIfNotExists === void 0 || R.boolean(r.options.ignoreIfNotExists))) && (r.annotationId === void 0 || yt.is(r.annotationId))
    }
    t.is = n
  })(yi || (yi = {}));
  var Ti;
  (function(t) {
    function e(n) {
      let i = n;
      return i && (i.changes !== void 0 || i.documentChanges !== void 0) && (i.documentChanges === void 0 || i.documentChanges.every(r => R.string(r.kind) ? _i.is(r) || vi.is(r) || yi.is(r) : wi.is(r)))
    }
    t.is = e
  })(Ti || (Ti = {}));
  var ia;
  (function(t) {
    function e(i) {
      return {
        uri: i
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && R.string(r.uri)
    }
    t.is = n
  })(ia || (ia = {}));
  var ra;
  (function(t) {
    function e(i, r) {
      return {
        uri: i,
        version: r
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && R.string(r.uri) && R.integer(r.version)
    }
    t.is = n
  })(ra || (ra = {}));
  var xi;
  (function(t) {
    function e(i, r) {
      return {
        uri: i,
        version: r
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && R.string(r.uri) && (r.version === null || R.integer(r.version))
    }
    t.is = n
  })(xi || (xi = {}));
  var sa;
  (function(t) {
    function e(i, r, s, a) {
      return {
        uri: i,
        languageId: r,
        version: s,
        text: a
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && R.string(r.uri) && R.string(r.languageId) && R.integer(r.version) && R.string(r.text)
    }
    t.is = n
  })(sa || (sa = {}));
  var qe;
  (function(t) {
    t.PlainText = "plaintext", t.Markdown = "markdown";

    function e(n) {
      const i = n;
      return i === t.PlainText || i === t.Markdown
    }
    t.is = e
  })(qe || (qe = {}));
  var Wt;
  (function(t) {
    function e(n) {
      const i = n;
      return R.objectLiteral(n) && qe.is(i.kind) && R.string(i.value)
    }
    t.is = e
  })(Wt || (Wt = {}));
  var fe;
  (function(t) {
    t.Text = 1, t.Method = 2, t.Function = 3, t.Constructor = 4, t.Field = 5, t.Variable = 6, t.Class = 7, t.Interface = 8, t.Module = 9, t.Property = 10, t.Unit = 11, t.Value = 12, t.Enum = 13, t.Keyword = 14, t.Snippet = 15, t.Color = 16, t.File = 17, t.Reference = 18, t.Folder = 19, t.EnumMember = 20, t.Constant = 21, t.Struct = 22, t.Event = 23, t.Operator = 24, t.TypeParameter = 25
  })(fe || (fe = {}));
  var Le;
  (function(t) {
    t.PlainText = 1, t.Snippet = 2
  })(Le || (Le = {}));
  var aa;
  (function(t) {
    t.Deprecated = 1
  })(aa || (aa = {}));
  var oa;
  (function(t) {
    function e(i, r, s) {
      return {
        newText: i,
        insert: r,
        replace: s
      }
    }
    t.create = e;

    function n(i) {
      const r = i;
      return r && R.string(r.newText) && J.is(r.insert) && J.is(r.replace)
    }
    t.is = n
  })(oa || (oa = {}));
  var la;
  (function(t) {
    t.asIs = 1, t.adjustIndentation = 2
  })(la || (la = {}));
  var ua;
  (function(t) {
    function e(n) {
      const i = n;
      return i && (R.string(i.detail) || i.detail === void 0) && (R.string(i.description) || i.description === void 0)
    }
    t.is = e
  })(ua || (ua = {}));
  var ca;
  (function(t) {
    function e(n) {
      return {
        label: n
      }
    }
    t.create = e
  })(ca || (ca = {}));
  var ha;
  (function(t) {
    function e(n, i) {
      return {
        items: n || [],
        isIncomplete: !!i
      }
    }
    t.create = e
  })(ha || (ha = {}));
  var pn;
  (function(t) {
    function e(i) {
      return i.replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&")
    }
    t.fromPlainText = e;

    function n(i) {
      const r = i;
      return R.string(r) || R.objectLiteral(r) && R.string(r.language) && R.string(r.value)
    }
    t.is = n
  })(pn || (pn = {}));
  var da;
  (function(t) {
    function e(n) {
      let i = n;
      return !!i && R.objectLiteral(i) && (Wt.is(i.contents) || pn.is(i.contents) || R.typedArray(i.contents, pn.is)) && (n.range === void 0 || J.is(n.range))
    }
    t.is = e
  })(da || (da = {}));
  var ma;
  (function(t) {
    function e(n, i) {
      return i ? {
        label: n,
        documentation: i
      } : {
        label: n
      }
    }
    t.create = e
  })(ma || (ma = {}));
  var fa;
  (function(t) {
    function e(n, i, ...r) {
      let s = {
        label: n
      };
      return R.defined(i) && (s.documentation = i), R.defined(r) ? s.parameters = r : s.parameters = [], s
    }
    t.create = e
  })(fa || (fa = {}));
  var gn;
  (function(t) {
    t.Text = 1, t.Read = 2, t.Write = 3
  })(gn || (gn = {}));
  var pa;
  (function(t) {
    function e(n, i) {
      let r = {
        range: n
      };
      return R.number(i) && (r.kind = i), r
    }
    t.create = e
  })(pa || (pa = {}));
  var ki;
  (function(t) {
    t.File = 1, t.Module = 2, t.Namespace = 3, t.Package = 4, t.Class = 5, t.Method = 6, t.Property = 7, t.Field = 8, t.Constructor = 9, t.Enum = 10, t.Interface = 11, t.Function = 12, t.Variable = 13, t.Constant = 14, t.String = 15, t.Number = 16, t.Boolean = 17, t.Array = 18, t.Object = 19, t.Key = 20, t.Null = 21, t.EnumMember = 22, t.Struct = 23, t.Event = 24, t.Operator = 25, t.TypeParameter = 26
  })(ki || (ki = {}));
  var ga;
  (function(t) {
    t.Deprecated = 1
  })(ga || (ga = {}));
  var Si;
  (function(t) {
    function e(n, i, r, s, a) {
      let l = {
        name: n,
        kind: i,
        location: {
          uri: s,
          range: r
        }
      };
      return a && (l.containerName = a), l
    }
    t.create = e
  })(Si || (Si = {}));
  var ba;
  (function(t) {
    function e(n, i, r, s) {
      return s !== void 0 ? {
        name: n,
        kind: i,
        location: {
          uri: r,
          range: s
        }
      } : {
        name: n,
        kind: i,
        location: {
          uri: r
        }
      }
    }
    t.create = e
  })(ba || (ba = {}));
  var Ai;
  (function(t) {
    function e(i, r, s, a, l, o) {
      let u = {
        name: i,
        detail: r,
        kind: s,
        range: a,
        selectionRange: l
      };
      return o !== void 0 && (u.children = o), u
    }
    t.create = e;

    function n(i) {
      let r = i;
      return r && R.string(r.name) && R.number(r.kind) && J.is(r.range) && J.is(r.selectionRange) && (r.detail === void 0 || R.string(r.detail)) && (r.deprecated === void 0 || R.boolean(r.deprecated)) && (r.children === void 0 || Array.isArray(r.children)) && (r.tags === void 0 || Array.isArray(r.tags))
    }
    t.is = n
  })(Ai || (Ai = {}));
  var wa;
  (function(t) {
    t.Empty = "", t.QuickFix = "quickfix", t.Refactor = "refactor", t.RefactorExtract = "refactor.extract", t.RefactorInline = "refactor.inline", t.RefactorRewrite = "refactor.rewrite", t.Source = "source", t.SourceOrganizeImports = "source.organizeImports", t.SourceFixAll = "source.fixAll"
  })(wa || (wa = {}));
  var bn;
  (function(t) {
    t.Invoked = 1, t.Automatic = 2
  })(bn || (bn = {}));
  var _a;
  (function(t) {
    function e(i, r, s) {
      let a = {
        diagnostics: i
      };
      return r != null && (a.only = r), s != null && (a.triggerKind = s), a
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && R.typedArray(r.diagnostics, fn.is) && (r.only === void 0 || R.typedArray(r.only, R.string)) && (r.triggerKind === void 0 || r.triggerKind === bn.Invoked || r.triggerKind === bn.Automatic)
    }
    t.is = n
  })(_a || (_a = {}));
  var va;
  (function(t) {
    function e(i, r, s) {
      let a = {
          title: i
        },
        l = !0;
      return typeof r == "string" ? (l = !1, a.kind = r) : vt.is(r) ? a.command = r : a.edit = r, l && s !== void 0 && (a.kind = s), a
    }
    t.create = e;

    function n(i) {
      let r = i;
      return r && R.string(r.title) && (r.diagnostics === void 0 || R.typedArray(r.diagnostics, fn.is)) && (r.kind === void 0 || R.string(r.kind)) && (r.edit !== void 0 || r.command !== void 0) && (r.command === void 0 || vt.is(r.command)) && (r.isPreferred === void 0 || R.boolean(r.isPreferred)) && (r.edit === void 0 || Ti.is(r.edit))
    }
    t.is = n
  })(va || (va = {}));
  var ya;
  (function(t) {
    function e(i, r) {
      let s = {
        range: i
      };
      return R.defined(r) && (s.data = r), s
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && J.is(r.range) && (R.undefined(r.command) || vt.is(r.command))
    }
    t.is = n
  })(ya || (ya = {}));
  var Ta;
  (function(t) {
    function e(i, r) {
      return {
        tabSize: i,
        insertSpaces: r
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && R.uinteger(r.tabSize) && R.boolean(r.insertSpaces)
    }
    t.is = n
  })(Ta || (Ta = {}));
  var xa;
  (function(t) {
    function e(i, r, s) {
      return {
        range: i,
        target: r,
        data: s
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.defined(r) && J.is(r.range) && (R.undefined(r.target) || R.string(r.target))
    }
    t.is = n
  })(xa || (xa = {}));
  var wn;
  (function(t) {
    function e(i, r) {
      return {
        range: i,
        parent: r
      }
    }
    t.create = e;

    function n(i) {
      let r = i;
      return R.objectLiteral(r) && J.is(r.range) && (r.parent === void 0 || t.is(r.parent))
    }
    t.is = n
  })(wn || (wn = {}));
  var ka;
  (function(t) {
    t.namespace = "namespace", t.type = "type", t.class = "class", t.enum = "enum", t.interface = "interface", t.struct = "struct", t.typeParameter = "typeParameter", t.parameter = "parameter", t.variable = "variable", t.property = "property", t.enumMember = "enumMember", t.event = "event", t.function = "function", t.method = "method", t.macro = "macro", t.keyword = "keyword", t.modifier = "modifier", t.comment = "comment", t.string = "string", t.number = "number", t.regexp = "regexp", t.operator = "operator", t.decorator = "decorator"
  })(ka || (ka = {}));
  var Sa;
  (function(t) {
    t.declaration = "declaration", t.definition = "definition", t.readonly = "readonly", t.static = "static", t.deprecated = "deprecated", t.abstract = "abstract", t.async = "async", t.modification = "modification", t.documentation = "documentation", t.defaultLibrary = "defaultLibrary"
  })(Sa || (Sa = {}));
  var Aa;
  (function(t) {
    function e(n) {
      const i = n;
      return R.objectLiteral(i) && (i.resultId === void 0 || typeof i.resultId == "string") && Array.isArray(i.data) && (i.data.length === 0 || typeof i.data[0] == "number")
    }
    t.is = e
  })(Aa || (Aa = {}));
  var La;
  (function(t) {
    function e(i, r) {
      return {
        range: i,
        text: r
      }
    }
    t.create = e;

    function n(i) {
      const r = i;
      return r != null && J.is(r.range) && R.string(r.text)
    }
    t.is = n
  })(La || (La = {}));
  var Ca;
  (function(t) {
    function e(i, r, s) {
      return {
        range: i,
        variableName: r,
        caseSensitiveLookup: s
      }
    }
    t.create = e;

    function n(i) {
      const r = i;
      return r != null && J.is(r.range) && R.boolean(r.caseSensitiveLookup) && (R.string(r.variableName) || r.variableName === void 0)
    }
    t.is = n
  })(Ca || (Ca = {}));
  var Ea;
  (function(t) {
    function e(i, r) {
      return {
        range: i,
        expression: r
      }
    }
    t.create = e;

    function n(i) {
      const r = i;
      return r != null && J.is(r.range) && (R.string(r.expression) || r.expression === void 0)
    }
    t.is = n
  })(Ea || (Ea = {}));
  var Ra;
  (function(t) {
    function e(i, r) {
      return {
        frameId: i,
        stoppedLocation: r
      }
    }
    t.create = e;

    function n(i) {
      const r = i;
      return R.defined(r) && J.is(i.stoppedLocation)
    }
    t.is = n
  })(Ra || (Ra = {}));
  var Li;
  (function(t) {
    t.Type = 1, t.Parameter = 2;

    function e(n) {
      return n === 1 || n === 2
    }
    t.is = e
  })(Li || (Li = {}));
  var Ci;
  (function(t) {
    function e(i) {
      return {
        value: i
      }
    }
    t.create = e;

    function n(i) {
      const r = i;
      return R.objectLiteral(r) && (r.tooltip === void 0 || R.string(r.tooltip) || Wt.is(r.tooltip)) && (r.location === void 0 || dn.is(r.location)) && (r.command === void 0 || vt.is(r.command))
    }
    t.is = n
  })(Ci || (Ci = {}));
  var Da;
  (function(t) {
    function e(i, r, s) {
      const a = {
        position: i,
        label: r
      };
      return s !== void 0 && (a.kind = s), a
    }
    t.create = e;

    function n(i) {
      const r = i;
      return R.objectLiteral(r) && se.is(r.position) && (R.string(r.label) || R.typedArray(r.label, Ci.is)) && (r.kind === void 0 || Li.is(r.kind)) && r.textEdits === void 0 || R.typedArray(r.textEdits, le.is) && (r.tooltip === void 0 || R.string(r.tooltip) || Wt.is(r.tooltip)) && (r.paddingLeft === void 0 || R.boolean(r.paddingLeft)) && (r.paddingRight === void 0 || R.boolean(r.paddingRight))
    }
    t.is = n
  })(Da || (Da = {}));
  var Ma;
  (function(t) {
    function e(n) {
      return {
        kind: "snippet",
        value: n
      }
    }
    t.createSnippet = e
  })(Ma || (Ma = {}));
  var Na;
  (function(t) {
    function e(n, i, r, s) {
      return {
        insertText: n,
        filterText: i,
        range: r,
        command: s
      }
    }
    t.create = e
  })(Na || (Na = {}));
  var Ia;
  (function(t) {
    function e(n) {
      return {
        items: n
      }
    }
    t.create = e
  })(Ia || (Ia = {}));
  var za;
  (function(t) {
    t.Invoked = 0, t.Automatic = 1
  })(za || (za = {}));
  var Ha;
  (function(t) {
    function e(n, i) {
      return {
        range: n,
        text: i
      }
    }
    t.create = e
  })(Ha || (Ha = {}));
  var Ua;
  (function(t) {
    function e(n, i) {
      return {
        triggerKind: n,
        selectedCompletionInfo: i
      }
    }
    t.create = e
  })(Ua || (Ua = {}));
  var Pa;
  (function(t) {
    function e(n) {
      const i = n;
      return R.objectLiteral(i) && fi.is(i.uri) && R.string(i.name)
    }
    t.is = e
  })(Pa || (Pa = {}));
  var Wa;
  (function(t) {
    function e(s, a, l, o) {
      return new Ku(s, a, l, o)
    }
    t.create = e;

    function n(s) {
      let a = s;
      return !!(R.defined(a) && R.string(a.uri) && (R.undefined(a.languageId) || R.string(a.languageId)) && R.uinteger(a.lineCount) && R.func(a.getText) && R.func(a.positionAt) && R.func(a.offsetAt))
    }
    t.is = n;

    function i(s, a) {
      let l = s.getText(),
        o = r(a, (c, d) => {
          let m = c.range.start.line - d.range.start.line;
          return m === 0 ? c.range.start.character - d.range.start.character : m
        }),
        u = l.length;
      for (let c = o.length - 1; c >= 0; c--) {
        let d = o[c],
          m = s.offsetAt(d.range.start),
          f = s.offsetAt(d.range.end);
        if (f <= u) l = l.substring(0, m) + d.newText + l.substring(f, l.length);
        else throw new Error("Overlapping edit");
        u = m
      }
      return l
    }
    t.applyEdits = i;

    function r(s, a) {
      if (s.length <= 1) return s;
      const l = s.length / 2 | 0,
        o = s.slice(0, l),
        u = s.slice(l);
      r(o, a), r(u, a);
      let c = 0,
        d = 0,
        m = 0;
      for (; c < o.length && d < u.length;) a(o[c], u[d]) <= 0 ? s[m++] = o[c++] : s[m++] = u[d++];
      for (; c < o.length;) s[m++] = o[c++];
      for (; d < u.length;) s[m++] = u[d++];
      return s
    }
  })(Wa || (Wa = {}));
  let Ku = class {
    constructor(e, n, i, r) {
      this._uri = e, this._languageId = n, this._version = i, this._content = r, this._lineOffsets = void 0
    }
    get uri() {
      return this._uri
    }
    get languageId() {
      return this._languageId
    }
    get version() {
      return this._version
    }
    getText(e) {
      if (e) {
        let n = this.offsetAt(e.start),
          i = this.offsetAt(e.end);
        return this._content.substring(n, i)
      }
      return this._content
    }
    update(e, n) {
      this._content = e.text, this._version = n, this._lineOffsets = void 0
    }
    getLineOffsets() {
      if (this._lineOffsets === void 0) {
        let e = [],
          n = this._content,
          i = !0;
        for (let r = 0; r < n.length; r++) {
          i && (e.push(r), i = !1);
          let s = n.charAt(r);
          i = s === "\r" || s === `
`, s === "\r" && r + 1 < n.length && n.charAt(r + 1) === `
` && r++
        }
        i && n.length > 0 && e.push(n.length), this._lineOffsets = e
      }
      return this._lineOffsets
    }
    positionAt(e) {
      e = Math.max(Math.min(e, this._content.length), 0);
      let n = this.getLineOffsets(),
        i = 0,
        r = n.length;
      if (r === 0) return se.create(0, e);
      for (; i < r;) {
        let a = Math.floor((i + r) / 2);
        n[a] > e ? r = a : i = a + 1
      }
      let s = i - 1;
      return se.create(s, e - n[s])
    }
    offsetAt(e) {
      let n = this.getLineOffsets();
      if (e.line >= n.length) return this._content.length;
      if (e.line < 0) return 0;
      let i = n[e.line],
        r = e.line + 1 < n.length ? n[e.line + 1] : this._content.length;
      return Math.max(Math.min(i + e.character, r), i)
    }
    get lineCount() {
      return this.getLineOffsets().length
    }
  };
  var R;
  (function(t) {
    const e = Object.prototype.toString;

    function n(f) {
      return typeof f < "u"
    }
    t.defined = n;

    function i(f) {
      return typeof f > "u"
    }
    t.undefined = i;

    function r(f) {
      return f === !0 || f === !1
    }
    t.boolean = r;

    function s(f) {
      return e.call(f) === "[object String]"
    }
    t.string = s;

    function a(f) {
      return e.call(f) === "[object Number]"
    }
    t.number = a;

    function l(f, w, p) {
      return e.call(f) === "[object Number]" && w <= f && f <= p
    }
    t.numberRange = l;

    function o(f) {
      return e.call(f) === "[object Number]" && -2147483648 <= f && f <= 2147483647
    }
    t.integer = o;

    function u(f) {
      return e.call(f) === "[object Number]" && 0 <= f && f <= 2147483647
    }
    t.uinteger = u;

    function c(f) {
      return e.call(f) === "[object Function]"
    }
    t.func = c;

    function d(f) {
      return f !== null && typeof f == "object"
    }
    t.objectLiteral = d;

    function m(f, w) {
      return Array.isArray(f) && f.every(w)
    }
    t.typedArray = m
  })(R || (R = {}));
  class Ft {
    constructor(e, n, i, r) {
      this._uri = e, this._languageId = n, this._version = i, this._content = r, this._lineOffsets = void 0
    }
    get uri() {
      return this._uri
    }
    get languageId() {
      return this._languageId
    }
    get version() {
      return this._version
    }
    getText(e) {
      if (e) {
        const n = this.offsetAt(e.start),
          i = this.offsetAt(e.end);
        return this._content.substring(n, i)
      }
      return this._content
    }
    update(e, n) {
      for (let i of e)
        if (Ft.isIncremental(i)) {
          const r = Ba(i.range),
            s = this.offsetAt(r.start),
            a = this.offsetAt(r.end);
          this._content = this._content.substring(0, s) + i.text + this._content.substring(a, this._content.length);
          const l = Math.max(r.start.line, 0),
            o = Math.max(r.end.line, 0);
          let u = this._lineOffsets;
          const c = Fa(i.text, !1, s);
          if (o - l === c.length)
            for (let m = 0, f = c.length; m < f; m++) u[m + l + 1] = c[m];
          else c.length < 1e4 ? u.splice(l + 1, o - l, ...c) : this._lineOffsets = u = u.slice(0, l + 1).concat(c, u.slice(o + 1));
          const d = i.text.length - (a - s);
          if (d !== 0)
            for (let m = l + 1 + c.length, f = u.length; m < f; m++) u[m] = u[m] + d
        } else if (Ft.isFull(i)) this._content = i.text, this._lineOffsets = void 0;
      else throw new Error("Unknown change event received");
      this._version = n
    }
    getLineOffsets() {
      return this._lineOffsets === void 0 && (this._lineOffsets = Fa(this._content, !0)), this._lineOffsets
    }
    positionAt(e) {
      e = Math.max(Math.min(e, this._content.length), 0);
      let n = this.getLineOffsets(),
        i = 0,
        r = n.length;
      if (r === 0) return {
        line: 0,
        character: e
      };
      for (; i < r;) {
        let a = Math.floor((i + r) / 2);
        n[a] > e ? r = a : i = a + 1
      }
      let s = i - 1;
      return {
        line: s,
        character: e - n[s]
      }
    }
    offsetAt(e) {
      let n = this.getLineOffsets();
      if (e.line >= n.length) return this._content.length;
      if (e.line < 0) return 0;
      let i = n[e.line],
        r = e.line + 1 < n.length ? n[e.line + 1] : this._content.length;
      return Math.max(Math.min(i + e.character, r), i)
    }
    get lineCount() {
      return this.getLineOffsets().length
    }
    static isIncremental(e) {
      let n = e;
      return n != null && typeof n.text == "string" && n.range !== void 0 && (n.rangeLength === void 0 || typeof n.rangeLength == "number")
    }
    static isFull(e) {
      let n = e;
      return n != null && typeof n.text == "string" && n.range === void 0 && n.rangeLength === void 0
    }
  }
  var Ei;
  (function(t) {
    function e(r, s, a, l) {
      return new Ft(r, s, a, l)
    }
    t.create = e;

    function n(r, s, a) {
      if (r instanceof Ft) return r.update(s, a), r;
      throw new Error("TextDocument.update: document must be created by TextDocument.create")
    }
    t.update = n;

    function i(r, s) {
      let a = r.getText(),
        l = Ri(s.map(ec), (c, d) => {
          let m = c.range.start.line - d.range.start.line;
          return m === 0 ? c.range.start.character - d.range.start.character : m
        }),
        o = 0;
      const u = [];
      for (const c of l) {
        let d = r.offsetAt(c.range.start);
        if (d < o) throw new Error("Overlapping edit");
        d > o && u.push(a.substring(o, d)), c.newText.length && u.push(c.newText), o = r.offsetAt(c.range.end)
      }
      return u.push(a.substr(o)), u.join("")
    }
    t.applyEdits = i
  })(Ei || (Ei = {}));

  function Ri(t, e) {
    if (t.length <= 1) return t;
    const n = t.length / 2 | 0,
      i = t.slice(0, n),
      r = t.slice(n);
    Ri(i, e), Ri(r, e);
    let s = 0,
      a = 0,
      l = 0;
    for (; s < i.length && a < r.length;) e(i[s], r[a]) <= 0 ? t[l++] = i[s++] : t[l++] = r[a++];
    for (; s < i.length;) t[l++] = i[s++];
    for (; a < r.length;) t[l++] = r[a++];
    return t
  }

  function Fa(t, e, n = 0) {
    const i = e ? [n] : [];
    for (let r = 0; r < t.length; r++) {
      let s = t.charCodeAt(r);
      (s === 13 || s === 10) && (s === 13 && r + 1 < t.length && t.charCodeAt(r + 1) === 10 && r++, i.push(n + r + 1))
    }
    return i
  }

  function Ba(t) {
    const e = t.start,
      n = t.end;
    return e.line > n.line || e.line === n.line && e.character > n.character ? {
      start: n,
      end: e
    } : t
  }

  function ec(t) {
    const e = Ba(t.range);
    return e !== t.range ? {
      newText: t.newText,
      range: e
    } : t
  }
  var z;
  (function(t) {
    t[t.StartCommentTag = 0] = "StartCommentTag", t[t.Comment = 1] = "Comment", t[t.EndCommentTag = 2] = "EndCommentTag", t[t.StartTagOpen = 3] = "StartTagOpen", t[t.StartTagClose = 4] = "StartTagClose", t[t.StartTagSelfClose = 5] = "StartTagSelfClose", t[t.StartTag = 6] = "StartTag", t[t.EndTagOpen = 7] = "EndTagOpen", t[t.EndTagClose = 8] = "EndTagClose", t[t.EndTag = 9] = "EndTag", t[t.DelimiterAssign = 10] = "DelimiterAssign", t[t.AttributeName = 11] = "AttributeName", t[t.AttributeValue = 12] = "AttributeValue", t[t.StartDoctypeTag = 13] = "StartDoctypeTag", t[t.Doctype = 14] = "Doctype", t[t.EndDoctypeTag = 15] = "EndDoctypeTag", t[t.Content = 16] = "Content", t[t.Whitespace = 17] = "Whitespace", t[t.Unknown = 18] = "Unknown", t[t.Script = 19] = "Script", t[t.Styles = 20] = "Styles", t[t.EOS = 21] = "EOS"
  })(z || (z = {}));
  var V;
  (function(t) {
    t[t.WithinContent = 0] = "WithinContent", t[t.AfterOpeningStartTag = 1] = "AfterOpeningStartTag", t[t.AfterOpeningEndTag = 2] = "AfterOpeningEndTag", t[t.WithinDoctype = 3] = "WithinDoctype", t[t.WithinTag = 4] = "WithinTag", t[t.WithinEndTag = 5] = "WithinEndTag", t[t.WithinComment = 6] = "WithinComment", t[t.WithinScriptContent = 7] = "WithinScriptContent", t[t.WithinStyleContent = 8] = "WithinStyleContent", t[t.AfterAttributeName = 9] = "AfterAttributeName", t[t.BeforeAttributeValue = 10] = "BeforeAttributeValue"
  })(V || (V = {}));
  var qa;
  (function(t) {
    t.LATEST = {
      textDocument: {
        completion: {
          completionItem: {
            documentationFormat: [qe.Markdown, qe.PlainText]
          }
        },
        hover: {
          contentFormat: [qe.Markdown, qe.PlainText]
        }
      }
    }
  })(qa || (qa = {}));
  var Di;
  (function(t) {
    t[t.Unknown = 0] = "Unknown", t[t.File = 1] = "File", t[t.Directory = 2] = "Directory", t[t.SymbolicLink = 64] = "SymbolicLink"
  })(Di || (Di = {}));
  class tc {
    constructor(e, n) {
      this.source = e, this.len = e.length, this.position = n
    }
    eos() {
      return this.len <= this.position
    }
    getSource() {
      return this.source
    }
    pos() {
      return this.position
    }
    goBackTo(e) {
      this.position = e
    }
    goBack(e) {
      this.position -= e
    }
    advance(e) {
      this.position += e
    }
    goToEnd() {
      this.position = this.source.length
    }
    nextChar() {
      return this.source.charCodeAt(this.position++) || 0
    }
    peekChar(e = 0) {
      return this.source.charCodeAt(this.position + e) || 0
    }
    advanceIfChar(e) {
      return e === this.source.charCodeAt(this.position) ? (this.position++, !0) : !1
    }
    advanceIfChars(e) {
      let n;
      if (this.position + e.length > this.source.length) return !1;
      for (n = 0; n < e.length; n++)
        if (this.source.charCodeAt(this.position + n) !== e[n]) return !1;
      return this.advance(n), !0
    }
    advanceIfRegExp(e) {
      const i = this.source.substr(this.position).match(e);
      return i ? (this.position = this.position + i.index + i[0].length, i[0]) : ""
    }
    advanceUntilRegExp(e) {
      const i = this.source.substr(this.position).match(e);
      return i ? (this.position = this.position + i.index, i[0]) : (this.goToEnd(), "")
    }
    advanceUntilChar(e) {
      for (; this.position < this.source.length;) {
        if (this.source.charCodeAt(this.position) === e) return !0;
        this.advance(1)
      }
      return !1
    }
    advanceUntilChars(e) {
      for (; this.position + e.length <= this.source.length;) {
        let n = 0;
        for (; n < e.length && this.source.charCodeAt(this.position + n) === e[n]; n++);
        if (n === e.length) return !0;
        this.advance(1)
      }
      return this.goToEnd(), !1
    }
    skipWhitespace() {
      return this.advanceWhileChar(n => n === lc || n === uc || n === sc || n === oc || n === ac) > 0
    }
    advanceWhileChar(e) {
      const n = this.position;
      for (; this.position < this.len && e(this.source.charCodeAt(this.position));) this.position++;
      return this.position - n
    }
  }
  const Oa = 33,
    Tt = 45,
    _n = 60,
    Ne = 62,
    Mi = 47,
    nc = 61,
    ic = 34,
    rc = 39,
    sc = 10,
    ac = 13,
    oc = 12,
    lc = 32,
    uc = 9,
    cc = {
      "text/x-handlebars-template": !0,
      "text/html": !0
    };

  function be(t, e = 0, n = V.WithinContent, i = !1) {
    const r = new tc(t, e);
    let s = n,
      a = 0,
      l = z.Unknown,
      o, u, c, d, m;

    function f() {
      return r.advanceIfRegExp(/^[_:\w][_:\w-.\d]*/).toLowerCase()
    }

    function w() {
      return r.advanceIfRegExp(/^[^\s"'></=\x00-\x0F\x7F\x80-\x9F]*/).toLowerCase()
    }

    function p(y, L, I) {
      return l = L, a = y, o = I, L
    }

    function x() {
      const y = r.pos(),
        L = s,
        I = T();
      return I !== z.EOS && y === r.pos() && !(i && (I === z.StartTagClose || I === z.EndTagClose)) ? (console.warn("Scanner.scan has not advanced at offset " + y + ", state before: " + L + " after: " + s), r.advance(1), p(y, z.Unknown)) : I
    }

    function T() {
      const y = r.pos();
      if (r.eos()) return p(y, z.EOS);
      let L;
      switch (s) {
        case V.WithinComment:
          return r.advanceIfChars([Tt, Tt, Ne]) ? (s = V.WithinContent, p(y, z.EndCommentTag)) : (r.advanceUntilChars([Tt, Tt, Ne]), p(y, z.Comment));
        case V.WithinDoctype:
          return r.advanceIfChar(Ne) ? (s = V.WithinContent, p(y, z.EndDoctypeTag)) : (r.advanceUntilChar(Ne), p(y, z.Doctype));
        case V.WithinContent:
          if (r.advanceIfChar(_n)) {
            if (!r.eos() && r.peekChar() === Oa) {
              if (r.advanceIfChars([Oa, Tt, Tt])) return s = V.WithinComment, p(y, z.StartCommentTag);
              if (r.advanceIfRegExp(/^!doctype/i)) return s = V.WithinDoctype, p(y, z.StartDoctypeTag)
            }
            return r.advanceIfChar(Mi) ? (s = V.AfterOpeningEndTag, p(y, z.EndTagOpen)) : (s = V.AfterOpeningStartTag, p(y, z.StartTagOpen))
          }
          return r.advanceUntilChar(_n), p(y, z.Content);
        case V.AfterOpeningEndTag:
          return f().length > 0 ? (s = V.WithinEndTag, p(y, z.EndTag)) : r.skipWhitespace() ? p(y, z.Whitespace, Ae("Tag name must directly follow the open bracket.")) : (s = V.WithinEndTag, r.advanceUntilChar(Ne), y < r.pos() ? p(y, z.Unknown, Ae("End tag name expected.")) : T());
        case V.WithinEndTag:
          if (r.skipWhitespace()) return p(y, z.Whitespace);
          if (r.advanceIfChar(Ne)) return s = V.WithinContent, p(y, z.EndTagClose);
          if (i && r.peekChar() === _n) return s = V.WithinContent, p(y, z.EndTagClose, Ae("Closing bracket missing."));
          L = Ae("Closing bracket expected.");
          break;
        case V.AfterOpeningStartTag:
          return c = f(), m = void 0, d = void 0, c.length > 0 ? (u = !1, s = V.WithinTag, p(y, z.StartTag)) : r.skipWhitespace() ? p(y, z.Whitespace, Ae("Tag name must directly follow the open bracket.")) : (s = V.WithinTag, r.advanceUntilChar(Ne), y < r.pos() ? p(y, z.Unknown, Ae("Start tag name expected.")) : T());
        case V.WithinTag:
          return r.skipWhitespace() ? (u = !0, p(y, z.Whitespace)) : u && (d = w(), d.length > 0) ? (s = V.AfterAttributeName, u = !1, p(y, z.AttributeName)) : r.advanceIfChars([Mi, Ne]) ? (s = V.WithinContent, p(y, z.StartTagSelfClose)) : r.advanceIfChar(Ne) ? (c === "script" ? m && cc[m] ? s = V.WithinContent : s = V.WithinScriptContent : c === "style" ? s = V.WithinStyleContent : s = V.WithinContent, p(y, z.StartTagClose)) : i && r.peekChar() === _n ? (s = V.WithinContent, p(y, z.StartTagClose, Ae("Closing bracket missing."))) : (r.advance(1), p(y, z.Unknown, Ae("Unexpected character in tag.")));
        case V.AfterAttributeName:
          return r.skipWhitespace() ? (u = !0, p(y, z.Whitespace)) : r.advanceIfChar(nc) ? (s = V.BeforeAttributeValue, p(y, z.DelimiterAssign)) : (s = V.WithinTag, T());
        case V.BeforeAttributeValue:
          if (r.skipWhitespace()) return p(y, z.Whitespace);
          let H = r.advanceIfRegExp(/^[^\s"'`=<>]+/);
          if (H.length > 0 && (r.peekChar() === Ne && r.peekChar(-1) === Mi && (r.goBack(1), H = H.substring(0, H.length - 1)), d === "type" && (m = H), H.length > 0)) return s = V.WithinTag, u = !1, p(y, z.AttributeValue);
          const P = r.peekChar();
          return P === rc || P === ic ? (r.advance(1), r.advanceUntilChar(P) && r.advance(1), d === "type" && (m = r.getSource().substring(y + 1, r.pos() - 1)), s = V.WithinTag, u = !1, p(y, z.AttributeValue)) : (s = V.WithinTag, u = !1, T());
        case V.WithinScriptContent:
          let b = 1;
          for (; !r.eos();) {
            const g = r.advanceIfRegExp(/<!--|-->|<\/?script\s*\/?>?/i);
            if (g.length === 0) return r.goToEnd(), p(y, z.Script);
            if (g === "<!--") b === 1 && (b = 2);
            else if (g === "-->") b = 1;
            else if (g[1] !== "/") b === 2 && (b = 3);
            else if (b === 3) b = 2;
            else {
              r.goBack(g.length);
              break
            }
          }
          return s = V.WithinContent, y < r.pos() ? p(y, z.Script) : T();
        case V.WithinStyleContent:
          return r.advanceUntilRegExp(/<\/style/i), s = V.WithinContent, y < r.pos() ? p(y, z.Styles) : T()
      }
      return r.advance(1), s = V.WithinContent, p(y, z.Unknown, L)
    }
    return {
      scan: x,
      getTokenType: () => l,
      getTokenOffset: () => a,
      getTokenLength: () => r.pos() - a,
      getTokenEnd: () => r.pos(),
      getTokenText: () => r.getSource().substring(a, r.pos()),
      getScannerState: () => s,
      getTokenError: () => o
    }
  }

  function Va(t, e) {
    let n = 0,
      i = t.length;
    if (i === 0) return 0;
    for (; n < i;) {
      let r = Math.floor((n + i) / 2);
      e(t[r]) ? i = r : n = r + 1
    }
    return n
  }

  function hc(t, e, n) {
    let i = 0,
      r = t.length - 1;
    for (; i <= r;) {
      const s = (i + r) / 2 | 0,
        a = n(t[s], e);
      if (a < 0) i = s + 1;
      else if (a > 0) r = s - 1;
      else return s
    }
    return -(i + 1)
  }
  class ja {
    get attributeNames() {
      return this.attributes ? Object.keys(this.attributes) : []
    }
    constructor(e, n, i, r) {
      this.start = e, this.end = n, this.children = i, this.parent = r, this.closed = !1
    }
    isSameTag(e) {
      return this.tag === void 0 ? e === void 0 : e !== void 0 && this.tag.length === e.length && this.tag.toLowerCase() === e
    }
    get firstChild() {
      return this.children[0]
    }
    get lastChild() {
      return this.children.length ? this.children[this.children.length - 1] : void 0
    }
    findNodeBefore(e) {
      const n = Va(this.children, i => e <= i.start) - 1;
      if (n >= 0) {
        const i = this.children[n];
        if (e > i.start) {
          if (e < i.end) return i.findNodeBefore(e);
          const r = i.lastChild;
          return r && r.end === i.end ? i.findNodeBefore(e) : i
        }
      }
      return this
    }
    findNodeAt(e) {
      const n = Va(this.children, i => e <= i.start) - 1;
      if (n >= 0) {
        const i = this.children[n];
        if (e > i.start && e <= i.end) return i.findNodeAt(e)
      }
      return this
    }
  }
  class dc {
    constructor(e) {
      this.dataManager = e
    }
    parseDocument(e) {
      return this.parse(e.getText(), this.dataManager.getVoidElements(e.languageId))
    }
    parse(e, n) {
      const i = be(e, void 0, void 0, !0),
        r = new ja(0, e.length, [], void 0);
      let s = r,
        a = -1,
        l, o = null,
        u = i.scan();
      for (; u !== z.EOS;) {
        switch (u) {
          case z.StartTagOpen:
            const c = new ja(i.getTokenOffset(), e.length, [], s);
            s.children.push(c), s = c;
            break;
          case z.StartTag:
            s.tag = i.getTokenText();
            break;
          case z.StartTagClose:
            s.parent && (s.end = i.getTokenEnd(), i.getTokenLength() ? (s.startTagEnd = i.getTokenEnd(), s.tag && this.dataManager.isVoidElement(s.tag, n) && (s.closed = !0, s = s.parent)) : s = s.parent);
            break;
          case z.StartTagSelfClose:
            s.parent && (s.closed = !0, s.end = i.getTokenEnd(), s.startTagEnd = i.getTokenEnd(), s = s.parent);
            break;
          case z.EndTagOpen:
            a = i.getTokenOffset(), l = void 0;
            break;
          case z.EndTag:
            l = i.getTokenText().toLowerCase();
            break;
          case z.EndTagClose:
            let d = s;
            for (; !d.isSameTag(l) && d.parent;) d = d.parent;
            if (d.parent) {
              for (; s !== d;) s.end = a, s.closed = !1, s = s.parent;
              s.closed = !0, s.endTagStart = a, s.end = i.getTokenEnd(), s = s.parent
            }
            break;
          case z.AttributeName: {
            o = i.getTokenText();
            let m = s.attributes;
            m || (s.attributes = m = {}), m[o] = null;
            break
          }
          case z.AttributeValue: {
            const m = i.getTokenText(),
              f = s.attributes;
            f && o && (f[o] = m, o = null);
            break
          }
        }
        u = i.scan()
      }
      for (; s.parent;) s.end = e.length, s.closed = !1, s = s.parent;
      return {
        roots: r.children,
        findNodeBefore: r.findNodeBefore.bind(r),
        findNodeAt: r.findNodeAt.bind(r)
      }
    }
  }
  const Bt = {
    "Aacute;": "Á",
    Aacute: "Á",
    "aacute;": "á",
    aacute: "á",
    "Abreve;": "Ă",
    "abreve;": "ă",
    "ac;": "∾",
    "acd;": "∿",
    "acE;": "∾̳",
    "Acirc;": "Â",
    Acirc: "Â",
    "acirc;": "â",
    acirc: "â",
    "acute;": "´",
    acute: "´",
    "Acy;": "А",
    "acy;": "а",
    "AElig;": "Æ",
    AElig: "Æ",
    "aelig;": "æ",
    aelig: "æ",
    "af;": "⁡",
    "Afr;": "𝔄",
    "afr;": "𝔞",
    "Agrave;": "À",
    Agrave: "À",
    "agrave;": "à",
    agrave: "à",
    "alefsym;": "ℵ",
    "aleph;": "ℵ",
    "Alpha;": "Α",
    "alpha;": "α",
    "Amacr;": "Ā",
    "amacr;": "ā",
    "amalg;": "⨿",
    "AMP;": "&",
    AMP: "&",
    "amp;": "&",
    amp: "&",
    "And;": "⩓",
    "and;": "∧",
    "andand;": "⩕",
    "andd;": "⩜",
    "andslope;": "⩘",
    "andv;": "⩚",
    "ang;": "∠",
    "ange;": "⦤",
    "angle;": "∠",
    "angmsd;": "∡",
    "angmsdaa;": "⦨",
    "angmsdab;": "⦩",
    "angmsdac;": "⦪",
    "angmsdad;": "⦫",
    "angmsdae;": "⦬",
    "angmsdaf;": "⦭",
    "angmsdag;": "⦮",
    "angmsdah;": "⦯",
    "angrt;": "∟",
    "angrtvb;": "⊾",
    "angrtvbd;": "⦝",
    "angsph;": "∢",
    "angst;": "Å",
    "angzarr;": "⍼",
    "Aogon;": "Ą",
    "aogon;": "ą",
    "Aopf;": "𝔸",
    "aopf;": "𝕒",
    "ap;": "≈",
    "apacir;": "⩯",
    "apE;": "⩰",
    "ape;": "≊",
    "apid;": "≋",
    "apos;": "'",
    "ApplyFunction;": "⁡",
    "approx;": "≈",
    "approxeq;": "≊",
    "Aring;": "Å",
    Aring: "Å",
    "aring;": "å",
    aring: "å",
    "Ascr;": "𝒜",
    "ascr;": "𝒶",
    "Assign;": "≔",
    "ast;": "*",
    "asymp;": "≈",
    "asympeq;": "≍",
    "Atilde;": "Ã",
    Atilde: "Ã",
    "atilde;": "ã",
    atilde: "ã",
    "Auml;": "Ä",
    Auml: "Ä",
    "auml;": "ä",
    auml: "ä",
    "awconint;": "∳",
    "awint;": "⨑",
    "backcong;": "≌",
    "backepsilon;": "϶",
    "backprime;": "‵",
    "backsim;": "∽",
    "backsimeq;": "⋍",
    "Backslash;": "∖",
    "Barv;": "⫧",
    "barvee;": "⊽",
    "Barwed;": "⌆",
    "barwed;": "⌅",
    "barwedge;": "⌅",
    "bbrk;": "⎵",
    "bbrktbrk;": "⎶",
    "bcong;": "≌",
    "Bcy;": "Б",
    "bcy;": "б",
    "bdquo;": "„",
    "becaus;": "∵",
    "Because;": "∵",
    "because;": "∵",
    "bemptyv;": "⦰",
    "bepsi;": "϶",
    "bernou;": "ℬ",
    "Bernoullis;": "ℬ",
    "Beta;": "Β",
    "beta;": "β",
    "beth;": "ℶ",
    "between;": "≬",
    "Bfr;": "𝔅",
    "bfr;": "𝔟",
    "bigcap;": "⋂",
    "bigcirc;": "◯",
    "bigcup;": "⋃",
    "bigodot;": "⨀",
    "bigoplus;": "⨁",
    "bigotimes;": "⨂",
    "bigsqcup;": "⨆",
    "bigstar;": "★",
    "bigtriangledown;": "▽",
    "bigtriangleup;": "△",
    "biguplus;": "⨄",
    "bigvee;": "⋁",
    "bigwedge;": "⋀",
    "bkarow;": "⤍",
    "blacklozenge;": "⧫",
    "blacksquare;": "▪",
    "blacktriangle;": "▴",
    "blacktriangledown;": "▾",
    "blacktriangleleft;": "◂",
    "blacktriangleright;": "▸",
    "blank;": "␣",
    "blk12;": "▒",
    "blk14;": "░",
    "blk34;": "▓",
    "block;": "█",
    "bne;": "=⃥",
    "bnequiv;": "≡⃥",
    "bNot;": "⫭",
    "bnot;": "⌐",
    "Bopf;": "𝔹",
    "bopf;": "𝕓",
    "bot;": "⊥",
    "bottom;": "⊥",
    "bowtie;": "⋈",
    "boxbox;": "⧉",
    "boxDL;": "╗",
    "boxDl;": "╖",
    "boxdL;": "╕",
    "boxdl;": "┐",
    "boxDR;": "╔",
    "boxDr;": "╓",
    "boxdR;": "╒",
    "boxdr;": "┌",
    "boxH;": "═",
    "boxh;": "─",
    "boxHD;": "╦",
    "boxHd;": "╤",
    "boxhD;": "╥",
    "boxhd;": "┬",
    "boxHU;": "╩",
    "boxHu;": "╧",
    "boxhU;": "╨",
    "boxhu;": "┴",
    "boxminus;": "⊟",
    "boxplus;": "⊞",
    "boxtimes;": "⊠",
    "boxUL;": "╝",
    "boxUl;": "╜",
    "boxuL;": "╛",
    "boxul;": "┘",
    "boxUR;": "╚",
    "boxUr;": "╙",
    "boxuR;": "╘",
    "boxur;": "└",
    "boxV;": "║",
    "boxv;": "│",
    "boxVH;": "╬",
    "boxVh;": "╫",
    "boxvH;": "╪",
    "boxvh;": "┼",
    "boxVL;": "╣",
    "boxVl;": "╢",
    "boxvL;": "╡",
    "boxvl;": "┤",
    "boxVR;": "╠",
    "boxVr;": "╟",
    "boxvR;": "╞",
    "boxvr;": "├",
    "bprime;": "‵",
    "Breve;": "˘",
    "breve;": "˘",
    "brvbar;": "¦",
    brvbar: "¦",
    "Bscr;": "ℬ",
    "bscr;": "𝒷",
    "bsemi;": "⁏",
    "bsim;": "∽",
    "bsime;": "⋍",
    "bsol;": "\\",
    "bsolb;": "⧅",
    "bsolhsub;": "⟈",
    "bull;": "•",
    "bullet;": "•",
    "bump;": "≎",
    "bumpE;": "⪮",
    "bumpe;": "≏",
    "Bumpeq;": "≎",
    "bumpeq;": "≏",
    "Cacute;": "Ć",
    "cacute;": "ć",
    "Cap;": "⋒",
    "cap;": "∩",
    "capand;": "⩄",
    "capbrcup;": "⩉",
    "capcap;": "⩋",
    "capcup;": "⩇",
    "capdot;": "⩀",
    "CapitalDifferentialD;": "ⅅ",
    "caps;": "∩︀",
    "caret;": "⁁",
    "caron;": "ˇ",
    "Cayleys;": "ℭ",
    "ccaps;": "⩍",
    "Ccaron;": "Č",
    "ccaron;": "č",
    "Ccedil;": "Ç",
    Ccedil: "Ç",
    "ccedil;": "ç",
    ccedil: "ç",
    "Ccirc;": "Ĉ",
    "ccirc;": "ĉ",
    "Cconint;": "∰",
    "ccups;": "⩌",
    "ccupssm;": "⩐",
    "Cdot;": "Ċ",
    "cdot;": "ċ",
    "cedil;": "¸",
    cedil: "¸",
    "Cedilla;": "¸",
    "cemptyv;": "⦲",
    "cent;": "¢",
    cent: "¢",
    "CenterDot;": "·",
    "centerdot;": "·",
    "Cfr;": "ℭ",
    "cfr;": "𝔠",
    "CHcy;": "Ч",
    "chcy;": "ч",
    "check;": "✓",
    "checkmark;": "✓",
    "Chi;": "Χ",
    "chi;": "χ",
    "cir;": "○",
    "circ;": "ˆ",
    "circeq;": "≗",
    "circlearrowleft;": "↺",
    "circlearrowright;": "↻",
    "circledast;": "⊛",
    "circledcirc;": "⊚",
    "circleddash;": "⊝",
    "CircleDot;": "⊙",
    "circledR;": "®",
    "circledS;": "Ⓢ",
    "CircleMinus;": "⊖",
    "CirclePlus;": "⊕",
    "CircleTimes;": "⊗",
    "cirE;": "⧃",
    "cire;": "≗",
    "cirfnint;": "⨐",
    "cirmid;": "⫯",
    "cirscir;": "⧂",
    "ClockwiseContourIntegral;": "∲",
    "CloseCurlyDoubleQuote;": "”",
    "CloseCurlyQuote;": "’",
    "clubs;": "♣",
    "clubsuit;": "♣",
    "Colon;": "∷",
    "colon;": ":",
    "Colone;": "⩴",
    "colone;": "≔",
    "coloneq;": "≔",
    "comma;": ",",
    "commat;": "@",
    "comp;": "∁",
    "compfn;": "∘",
    "complement;": "∁",
    "complexes;": "ℂ",
    "cong;": "≅",
    "congdot;": "⩭",
    "Congruent;": "≡",
    "Conint;": "∯",
    "conint;": "∮",
    "ContourIntegral;": "∮",
    "Copf;": "ℂ",
    "copf;": "𝕔",
    "coprod;": "∐",
    "Coproduct;": "∐",
    "COPY;": "©",
    COPY: "©",
    "copy;": "©",
    copy: "©",
    "copysr;": "℗",
    "CounterClockwiseContourIntegral;": "∳",
    "crarr;": "↵",
    "Cross;": "⨯",
    "cross;": "✗",
    "Cscr;": "𝒞",
    "cscr;": "𝒸",
    "csub;": "⫏",
    "csube;": "⫑",
    "csup;": "⫐",
    "csupe;": "⫒",
    "ctdot;": "⋯",
    "cudarrl;": "⤸",
    "cudarrr;": "⤵",
    "cuepr;": "⋞",
    "cuesc;": "⋟",
    "cularr;": "↶",
    "cularrp;": "⤽",
    "Cup;": "⋓",
    "cup;": "∪",
    "cupbrcap;": "⩈",
    "CupCap;": "≍",
    "cupcap;": "⩆",
    "cupcup;": "⩊",
    "cupdot;": "⊍",
    "cupor;": "⩅",
    "cups;": "∪︀",
    "curarr;": "↷",
    "curarrm;": "⤼",
    "curlyeqprec;": "⋞",
    "curlyeqsucc;": "⋟",
    "curlyvee;": "⋎",
    "curlywedge;": "⋏",
    "curren;": "¤",
    curren: "¤",
    "curvearrowleft;": "↶",
    "curvearrowright;": "↷",
    "cuvee;": "⋎",
    "cuwed;": "⋏",
    "cwconint;": "∲",
    "cwint;": "∱",
    "cylcty;": "⌭",
    "Dagger;": "‡",
    "dagger;": "†",
    "daleth;": "ℸ",
    "Darr;": "↡",
    "dArr;": "⇓",
    "darr;": "↓",
    "dash;": "‐",
    "Dashv;": "⫤",
    "dashv;": "⊣",
    "dbkarow;": "⤏",
    "dblac;": "˝",
    "Dcaron;": "Ď",
    "dcaron;": "ď",
    "Dcy;": "Д",
    "dcy;": "д",
    "DD;": "ⅅ",
    "dd;": "ⅆ",
    "ddagger;": "‡",
    "ddarr;": "⇊",
    "DDotrahd;": "⤑",
    "ddotseq;": "⩷",
    "deg;": "°",
    deg: "°",
    "Del;": "∇",
    "Delta;": "Δ",
    "delta;": "δ",
    "demptyv;": "⦱",
    "dfisht;": "⥿",
    "Dfr;": "𝔇",
    "dfr;": "𝔡",
    "dHar;": "⥥",
    "dharl;": "⇃",
    "dharr;": "⇂",
    "DiacriticalAcute;": "´",
    "DiacriticalDot;": "˙",
    "DiacriticalDoubleAcute;": "˝",
    "DiacriticalGrave;": "`",
    "DiacriticalTilde;": "˜",
    "diam;": "⋄",
    "Diamond;": "⋄",
    "diamond;": "⋄",
    "diamondsuit;": "♦",
    "diams;": "♦",
    "die;": "¨",
    "DifferentialD;": "ⅆ",
    "digamma;": "ϝ",
    "disin;": "⋲",
    "div;": "÷",
    "divide;": "÷",
    divide: "÷",
    "divideontimes;": "⋇",
    "divonx;": "⋇",
    "DJcy;": "Ђ",
    "djcy;": "ђ",
    "dlcorn;": "⌞",
    "dlcrop;": "⌍",
    "dollar;": "$",
    "Dopf;": "𝔻",
    "dopf;": "𝕕",
    "Dot;": "¨",
    "dot;": "˙",
    "DotDot;": "⃜",
    "doteq;": "≐",
    "doteqdot;": "≑",
    "DotEqual;": "≐",
    "dotminus;": "∸",
    "dotplus;": "∔",
    "dotsquare;": "⊡",
    "doublebarwedge;": "⌆",
    "DoubleContourIntegral;": "∯",
    "DoubleDot;": "¨",
    "DoubleDownArrow;": "⇓",
    "DoubleLeftArrow;": "⇐",
    "DoubleLeftRightArrow;": "⇔",
    "DoubleLeftTee;": "⫤",
    "DoubleLongLeftArrow;": "⟸",
    "DoubleLongLeftRightArrow;": "⟺",
    "DoubleLongRightArrow;": "⟹",
    "DoubleRightArrow;": "⇒",
    "DoubleRightTee;": "⊨",
    "DoubleUpArrow;": "⇑",
    "DoubleUpDownArrow;": "⇕",
    "DoubleVerticalBar;": "∥",
    "DownArrow;": "↓",
    "Downarrow;": "⇓",
    "downarrow;": "↓",
    "DownArrowBar;": "⤓",
    "DownArrowUpArrow;": "⇵",
    "DownBreve;": "̑",
    "downdownarrows;": "⇊",
    "downharpoonleft;": "⇃",
    "downharpoonright;": "⇂",
    "DownLeftRightVector;": "⥐",
    "DownLeftTeeVector;": "⥞",
    "DownLeftVector;": "↽",
    "DownLeftVectorBar;": "⥖",
    "DownRightTeeVector;": "⥟",
    "DownRightVector;": "⇁",
    "DownRightVectorBar;": "⥗",
    "DownTee;": "⊤",
    "DownTeeArrow;": "↧",
    "drbkarow;": "⤐",
    "drcorn;": "⌟",
    "drcrop;": "⌌",
    "Dscr;": "𝒟",
    "dscr;": "𝒹",
    "DScy;": "Ѕ",
    "dscy;": "ѕ",
    "dsol;": "⧶",
    "Dstrok;": "Đ",
    "dstrok;": "đ",
    "dtdot;": "⋱",
    "dtri;": "▿",
    "dtrif;": "▾",
    "duarr;": "⇵",
    "duhar;": "⥯",
    "dwangle;": "⦦",
    "DZcy;": "Џ",
    "dzcy;": "џ",
    "dzigrarr;": "⟿",
    "Eacute;": "É",
    Eacute: "É",
    "eacute;": "é",
    eacute: "é",
    "easter;": "⩮",
    "Ecaron;": "Ě",
    "ecaron;": "ě",
    "ecir;": "≖",
    "Ecirc;": "Ê",
    Ecirc: "Ê",
    "ecirc;": "ê",
    ecirc: "ê",
    "ecolon;": "≕",
    "Ecy;": "Э",
    "ecy;": "э",
    "eDDot;": "⩷",
    "Edot;": "Ė",
    "eDot;": "≑",
    "edot;": "ė",
    "ee;": "ⅇ",
    "efDot;": "≒",
    "Efr;": "𝔈",
    "efr;": "𝔢",
    "eg;": "⪚",
    "Egrave;": "È",
    Egrave: "È",
    "egrave;": "è",
    egrave: "è",
    "egs;": "⪖",
    "egsdot;": "⪘",
    "el;": "⪙",
    "Element;": "∈",
    "elinters;": "⏧",
    "ell;": "ℓ",
    "els;": "⪕",
    "elsdot;": "⪗",
    "Emacr;": "Ē",
    "emacr;": "ē",
    "empty;": "∅",
    "emptyset;": "∅",
    "EmptySmallSquare;": "◻",
    "emptyv;": "∅",
    "EmptyVerySmallSquare;": "▫",
    "emsp;": " ",
    "emsp13;": " ",
    "emsp14;": " ",
    "ENG;": "Ŋ",
    "eng;": "ŋ",
    "ensp;": " ",
    "Eogon;": "Ę",
    "eogon;": "ę",
    "Eopf;": "𝔼",
    "eopf;": "𝕖",
    "epar;": "⋕",
    "eparsl;": "⧣",
    "eplus;": "⩱",
    "epsi;": "ε",
    "Epsilon;": "Ε",
    "epsilon;": "ε",
    "epsiv;": "ϵ",
    "eqcirc;": "≖",
    "eqcolon;": "≕",
    "eqsim;": "≂",
    "eqslantgtr;": "⪖",
    "eqslantless;": "⪕",
    "Equal;": "⩵",
    "equals;": "=",
    "EqualTilde;": "≂",
    "equest;": "≟",
    "Equilibrium;": "⇌",
    "equiv;": "≡",
    "equivDD;": "⩸",
    "eqvparsl;": "⧥",
    "erarr;": "⥱",
    "erDot;": "≓",
    "Escr;": "ℰ",
    "escr;": "ℯ",
    "esdot;": "≐",
    "Esim;": "⩳",
    "esim;": "≂",
    "Eta;": "Η",
    "eta;": "η",
    "ETH;": "Ð",
    ETH: "Ð",
    "eth;": "ð",
    eth: "ð",
    "Euml;": "Ë",
    Euml: "Ë",
    "euml;": "ë",
    euml: "ë",
    "euro;": "€",
    "excl;": "!",
    "exist;": "∃",
    "Exists;": "∃",
    "expectation;": "ℰ",
    "ExponentialE;": "ⅇ",
    "exponentiale;": "ⅇ",
    "fallingdotseq;": "≒",
    "Fcy;": "Ф",
    "fcy;": "ф",
    "female;": "♀",
    "ffilig;": "ﬃ",
    "fflig;": "ﬀ",
    "ffllig;": "ﬄ",
    "Ffr;": "𝔉",
    "ffr;": "𝔣",
    "filig;": "ﬁ",
    "FilledSmallSquare;": "◼",
    "FilledVerySmallSquare;": "▪",
    "fjlig;": "fj",
    "flat;": "♭",
    "fllig;": "ﬂ",
    "fltns;": "▱",
    "fnof;": "ƒ",
    "Fopf;": "𝔽",
    "fopf;": "𝕗",
    "ForAll;": "∀",
    "forall;": "∀",
    "fork;": "⋔",
    "forkv;": "⫙",
    "Fouriertrf;": "ℱ",
    "fpartint;": "⨍",
    "frac12;": "½",
    frac12: "½",
    "frac13;": "⅓",
    "frac14;": "¼",
    frac14: "¼",
    "frac15;": "⅕",
    "frac16;": "⅙",
    "frac18;": "⅛",
    "frac23;": "⅔",
    "frac25;": "⅖",
    "frac34;": "¾",
    frac34: "¾",
    "frac35;": "⅗",
    "frac38;": "⅜",
    "frac45;": "⅘",
    "frac56;": "⅚",
    "frac58;": "⅝",
    "frac78;": "⅞",
    "frasl;": "⁄",
    "frown;": "⌢",
    "Fscr;": "ℱ",
    "fscr;": "𝒻",
    "gacute;": "ǵ",
    "Gamma;": "Γ",
    "gamma;": "γ",
    "Gammad;": "Ϝ",
    "gammad;": "ϝ",
    "gap;": "⪆",
    "Gbreve;": "Ğ",
    "gbreve;": "ğ",
    "Gcedil;": "Ģ",
    "Gcirc;": "Ĝ",
    "gcirc;": "ĝ",
    "Gcy;": "Г",
    "gcy;": "г",
    "Gdot;": "Ġ",
    "gdot;": "ġ",
    "gE;": "≧",
    "ge;": "≥",
    "gEl;": "⪌",
    "gel;": "⋛",
    "geq;": "≥",
    "geqq;": "≧",
    "geqslant;": "⩾",
    "ges;": "⩾",
    "gescc;": "⪩",
    "gesdot;": "⪀",
    "gesdoto;": "⪂",
    "gesdotol;": "⪄",
    "gesl;": "⋛︀",
    "gesles;": "⪔",
    "Gfr;": "𝔊",
    "gfr;": "𝔤",
    "Gg;": "⋙",
    "gg;": "≫",
    "ggg;": "⋙",
    "gimel;": "ℷ",
    "GJcy;": "Ѓ",
    "gjcy;": "ѓ",
    "gl;": "≷",
    "gla;": "⪥",
    "glE;": "⪒",
    "glj;": "⪤",
    "gnap;": "⪊",
    "gnapprox;": "⪊",
    "gnE;": "≩",
    "gne;": "⪈",
    "gneq;": "⪈",
    "gneqq;": "≩",
    "gnsim;": "⋧",
    "Gopf;": "𝔾",
    "gopf;": "𝕘",
    "grave;": "`",
    "GreaterEqual;": "≥",
    "GreaterEqualLess;": "⋛",
    "GreaterFullEqual;": "≧",
    "GreaterGreater;": "⪢",
    "GreaterLess;": "≷",
    "GreaterSlantEqual;": "⩾",
    "GreaterTilde;": "≳",
    "Gscr;": "𝒢",
    "gscr;": "ℊ",
    "gsim;": "≳",
    "gsime;": "⪎",
    "gsiml;": "⪐",
    "GT;": ">",
    GT: ">",
    "Gt;": "≫",
    "gt;": ">",
    gt: ">",
    "gtcc;": "⪧",
    "gtcir;": "⩺",
    "gtdot;": "⋗",
    "gtlPar;": "⦕",
    "gtquest;": "⩼",
    "gtrapprox;": "⪆",
    "gtrarr;": "⥸",
    "gtrdot;": "⋗",
    "gtreqless;": "⋛",
    "gtreqqless;": "⪌",
    "gtrless;": "≷",
    "gtrsim;": "≳",
    "gvertneqq;": "≩︀",
    "gvnE;": "≩︀",
    "Hacek;": "ˇ",
    "hairsp;": " ",
    "half;": "½",
    "hamilt;": "ℋ",
    "HARDcy;": "Ъ",
    "hardcy;": "ъ",
    "hArr;": "⇔",
    "harr;": "↔",
    "harrcir;": "⥈",
    "harrw;": "↭",
    "Hat;": "^",
    "hbar;": "ℏ",
    "Hcirc;": "Ĥ",
    "hcirc;": "ĥ",
    "hearts;": "♥",
    "heartsuit;": "♥",
    "hellip;": "…",
    "hercon;": "⊹",
    "Hfr;": "ℌ",
    "hfr;": "𝔥",
    "HilbertSpace;": "ℋ",
    "hksearow;": "⤥",
    "hkswarow;": "⤦",
    "hoarr;": "⇿",
    "homtht;": "∻",
    "hookleftarrow;": "↩",
    "hookrightarrow;": "↪",
    "Hopf;": "ℍ",
    "hopf;": "𝕙",
    "horbar;": "―",
    "HorizontalLine;": "─",
    "Hscr;": "ℋ",
    "hscr;": "𝒽",
    "hslash;": "ℏ",
    "Hstrok;": "Ħ",
    "hstrok;": "ħ",
    "HumpDownHump;": "≎",
    "HumpEqual;": "≏",
    "hybull;": "⁃",
    "hyphen;": "‐",
    "Iacute;": "Í",
    Iacute: "Í",
    "iacute;": "í",
    iacute: "í",
    "ic;": "⁣",
    "Icirc;": "Î",
    Icirc: "Î",
    "icirc;": "î",
    icirc: "î",
    "Icy;": "И",
    "icy;": "и",
    "Idot;": "İ",
    "IEcy;": "Е",
    "iecy;": "е",
    "iexcl;": "¡",
    iexcl: "¡",
    "iff;": "⇔",
    "Ifr;": "ℑ",
    "ifr;": "𝔦",
    "Igrave;": "Ì",
    Igrave: "Ì",
    "igrave;": "ì",
    igrave: "ì",
    "ii;": "ⅈ",
    "iiiint;": "⨌",
    "iiint;": "∭",
    "iinfin;": "⧜",
    "iiota;": "℩",
    "IJlig;": "Ĳ",
    "ijlig;": "ĳ",
    "Im;": "ℑ",
    "Imacr;": "Ī",
    "imacr;": "ī",
    "image;": "ℑ",
    "ImaginaryI;": "ⅈ",
    "imagline;": "ℐ",
    "imagpart;": "ℑ",
    "imath;": "ı",
    "imof;": "⊷",
    "imped;": "Ƶ",
    "Implies;": "⇒",
    "in;": "∈",
    "incare;": "℅",
    "infin;": "∞",
    "infintie;": "⧝",
    "inodot;": "ı",
    "Int;": "∬",
    "int;": "∫",
    "intcal;": "⊺",
    "integers;": "ℤ",
    "Integral;": "∫",
    "intercal;": "⊺",
    "Intersection;": "⋂",
    "intlarhk;": "⨗",
    "intprod;": "⨼",
    "InvisibleComma;": "⁣",
    "InvisibleTimes;": "⁢",
    "IOcy;": "Ё",
    "iocy;": "ё",
    "Iogon;": "Į",
    "iogon;": "į",
    "Iopf;": "𝕀",
    "iopf;": "𝕚",
    "Iota;": "Ι",
    "iota;": "ι",
    "iprod;": "⨼",
    "iquest;": "¿",
    iquest: "¿",
    "Iscr;": "ℐ",
    "iscr;": "𝒾",
    "isin;": "∈",
    "isindot;": "⋵",
    "isinE;": "⋹",
    "isins;": "⋴",
    "isinsv;": "⋳",
    "isinv;": "∈",
    "it;": "⁢",
    "Itilde;": "Ĩ",
    "itilde;": "ĩ",
    "Iukcy;": "І",
    "iukcy;": "і",
    "Iuml;": "Ï",
    Iuml: "Ï",
    "iuml;": "ï",
    iuml: "ï",
    "Jcirc;": "Ĵ",
    "jcirc;": "ĵ",
    "Jcy;": "Й",
    "jcy;": "й",
    "Jfr;": "𝔍",
    "jfr;": "𝔧",
    "jmath;": "ȷ",
    "Jopf;": "𝕁",
    "jopf;": "𝕛",
    "Jscr;": "𝒥",
    "jscr;": "𝒿",
    "Jsercy;": "Ј",
    "jsercy;": "ј",
    "Jukcy;": "Є",
    "jukcy;": "є",
    "Kappa;": "Κ",
    "kappa;": "κ",
    "kappav;": "ϰ",
    "Kcedil;": "Ķ",
    "kcedil;": "ķ",
    "Kcy;": "К",
    "kcy;": "к",
    "Kfr;": "𝔎",
    "kfr;": "𝔨",
    "kgreen;": "ĸ",
    "KHcy;": "Х",
    "khcy;": "х",
    "KJcy;": "Ќ",
    "kjcy;": "ќ",
    "Kopf;": "𝕂",
    "kopf;": "𝕜",
    "Kscr;": "𝒦",
    "kscr;": "𝓀",
    "lAarr;": "⇚",
    "Lacute;": "Ĺ",
    "lacute;": "ĺ",
    "laemptyv;": "⦴",
    "lagran;": "ℒ",
    "Lambda;": "Λ",
    "lambda;": "λ",
    "Lang;": "⟪",
    "lang;": "⟨",
    "langd;": "⦑",
    "langle;": "⟨",
    "lap;": "⪅",
    "Laplacetrf;": "ℒ",
    "laquo;": "«",
    laquo: "«",
    "Larr;": "↞",
    "lArr;": "⇐",
    "larr;": "←",
    "larrb;": "⇤",
    "larrbfs;": "⤟",
    "larrfs;": "⤝",
    "larrhk;": "↩",
    "larrlp;": "↫",
    "larrpl;": "⤹",
    "larrsim;": "⥳",
    "larrtl;": "↢",
    "lat;": "⪫",
    "lAtail;": "⤛",
    "latail;": "⤙",
    "late;": "⪭",
    "lates;": "⪭︀",
    "lBarr;": "⤎",
    "lbarr;": "⤌",
    "lbbrk;": "❲",
    "lbrace;": "{",
    "lbrack;": "[",
    "lbrke;": "⦋",
    "lbrksld;": "⦏",
    "lbrkslu;": "⦍",
    "Lcaron;": "Ľ",
    "lcaron;": "ľ",
    "Lcedil;": "Ļ",
    "lcedil;": "ļ",
    "lceil;": "⌈",
    "lcub;": "{",
    "Lcy;": "Л",
    "lcy;": "л",
    "ldca;": "⤶",
    "ldquo;": "“",
    "ldquor;": "„",
    "ldrdhar;": "⥧",
    "ldrushar;": "⥋",
    "ldsh;": "↲",
    "lE;": "≦",
    "le;": "≤",
    "LeftAngleBracket;": "⟨",
    "LeftArrow;": "←",
    "Leftarrow;": "⇐",
    "leftarrow;": "←",
    "LeftArrowBar;": "⇤",
    "LeftArrowRightArrow;": "⇆",
    "leftarrowtail;": "↢",
    "LeftCeiling;": "⌈",
    "LeftDoubleBracket;": "⟦",
    "LeftDownTeeVector;": "⥡",
    "LeftDownVector;": "⇃",
    "LeftDownVectorBar;": "⥙",
    "LeftFloor;": "⌊",
    "leftharpoondown;": "↽",
    "leftharpoonup;": "↼",
    "leftleftarrows;": "⇇",
    "LeftRightArrow;": "↔",
    "Leftrightarrow;": "⇔",
    "leftrightarrow;": "↔",
    "leftrightarrows;": "⇆",
    "leftrightharpoons;": "⇋",
    "leftrightsquigarrow;": "↭",
    "LeftRightVector;": "⥎",
    "LeftTee;": "⊣",
    "LeftTeeArrow;": "↤",
    "LeftTeeVector;": "⥚",
    "leftthreetimes;": "⋋",
    "LeftTriangle;": "⊲",
    "LeftTriangleBar;": "⧏",
    "LeftTriangleEqual;": "⊴",
    "LeftUpDownVector;": "⥑",
    "LeftUpTeeVector;": "⥠",
    "LeftUpVector;": "↿",
    "LeftUpVectorBar;": "⥘",
    "LeftVector;": "↼",
    "LeftVectorBar;": "⥒",
    "lEg;": "⪋",
    "leg;": "⋚",
    "leq;": "≤",
    "leqq;": "≦",
    "leqslant;": "⩽",
    "les;": "⩽",
    "lescc;": "⪨",
    "lesdot;": "⩿",
    "lesdoto;": "⪁",
    "lesdotor;": "⪃",
    "lesg;": "⋚︀",
    "lesges;": "⪓",
    "lessapprox;": "⪅",
    "lessdot;": "⋖",
    "lesseqgtr;": "⋚",
    "lesseqqgtr;": "⪋",
    "LessEqualGreater;": "⋚",
    "LessFullEqual;": "≦",
    "LessGreater;": "≶",
    "lessgtr;": "≶",
    "LessLess;": "⪡",
    "lesssim;": "≲",
    "LessSlantEqual;": "⩽",
    "LessTilde;": "≲",
    "lfisht;": "⥼",
    "lfloor;": "⌊",
    "Lfr;": "𝔏",
    "lfr;": "𝔩",
    "lg;": "≶",
    "lgE;": "⪑",
    "lHar;": "⥢",
    "lhard;": "↽",
    "lharu;": "↼",
    "lharul;": "⥪",
    "lhblk;": "▄",
    "LJcy;": "Љ",
    "ljcy;": "љ",
    "Ll;": "⋘",
    "ll;": "≪",
    "llarr;": "⇇",
    "llcorner;": "⌞",
    "Lleftarrow;": "⇚",
    "llhard;": "⥫",
    "lltri;": "◺",
    "Lmidot;": "Ŀ",
    "lmidot;": "ŀ",
    "lmoust;": "⎰",
    "lmoustache;": "⎰",
    "lnap;": "⪉",
    "lnapprox;": "⪉",
    "lnE;": "≨",
    "lne;": "⪇",
    "lneq;": "⪇",
    "lneqq;": "≨",
    "lnsim;": "⋦",
    "loang;": "⟬",
    "loarr;": "⇽",
    "lobrk;": "⟦",
    "LongLeftArrow;": "⟵",
    "Longleftarrow;": "⟸",
    "longleftarrow;": "⟵",
    "LongLeftRightArrow;": "⟷",
    "Longleftrightarrow;": "⟺",
    "longleftrightarrow;": "⟷",
    "longmapsto;": "⟼",
    "LongRightArrow;": "⟶",
    "Longrightarrow;": "⟹",
    "longrightarrow;": "⟶",
    "looparrowleft;": "↫",
    "looparrowright;": "↬",
    "lopar;": "⦅",
    "Lopf;": "𝕃",
    "lopf;": "𝕝",
    "loplus;": "⨭",
    "lotimes;": "⨴",
    "lowast;": "∗",
    "lowbar;": "_",
    "LowerLeftArrow;": "↙",
    "LowerRightArrow;": "↘",
    "loz;": "◊",
    "lozenge;": "◊",
    "lozf;": "⧫",
    "lpar;": "(",
    "lparlt;": "⦓",
    "lrarr;": "⇆",
    "lrcorner;": "⌟",
    "lrhar;": "⇋",
    "lrhard;": "⥭",
    "lrm;": "‎",
    "lrtri;": "⊿",
    "lsaquo;": "‹",
    "Lscr;": "ℒ",
    "lscr;": "𝓁",
    "Lsh;": "↰",
    "lsh;": "↰",
    "lsim;": "≲",
    "lsime;": "⪍",
    "lsimg;": "⪏",
    "lsqb;": "[",
    "lsquo;": "‘",
    "lsquor;": "‚",
    "Lstrok;": "Ł",
    "lstrok;": "ł",
    "LT;": "<",
    LT: "<",
    "Lt;": "≪",
    "lt;": "<",
    lt: "<",
    "ltcc;": "⪦",
    "ltcir;": "⩹",
    "ltdot;": "⋖",
    "lthree;": "⋋",
    "ltimes;": "⋉",
    "ltlarr;": "⥶",
    "ltquest;": "⩻",
    "ltri;": "◃",
    "ltrie;": "⊴",
    "ltrif;": "◂",
    "ltrPar;": "⦖",
    "lurdshar;": "⥊",
    "luruhar;": "⥦",
    "lvertneqq;": "≨︀",
    "lvnE;": "≨︀",
    "macr;": "¯",
    macr: "¯",
    "male;": "♂",
    "malt;": "✠",
    "maltese;": "✠",
    "Map;": "⤅",
    "map;": "↦",
    "mapsto;": "↦",
    "mapstodown;": "↧",
    "mapstoleft;": "↤",
    "mapstoup;": "↥",
    "marker;": "▮",
    "mcomma;": "⨩",
    "Mcy;": "М",
    "mcy;": "м",
    "mdash;": "—",
    "mDDot;": "∺",
    "measuredangle;": "∡",
    "MediumSpace;": " ",
    "Mellintrf;": "ℳ",
    "Mfr;": "𝔐",
    "mfr;": "𝔪",
    "mho;": "℧",
    "micro;": "µ",
    micro: "µ",
    "mid;": "∣",
    "midast;": "*",
    "midcir;": "⫰",
    "middot;": "·",
    middot: "·",
    "minus;": "−",
    "minusb;": "⊟",
    "minusd;": "∸",
    "minusdu;": "⨪",
    "MinusPlus;": "∓",
    "mlcp;": "⫛",
    "mldr;": "…",
    "mnplus;": "∓",
    "models;": "⊧",
    "Mopf;": "𝕄",
    "mopf;": "𝕞",
    "mp;": "∓",
    "Mscr;": "ℳ",
    "mscr;": "𝓂",
    "mstpos;": "∾",
    "Mu;": "Μ",
    "mu;": "μ",
    "multimap;": "⊸",
    "mumap;": "⊸",
    "nabla;": "∇",
    "Nacute;": "Ń",
    "nacute;": "ń",
    "nang;": "∠⃒",
    "nap;": "≉",
    "napE;": "⩰̸",
    "napid;": "≋̸",
    "napos;": "ŉ",
    "napprox;": "≉",
    "natur;": "♮",
    "natural;": "♮",
    "naturals;": "ℕ",
    "nbsp;": " ",
    nbsp: " ",
    "nbump;": "≎̸",
    "nbumpe;": "≏̸",
    "ncap;": "⩃",
    "Ncaron;": "Ň",
    "ncaron;": "ň",
    "Ncedil;": "Ņ",
    "ncedil;": "ņ",
    "ncong;": "≇",
    "ncongdot;": "⩭̸",
    "ncup;": "⩂",
    "Ncy;": "Н",
    "ncy;": "н",
    "ndash;": "–",
    "ne;": "≠",
    "nearhk;": "⤤",
    "neArr;": "⇗",
    "nearr;": "↗",
    "nearrow;": "↗",
    "nedot;": "≐̸",
    "NegativeMediumSpace;": "​",
    "NegativeThickSpace;": "​",
    "NegativeThinSpace;": "​",
    "NegativeVeryThinSpace;": "​",
    "nequiv;": "≢",
    "nesear;": "⤨",
    "nesim;": "≂̸",
    "NestedGreaterGreater;": "≫",
    "NestedLessLess;": "≪",
    "NewLine;": `
`,
    "nexist;": "∄",
    "nexists;": "∄",
    "Nfr;": "𝔑",
    "nfr;": "𝔫",
    "ngE;": "≧̸",
    "nge;": "≱",
    "ngeq;": "≱",
    "ngeqq;": "≧̸",
    "ngeqslant;": "⩾̸",
    "nges;": "⩾̸",
    "nGg;": "⋙̸",
    "ngsim;": "≵",
    "nGt;": "≫⃒",
    "ngt;": "≯",
    "ngtr;": "≯",
    "nGtv;": "≫̸",
    "nhArr;": "⇎",
    "nharr;": "↮",
    "nhpar;": "⫲",
    "ni;": "∋",
    "nis;": "⋼",
    "nisd;": "⋺",
    "niv;": "∋",
    "NJcy;": "Њ",
    "njcy;": "њ",
    "nlArr;": "⇍",
    "nlarr;": "↚",
    "nldr;": "‥",
    "nlE;": "≦̸",
    "nle;": "≰",
    "nLeftarrow;": "⇍",
    "nleftarrow;": "↚",
    "nLeftrightarrow;": "⇎",
    "nleftrightarrow;": "↮",
    "nleq;": "≰",
    "nleqq;": "≦̸",
    "nleqslant;": "⩽̸",
    "nles;": "⩽̸",
    "nless;": "≮",
    "nLl;": "⋘̸",
    "nlsim;": "≴",
    "nLt;": "≪⃒",
    "nlt;": "≮",
    "nltri;": "⋪",
    "nltrie;": "⋬",
    "nLtv;": "≪̸",
    "nmid;": "∤",
    "NoBreak;": "⁠",
    "NonBreakingSpace;": " ",
    "Nopf;": "ℕ",
    "nopf;": "𝕟",
    "Not;": "⫬",
    "not;": "¬",
    not: "¬",
    "NotCongruent;": "≢",
    "NotCupCap;": "≭",
    "NotDoubleVerticalBar;": "∦",
    "NotElement;": "∉",
    "NotEqual;": "≠",
    "NotEqualTilde;": "≂̸",
    "NotExists;": "∄",
    "NotGreater;": "≯",
    "NotGreaterEqual;": "≱",
    "NotGreaterFullEqual;": "≧̸",
    "NotGreaterGreater;": "≫̸",
    "NotGreaterLess;": "≹",
    "NotGreaterSlantEqual;": "⩾̸",
    "NotGreaterTilde;": "≵",
    "NotHumpDownHump;": "≎̸",
    "NotHumpEqual;": "≏̸",
    "notin;": "∉",
    "notindot;": "⋵̸",
    "notinE;": "⋹̸",
    "notinva;": "∉",
    "notinvb;": "⋷",
    "notinvc;": "⋶",
    "NotLeftTriangle;": "⋪",
    "NotLeftTriangleBar;": "⧏̸",
    "NotLeftTriangleEqual;": "⋬",
    "NotLess;": "≮",
    "NotLessEqual;": "≰",
    "NotLessGreater;": "≸",
    "NotLessLess;": "≪̸",
    "NotLessSlantEqual;": "⩽̸",
    "NotLessTilde;": "≴",
    "NotNestedGreaterGreater;": "⪢̸",
    "NotNestedLessLess;": "⪡̸",
    "notni;": "∌",
    "notniva;": "∌",
    "notnivb;": "⋾",
    "notnivc;": "⋽",
    "NotPrecedes;": "⊀",
    "NotPrecedesEqual;": "⪯̸",
    "NotPrecedesSlantEqual;": "⋠",
    "NotReverseElement;": "∌",
    "NotRightTriangle;": "⋫",
    "NotRightTriangleBar;": "⧐̸",
    "NotRightTriangleEqual;": "⋭",
    "NotSquareSubset;": "⊏̸",
    "NotSquareSubsetEqual;": "⋢",
    "NotSquareSuperset;": "⊐̸",
    "NotSquareSupersetEqual;": "⋣",
    "NotSubset;": "⊂⃒",
    "NotSubsetEqual;": "⊈",
    "NotSucceeds;": "⊁",
    "NotSucceedsEqual;": "⪰̸",
    "NotSucceedsSlantEqual;": "⋡",
    "NotSucceedsTilde;": "≿̸",
    "NotSuperset;": "⊃⃒",
    "NotSupersetEqual;": "⊉",
    "NotTilde;": "≁",
    "NotTildeEqual;": "≄",
    "NotTildeFullEqual;": "≇",
    "NotTildeTilde;": "≉",
    "NotVerticalBar;": "∤",
    "npar;": "∦",
    "nparallel;": "∦",
    "nparsl;": "⫽⃥",
    "npart;": "∂̸",
    "npolint;": "⨔",
    "npr;": "⊀",
    "nprcue;": "⋠",
    "npre;": "⪯̸",
    "nprec;": "⊀",
    "npreceq;": "⪯̸",
    "nrArr;": "⇏",
    "nrarr;": "↛",
    "nrarrc;": "⤳̸",
    "nrarrw;": "↝̸",
    "nRightarrow;": "⇏",
    "nrightarrow;": "↛",
    "nrtri;": "⋫",
    "nrtrie;": "⋭",
    "nsc;": "⊁",
    "nsccue;": "⋡",
    "nsce;": "⪰̸",
    "Nscr;": "𝒩",
    "nscr;": "𝓃",
    "nshortmid;": "∤",
    "nshortparallel;": "∦",
    "nsim;": "≁",
    "nsime;": "≄",
    "nsimeq;": "≄",
    "nsmid;": "∤",
    "nspar;": "∦",
    "nsqsube;": "⋢",
    "nsqsupe;": "⋣",
    "nsub;": "⊄",
    "nsubE;": "⫅̸",
    "nsube;": "⊈",
    "nsubset;": "⊂⃒",
    "nsubseteq;": "⊈",
    "nsubseteqq;": "⫅̸",
    "nsucc;": "⊁",
    "nsucceq;": "⪰̸",
    "nsup;": "⊅",
    "nsupE;": "⫆̸",
    "nsupe;": "⊉",
    "nsupset;": "⊃⃒",
    "nsupseteq;": "⊉",
    "nsupseteqq;": "⫆̸",
    "ntgl;": "≹",
    "Ntilde;": "Ñ",
    Ntilde: "Ñ",
    "ntilde;": "ñ",
    ntilde: "ñ",
    "ntlg;": "≸",
    "ntriangleleft;": "⋪",
    "ntrianglelefteq;": "⋬",
    "ntriangleright;": "⋫",
    "ntrianglerighteq;": "⋭",
    "Nu;": "Ν",
    "nu;": "ν",
    "num;": "#",
    "numero;": "№",
    "numsp;": " ",
    "nvap;": "≍⃒",
    "nVDash;": "⊯",
    "nVdash;": "⊮",
    "nvDash;": "⊭",
    "nvdash;": "⊬",
    "nvge;": "≥⃒",
    "nvgt;": ">⃒",
    "nvHarr;": "⤄",
    "nvinfin;": "⧞",
    "nvlArr;": "⤂",
    "nvle;": "≤⃒",
    "nvlt;": "<⃒",
    "nvltrie;": "⊴⃒",
    "nvrArr;": "⤃",
    "nvrtrie;": "⊵⃒",
    "nvsim;": "∼⃒",
    "nwarhk;": "⤣",
    "nwArr;": "⇖",
    "nwarr;": "↖",
    "nwarrow;": "↖",
    "nwnear;": "⤧",
    "Oacute;": "Ó",
    Oacute: "Ó",
    "oacute;": "ó",
    oacute: "ó",
    "oast;": "⊛",
    "ocir;": "⊚",
    "Ocirc;": "Ô",
    Ocirc: "Ô",
    "ocirc;": "ô",
    ocirc: "ô",
    "Ocy;": "О",
    "ocy;": "о",
    "odash;": "⊝",
    "Odblac;": "Ő",
    "odblac;": "ő",
    "odiv;": "⨸",
    "odot;": "⊙",
    "odsold;": "⦼",
    "OElig;": "Œ",
    "oelig;": "œ",
    "ofcir;": "⦿",
    "Ofr;": "𝔒",
    "ofr;": "𝔬",
    "ogon;": "˛",
    "Ograve;": "Ò",
    Ograve: "Ò",
    "ograve;": "ò",
    ograve: "ò",
    "ogt;": "⧁",
    "ohbar;": "⦵",
    "ohm;": "Ω",
    "oint;": "∮",
    "olarr;": "↺",
    "olcir;": "⦾",
    "olcross;": "⦻",
    "oline;": "‾",
    "olt;": "⧀",
    "Omacr;": "Ō",
    "omacr;": "ō",
    "Omega;": "Ω",
    "omega;": "ω",
    "Omicron;": "Ο",
    "omicron;": "ο",
    "omid;": "⦶",
    "ominus;": "⊖",
    "Oopf;": "𝕆",
    "oopf;": "𝕠",
    "opar;": "⦷",
    "OpenCurlyDoubleQuote;": "“",
    "OpenCurlyQuote;": "‘",
    "operp;": "⦹",
    "oplus;": "⊕",
    "Or;": "⩔",
    "or;": "∨",
    "orarr;": "↻",
    "ord;": "⩝",
    "order;": "ℴ",
    "orderof;": "ℴ",
    "ordf;": "ª",
    ordf: "ª",
    "ordm;": "º",
    ordm: "º",
    "origof;": "⊶",
    "oror;": "⩖",
    "orslope;": "⩗",
    "orv;": "⩛",
    "oS;": "Ⓢ",
    "Oscr;": "𝒪",
    "oscr;": "ℴ",
    "Oslash;": "Ø",
    Oslash: "Ø",
    "oslash;": "ø",
    oslash: "ø",
    "osol;": "⊘",
    "Otilde;": "Õ",
    Otilde: "Õ",
    "otilde;": "õ",
    otilde: "õ",
    "Otimes;": "⨷",
    "otimes;": "⊗",
    "otimesas;": "⨶",
    "Ouml;": "Ö",
    Ouml: "Ö",
    "ouml;": "ö",
    ouml: "ö",
    "ovbar;": "⌽",
    "OverBar;": "‾",
    "OverBrace;": "⏞",
    "OverBracket;": "⎴",
    "OverParenthesis;": "⏜",
    "par;": "∥",
    "para;": "¶",
    para: "¶",
    "parallel;": "∥",
    "parsim;": "⫳",
    "parsl;": "⫽",
    "part;": "∂",
    "PartialD;": "∂",
    "Pcy;": "П",
    "pcy;": "п",
    "percnt;": "%",
    "period;": ".",
    "permil;": "‰",
    "perp;": "⊥",
    "pertenk;": "‱",
    "Pfr;": "𝔓",
    "pfr;": "𝔭",
    "Phi;": "Φ",
    "phi;": "φ",
    "phiv;": "ϕ",
    "phmmat;": "ℳ",
    "phone;": "☎",
    "Pi;": "Π",
    "pi;": "π",
    "pitchfork;": "⋔",
    "piv;": "ϖ",
    "planck;": "ℏ",
    "planckh;": "ℎ",
    "plankv;": "ℏ",
    "plus;": "+",
    "plusacir;": "⨣",
    "plusb;": "⊞",
    "pluscir;": "⨢",
    "plusdo;": "∔",
    "plusdu;": "⨥",
    "pluse;": "⩲",
    "PlusMinus;": "±",
    "plusmn;": "±",
    plusmn: "±",
    "plussim;": "⨦",
    "plustwo;": "⨧",
    "pm;": "±",
    "Poincareplane;": "ℌ",
    "pointint;": "⨕",
    "Popf;": "ℙ",
    "popf;": "𝕡",
    "pound;": "£",
    pound: "£",
    "Pr;": "⪻",
    "pr;": "≺",
    "prap;": "⪷",
    "prcue;": "≼",
    "prE;": "⪳",
    "pre;": "⪯",
    "prec;": "≺",
    "precapprox;": "⪷",
    "preccurlyeq;": "≼",
    "Precedes;": "≺",
    "PrecedesEqual;": "⪯",
    "PrecedesSlantEqual;": "≼",
    "PrecedesTilde;": "≾",
    "preceq;": "⪯",
    "precnapprox;": "⪹",
    "precneqq;": "⪵",
    "precnsim;": "⋨",
    "precsim;": "≾",
    "Prime;": "″",
    "prime;": "′",
    "primes;": "ℙ",
    "prnap;": "⪹",
    "prnE;": "⪵",
    "prnsim;": "⋨",
    "prod;": "∏",
    "Product;": "∏",
    "profalar;": "⌮",
    "profline;": "⌒",
    "profsurf;": "⌓",
    "prop;": "∝",
    "Proportion;": "∷",
    "Proportional;": "∝",
    "propto;": "∝",
    "prsim;": "≾",
    "prurel;": "⊰",
    "Pscr;": "𝒫",
    "pscr;": "𝓅",
    "Psi;": "Ψ",
    "psi;": "ψ",
    "puncsp;": " ",
    "Qfr;": "𝔔",
    "qfr;": "𝔮",
    "qint;": "⨌",
    "Qopf;": "ℚ",
    "qopf;": "𝕢",
    "qprime;": "⁗",
    "Qscr;": "𝒬",
    "qscr;": "𝓆",
    "quaternions;": "ℍ",
    "quatint;": "⨖",
    "quest;": "?",
    "questeq;": "≟",
    "QUOT;": '"',
    QUOT: '"',
    "quot;": '"',
    quot: '"',
    "rAarr;": "⇛",
    "race;": "∽̱",
    "Racute;": "Ŕ",
    "racute;": "ŕ",
    "radic;": "√",
    "raemptyv;": "⦳",
    "Rang;": "⟫",
    "rang;": "⟩",
    "rangd;": "⦒",
    "range;": "⦥",
    "rangle;": "⟩",
    "raquo;": "»",
    raquo: "»",
    "Rarr;": "↠",
    "rArr;": "⇒",
    "rarr;": "→",
    "rarrap;": "⥵",
    "rarrb;": "⇥",
    "rarrbfs;": "⤠",
    "rarrc;": "⤳",
    "rarrfs;": "⤞",
    "rarrhk;": "↪",
    "rarrlp;": "↬",
    "rarrpl;": "⥅",
    "rarrsim;": "⥴",
    "Rarrtl;": "⤖",
    "rarrtl;": "↣",
    "rarrw;": "↝",
    "rAtail;": "⤜",
    "ratail;": "⤚",
    "ratio;": "∶",
    "rationals;": "ℚ",
    "RBarr;": "⤐",
    "rBarr;": "⤏",
    "rbarr;": "⤍",
    "rbbrk;": "❳",
    "rbrace;": "}",
    "rbrack;": "]",
    "rbrke;": "⦌",
    "rbrksld;": "⦎",
    "rbrkslu;": "⦐",
    "Rcaron;": "Ř",
    "rcaron;": "ř",
    "Rcedil;": "Ŗ",
    "rcedil;": "ŗ",
    "rceil;": "⌉",
    "rcub;": "}",
    "Rcy;": "Р",
    "rcy;": "р",
    "rdca;": "⤷",
    "rdldhar;": "⥩",
    "rdquo;": "”",
    "rdquor;": "”",
    "rdsh;": "↳",
    "Re;": "ℜ",
    "real;": "ℜ",
    "realine;": "ℛ",
    "realpart;": "ℜ",
    "reals;": "ℝ",
    "rect;": "▭",
    "REG;": "®",
    REG: "®",
    "reg;": "®",
    reg: "®",
    "ReverseElement;": "∋",
    "ReverseEquilibrium;": "⇋",
    "ReverseUpEquilibrium;": "⥯",
    "rfisht;": "⥽",
    "rfloor;": "⌋",
    "Rfr;": "ℜ",
    "rfr;": "𝔯",
    "rHar;": "⥤",
    "rhard;": "⇁",
    "rharu;": "⇀",
    "rharul;": "⥬",
    "Rho;": "Ρ",
    "rho;": "ρ",
    "rhov;": "ϱ",
    "RightAngleBracket;": "⟩",
    "RightArrow;": "→",
    "Rightarrow;": "⇒",
    "rightarrow;": "→",
    "RightArrowBar;": "⇥",
    "RightArrowLeftArrow;": "⇄",
    "rightarrowtail;": "↣",
    "RightCeiling;": "⌉",
    "RightDoubleBracket;": "⟧",
    "RightDownTeeVector;": "⥝",
    "RightDownVector;": "⇂",
    "RightDownVectorBar;": "⥕",
    "RightFloor;": "⌋",
    "rightharpoondown;": "⇁",
    "rightharpoonup;": "⇀",
    "rightleftarrows;": "⇄",
    "rightleftharpoons;": "⇌",
    "rightrightarrows;": "⇉",
    "rightsquigarrow;": "↝",
    "RightTee;": "⊢",
    "RightTeeArrow;": "↦",
    "RightTeeVector;": "⥛",
    "rightthreetimes;": "⋌",
    "RightTriangle;": "⊳",
    "RightTriangleBar;": "⧐",
    "RightTriangleEqual;": "⊵",
    "RightUpDownVector;": "⥏",
    "RightUpTeeVector;": "⥜",
    "RightUpVector;": "↾",
    "RightUpVectorBar;": "⥔",
    "RightVector;": "⇀",
    "RightVectorBar;": "⥓",
    "ring;": "˚",
    "risingdotseq;": "≓",
    "rlarr;": "⇄",
    "rlhar;": "⇌",
    "rlm;": "‏",
    "rmoust;": "⎱",
    "rmoustache;": "⎱",
    "rnmid;": "⫮",
    "roang;": "⟭",
    "roarr;": "⇾",
    "robrk;": "⟧",
    "ropar;": "⦆",
    "Ropf;": "ℝ",
    "ropf;": "𝕣",
    "roplus;": "⨮",
    "rotimes;": "⨵",
    "RoundImplies;": "⥰",
    "rpar;": ")",
    "rpargt;": "⦔",
    "rppolint;": "⨒",
    "rrarr;": "⇉",
    "Rrightarrow;": "⇛",
    "rsaquo;": "›",
    "Rscr;": "ℛ",
    "rscr;": "𝓇",
    "Rsh;": "↱",
    "rsh;": "↱",
    "rsqb;": "]",
    "rsquo;": "’",
    "rsquor;": "’",
    "rthree;": "⋌",
    "rtimes;": "⋊",
    "rtri;": "▹",
    "rtrie;": "⊵",
    "rtrif;": "▸",
    "rtriltri;": "⧎",
    "RuleDelayed;": "⧴",
    "ruluhar;": "⥨",
    "rx;": "℞",
    "Sacute;": "Ś",
    "sacute;": "ś",
    "sbquo;": "‚",
    "Sc;": "⪼",
    "sc;": "≻",
    "scap;": "⪸",
    "Scaron;": "Š",
    "scaron;": "š",
    "sccue;": "≽",
    "scE;": "⪴",
    "sce;": "⪰",
    "Scedil;": "Ş",
    "scedil;": "ş",
    "Scirc;": "Ŝ",
    "scirc;": "ŝ",
    "scnap;": "⪺",
    "scnE;": "⪶",
    "scnsim;": "⋩",
    "scpolint;": "⨓",
    "scsim;": "≿",
    "Scy;": "С",
    "scy;": "с",
    "sdot;": "⋅",
    "sdotb;": "⊡",
    "sdote;": "⩦",
    "searhk;": "⤥",
    "seArr;": "⇘",
    "searr;": "↘",
    "searrow;": "↘",
    "sect;": "§",
    sect: "§",
    "semi;": ";",
    "seswar;": "⤩",
    "setminus;": "∖",
    "setmn;": "∖",
    "sext;": "✶",
    "Sfr;": "𝔖",
    "sfr;": "𝔰",
    "sfrown;": "⌢",
    "sharp;": "♯",
    "SHCHcy;": "Щ",
    "shchcy;": "щ",
    "SHcy;": "Ш",
    "shcy;": "ш",
    "ShortDownArrow;": "↓",
    "ShortLeftArrow;": "←",
    "shortmid;": "∣",
    "shortparallel;": "∥",
    "ShortRightArrow;": "→",
    "ShortUpArrow;": "↑",
    "shy;": "­",
    shy: "­",
    "Sigma;": "Σ",
    "sigma;": "σ",
    "sigmaf;": "ς",
    "sigmav;": "ς",
    "sim;": "∼",
    "simdot;": "⩪",
    "sime;": "≃",
    "simeq;": "≃",
    "simg;": "⪞",
    "simgE;": "⪠",
    "siml;": "⪝",
    "simlE;": "⪟",
    "simne;": "≆",
    "simplus;": "⨤",
    "simrarr;": "⥲",
    "slarr;": "←",
    "SmallCircle;": "∘",
    "smallsetminus;": "∖",
    "smashp;": "⨳",
    "smeparsl;": "⧤",
    "smid;": "∣",
    "smile;": "⌣",
    "smt;": "⪪",
    "smte;": "⪬",
    "smtes;": "⪬︀",
    "SOFTcy;": "Ь",
    "softcy;": "ь",
    "sol;": "/",
    "solb;": "⧄",
    "solbar;": "⌿",
    "Sopf;": "𝕊",
    "sopf;": "𝕤",
    "spades;": "♠",
    "spadesuit;": "♠",
    "spar;": "∥",
    "sqcap;": "⊓",
    "sqcaps;": "⊓︀",
    "sqcup;": "⊔",
    "sqcups;": "⊔︀",
    "Sqrt;": "√",
    "sqsub;": "⊏",
    "sqsube;": "⊑",
    "sqsubset;": "⊏",
    "sqsubseteq;": "⊑",
    "sqsup;": "⊐",
    "sqsupe;": "⊒",
    "sqsupset;": "⊐",
    "sqsupseteq;": "⊒",
    "squ;": "□",
    "Square;": "□",
    "square;": "□",
    "SquareIntersection;": "⊓",
    "SquareSubset;": "⊏",
    "SquareSubsetEqual;": "⊑",
    "SquareSuperset;": "⊐",
    "SquareSupersetEqual;": "⊒",
    "SquareUnion;": "⊔",
    "squarf;": "▪",
    "squf;": "▪",
    "srarr;": "→",
    "Sscr;": "𝒮",
    "sscr;": "𝓈",
    "ssetmn;": "∖",
    "ssmile;": "⌣",
    "sstarf;": "⋆",
    "Star;": "⋆",
    "star;": "☆",
    "starf;": "★",
    "straightepsilon;": "ϵ",
    "straightphi;": "ϕ",
    "strns;": "¯",
    "Sub;": "⋐",
    "sub;": "⊂",
    "subdot;": "⪽",
    "subE;": "⫅",
    "sube;": "⊆",
    "subedot;": "⫃",
    "submult;": "⫁",
    "subnE;": "⫋",
    "subne;": "⊊",
    "subplus;": "⪿",
    "subrarr;": "⥹",
    "Subset;": "⋐",
    "subset;": "⊂",
    "subseteq;": "⊆",
    "subseteqq;": "⫅",
    "SubsetEqual;": "⊆",
    "subsetneq;": "⊊",
    "subsetneqq;": "⫋",
    "subsim;": "⫇",
    "subsub;": "⫕",
    "subsup;": "⫓",
    "succ;": "≻",
    "succapprox;": "⪸",
    "succcurlyeq;": "≽",
    "Succeeds;": "≻",
    "SucceedsEqual;": "⪰",
    "SucceedsSlantEqual;": "≽",
    "SucceedsTilde;": "≿",
    "succeq;": "⪰",
    "succnapprox;": "⪺",
    "succneqq;": "⪶",
    "succnsim;": "⋩",
    "succsim;": "≿",
    "SuchThat;": "∋",
    "Sum;": "∑",
    "sum;": "∑",
    "sung;": "♪",
    "Sup;": "⋑",
    "sup;": "⊃",
    "sup1;": "¹",
    sup1: "¹",
    "sup2;": "²",
    sup2: "²",
    "sup3;": "³",
    sup3: "³",
    "supdot;": "⪾",
    "supdsub;": "⫘",
    "supE;": "⫆",
    "supe;": "⊇",
    "supedot;": "⫄",
    "Superset;": "⊃",
    "SupersetEqual;": "⊇",
    "suphsol;": "⟉",
    "suphsub;": "⫗",
    "suplarr;": "⥻",
    "supmult;": "⫂",
    "supnE;": "⫌",
    "supne;": "⊋",
    "supplus;": "⫀",
    "Supset;": "⋑",
    "supset;": "⊃",
    "supseteq;": "⊇",
    "supseteqq;": "⫆",
    "supsetneq;": "⊋",
    "supsetneqq;": "⫌",
    "supsim;": "⫈",
    "supsub;": "⫔",
    "supsup;": "⫖",
    "swarhk;": "⤦",
    "swArr;": "⇙",
    "swarr;": "↙",
    "swarrow;": "↙",
    "swnwar;": "⤪",
    "szlig;": "ß",
    szlig: "ß",
    "Tab;": "	",
    "target;": "⌖",
    "Tau;": "Τ",
    "tau;": "τ",
    "tbrk;": "⎴",
    "Tcaron;": "Ť",
    "tcaron;": "ť",
    "Tcedil;": "Ţ",
    "tcedil;": "ţ",
    "Tcy;": "Т",
    "tcy;": "т",
    "tdot;": "⃛",
    "telrec;": "⌕",
    "Tfr;": "𝔗",
    "tfr;": "𝔱",
    "there4;": "∴",
    "Therefore;": "∴",
    "therefore;": "∴",
    "Theta;": "Θ",
    "theta;": "θ",
    "thetasym;": "ϑ",
    "thetav;": "ϑ",
    "thickapprox;": "≈",
    "thicksim;": "∼",
    "ThickSpace;": "  ",
    "thinsp;": " ",
    "ThinSpace;": " ",
    "thkap;": "≈",
    "thksim;": "∼",
    "THORN;": "Þ",
    THORN: "Þ",
    "thorn;": "þ",
    thorn: "þ",
    "Tilde;": "∼",
    "tilde;": "˜",
    "TildeEqual;": "≃",
    "TildeFullEqual;": "≅",
    "TildeTilde;": "≈",
    "times;": "×",
    times: "×",
    "timesb;": "⊠",
    "timesbar;": "⨱",
    "timesd;": "⨰",
    "tint;": "∭",
    "toea;": "⤨",
    "top;": "⊤",
    "topbot;": "⌶",
    "topcir;": "⫱",
    "Topf;": "𝕋",
    "topf;": "𝕥",
    "topfork;": "⫚",
    "tosa;": "⤩",
    "tprime;": "‴",
    "TRADE;": "™",
    "trade;": "™",
    "triangle;": "▵",
    "triangledown;": "▿",
    "triangleleft;": "◃",
    "trianglelefteq;": "⊴",
    "triangleq;": "≜",
    "triangleright;": "▹",
    "trianglerighteq;": "⊵",
    "tridot;": "◬",
    "trie;": "≜",
    "triminus;": "⨺",
    "TripleDot;": "⃛",
    "triplus;": "⨹",
    "trisb;": "⧍",
    "tritime;": "⨻",
    "trpezium;": "⏢",
    "Tscr;": "𝒯",
    "tscr;": "𝓉",
    "TScy;": "Ц",
    "tscy;": "ц",
    "TSHcy;": "Ћ",
    "tshcy;": "ћ",
    "Tstrok;": "Ŧ",
    "tstrok;": "ŧ",
    "twixt;": "≬",
    "twoheadleftarrow;": "↞",
    "twoheadrightarrow;": "↠",
    "Uacute;": "Ú",
    Uacute: "Ú",
    "uacute;": "ú",
    uacute: "ú",
    "Uarr;": "↟",
    "uArr;": "⇑",
    "uarr;": "↑",
    "Uarrocir;": "⥉",
    "Ubrcy;": "Ў",
    "ubrcy;": "ў",
    "Ubreve;": "Ŭ",
    "ubreve;": "ŭ",
    "Ucirc;": "Û",
    Ucirc: "Û",
    "ucirc;": "û",
    ucirc: "û",
    "Ucy;": "У",
    "ucy;": "у",
    "udarr;": "⇅",
    "Udblac;": "Ű",
    "udblac;": "ű",
    "udhar;": "⥮",
    "ufisht;": "⥾",
    "Ufr;": "𝔘",
    "ufr;": "𝔲",
    "Ugrave;": "Ù",
    Ugrave: "Ù",
    "ugrave;": "ù",
    ugrave: "ù",
    "uHar;": "⥣",
    "uharl;": "↿",
    "uharr;": "↾",
    "uhblk;": "▀",
    "ulcorn;": "⌜",
    "ulcorner;": "⌜",
    "ulcrop;": "⌏",
    "ultri;": "◸",
    "Umacr;": "Ū",
    "umacr;": "ū",
    "uml;": "¨",
    uml: "¨",
    "UnderBar;": "_",
    "UnderBrace;": "⏟",
    "UnderBracket;": "⎵",
    "UnderParenthesis;": "⏝",
    "Union;": "⋃",
    "UnionPlus;": "⊎",
    "Uogon;": "Ų",
    "uogon;": "ų",
    "Uopf;": "𝕌",
    "uopf;": "𝕦",
    "UpArrow;": "↑",
    "Uparrow;": "⇑",
    "uparrow;": "↑",
    "UpArrowBar;": "⤒",
    "UpArrowDownArrow;": "⇅",
    "UpDownArrow;": "↕",
    "Updownarrow;": "⇕",
    "updownarrow;": "↕",
    "UpEquilibrium;": "⥮",
    "upharpoonleft;": "↿",
    "upharpoonright;": "↾",
    "uplus;": "⊎",
    "UpperLeftArrow;": "↖",
    "UpperRightArrow;": "↗",
    "Upsi;": "ϒ",
    "upsi;": "υ",
    "upsih;": "ϒ",
    "Upsilon;": "Υ",
    "upsilon;": "υ",
    "UpTee;": "⊥",
    "UpTeeArrow;": "↥",
    "upuparrows;": "⇈",
    "urcorn;": "⌝",
    "urcorner;": "⌝",
    "urcrop;": "⌎",
    "Uring;": "Ů",
    "uring;": "ů",
    "urtri;": "◹",
    "Uscr;": "𝒰",
    "uscr;": "𝓊",
    "utdot;": "⋰",
    "Utilde;": "Ũ",
    "utilde;": "ũ",
    "utri;": "▵",
    "utrif;": "▴",
    "uuarr;": "⇈",
    "Uuml;": "Ü",
    Uuml: "Ü",
    "uuml;": "ü",
    uuml: "ü",
    "uwangle;": "⦧",
    "vangrt;": "⦜",
    "varepsilon;": "ϵ",
    "varkappa;": "ϰ",
    "varnothing;": "∅",
    "varphi;": "ϕ",
    "varpi;": "ϖ",
    "varpropto;": "∝",
    "vArr;": "⇕",
    "varr;": "↕",
    "varrho;": "ϱ",
    "varsigma;": "ς",
    "varsubsetneq;": "⊊︀",
    "varsubsetneqq;": "⫋︀",
    "varsupsetneq;": "⊋︀",
    "varsupsetneqq;": "⫌︀",
    "vartheta;": "ϑ",
    "vartriangleleft;": "⊲",
    "vartriangleright;": "⊳",
    "Vbar;": "⫫",
    "vBar;": "⫨",
    "vBarv;": "⫩",
    "Vcy;": "В",
    "vcy;": "в",
    "VDash;": "⊫",
    "Vdash;": "⊩",
    "vDash;": "⊨",
    "vdash;": "⊢",
    "Vdashl;": "⫦",
    "Vee;": "⋁",
    "vee;": "∨",
    "veebar;": "⊻",
    "veeeq;": "≚",
    "vellip;": "⋮",
    "Verbar;": "‖",
    "verbar;": "|",
    "Vert;": "‖",
    "vert;": "|",
    "VerticalBar;": "∣",
    "VerticalLine;": "|",
    "VerticalSeparator;": "❘",
    "VerticalTilde;": "≀",
    "VeryThinSpace;": " ",
    "Vfr;": "𝔙",
    "vfr;": "𝔳",
    "vltri;": "⊲",
    "vnsub;": "⊂⃒",
    "vnsup;": "⊃⃒",
    "Vopf;": "𝕍",
    "vopf;": "𝕧",
    "vprop;": "∝",
    "vrtri;": "⊳",
    "Vscr;": "𝒱",
    "vscr;": "𝓋",
    "vsubnE;": "⫋︀",
    "vsubne;": "⊊︀",
    "vsupnE;": "⫌︀",
    "vsupne;": "⊋︀",
    "Vvdash;": "⊪",
    "vzigzag;": "⦚",
    "Wcirc;": "Ŵ",
    "wcirc;": "ŵ",
    "wedbar;": "⩟",
    "Wedge;": "⋀",
    "wedge;": "∧",
    "wedgeq;": "≙",
    "weierp;": "℘",
    "Wfr;": "𝔚",
    "wfr;": "𝔴",
    "Wopf;": "𝕎",
    "wopf;": "𝕨",
    "wp;": "℘",
    "wr;": "≀",
    "wreath;": "≀",
    "Wscr;": "𝒲",
    "wscr;": "𝓌",
    "xcap;": "⋂",
    "xcirc;": "◯",
    "xcup;": "⋃",
    "xdtri;": "▽",
    "Xfr;": "𝔛",
    "xfr;": "𝔵",
    "xhArr;": "⟺",
    "xharr;": "⟷",
    "Xi;": "Ξ",
    "xi;": "ξ",
    "xlArr;": "⟸",
    "xlarr;": "⟵",
    "xmap;": "⟼",
    "xnis;": "⋻",
    "xodot;": "⨀",
    "Xopf;": "𝕏",
    "xopf;": "𝕩",
    "xoplus;": "⨁",
    "xotime;": "⨂",
    "xrArr;": "⟹",
    "xrarr;": "⟶",
    "Xscr;": "𝒳",
    "xscr;": "𝓍",
    "xsqcup;": "⨆",
    "xuplus;": "⨄",
    "xutri;": "△",
    "xvee;": "⋁",
    "xwedge;": "⋀",
    "Yacute;": "Ý",
    Yacute: "Ý",
    "yacute;": "ý",
    yacute: "ý",
    "YAcy;": "Я",
    "yacy;": "я",
    "Ycirc;": "Ŷ",
    "ycirc;": "ŷ",
    "Ycy;": "Ы",
    "ycy;": "ы",
    "yen;": "¥",
    yen: "¥",
    "Yfr;": "𝔜",
    "yfr;": "𝔶",
    "YIcy;": "Ї",
    "yicy;": "ї",
    "Yopf;": "𝕐",
    "yopf;": "𝕪",
    "Yscr;": "𝒴",
    "yscr;": "𝓎",
    "YUcy;": "Ю",
    "yucy;": "ю",
    "Yuml;": "Ÿ",
    "yuml;": "ÿ",
    yuml: "ÿ",
    "Zacute;": "Ź",
    "zacute;": "ź",
    "Zcaron;": "Ž",
    "zcaron;": "ž",
    "Zcy;": "З",
    "zcy;": "з",
    "Zdot;": "Ż",
    "zdot;": "ż",
    "zeetrf;": "ℨ",
    "ZeroWidthSpace;": "​",
    "Zeta;": "Ζ",
    "zeta;": "ζ",
    "Zfr;": "ℨ",
    "zfr;": "𝔷",
    "ZHcy;": "Ж",
    "zhcy;": "ж",
    "zigrarr;": "⇝",
    "Zopf;": "ℤ",
    "zopf;": "𝕫",
    "Zscr;": "𝒵",
    "zscr;": "𝓏",
    "zwj;": "‍",
    "zwnj;": "‌"
  };

  function Je(t, e) {
    if (t.length < e.length) return !1;
    for (let n = 0; n < e.length; n++)
      if (t[n] !== e[n]) return !1;
    return !0
  }

  function mc(t, e) {
    const n = t.length - e.length;
    return n > 0 ? t.lastIndexOf(e) === n : n === 0 ? t === e : !1
  }

  function $a(t, e) {
    let n = "";
    for (; e > 0;)(e & 1) === 1 && (n += t), t += t, e = e >>> 1;
    return n
  }
  const fc = 97,
    pc = 122,
    gc = 65,
    bc = 90,
    wc = 48,
    _c = 57;

  function qt(t, e) {
    const n = t.charCodeAt(e);
    return fc <= n && n <= pc || gc <= n && n <= bc || wc <= n && n <= _c
  }

  function vn(t) {
    return typeof t < "u"
  }

  function vc(t) {
    if (t) return typeof t == "string" ? {
      kind: "markdown",
      value: t
    } : {
      kind: "markdown",
      value: t.value
    }
  }
  class Ga {
    isApplicable() {
      return !0
    }
    constructor(e, n) {
      this.id = e, this._tags = [], this._tagMap = {}, this._valueSetMap = {}, this._tags = n.tags || [], this._globalAttributes = n.globalAttributes || [], this._tags.forEach(i => {
        this._tagMap[i.name.toLowerCase()] = i
      }), n.valueSets && n.valueSets.forEach(i => {
        this._valueSetMap[i.name] = i.values
      })
    }
    getId() {
      return this.id
    }
    provideTags() {
      return this._tags
    }
    provideAttributes(e) {
      const n = [],
        i = s => {
          n.push(s)
        },
        r = this._tagMap[e.toLowerCase()];
      return r && r.attributes.forEach(i), this._globalAttributes.forEach(i), n
    }
    provideValues(e, n) {
      const i = [];
      n = n.toLowerCase();
      const r = a => {
          a.forEach(l => {
            l.name.toLowerCase() === n && (l.values && l.values.forEach(o => {
              i.push(o)
            }), l.valueSet && this._valueSetMap[l.valueSet] && this._valueSetMap[l.valueSet].forEach(o => {
              i.push(o)
            }))
          })
        },
        s = this._tagMap[e.toLowerCase()];
      return s && r(s.attributes), r(this._globalAttributes), i
    }
  }

  function nt(t, e = {}, n) {
    const i = {
      kind: n ? "markdown" : "plaintext",
      value: ""
    };
    if (t.description && e.documentation !== !1) {
      const r = vc(t.description);
      r && (i.value += r.value)
    }
    if (t.references && t.references.length > 0 && e.references !== !1 && (i.value.length && (i.value += `

`), n ? i.value += t.references.map(r => `[${r.name}](${r.url})`).join(" | ") : i.value += t.references.map(r => `${r.name}: ${r.url}`).join(`
`)), i.value !== "") return i
  }
  class yc {
    constructor(e, n) {
      this.dataManager = e, this.readDirectory = n, this.atributeCompletions = []
    }
    onHtmlAttributeValue(e) {
      this.dataManager.isPathAttribute(e.tag, e.attribute) && this.atributeCompletions.push(e)
    }
    async computeCompletions(e, n) {
      const i = {
        items: [],
        isIncomplete: !1
      };
      for (const r of this.atributeCompletions) {
        const s = xc(e.getText(r.range));
        if (kc(s))
          if (s === "." || s === "..") i.isIncomplete = !0;
          else {
            const a = Sc(r.value, s, r.range),
              l = await this.providePathSuggestions(r.value, a, e, n);
            for (const o of l) i.items.push(o)
          }
      }
      return i
    }
    async providePathSuggestions(e, n, i, r) {
      const s = e.substring(0, e.lastIndexOf("/") + 1);
      let a = r.resolveReference(s || ".", i.uri);
      if (a) try {
        const l = [],
          o = await this.readDirectory(a);
        for (const [u, c] of o) u.charCodeAt(0) !== Tc && l.push(Ac(u, c === Di.Directory, n));
        return l
      } catch {}
      return []
    }
  }
  const Tc = 46;

  function xc(t) {
    return Je(t, "'") || Je(t, '"') ? t.slice(1, -1) : t
  }

  function kc(t) {
    return !(Je(t, "http") || Je(t, "https") || Je(t, "//"))
  }

  function Sc(t, e, n) {
    let i;
    const r = t.lastIndexOf("/");
    if (r === -1) i = Lc(n, 1, -1);
    else {
      const s = e.slice(r + 1),
        a = Ot(n.end, -1 - s.length),
        l = s.indexOf(" ");
      let o;
      l !== -1 ? o = Ot(a, l) : o = Ot(n.end, -1), i = J.create(a, o)
    }
    return i
  }

  function Ac(t, e, n) {
    return e ? (t = t + "/", {
      label: t,
      kind: fe.Folder,
      textEdit: le.replace(n, t),
      command: {
        title: "Suggest",
        command: "editor.action.triggerSuggest"
      }
    }) : {
      label: t,
      kind: fe.File,
      textEdit: le.replace(n, t)
    }
  }

  function Ot(t, e) {
    return se.create(t.line, t.character + e)
  }

  function Lc(t, e, n) {
    const i = Ot(t.start, e),
      r = Ot(t.end, n);
    return J.create(i, r)
  }
  class Cc {
    constructor(e, n) {
      this.lsOptions = e, this.dataManager = n, this.completionParticipants = []
    }
    setCompletionParticipants(e) {
      this.completionParticipants = e || []
    }
    async doComplete2(e, n, i, r, s) {
      if (!this.lsOptions.fileSystemProvider || !this.lsOptions.fileSystemProvider.readDirectory) return this.doComplete(e, n, i, s);
      const a = new yc(this.dataManager, this.lsOptions.fileSystemProvider.readDirectory),
        l = this.completionParticipants;
      this.completionParticipants = [a].concat(l);
      const o = this.doComplete(e, n, i, s);
      try {
        const u = await a.computeCompletions(e, r);
        return {
          isIncomplete: o.isIncomplete || u.isIncomplete,
          items: u.items.concat(o.items)
        }
      } finally {
        this.completionParticipants = l
      }
    }
    doComplete(e, n, i, r) {
      const s = this._doComplete(e, n, i, r);
      return this.convertCompletionList(s)
    }
    _doComplete(e, n, i, r) {
      const s = {
          isIncomplete: !1,
          items: []
        },
        a = this.completionParticipants,
        l = this.dataManager.getDataProviders().filter(k => k.isApplicable(e.languageId) && (!r || r[k.getId()] !== !1)),
        o = this.dataManager.getVoidElements(l),
        u = this.doesSupportMarkdown(),
        c = e.getText(),
        d = e.offsetAt(n),
        m = i.findNodeBefore(d);
      if (!m) return s;
      const f = be(c, m.start);
      let w = "",
        p;

      function x(k, E = d) {
        return k > d && (k = d), {
          start: e.positionAt(k),
          end: e.positionAt(E)
        }
      }

      function T(k, E) {
        const M = x(k, E);
        return l.forEach(W => {
          W.provideTags().forEach(F => {
            s.items.push({
              label: F.name,
              kind: fe.Property,
              documentation: nt(F, void 0, u),
              textEdit: le.replace(M, F.name),
              insertTextFormat: Le.PlainText
            })
          })
        }), s
      }

      function y(k) {
        let E = k;
        for (; E > 0;) {
          const M = c.charAt(E - 1);
          if (`
\r`.indexOf(M) >= 0) return c.substring(E, k);
          if (!yn(M)) return null;
          E--
        }
        return c.substring(0, k)
      }

      function L(k, E, M = d) {
        const W = x(k, M),
          F = Xa(c, M, V.WithinEndTag, z.EndTagClose) ? "" : ">";
        let U = m;
        for (E && (U = U.parent); U;) {
          const O = U.tag;
          if (O && (!U.closed || U.endTagStart && U.endTagStart > d)) {
            const Z = {
                label: "/" + O,
                kind: fe.Property,
                filterText: "/" + O,
                textEdit: le.replace(W, "/" + O + F),
                insertTextFormat: Le.PlainText
              },
              Y = y(U.start),
              xe = y(k - 1);
            if (Y !== null && xe !== null && Y !== xe) {
              const Ee = Y + "</" + O + F;
              Z.textEdit = le.replace(x(k - 1 - xe.length), Ee), Z.filterText = xe + "</" + O
            }
            return s.items.push(Z), s
          }
          U = U.parent
        }
        return E || l.forEach(O => {
          O.provideTags().forEach(Z => {
            s.items.push({
              label: "/" + Z.name,
              kind: fe.Property,
              documentation: nt(Z, void 0, u),
              filterText: "/" + Z.name + F,
              textEdit: le.replace(W, "/" + Z.name + F),
              insertTextFormat: Le.PlainText
            })
          })
        }), s
      }
      const I = (k, E) => {
        if (r && r.hideAutoCompleteProposals) return s;
        if (!this.dataManager.isVoidElement(E, o)) {
          const M = e.positionAt(k);
          s.items.push({
            label: "</" + E + ">",
            kind: fe.Property,
            filterText: "</" + E + ">",
            textEdit: le.insert(M, "$0</" + E + ">"),
            insertTextFormat: Le.Snippet
          })
        }
        return s
      };

      function H(k, E) {
        return T(k, E), L(k, !0, E), s
      }

      function P() {
        const k = Object.create(null);
        return m.attributeNames.forEach(E => {
          k[E] = !0
        }), k
      }

      function b(k, E = d) {
        let M = d;
        for (; M < E && c[M] !== "<";) M++;
        const W = c.substring(k, E),
          F = x(k, M);
        let U = "";
        if (!Xa(c, E, V.AfterAttributeName, z.DelimiterAssign)) {
          const Z = (r == null ? void 0 : r.attributeDefaultValue) ?? "doublequotes";
          Z === "empty" ? U = "=$1" : Z === "singlequotes" ? U = "='$1'" : U = '="$1"'
        }
        const O = P();
        return O[W] = !1, l.forEach(Z => {
          Z.provideAttributes(w).forEach(Y => {
            if (O[Y.name]) return;
            O[Y.name] = !0;
            let xe = Y.name,
              Ee;
            Y.valueSet !== "v" && U.length && (xe = xe + U, (Y.valueSet || Y.name === "style") && (Ee = {
              title: "Suggest",
              command: "editor.action.triggerSuggest"
            })), s.items.push({
              label: Y.name,
              kind: Y.valueSet === "handler" ? fe.Function : fe.Value,
              documentation: nt(Y, void 0, u),
              textEdit: le.replace(F, xe),
              insertTextFormat: Le.Snippet,
              command: Ee
            })
          })
        }), g(F, O), s
      }

      function g(k, E) {
        const M = "data-",
          W = {};
        W[M] = `${M}$1="$2"`;

        function F(U) {
          U.attributeNames.forEach(O => {
            Je(O, M) && !W[O] && !E[O] && (W[O] = O + '="$1"')
          }), U.children.forEach(O => F(O))
        }
        i && i.roots.forEach(U => F(U)), Object.keys(W).forEach(U => s.items.push({
          label: U,
          kind: fe.Value,
          textEdit: le.replace(k, W[U]),
          insertTextFormat: Le.Snippet
        }))
      }

      function _(k, E = d) {
        let M, W, F;
        if (d > k && d <= E && Ec(c[k])) {
          const U = k + 1;
          let O = E;
          E > k && c[E - 1] === c[k] && O--;
          const Z = Rc(c, d, U),
            Y = Dc(c, d, O);
          M = x(Z, Y), F = d >= U && d <= O ? c.substring(U, d) : "", W = !1
        } else M = x(k, E), F = c.substring(k, d), W = !0;
        if (a.length > 0) {
          const U = w.toLowerCase(),
            O = p.toLowerCase(),
            Z = x(k, E);
          for (const Y of a) Y.onHtmlAttributeValue && Y.onHtmlAttributeValue({
            document: e,
            position: n,
            tag: U,
            attribute: O,
            value: F,
            range: Z
          })
        }
        return l.forEach(U => {
          U.provideValues(w, p).forEach(O => {
            const Z = W ? '"' + O.name + '"' : O.name;
            s.items.push({
              label: O.name,
              filterText: Z,
              kind: fe.Unit,
              documentation: nt(O, void 0, u),
              textEdit: le.replace(M, Z),
              insertTextFormat: Le.PlainText
            })
          })
        }), v(), s
      }

      function N(k) {
        return d === f.getTokenEnd() && (D = f.scan(), D === k && f.getTokenOffset() === d) ? f.getTokenEnd() : d
      }

      function S() {
        for (const k of a) k.onHtmlContent && k.onHtmlContent({
          document: e,
          position: n
        });
        return v()
      }

      function v() {
        let k = d - 1,
          E = n.character;
        for (; k >= 0 && qt(c, k);) k--, E--;
        if (k >= 0 && c[k] === "&") {
          const M = J.create(se.create(n.line, E - 1), n);
          for (const W in Bt)
            if (mc(W, ";")) {
              const F = "&" + W;
              s.items.push({
                label: F,
                kind: fe.Keyword,
                documentation: Ae("Character entity representing '{0}'", Bt[W]),
                textEdit: le.replace(M, F),
                insertTextFormat: Le.PlainText
              })
            }
        }
        return s
      }

      function A(k, E) {
        const M = x(k, E);
        s.items.push({
          label: "!DOCTYPE",
          kind: fe.Property,
          documentation: "A preamble for an HTML document.",
          textEdit: le.replace(M, "!DOCTYPE html>"),
          insertTextFormat: Le.PlainText
        })
      }
      let D = f.scan();
      for (; D !== z.EOS && f.getTokenOffset() <= d;) {
        switch (D) {
          case z.StartTagOpen:
            if (f.getTokenEnd() === d) {
              const k = N(z.StartTag);
              return n.line === 0 && A(d, k), H(d, k)
            }
            break;
          case z.StartTag:
            if (f.getTokenOffset() <= d && d <= f.getTokenEnd()) return T(f.getTokenOffset(), f.getTokenEnd());
            w = f.getTokenText();
            break;
          case z.AttributeName:
            if (f.getTokenOffset() <= d && d <= f.getTokenEnd()) return b(f.getTokenOffset(), f.getTokenEnd());
            p = f.getTokenText();
            break;
          case z.DelimiterAssign:
            if (f.getTokenEnd() === d) {
              const k = N(z.AttributeValue);
              return _(d, k)
            }
            break;
          case z.AttributeValue:
            if (f.getTokenOffset() <= d && d <= f.getTokenEnd()) return _(f.getTokenOffset(), f.getTokenEnd());
            break;
          case z.Whitespace:
            if (d <= f.getTokenEnd()) switch (f.getScannerState()) {
              case V.AfterOpeningStartTag:
                const k = f.getTokenOffset(),
                  E = N(z.StartTag);
                return H(k, E);
              case V.WithinTag:
              case V.AfterAttributeName:
                return b(f.getTokenEnd());
              case V.BeforeAttributeValue:
                return _(f.getTokenEnd());
              case V.AfterOpeningEndTag:
                return L(f.getTokenOffset() - 1, !1);
              case V.WithinContent:
                return S()
            }
            break;
          case z.EndTagOpen:
            if (d <= f.getTokenEnd()) {
              const k = f.getTokenOffset() + 1,
                E = N(z.EndTag);
              return L(k, !1, E)
            }
            break;
          case z.EndTag:
            if (d <= f.getTokenEnd()) {
              let k = f.getTokenOffset() - 1;
              for (; k >= 0;) {
                const E = c.charAt(k);
                if (E === "/") return L(k, !1, f.getTokenEnd());
                if (!yn(E)) break;
                k--
              }
            }
            break;
          case z.StartTagClose:
            if (d <= f.getTokenEnd() && w) return I(f.getTokenEnd(), w);
            break;
          case z.Content:
            if (d <= f.getTokenEnd()) return S();
            break;
          default:
            if (d <= f.getTokenEnd()) return s;
            break
        }
        D = f.scan()
      }
      return s
    }
    doQuoteComplete(e, n, i, r) {
      const s = e.offsetAt(n);
      if (s <= 0) return null;
      const a = (r == null ? void 0 : r.attributeDefaultValue) ?? "doublequotes";
      if (a === "empty" || e.getText().charAt(s - 1) !== "=") return null;
      const o = a === "doublequotes" ? '"$1"' : "'$1'",
        u = i.findNodeBefore(s);
      if (u && u.attributes && u.start < s && (!u.endTagStart || u.endTagStart > s)) {
        const c = be(e.getText(), u.start);
        let d = c.scan();
        for (; d !== z.EOS && c.getTokenEnd() <= s;) {
          if (d === z.AttributeName && c.getTokenEnd() === s - 1) return d = c.scan(), d !== z.DelimiterAssign || (d = c.scan(), d === z.Unknown || d === z.AttributeValue) ? null : o;
          d = c.scan()
        }
      }
      return null
    }
    doTagComplete(e, n, i) {
      const r = e.offsetAt(n);
      if (r <= 0) return null;
      const s = e.getText().charAt(r - 1);
      if (s === ">") {
        const a = this.dataManager.getVoidElements(e.languageId),
          l = i.findNodeBefore(r);
        if (l && l.tag && !this.dataManager.isVoidElement(l.tag, a) && l.start < r && (!l.endTagStart || l.endTagStart > r)) {
          const o = be(e.getText(), l.start);
          let u = o.scan();
          for (; u !== z.EOS && o.getTokenEnd() <= r;) {
            if (u === z.StartTagClose && o.getTokenEnd() === r) return `$0</${l.tag}>`;
            u = o.scan()
          }
        }
      } else if (s === "/") {
        let a = i.findNodeBefore(r);
        for (; a && a.closed && !(a.endTagStart && a.endTagStart > r);) a = a.parent;
        if (a && a.tag) {
          const l = be(e.getText(), a.start);
          let o = l.scan();
          for (; o !== z.EOS && l.getTokenEnd() <= r;) {
            if (o === z.EndTagOpen && l.getTokenEnd() === r) return e.getText().charAt(r) !== ">" ? `${a.tag}>` : a.tag;
            o = l.scan()
          }
        }
      }
      return null
    }
    convertCompletionList(e) {
      return this.doesSupportMarkdown() || e.items.forEach(n => {
        n.documentation && typeof n.documentation != "string" && (n.documentation = {
          kind: "plaintext",
          value: n.documentation.value
        })
      }), e
    }
    doesSupportMarkdown() {
      var e, n, i;
      if (!vn(this.supportsMarkdown)) {
        if (!vn(this.lsOptions.clientCapabilities)) return this.supportsMarkdown = !0, this.supportsMarkdown;
        const r = (i = (n = (e = this.lsOptions.clientCapabilities.textDocument) == null ? void 0 : e.completion) == null ? void 0 : n.completionItem) == null ? void 0 : i.documentationFormat;
        this.supportsMarkdown = Array.isArray(r) && r.indexOf(qe.Markdown) !== -1
      }
      return this.supportsMarkdown
    }
  }

  function Ec(t) {
    return /^["']*$/.test(t)
  }

  function yn(t) {
    return /^\s*$/.test(t)
  }

  function Xa(t, e, n, i) {
    const r = be(t, e, n);
    let s = r.scan();
    for (; s === z.Whitespace;) s = r.scan();
    return s === i
  }

  function Rc(t, e, n) {
    for (; e > n && !yn(t[e - 1]);) e--;
    return e
  }

  function Dc(t, e, n) {
    for (; e < n && !yn(t[e]);) e++;
    return e
  }
  class Mc {
    constructor(e, n) {
      this.lsOptions = e, this.dataManager = n
    }
    doHover(e, n, i, r) {
      const s = this.convertContents.bind(this),
        a = this.doesSupportMarkdown(),
        l = e.offsetAt(n),
        o = i.findNodeAt(l),
        u = e.getText();
      if (!o || !o.tag) return null;
      const c = this.dataManager.getDataProviders().filter(b => b.isApplicable(e.languageId));

      function d(b, g, _) {
        for (const N of c) {
          let S = null;
          if (N.provideTags().forEach(v => {
              if (v.name.toLowerCase() === b.toLowerCase()) {
                let A = nt(v, r, a);
                A || (A = {
                  kind: a ? "markdown" : "plaintext",
                  value: ""
                }), S = {
                  contents: A,
                  range: g
                }
              }
            }), S) return S.contents = s(S.contents), S
        }
        return null
      }

      function m(b, g, _) {
        for (const N of c) {
          let S = null;
          if (N.provideAttributes(b).forEach(v => {
              if (g === v.name && v.description) {
                const A = nt(v, r, a);
                A ? S = {
                  contents: A,
                  range: _
                } : S = null
              }
            }), S) return S.contents = s(S.contents), S
        }
        return null
      }

      function f(b, g, _, N) {
        for (const S of c) {
          let v = null;
          if (S.provideValues(b, g).forEach(A => {
              if (_ === A.name && A.description) {
                const D = nt(A, r, a);
                D ? v = {
                  contents: D,
                  range: N
                } : v = null
              }
            }), v) return v.contents = s(v.contents), v
        }
        return null
      }

      function w(b, g) {
        let _ = T(b);
        for (const N in Bt) {
          let S = null;
          const v = "&" + N;
          if (_ === v) {
            let A = Bt[N].charCodeAt(0).toString(16).toUpperCase(),
              D = "U+";
            if (A.length < 4) {
              const E = 4 - A.length;
              let M = 0;
              for (; M < E;) D += "0", M += 1
            }
            D += A;
            const k = Ae("Character entity representing '{0}', unicode equivalent '{1}'", Bt[N], D);
            k ? S = {
              contents: k,
              range: g
            } : S = null
          }
          if (S) return S.contents = s(S.contents), S
        }
        return null
      }

      function p(b, g) {
        const _ = be(e.getText(), g);
        let N = _.scan();
        for (; N !== z.EOS && (_.getTokenEnd() < l || _.getTokenEnd() === l && N !== b);) N = _.scan();
        return N === b && l <= _.getTokenEnd() ? {
          start: e.positionAt(_.getTokenOffset()),
          end: e.positionAt(_.getTokenEnd())
        } : null
      }

      function x() {
        let b = l - 1,
          g = n.character;
        for (; b >= 0 && qt(u, b);) b--, g--;
        let _ = b + 1,
          N = g;
        for (; qt(u, _);) _++, N++;
        if (b >= 0 && u[b] === "&") {
          let S = null;
          return u[_] === ";" ? S = J.create(se.create(n.line, g), se.create(n.line, N + 1)) : S = J.create(se.create(n.line, g), se.create(n.line, N)), S
        }
        return null
      }

      function T(b) {
        let g = l - 1,
          _ = "&";
        for (; g >= 0 && qt(b, g);) g--;
        for (g = g + 1; qt(b, g);) _ += b[g], g += 1;
        return _ += ";", _
      }
      if (o.endTagStart && l >= o.endTagStart) {
        const b = p(z.EndTag, o.endTagStart);
        return b ? d(o.tag, b) : null
      }
      const y = p(z.StartTag, o.start);
      if (y) return d(o.tag, y);
      const L = p(z.AttributeName, o.start);
      if (L) {
        const b = o.tag,
          g = e.getText(L);
        return m(b, g, L)
      }
      const I = x();
      if (I) return w(u, I);

      function H(b, g) {
        const _ = be(e.getText(), b);
        let N = _.scan(),
          S;
        for (; N !== z.EOS && _.getTokenEnd() <= g;) N = _.scan(), N === z.AttributeName && (S = _.getTokenText());
        return S
      }
      const P = p(z.AttributeValue, o.start);
      if (P) {
        const b = o.tag,
          g = Nc(e.getText(P)),
          _ = H(o.start, e.offsetAt(P.start));
        if (_) return f(b, _, g, P)
      }
      return null
    }
    convertContents(e) {
      if (!this.doesSupportMarkdown()) {
        if (typeof e == "string") return e;
        if ("kind" in e) return {
          kind: "plaintext",
          value: e.value
        };
        if (Array.isArray(e)) e.map(n => typeof n == "string" ? n : n.value);
        else return e.value
      }
      return e
    }
    doesSupportMarkdown() {
      var e, n, i;
      if (!vn(this.supportsMarkdown)) {
        if (!vn(this.lsOptions.clientCapabilities)) return this.supportsMarkdown = !0, this.supportsMarkdown;
        const r = (i = (n = (e = this.lsOptions.clientCapabilities) == null ? void 0 : e.textDocument) == null ? void 0 : n.hover) == null ? void 0 : i.contentFormat;
        this.supportsMarkdown = Array.isArray(r) && r.indexOf(qe.Markdown) !== -1
      }
      return this.supportsMarkdown
    }
  }

  function Nc(t) {
    return t.length <= 1 ? t.replace(/['"]/, "") : ((t[0] === "'" || t[0] === '"') && (t = t.slice(1)), (t[t.length - 1] === "'" || t[t.length - 1] === '"') && (t = t.slice(0, -1)), t)
  }

  function Ic(t, e) {
    return t
  }
  var Ja;
  (function() {
    var t = [, , (function(r) {
        function s(o) {
          this.__parent = o, this.__character_count = 0, this.__indent_count = -1, this.__alignment_count = 0, this.__wrap_point_index = 0, this.__wrap_point_character_count = 0, this.__wrap_point_indent_count = -1, this.__wrap_point_alignment_count = 0, this.__items = []
        }
        s.prototype.clone_empty = function() {
          var o = new s(this.__parent);
          return o.set_indent(this.__indent_count, this.__alignment_count), o
        }, s.prototype.item = function(o) {
          return o < 0 ? this.__items[this.__items.length + o] : this.__items[o]
        }, s.prototype.has_match = function(o) {
          for (var u = this.__items.length - 1; u >= 0; u--)
            if (this.__items[u].match(o)) return !0;
          return !1
        }, s.prototype.set_indent = function(o, u) {
          this.is_empty() && (this.__indent_count = o || 0, this.__alignment_count = u || 0, this.__character_count = this.__parent.get_indent_size(this.__indent_count, this.__alignment_count))
        }, s.prototype._set_wrap_point = function() {
          this.__parent.wrap_line_length && (this.__wrap_point_index = this.__items.length, this.__wrap_point_character_count = this.__character_count, this.__wrap_point_indent_count = this.__parent.next_line.__indent_count, this.__wrap_point_alignment_count = this.__parent.next_line.__alignment_count)
        }, s.prototype._should_wrap = function() {
          return this.__wrap_point_index && this.__character_count > this.__parent.wrap_line_length && this.__wrap_point_character_count > this.__parent.next_line.__character_count
        }, s.prototype._allow_wrap = function() {
          if (this._should_wrap()) {
            this.__parent.add_new_line();
            var o = this.__parent.current_line;
            return o.set_indent(this.__wrap_point_indent_count, this.__wrap_point_alignment_count), o.__items = this.__items.slice(this.__wrap_point_index), this.__items = this.__items.slice(0, this.__wrap_point_index), o.__character_count += this.__character_count - this.__wrap_point_character_count, this.__character_count = this.__wrap_point_character_count, o.__items[0] === " " && (o.__items.splice(0, 1), o.__character_count -= 1), !0
          }
          return !1
        }, s.prototype.is_empty = function() {
          return this.__items.length === 0
        }, s.prototype.last = function() {
          return this.is_empty() ? null : this.__items[this.__items.length - 1]
        }, s.prototype.push = function(o) {
          this.__items.push(o);
          var u = o.lastIndexOf(`
`);
          u !== -1 ? this.__character_count = o.length - u : this.__character_count += o.length
        }, s.prototype.pop = function() {
          var o = null;
          return this.is_empty() || (o = this.__items.pop(), this.__character_count -= o.length), o
        }, s.prototype._remove_indent = function() {
          this.__indent_count > 0 && (this.__indent_count -= 1, this.__character_count -= this.__parent.indent_size)
        }, s.prototype._remove_wrap_indent = function() {
          this.__wrap_point_indent_count > 0 && (this.__wrap_point_indent_count -= 1)
        }, s.prototype.trim = function() {
          for (; this.last() === " ";) this.__items.pop(), this.__character_count -= 1
        }, s.prototype.toString = function() {
          var o = "";
          return this.is_empty() ? this.__parent.indent_empty_lines && (o = this.__parent.get_indent_string(this.__indent_count)) : (o = this.__parent.get_indent_string(this.__indent_count, this.__alignment_count), o += this.__items.join("")), o
        };

        function a(o, u) {
          this.__cache = [""], this.__indent_size = o.indent_size, this.__indent_string = o.indent_char, o.indent_with_tabs || (this.__indent_string = new Array(o.indent_size + 1).join(o.indent_char)), u = u || "", o.indent_level > 0 && (u = new Array(o.indent_level + 1).join(this.__indent_string)), this.__base_string = u, this.__base_string_length = u.length
        }
        a.prototype.get_indent_size = function(o, u) {
          var c = this.__base_string_length;
          return u = u || 0, o < 0 && (c = 0), c += o * this.__indent_size, c += u, c
        }, a.prototype.get_indent_string = function(o, u) {
          var c = this.__base_string;
          return u = u || 0, o < 0 && (o = 0, c = ""), u += o * this.__indent_size, this.__ensure_cache(u), c += this.__cache[u], c
        }, a.prototype.__ensure_cache = function(o) {
          for (; o >= this.__cache.length;) this.__add_column()
        }, a.prototype.__add_column = function() {
          var o = this.__cache.length,
            u = 0,
            c = "";
          this.__indent_size && o >= this.__indent_size && (u = Math.floor(o / this.__indent_size), o -= u * this.__indent_size, c = new Array(u + 1).join(this.__indent_string)), o && (c += new Array(o + 1).join(" ")), this.__cache.push(c)
        };

        function l(o, u) {
          this.__indent_cache = new a(o, u), this.raw = !1, this._end_with_newline = o.end_with_newline, this.indent_size = o.indent_size, this.wrap_line_length = o.wrap_line_length, this.indent_empty_lines = o.indent_empty_lines, this.__lines = [], this.previous_line = null, this.current_line = null, this.next_line = new s(this), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1, this.__add_outputline()
        }
        l.prototype.__add_outputline = function() {
          this.previous_line = this.current_line, this.current_line = this.next_line.clone_empty(), this.__lines.push(this.current_line)
        }, l.prototype.get_line_number = function() {
          return this.__lines.length
        }, l.prototype.get_indent_string = function(o, u) {
          return this.__indent_cache.get_indent_string(o, u)
        }, l.prototype.get_indent_size = function(o, u) {
          return this.__indent_cache.get_indent_size(o, u)
        }, l.prototype.is_empty = function() {
          return !this.previous_line && this.current_line.is_empty()
        }, l.prototype.add_new_line = function(o) {
          return this.is_empty() || !o && this.just_added_newline() ? !1 : (this.raw || this.__add_outputline(), !0)
        }, l.prototype.get_code = function(o) {
          this.trim(!0);
          var u = this.current_line.pop();
          u && (u[u.length - 1] === `
` && (u = u.replace(/\n+$/g, "")), this.current_line.push(u)), this._end_with_newline && this.__add_outputline();
          var c = this.__lines.join(`
`);
          return o !== `
` && (c = c.replace(/[\n]/g, o)), c
        }, l.prototype.set_wrap_point = function() {
          this.current_line._set_wrap_point()
        }, l.prototype.set_indent = function(o, u) {
          return o = o || 0, u = u || 0, this.next_line.set_indent(o, u), this.__lines.length > 1 ? (this.current_line.set_indent(o, u), !0) : (this.current_line.set_indent(), !1)
        }, l.prototype.add_raw_token = function(o) {
          for (var u = 0; u < o.newlines; u++) this.__add_outputline();
          this.current_line.set_indent(-1), this.current_line.push(o.whitespace_before), this.current_line.push(o.text), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1
        }, l.prototype.add_token = function(o) {
          this.__add_space_before_token(), this.current_line.push(o), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = this.current_line._allow_wrap()
        }, l.prototype.__add_space_before_token = function() {
          this.space_before_token && !this.just_added_newline() && (this.non_breaking_space || this.set_wrap_point(), this.current_line.push(" "))
        }, l.prototype.remove_indent = function(o) {
          for (var u = this.__lines.length; o < u;) this.__lines[o]._remove_indent(), o++;
          this.current_line._remove_wrap_indent()
        }, l.prototype.trim = function(o) {
          for (o = o === void 0 ? !1 : o, this.current_line.trim(); o && this.__lines.length > 1 && this.current_line.is_empty();) this.__lines.pop(), this.current_line = this.__lines[this.__lines.length - 1], this.current_line.trim();
          this.previous_line = this.__lines.length > 1 ? this.__lines[this.__lines.length - 2] : null
        }, l.prototype.just_added_newline = function() {
          return this.current_line.is_empty()
        }, l.prototype.just_added_blankline = function() {
          return this.is_empty() || this.current_line.is_empty() && this.previous_line.is_empty()
        }, l.prototype.ensure_empty_line_above = function(o, u) {
          for (var c = this.__lines.length - 2; c >= 0;) {
            var d = this.__lines[c];
            if (d.is_empty()) break;
            if (d.item(0).indexOf(o) !== 0 && d.item(-1) !== u) {
              this.__lines.splice(c + 1, 0, new s(this)), this.previous_line = this.__lines[this.__lines.length - 2];
              break
            }
            c--
          }
        }, r.exports.Output = l
      }), , , , (function(r) {
        function s(o, u) {
          this.raw_options = a(o, u), this.disabled = this._get_boolean("disabled"), this.eol = this._get_characters("eol", "auto"), this.end_with_newline = this._get_boolean("end_with_newline"), this.indent_size = this._get_number("indent_size", 4), this.indent_char = this._get_characters("indent_char", " "), this.indent_level = this._get_number("indent_level"), this.preserve_newlines = this._get_boolean("preserve_newlines", !0), this.max_preserve_newlines = this._get_number("max_preserve_newlines", 32786), this.preserve_newlines || (this.max_preserve_newlines = 0), this.indent_with_tabs = this._get_boolean("indent_with_tabs", this.indent_char === "	"), this.indent_with_tabs && (this.indent_char = "	", this.indent_size === 1 && (this.indent_size = 4)), this.wrap_line_length = this._get_number("wrap_line_length", this._get_number("max_char")), this.indent_empty_lines = this._get_boolean("indent_empty_lines"), this.templating = this._get_selection_list("templating", ["auto", "none", "angular", "django", "erb", "handlebars", "php", "smarty"], ["auto"])
        }
        s.prototype._get_array = function(o, u) {
          var c = this.raw_options[o],
            d = u || [];
          return typeof c == "object" ? c !== null && typeof c.concat == "function" && (d = c.concat()) : typeof c == "string" && (d = c.split(/[^a-zA-Z0-9_\/\-]+/)), d
        }, s.prototype._get_boolean = function(o, u) {
          var c = this.raw_options[o],
            d = c === void 0 ? !!u : !!c;
          return d
        }, s.prototype._get_characters = function(o, u) {
          var c = this.raw_options[o],
            d = u || "";
          return typeof c == "string" && (d = c.replace(/\\r/, "\r").replace(/\\n/, `
`).replace(/\\t/, "	")), d
        }, s.prototype._get_number = function(o, u) {
          var c = this.raw_options[o];
          u = parseInt(u, 10), isNaN(u) && (u = 0);
          var d = parseInt(c, 10);
          return isNaN(d) && (d = u), d
        }, s.prototype._get_selection = function(o, u, c) {
          var d = this._get_selection_list(o, u, c);
          if (d.length !== 1) throw new Error("Invalid Option Value: The option '" + o + `' can only be one of the following values:
` + u + `
You passed in: '` + this.raw_options[o] + "'");
          return d[0]
        }, s.prototype._get_selection_list = function(o, u, c) {
          if (!u || u.length === 0) throw new Error("Selection list cannot be empty.");
          if (c = c || [u[0]], !this._is_valid_selection(c, u)) throw new Error("Invalid Default Value!");
          var d = this._get_array(o, c);
          if (!this._is_valid_selection(d, u)) throw new Error("Invalid Option Value: The option '" + o + `' can contain only the following values:
` + u + `
You passed in: '` + this.raw_options[o] + "'");
          return d
        }, s.prototype._is_valid_selection = function(o, u) {
          return o.length && u.length && !o.some(function(c) {
            return u.indexOf(c) === -1
          })
        };

        function a(o, u) {
          var c = {};
          o = l(o);
          var d;
          for (d in o) d !== u && (c[d] = o[d]);
          if (u && o[u])
            for (d in o[u]) c[d] = o[u][d];
          return c
        }

        function l(o) {
          var u = {},
            c;
          for (c in o) {
            var d = c.replace(/-/g, "_");
            u[d] = o[c]
          }
          return u
        }
        r.exports.Options = s, r.exports.normalizeOpts = l, r.exports.mergeOpts = a
      }), , (function(r) {
        var s = RegExp.prototype.hasOwnProperty("sticky");

        function a(l) {
          this.__input = l || "", this.__input_length = this.__input.length, this.__position = 0
        }
        a.prototype.restart = function() {
          this.__position = 0
        }, a.prototype.back = function() {
          this.__position > 0 && (this.__position -= 1)
        }, a.prototype.hasNext = function() {
          return this.__position < this.__input_length
        }, a.prototype.next = function() {
          var l = null;
          return this.hasNext() && (l = this.__input.charAt(this.__position), this.__position += 1), l
        }, a.prototype.peek = function(l) {
          var o = null;
          return l = l || 0, l += this.__position, l >= 0 && l < this.__input_length && (o = this.__input.charAt(l)), o
        }, a.prototype.__match = function(l, o) {
          l.lastIndex = o;
          var u = l.exec(this.__input);
          return u && !(s && l.sticky) && u.index !== o && (u = null), u
        }, a.prototype.test = function(l, o) {
          return o = o || 0, o += this.__position, o >= 0 && o < this.__input_length ? !!this.__match(l, o) : !1
        }, a.prototype.testChar = function(l, o) {
          var u = this.peek(o);
          return l.lastIndex = 0, u !== null && l.test(u)
        }, a.prototype.match = function(l) {
          var o = this.__match(l, this.__position);
          return o ? this.__position += o[0].length : o = null, o
        }, a.prototype.read = function(l, o, u) {
          var c = "",
            d;
          return l && (d = this.match(l), d && (c += d[0])), o && (d || !l) && (c += this.readUntil(o, u)), c
        }, a.prototype.readUntil = function(l, o) {
          var u = "",
            c = this.__position;
          l.lastIndex = this.__position;
          var d = l.exec(this.__input);
          return d ? (c = d.index, o && (c += d[0].length)) : c = this.__input_length, u = this.__input.substring(this.__position, c), this.__position = c, u
        }, a.prototype.readUntilAfter = function(l) {
          return this.readUntil(l, !0)
        }, a.prototype.get_regexp = function(l, o) {
          var u = null,
            c = "g";
          return o && s && (c = "y"), typeof l == "string" && l !== "" ? u = new RegExp(l, c) : l && (u = new RegExp(l.source, c)), u
        }, a.prototype.get_literal_regexp = function(l) {
          return RegExp(l.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
        }, a.prototype.peekUntilAfter = function(l) {
          var o = this.__position,
            u = this.readUntilAfter(l);
          return this.__position = o, u
        }, a.prototype.lookBack = function(l) {
          var o = this.__position - 1;
          return o >= l.length && this.__input.substring(o - l.length, o).toLowerCase() === l
        }, r.exports.InputScanner = a
      }), , , , , (function(r) {
        function s(a, l) {
          a = typeof a == "string" ? a : a.source, l = typeof l == "string" ? l : l.source, this.__directives_block_pattern = new RegExp(a + / beautify( \w+[:]\w+)+ /.source + l, "g"), this.__directive_pattern = / (\w+)[:](\w+)/g, this.__directives_end_ignore_pattern = new RegExp(a + /\sbeautify\signore:end\s/.source + l, "g")
        }
        s.prototype.get_directives = function(a) {
          if (!a.match(this.__directives_block_pattern)) return null;
          var l = {};
          this.__directive_pattern.lastIndex = 0;
          for (var o = this.__directive_pattern.exec(a); o;) l[o[1]] = o[2], o = this.__directive_pattern.exec(a);
          return l
        }, s.prototype.readIgnored = function(a) {
          return a.readUntilAfter(this.__directives_end_ignore_pattern)
        }, r.exports.Directives = s
      }), , (function(r, s, a) {
        var l = a(16).Beautifier,
          o = a(17).Options;

        function u(c, d) {
          var m = new l(c, d);
          return m.beautify()
        }
        r.exports = u, r.exports.defaultOptions = function() {
          return new o
        }
      }), (function(r, s, a) {
        var l = a(17).Options,
          o = a(2).Output,
          u = a(8).InputScanner,
          c = a(13).Directives,
          d = new c(/\/\*/, /\*\//),
          m = /\r\n|[\r\n]/,
          f = /\r\n|[\r\n]/g,
          w = /\s/,
          p = /(?:\s|\n)+/g,
          x = /\/\*(?:[\s\S]*?)((?:\*\/)|$)/g,
          T = /\/\/(?:[^\n\r\u2028\u2029]*)/g;

        function y(L, I) {
          this._source_text = L || "", this._options = new l(I), this._ch = null, this._input = null, this.NESTED_AT_RULE = {
            page: !0,
            "font-face": !0,
            keyframes: !0,
            media: !0,
            supports: !0,
            document: !0
          }, this.CONDITIONAL_GROUP_RULE = {
            media: !0,
            supports: !0,
            document: !0
          }, this.NON_SEMICOLON_NEWLINE_PROPERTY = ["grid-template-areas", "grid-template"]
        }
        y.prototype.eatString = function(L) {
          var I = "";
          for (this._ch = this._input.next(); this._ch;) {
            if (I += this._ch, this._ch === "\\") I += this._input.next();
            else if (L.indexOf(this._ch) !== -1 || this._ch === `
`) break;
            this._ch = this._input.next()
          }
          return I
        }, y.prototype.eatWhitespace = function(L) {
          for (var I = w.test(this._input.peek()), H = 0; w.test(this._input.peek());) this._ch = this._input.next(), L && this._ch === `
` && (H === 0 || H < this._options.max_preserve_newlines) && (H++, this._output.add_new_line(!0));
          return I
        }, y.prototype.foundNestedPseudoClass = function() {
          for (var L = 0, I = 1, H = this._input.peek(I); H;) {
            if (H === "{") return !0;
            if (H === "(") L += 1;
            else if (H === ")") {
              if (L === 0) return !1;
              L -= 1
            } else if (H === ";" || H === "}") return !1;
            I++, H = this._input.peek(I)
          }
          return !1
        }, y.prototype.print_string = function(L) {
          this._output.set_indent(this._indentLevel), this._output.non_breaking_space = !0, this._output.add_token(L)
        }, y.prototype.preserveSingleSpace = function(L) {
          L && (this._output.space_before_token = !0)
        }, y.prototype.indent = function() {
          this._indentLevel++
        }, y.prototype.outdent = function() {
          this._indentLevel > 0 && this._indentLevel--
        }, y.prototype.beautify = function() {
          if (this._options.disabled) return this._source_text;
          var L = this._source_text,
            I = this._options.eol;
          I === "auto" && (I = `
`, L && m.test(L || "") && (I = L.match(m)[0])), L = L.replace(f, `
`);
          var H = L.match(/^[\t ]*/)[0];
          this._output = new o(this._options, H), this._input = new u(L), this._indentLevel = 0, this._nestedLevel = 0, this._ch = null;
          for (var P = 0, b = !1, g = !1, _ = !1, N = !1, S = !1, v = this._ch, A = !1, D, k, E; D = this._input.read(p), k = D !== "", E = v, this._ch = this._input.next(), this._ch === "\\" && this._input.hasNext() && (this._ch += this._input.next()), v = this._ch, this._ch;)
            if (this._ch === "/" && this._input.peek() === "*") {
              this._output.add_new_line(), this._input.back();
              var M = this._input.read(x),
                W = d.get_directives(M);
              W && W.ignore === "start" && (M += d.readIgnored(this._input)), this.print_string(M), this.eatWhitespace(!0), this._output.add_new_line()
            } else if (this._ch === "/" && this._input.peek() === "/") this._output.space_before_token = !0, this._input.back(), this.print_string(this._input.read(T)), this.eatWhitespace(!0);
          else if (this._ch === "$") {
            this.preserveSingleSpace(k), this.print_string(this._ch);
            var F = this._input.peekUntilAfter(/[: ,;{}()[\]\/='"]/g);
            F.match(/[ :]$/) && (F = this.eatString(": ").replace(/\s+$/, ""), this.print_string(F), this._output.space_before_token = !0), P === 0 && F.indexOf(":") !== -1 && (g = !0, this.indent())
          } else if (this._ch === "@")
            if (this.preserveSingleSpace(k), this._input.peek() === "{") this.print_string(this._ch + this.eatString("}"));
            else {
              this.print_string(this._ch);
              var U = this._input.peekUntilAfter(/[: ,;{}()[\]\/='"]/g);
              U.match(/[ :]$/) && (U = this.eatString(": ").replace(/\s+$/, ""), this.print_string(U), this._output.space_before_token = !0), P === 0 && U.indexOf(":") !== -1 ? (g = !0, this.indent()) : U in this.NESTED_AT_RULE ? (this._nestedLevel += 1, U in this.CONDITIONAL_GROUP_RULE && (_ = !0)) : P === 0 && !g && (N = !0)
            }
          else if (this._ch === "#" && this._input.peek() === "{") this.preserveSingleSpace(k), this.print_string(this._ch + this.eatString("}"));
          else if (this._ch === "{") g && (g = !1, this.outdent()), N = !1, _ ? (_ = !1, b = this._indentLevel >= this._nestedLevel) : b = this._indentLevel >= this._nestedLevel - 1, this._options.newline_between_rules && b && this._output.previous_line && this._output.previous_line.item(-1) !== "{" && this._output.ensure_empty_line_above("/", ","), this._output.space_before_token = !0, this._options.brace_style === "expand" ? (this._output.add_new_line(), this.print_string(this._ch), this.indent(), this._output.set_indent(this._indentLevel)) : (E === "(" ? this._output.space_before_token = !1 : E !== "," && this.indent(), this.print_string(this._ch)), this.eatWhitespace(!0), this._output.add_new_line();
          else if (this._ch === "}") this.outdent(), this._output.add_new_line(), E === "{" && this._output.trim(!0), g && (this.outdent(), g = !1), this.print_string(this._ch), b = !1, this._nestedLevel && this._nestedLevel--, this.eatWhitespace(!0), this._output.add_new_line(), this._options.newline_between_rules && !this._output.just_added_blankline() && this._input.peek() !== "}" && this._output.add_new_line(!0), this._input.peek() === ")" && (this._output.trim(!0), this._options.brace_style === "expand" && this._output.add_new_line(!0));
          else if (this._ch === ":") {
            for (var O = 0; O < this.NON_SEMICOLON_NEWLINE_PROPERTY.length; O++)
              if (this._input.lookBack(this.NON_SEMICOLON_NEWLINE_PROPERTY[O])) {
                A = !0;
                break
              }(b || _) && !(this._input.lookBack("&") || this.foundNestedPseudoClass()) && ! this._input.lookBack("(") && !N && P === 0 ? (this.print_string(":"), g || (g = !0, this._output.space_before_token = !0, this.eatWhitespace(!0), this.indent())) : (this._input.lookBack(" ") && (this._output.space_before_token = !0), this._input.peek() === ":" ? (this._ch = this._input.next(), this.print_string("::")) : this.print_string(":"))
          } else if (this._ch === '"' || this._ch === "'") {
            var Z = E === '"' || E === "'";
            this.preserveSingleSpace(Z || k), this.print_string(this._ch + this.eatString(this._ch)), this.eatWhitespace(!0)
          } else if (this._ch === ";") A = !1, P === 0 ? (g && (this.outdent(), g = !1), N = !1, this.print_string(this._ch), this.eatWhitespace(!0), this._input.peek() !== "/" && this._output.add_new_line()) : (this.print_string(this._ch), this.eatWhitespace(!0), this._output.space_before_token = !0);
          else if (this._ch === "(")
            if (this._input.lookBack("url")) this.print_string(this._ch), this.eatWhitespace(), P++, this.indent(), this._ch = this._input.next(), this._ch === ")" || this._ch === '"' || this._ch === "'" ? this._input.back() : this._ch && (this.print_string(this._ch + this.eatString(")")), P && (P--, this.outdent()));
            else {
              var Y = !1;
              this._input.lookBack("with") && (Y = !0), this.preserveSingleSpace(k || Y), this.print_string(this._ch), g && E === "$" && this._options.selector_separator_newline ? (this._output.add_new_line(), S = !0) : (this.eatWhitespace(), P++, this.indent())
            }
          else if (this._ch === ")") P && (P--, this.outdent()), S && this._input.peek() === ";" && this._options.selector_separator_newline && (S = !1, this.outdent(), this._output.add_new_line()), this.print_string(this._ch);
          else if (this._ch === ",") this.print_string(this._ch), this.eatWhitespace(!0), this._options.selector_separator_newline && (!g || S) && P === 0 && !N ? this._output.add_new_line() : this._output.space_before_token = !0;
          else if ((this._ch === ">" || this._ch === "+" || this._ch === "~") && !g && P === 0) this._options.space_around_combinator ? (this._output.space_before_token = !0, this.print_string(this._ch), this._output.space_before_token = !0) : (this.print_string(this._ch), this.eatWhitespace(), this._ch && w.test(this._ch) && (this._ch = ""));
          else if (this._ch === "]") this.print_string(this._ch);
          else if (this._ch === "[") this.preserveSingleSpace(k), this.print_string(this._ch);
          else if (this._ch === "=") this.eatWhitespace(), this.print_string("="), w.test(this._ch) && (this._ch = "");
          else if (this._ch === "!" && !this._input.lookBack("\\")) this._output.space_before_token = !0, this.print_string(this._ch);
          else {
            var xe = E === '"' || E === "'";
            this.preserveSingleSpace(xe || k), this.print_string(this._ch), !this._output.just_added_newline() && this._input.peek() === `
` && A && this._output.add_new_line()
          }
          var Ee = this._output.get_code(I);
          return Ee
        }, r.exports.Beautifier = y
      }), (function(r, s, a) {
        var l = a(6).Options;

        function o(u) {
          l.call(this, u, "css"), this.selector_separator_newline = this._get_boolean("selector_separator_newline", !0), this.newline_between_rules = this._get_boolean("newline_between_rules", !0);
          var c = this._get_boolean("space_around_selector_separator");
          this.space_around_combinator = this._get_boolean("space_around_combinator") || c;
          var d = this._get_selection_list("brace_style", ["collapse", "expand", "end-expand", "none", "preserve-inline"]);
          this.brace_style = "collapse";
          for (var m = 0; m < d.length; m++) d[m] !== "expand" ? this.brace_style = "collapse" : this.brace_style = d[m]
        }
        o.prototype = new l, r.exports.Options = o
      })],
      e = {};

    function n(r) {
      var s = e[r];
      if (s !== void 0) return s.exports;
      var a = e[r] = {
        exports: {}
      };
      return t[r](a, a.exports, n), a.exports
    }
    var i = n(15);
    Ja = i
  })();
  var zc = Ja,
    Qa;
  (function() {
    var t = [, , (function(r) {
        function s(o) {
          this.__parent = o, this.__character_count = 0, this.__indent_count = -1, this.__alignment_count = 0, this.__wrap_point_index = 0, this.__wrap_point_character_count = 0, this.__wrap_point_indent_count = -1, this.__wrap_point_alignment_count = 0, this.__items = []
        }
        s.prototype.clone_empty = function() {
          var o = new s(this.__parent);
          return o.set_indent(this.__indent_count, this.__alignment_count), o
        }, s.prototype.item = function(o) {
          return o < 0 ? this.__items[this.__items.length + o] : this.__items[o]
        }, s.prototype.has_match = function(o) {
          for (var u = this.__items.length - 1; u >= 0; u--)
            if (this.__items[u].match(o)) return !0;
          return !1
        }, s.prototype.set_indent = function(o, u) {
          this.is_empty() && (this.__indent_count = o || 0, this.__alignment_count = u || 0, this.__character_count = this.__parent.get_indent_size(this.__indent_count, this.__alignment_count))
        }, s.prototype._set_wrap_point = function() {
          this.__parent.wrap_line_length && (this.__wrap_point_index = this.__items.length, this.__wrap_point_character_count = this.__character_count, this.__wrap_point_indent_count = this.__parent.next_line.__indent_count, this.__wrap_point_alignment_count = this.__parent.next_line.__alignment_count)
        }, s.prototype._should_wrap = function() {
          return this.__wrap_point_index && this.__character_count > this.__parent.wrap_line_length && this.__wrap_point_character_count > this.__parent.next_line.__character_count
        }, s.prototype._allow_wrap = function() {
          if (this._should_wrap()) {
            this.__parent.add_new_line();
            var o = this.__parent.current_line;
            return o.set_indent(this.__wrap_point_indent_count, this.__wrap_point_alignment_count), o.__items = this.__items.slice(this.__wrap_point_index), this.__items = this.__items.slice(0, this.__wrap_point_index), o.__character_count += this.__character_count - this.__wrap_point_character_count, this.__character_count = this.__wrap_point_character_count, o.__items[0] === " " && (o.__items.splice(0, 1), o.__character_count -= 1), !0
          }
          return !1
        }, s.prototype.is_empty = function() {
          return this.__items.length === 0
        }, s.prototype.last = function() {
          return this.is_empty() ? null : this.__items[this.__items.length - 1]
        }, s.prototype.push = function(o) {
          this.__items.push(o);
          var u = o.lastIndexOf(`
`);
          u !== -1 ? this.__character_count = o.length - u : this.__character_count += o.length
        }, s.prototype.pop = function() {
          var o = null;
          return this.is_empty() || (o = this.__items.pop(), this.__character_count -= o.length), o
        }, s.prototype._remove_indent = function() {
          this.__indent_count > 0 && (this.__indent_count -= 1, this.__character_count -= this.__parent.indent_size)
        }, s.prototype._remove_wrap_indent = function() {
          this.__wrap_point_indent_count > 0 && (this.__wrap_point_indent_count -= 1)
        }, s.prototype.trim = function() {
          for (; this.last() === " ";) this.__items.pop(), this.__character_count -= 1
        }, s.prototype.toString = function() {
          var o = "";
          return this.is_empty() ? this.__parent.indent_empty_lines && (o = this.__parent.get_indent_string(this.__indent_count)) : (o = this.__parent.get_indent_string(this.__indent_count, this.__alignment_count), o += this.__items.join("")), o
        };

        function a(o, u) {
          this.__cache = [""], this.__indent_size = o.indent_size, this.__indent_string = o.indent_char, o.indent_with_tabs || (this.__indent_string = new Array(o.indent_size + 1).join(o.indent_char)), u = u || "", o.indent_level > 0 && (u = new Array(o.indent_level + 1).join(this.__indent_string)), this.__base_string = u, this.__base_string_length = u.length
        }
        a.prototype.get_indent_size = function(o, u) {
          var c = this.__base_string_length;
          return u = u || 0, o < 0 && (c = 0), c += o * this.__indent_size, c += u, c
        }, a.prototype.get_indent_string = function(o, u) {
          var c = this.__base_string;
          return u = u || 0, o < 0 && (o = 0, c = ""), u += o * this.__indent_size, this.__ensure_cache(u), c += this.__cache[u], c
        }, a.prototype.__ensure_cache = function(o) {
          for (; o >= this.__cache.length;) this.__add_column()
        }, a.prototype.__add_column = function() {
          var o = this.__cache.length,
            u = 0,
            c = "";
          this.__indent_size && o >= this.__indent_size && (u = Math.floor(o / this.__indent_size), o -= u * this.__indent_size, c = new Array(u + 1).join(this.__indent_string)), o && (c += new Array(o + 1).join(" ")), this.__cache.push(c)
        };

        function l(o, u) {
          this.__indent_cache = new a(o, u), this.raw = !1, this._end_with_newline = o.end_with_newline, this.indent_size = o.indent_size, this.wrap_line_length = o.wrap_line_length, this.indent_empty_lines = o.indent_empty_lines, this.__lines = [], this.previous_line = null, this.current_line = null, this.next_line = new s(this), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1, this.__add_outputline()
        }
        l.prototype.__add_outputline = function() {
          this.previous_line = this.current_line, this.current_line = this.next_line.clone_empty(), this.__lines.push(this.current_line)
        }, l.prototype.get_line_number = function() {
          return this.__lines.length
        }, l.prototype.get_indent_string = function(o, u) {
          return this.__indent_cache.get_indent_string(o, u)
        }, l.prototype.get_indent_size = function(o, u) {
          return this.__indent_cache.get_indent_size(o, u)
        }, l.prototype.is_empty = function() {
          return !this.previous_line && this.current_line.is_empty()
        }, l.prototype.add_new_line = function(o) {
          return this.is_empty() || !o && this.just_added_newline() ? !1 : (this.raw || this.__add_outputline(), !0)
        }, l.prototype.get_code = function(o) {
          this.trim(!0);
          var u = this.current_line.pop();
          u && (u[u.length - 1] === `
` && (u = u.replace(/\n+$/g, "")), this.current_line.push(u)), this._end_with_newline && this.__add_outputline();
          var c = this.__lines.join(`
`);
          return o !== `
` && (c = c.replace(/[\n]/g, o)), c
        }, l.prototype.set_wrap_point = function() {
          this.current_line._set_wrap_point()
        }, l.prototype.set_indent = function(o, u) {
          return o = o || 0, u = u || 0, this.next_line.set_indent(o, u), this.__lines.length > 1 ? (this.current_line.set_indent(o, u), !0) : (this.current_line.set_indent(), !1)
        }, l.prototype.add_raw_token = function(o) {
          for (var u = 0; u < o.newlines; u++) this.__add_outputline();
          this.current_line.set_indent(-1), this.current_line.push(o.whitespace_before), this.current_line.push(o.text), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1
        }, l.prototype.add_token = function(o) {
          this.__add_space_before_token(), this.current_line.push(o), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = this.current_line._allow_wrap()
        }, l.prototype.__add_space_before_token = function() {
          this.space_before_token && !this.just_added_newline() && (this.non_breaking_space || this.set_wrap_point(), this.current_line.push(" "))
        }, l.prototype.remove_indent = function(o) {
          for (var u = this.__lines.length; o < u;) this.__lines[o]._remove_indent(), o++;
          this.current_line._remove_wrap_indent()
        }, l.prototype.trim = function(o) {
          for (o = o === void 0 ? !1 : o, this.current_line.trim(); o && this.__lines.length > 1 && this.current_line.is_empty();) this.__lines.pop(), this.current_line = this.__lines[this.__lines.length - 1], this.current_line.trim();
          this.previous_line = this.__lines.length > 1 ? this.__lines[this.__lines.length - 2] : null
        }, l.prototype.just_added_newline = function() {
          return this.current_line.is_empty()
        }, l.prototype.just_added_blankline = function() {
          return this.is_empty() || this.current_line.is_empty() && this.previous_line.is_empty()
        }, l.prototype.ensure_empty_line_above = function(o, u) {
          for (var c = this.__lines.length - 2; c >= 0;) {
            var d = this.__lines[c];
            if (d.is_empty()) break;
            if (d.item(0).indexOf(o) !== 0 && d.item(-1) !== u) {
              this.__lines.splice(c + 1, 0, new s(this)), this.previous_line = this.__lines[this.__lines.length - 2];
              break
            }
            c--
          }
        }, r.exports.Output = l
      }), (function(r) {
        function s(a, l, o, u) {
          this.type = a, this.text = l, this.comments_before = null, this.newlines = o || 0, this.whitespace_before = u || "", this.parent = null, this.next = null, this.previous = null, this.opened = null, this.closed = null, this.directives = null
        }
        r.exports.Token = s
      }), , , (function(r) {
        function s(o, u) {
          this.raw_options = a(o, u), this.disabled = this._get_boolean("disabled"), this.eol = this._get_characters("eol", "auto"), this.end_with_newline = this._get_boolean("end_with_newline"), this.indent_size = this._get_number("indent_size", 4), this.indent_char = this._get_characters("indent_char", " "), this.indent_level = this._get_number("indent_level"), this.preserve_newlines = this._get_boolean("preserve_newlines", !0), this.max_preserve_newlines = this._get_number("max_preserve_newlines", 32786), this.preserve_newlines || (this.max_preserve_newlines = 0), this.indent_with_tabs = this._get_boolean("indent_with_tabs", this.indent_char === "	"), this.indent_with_tabs && (this.indent_char = "	", this.indent_size === 1 && (this.indent_size = 4)), this.wrap_line_length = this._get_number("wrap_line_length", this._get_number("max_char")), this.indent_empty_lines = this._get_boolean("indent_empty_lines"), this.templating = this._get_selection_list("templating", ["auto", "none", "angular", "django", "erb", "handlebars", "php", "smarty"], ["auto"])
        }
        s.prototype._get_array = function(o, u) {
          var c = this.raw_options[o],
            d = u || [];
          return typeof c == "object" ? c !== null && typeof c.concat == "function" && (d = c.concat()) : typeof c == "string" && (d = c.split(/[^a-zA-Z0-9_\/\-]+/)), d
        }, s.prototype._get_boolean = function(o, u) {
          var c = this.raw_options[o],
            d = c === void 0 ? !!u : !!c;
          return d
        }, s.prototype._get_characters = function(o, u) {
          var c = this.raw_options[o],
            d = u || "";
          return typeof c == "string" && (d = c.replace(/\\r/, "\r").replace(/\\n/, `
`).replace(/\\t/, "	")), d
        }, s.prototype._get_number = function(o, u) {
          var c = this.raw_options[o];
          u = parseInt(u, 10), isNaN(u) && (u = 0);
          var d = parseInt(c, 10);
          return isNaN(d) && (d = u), d
        }, s.prototype._get_selection = function(o, u, c) {
          var d = this._get_selection_list(o, u, c);
          if (d.length !== 1) throw new Error("Invalid Option Value: The option '" + o + `' can only be one of the following values:
` + u + `
You passed in: '` + this.raw_options[o] + "'");
          return d[0]
        }, s.prototype._get_selection_list = function(o, u, c) {
          if (!u || u.length === 0) throw new Error("Selection list cannot be empty.");
          if (c = c || [u[0]], !this._is_valid_selection(c, u)) throw new Error("Invalid Default Value!");
          var d = this._get_array(o, c);
          if (!this._is_valid_selection(d, u)) throw new Error("Invalid Option Value: The option '" + o + `' can contain only the following values:
` + u + `
You passed in: '` + this.raw_options[o] + "'");
          return d
        }, s.prototype._is_valid_selection = function(o, u) {
          return o.length && u.length && !o.some(function(c) {
            return u.indexOf(c) === -1
          })
        };

        function a(o, u) {
          var c = {};
          o = l(o);
          var d;
          for (d in o) d !== u && (c[d] = o[d]);
          if (u && o[u])
            for (d in o[u]) c[d] = o[u][d];
          return c
        }

        function l(o) {
          var u = {},
            c;
          for (c in o) {
            var d = c.replace(/-/g, "_");
            u[d] = o[c]
          }
          return u
        }
        r.exports.Options = s, r.exports.normalizeOpts = l, r.exports.mergeOpts = a
      }), , (function(r) {
        var s = RegExp.prototype.hasOwnProperty("sticky");

        function a(l) {
          this.__input = l || "", this.__input_length = this.__input.length, this.__position = 0
        }
        a.prototype.restart = function() {
          this.__position = 0
        }, a.prototype.back = function() {
          this.__position > 0 && (this.__position -= 1)
        }, a.prototype.hasNext = function() {
          return this.__position < this.__input_length
        }, a.prototype.next = function() {
          var l = null;
          return this.hasNext() && (l = this.__input.charAt(this.__position), this.__position += 1), l
        }, a.prototype.peek = function(l) {
          var o = null;
          return l = l || 0, l += this.__position, l >= 0 && l < this.__input_length && (o = this.__input.charAt(l)), o
        }, a.prototype.__match = function(l, o) {
          l.lastIndex = o;
          var u = l.exec(this.__input);
          return u && !(s && l.sticky) && u.index !== o && (u = null), u
        }, a.prototype.test = function(l, o) {
          return o = o || 0, o += this.__position, o >= 0 && o < this.__input_length ? !!this.__match(l, o) : !1
        }, a.prototype.testChar = function(l, o) {
          var u = this.peek(o);
          return l.lastIndex = 0, u !== null && l.test(u)
        }, a.prototype.match = function(l) {
          var o = this.__match(l, this.__position);
          return o ? this.__position += o[0].length : o = null, o
        }, a.prototype.read = function(l, o, u) {
          var c = "",
            d;
          return l && (d = this.match(l), d && (c += d[0])), o && (d || !l) && (c += this.readUntil(o, u)), c
        }, a.prototype.readUntil = function(l, o) {
          var u = "",
            c = this.__position;
          l.lastIndex = this.__position;
          var d = l.exec(this.__input);
          return d ? (c = d.index, o && (c += d[0].length)) : c = this.__input_length, u = this.__input.substring(this.__position, c), this.__position = c, u
        }, a.prototype.readUntilAfter = function(l) {
          return this.readUntil(l, !0)
        }, a.prototype.get_regexp = function(l, o) {
          var u = null,
            c = "g";
          return o && s && (c = "y"), typeof l == "string" && l !== "" ? u = new RegExp(l, c) : l && (u = new RegExp(l.source, c)), u
        }, a.prototype.get_literal_regexp = function(l) {
          return RegExp(l.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
        }, a.prototype.peekUntilAfter = function(l) {
          var o = this.__position,
            u = this.readUntilAfter(l);
          return this.__position = o, u
        }, a.prototype.lookBack = function(l) {
          var o = this.__position - 1;
          return o >= l.length && this.__input.substring(o - l.length, o).toLowerCase() === l
        }, r.exports.InputScanner = a
      }), (function(r, s, a) {
        var l = a(8).InputScanner,
          o = a(3).Token,
          u = a(10).TokenStream,
          c = a(11).WhitespacePattern,
          d = {
            START: "TK_START",
            RAW: "TK_RAW",
            EOF: "TK_EOF"
          },
          m = function(f, w) {
            this._input = new l(f), this._options = w || {}, this.__tokens = null, this._patterns = {}, this._patterns.whitespace = new c(this._input)
          };
        m.prototype.tokenize = function() {
          this._input.restart(), this.__tokens = new u, this._reset();
          for (var f, w = new o(d.START, ""), p = null, x = [], T = new u; w.type !== d.EOF;) {
            for (f = this._get_next_token(w, p); this._is_comment(f);) T.add(f), f = this._get_next_token(w, p);
            T.isEmpty() || (f.comments_before = T, T = new u), f.parent = p, this._is_opening(f) ? (x.push(p), p = f) : p && this._is_closing(f, p) && (f.opened = p, p.closed = f, p = x.pop(), f.parent = p), f.previous = w, w.next = f, this.__tokens.add(f), w = f
          }
          return this.__tokens
        }, m.prototype._is_first_token = function() {
          return this.__tokens.isEmpty()
        }, m.prototype._reset = function() {}, m.prototype._get_next_token = function(f, w) {
          this._readWhitespace();
          var p = this._input.read(/.+/g);
          return p ? this._create_token(d.RAW, p) : this._create_token(d.EOF, "")
        }, m.prototype._is_comment = function(f) {
          return !1
        }, m.prototype._is_opening = function(f) {
          return !1
        }, m.prototype._is_closing = function(f, w) {
          return !1
        }, m.prototype._create_token = function(f, w) {
          var p = new o(f, w, this._patterns.whitespace.newline_count, this._patterns.whitespace.whitespace_before_token);
          return p
        }, m.prototype._readWhitespace = function() {
          return this._patterns.whitespace.read()
        }, r.exports.Tokenizer = m, r.exports.TOKEN = d
      }), (function(r) {
        function s(a) {
          this.__tokens = [], this.__tokens_length = this.__tokens.length, this.__position = 0, this.__parent_token = a
        }
        s.prototype.restart = function() {
          this.__position = 0
        }, s.prototype.isEmpty = function() {
          return this.__tokens_length === 0
        }, s.prototype.hasNext = function() {
          return this.__position < this.__tokens_length
        }, s.prototype.next = function() {
          var a = null;
          return this.hasNext() && (a = this.__tokens[this.__position], this.__position += 1), a
        }, s.prototype.peek = function(a) {
          var l = null;
          return a = a || 0, a += this.__position, a >= 0 && a < this.__tokens_length && (l = this.__tokens[a]), l
        }, s.prototype.add = function(a) {
          this.__parent_token && (a.parent = this.__parent_token), this.__tokens.push(a), this.__tokens_length += 1
        }, r.exports.TokenStream = s
      }), (function(r, s, a) {
        var l = a(12).Pattern;

        function o(u, c) {
          l.call(this, u, c), c ? this._line_regexp = this._input.get_regexp(c._line_regexp) : this.__set_whitespace_patterns("", ""), this.newline_count = 0, this.whitespace_before_token = ""
        }
        o.prototype = new l, o.prototype.__set_whitespace_patterns = function(u, c) {
          u += "\\t ", c += "\\n\\r", this._match_pattern = this._input.get_regexp("[" + u + c + "]+", !0), this._newline_regexp = this._input.get_regexp("\\r\\n|[" + c + "]")
        }, o.prototype.read = function() {
          this.newline_count = 0, this.whitespace_before_token = "";
          var u = this._input.read(this._match_pattern);
          if (u === " ") this.whitespace_before_token = " ";
          else if (u) {
            var c = this.__split(this._newline_regexp, u);
            this.newline_count = c.length - 1, this.whitespace_before_token = c[this.newline_count]
          }
          return u
        }, o.prototype.matching = function(u, c) {
          var d = this._create();
          return d.__set_whitespace_patterns(u, c), d._update(), d
        }, o.prototype._create = function() {
          return new o(this._input, this)
        }, o.prototype.__split = function(u, c) {
          u.lastIndex = 0;
          for (var d = 0, m = [], f = u.exec(c); f;) m.push(c.substring(d, f.index)), d = f.index + f[0].length, f = u.exec(c);
          return d < c.length ? m.push(c.substring(d, c.length)) : m.push(""), m
        }, r.exports.WhitespacePattern = o
      }), (function(r) {
        function s(a, l) {
          this._input = a, this._starting_pattern = null, this._match_pattern = null, this._until_pattern = null, this._until_after = !1, l && (this._starting_pattern = this._input.get_regexp(l._starting_pattern, !0), this._match_pattern = this._input.get_regexp(l._match_pattern, !0), this._until_pattern = this._input.get_regexp(l._until_pattern), this._until_after = l._until_after)
        }
        s.prototype.read = function() {
          var a = this._input.read(this._starting_pattern);
          return (!this._starting_pattern || a) && (a += this._input.read(this._match_pattern, this._until_pattern, this._until_after)), a
        }, s.prototype.read_match = function() {
          return this._input.match(this._match_pattern)
        }, s.prototype.until_after = function(a) {
          var l = this._create();
          return l._until_after = !0, l._until_pattern = this._input.get_regexp(a), l._update(), l
        }, s.prototype.until = function(a) {
          var l = this._create();
          return l._until_after = !1, l._until_pattern = this._input.get_regexp(a), l._update(), l
        }, s.prototype.starting_with = function(a) {
          var l = this._create();
          return l._starting_pattern = this._input.get_regexp(a, !0), l._update(), l
        }, s.prototype.matching = function(a) {
          var l = this._create();
          return l._match_pattern = this._input.get_regexp(a, !0), l._update(), l
        }, s.prototype._create = function() {
          return new s(this._input, this)
        }, s.prototype._update = function() {}, r.exports.Pattern = s
      }), (function(r) {
        function s(a, l) {
          a = typeof a == "string" ? a : a.source, l = typeof l == "string" ? l : l.source, this.__directives_block_pattern = new RegExp(a + / beautify( \w+[:]\w+)+ /.source + l, "g"), this.__directive_pattern = / (\w+)[:](\w+)/g, this.__directives_end_ignore_pattern = new RegExp(a + /\sbeautify\signore:end\s/.source + l, "g")
        }
        s.prototype.get_directives = function(a) {
          if (!a.match(this.__directives_block_pattern)) return null;
          var l = {};
          this.__directive_pattern.lastIndex = 0;
          for (var o = this.__directive_pattern.exec(a); o;) l[o[1]] = o[2], o = this.__directive_pattern.exec(a);
          return l
        }, s.prototype.readIgnored = function(a) {
          return a.readUntilAfter(this.__directives_end_ignore_pattern)
        }, r.exports.Directives = s
      }), (function(r, s, a) {
        var l = a(12).Pattern,
          o = {
            django: !1,
            erb: !1,
            handlebars: !1,
            php: !1,
            smarty: !1,
            angular: !1
          };

        function u(c, d) {
          l.call(this, c, d), this.__template_pattern = null, this._disabled = Object.assign({}, o), this._excluded = Object.assign({}, o), d && (this.__template_pattern = this._input.get_regexp(d.__template_pattern), this._excluded = Object.assign(this._excluded, d._excluded), this._disabled = Object.assign(this._disabled, d._disabled));
          var m = new l(c);
          this.__patterns = {
            handlebars_comment: m.starting_with(/{{!--/).until_after(/--}}/),
            handlebars_unescaped: m.starting_with(/{{{/).until_after(/}}}/),
            handlebars: m.starting_with(/{{/).until_after(/}}/),
            php: m.starting_with(/<\?(?:[= ]|php)/).until_after(/\?>/),
            erb: m.starting_with(/<%[^%]/).until_after(/[^%]%>/),
            django: m.starting_with(/{%/).until_after(/%}/),
            django_value: m.starting_with(/{{/).until_after(/}}/),
            django_comment: m.starting_with(/{#/).until_after(/#}/),
            smarty: m.starting_with(/{(?=[^}{\s\n])/).until_after(/[^\s\n]}/),
            smarty_comment: m.starting_with(/{\*/).until_after(/\*}/),
            smarty_literal: m.starting_with(/{literal}/).until_after(/{\/literal}/)
          }
        }
        u.prototype = new l, u.prototype._create = function() {
          return new u(this._input, this)
        }, u.prototype._update = function() {
          this.__set_templated_pattern()
        }, u.prototype.disable = function(c) {
          var d = this._create();
          return d._disabled[c] = !0, d._update(), d
        }, u.prototype.read_options = function(c) {
          var d = this._create();
          for (var m in o) d._disabled[m] = c.templating.indexOf(m) === -1;
          return d._update(), d
        }, u.prototype.exclude = function(c) {
          var d = this._create();
          return d._excluded[c] = !0, d._update(), d
        }, u.prototype.read = function() {
          var c = "";
          this._match_pattern ? c = this._input.read(this._starting_pattern) : c = this._input.read(this._starting_pattern, this.__template_pattern);
          for (var d = this._read_template(); d;) this._match_pattern ? d += this._input.read(this._match_pattern) : d += this._input.readUntil(this.__template_pattern), c += d, d = this._read_template();
          return this._until_after && (c += this._input.readUntilAfter(this._until_pattern)), c
        }, u.prototype.__set_templated_pattern = function() {
          var c = [];
          this._disabled.php || c.push(this.__patterns.php._starting_pattern.source), this._disabled.handlebars || c.push(this.__patterns.handlebars._starting_pattern.source), this._disabled.erb || c.push(this.__patterns.erb._starting_pattern.source), this._disabled.django || (c.push(this.__patterns.django._starting_pattern.source), c.push(this.__patterns.django_value._starting_pattern.source), c.push(this.__patterns.django_comment._starting_pattern.source)), this._disabled.smarty || c.push(this.__patterns.smarty._starting_pattern.source), this._until_pattern && c.push(this._until_pattern.source), this.__template_pattern = this._input.get_regexp("(?:" + c.join("|") + ")")
        }, u.prototype._read_template = function() {
          var c = "",
            d = this._input.peek();
          if (d === "<") {
            var m = this._input.peek(1);
            !this._disabled.php && !this._excluded.php && m === "?" && (c = c || this.__patterns.php.read()), !this._disabled.erb && !this._excluded.erb && m === "%" && (c = c || this.__patterns.erb.read())
          } else d === "{" && (!this._disabled.handlebars && !this._excluded.handlebars && (c = c || this.__patterns.handlebars_comment.read(), c = c || this.__patterns.handlebars_unescaped.read(), c = c || this.__patterns.handlebars.read()), this._disabled.django || (!this._excluded.django && !this._excluded.handlebars && (c = c || this.__patterns.django_value.read()), this._excluded.django || (c = c || this.__patterns.django_comment.read(), c = c || this.__patterns.django.read())), this._disabled.smarty || this._disabled.django && this._disabled.handlebars && (c = c || this.__patterns.smarty_comment.read(), c = c || this.__patterns.smarty_literal.read(), c = c || this.__patterns.smarty.read()));
          return c
        }, r.exports.TemplatablePattern = u
      }), , , , (function(r, s, a) {
        var l = a(19).Beautifier,
          o = a(20).Options;

        function u(c, d, m, f) {
          var w = new l(c, d, m, f);
          return w.beautify()
        }
        r.exports = u, r.exports.defaultOptions = function() {
          return new o
        }
      }), (function(r, s, a) {
        var l = a(20).Options,
          o = a(2).Output,
          u = a(21).Tokenizer,
          c = a(21).TOKEN,
          d = /\r\n|[\r\n]/,
          m = /\r\n|[\r\n]/g,
          f = function(b, g) {
            this.indent_level = 0, this.alignment_size = 0, this.max_preserve_newlines = b.max_preserve_newlines, this.preserve_newlines = b.preserve_newlines, this._output = new o(b, g)
          };
        f.prototype.current_line_has_match = function(b) {
          return this._output.current_line.has_match(b)
        }, f.prototype.set_space_before_token = function(b, g) {
          this._output.space_before_token = b, this._output.non_breaking_space = g
        }, f.prototype.set_wrap_point = function() {
          this._output.set_indent(this.indent_level, this.alignment_size), this._output.set_wrap_point()
        }, f.prototype.add_raw_token = function(b) {
          this._output.add_raw_token(b)
        }, f.prototype.print_preserved_newlines = function(b) {
          var g = 0;
          b.type !== c.TEXT && b.previous.type !== c.TEXT && (g = b.newlines ? 1 : 0), this.preserve_newlines && (g = b.newlines < this.max_preserve_newlines + 1 ? b.newlines : this.max_preserve_newlines + 1);
          for (var _ = 0; _ < g; _++) this.print_newline(_ > 0);
          return g !== 0
        }, f.prototype.traverse_whitespace = function(b) {
          return b.whitespace_before || b.newlines ? (this.print_preserved_newlines(b) || (this._output.space_before_token = !0), !0) : !1
        }, f.prototype.previous_token_wrapped = function() {
          return this._output.previous_token_wrapped
        }, f.prototype.print_newline = function(b) {
          this._output.add_new_line(b)
        }, f.prototype.print_token = function(b) {
          b.text && (this._output.set_indent(this.indent_level, this.alignment_size), this._output.add_token(b.text))
        }, f.prototype.indent = function() {
          this.indent_level++
        }, f.prototype.deindent = function() {
          this.indent_level > 0 && (this.indent_level--, this._output.set_indent(this.indent_level, this.alignment_size))
        }, f.prototype.get_full_indent = function(b) {
          return b = this.indent_level + (b || 0), b < 1 ? "" : this._output.get_indent_string(b)
        };
        var w = function(b) {
            for (var g = null, _ = b.next; _.type !== c.EOF && b.closed !== _;) {
              if (_.type === c.ATTRIBUTE && _.text === "type") {
                _.next && _.next.type === c.EQUALS && _.next.next && _.next.next.type === c.VALUE && (g = _.next.next.text);
                break
              }
              _ = _.next
            }
            return g
          },
          p = function(b, g) {
            var _ = null,
              N = null;
            return g.closed ? (b === "script" ? _ = "text/javascript" : b === "style" && (_ = "text/css"), _ = w(g) || _, _.search("text/css") > -1 ? N = "css" : _.search(/module|((text|application|dojo)\/(x-)?(javascript|ecmascript|jscript|livescript|(ld\+)?json|method|aspect))/) > -1 ? N = "javascript" : _.search(/(text|application|dojo)\/(x-)?(html)/) > -1 ? N = "html" : _.search(/test\/null/) > -1 && (N = "null"), N) : null
          };

        function x(b, g) {
          return g.indexOf(b) !== -1
        }

        function T(b, g, _) {
          this.parent = b || null, this.tag = g ? g.tag_name : "", this.indent_level = _ || 0, this.parser_token = g || null
        }

        function y(b) {
          this._printer = b, this._current_frame = null
        }
        y.prototype.get_parser_token = function() {
          return this._current_frame ? this._current_frame.parser_token : null
        }, y.prototype.record_tag = function(b) {
          var g = new T(this._current_frame, b, this._printer.indent_level);
          this._current_frame = g
        }, y.prototype._try_pop_frame = function(b) {
          var g = null;
          return b && (g = b.parser_token, this._printer.indent_level = b.indent_level, this._current_frame = b.parent), g
        }, y.prototype._get_frame = function(b, g) {
          for (var _ = this._current_frame; _ && b.indexOf(_.tag) === -1;) {
            if (g && g.indexOf(_.tag) !== -1) {
              _ = null;
              break
            }
            _ = _.parent
          }
          return _
        }, y.prototype.try_pop = function(b, g) {
          var _ = this._get_frame([b], g);
          return this._try_pop_frame(_)
        }, y.prototype.indent_to_tag = function(b) {
          var g = this._get_frame(b);
          g && (this._printer.indent_level = g.indent_level)
        };

        function L(b, g, _, N) {
          this._source_text = b || "", g = g || {}, this._js_beautify = _, this._css_beautify = N, this._tag_stack = null;
          var S = new l(g, "html");
          this._options = S, this._is_wrap_attributes_force = this._options.wrap_attributes.substr(0, 5) === "force", this._is_wrap_attributes_force_expand_multiline = this._options.wrap_attributes === "force-expand-multiline", this._is_wrap_attributes_force_aligned = this._options.wrap_attributes === "force-aligned", this._is_wrap_attributes_aligned_multiple = this._options.wrap_attributes === "aligned-multiple", this._is_wrap_attributes_preserve = this._options.wrap_attributes.substr(0, 8) === "preserve", this._is_wrap_attributes_preserve_aligned = this._options.wrap_attributes === "preserve-aligned"
        }
        L.prototype.beautify = function() {
          if (this._options.disabled) return this._source_text;
          var b = this._source_text,
            g = this._options.eol;
          this._options.eol === "auto" && (g = `
`, b && d.test(b) && (g = b.match(d)[0])), b = b.replace(m, `
`);
          var _ = b.match(/^[\t ]*/)[0],
            N = {
              text: "",
              type: ""
            },
            S = new I,
            v = new f(this._options, _),
            A = new u(b, this._options).tokenize();
          this._tag_stack = new y(v);
          for (var D = null, k = A.next(); k.type !== c.EOF;) k.type === c.TAG_OPEN || k.type === c.COMMENT ? (D = this._handle_tag_open(v, k, S, N, A), S = D) : k.type === c.ATTRIBUTE || k.type === c.EQUALS || k.type === c.VALUE || k.type === c.TEXT && !S.tag_complete ? D = this._handle_inside_tag(v, k, S, N) : k.type === c.TAG_CLOSE ? D = this._handle_tag_close(v, k, S) : k.type === c.TEXT ? D = this._handle_text(v, k, S) : k.type === c.CONTROL_FLOW_OPEN ? D = this._handle_control_flow_open(v, k) : k.type === c.CONTROL_FLOW_CLOSE ? D = this._handle_control_flow_close(v, k) : v.add_raw_token(k), N = D, k = A.next();
          var E = v._output.get_code(g);
          return E
        }, L.prototype._handle_control_flow_open = function(b, g) {
          var _ = {
            text: g.text,
            type: g.type
          };
          return b.set_space_before_token(g.newlines || g.whitespace_before !== "", !0), g.newlines ? b.print_preserved_newlines(g) : b.set_space_before_token(g.newlines || g.whitespace_before !== "", !0), b.print_token(g), b.indent(), _
        }, L.prototype._handle_control_flow_close = function(b, g) {
          var _ = {
            text: g.text,
            type: g.type
          };
          return b.deindent(), g.newlines ? b.print_preserved_newlines(g) : b.set_space_before_token(g.newlines || g.whitespace_before !== "", !0), b.print_token(g), _
        }, L.prototype._handle_tag_close = function(b, g, _) {
          var N = {
            text: g.text,
            type: g.type
          };
          return b.alignment_size = 0, _.tag_complete = !0, b.set_space_before_token(g.newlines || g.whitespace_before !== "", !0), _.is_unformatted ? b.add_raw_token(g) : (_.tag_start_char === "<" && (b.set_space_before_token(g.text[0] === "/", !0), this._is_wrap_attributes_force_expand_multiline && _.has_wrapped_attrs && b.print_newline(!1)), b.print_token(g)), _.indent_content && !(_.is_unformatted || _.is_content_unformatted) && (b.indent(), _.indent_content = !1), !_.is_inline_element && !(_.is_unformatted || _.is_content_unformatted) && b.set_wrap_point(), N
        }, L.prototype._handle_inside_tag = function(b, g, _, N) {
          var S = _.has_wrapped_attrs,
            v = {
              text: g.text,
              type: g.type
            };
          return b.set_space_before_token(g.newlines || g.whitespace_before !== "", !0), _.is_unformatted ? b.add_raw_token(g) : _.tag_start_char === "{" && g.type === c.TEXT ? b.print_preserved_newlines(g) ? (g.newlines = 0, b.add_raw_token(g)) : b.print_token(g) : (g.type === c.ATTRIBUTE ? b.set_space_before_token(!0) : (g.type === c.EQUALS || g.type === c.VALUE && g.previous.type === c.EQUALS) && b.set_space_before_token(!1), g.type === c.ATTRIBUTE && _.tag_start_char === "<" && ((this._is_wrap_attributes_preserve || this._is_wrap_attributes_preserve_aligned) && (b.traverse_whitespace(g), S = S || g.newlines !== 0), this._is_wrap_attributes_force && _.attr_count >= this._options.wrap_attributes_min_attrs && (N.type !== c.TAG_OPEN || this._is_wrap_attributes_force_expand_multiline) && (b.print_newline(!1), S = !0)), b.print_token(g), S = S || b.previous_token_wrapped(), _.has_wrapped_attrs = S), v
        }, L.prototype._handle_text = function(b, g, _) {
          var N = {
            text: g.text,
            type: "TK_CONTENT"
          };
          return _.custom_beautifier_name ? this._print_custom_beatifier_text(b, g, _) : _.is_unformatted || _.is_content_unformatted ? b.add_raw_token(g) : (b.traverse_whitespace(g), b.print_token(g)), N
        }, L.prototype._print_custom_beatifier_text = function(b, g, _) {
          var N = this;
          if (g.text !== "") {
            var S = g.text,
              v, A = 1,
              D = "",
              k = "";
            _.custom_beautifier_name === "javascript" && typeof this._js_beautify == "function" ? v = this._js_beautify : _.custom_beautifier_name === "css" && typeof this._css_beautify == "function" ? v = this._css_beautify : _.custom_beautifier_name === "html" && (v = function(O, Z) {
              var Y = new L(O, Z, N._js_beautify, N._css_beautify);
              return Y.beautify()
            }), this._options.indent_scripts === "keep" ? A = 0 : this._options.indent_scripts === "separate" && (A = -b.indent_level);
            var E = b.get_full_indent(A);
            if (S = S.replace(/\n[ \t]*$/, ""), _.custom_beautifier_name !== "html" && S[0] === "<" && S.match(/^(<!--|<!\[CDATA\[)/)) {
              var M = /^(<!--[^\n]*|<!\[CDATA\[)(\n?)([ \t\n]*)([\s\S]*)(-->|]]>)$/.exec(S);
              if (!M) {
                b.add_raw_token(g);
                return
              }
              D = E + M[1] + `
`, S = M[4], M[5] && (k = E + M[5]), S = S.replace(/\n[ \t]*$/, ""), (M[2] || M[3].indexOf(`
`) !== -1) && (M = M[3].match(/[ \t]+$/), M && (g.whitespace_before = M[0]))
            }
            if (S)
              if (v) {
                var W = function() {
                  this.eol = `
`
                };
                W.prototype = this._options.raw_options;
                var F = new W;
                S = v(E + S, F)
              } else {
                var U = g.whitespace_before;
                U && (S = S.replace(new RegExp(`
(` + U + ")?", "g"), `
`)), S = E + S.replace(/\n/g, `
` + E)
              } D && (S ? S = D + S + `
` + k : S = D + k), b.print_newline(!1), S && (g.text = S, g.whitespace_before = "", g.newlines = 0, b.add_raw_token(g), b.print_newline(!0))
          }
        }, L.prototype._handle_tag_open = function(b, g, _, N, S) {
          var v = this._get_tag_open_token(g);
          if ((_.is_unformatted || _.is_content_unformatted) && !_.is_empty_element && g.type === c.TAG_OPEN && !v.is_start_tag ? (b.add_raw_token(g), v.start_tag_token = this._tag_stack.try_pop(v.tag_name)) : (b.traverse_whitespace(g), this._set_tag_position(b, g, v, _, N), v.is_inline_element || b.set_wrap_point(), b.print_token(g)), v.is_start_tag && this._is_wrap_attributes_force) {
            var A = 0,
              D;
            do D = S.peek(A), D.type === c.ATTRIBUTE && (v.attr_count += 1), A += 1; while (D.type !== c.EOF && D.type !== c.TAG_CLOSE)
          }
          return (this._is_wrap_attributes_force_aligned || this._is_wrap_attributes_aligned_multiple || this._is_wrap_attributes_preserve_aligned) && (v.alignment_size = g.text.length + 1), !v.tag_complete && !v.is_unformatted && (b.alignment_size = v.alignment_size), v
        };
        var I = function(b, g) {
          if (this.parent = b || null, this.text = "", this.type = "TK_TAG_OPEN", this.tag_name = "", this.is_inline_element = !1, this.is_unformatted = !1, this.is_content_unformatted = !1, this.is_empty_element = !1, this.is_start_tag = !1, this.is_end_tag = !1, this.indent_content = !1, this.multiline_content = !1, this.custom_beautifier_name = null, this.start_tag_token = null, this.attr_count = 0, this.has_wrapped_attrs = !1, this.alignment_size = 0, this.tag_complete = !1, this.tag_start_char = "", this.tag_check = "", !g) this.tag_complete = !0;
          else {
            var _;
            this.tag_start_char = g.text[0], this.text = g.text, this.tag_start_char === "<" ? (_ = g.text.match(/^<([^\s>]*)/), this.tag_check = _ ? _[1] : "") : (_ = g.text.match(/^{{~?(?:[\^]|#\*?)?([^\s}]+)/), this.tag_check = _ ? _[1] : "", (g.text.startsWith("{{#>") || g.text.startsWith("{{~#>")) && this.tag_check[0] === ">" && (this.tag_check === ">" && g.next !== null ? this.tag_check = g.next.text.split(" ")[0] : this.tag_check = g.text.split(">")[1])), this.tag_check = this.tag_check.toLowerCase(), g.type === c.COMMENT && (this.tag_complete = !0), this.is_start_tag = this.tag_check.charAt(0) !== "/", this.tag_name = this.is_start_tag ? this.tag_check : this.tag_check.substr(1), this.is_end_tag = !this.is_start_tag || g.closed && g.closed.text === "/>";
            var N = 2;
            this.tag_start_char === "{" && this.text.length >= 3 && this.text.charAt(2) === "~" && (N = 3), this.is_end_tag = this.is_end_tag || this.tag_start_char === "{" && (this.text.length < 3 || /[^#\^]/.test(this.text.charAt(N)))
          }
        };
        L.prototype._get_tag_open_token = function(b) {
          var g = new I(this._tag_stack.get_parser_token(), b);
          return g.alignment_size = this._options.wrap_attributes_indent_size, g.is_end_tag = g.is_end_tag || x(g.tag_check, this._options.void_elements), g.is_empty_element = g.tag_complete || g.is_start_tag && g.is_end_tag, g.is_unformatted = !g.tag_complete && x(g.tag_check, this._options.unformatted), g.is_content_unformatted = !g.is_empty_element && x(g.tag_check, this._options.content_unformatted), g.is_inline_element = x(g.tag_name, this._options.inline) || this._options.inline_custom_elements && g.tag_name.includes("-") || g.tag_start_char === "{", g
        }, L.prototype._set_tag_position = function(b, g, _, N, S) {
          if (_.is_empty_element || (_.is_end_tag ? _.start_tag_token = this._tag_stack.try_pop(_.tag_name) : (this._do_optional_end_element(_) && (_.is_inline_element || b.print_newline(!1)), this._tag_stack.record_tag(_), (_.tag_name === "script" || _.tag_name === "style") && !(_.is_unformatted || _.is_content_unformatted) && (_.custom_beautifier_name = p(_.tag_check, g)))), x(_.tag_check, this._options.extra_liners) && (b.print_newline(!1), b._output.just_added_blankline() || b.print_newline(!0)), _.is_empty_element) {
            if (_.tag_start_char === "{" && _.tag_check === "else") {
              this._tag_stack.indent_to_tag(["if", "unless", "each"]), _.indent_content = !0;
              var v = b.current_line_has_match(/{{#if/);
              v || b.print_newline(!1)
            }
            _.tag_name === "!--" && S.type === c.TAG_CLOSE && N.is_end_tag && _.text.indexOf(`
`) === -1 || (_.is_inline_element || _.is_unformatted || b.print_newline(!1), this._calcluate_parent_multiline(b, _))
          } else if (_.is_end_tag) {
            var A = !1;
            A = _.start_tag_token && _.start_tag_token.multiline_content, A = A || !_.is_inline_element && !(N.is_inline_element || N.is_unformatted) && !(S.type === c.TAG_CLOSE && _.start_tag_token === N) && S.type !== "TK_CONTENT", (_.is_content_unformatted || _.is_unformatted) && (A = !1), A && b.print_newline(!1)
          } else _.indent_content = !_.custom_beautifier_name, _.tag_start_char === "<" && (_.tag_name === "html" ? _.indent_content = this._options.indent_inner_html : _.tag_name === "head" ? _.indent_content = this._options.indent_head_inner_html : _.tag_name === "body" && (_.indent_content = this._options.indent_body_inner_html)), !(_.is_inline_element || _.is_unformatted) && (S.type !== "TK_CONTENT" || _.is_content_unformatted) && b.print_newline(!1), this._calcluate_parent_multiline(b, _)
        }, L.prototype._calcluate_parent_multiline = function(b, g) {
          g.parent && b._output.just_added_newline() && !((g.is_inline_element || g.is_unformatted) && g.parent.is_inline_element) && (g.parent.multiline_content = !0)
        };
        var H = ["address", "article", "aside", "blockquote", "details", "div", "dl", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hr", "main", "menu", "nav", "ol", "p", "pre", "section", "table", "ul"],
          P = ["a", "audio", "del", "ins", "map", "noscript", "video"];
        L.prototype._do_optional_end_element = function(b) {
          var g = null;
          if (!(b.is_empty_element || !b.is_start_tag || !b.parent)) {
            if (b.tag_name === "body") g = g || this._tag_stack.try_pop("head");
            else if (b.tag_name === "li") g = g || this._tag_stack.try_pop("li", ["ol", "ul", "menu"]);
            else if (b.tag_name === "dd" || b.tag_name === "dt") g = g || this._tag_stack.try_pop("dt", ["dl"]), g = g || this._tag_stack.try_pop("dd", ["dl"]);
            else if (b.parent.tag_name === "p" && H.indexOf(b.tag_name) !== -1) {
              var _ = b.parent.parent;
              (!_ || P.indexOf(_.tag_name) === -1) && (g = g || this._tag_stack.try_pop("p"))
            } else b.tag_name === "rp" || b.tag_name === "rt" ? (g = g || this._tag_stack.try_pop("rt", ["ruby", "rtc"]), g = g || this._tag_stack.try_pop("rp", ["ruby", "rtc"])) : b.tag_name === "optgroup" ? g = g || this._tag_stack.try_pop("optgroup", ["select"]) : b.tag_name === "option" ? g = g || this._tag_stack.try_pop("option", ["select", "datalist", "optgroup"]) : b.tag_name === "colgroup" ? g = g || this._tag_stack.try_pop("caption", ["table"]) : b.tag_name === "thead" ? (g = g || this._tag_stack.try_pop("caption", ["table"]), g = g || this._tag_stack.try_pop("colgroup", ["table"])) : b.tag_name === "tbody" || b.tag_name === "tfoot" ? (g = g || this._tag_stack.try_pop("caption", ["table"]), g = g || this._tag_stack.try_pop("colgroup", ["table"]), g = g || this._tag_stack.try_pop("thead", ["table"]), g = g || this._tag_stack.try_pop("tbody", ["table"])) : b.tag_name === "tr" ? (g = g || this._tag_stack.try_pop("caption", ["table"]), g = g || this._tag_stack.try_pop("colgroup", ["table"]), g = g || this._tag_stack.try_pop("tr", ["table", "thead", "tbody", "tfoot"])) : (b.tag_name === "th" || b.tag_name === "td") && (g = g || this._tag_stack.try_pop("td", ["table", "thead", "tbody", "tfoot", "tr"]), g = g || this._tag_stack.try_pop("th", ["table", "thead", "tbody", "tfoot", "tr"]));
            return b.parent = this._tag_stack.get_parser_token(), g
          }
        }, r.exports.Beautifier = L
      }), (function(r, s, a) {
        var l = a(6).Options;

        function o(u) {
          l.call(this, u, "html"), this.templating.length === 1 && this.templating[0] === "auto" && (this.templating = ["django", "erb", "handlebars", "php"]), this.indent_inner_html = this._get_boolean("indent_inner_html"), this.indent_body_inner_html = this._get_boolean("indent_body_inner_html", !0), this.indent_head_inner_html = this._get_boolean("indent_head_inner_html", !0), this.indent_handlebars = this._get_boolean("indent_handlebars", !0), this.wrap_attributes = this._get_selection("wrap_attributes", ["auto", "force", "force-aligned", "force-expand-multiline", "aligned-multiple", "preserve", "preserve-aligned"]), this.wrap_attributes_min_attrs = this._get_number("wrap_attributes_min_attrs", 2), this.wrap_attributes_indent_size = this._get_number("wrap_attributes_indent_size", this.indent_size), this.extra_liners = this._get_array("extra_liners", ["head", "body", "/html"]), this.inline = this._get_array("inline", ["a", "abbr", "area", "audio", "b", "bdi", "bdo", "br", "button", "canvas", "cite", "code", "data", "datalist", "del", "dfn", "em", "embed", "i", "iframe", "img", "input", "ins", "kbd", "keygen", "label", "map", "mark", "math", "meter", "noscript", "object", "output", "progress", "q", "ruby", "s", "samp", "select", "small", "span", "strong", "sub", "sup", "svg", "template", "textarea", "time", "u", "var", "video", "wbr", "text", "acronym", "big", "strike", "tt"]), this.inline_custom_elements = this._get_boolean("inline_custom_elements", !0), this.void_elements = this._get_array("void_elements", ["area", "base", "br", "col", "embed", "hr", "img", "input", "keygen", "link", "menuitem", "meta", "param", "source", "track", "wbr", "!doctype", "?xml", "basefont", "isindex"]), this.unformatted = this._get_array("unformatted", []), this.content_unformatted = this._get_array("content_unformatted", ["pre", "textarea"]), this.unformatted_content_delimiter = this._get_characters("unformatted_content_delimiter"), this.indent_scripts = this._get_selection("indent_scripts", ["normal", "keep", "separate"])
        }
        o.prototype = new l, r.exports.Options = o
      }), (function(r, s, a) {
        var l = a(9).Tokenizer,
          o = a(9).TOKEN,
          u = a(13).Directives,
          c = a(14).TemplatablePattern,
          d = a(12).Pattern,
          m = {
            TAG_OPEN: "TK_TAG_OPEN",
            TAG_CLOSE: "TK_TAG_CLOSE",
            CONTROL_FLOW_OPEN: "TK_CONTROL_FLOW_OPEN",
            CONTROL_FLOW_CLOSE: "TK_CONTROL_FLOW_CLOSE",
            ATTRIBUTE: "TK_ATTRIBUTE",
            EQUALS: "TK_EQUALS",
            VALUE: "TK_VALUE",
            COMMENT: "TK_COMMENT",
            TEXT: "TK_TEXT",
            UNKNOWN: "TK_UNKNOWN",
            START: o.START,
            RAW: o.RAW,
            EOF: o.EOF
          },
          f = new u(/<\!--/, /-->/),
          w = function(p, x) {
            l.call(this, p, x), this._current_tag_name = "";
            var T = new c(this._input).read_options(this._options),
              y = new d(this._input);
            if (this.__patterns = {
                word: T.until(/[\n\r\t <]/),
                word_control_flow_close_excluded: T.until(/[\n\r\t <}]/),
                single_quote: T.until_after(/'/),
                double_quote: T.until_after(/"/),
                attribute: T.until(/[\n\r\t =>]|\/>/),
                element_name: T.until(/[\n\r\t >\/]/),
                angular_control_flow_start: y.matching(/\@[a-zA-Z]+[^({]*[({]/),
                handlebars_comment: y.starting_with(/{{!--/).until_after(/--}}/),
                handlebars: y.starting_with(/{{/).until_after(/}}/),
                handlebars_open: y.until(/[\n\r\t }]/),
                handlebars_raw_close: y.until(/}}/),
                comment: y.starting_with(/<!--/).until_after(/-->/),
                cdata: y.starting_with(/<!\[CDATA\[/).until_after(/]]>/),
                conditional_comment: y.starting_with(/<!\[/).until_after(/]>/),
                processing: y.starting_with(/<\?/).until_after(/\?>/)
              }, this._options.indent_handlebars && (this.__patterns.word = this.__patterns.word.exclude("handlebars"), this.__patterns.word_control_flow_close_excluded = this.__patterns.word_control_flow_close_excluded.exclude("handlebars")), this._unformatted_content_delimiter = null, this._options.unformatted_content_delimiter) {
              var L = this._input.get_literal_regexp(this._options.unformatted_content_delimiter);
              this.__patterns.unformatted_content_delimiter = y.matching(L).until_after(L)
            }
          };
        w.prototype = new l, w.prototype._is_comment = function(p) {
          return !1
        }, w.prototype._is_opening = function(p) {
          return p.type === m.TAG_OPEN || p.type === m.CONTROL_FLOW_OPEN
        }, w.prototype._is_closing = function(p, x) {
          return p.type === m.TAG_CLOSE && x && ((p.text === ">" || p.text === "/>") && x.text[0] === "<" || p.text === "}}" && x.text[0] === "{" && x.text[1] === "{") || p.type === m.CONTROL_FLOW_CLOSE && p.text === "}" && x.text.endsWith("{")
        }, w.prototype._reset = function() {
          this._current_tag_name = ""
        }, w.prototype._get_next_token = function(p, x) {
          var T = null;
          this._readWhitespace();
          var y = this._input.peek();
          return y === null ? this._create_token(m.EOF, "") : (T = T || this._read_open_handlebars(y, x), T = T || this._read_attribute(y, p, x), T = T || this._read_close(y, x), T = T || this._read_control_flows(y, x), T = T || this._read_raw_content(y, p, x), T = T || this._read_content_word(y, x), T = T || this._read_comment_or_cdata(y), T = T || this._read_processing(y), T = T || this._read_open(y, x), T = T || this._create_token(m.UNKNOWN, this._input.next()), T)
        }, w.prototype._read_comment_or_cdata = function(p) {
          var x = null,
            T = null,
            y = null;
          if (p === "<") {
            var L = this._input.peek(1);
            L === "!" && (T = this.__patterns.comment.read(), T ? (y = f.get_directives(T), y && y.ignore === "start" && (T += f.readIgnored(this._input))) : T = this.__patterns.cdata.read()), T && (x = this._create_token(m.COMMENT, T), x.directives = y)
          }
          return x
        }, w.prototype._read_processing = function(p) {
          var x = null,
            T = null,
            y = null;
          if (p === "<") {
            var L = this._input.peek(1);
            (L === "!" || L === "?") && (T = this.__patterns.conditional_comment.read(), T = T || this.__patterns.processing.read()), T && (x = this._create_token(m.COMMENT, T), x.directives = y)
          }
          return x
        }, w.prototype._read_open = function(p, x) {
          var T = null,
            y = null;
          return (!x || x.type === m.CONTROL_FLOW_OPEN) && p === "<" && (T = this._input.next(), this._input.peek() === "/" && (T += this._input.next()), T += this.__patterns.element_name.read(), y = this._create_token(m.TAG_OPEN, T)), y
        }, w.prototype._read_open_handlebars = function(p, x) {
          var T = null,
            y = null;
          return (!x || x.type === m.CONTROL_FLOW_OPEN) && this._options.indent_handlebars && p === "{" && this._input.peek(1) === "{" && (this._input.peek(2) === "!" ? (T = this.__patterns.handlebars_comment.read(), T = T || this.__patterns.handlebars.read(), y = this._create_token(m.COMMENT, T)) : (T = this.__patterns.handlebars_open.read(), y = this._create_token(m.TAG_OPEN, T))), y
        }, w.prototype._read_control_flows = function(p, x) {
          var T = "",
            y = null;
          if (!this._options.templating.includes("angular") || !this._options.indent_handlebars) return y;
          if (p === "@") {
            if (T = this.__patterns.angular_control_flow_start.read(), T === "") return y;
            for (var L = T.endsWith("(") ? 1 : 0, I = 0; !(T.endsWith("{") && L === I);) {
              var H = this._input.next();
              if (H === null) break;
              H === "(" ? L++ : H === ")" && I++, T += H
            }
            y = this._create_token(m.CONTROL_FLOW_OPEN, T)
          } else p === "}" && x && x.type === m.CONTROL_FLOW_OPEN && (T = this._input.next(), y = this._create_token(m.CONTROL_FLOW_CLOSE, T));
          return y
        }, w.prototype._read_close = function(p, x) {
          var T = null,
            y = null;
          return x && x.type === m.TAG_OPEN && (x.text[0] === "<" && (p === ">" || p === "/" && this._input.peek(1) === ">") ? (T = this._input.next(), p === "/" && (T += this._input.next()), y = this._create_token(m.TAG_CLOSE, T)) : x.text[0] === "{" && p === "}" && this._input.peek(1) === "}" && (this._input.next(), this._input.next(), y = this._create_token(m.TAG_CLOSE, "}}"))), y
        }, w.prototype._read_attribute = function(p, x, T) {
          var y = null,
            L = "";
          if (T && T.text[0] === "<")
            if (p === "=") y = this._create_token(m.EQUALS, this._input.next());
            else if (p === '"' || p === "'") {
            var I = this._input.next();
            p === '"' ? I += this.__patterns.double_quote.read() : I += this.__patterns.single_quote.read(), y = this._create_token(m.VALUE, I)
          } else L = this.__patterns.attribute.read(), L && (x.type === m.EQUALS ? y = this._create_token(m.VALUE, L) : y = this._create_token(m.ATTRIBUTE, L));
          return y
        }, w.prototype._is_content_unformatted = function(p) {
          return this._options.void_elements.indexOf(p) === -1 && (this._options.content_unformatted.indexOf(p) !== -1 || this._options.unformatted.indexOf(p) !== -1)
        }, w.prototype._read_raw_content = function(p, x, T) {
          var y = "";
          if (T && T.text[0] === "{") y = this.__patterns.handlebars_raw_close.read();
          else if (x.type === m.TAG_CLOSE && x.opened.text[0] === "<" && x.text[0] !== "/") {
            var L = x.opened.text.substr(1).toLowerCase();
            if (L === "script" || L === "style") {
              var I = this._read_comment_or_cdata(p);
              if (I) return I.type = m.TEXT, I;
              y = this._input.readUntil(new RegExp("</" + L + "[\\n\\r\\t ]*?>", "ig"))
            } else this._is_content_unformatted(L) && (y = this._input.readUntil(new RegExp("</" + L + "[\\n\\r\\t ]*?>", "ig")))
          }
          return y ? this._create_token(m.TEXT, y) : null
        }, w.prototype._read_content_word = function(p, x) {
          var T = "";
          if (this._options.unformatted_content_delimiter && p === this._options.unformatted_content_delimiter[0] && (T = this.__patterns.unformatted_content_delimiter.read()), T || (T = x && x.type === m.CONTROL_FLOW_OPEN ? this.__patterns.word_control_flow_close_excluded.read() : this.__patterns.word.read()), T) return this._create_token(m.TEXT, T)
        }, r.exports.Tokenizer = w, r.exports.TOKEN = m
      })],
      e = {};

    function n(r) {
      var s = e[r];
      if (s !== void 0) return s.exports;
      var a = e[r] = {
        exports: {}
      };
      return t[r](a, a.exports, n), a.exports
    }
    var i = n(18);
    Qa = i
  })();

  function Hc(t, e) {
    return Qa(t, e, Ic, zc)
  }

  function Uc(t, e, n) {
    let i = t.getText(),
      r = !0,
      s = 0;
    const a = n.tabSize || 4;
    if (e) {
      let u = t.offsetAt(e.start),
        c = u;
      for (; c > 0 && Za(i, c - 1);) c--;
      c === 0 || Ya(i, c - 1) ? u = c : c < u && (u = c + 1);
      let d = t.offsetAt(e.end),
        m = d;
      for (; m < i.length && Za(i, m);) m++;
      (m === i.length || Ya(i, m)) && (d = m), e = J.create(t.positionAt(u), t.positionAt(d));
      const f = i.substring(0, u);
      if (new RegExp(/.*[<][^>]*$/).test(f)) return i = i.substring(u, d), [{
        range: e,
        newText: i
      }];
      if (r = d === i.length, i = i.substring(u, d), u !== 0) {
        const w = t.offsetAt(se.create(e.start.line, 0));
        s = Fc(t.getText(), w, n)
      }
    } else e = J.create(se.create(0, 0), t.positionAt(i.length));
    const l = {
      indent_size: a,
      indent_char: n.insertSpaces ? " " : "	",
      indent_empty_lines: we(n, "indentEmptyLines", !1),
      wrap_line_length: we(n, "wrapLineLength", 120),
      unformatted: Ni(n, "unformatted", void 0),
      content_unformatted: Ni(n, "contentUnformatted", void 0),
      indent_inner_html: we(n, "indentInnerHtml", !1),
      preserve_newlines: we(n, "preserveNewLines", !0),
      max_preserve_newlines: we(n, "maxPreserveNewLines", 32786),
      indent_handlebars: we(n, "indentHandlebars", !1),
      end_with_newline: r && we(n, "endWithNewline", !1),
      extra_liners: Ni(n, "extraLiners", void 0),
      wrap_attributes: we(n, "wrapAttributes", "auto"),
      wrap_attributes_indent_size: we(n, "wrapAttributesIndentSize", void 0),
      eol: `
`,
      indent_scripts: we(n, "indentScripts", "normal"),
      templating: Wc(n, "all"),
      unformatted_content_delimiter: we(n, "unformattedContentDelimiter", "")
    };
    let o = Hc(Pc(i), l);
    if (s > 0) {
      const u = n.insertSpaces ? $a(" ", a * s) : $a("	", s);
      o = o.split(`
`).join(`
` + u), e.start.character === 0 && (o = u + o)
    }
    return [{
      range: e,
      newText: o
    }]
  }

  function Pc(t) {
    return t.replace(/^\s+/, "")
  }

  function we(t, e, n) {
    if (t && t.hasOwnProperty(e)) {
      const i = t[e];
      if (i !== null) return i
    }
    return n
  }

  function Ni(t, e, n) {
    const i = we(t, e, null);
    return typeof i == "string" ? i.length > 0 ? i.split(",").map(r => r.trim().toLowerCase()) : [] : n
  }

  function Wc(t, e) {
    const n = we(t, "templating", e);
    return n === !0 ? ["auto"] : n === !1 || n === e || Array.isArray(n) === !1 ? ["none"] : n
  }

  function Fc(t, e, n) {
    let i = e,
      r = 0;
    const s = n.tabSize || 4;
    for (; i < t.length;) {
      const a = t.charAt(i);
      if (a === " ") r++;
      else if (a === "	") r += s;
      else break;
      i++
    }
    return Math.floor(r / s)
  }

  function Ya(t, e) {
    return `\r
`.indexOf(t.charAt(e)) !== -1
  }

  function Za(t, e) {
    return " 	".indexOf(t.charAt(e)) !== -1
  }
  var Ka;
  (() => {
    var t = {
        470: r => {
          function s(o) {
            if (typeof o != "string") throw new TypeError("Path must be a string. Received " + JSON.stringify(o))
          }

          function a(o, u) {
            for (var c, d = "", m = 0, f = -1, w = 0, p = 0; p <= o.length; ++p) {
              if (p < o.length) c = o.charCodeAt(p);
              else {
                if (c === 47) break;
                c = 47
              }
              if (c === 47) {
                if (!(f === p - 1 || w === 1))
                  if (f !== p - 1 && w === 2) {
                    if (d.length < 2 || m !== 2 || d.charCodeAt(d.length - 1) !== 46 || d.charCodeAt(d.length - 2) !== 46) {
                      if (d.length > 2) {
                        var x = d.lastIndexOf("/");
                        if (x !== d.length - 1) {
                          x === -1 ? (d = "", m = 0) : m = (d = d.slice(0, x)).length - 1 - d.lastIndexOf("/"), f = p, w = 0;
                          continue
                        }
                      } else if (d.length === 2 || d.length === 1) {
                        d = "", m = 0, f = p, w = 0;
                        continue
                      }
                    }
                    u && (d.length > 0 ? d += "/.." : d = "..", m = 2)
                  } else d.length > 0 ? d += "/" + o.slice(f + 1, p) : d = o.slice(f + 1, p), m = p - f - 1;
                f = p, w = 0
              } else c === 46 && w !== -1 ? ++w : w = -1
            }
            return d
          }
          var l = {
            resolve: function() {
              for (var o, u = "", c = !1, d = arguments.length - 1; d >= -1 && !c; d--) {
                var m;
                d >= 0 ? m = arguments[d] : (o === void 0 && (o = process.cwd()), m = o), s(m), m.length !== 0 && (u = m + "/" + u, c = m.charCodeAt(0) === 47)
              }
              return u = a(u, !c), c ? u.length > 0 ? "/" + u : "/" : u.length > 0 ? u : "."
            },
            normalize: function(o) {
              if (s(o), o.length === 0) return ".";
              var u = o.charCodeAt(0) === 47,
                c = o.charCodeAt(o.length - 1) === 47;
              return (o = a(o, !u)).length !== 0 || u || (o = "."), o.length > 0 && c && (o += "/"), u ? "/" + o : o
            },
            isAbsolute: function(o) {
              return s(o), o.length > 0 && o.charCodeAt(0) === 47
            },
            join: function() {
              if (arguments.length === 0) return ".";
              for (var o, u = 0; u < arguments.length; ++u) {
                var c = arguments[u];
                s(c), c.length > 0 && (o === void 0 ? o = c : o += "/" + c)
              }
              return o === void 0 ? "." : l.normalize(o)
            },
            relative: function(o, u) {
              if (s(o), s(u), o === u || (o = l.resolve(o)) === (u = l.resolve(u))) return "";
              for (var c = 1; c < o.length && o.charCodeAt(c) === 47; ++c);
              for (var d = o.length, m = d - c, f = 1; f < u.length && u.charCodeAt(f) === 47; ++f);
              for (var w = u.length - f, p = m < w ? m : w, x = -1, T = 0; T <= p; ++T) {
                if (T === p) {
                  if (w > p) {
                    if (u.charCodeAt(f + T) === 47) return u.slice(f + T + 1);
                    if (T === 0) return u.slice(f + T)
                  } else m > p && (o.charCodeAt(c + T) === 47 ? x = T : T === 0 && (x = 0));
                  break
                }
                var y = o.charCodeAt(c + T);
                if (y !== u.charCodeAt(f + T)) break;
                y === 47 && (x = T)
              }
              var L = "";
              for (T = c + x + 1; T <= d; ++T) T !== d && o.charCodeAt(T) !== 47 || (L.length === 0 ? L += ".." : L += "/..");
              return L.length > 0 ? L + u.slice(f + x) : (f += x, u.charCodeAt(f) === 47 && ++f, u.slice(f))
            },
            _makeLong: function(o) {
              return o
            },
            dirname: function(o) {
              if (s(o), o.length === 0) return ".";
              for (var u = o.charCodeAt(0), c = u === 47, d = -1, m = !0, f = o.length - 1; f >= 1; --f)
                if ((u = o.charCodeAt(f)) === 47) {
                  if (!m) {
                    d = f;
                    break
                  }
                } else m = !1;
              return d === -1 ? c ? "/" : "." : c && d === 1 ? "//" : o.slice(0, d)
            },
            basename: function(o, u) {
              if (u !== void 0 && typeof u != "string") throw new TypeError('"ext" argument must be a string');
              s(o);
              var c, d = 0,
                m = -1,
                f = !0;
              if (u !== void 0 && u.length > 0 && u.length <= o.length) {
                if (u.length === o.length && u === o) return "";
                var w = u.length - 1,
                  p = -1;
                for (c = o.length - 1; c >= 0; --c) {
                  var x = o.charCodeAt(c);
                  if (x === 47) {
                    if (!f) {
                      d = c + 1;
                      break
                    }
                  } else p === -1 && (f = !1, p = c + 1), w >= 0 && (x === u.charCodeAt(w) ? --w == -1 && (m = c) : (w = -1, m = p))
                }
                return d === m ? m = p : m === -1 && (m = o.length), o.slice(d, m)
              }
              for (c = o.length - 1; c >= 0; --c)
                if (o.charCodeAt(c) === 47) {
                  if (!f) {
                    d = c + 1;
                    break
                  }
                } else m === -1 && (f = !1, m = c + 1);
              return m === -1 ? "" : o.slice(d, m)
            },
            extname: function(o) {
              s(o);
              for (var u = -1, c = 0, d = -1, m = !0, f = 0, w = o.length - 1; w >= 0; --w) {
                var p = o.charCodeAt(w);
                if (p !== 47) d === -1 && (m = !1, d = w + 1), p === 46 ? u === -1 ? u = w : f !== 1 && (f = 1) : u !== -1 && (f = -1);
                else if (!m) {
                  c = w + 1;
                  break
                }
              }
              return u === -1 || d === -1 || f === 0 || f === 1 && u === d - 1 && u === c + 1 ? "" : o.slice(u, d)
            },
            format: function(o) {
              if (o === null || typeof o != "object") throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof o);
              return (function(u, c) {
                var d = c.dir || c.root,
                  m = c.base || (c.name || "") + (c.ext || "");
                return d ? d === c.root ? d + m : d + "/" + m : m
              })(0, o)
            },
            parse: function(o) {
              s(o);
              var u = {
                root: "",
                dir: "",
                base: "",
                ext: "",
                name: ""
              };
              if (o.length === 0) return u;
              var c, d = o.charCodeAt(0),
                m = d === 47;
              m ? (u.root = "/", c = 1) : c = 0;
              for (var f = -1, w = 0, p = -1, x = !0, T = o.length - 1, y = 0; T >= c; --T)
                if ((d = o.charCodeAt(T)) !== 47) p === -1 && (x = !1, p = T + 1), d === 46 ? f === -1 ? f = T : y !== 1 && (y = 1) : f !== -1 && (y = -1);
                else if (!x) {
                w = T + 1;
                break
              }
              return f === -1 || p === -1 || y === 0 || y === 1 && f === p - 1 && f === w + 1 ? p !== -1 && (u.base = u.name = w === 0 && m ? o.slice(1, p) : o.slice(w, p)) : (w === 0 && m ? (u.name = o.slice(1, f), u.base = o.slice(1, p)) : (u.name = o.slice(w, f), u.base = o.slice(w, p)), u.ext = o.slice(f, p)), w > 0 ? u.dir = o.slice(0, w - 1) : m && (u.dir = "/"), u
            },
            sep: "/",
            delimiter: ":",
            win32: null,
            posix: null
          };
          l.posix = l, r.exports = l
        }
      },
      e = {};

    function n(r) {
      var s = e[r];
      if (s !== void 0) return s.exports;
      var a = e[r] = {
        exports: {}
      };
      return t[r](a, a.exports, n), a.exports
    }
    n.d = (r, s) => {
      for (var a in s) n.o(s, a) && !n.o(r, a) && Object.defineProperty(r, a, {
        enumerable: !0,
        get: s[a]
      })
    }, n.o = (r, s) => Object.prototype.hasOwnProperty.call(r, s), n.r = r => {
      typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(r, Symbol.toStringTag, {
        value: "Module"
      }), Object.defineProperty(r, "__esModule", {
        value: !0
      })
    };
    var i = {};
    (() => {
      let r;
      n.r(i), n.d(i, {
        URI: () => m,
        Utils: () => N
      }), typeof process == "object" ? r = process.platform === "win32" : typeof navigator == "object" && (r = navigator.userAgent.indexOf("Windows") >= 0);
      const s = /^\w[\w\d+.-]*$/,
        a = /^\//,
        l = /^\/\//;

      function o(S, v) {
        if (!S.scheme && v) throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${S.authority}", path: "${S.path}", query: "${S.query}", fragment: "${S.fragment}"}`);
        if (S.scheme && !s.test(S.scheme)) throw new Error("[UriError]: Scheme contains illegal characters.");
        if (S.path) {
          if (S.authority) {
            if (!a.test(S.path)) throw new Error('[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash ("/") character')
          } else if (l.test(S.path)) throw new Error('[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters ("//")')
        }
      }
      const u = "",
        c = "/",
        d = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
      class m {
        constructor(v, A, D, k, E, M = !1) {
          Qe(this, "scheme");
          Qe(this, "authority");
          Qe(this, "path");
          Qe(this, "query");
          Qe(this, "fragment");
          typeof v == "object" ? (this.scheme = v.scheme || u, this.authority = v.authority || u, this.path = v.path || u, this.query = v.query || u, this.fragment = v.fragment || u) : (this.scheme = (function(W, F) {
            return W || F ? W : "file"
          })(v, M), this.authority = A || u, this.path = (function(W, F) {
            switch (W) {
              case "https":
              case "http":
              case "file":
                F ? F[0] !== c && (F = c + F) : F = c
            }
            return F
          })(this.scheme, D || u), this.query = k || u, this.fragment = E || u, o(this, M))
        }
        static isUri(v) {
          return v instanceof m || !!v && typeof v.authority == "string" && typeof v.fragment == "string" && typeof v.path == "string" && typeof v.query == "string" && typeof v.scheme == "string" && typeof v.fsPath == "string" && typeof v.with == "function" && typeof v.toString == "function"
        }
        get fsPath() {
          return y(this)
        }
        with(v) {
          if (!v) return this;
          let {
            scheme: A,
            authority: D,
            path: k,
            query: E,
            fragment: M
          } = v;
          return A === void 0 ? A = this.scheme : A === null && (A = u), D === void 0 ? D = this.authority : D === null && (D = u), k === void 0 ? k = this.path : k === null && (k = u), E === void 0 ? E = this.query : E === null && (E = u), M === void 0 ? M = this.fragment : M === null && (M = u), A === this.scheme && D === this.authority && k === this.path && E === this.query && M === this.fragment ? this : new w(A, D, k, E, M)
        }
        static parse(v, A = !1) {
          const D = d.exec(v);
          return D ? new w(D[2] || u, P(D[4] || u), P(D[5] || u), P(D[7] || u), P(D[9] || u), A) : new w(u, u, u, u, u)
        }
        static file(v) {
          let A = u;
          if (r && (v = v.replace(/\\/g, c)), v[0] === c && v[1] === c) {
            const D = v.indexOf(c, 2);
            D === -1 ? (A = v.substring(2), v = c) : (A = v.substring(2, D), v = v.substring(D) || c)
          }
          return new w("file", A, v, u, u)
        }
        static from(v) {
          const A = new w(v.scheme, v.authority, v.path, v.query, v.fragment);
          return o(A, !0), A
        }
        toString(v = !1) {
          return L(this, v)
        }
        toJSON() {
          return this
        }
        static revive(v) {
          if (v) {
            if (v instanceof m) return v;
            {
              const A = new w(v);
              return A._formatted = v.external, A._fsPath = v._sep === f ? v.fsPath : null, A
            }
          }
          return v
        }
      }
      const f = r ? 1 : void 0;
      class w extends m {
        constructor() {
          super(...arguments);
          Qe(this, "_formatted", null);
          Qe(this, "_fsPath", null)
        }
        get fsPath() {
          return this._fsPath || (this._fsPath = y(this)), this._fsPath
        }
        toString(A = !1) {
          return A ? L(this, !0) : (this._formatted || (this._formatted = L(this, !1)), this._formatted)
        }
        toJSON() {
          const A = {
            $mid: 1
          };
          return this._fsPath && (A.fsPath = this._fsPath, A._sep = f), this._formatted && (A.external = this._formatted), this.path && (A.path = this.path), this.scheme && (A.scheme = this.scheme), this.authority && (A.authority = this.authority), this.query && (A.query = this.query), this.fragment && (A.fragment = this.fragment), A
        }
      }
      const p = {
        58: "%3A",
        47: "%2F",
        63: "%3F",
        35: "%23",
        91: "%5B",
        93: "%5D",
        64: "%40",
        33: "%21",
        36: "%24",
        38: "%26",
        39: "%27",
        40: "%28",
        41: "%29",
        42: "%2A",
        43: "%2B",
        44: "%2C",
        59: "%3B",
        61: "%3D",
        32: "%20"
      };

      function x(S, v, A) {
        let D, k = -1;
        for (let E = 0; E < S.length; E++) {
          const M = S.charCodeAt(E);
          if (M >= 97 && M <= 122 || M >= 65 && M <= 90 || M >= 48 && M <= 57 || M === 45 || M === 46 || M === 95 || M === 126 || v && M === 47 || A && M === 91 || A && M === 93 || A && M === 58) k !== -1 && (D += encodeURIComponent(S.substring(k, E)), k = -1), D !== void 0 && (D += S.charAt(E));
          else {
            D === void 0 && (D = S.substr(0, E));
            const W = p[M];
            W !== void 0 ? (k !== -1 && (D += encodeURIComponent(S.substring(k, E)), k = -1), D += W) : k === -1 && (k = E)
          }
        }
        return k !== -1 && (D += encodeURIComponent(S.substring(k))), D !== void 0 ? D : S
      }

      function T(S) {
        let v;
        for (let A = 0; A < S.length; A++) {
          const D = S.charCodeAt(A);
          D === 35 || D === 63 ? (v === void 0 && (v = S.substr(0, A)), v += p[D]) : v !== void 0 && (v += S[A])
        }
        return v !== void 0 ? v : S
      }

      function y(S, v) {
        let A;
        return A = S.authority && S.path.length > 1 && S.scheme === "file" ? `//${S.authority}${S.path}` : S.path.charCodeAt(0) === 47 && (S.path.charCodeAt(1) >= 65 && S.path.charCodeAt(1) <= 90 || S.path.charCodeAt(1) >= 97 && S.path.charCodeAt(1) <= 122) && S.path.charCodeAt(2) === 58 ? S.path[1].toLowerCase() + S.path.substr(2) : S.path, r && (A = A.replace(/\//g, "\\")), A
      }

      function L(S, v) {
        const A = v ? T : x;
        let D = "",
          {
            scheme: k,
            authority: E,
            path: M,
            query: W,
            fragment: F
          } = S;
        if (k && (D += k, D += ":"), (E || k === "file") && (D += c, D += c), E) {
          let U = E.indexOf("@");
          if (U !== -1) {
            const O = E.substr(0, U);
            E = E.substr(U + 1), U = O.lastIndexOf(":"), U === -1 ? D += A(O, !1, !1) : (D += A(O.substr(0, U), !1, !1), D += ":", D += A(O.substr(U + 1), !1, !0)), D += "@"
          }
          E = E.toLowerCase(), U = E.lastIndexOf(":"), U === -1 ? D += A(E, !1, !0) : (D += A(E.substr(0, U), !1, !0), D += E.substr(U))
        }
        if (M) {
          if (M.length >= 3 && M.charCodeAt(0) === 47 && M.charCodeAt(2) === 58) {
            const U = M.charCodeAt(1);
            U >= 65 && U <= 90 && (M = `/${String.fromCharCode(U+32)}:${M.substr(3)}`)
          } else if (M.length >= 2 && M.charCodeAt(1) === 58) {
            const U = M.charCodeAt(0);
            U >= 65 && U <= 90 && (M = `${String.fromCharCode(U+32)}:${M.substr(2)}`)
          }
          D += A(M, !0, !1)
        }
        return W && (D += "?", D += A(W, !1, !1)), F && (D += "#", D += v ? F : x(F, !1, !1)), D
      }

      function I(S) {
        try {
          return decodeURIComponent(S)
        } catch {
          return S.length > 3 ? S.substr(0, 3) + I(S.substr(3)) : S
        }
      }
      const H = /(%[0-9A-Za-z][0-9A-Za-z])+/g;

      function P(S) {
        return S.match(H) ? S.replace(H, (v => I(v))) : S
      }
      var b = n(470);
      const g = b.posix || b,
        _ = "/";
      var N;
      (function(S) {
        S.joinPath = function(v, ...A) {
          return v.with({
            path: g.join(v.path, ...A)
          })
        }, S.resolvePath = function(v, ...A) {
          let D = v.path,
            k = !1;
          D[0] !== _ && (D = _ + D, k = !0);
          let E = g.resolve(D, ...A);
          return k && E[0] === _ && !v.authority && (E = E.substring(1)), v.with({
            path: E
          })
        }, S.dirname = function(v) {
          if (v.path.length === 0 || v.path === _) return v;
          let A = g.dirname(v.path);
          return A.length === 1 && A.charCodeAt(0) === 46 && (A = ""), v.with({
            path: A
          })
        }, S.basename = function(v) {
          return g.basename(v.path)
        }, S.extname = function(v) {
          return g.extname(v.path)
        }
      })(N || (N = {}))
    })(), Ka = i
  })();
  const {
    URI: Bc,
    Utils: gh
  } = Ka;

  function Ii(t) {
    const e = t[0],
      n = t[t.length - 1];
    return e === n && (e === "'" || e === '"') && (t = t.substring(1, t.length - 1)), t
  }

  function qc(t, e) {
    return !t.length || e === "handlebars" && /{{|}}/.test(t) ? !1 : /\b(w[\w\d+.-]*:\/\/)?[^\s()<>]+(?:\([\w\d]+\)|([^[:punct:]\s]|\/?))/.test(t)
  }

  function Oc(t, e, n, i) {
    if (/^\s*javascript\:/i.test(e) || /[\n\r]/.test(e)) return;
    e = e.replace(/^\s*/g, "");
    const r = e.match(/^(\w[\w\d+.-]*):/);
    if (r) {
      const s = r[1].toLowerCase();
      return s === "http" || s === "https" || s === "file" ? e : void 0
    }
    return /^\#/i.test(e) ? t + e : /^\/\//i.test(e) ? (Je(t, "https://") ? "https" : "http") + ":" + e.replace(/^\s*/g, "") : n ? n.resolveReference(e, i || t) : e
  }

  function Vc(t, e, n, i, r, s) {
    const a = Ii(n);
    if (!qc(a, t.languageId)) return;
    a.length < n.length && (i++, r--);
    const l = Oc(t.uri, a, e, s);
    if (!l) return;
    const o = $c(l, t);
    return {
      range: J.create(t.positionAt(i), t.positionAt(r)),
      target: o
    }
  }
  const jc = 35;

  function $c(t, e) {
    try {
      let n = Bc.parse(t);
      return n.scheme === "file" && n.query && (n = n.with({
        query: null
      }), t = n.toString(!0)), n.scheme === "file" && n.fragment && !(t.startsWith(e.uri) && t.charCodeAt(e.uri.length) === jc) ? n.with({
        fragment: null
      }).toString(!0) : t
    } catch {
      return
    }
  }
  class Gc {
    constructor(e) {
      this.dataManager = e
    }
    findDocumentLinks(e, n) {
      const i = [],
        r = be(e.getText(), 0);
      let s = r.scan(),
        a, l, o = !1,
        u;
      const c = {};
      for (; s !== z.EOS;) {
        switch (s) {
          case z.StartTag:
            l = r.getTokenText().toLowerCase(), u || (o = l === "base");
            break;
          case z.AttributeName:
            a = r.getTokenText().toLowerCase();
            break;
          case z.AttributeValue:
            if (l && a && this.dataManager.isPathAttribute(l, a)) {
              const d = r.getTokenText();
              if (!o) {
                const m = Vc(e, n, d, r.getTokenOffset(), r.getTokenEnd(), u);
                m && i.push(m)
              }
              o && typeof u > "u" && (u = Ii(d), u && n && (u = n.resolveReference(u, e.uri))), o = !1, a = void 0
            } else if (a === "id") {
              const d = Ii(r.getTokenText());
              c[d] = r.getTokenOffset()
            }
            break
        }
        s = r.scan()
      }
      for (const d of i) {
        const m = e.uri + "#";
        if (d.target && Je(d.target, m)) {
          const f = d.target.substring(m.length),
            w = c[f];
          if (w !== void 0) {
            const p = e.positionAt(w);
            d.target = `${m}${p.line+1},${p.character+1}`
          } else d.target = e.uri
        }
      }
      return i
    }
  }

  function Xc(t, e, n) {
    const i = t.offsetAt(e),
      r = n.findNodeAt(i);
    if (!r.tag) return [];
    const s = [],
      a = no(z.StartTag, t, r.start),
      l = typeof r.endTagStart == "number" && no(z.EndTag, t, r.endTagStart);
    return (a && to(a, e) || l && to(l, e)) && (a && s.push({
      kind: gn.Read,
      range: a
    }), l && s.push({
      kind: gn.Read,
      range: l
    })), s
  }

  function eo(t, e) {
    return t.line < e.line || t.line === e.line && t.character <= e.character
  }

  function to(t, e) {
    return eo(t.start, e) && eo(e, t.end)
  }

  function no(t, e, n) {
    const i = be(e.getText(), n);
    let r = i.scan();
    for (; r !== z.EOS && r !== t;) r = i.scan();
    return r !== z.EOS ? {
      start: e.positionAt(i.getTokenOffset()),
      end: e.positionAt(i.getTokenEnd())
    } : null
  }

  function Jc(t, e) {
    const n = [],
      i = io(t, e);
    for (const s of i) r(s, void 0);
    return n;

    function r(s, a) {
      const l = Si.create(s.name, s.kind, s.range, t.uri, a == null ? void 0 : a.name);
      if (l.containerName ?? (l.containerName = ""), n.push(l), s.children)
        for (const o of s.children) r(o, s)
    }
  }

  function io(t, e) {
    const n = [];
    return e.roots.forEach(i => {
      ro(t, i, n)
    }), n
  }

  function ro(t, e, n) {
    const i = Qc(e),
      r = J.create(t.positionAt(e.start), t.positionAt(e.end)),
      s = Ai.create(i, void 0, ki.Field, r, r);
    n.push(s), e.children.forEach(a => {
      s.children ?? (s.children = []), ro(t, a, s.children)
    })
  }

  function Qc(t) {
    let e = t.tag;
    if (t.attributes) {
      const n = t.attributes.id,
        i = t.attributes.class;
      n && (e += `#${n.replace(/[\"\']/g,"")}`), i && (e += i.replace(/[\"\']/g, "").split(/\s+/).map(r => `.${r}`).join(""))
    }
    return e || "?"
  }

  function Yc(t, e, n, i) {
    const r = t.offsetAt(e),
      s = i.findNodeAt(r);
    if (!s.tag || !Zc(s, r, s.tag)) return null;
    const a = [],
      l = {
        start: t.positionAt(s.start + 1),
        end: t.positionAt(s.start + 1 + s.tag.length)
      };
    if (a.push({
        range: l,
        newText: n
      }), s.endTagStart) {
      const u = {
        start: t.positionAt(s.endTagStart + 2),
        end: t.positionAt(s.endTagStart + 2 + s.tag.length)
      };
      a.push({
        range: u,
        newText: n
      })
    }
    return {
      changes: {
        [t.uri.toString()]: a
      }
    }
  }

  function Zc(t, e, n) {
    return t.endTagStart && t.endTagStart + 2 <= e && e <= t.endTagStart + 2 + n.length ? !0 : t.start + 1 <= e && e <= t.start + 1 + n.length
  }

  function Kc(t, e, n) {
    const i = t.offsetAt(e),
      r = n.findNodeAt(i);
    if (!r.tag || !r.endTagStart) return null;
    if (r.start + 1 <= i && i <= r.start + 1 + r.tag.length) {
      const s = i - 1 - r.start + r.endTagStart + 2;
      return t.positionAt(s)
    }
    if (r.endTagStart + 2 <= i && i <= r.endTagStart + 2 + r.tag.length) {
      const s = i - 2 - r.endTagStart + r.start + 1;
      return t.positionAt(s)
    }
    return null
  }

  function so(t, e, n) {
    const i = t.offsetAt(e),
      r = n.findNodeAt(i),
      s = r.tag ? r.tag.length : 0;
    return r.endTagStart && (r.start + 1 <= i && i <= r.start + 1 + s || r.endTagStart + 2 <= i && i <= r.endTagStart + 2 + s) ? [J.create(t.positionAt(r.start + 1), t.positionAt(r.start + 1 + s)), J.create(t.positionAt(r.endTagStart + 2), t.positionAt(r.endTagStart + 2 + s))] : null
  }
  class eh {
    constructor(e) {
      this.dataManager = e
    }
    limitRanges(e, n) {
      e = e.sort((d, m) => {
        let f = d.startLine - m.startLine;
        return f === 0 && (f = d.endLine - m.endLine), f
      });
      let i;
      const r = [],
        s = [],
        a = [],
        l = (d, m) => {
          s[d] = m, m < 30 && (a[m] = (a[m] || 0) + 1)
        };
      for (let d = 0; d < e.length; d++) {
        const m = e[d];
        if (!i) i = m, l(d, 0);
        else if (m.startLine > i.startLine) {
          if (m.endLine <= i.endLine) r.push(i), i = m, l(d, r.length);
          else if (m.startLine > i.endLine) {
            do i = r.pop(); while (i && m.startLine > i.endLine);
            i && r.push(i), i = m, l(d, r.length)
          }
        }
      }
      let o = 0,
        u = 0;
      for (let d = 0; d < a.length; d++) {
        const m = a[d];
        if (m) {
          if (m + o > n) {
            u = d;
            break
          }
          o += m
        }
      }
      const c = [];
      for (let d = 0; d < e.length; d++) {
        const m = s[d];
        typeof m == "number" && (m < u || m === u && o++ < n) && c.push(e[d])
      }
      return c
    }
    getFoldingRanges(e, n) {
      const i = this.dataManager.getVoidElements(e.languageId),
        r = be(e.getText());
      let s = r.scan();
      const a = [],
        l = [];
      let o = null,
        u = -1;

      function c(m) {
        a.push(m), u = m.startLine
      }
      for (; s !== z.EOS;) {
        switch (s) {
          case z.StartTag: {
            const m = r.getTokenText(),
              f = e.positionAt(r.getTokenOffset()).line;
            l.push({
              startLine: f,
              tagName: m
            }), o = m;
            break
          }
          case z.EndTag: {
            o = r.getTokenText();
            break
          }
          case z.StartTagClose:
            if (!o || !this.dataManager.isVoidElement(o, i)) break;
          case z.EndTagClose:
          case z.StartTagSelfClose: {
            let m = l.length - 1;
            for (; m >= 0 && l[m].tagName !== o;) m--;
            if (m >= 0) {
              const f = l[m];
              l.length = m;
              const w = e.positionAt(r.getTokenOffset()).line,
                p = f.startLine,
                x = w - 1;
              x > p && u !== p && c({
                startLine: p,
                endLine: x
              })
            }
            break
          }
          case z.Comment: {
            let m = e.positionAt(r.getTokenOffset()).line;
            const w = r.getTokenText().match(/^\s*#(region\b)|(endregion\b)/);
            if (w)
              if (w[1]) l.push({
                startLine: m,
                tagName: ""
              });
              else {
                let p = l.length - 1;
                for (; p >= 0 && l[p].tagName.length;) p--;
                if (p >= 0) {
                  const x = l[p];
                  l.length = p;
                  const T = m;
                  m = x.startLine, T > m && u !== m && c({
                    startLine: m,
                    endLine: T,
                    kind: mn.Region
                  })
                }
              }
            else {
              const p = e.positionAt(r.getTokenOffset() + r.getTokenLength()).line;
              m < p && c({
                startLine: m,
                endLine: p,
                kind: mn.Comment
              })
            }
            break
          }
        }
        s = r.scan()
      }
      const d = n && n.rangeLimit || Number.MAX_VALUE;
      return a.length > d ? this.limitRanges(a, d) : a
    }
  }
  class th {
    constructor(e) {
      this.htmlParser = e
    }
    getSelectionRanges(e, n) {
      const i = this.htmlParser.parseDocument(e);
      return n.map(r => this.getSelectionRange(r, e, i))
    }
    getSelectionRange(e, n, i) {
      const r = this.getApplicableRanges(n, e, i);
      let s, a;
      for (let l = r.length - 1; l >= 0; l--) {
        const o = r[l];
        (!s || o[0] !== s[0] || o[1] !== s[1]) && (a = wn.create(J.create(n.positionAt(r[l][0]), n.positionAt(r[l][1])), a)), s = o
      }
      return a || (a = wn.create(J.create(e, e))), a
    }
    getApplicableRanges(e, n, i) {
      const r = e.offsetAt(n),
        s = i.findNodeAt(r);
      let a = this.getAllParentTagRanges(s);
      if (s.startTagEnd && !s.endTagStart) {
        if (s.startTagEnd !== s.end) return [
          [s.start, s.end]
        ];
        const l = J.create(e.positionAt(s.startTagEnd - 2), e.positionAt(s.startTagEnd));
        return e.getText(l) === "/>" ? a.unshift([s.start + 1, s.startTagEnd - 2]) : a.unshift([s.start + 1, s.startTagEnd - 1]), a = this.getAttributeLevelRanges(e, s, r).concat(a), a
      }
      return !s.startTagEnd || !s.endTagStart ? a : (a.unshift([s.start, s.end]), s.start < r && r < s.startTagEnd ? (a.unshift([s.start + 1, s.startTagEnd - 1]), a = this.getAttributeLevelRanges(e, s, r).concat(a), a) : s.startTagEnd <= r && r <= s.endTagStart ? (a.unshift([s.startTagEnd, s.endTagStart]), a) : (r >= s.endTagStart + 2 && a.unshift([s.endTagStart + 2, s.end - 1]), a))
    }
    getAllParentTagRanges(e) {
      let n = e;
      const i = [];
      for (; n.parent;) n = n.parent, this.getNodeRanges(n).forEach(r => i.push(r));
      return i
    }
    getNodeRanges(e) {
      return e.startTagEnd && e.endTagStart && e.startTagEnd < e.endTagStart ? [
        [e.startTagEnd, e.endTagStart],
        [e.start, e.end]
      ] : [
        [e.start, e.end]
      ]
    }
    getAttributeLevelRanges(e, n, i) {
      const r = J.create(e.positionAt(n.start), e.positionAt(n.end)),
        s = e.getText(r),
        a = i - n.start,
        l = be(s);
      let o = l.scan();
      const u = n.start,
        c = [];
      let d = !1,
        m = -1;
      for (; o !== z.EOS;) {
        switch (o) {
          case z.AttributeName: {
            if (a < l.getTokenOffset()) {
              d = !1;
              break
            }
            a <= l.getTokenEnd() && c.unshift([l.getTokenOffset(), l.getTokenEnd()]), d = !0, m = l.getTokenOffset();
            break
          }
          case z.AttributeValue: {
            if (!d) break;
            const f = l.getTokenText();
            if (a < l.getTokenOffset()) {
              c.push([m, l.getTokenEnd()]);
              break
            }
            a >= l.getTokenOffset() && a <= l.getTokenEnd() && (c.unshift([l.getTokenOffset(), l.getTokenEnd()]), (f[0] === '"' && f[f.length - 1] === '"' || f[0] === "'" && f[f.length - 1] === "'") && a >= l.getTokenOffset() + 1 && a <= l.getTokenEnd() - 1 && c.unshift([l.getTokenOffset() + 1, l.getTokenEnd() - 1]), c.push([m, l.getTokenEnd()]));
            break
          }
        }
        o = l.scan()
      }
      return c.map(f => [f[0] + u, f[1] + u])
    }
  }
  const nh = {
    version: 1.1,
    tags: [{
      name: "html",
      description: {
        kind: "markdown",
        value: "The html element represents the root of an HTML document."
      },
      attributes: [{
        name: "manifest",
        description: {
          kind: "markdown",
          value: "Specifies the URI of a resource manifest indicating resources that should be cached locally. See [Using the application cache](https://developer.mozilla.org/en-US/docs/Web/HTML/Using_the_application_cache) for details."
        }
      }, {
        name: "version",
        description: 'Specifies the version of the HTML [Document Type Definition](https://developer.mozilla.org/en-US/docs/Glossary/DTD "Document Type Definition: In HTML, the doctype is the required "<!DOCTYPE html>" preamble found at the top of all documents. Its sole purpose is to prevent a browser from switching into so-called “quirks mode” when rendering a document; that is, the "<!DOCTYPE html>" doctype ensures that the browser makes a best-effort attempt at following the relevant specifications, rather than using a different rendering mode that is incompatible with some specifications.") that governs the current document. This attribute is not needed, because it is redundant with the version information in the document type declaration.'
      }, {
        name: "xmlns",
        description: 'Specifies the XML Namespace of the document. Default value is `"http://www.w3.org/1999/xhtml"`. This is required in documents parsed with XML parsers, and optional in text/html documents.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/html"
      }]
    }, {
      name: "head",
      description: {
        kind: "markdown",
        value: "The head element represents a collection of metadata for the Document."
      },
      attributes: [{
        name: "profile",
        description: "The URIs of one or more metadata profiles, separated by white space."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/head"
      }]
    }, {
      name: "title",
      description: {
        kind: "markdown",
        value: "The title element represents the document's title or name. Authors should use titles that identify their documents even when they are used out of context, for example in a user's history or bookmarks, or in search results. The document's title is often different from its first heading, since the first heading does not have to stand alone when taken out of context."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/title"
      }]
    }, {
      name: "base",
      description: {
        kind: "markdown",
        value: "The base element allows authors to specify the document base URL for the purposes of resolving relative URLs, and the name of the default browsing context for the purposes of following hyperlinks. The element does not represent any content beyond this information."
      },
      void: !0,
      attributes: [{
        name: "href",
        description: {
          kind: "markdown",
          value: "The base URL to be used throughout the document for relative URL addresses. If this attribute is specified, this element must come before any other elements with attributes whose values are URLs. Absolute and relative URLs are allowed."
        }
      }, {
        name: "target",
        valueSet: "target",
        description: {
          kind: "markdown",
          value: "A name or keyword indicating the default location to display the result when hyperlinks or forms cause navigation, for elements that do not have an explicit target reference. It is a name of, or keyword for, a _browsing context_ (for example: tab, window, or inline frame). The following keywords have special meanings:\n\n*   `_self`: Load the result into the same browsing context as the current one. This value is the default if the attribute is not specified.\n*   `_blank`: Load the result into a new unnamed browsing context.\n*   `_parent`: Load the result into the parent browsing context of the current one. If there is no parent, this option behaves the same way as `_self`.\n*   `_top`: Load the result into the top-level browsing context (that is, the browsing context that is an ancestor of the current one, and has no parent). If there is no parent, this option behaves the same way as `_self`.\n\nIf this attribute is specified, this element must come before any other elements with attributes whose values are URLs."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/base"
      }]
    }, {
      name: "link",
      description: {
        kind: "markdown",
        value: "The link element allows authors to link their document to other resources."
      },
      void: !0,
      attributes: [{
        name: "href",
        description: {
          kind: "markdown",
          value: 'This attribute specifies the [URL](https://developer.mozilla.org/en-US/docs/Glossary/URL "URL: Uniform Resource Locator (URL) is a text string specifying where a resource can be found on the Internet.") of the linked resource. A URL can be absolute or relative.'
        }
      }, {
        name: "crossorigin",
        valueSet: "xo",
        description: {
          kind: "markdown",
          value: 'This enumerated attribute indicates whether [CORS](https://developer.mozilla.org/en-US/docs/Glossary/CORS "CORS: CORS (Cross-Origin Resource Sharing) is a system, consisting of transmitting HTTP headers, that determines whether browsers block frontend JavaScript code from accessing responses for cross-origin requests.") must be used when fetching the resource. [CORS-enabled images](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_Enabled_Image) can be reused in the [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas "Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.") element without being _tainted_. The allowed values are:\n\n`anonymous`\n\nA cross-origin request (i.e. with an [`Origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Origin "The Origin request header indicates where a fetch originates from. It doesn\'t include any path information, but only the server name. It is sent with CORS requests, as well as with POST requests. It is similar to the Referer header, but, unlike this header, it doesn\'t disclose the whole path.") HTTP header) is performed, but no credential is sent (i.e. no cookie, X.509 certificate, or HTTP Basic authentication). If the server does not give credentials to the origin site (by not setting the [`Access-Control-Allow-Origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Origin "The Access-Control-Allow-Origin response header indicates whether the response can be shared with requesting code from the given origin.") HTTP header) the image will be tainted and its usage restricted.\n\n`use-credentials`\n\nA cross-origin request (i.e. with an `Origin` HTTP header) is performed along with a credential sent (i.e. a cookie, certificate, and/or HTTP Basic authentication is performed). If the server does not give credentials to the origin site (through [`Access-Control-Allow-Credentials`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Credentials "The Access-Control-Allow-Credentials response header tells browsers whether to expose the response to frontend JavaScript code when the request\'s credentials mode (Request.credentials) is "include".") HTTP header), the resource will be _tainted_ and its usage restricted.\n\nIf the attribute is not present, the resource is fetched without a [CORS](https://developer.mozilla.org/en-US/docs/Glossary/CORS "CORS: CORS (Cross-Origin Resource Sharing) is a system, consisting of transmitting HTTP headers, that determines whether browsers block frontend JavaScript code from accessing responses for cross-origin requests.") request (i.e. without sending the `Origin` HTTP header), preventing its non-tainted usage. If invalid, it is handled as if the enumerated keyword **anonymous** was used. See [CORS settings attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_settings_attributes) for additional information.'
        }
      }, {
        name: "rel",
        description: {
          kind: "markdown",
          value: "This attribute names a relationship of the linked document to the current document. The attribute must be a space-separated list of the [link types values](https://developer.mozilla.org/en-US/docs/Web/HTML/Link_types)."
        }
      }, {
        name: "media",
        description: {
          kind: "markdown",
          value: "This attribute specifies the media that the linked resource applies to. Its value must be a media type / [media query](https://developer.mozilla.org/en-US/docs/Web/CSS/Media_queries). This attribute is mainly useful when linking to external stylesheets — it allows the user agent to pick the best adapted one for the device it runs on.\n\n**Notes:**\n\n*   In HTML 4, this can only be a simple white-space-separated list of media description literals, i.e., [media types and groups](https://developer.mozilla.org/en-US/docs/Web/CSS/@media), where defined and allowed as values for this attribute, such as `print`, `screen`, `aural`, `braille`. HTML5 extended this to any kind of [media queries](https://developer.mozilla.org/en-US/docs/Web/CSS/Media_queries), which are a superset of the allowed values of HTML 4.\n*   Browsers not supporting [CSS3 Media Queries](https://developer.mozilla.org/en-US/docs/Web/CSS/Media_queries) won't necessarily recognize the adequate link; do not forget to set fallback links, the restricted set of media queries defined in HTML 4."
        }
      }, {
        name: "hreflang",
        description: {
          kind: "markdown",
          value: "This attribute indicates the language of the linked resource. It is purely advisory. Allowed values are determined by [BCP47](https://www.ietf.org/rfc/bcp/bcp47.txt). Use this attribute only if the [`href`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a#attr-href) attribute is present."
        }
      }, {
        name: "type",
        description: {
          kind: "markdown",
          value: 'This attribute is used to define the type of the content linked to. The value of the attribute should be a MIME type such as **text/html**, **text/css**, and so on. The common use of this attribute is to define the type of stylesheet being referenced (such as **text/css**), but given that CSS is the only stylesheet language used on the web, not only is it possible to omit the `type` attribute, but is actually now recommended practice. It is also used on `rel="preload"` link types, to make sure the browser only downloads file types that it supports.'
        }
      }, {
        name: "sizes",
        description: {
          kind: "markdown",
          value: "This attribute defines the sizes of the icons for visual media contained in the resource. It must be present only if the [`rel`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/link#attr-rel) contains a value of `icon` or a non-standard type such as Apple's `apple-touch-icon`. It may have the following values:\n\n*   `any`, meaning that the icon can be scaled to any size as it is in a vector format, like `image/svg+xml`.\n*   a white-space separated list of sizes, each in the format `_<width in pixels>_x_<height in pixels>_` or `_<width in pixels>_X_<height in pixels>_`. Each of these sizes must be contained in the resource.\n\n**Note:** Most icon formats are only able to store one single icon; therefore most of the time the [`sizes`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes#attr-sizes) contains only one entry. MS's ICO format does, as well as Apple's ICNS. ICO is more ubiquitous; you should definitely use it."
        }
      }, {
        name: "as",
        description: 'This attribute is only used when `rel="preload"` or `rel="prefetch"` has been set on the `<link>` element. It specifies the type of content being loaded by the `<link>`, which is necessary for content prioritization, request matching, application of correct [content security policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP), and setting of correct [`Accept`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Accept "The Accept request HTTP header advertises which content types, expressed as MIME types, the client is able to understand. Using content negotiation, the server then selects one of the proposals, uses it and informs the client of its choice with the Content-Type response header. Browsers set adequate values for this header depending on the context where the request is done: when fetching a CSS stylesheet a different value is set for the request than when fetching an image, video or a script.") request header.'
      }, {
        name: "importance",
        description: "Indicates the relative importance of the resource. Priority hints are delegated using the values:"
      }, {
        name: "importance",
        description: '**`auto`**: Indicates **no preference**. The browser may use its own heuristics to decide the priority of the resource.\n\n**`high`**: Indicates to the browser that the resource is of **high** priority.\n\n**`low`**: Indicates to the browser that the resource is of **low** priority.\n\n**Note:** The `importance` attribute may only be used for the `<link>` element if `rel="preload"` or `rel="prefetch"` is present.'
      }, {
        name: "integrity",
        description: "Contains inline metadata — a base64-encoded cryptographic hash of the resource (file) you’re telling the browser to fetch. The browser can use this to verify that the fetched resource has been delivered free of unexpected manipulation. See [Subresource Integrity](https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity)."
      }, {
        name: "referrerpolicy",
        description: 'A string indicating which referrer to use when fetching the resource:\n\n*   `no-referrer` means that the [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer "The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.") header will not be sent.\n*   `no-referrer-when-downgrade` means that no [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer "The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.") header will be sent when navigating to an origin without TLS (HTTPS). This is a user agent’s default behavior, if no policy is otherwise specified.\n*   `origin` means that the referrer will be the origin of the page, which is roughly the scheme, the host, and the port.\n*   `origin-when-cross-origin` means that navigating to other origins will be limited to the scheme, the host, and the port, while navigating on the same origin will include the referrer\'s path.\n*   `unsafe-url` means that the referrer will include the origin and the path (but not the fragment, password, or username). This case is unsafe because it can leak origins and paths from TLS-protected resources to insecure origins.'
      }, {
        name: "title",
        description: 'The `title` attribute has special semantics on the `<link>` element. When used on a `<link rel="stylesheet">` it defines a [preferred or an alternate stylesheet](https://developer.mozilla.org/en-US/docs/Web/CSS/Alternative_style_sheets). Incorrectly using it may [cause the stylesheet to be ignored](https://developer.mozilla.org/en-US/docs/Correctly_Using_Titles_With_External_Stylesheets).'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/link"
      }]
    }, {
      name: "meta",
      description: {
        kind: "markdown",
        value: "The meta element represents various kinds of metadata that cannot be expressed using the title, base, link, style, and script elements."
      },
      void: !0,
      attributes: [{
        name: "name",
        description: {
          kind: "markdown",
          value: `This attribute defines the name of a piece of document-level metadata. It should not be set if one of the attributes [\`itemprop\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes#attr-itemprop), [\`http-equiv\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-http-equiv) or [\`charset\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-charset) is also set.

This metadata name is associated with the value contained by the [\`content\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-content) attribute. The possible values for the name attribute are:

*   \`application-name\` which defines the name of the application running in the web page.
    
    **Note:**
    
    *   Browsers may use this to identify the application. It is different from the [\`<title>\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/title "The HTML Title element (<title>) defines the document's title that is shown in a browser's title bar or a page's tab.") element, which usually contain the application name, but may also contain information like the document name or a status.
    *   Simple web pages shouldn't define an application-name.
    
*   \`author\` which defines the name of the document's author.
*   \`description\` which contains a short and accurate summary of the content of the page. Several browsers, like Firefox and Opera, use this as the default description of bookmarked pages.
*   \`generator\` which contains the identifier of the software that generated the page.
*   \`keywords\` which contains words relevant to the page's content separated by commas.
*   \`referrer\` which controls the [\`Referer\` HTTP header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer) attached to requests sent from the document:
    
    Values for the \`content\` attribute of \`<meta name="referrer">\`
    
    \`no-referrer\`
    
    Do not send a HTTP \`Referrer\` header.
    
    \`origin\`
    
    Send the [origin](https://developer.mozilla.org/en-US/docs/Glossary/Origin) of the document.
    
    \`no-referrer-when-downgrade\`
    
    Send the [origin](https://developer.mozilla.org/en-US/docs/Glossary/Origin) as a referrer to URLs as secure as the current page, (https→https), but does not send a referrer to less secure URLs (https→http). This is the default behaviour.
    
    \`origin-when-cross-origin\`
    
    Send the full URL (stripped of parameters) for same-origin requests, but only send the [origin](https://developer.mozilla.org/en-US/docs/Glossary/Origin) for other cases.
    
    \`same-origin\`
    
    A referrer will be sent for [same-site origins](https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy), but cross-origin requests will contain no referrer information.
    
    \`strict-origin\`
    
    Only send the origin of the document as the referrer to a-priori as-much-secure destination (HTTPS->HTTPS), but don't send it to a less secure destination (HTTPS->HTTP).
    
    \`strict-origin-when-cross-origin\`
    
    Send a full URL when performing a same-origin request, only send the origin of the document to a-priori as-much-secure destination (HTTPS->HTTPS), and send no header to a less secure destination (HTTPS->HTTP).
    
    \`unsafe-URL\`
    
    Send the full URL (stripped of parameters) for same-origin or cross-origin requests.
    
    **Notes:**
    
    *   Some browsers support the deprecated values of \`always\`, \`default\`, and \`never\` for referrer.
    *   Dynamically inserting \`<meta name="referrer">\` (with [\`document.write\`](https://developer.mozilla.org/en-US/docs/Web/API/Document/write) or [\`appendChild\`](https://developer.mozilla.org/en-US/docs/Web/API/Node/appendChild)) makes the referrer behaviour unpredictable.
    *   When several conflicting policies are defined, the no-referrer policy is applied.
    

This attribute may also have a value taken from the extended list defined on [WHATWG Wiki MetaExtensions page](https://wiki.whatwg.org/wiki/MetaExtensions). Although none have been formally accepted yet, a few commonly used names are:

*   \`creator\` which defines the name of the creator of the document, such as an organization or institution. If there are more than one, several [\`<meta>\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta "The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.") elements should be used.
*   \`googlebot\`, a synonym of \`robots\`, is only followed by Googlebot (the indexing crawler for Google).
*   \`publisher\` which defines the name of the document's publisher.
*   \`robots\` which defines the behaviour that cooperative crawlers, or "robots", should use with the page. It is a comma-separated list of the values below:
    
    Values for the content of \`<meta name="robots">\`
    
    Value
    
    Description
    
    Used by
    
    \`index\`
    
    Allows the robot to index the page (default).
    
    All
    
    \`noindex\`
    
    Requests the robot to not index the page.
    
    All
    
    \`follow\`
    
    Allows the robot to follow the links on the page (default).
    
    All
    
    \`nofollow\`
    
    Requests the robot to not follow the links on the page.
    
    All
    
    \`none\`
    
    Equivalent to \`noindex, nofollow\`
    
    [Google](https://support.google.com/webmasters/answer/79812)
    
    \`noodp\`
    
    Prevents using the [Open Directory Project](https://www.dmoz.org/) description, if any, as the page description in search engine results.
    
    [Google](https://support.google.com/webmasters/answer/35624#nodmoz), [Yahoo](https://help.yahoo.com/kb/search-for-desktop/meta-tags-robotstxt-yahoo-search-sln2213.html#cont5), [Bing](https://www.bing.com/webmaster/help/which-robots-metatags-does-bing-support-5198d240)
    
    \`noarchive\`
    
    Requests the search engine not to cache the page content.
    
    [Google](https://developers.google.com/webmasters/control-crawl-index/docs/robots_meta_tag#valid-indexing--serving-directives), [Yahoo](https://help.yahoo.com/kb/search-for-desktop/SLN2213.html), [Bing](https://www.bing.com/webmaster/help/which-robots-metatags-does-bing-support-5198d240)
    
    \`nosnippet\`
    
    Prevents displaying any description of the page in search engine results.
    
    [Google](https://developers.google.com/webmasters/control-crawl-index/docs/robots_meta_tag#valid-indexing--serving-directives), [Bing](https://www.bing.com/webmaster/help/which-robots-metatags-does-bing-support-5198d240)
    
    \`noimageindex\`
    
    Requests this page not to appear as the referring page of an indexed image.
    
    [Google](https://developers.google.com/webmasters/control-crawl-index/docs/robots_meta_tag#valid-indexing--serving-directives)
    
    \`nocache\`
    
    Synonym of \`noarchive\`.
    
    [Bing](https://www.bing.com/webmaster/help/which-robots-metatags-does-bing-support-5198d240)
    
    **Notes:**
    
    *   Only cooperative robots follow these rules. Do not expect to prevent e-mail harvesters with them.
    *   The robot still needs to access the page in order to read these rules. To prevent bandwidth consumption, use a _[robots.txt](https://developer.mozilla.org/en-US/docs/Glossary/robots.txt "robots.txt: Robots.txt is a file which is usually placed in the root of any website. It decides whether crawlers are permitted or forbidden access to the web site.")_ file.
    *   If you want to remove a page, \`noindex\` will work, but only after the robot visits the page again. Ensure that the \`robots.txt\` file is not preventing revisits.
    *   Some values are mutually exclusive, like \`index\` and \`noindex\`, or \`follow\` and \`nofollow\`. In these cases the robot's behaviour is undefined and may vary between them.
    *   Some crawler robots, like Google, Yahoo and Bing, support the same values for the HTTP header \`X-Robots-Tag\`; this allows non-HTML documents like images to use these rules.
    
*   \`slurp\`, is a synonym of \`robots\`, but only for Slurp - the crawler for Yahoo Search.
*   \`viewport\`, which gives hints about the size of the initial size of the [viewport](https://developer.mozilla.org/en-US/docs/Glossary/viewport "viewport: A viewport represents a polygonal (normally rectangular) area in computer graphics that is currently being viewed. In web browser terms, it refers to the part of the document you're viewing which is currently visible in its window (or the screen, if the document is being viewed in full screen mode). Content outside the viewport is not visible onscreen until scrolled into view."). Used by mobile devices only.
    
    Values for the content of \`<meta name="viewport">\`
    
    Value
    
    Possible subvalues
    
    Description
    
    \`width\`
    
    A positive integer number, or the text \`device-width\`
    
    Defines the pixel width of the viewport that you want the web site to be rendered at.
    
    \`height\`
    
    A positive integer, or the text \`device-height\`
    
    Defines the height of the viewport. Not used by any browser.
    
    \`initial-scale\`
    
    A positive number between \`0.0\` and \`10.0\`
    
    Defines the ratio between the device width (\`device-width\` in portrait mode or \`device-height\` in landscape mode) and the viewport size.
    
    \`maximum-scale\`
    
    A positive number between \`0.0\` and \`10.0\`
    
    Defines the maximum amount to zoom in. It must be greater or equal to the \`minimum-scale\` or the behaviour is undefined. Browser settings can ignore this rule and iOS10+ ignores it by default.
    
    \`minimum-scale\`
    
    A positive number between \`0.0\` and \`10.0\`
    
    Defines the minimum zoom level. It must be smaller or equal to the \`maximum-scale\` or the behaviour is undefined. Browser settings can ignore this rule and iOS10+ ignores it by default.
    
    \`user-scalable\`
    
    \`yes\` or \`no\`
    
    If set to \`no\`, the user is not able to zoom in the webpage. The default is \`yes\`. Browser settings can ignore this rule, and iOS10+ ignores it by default.
    
    Specification
    
    Status
    
    Comment
    
    [CSS Device Adaptation  
    The definition of '<meta name="viewport">' in that specification.](https://drafts.csswg.org/css-device-adapt/#viewport-meta)
    
    Working Draft
    
    Non-normatively describes the Viewport META element
    
    See also: [\`@viewport\`](https://developer.mozilla.org/en-US/docs/Web/CSS/@viewport "The @viewport CSS at-rule lets you configure the viewport through which the document is viewed. It's primarily used for mobile devices, but is also used by desktop browsers that support features like "snap to edge" (such as Microsoft Edge).")
    
    **Notes:**
    
    *   Though unstandardized, this declaration is respected by most mobile browsers due to de-facto dominance.
    *   The default values may vary between devices and browsers.
    *   To learn about this declaration in Firefox for Mobile, see [this article](https://developer.mozilla.org/en-US/docs/Mobile/Viewport_meta_tag "Mobile/Viewport meta tag").`
        }
      }, {
        name: "http-equiv",
        description: {
          kind: "markdown",
          value: 'Defines a pragma directive. The attribute is named `**http-equiv**(alent)` because all the allowed values are names of particular HTTP headers:\n\n*   `"content-language"`  \n    Defines the default language of the page. It can be overridden by the [lang](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/lang) attribute on any element.\n    \n    **Warning:** Do not use this value, as it is obsolete. Prefer the `lang` attribute on the [`<html>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/html "The HTML <html> element represents the root (top-level element) of an HTML document, so it is also referred to as the root element. All other elements must be descendants of this element.") element.\n    \n*   `"content-security-policy"`  \n    Allows page authors to define a [content policy](https://developer.mozilla.org/en-US/docs/Web/Security/CSP/CSP_policy_directives) for the current page. Content policies mostly specify allowed server origins and script endpoints which help guard against cross-site scripting attacks.\n*   `"content-type"`  \n    Defines the [MIME type](https://developer.mozilla.org/en-US/docs/Glossary/MIME_type) of the document, followed by its character encoding. It follows the same syntax as the HTTP `content-type` entity-header field, but as it is inside a HTML page, most values other than `text/html` are impossible. Therefore the valid syntax for its `content` is the string \'`text/html`\' followed by a character set with the following syntax: \'`; charset=_IANAcharset_`\', where `IANAcharset` is the _preferred MIME name_ for a character set as [defined by the IANA.](https://www.iana.org/assignments/character-sets)\n    \n    **Warning:** Do not use this value, as it is obsolete. Use the [`charset`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-charset) attribute on the [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta "The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.") element.\n    \n    **Note:** As [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta "The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.") can\'t change documents\' types in XHTML or HTML5\'s XHTML serialization, never set the MIME type to an XHTML MIME type with `<meta>`.\n    \n*   `"refresh"`  \n    This instruction specifies:\n    *   The number of seconds until the page should be reloaded - only if the [`content`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-content) attribute contains a positive integer.\n    *   The number of seconds until the page should redirect to another - only if the [`content`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-content) attribute contains a positive integer followed by the string \'`;url=`\', and a valid URL.\n*   `"set-cookie"`  \n    Defines a [cookie](https://developer.mozilla.org/en-US/docs/cookie) for the page. Its content must follow the syntax defined in the [IETF HTTP Cookie Specification](https://tools.ietf.org/html/draft-ietf-httpstate-cookie-14).\n    \n    **Warning:** Do not use this instruction, as it is obsolete. Use the HTTP header [`Set-Cookie`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Set-Cookie) instead.'
        }
      }, {
        name: "content",
        description: {
          kind: "markdown",
          value: "This attribute contains the value for the [`http-equiv`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-http-equiv) or [`name`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-name) attribute, depending on which is used."
        }
      }, {
        name: "charset",
        description: {
          kind: "markdown",
          value: 'This attribute declares the page\'s character encoding. It must contain a [standard IANA MIME name for character encodings](https://www.iana.org/assignments/character-sets). Although the standard doesn\'t request a specific encoding, it suggests:\n\n*   Authors are encouraged to use [`UTF-8`](https://developer.mozilla.org/en-US/docs/Glossary/UTF-8).\n*   Authors should not use ASCII-incompatible encodings to avoid security risk: browsers not supporting them may interpret harmful content as HTML. This happens with the `JIS_C6226-1983`, `JIS_X0212-1990`, `HZ-GB-2312`, `JOHAB`, the ISO-2022 family and the EBCDIC family.\n\n**Note:** ASCII-incompatible encodings are those that don\'t map the 8-bit code points `0x20` to `0x7E` to the `0x0020` to `0x007E` Unicode code points)\n\n*   Authors **must not** use `CESU-8`, `UTF-7`, `BOCU-1` and/or `SCSU` as [cross-site scripting](https://developer.mozilla.org/en-US/docs/Glossary/Cross-site_scripting) attacks with these encodings have been demonstrated.\n*   Authors should not use `UTF-32` because not all HTML5 encoding algorithms can distinguish it from `UTF-16`.\n\n**Notes:**\n\n*   The declared character encoding must match the one the page was saved with to avoid garbled characters and security holes.\n*   The [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta "The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.") element declaring the encoding must be inside the [`<head>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/head "The HTML <head> element provides general information (metadata) about the document, including its title and links to its scripts and style sheets.") element and **within the first 1024 bytes** of the HTML as some browsers only look at those bytes before choosing an encoding.\n*   This [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta "The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.") element is only one part of the [algorithm to determine a page\'s character set](https://www.whatwg.org/specs/web-apps/current-work/multipage/parsing.html#encoding-sniffing-algorithm "Algorithm charset page"). The [`Content-Type` header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Type) and any [Byte-Order Marks](https://developer.mozilla.org/en-US/docs/Glossary/Byte-Order_Mark "The definition of that term (Byte-Order Marks) has not been written yet; please consider contributing it!") override this element.\n*   It is strongly recommended to define the character encoding. If a page\'s encoding is undefined, cross-scripting techniques are possible, such as the [`UTF-7` fallback cross-scripting technique](https://code.google.com/p/doctype-mirror/wiki/ArticleUtf7).\n*   The [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta "The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.") element with a `charset` attribute is a synonym for the pre-HTML5 `<meta http-equiv="Content-Type" content="text/html; charset=_IANAcharset_">`, where _`IANAcharset`_ contains the value of the equivalent [`charset`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-charset) attribute. This syntax is still allowed, although no longer recommended.'
        }
      }, {
        name: "scheme",
        description: "This attribute defines the scheme in which metadata is described. A scheme is a context leading to the correct interpretations of the [`content`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-content) value, like a format.\n\n**Warning:** Do not use this value, as it is obsolete. There is no replacement as there was no real usage for it."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/meta"
      }]
    }, {
      name: "style",
      description: {
        kind: "markdown",
        value: "The style element allows authors to embed style information in their documents. The style element is one of several inputs to the styling processing model. The element does not represent content for the user."
      },
      attributes: [{
        name: "media",
        description: {
          kind: "markdown",
          value: "This attribute defines which media the style should be applied to. Its value is a [media query](https://developer.mozilla.org/en-US/docs/Web/Guide/CSS/Media_queries), which defaults to `all` if the attribute is missing."
        }
      }, {
        name: "nonce",
        description: {
          kind: "markdown",
          value: "A cryptographic nonce (number used once) used to whitelist inline styles in a [style-src Content-Security-Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Security-Policy/style-src). The server must generate a unique nonce value each time it transmits a policy. It is critical to provide a nonce that cannot be guessed as bypassing a resource’s policy is otherwise trivial."
        }
      }, {
        name: "type",
        description: {
          kind: "markdown",
          value: "This attribute defines the styling language as a MIME type (charset should not be specified). This attribute is optional and defaults to `text/css` if it is not specified — there is very little reason to include this in modern web documents."
        }
      }, {
        name: "scoped",
        valueSet: "v"
      }, {
        name: "title",
        description: "This attribute specifies [alternative style sheet](https://developer.mozilla.org/en-US/docs/Web/CSS/Alternative_style_sheets) sets."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/style"
      }]
    }, {
      name: "body",
      description: {
        kind: "markdown",
        value: "The body element represents the content of the document."
      },
      attributes: [{
        name: "onafterprint",
        description: {
          kind: "markdown",
          value: "Function to call after the user has printed the document."
        }
      }, {
        name: "onbeforeprint",
        description: {
          kind: "markdown",
          value: "Function to call when the user requests printing of the document."
        }
      }, {
        name: "onbeforeunload",
        description: {
          kind: "markdown",
          value: "Function to call when the document is about to be unloaded."
        }
      }, {
        name: "onhashchange",
        description: {
          kind: "markdown",
          value: "Function to call when the fragment identifier part (starting with the hash (`'#'`) character) of the document's current address has changed."
        }
      }, {
        name: "onlanguagechange",
        description: {
          kind: "markdown",
          value: "Function to call when the preferred languages changed."
        }
      }, {
        name: "onmessage",
        description: {
          kind: "markdown",
          value: "Function to call when the document has received a message."
        }
      }, {
        name: "onoffline",
        description: {
          kind: "markdown",
          value: "Function to call when network communication has failed."
        }
      }, {
        name: "ononline",
        description: {
          kind: "markdown",
          value: "Function to call when network communication has been restored."
        }
      }, {
        name: "onpagehide"
      }, {
        name: "onpageshow"
      }, {
        name: "onpopstate",
        description: {
          kind: "markdown",
          value: "Function to call when the user has navigated session history."
        }
      }, {
        name: "onstorage",
        description: {
          kind: "markdown",
          value: "Function to call when the storage area has changed."
        }
      }, {
        name: "onunload",
        description: {
          kind: "markdown",
          value: "Function to call when the document is going away."
        }
      }, {
        name: "alink",
        description: 'Color of text for hyperlinks when selected. _This method is non-conforming, use CSS [`color`](https://developer.mozilla.org/en-US/docs/Web/CSS/color "The color CSS property sets the foreground color value of an element\'s text and text decorations, and sets the currentcolor value.") property in conjunction with the [`:active`](https://developer.mozilla.org/en-US/docs/Web/CSS/:active "The :active CSS pseudo-class represents an element (such as a button) that is being activated by the user.") pseudo-class instead._'
      }, {
        name: "background",
        description: 'URI of a image to use as a background. _This method is non-conforming, use CSS [`background`](https://developer.mozilla.org/en-US/docs/Web/CSS/background "The background shorthand CSS property sets all background style properties at once, such as color, image, origin and size, or repeat method.") property on the element instead._'
      }, {
        name: "bgcolor",
        description: 'Background color for the document. _This method is non-conforming, use CSS [`background-color`](https://developer.mozilla.org/en-US/docs/Web/CSS/background-color "The background-color CSS property sets the background color of an element.") property on the element instead._'
      }, {
        name: "bottommargin",
        description: 'The margin of the bottom of the body. _This method is non-conforming, use CSS [`margin-bottom`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-bottom "The margin-bottom CSS property sets the margin area on the bottom of an element. A positive value places it farther from its neighbors, while a negative value places it closer.") property on the element instead._'
      }, {
        name: "leftmargin",
        description: 'The margin of the left of the body. _This method is non-conforming, use CSS [`margin-left`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-left "The margin-left CSS property sets the margin area on the left side of an element. A positive value places it farther from its neighbors, while a negative value places it closer.") property on the element instead._'
      }, {
        name: "link",
        description: 'Color of text for unvisited hypertext links. _This method is non-conforming, use CSS [`color`](https://developer.mozilla.org/en-US/docs/Web/CSS/color "The color CSS property sets the foreground color value of an element\'s text and text decorations, and sets the currentcolor value.") property in conjunction with the [`:link`](https://developer.mozilla.org/en-US/docs/Web/CSS/:link "The :link CSS pseudo-class represents an element that has not yet been visited. It matches every unvisited <a>, <area>, or <link> element that has an href attribute.") pseudo-class instead._'
      }, {
        name: "onblur",
        description: "Function to call when the document loses focus."
      }, {
        name: "onerror",
        description: "Function to call when the document fails to load properly."
      }, {
        name: "onfocus",
        description: "Function to call when the document receives focus."
      }, {
        name: "onload",
        description: "Function to call when the document has finished loading."
      }, {
        name: "onredo",
        description: "Function to call when the user has moved forward in undo transaction history."
      }, {
        name: "onresize",
        description: "Function to call when the document has been resized."
      }, {
        name: "onundo",
        description: "Function to call when the user has moved backward in undo transaction history."
      }, {
        name: "rightmargin",
        description: 'The margin of the right of the body. _This method is non-conforming, use CSS [`margin-right`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-right "The margin-right CSS property sets the margin area on the right side of an element. A positive value places it farther from its neighbors, while a negative value places it closer.") property on the element instead._'
      }, {
        name: "text",
        description: 'Foreground color of text. _This method is non-conforming, use CSS [`color`](https://developer.mozilla.org/en-US/docs/Web/CSS/color "The color CSS property sets the foreground color value of an element\'s text and text decorations, and sets the currentcolor value.") property on the element instead._'
      }, {
        name: "topmargin",
        description: 'The margin of the top of the body. _This method is non-conforming, use CSS [`margin-top`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-top "The margin-top CSS property sets the margin area on the top of an element. A positive value places it farther from its neighbors, while a negative value places it closer.") property on the element instead._'
      }, {
        name: "vlink",
        description: 'Color of text for visited hypertext links. _This method is non-conforming, use CSS [`color`](https://developer.mozilla.org/en-US/docs/Web/CSS/color "The color CSS property sets the foreground color value of an element\'s text and text decorations, and sets the currentcolor value.") property in conjunction with the [`:visited`](https://developer.mozilla.org/en-US/docs/Web/CSS/:visited "The :visited CSS pseudo-class represents links that the user has already visited. For privacy reasons, the styles that can be modified using this selector are very limited.") pseudo-class instead._'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/body"
      }]
    }, {
      name: "article",
      description: {
        kind: "markdown",
        value: "The article element represents a complete, or self-contained, composition in a document, page, application, or site and that is, in principle, independently distributable or reusable, e.g. in syndication. This could be a forum post, a magazine or newspaper article, a blog entry, a user-submitted comment, an interactive widget or gadget, or any other independent item of content. Each article should be identified, typically by including a heading (h1–h6 element) as a child of the article element."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/article"
      }]
    }, {
      name: "section",
      description: {
        kind: "markdown",
        value: "The section element represents a generic section of a document or application. A section, in this context, is a thematic grouping of content. Each section should be identified, typically by including a heading ( h1- h6 element) as a child of the section element."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/section"
      }]
    }, {
      name: "nav",
      description: {
        kind: "markdown",
        value: "The nav element represents a section of a page that links to other pages or to parts within the page: a section with navigation links."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/nav"
      }]
    }, {
      name: "aside",
      description: {
        kind: "markdown",
        value: "The aside element represents a section of a page that consists of content that is tangentially related to the content around the aside element, and which could be considered separate from that content. Such sections are often represented as sidebars in printed typography."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/aside"
      }]
    }, {
      name: "h1",
      description: {
        kind: "markdown",
        value: "The h1 element represents a section heading."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
      }]
    }, {
      name: "h2",
      description: {
        kind: "markdown",
        value: "The h2 element represents a section heading."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
      }]
    }, {
      name: "h3",
      description: {
        kind: "markdown",
        value: "The h3 element represents a section heading."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
      }]
    }, {
      name: "h4",
      description: {
        kind: "markdown",
        value: "The h4 element represents a section heading."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
      }]
    }, {
      name: "h5",
      description: {
        kind: "markdown",
        value: "The h5 element represents a section heading."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
      }]
    }, {
      name: "h6",
      description: {
        kind: "markdown",
        value: "The h6 element represents a section heading."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
      }]
    }, {
      name: "header",
      description: {
        kind: "markdown",
        value: "The header element represents introductory content for its nearest ancestor sectioning content or sectioning root element. A header typically contains a group of introductory or navigational aids. When the nearest ancestor sectioning content or sectioning root element is the body element, then it applies to the whole page."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/header"
      }]
    }, {
      name: "footer",
      description: {
        kind: "markdown",
        value: "The footer element represents a footer for its nearest ancestor sectioning content or sectioning root element. A footer typically contains information about its section such as who wrote it, links to related documents, copyright data, and the like."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/footer"
      }]
    }, {
      name: "address",
      description: {
        kind: "markdown",
        value: "The address element represents the contact information for its nearest article or body element ancestor. If that is the body element, then the contact information applies to the document as a whole."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/address"
      }]
    }, {
      name: "p",
      description: {
        kind: "markdown",
        value: "The p element represents a paragraph."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/p"
      }]
    }, {
      name: "hr",
      description: {
        kind: "markdown",
        value: "The hr element represents a paragraph-level thematic break, e.g. a scene change in a story, or a transition to another topic within a section of a reference book."
      },
      void: !0,
      attributes: [{
        name: "align",
        description: "Sets the alignment of the rule on the page. If no value is specified, the default value is `left`."
      }, {
        name: "color",
        description: "Sets the color of the rule through color name or hexadecimal value."
      }, {
        name: "noshade",
        description: "Sets the rule to have no shading."
      }, {
        name: "size",
        description: "Sets the height, in pixels, of the rule."
      }, {
        name: "width",
        description: "Sets the length of the rule on the page through a pixel or percentage value."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/hr"
      }]
    }, {
      name: "pre",
      description: {
        kind: "markdown",
        value: "The pre element represents a block of preformatted text, in which structure is represented by typographic conventions rather than by elements."
      },
      attributes: [{
        name: "cols",
        description: 'Contains the _preferred_ count of characters that a line should have. It was a non-standard synonym of [`width`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/pre#attr-width). To achieve such an effect, use CSS [`width`](https://developer.mozilla.org/en-US/docs/Web/CSS/width "The width CSS property sets an element\'s width. By default it sets the width of the content area, but if box-sizing is set to border-box, it sets the width of the border area.") instead.'
      }, {
        name: "width",
        description: 'Contains the _preferred_ count of characters that a line should have. Though technically still implemented, this attribute has no visual effect; to achieve such an effect, use CSS [`width`](https://developer.mozilla.org/en-US/docs/Web/CSS/width "The width CSS property sets an element\'s width. By default it sets the width of the content area, but if box-sizing is set to border-box, it sets the width of the border area.") instead.'
      }, {
        name: "wrap",
        description: 'Is a _hint_ indicating how the overflow must happen. In modern browser this hint is ignored and no visual effect results in its present; to achieve such an effect, use CSS [`white-space`](https://developer.mozilla.org/en-US/docs/Web/CSS/white-space "The white-space CSS property sets how white space inside an element is handled.") instead.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/pre"
      }]
    }, {
      name: "blockquote",
      description: {
        kind: "markdown",
        value: "The blockquote element represents content that is quoted from another source, optionally with a citation which must be within a footer or cite element, and optionally with in-line changes such as annotations and abbreviations."
      },
      attributes: [{
        name: "cite",
        description: {
          kind: "markdown",
          value: "A URL that designates a source document or message for the information quoted. This attribute is intended to point to information explaining the context or the reference for the quote."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/blockquote"
      }]
    }, {
      name: "ol",
      description: {
        kind: "markdown",
        value: "The ol element represents a list of items, where the items have been intentionally ordered, such that changing the order would change the meaning of the document."
      },
      attributes: [{
        name: "reversed",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This Boolean attribute specifies that the items of the list are specified in reversed order."
        }
      }, {
        name: "start",
        description: {
          kind: "markdown",
          value: 'This integer attribute specifies the start value for numbering the individual list items. Although the ordering type of list elements might be Roman numerals, such as XXXI, or letters, the value of start is always represented as a number. To start numbering elements from the letter "C", use `<ol start="3">`.\n\n**Note**: This attribute was deprecated in HTML4, but reintroduced in HTML5.'
        }
      }, {
        name: "type",
        valueSet: "lt",
        description: {
          kind: "markdown",
          value: "Indicates the numbering type:\n\n*   `'a'` indicates lowercase letters,\n*   `'A'` indicates uppercase letters,\n*   `'i'` indicates lowercase Roman numerals,\n*   `'I'` indicates uppercase Roman numerals,\n*   and `'1'` indicates numbers (default).\n\nThe type set is used for the entire list unless a different [`type`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/li#attr-type) attribute is used within an enclosed [`<li>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/li \"The HTML <li> element is used to represent an item in a list. It must be contained in a parent element: an ordered list (<ol>), an unordered list (<ul>), or a menu (<menu>). In menus and unordered lists, list items are usually displayed using bullet points. In ordered lists, they are usually displayed with an ascending counter on the left, such as a number or letter.\") element.\n\n**Note:** This attribute was deprecated in HTML4, but reintroduced in HTML5.\n\nUnless the value of the list number matters (e.g. in legal or technical documents where items are to be referenced by their number/letter), the CSS [`list-style-type`](https://developer.mozilla.org/en-US/docs/Web/CSS/list-style-type \"The list-style-type CSS property sets the marker (such as a disc, character, or custom counter style) of a list item element.\") property should be used instead."
        }
      }, {
        name: "compact",
        description: 'This Boolean attribute hints that the list should be rendered in a compact style. The interpretation of this attribute depends on the user agent and it doesn\'t work in all browsers.\n\n**Warning:** Do not use this attribute, as it has been deprecated: the [`<ol>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ol "The HTML <ol> element represents an ordered list of items, typically rendered as a numbered list.") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/CSS). To give an effect similar to the `compact` attribute, the [CSS](https://developer.mozilla.org/en-US/docs/CSS) property [`line-height`](https://developer.mozilla.org/en-US/docs/Web/CSS/line-height "The line-height CSS property sets the amount of space used for lines, such as in text. On block-level elements, it specifies the minimum height of line boxes within the element. On non-replaced inline elements, it specifies the height that is used to calculate line box height.") can be used with a value of `80%`.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/ol"
      }]
    }, {
      name: "ul",
      description: {
        kind: "markdown",
        value: "The ul element represents a list of items, where the order of the items is not important — that is, where changing the order would not materially change the meaning of the document."
      },
      attributes: [{
        name: "compact",
        description: 'This Boolean attribute hints that the list should be rendered in a compact style. The interpretation of this attribute depends on the user agent and it doesn\'t work in all browsers.\n\n**Usage note: **Do not use this attribute, as it has been deprecated: the [`<ul>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ul "The HTML <ul> element represents an unordered list of items, typically rendered as a bulleted list.") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/CSS). To give a similar effect as the `compact` attribute, the [CSS](https://developer.mozilla.org/en-US/docs/CSS) property [line-height](https://developer.mozilla.org/en-US/docs/CSS/line-height) can be used with a value of `80%`.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/ul"
      }]
    }, {
      name: "li",
      description: {
        kind: "markdown",
        value: "The li element represents a list item. If its parent element is an ol, ul, or menu element, then the element is an item of the parent element's list, as defined for those elements. Otherwise, the list item has no defined list-related relationship to any other li element."
      },
      attributes: [{
        name: "value",
        description: {
          kind: "markdown",
          value: 'This integer attribute indicates the current ordinal value of the list item as defined by the [`<ol>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ol "The HTML <ol> element represents an ordered list of items, typically rendered as a numbered list.") element. The only allowed value for this attribute is a number, even if the list is displayed with Roman numerals or letters. List items that follow this one continue numbering from the value set. The **value** attribute has no meaning for unordered lists ([`<ul>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ul "The HTML <ul> element represents an unordered list of items, typically rendered as a bulleted list.")) or for menus ([`<menu>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/menu "The HTML <menu> element represents a group of commands that a user can perform or activate. This includes both list menus, which might appear across the top of a screen, as well as context menus, such as those that might appear underneath a button after it has been clicked.")).\n\n**Note**: This attribute was deprecated in HTML4, but reintroduced in HTML5.\n\n**Note:** Prior to Gecko 9.0, negative values were incorrectly converted to 0. Starting in Gecko 9.0 all integer values are correctly parsed.'
        }
      }, {
        name: "type",
        description: 'This character attribute indicates the numbering type:\n\n*   `a`: lowercase letters\n*   `A`: uppercase letters\n*   `i`: lowercase Roman numerals\n*   `I`: uppercase Roman numerals\n*   `1`: numbers\n\nThis type overrides the one used by its parent [`<ol>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ol "The HTML <ol> element represents an ordered list of items, typically rendered as a numbered list.") element, if any.\n\n**Usage note:** This attribute has been deprecated: use the CSS [`list-style-type`](https://developer.mozilla.org/en-US/docs/Web/CSS/list-style-type "The list-style-type CSS property sets the marker (such as a disc, character, or custom counter style) of a list item element.") property instead.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/li"
      }]
    }, {
      name: "dl",
      description: {
        kind: "markdown",
        value: "The dl element represents an association list consisting of zero or more name-value groups (a description list). A name-value group consists of one or more names (dt elements) followed by one or more values (dd elements), ignoring any nodes other than dt and dd elements. Within a single dl element, there should not be more than one dt element for each name."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/dl"
      }]
    }, {
      name: "dt",
      description: {
        kind: "markdown",
        value: "The dt element represents the term, or name, part of a term-description group in a description list (dl element)."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/dt"
      }]
    }, {
      name: "dd",
      description: {
        kind: "markdown",
        value: "The dd element represents the description, definition, or value, part of a term-description group in a description list (dl element)."
      },
      attributes: [{
        name: "nowrap",
        description: "If the value of this attribute is set to `yes`, the definition text will not wrap. The default value is `no`."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/dd"
      }]
    }, {
      name: "figure",
      description: {
        kind: "markdown",
        value: "The figure element represents some flow content, optionally with a caption, that is self-contained (like a complete sentence) and is typically referenced as a single unit from the main flow of the document."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/figure"
      }]
    }, {
      name: "figcaption",
      description: {
        kind: "markdown",
        value: "The figcaption element represents a caption or legend for the rest of the contents of the figcaption element's parent figure element, if any."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/figcaption"
      }]
    }, {
      name: "main",
      description: {
        kind: "markdown",
        value: "The main element represents the main content of the body of a document or application. The main content area consists of content that is directly related to or expands upon the central topic of a document or central functionality of an application."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/main"
      }]
    }, {
      name: "div",
      description: {
        kind: "markdown",
        value: "The div element has no special meaning at all. It represents its children. It can be used with the class, lang, and title attributes to mark up semantics common to a group of consecutive elements."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/div"
      }]
    }, {
      name: "a",
      description: {
        kind: "markdown",
        value: "If the a element has an href attribute, then it represents a hyperlink (a hypertext anchor) labeled by its contents."
      },
      attributes: [{
        name: "href",
        description: {
          kind: "markdown",
          value: 'Contains a URL or a URL fragment that the hyperlink points to.\nA URL fragment is a name preceded by a hash mark (`#`), which specifies an internal target location (an [`id`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes#attr-id) of an HTML element) within the current document. URLs are not restricted to Web (HTTP)-based documents, but can use any protocol supported by the browser. For example, [`file:`](https://en.wikipedia.org/wiki/File_URI_scheme), `ftp:`, and `mailto:` work in most browsers.\n\n**Note:** You can use `href="#top"` or the empty fragment `href="#"` to link to the top of the current page. [This behavior is specified by HTML5](https://www.w3.org/TR/html5/single-page.html#scroll-to-fragid).'
        }
      }, {
        name: "target",
        valueSet: "target",
        description: {
          kind: "markdown",
          value: 'Specifies where to display the linked URL. It is a name of, or keyword for, a _browsing context_: a tab, window, or `<iframe>`. The following keywords have special meanings:\n\n*   `_self`: Load the URL into the same browsing context as the current one. This is the default behavior.\n*   `_blank`: Load the URL into a new browsing context. This is usually a tab, but users can configure browsers to use new windows instead.\n*   `_parent`: Load the URL into the parent browsing context of the current one. If there is no parent, this behaves the same way as `_self`.\n*   `_top`: Load the URL into the top-level browsing context (that is, the "highest" browsing context that is an ancestor of the current one, and has no parent). If there is no parent, this behaves the same way as `_self`.\n\n**Note:** When using `target`, consider adding `rel="noreferrer"` to avoid exploitation of the `window.opener` API.\n\n**Note:** Linking to another page using `target="_blank"` will run the new page on the same process as your page. If the new page is executing expensive JS, your page\'s performance may suffer. To avoid this use `rel="noopener"`.'
        }
      }, {
        name: "download",
        description: {
          kind: "markdown",
          value: "This attribute instructs browsers to download a URL instead of navigating to it, so the user will be prompted to save it as a local file. If the attribute has a value, it is used as the pre-filled file name in the Save prompt (the user can still change the file name if they want). There are no restrictions on allowed values, though `/` and `\\` are converted to underscores. Most file systems limit some punctuation in file names, and browsers will adjust the suggested name accordingly.\n\n**Notes:**\n\n*   This attribute only works for [same-origin URLs](https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy).\n*   Although HTTP(s) URLs need to be in the same-origin, [`blob:` URLs](https://developer.mozilla.org/en-US/docs/Web/API/URL.createObjectURL) and [`data:` URLs](https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs) are allowed so that content generated by JavaScript, such as pictures created in an image-editor Web app, can be downloaded.\n*   If the HTTP header [`Content-Disposition:`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Disposition) gives a different filename than this attribute, the HTTP header takes priority over this attribute.\n*   If `Content-Disposition:` is set to `inline`, Firefox prioritizes `Content-Disposition`, like the filename case, while Chrome prioritizes the `download` attribute."
        }
      }, {
        name: "ping",
        description: {
          kind: "markdown",
          value: 'Contains a space-separated list of URLs to which, when the hyperlink is followed, [`POST`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/POST "The HTTP POST method sends data to the server. The type of the body of the request is indicated by the Content-Type header.") requests with the body `PING` will be sent by the browser (in the background). Typically used for tracking.'
        }
      }, {
        name: "rel",
        description: {
          kind: "markdown",
          value: "Specifies the relationship of the target object to the link object. The value is a space-separated list of [link types](https://developer.mozilla.org/en-US/docs/Web/HTML/Link_types)."
        }
      }, {
        name: "hreflang",
        description: {
          kind: "markdown",
          value: 'This attribute indicates the human language of the linked resource. It is purely advisory, with no built-in functionality. Allowed values are determined by [BCP47](https://www.ietf.org/rfc/bcp/bcp47.txt "Tags for Identifying Languages").'
        }
      }, {
        name: "type",
        description: {
          kind: "markdown",
          value: 'Specifies the media type in the form of a [MIME type](https://developer.mozilla.org/en-US/docs/Glossary/MIME_type "MIME type: A MIME type (now properly called "media type", but also sometimes "content type") is a string sent along with a file indicating the type of the file (describing the content format, for example, a sound file might be labeled audio/ogg, or an image file image/png).") for the linked URL. It is purely advisory, with no built-in functionality.'
        }
      }, {
        name: "referrerpolicy",
        description: "Indicates which [referrer](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer) to send when fetching the URL:\n\n*   `'no-referrer'` means the `Referer:` header will not be sent.\n*   `'no-referrer-when-downgrade'` means no `Referer:` header will be sent when navigating to an origin without HTTPS. This is the default behavior.\n*   `'origin'` means the referrer will be the [origin](https://developer.mozilla.org/en-US/docs/Glossary/Origin) of the page, not including information after the domain.\n*   `'origin-when-cross-origin'` meaning that navigations to other origins will be limited to the scheme, the host and the port, while navigations on the same origin will include the referrer's path.\n*   `'strict-origin-when-cross-origin'`\n*   `'unsafe-url'` means the referrer will include the origin and path, but not the fragment, password, or username. This is unsafe because it can leak data from secure URLs to insecure ones."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/a"
      }]
    }, {
      name: "em",
      description: {
        kind: "markdown",
        value: "The em element represents stress emphasis of its contents."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/em"
      }]
    }, {
      name: "strong",
      description: {
        kind: "markdown",
        value: "The strong element represents strong importance, seriousness, or urgency for its contents."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/strong"
      }]
    }, {
      name: "small",
      description: {
        kind: "markdown",
        value: "The small element represents side comments such as small print."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/small"
      }]
    }, {
      name: "s",
      description: {
        kind: "markdown",
        value: "The s element represents contents that are no longer accurate or no longer relevant."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/s"
      }]
    }, {
      name: "cite",
      description: {
        kind: "markdown",
        value: "The cite element represents a reference to a creative work. It must include the title of the work or the name of the author(person, people or organization) or an URL reference, or a reference in abbreviated form as per the conventions used for the addition of citation metadata."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/cite"
      }]
    }, {
      name: "q",
      description: {
        kind: "markdown",
        value: "The q element represents some phrasing content quoted from another source."
      },
      attributes: [{
        name: "cite",
        description: {
          kind: "markdown",
          value: "The value of this attribute is a URL that designates a source document or message for the information quoted. This attribute is intended to point to information explaining the context or the reference for the quote."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/q"
      }]
    }, {
      name: "dfn",
      description: {
        kind: "markdown",
        value: "The dfn element represents the defining instance of a term. The paragraph, description list group, or section that is the nearest ancestor of the dfn element must also contain the definition(s) for the term given by the dfn element."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/dfn"
      }]
    }, {
      name: "abbr",
      description: {
        kind: "markdown",
        value: "The abbr element represents an abbreviation or acronym, optionally with its expansion. The title attribute may be used to provide an expansion of the abbreviation. The attribute, if specified, must contain an expansion of the abbreviation, and nothing else."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/abbr"
      }]
    }, {
      name: "ruby",
      description: {
        kind: "markdown",
        value: "The ruby element allows one or more spans of phrasing content to be marked with ruby annotations. Ruby annotations are short runs of text presented alongside base text, primarily used in East Asian typography as a guide for pronunciation or to include other annotations. In Japanese, this form of typography is also known as furigana. Ruby text can appear on either side, and sometimes both sides, of the base text, and it is possible to control its position using CSS. A more complete introduction to ruby can be found in the Use Cases & Exploratory Approaches for Ruby Markup document as well as in CSS Ruby Module Level 1. [RUBY-UC] [CSSRUBY]"
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/ruby"
      }]
    }, {
      name: "rb",
      description: {
        kind: "markdown",
        value: "The rb element marks the base text component of a ruby annotation. When it is the child of a ruby element, it doesn't represent anything itself, but its parent ruby element uses it as part of determining what it represents."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/rb"
      }]
    }, {
      name: "rt",
      description: {
        kind: "markdown",
        value: "The rt element marks the ruby text component of a ruby annotation. When it is the child of a ruby element or of an rtc element that is itself the child of a ruby element, it doesn't represent anything itself, but its ancestor ruby element uses it as part of determining what it represents."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/rt"
      }]
    }, {
      name: "rp",
      description: {
        kind: "markdown",
        value: "The rp element is used to provide fallback text to be shown by user agents that don't support ruby annotations. One widespread convention is to provide parentheses around the ruby text component of a ruby annotation."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/rp"
      }]
    }, {
      name: "time",
      description: {
        kind: "markdown",
        value: "The time element represents its contents, along with a machine-readable form of those contents in the datetime attribute. The kind of content is limited to various kinds of dates, times, time-zone offsets, and durations, as described below."
      },
      attributes: [{
        name: "datetime",
        description: {
          kind: "markdown",
          value: "This attribute indicates the time and/or date of the element and must be in one of the formats described below."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/time"
      }]
    }, {
      name: "code",
      description: {
        kind: "markdown",
        value: "The code element represents a fragment of computer code. This could be an XML element name, a file name, a computer program, or any other string that a computer would recognize."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/code"
      }]
    }, {
      name: "var",
      description: {
        kind: "markdown",
        value: "The var element represents a variable. This could be an actual variable in a mathematical expression or programming context, an identifier representing a constant, a symbol identifying a physical quantity, a function parameter, or just be a term used as a placeholder in prose."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/var"
      }]
    }, {
      name: "samp",
      description: {
        kind: "markdown",
        value: "The samp element represents sample or quoted output from another program or computing system."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/samp"
      }]
    }, {
      name: "kbd",
      description: {
        kind: "markdown",
        value: "The kbd element represents user input (typically keyboard input, although it may also be used to represent other input, such as voice commands)."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/kbd"
      }]
    }, {
      name: "sub",
      description: {
        kind: "markdown",
        value: "The sub element represents a subscript."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/sub"
      }]
    }, {
      name: "sup",
      description: {
        kind: "markdown",
        value: "The sup element represents a superscript."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/sup"
      }]
    }, {
      name: "i",
      description: {
        kind: "markdown",
        value: "The i element represents a span of text in an alternate voice or mood, or otherwise offset from the normal prose in a manner indicating a different quality of text, such as a taxonomic designation, a technical term, an idiomatic phrase from another language, transliteration, a thought, or a ship name in Western texts."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/i"
      }]
    }, {
      name: "b",
      description: {
        kind: "markdown",
        value: "The b element represents a span of text to which attention is being drawn for utilitarian purposes without conveying any extra importance and with no implication of an alternate voice or mood, such as key words in a document abstract, product names in a review, actionable words in interactive text-driven software, or an article lede."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/b"
      }]
    }, {
      name: "u",
      description: {
        kind: "markdown",
        value: "The u element represents a span of text with an unarticulated, though explicitly rendered, non-textual annotation, such as labeling the text as being a proper name in Chinese text (a Chinese proper name mark), or labeling the text as being misspelt."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/u"
      }]
    }, {
      name: "mark",
      description: {
        kind: "markdown",
        value: "The mark element represents a run of text in one document marked or highlighted for reference purposes, due to its relevance in another context. When used in a quotation or other block of text referred to from the prose, it indicates a highlight that was not originally present but which has been added to bring the reader's attention to a part of the text that might not have been considered important by the original author when the block was originally written, but which is now under previously unexpected scrutiny. When used in the main prose of a document, it indicates a part of the document that has been highlighted due to its likely relevance to the user's current activity."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/mark"
      }]
    }, {
      name: "bdi",
      description: {
        kind: "markdown",
        value: "The bdi element represents a span of text that is to be isolated from its surroundings for the purposes of bidirectional text formatting. [BIDI]"
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/bdi"
      }]
    }, {
      name: "bdo",
      description: {
        kind: "markdown",
        value: "The bdo element represents explicit text directionality formatting control for its children. It allows authors to override the Unicode bidirectional algorithm by explicitly specifying a direction override. [BIDI]"
      },
      attributes: [{
        name: "dir",
        description: "The direction in which text should be rendered in this element's contents. Possible values are:\n\n*   `ltr`: Indicates that the text should go in a left-to-right direction.\n*   `rtl`: Indicates that the text should go in a right-to-left direction."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/bdo"
      }]
    }, {
      name: "span",
      description: {
        kind: "markdown",
        value: "The span element doesn't mean anything on its own, but can be useful when used together with the global attributes, e.g. class, lang, or dir. It represents its children."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/span"
      }]
    }, {
      name: "br",
      description: {
        kind: "markdown",
        value: "The br element represents a line break."
      },
      void: !0,
      attributes: [{
        name: "clear",
        description: "Indicates where to begin the next line after the break."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/br"
      }]
    }, {
      name: "wbr",
      description: {
        kind: "markdown",
        value: "The wbr element represents a line break opportunity."
      },
      void: !0,
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/wbr"
      }]
    }, {
      name: "ins",
      description: {
        kind: "markdown",
        value: "The ins element represents an addition to the document."
      },
      attributes: [{
        name: "cite",
        description: "This attribute defines the URI of a resource that explains the change, such as a link to meeting minutes or a ticket in a troubleshooting system."
      }, {
        name: "datetime",
        description: 'This attribute indicates the time and date of the change and must be a valid date with an optional time string. If the value cannot be parsed as a date with an optional time string, the element does not have an associated time stamp. For the format of the string without a time, see [Format of a valid date string](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#Format_of_a_valid_date_string "Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.") in [Date and time formats used in HTML](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats "Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article."). The format of the string if it includes both date and time is covered in [Format of a valid local date and time string](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#Format_of_a_valid_local_date_and_time_string "Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.") in [Date and time formats used in HTML](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats "Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.").'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/ins"
      }]
    }, {
      name: "del",
      description: {
        kind: "markdown",
        value: "The del element represents a removal from the document."
      },
      attributes: [{
        name: "cite",
        description: {
          kind: "markdown",
          value: "A URI for a resource that explains the change (for example, meeting minutes)."
        }
      }, {
        name: "datetime",
        description: {
          kind: "markdown",
          value: 'This attribute indicates the time and date of the change and must be a valid date string with an optional time. If the value cannot be parsed as a date with an optional time string, the element does not have an associated time stamp. For the format of the string without a time, see [Format of a valid date string](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#Format_of_a_valid_date_string "Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.") in [Date and time formats used in HTML](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats "Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article."). The format of the string if it includes both date and time is covered in [Format of a valid local date and time string](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#Format_of_a_valid_local_date_and_time_string "Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.") in [Date and time formats used in HTML](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats "Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.").'
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/del"
      }]
    }, {
      name: "picture",
      description: {
        kind: "markdown",
        value: "The picture element is a container which provides multiple sources to its contained img element to allow authors to declaratively control or give hints to the user agent about which image resource to use, based on the screen pixel density, viewport size, image format, and other factors. It represents its children."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/picture"
      }]
    }, {
      name: "img",
      description: {
        kind: "markdown",
        value: "An img element represents an image."
      },
      void: !0,
      attributes: [{
        name: "alt",
        description: {
          kind: "markdown",
          value: 'This attribute defines an alternative text description of the image.\n\n**Note:** Browsers do not always display the image referenced by the element. This is the case for non-graphical browsers (including those used by people with visual impairments), if the user chooses not to display images, or if the browser cannot display the image because it is invalid or an [unsupported type](#Supported_image_formats). In these cases, the browser may replace the image with the text defined in this element\'s `alt` attribute. You should, for these reasons and others, provide a useful value for `alt` whenever possible.\n\n**Note:** Omitting this attribute altogether indicates that the image is a key part of the content, and no textual equivalent is available. Setting this attribute to an empty string (`alt=""`) indicates that this image is _not_ a key part of the content (decorative), and that non-visual browsers may omit it from rendering.'
        }
      }, {
        name: "src",
        description: {
          kind: "markdown",
          value: "The image URL. This attribute is mandatory for the `<img>` element. On browsers supporting `srcset`, `src` is treated like a candidate image with a pixel density descriptor `1x` unless an image with this pixel density descriptor is already defined in `srcset,` or unless `srcset` contains '`w`' descriptors."
        }
      }, {
        name: "srcset",
        description: {
          kind: "markdown",
          value: "A list of one or more strings separated by commas indicating a set of possible image sources for the user agent to use. Each string is composed of:\n\n1.  a URL to an image,\n2.  optionally, whitespace followed by one of:\n    *   A width descriptor, or a positive integer directly followed by '`w`'. The width descriptor is divided by the source size given in the `sizes` attribute to calculate the effective pixel density.\n    *   A pixel density descriptor, which is a positive floating point number directly followed by '`x`'.\n\nIf no descriptor is specified, the source is assigned the default descriptor: `1x`.\n\nIt is incorrect to mix width descriptors and pixel density descriptors in the same `srcset` attribute. Duplicate descriptors (for instance, two sources in the same `srcset` which are both described with '`2x`') are also invalid.\n\nThe user agent selects any one of the available sources at its discretion. This provides them with significant leeway to tailor their selection based on things like user preferences or bandwidth conditions. See our [Responsive images](https://developer.mozilla.org/en-US/docs/Learn/HTML/Multimedia_and_embedding/Responsive_images) tutorial for an example."
        }
      }, {
        name: "crossorigin",
        valueSet: "xo",
        description: {
          kind: "markdown",
          value: 'This enumerated attribute indicates if the fetching of the related image must be done using CORS or not. [CORS-enabled images](https://developer.mozilla.org/en-US/docs/CORS_Enabled_Image) can be reused in the [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas "Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.") element without being "[tainted](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_enabled_image#What_is_a_tainted_canvas)." The allowed values are:\n`anonymous`\n\nA cross-origin request (i.e., with `Origin:` HTTP header) is performed, but no credential is sent (i.e., no cookie, X.509 certificate, or HTTP Basic authentication). If the server does not give credentials to the origin site (by not setting the [`Access-Control-Allow-Origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Origin "The Access-Control-Allow-Origin response header indicates whether the response can be shared with requesting code from the given origin.") HTTP header), the image will be tainted and its usage restricted.\n\n`use-credentials`\n\nA cross-origin request (i.e., with the [`Origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Origin "The Origin request header indicates where a fetch originates from. It doesn\'t include any path information, but only the server name. It is sent with CORS requests, as well as with POST requests. It is similar to the Referer header, but, unlike this header, it doesn\'t disclose the whole path.") HTTP header) performed along with credentials sent (i.e., a cookie, certificate, or HTTP Basic authentication). If the server does not give credentials to the origin site (through the `Access-Control-Allow-Credentials` HTTP header), the image will be tainted and its usage restricted.\n\nIf the attribute is not present, the resource is fetched without a CORS request (i.e., without sending the `Origin` HTTP header), preventing its non-tainted usage in [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas "Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.") elements. If invalid, it is handled as if the `anonymous` value was used. See [CORS settings attributes](https://developer.mozilla.org/en-US/docs/HTML/CORS_settings_attributes) for additional information.'
        }
      }, {
        name: "usemap",
        description: {
          kind: "markdown",
          value: 'The partial URL (starting with \'#\') of an [image map](https://developer.mozilla.org/en-US/docs/HTML/Element/map) associated with the element.\n\n**Note:** You cannot use this attribute if the `<img>` element is a descendant of an [`<a>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a "The HTML <a> element (or anchor element) creates a hyperlink to other web pages, files, locations within the same page, email addresses, or any other URL.") or [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") element.'
        }
      }, {
        name: "ismap",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: 'This Boolean attribute indicates that the image is part of a server-side map. If so, the precise coordinates of a click are sent to the server.\n\n**Note:** This attribute is allowed only if the `<img>` element is a descendant of an [`<a>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a "The HTML <a> element (or anchor element) creates a hyperlink to other web pages, files, locations within the same page, email addresses, or any other URL.") element with a valid [`href`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a#attr-href) attribute.'
        }
      }, {
        name: "width",
        description: {
          kind: "markdown",
          value: "The intrinsic width of the image in pixels."
        }
      }, {
        name: "height",
        description: {
          kind: "markdown",
          value: "The intrinsic height of the image in pixels."
        }
      }, {
        name: "decoding",
        valueSet: "decoding",
        description: {
          kind: "markdown",
          value: `Provides an image decoding hint to the browser. The allowed values are:
\`sync\`

Decode the image synchronously for atomic presentation with other content.

\`async\`

Decode the image asynchronously to reduce delay in presenting other content.

\`auto\`

Default mode, which indicates no preference for the decoding mode. The browser decides what is best for the user.`
        }
      }, {
        name: "loading",
        valueSet: "loading",
        description: {
          kind: "markdown",
          value: "Indicates how the browser should load the image."
        }
      }, {
        name: "referrerpolicy",
        valueSet: "referrerpolicy",
        description: {
          kind: "markdown",
          value: "A string indicating which referrer to use when fetching the resource:\n\n*   `no-referrer:` The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer \"The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.\") header will not be sent.\n*   `no-referrer-when-downgrade:` No `Referer` header will be sent when navigating to an origin without TLS (HTTPS). This is a user agent’s default behavior if no policy is otherwise specified.\n*   `origin:` The `Referer` header will include the page of origin's scheme, the host, and the port.\n*   `origin-when-cross-origin:` Navigating to other origins will limit the included referral data to the scheme, the host and the port, while navigating from the same origin will include the referrer's full path.\n*   `unsafe-url:` The `Referer` header will include the origin and the path, but not the fragment, password, or username. This case is unsafe because it can leak origins and paths from TLS-protected resources to insecure origins."
        }
      }, {
        name: "sizes",
        description: {
          kind: "markdown",
          value: "A list of one or more strings separated by commas indicating a set of source sizes. Each source size consists of:\n\n1.  a media condition. This must be omitted for the last item.\n2.  a source size value.\n\nSource size values specify the intended display size of the image. User agents use the current source size to select one of the sources supplied by the `srcset` attribute, when those sources are described using width ('`w`') descriptors. The selected source size affects the intrinsic size of the image (the image’s display size if no CSS styling is applied). If the `srcset` attribute is absent, or contains no values with a width (`w`) descriptor, then the `sizes` attribute has no effect."
        }
      }, {
        name: "importance",
        description: "Indicates the relative importance of the resource. Priority hints are delegated using the values:"
      }, {
        name: "importance",
        description: "`auto`: Indicates **no preference**. The browser may use its own heuristics to decide the priority of the image.\n\n`high`: Indicates to the browser that the image is of **high** priority.\n\n`low`: Indicates to the browser that the image is of **low** priority."
      }, {
        name: "intrinsicsize",
        description: "This attribute tells the browser to ignore the actual intrinsic size of the image and pretend it’s the size specified in the attribute. Specifically, the image would raster at these dimensions and `naturalWidth`/`naturalHeight` on images would return the values specified in this attribute. [Explainer](https://github.com/ojanvafai/intrinsicsize-attribute), [examples](https://googlechrome.github.io/samples/intrinsic-size/index.html)"
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/img"
      }]
    }, {
      name: "iframe",
      description: {
        kind: "markdown",
        value: "The iframe element represents a nested browsing context."
      },
      attributes: [{
        name: "src",
        description: {
          kind: "markdown",
          value: 'The URL of the page to embed. Use a value of `about:blank` to embed an empty page that conforms to the [same-origin policy](https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy#Inherited_origins). Also note that programatically removing an `<iframe>`\'s src attribute (e.g. via [`Element.removeAttribute()`](https://developer.mozilla.org/en-US/docs/Web/API/Element/removeAttribute "The Element method removeAttribute() removes the attribute with the specified name from the element.")) causes `about:blank` to be loaded in the frame in Firefox (from version 65), Chromium-based browsers, and Safari/iOS.'
        }
      }, {
        name: "srcdoc",
        description: {
          kind: "markdown",
          value: "Inline HTML to embed, overriding the `src` attribute. If a browser does not support the `srcdoc` attribute, it will fall back to the URL in the `src` attribute."
        }
      }, {
        name: "name",
        description: {
          kind: "markdown",
          value: 'A targetable name for the embedded browsing context. This can be used in the `target` attribute of the [`<a>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a "The HTML <a> element (or anchor element) creates a hyperlink to other web pages, files, locations within the same page, email addresses, or any other URL."), [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server."), or [`<base>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/base "The HTML <base> element specifies the base URL to use for all relative URLs contained within a document. There can be only one <base> element in a document.") elements; the `formtarget` attribute of the [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") or [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") elements; or the `windowName` parameter in the [`window.open()`](https://developer.mozilla.org/en-US/docs/Web/API/Window/open "The Window interface\'s open() method loads the specified resource into the browsing context (window, <iframe> or tab) with the specified name. If the name doesn\'t exist, then a new window is opened and the specified resource is loaded into its browsing context.") method.'
        }
      }, {
        name: "sandbox",
        valueSet: "sb",
        description: {
          kind: "markdown",
          value: 'Applies extra restrictions to the content in the frame. The value of the attribute can either be empty to apply all restrictions, or space-separated tokens to lift particular restrictions:\n\n*   `allow-forms`: Allows the resource to submit forms. If this keyword is not used, form submission is blocked.\n*   `allow-modals`: Lets the resource [open modal windows](https://html.spec.whatwg.org/multipage/origin.html#sandboxed-modals-flag).\n*   `allow-orientation-lock`: Lets the resource [lock the screen orientation](https://developer.mozilla.org/en-US/docs/Web/API/Screen/lockOrientation).\n*   `allow-pointer-lock`: Lets the resource use the [Pointer Lock API](https://developer.mozilla.org/en-US/docs/WebAPI/Pointer_Lock).\n*   `allow-popups`: Allows popups (such as `window.open()`, `target="_blank"`, or `showModalDialog()`). If this keyword is not used, the popup will silently fail to open.\n*   `allow-popups-to-escape-sandbox`: Lets the sandboxed document open new windows without those windows inheriting the sandboxing. For example, this can safely sandbox an advertisement without forcing the same restrictions upon the page the ad links to.\n*   `allow-presentation`: Lets the resource start a [presentation session](https://developer.mozilla.org/en-US/docs/Web/API/PresentationRequest).\n*   `allow-same-origin`: If this token is not used, the resource is treated as being from a special origin that always fails the [same-origin policy](https://developer.mozilla.org/en-US/docs/Glossary/same-origin_policy "same-origin policy: The same-origin policy is a critical security mechanism that restricts how a document or script loaded from one origin can interact with a resource from another origin.").\n*   `allow-scripts`: Lets the resource run scripts (but not create popup windows).\n*   `allow-storage-access-by-user-activation` : Lets the resource request access to the parent\'s storage capabilities with the [Storage Access API](https://developer.mozilla.org/en-US/docs/Web/API/Storage_Access_API).\n*   `allow-top-navigation`: Lets the resource navigate the top-level browsing context (the one named `_top`).\n*   `allow-top-navigation-by-user-activation`: Lets the resource navigate the top-level browsing context, but only if initiated by a user gesture.\n\n**Notes about sandboxing:**\n\n*   When the embedded document has the same origin as the embedding page, it is **strongly discouraged** to use both `allow-scripts` and `allow-same-origin`, as that lets the embedded document remove the `sandbox` attribute — making it no more secure than not using the `sandbox` attribute at all.\n*   Sandboxing is useless if the attacker can display content outside a sandboxed `iframe` — such as if the viewer opens the frame in a new tab. Such content should be also served from a _separate origin_ to limit potential damage.\n*   The `sandbox` attribute is unsupported in Internet Explorer 9 and earlier.'
        }
      }, {
        name: "seamless",
        valueSet: "v"
      }, {
        name: "allowfullscreen",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: 'Set to `true` if the `<iframe>` can activate fullscreen mode by calling the [`requestFullscreen()`](https://developer.mozilla.org/en-US/docs/Web/API/Element/requestFullscreen "The Element.requestFullscreen() method issues an asynchronous request to make the element be displayed in full-screen mode.") method.\nThis attribute is considered a legacy attribute and redefined as `allow="fullscreen"`.'
        }
      }, {
        name: "width",
        description: {
          kind: "markdown",
          value: "The width of the frame in CSS pixels. Default is `300`."
        }
      }, {
        name: "height",
        description: {
          kind: "markdown",
          value: "The height of the frame in CSS pixels. Default is `150`."
        }
      }, {
        name: "allow",
        description: "Specifies a [feature policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/Feature_Policy) for the `<iframe>`."
      }, {
        name: "allowpaymentrequest",
        description: "Set to `true` if a cross-origin `<iframe>` should be allowed to invoke the [Payment Request API](https://developer.mozilla.org/en-US/docs/Web/API/Payment_Request_API)."
      }, {
        name: "allowpaymentrequest",
        description: 'This attribute is considered a legacy attribute and redefined as `allow="payment"`.'
      }, {
        name: "csp",
        description: 'A [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) enforced for the embedded resource. See [`HTMLIFrameElement.csp`](https://developer.mozilla.org/en-US/docs/Web/API/HTMLIFrameElement/csp "The csp property of the HTMLIFrameElement interface specifies the Content Security Policy that an embedded document must agree to enforce upon itself.") for details.'
      }, {
        name: "importance",
        description: `The download priority of the resource in the \`<iframe>\`'s \`src\` attribute. Allowed values:

\`auto\` (default)

No preference. The browser uses its own heuristics to decide the priority of the resource.

\`high\`

The resource should be downloaded before other lower-priority page resources.

\`low\`

The resource should be downloaded after other higher-priority page resources.`
      }, {
        name: "referrerpolicy",
        description: 'Indicates which [referrer](https://developer.mozilla.org/en-US/docs/Web/API/Document/referrer) to send when fetching the frame\'s resource:\n\n*   `no-referrer`: The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer "The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.") header will not be sent.\n*   `no-referrer-when-downgrade` (default): The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer "The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.") header will not be sent to [origin](https://developer.mozilla.org/en-US/docs/Glossary/origin "origin: Web content\'s origin is defined by the scheme (protocol), host (domain), and port of the URL used to access it. Two objects have the same origin only when the scheme, host, and port all match.")s without [TLS](https://developer.mozilla.org/en-US/docs/Glossary/TLS "TLS: Transport Layer Security (TLS), previously known as Secure Sockets Layer (SSL), is a protocol used by applications to communicate securely across a network, preventing tampering with and eavesdropping on email, web browsing, messaging, and other protocols.") ([HTTPS](https://developer.mozilla.org/en-US/docs/Glossary/HTTPS "HTTPS: HTTPS (HTTP Secure) is an encrypted version of the HTTP protocol. It usually uses SSL or TLS to encrypt all communication between a client and a server. This secure connection allows clients to safely exchange sensitive data with a server, for example for banking activities or online shopping.")).\n*   `origin`: The sent referrer will be limited to the origin of the referring page: its [scheme](https://developer.mozilla.org/en-US/docs/Archive/Mozilla/URIScheme), [host](https://developer.mozilla.org/en-US/docs/Glossary/host "host: A host is a device connected to the Internet (or a local network). Some hosts called servers offer additional services like serving webpages or storing files and emails."), and [port](https://developer.mozilla.org/en-US/docs/Glossary/port "port: For a computer connected to a network with an IP address, a port is a communication endpoint. Ports are designated by numbers, and below 1024 each port is associated by default with a specific protocol.").\n*   `origin-when-cross-origin`: The referrer sent to other origins will be limited to the scheme, the host, and the port. Navigations on the same origin will still include the path.\n*   `same-origin`: A referrer will be sent for [same origin](https://developer.mozilla.org/en-US/docs/Glossary/Same-origin_policy "same origin: The same-origin policy is a critical security mechanism that restricts how a document or script loaded from one origin can interact with a resource from another origin."), but cross-origin requests will contain no referrer information.\n*   `strict-origin`: Only send the origin of the document as the referrer when the protocol security level stays the same (HTTPS→HTTPS), but don\'t send it to a less secure destination (HTTPS→HTTP).\n*   `strict-origin-when-cross-origin`: Send a full URL when performing a same-origin request, only send the origin when the protocol security level stays the same (HTTPS→HTTPS), and send no header to a less secure destination (HTTPS→HTTP).\n*   `unsafe-url`: The referrer will include the origin _and_ the path (but not the [fragment](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/hash), [password](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/password), or [username](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/username)). **This value is unsafe**, because it leaks origins and paths from TLS-protected resources to insecure origins.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/iframe"
      }]
    }, {
      name: "embed",
      description: {
        kind: "markdown",
        value: "The embed element provides an integration point for an external (typically non-HTML) application or interactive content."
      },
      void: !0,
      attributes: [{
        name: "src",
        description: {
          kind: "markdown",
          value: "The URL of the resource being embedded."
        }
      }, {
        name: "type",
        description: {
          kind: "markdown",
          value: "The MIME type to use to select the plug-in to instantiate."
        }
      }, {
        name: "width",
        description: {
          kind: "markdown",
          value: "The displayed width of the resource, in [CSS pixels](https://drafts.csswg.org/css-values/#px). This must be an absolute value; percentages are _not_ allowed."
        }
      }, {
        name: "height",
        description: {
          kind: "markdown",
          value: "The displayed height of the resource, in [CSS pixels](https://drafts.csswg.org/css-values/#px). This must be an absolute value; percentages are _not_ allowed."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/embed"
      }]
    }, {
      name: "object",
      description: {
        kind: "markdown",
        value: "The object element can represent an external resource, which, depending on the type of the resource, will either be treated as an image, as a nested browsing context, or as an external resource to be processed by a plugin."
      },
      attributes: [{
        name: "data",
        description: {
          kind: "markdown",
          value: "The address of the resource as a valid URL. At least one of **data** and **type** must be defined."
        }
      }, {
        name: "type",
        description: {
          kind: "markdown",
          value: "The [content type](https://developer.mozilla.org/en-US/docs/Glossary/Content_type) of the resource specified by **data**. At least one of **data** and **type** must be defined."
        }
      }, {
        name: "typemustmatch",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This Boolean attribute indicates if the **type** attribute and the actual [content type](https://developer.mozilla.org/en-US/docs/Glossary/Content_type) of the resource must match to be used."
        }
      }, {
        name: "name",
        description: {
          kind: "markdown",
          value: "The name of valid browsing context (HTML5), or the name of the control (HTML 4)."
        }
      }, {
        name: "usemap",
        description: {
          kind: "markdown",
          value: "A hash-name reference to a [`<map>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/map \"The HTML <map> element is used with <area> elements to define an image map (a clickable link area).\") element; that is a '#' followed by the value of a [`name`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/map#attr-name) of a map element."
        }
      }, {
        name: "form",
        description: {
          kind: "markdown",
          value: 'The form element, if any, that the object element is associated with (its _form owner_). The value of the attribute must be an ID of a [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.") element in the same document.'
        }
      }, {
        name: "width",
        description: {
          kind: "markdown",
          value: "The width of the display resource, in [CSS pixels](https://drafts.csswg.org/css-values/#px). -- (Absolute values only. [NO percentages](https://html.spec.whatwg.org/multipage/embedded-content.html#dimension-attributes))"
        }
      }, {
        name: "height",
        description: {
          kind: "markdown",
          value: "The height of the displayed resource, in [CSS pixels](https://drafts.csswg.org/css-values/#px). -- (Absolute values only. [NO percentages](https://html.spec.whatwg.org/multipage/embedded-content.html#dimension-attributes))"
        }
      }, {
        name: "archive",
        description: "A space-separated list of URIs for archives of resources for the object."
      }, {
        name: "border",
        description: "The width of a border around the control, in pixels."
      }, {
        name: "classid",
        description: "The URI of the object's implementation. It can be used together with, or in place of, the **data** attribute."
      }, {
        name: "codebase",
        description: "The base path used to resolve relative URIs specified by **classid**, **data**, or **archive**. If not specified, the default is the base URI of the current document."
      }, {
        name: "codetype",
        description: "The content type of the data specified by **classid**."
      }, {
        name: "declare",
        description: "The presence of this Boolean attribute makes this element a declaration only. The object must be instantiated by a subsequent `<object>` element. In HTML5, repeat the <object> element completely each that that the resource is reused."
      }, {
        name: "standby",
        description: "A message that the browser can show while loading the object's implementation and data."
      }, {
        name: "tabindex",
        description: "The position of the element in the tabbing navigation order for the current document."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/object"
      }]
    }, {
      name: "param",
      description: {
        kind: "markdown",
        value: "The param element defines parameters for plugins invoked by object elements. It does not represent anything on its own."
      },
      void: !0,
      attributes: [{
        name: "name",
        description: {
          kind: "markdown",
          value: "Name of the parameter."
        }
      }, {
        name: "value",
        description: {
          kind: "markdown",
          value: "Specifies the value of the parameter."
        }
      }, {
        name: "type",
        description: 'Only used if the `valuetype` is set to "ref". Specifies the MIME type of values found at the URI specified by value.'
      }, {
        name: "valuetype",
        description: `Specifies the type of the \`value\` attribute. Possible values are:

*   data: Default value. The value is passed to the object's implementation as a string.
*   ref: The value is a URI to a resource where run-time values are stored.
*   object: An ID of another [\`<object>\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/object "The HTML <object> element represents an external resource, which can be treated as an image, a nested browsing context, or a resource to be handled by a plugin.") in the same document.`
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/param"
      }]
    }, {
      name: "video",
      description: {
        kind: "markdown",
        value: "A video element is used for playing videos or movies, and audio files with captions."
      },
      attributes: [{
        name: "src"
      }, {
        name: "crossorigin",
        valueSet: "xo"
      }, {
        name: "poster"
      }, {
        name: "preload",
        valueSet: "pl"
      }, {
        name: "autoplay",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: 'A Boolean attribute; if specified, the video automatically begins to play back as soon as it can do so without stopping to finish loading the data.\n**Note**: Sites that automatically play audio (or video with an audio track) can be an unpleasant experience for users, so it should be avoided when possible. If you must offer autoplay functionality, you should make it opt-in (requiring a user to specifically enable it). However, this can be useful when creating media elements whose source will be set at a later time, under user control.\n\nTo disable video autoplay, `autoplay="false"` will not work; the video will autoplay if the attribute is there in the `<video>` tag at all. To remove autoplay the attribute needs to be removed altogether.\n\nIn some browsers (e.g. Chrome 70.0) autoplay is not working if no `muted` attribute is present.'
        }
      }, {
        name: "mediagroup"
      }, {
        name: "loop",
        valueSet: "v"
      }, {
        name: "muted",
        valueSet: "v"
      }, {
        name: "controls",
        valueSet: "v"
      }, {
        name: "width"
      }, {
        name: "height"
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/video"
      }]
    }, {
      name: "audio",
      description: {
        kind: "markdown",
        value: "An audio element represents a sound or audio stream."
      },
      attributes: [{
        name: "src",
        description: {
          kind: "markdown",
          value: 'The URL of the audio to embed. This is subject to [HTTP access controls](https://developer.mozilla.org/en-US/docs/HTTP_access_control). This is optional; you may instead use the [`<source>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/source "The HTML <source> element specifies multiple media resources for the <picture>, the <audio> element, or the <video> element.") element within the audio block to specify the audio to embed.'
        }
      }, {
        name: "crossorigin",
        valueSet: "xo",
        description: {
          kind: "markdown",
          value: 'This enumerated attribute indicates whether to use CORS to fetch the related image. [CORS-enabled resources](https://developer.mozilla.org/en-US/docs/CORS_Enabled_Image) can be reused in the [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas "Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.") element without being _tainted_. The allowed values are:\n\nanonymous\n\nSends a cross-origin request without a credential. In other words, it sends the `Origin:` HTTP header without a cookie, X.509 certificate, or performing HTTP Basic authentication. If the server does not give credentials to the origin site (by not setting the `Access-Control-Allow-Origin:` HTTP header), the image will be _tainted_, and its usage restricted.\n\nuse-credentials\n\nSends a cross-origin request with a credential. In other words, it sends the `Origin:` HTTP header with a cookie, a certificate, or performing HTTP Basic authentication. If the server does not give credentials to the origin site (through `Access-Control-Allow-Credentials:` HTTP header), the image will be _tainted_ and its usage restricted.\n\nWhen not present, the resource is fetched without a CORS request (i.e. without sending the `Origin:` HTTP header), preventing its non-tainted used in [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas "Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.") elements. If invalid, it is handled as if the enumerated keyword **anonymous** was used. See [CORS settings attributes](https://developer.mozilla.org/en-US/docs/HTML/CORS_settings_attributes) for additional information.'
        }
      }, {
        name: "preload",
        valueSet: "pl",
        description: {
          kind: "markdown",
          value: "This enumerated attribute is intended to provide a hint to the browser about what the author thinks will lead to the best user experience. It may have one of the following values:\n\n*   `none`: Indicates that the audio should not be preloaded.\n*   `metadata`: Indicates that only audio metadata (e.g. length) is fetched.\n*   `auto`: Indicates that the whole audio file can be downloaded, even if the user is not expected to use it.\n*   _empty string_: A synonym of the `auto` value.\n\nIf not set, `preload`'s default value is browser-defined (i.e. each browser may have its own default value). The spec advises it to be set to `metadata`.\n\n**Usage notes:**\n\n*   The `autoplay` attribute has precedence over `preload`. If `autoplay` is specified, the browser would obviously need to start downloading the audio for playback.\n*   The browser is not forced by the specification to follow the value of this attribute; it is a mere hint."
        }
      }, {
        name: "autoplay",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: `A Boolean attribute: if specified, the audio will automatically begin playback as soon as it can do so, without waiting for the entire audio file to finish downloading.

**Note**: Sites that automatically play audio (or videos with an audio track) can be an unpleasant experience for users, so should be avoided when possible. If you must offer autoplay functionality, you should make it opt-in (requiring a user to specifically enable it). However, this can be useful when creating media elements whose source will be set at a later time, under user control.`
        }
      }, {
        name: "mediagroup"
      }, {
        name: "loop",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "A Boolean attribute: if specified, the audio player will automatically seek back to the start upon reaching the end of the audio."
        }
      }, {
        name: "muted",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "A Boolean attribute that indicates whether the audio will be initially silenced. Its default value is `false`."
        }
      }, {
        name: "controls",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "If this attribute is present, the browser will offer controls to allow the user to control audio playback, including volume, seeking, and pause/resume playback."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/audio"
      }]
    }, {
      name: "source",
      description: {
        kind: "markdown",
        value: "The source element allows authors to specify multiple alternative media resources for media elements. It does not represent anything on its own."
      },
      void: !0,
      attributes: [{
        name: "src",
        description: {
          kind: "markdown",
          value: 'Required for [`<audio>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/audio "The HTML <audio> element is used to embed sound content in documents. It may contain one or more audio sources, represented using the src attribute or the <source> element: the browser will choose the most suitable one. It can also be the destination for streamed media, using a MediaStream.") and [`<video>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/video "The HTML Video element (<video>) embeds a media player which supports video playback into the document."), address of the media resource. The value of this attribute is ignored when the `<source>` element is placed inside a [`<picture>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture "The HTML <picture> element contains zero or more <source> elements and one <img> element to provide versions of an image for different display/device scenarios.") element.'
        }
      }, {
        name: "type",
        description: {
          kind: "markdown",
          value: "The MIME-type of the resource, optionally with a `codecs` parameter. See [RFC 4281](https://tools.ietf.org/html/rfc4281) for information about how to specify codecs."
        }
      }, {
        name: "sizes",
        description: 'Is a list of source sizes that describes the final rendered width of the image represented by the source. Each source size consists of a comma-separated list of media condition-length pairs. This information is used by the browser to determine, before laying the page out, which image defined in [`srcset`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/source#attr-srcset) to use.  \nThe `sizes` attribute has an effect only when the [`<source>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/source "The HTML <source> element specifies multiple media resources for the <picture>, the <audio> element, or the <video> element.") element is the direct child of a [`<picture>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture "The HTML <picture> element contains zero or more <source> elements and one <img> element to provide versions of an image for different display/device scenarios.") element.'
      }, {
        name: "srcset",
        description: "A list of one or more strings separated by commas indicating a set of possible images represented by the source for the browser to use. Each string is composed of:\n\n1.  one URL to an image,\n2.  a width descriptor, that is a positive integer directly followed by `'w'`. The default value, if missing, is the infinity.\n3.  a pixel density descriptor, that is a positive floating number directly followed by `'x'`. The default value, if missing, is `1x`.\n\nEach string in the list must have at least a width descriptor or a pixel density descriptor to be valid. Among the list, there must be only one string containing the same tuple of width descriptor and pixel density descriptor.  \nThe browser chooses the most adequate image to display at a given point of time.  \nThe `srcset` attribute has an effect only when the [`<source>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/source \"The HTML <source> element specifies multiple media resources for the <picture>, the <audio> element, or the <video> element.\") element is the direct child of a [`<picture>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture \"The HTML <picture> element contains zero or more <source> elements and one <img> element to provide versions of an image for different display/device scenarios.\") element."
      }, {
        name: "media",
        description: '[Media query](https://developer.mozilla.org/en-US/docs/CSS/Media_queries) of the resource\'s intended media; this should be used only in a [`<picture>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture "The HTML <picture> element contains zero or more <source> elements and one <img> element to provide versions of an image for different display/device scenarios.") element.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/source"
      }]
    }, {
      name: "track",
      description: {
        kind: "markdown",
        value: "The track element allows authors to specify explicit external timed text tracks for media elements. It does not represent anything on its own."
      },
      void: !0,
      attributes: [{
        name: "default",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This attribute indicates that the track should be enabled unless the user's preferences indicate that another track is more appropriate. This may only be used on one `track` element per media element."
        }
      }, {
        name: "kind",
        valueSet: "tk",
        description: {
          kind: "markdown",
          value: "How the text track is meant to be used. If omitted the default kind is `subtitles`. If the attribute is not present, it will use the `subtitles`. If the attribute contains an invalid value, it will use `metadata`. (Versions of Chrome earlier than 52 treated an invalid value as `subtitles`.) The following keywords are allowed:\n\n*   `subtitles`\n    *   Subtitles provide translation of content that cannot be understood by the viewer. For example dialogue or text that is not English in an English language film.\n    *   Subtitles may contain additional content, usually extra background information. For example the text at the beginning of the Star Wars films, or the date, time, and location of a scene.\n*   `captions`\n    *   Closed captions provide a transcription and possibly a translation of audio.\n    *   It may include important non-verbal information such as music cues or sound effects. It may indicate the cue's source (e.g. music, text, character).\n    *   Suitable for users who are deaf or when the sound is muted.\n*   `descriptions`\n    *   Textual description of the video content.\n    *   Suitable for users who are blind or where the video cannot be seen.\n*   `chapters`\n    *   Chapter titles are intended to be used when the user is navigating the media resource.\n*   `metadata`\n    *   Tracks used by scripts. Not visible to the user."
        }
      }, {
        name: "label",
        description: {
          kind: "markdown",
          value: "A user-readable title of the text track which is used by the browser when listing available text tracks."
        }
      }, {
        name: "src",
        description: {
          kind: "markdown",
          value: 'Address of the track (`.vtt` file). Must be a valid URL. This attribute must be specified and its URL value must have the same origin as the document — unless the [`<audio>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/audio "The HTML <audio> element is used to embed sound content in documents. It may contain one or more audio sources, represented using the src attribute or the <source> element: the browser will choose the most suitable one. It can also be the destination for streamed media, using a MediaStream.") or [`<video>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/video "The HTML Video element (<video>) embeds a media player which supports video playback into the document.") parent element of the `track` element has a [`crossorigin`](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_settings_attributes) attribute.'
        }
      }, {
        name: "srclang",
        description: {
          kind: "markdown",
          value: "Language of the track text data. It must be a valid [BCP 47](https://r12a.github.io/app-subtags/) language tag. If the `kind` attribute is set to `subtitles,` then `srclang` must be defined."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/track"
      }]
    }, {
      name: "map",
      description: {
        kind: "markdown",
        value: "The map element, in conjunction with an img element and any area element descendants, defines an image map. The element represents its children."
      },
      attributes: [{
        name: "name",
        description: {
          kind: "markdown",
          value: "The name attribute gives the map a name so that it can be referenced. The attribute must be present and must have a non-empty value with no space characters. The value of the name attribute must not be a compatibility-caseless match for the value of the name attribute of another map element in the same document. If the id attribute is also specified, both attributes must have the same value."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/map"
      }]
    }, {
      name: "area",
      description: {
        kind: "markdown",
        value: "The area element represents either a hyperlink with some text and a corresponding area on an image map, or a dead area on an image map."
      },
      void: !0,
      attributes: [{
        name: "alt"
      }, {
        name: "coords"
      }, {
        name: "shape",
        valueSet: "sh"
      }, {
        name: "href"
      }, {
        name: "target",
        valueSet: "target"
      }, {
        name: "download"
      }, {
        name: "ping"
      }, {
        name: "rel"
      }, {
        name: "hreflang"
      }, {
        name: "type"
      }, {
        name: "accesskey",
        description: "Specifies a keyboard navigation accelerator for the element. Pressing ALT or a similar key in association with the specified character selects the form control correlated with that key sequence. Page designers are forewarned to avoid key sequences already bound to browsers. This attribute is global since HTML5."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/area"
      }]
    }, {
      name: "table",
      description: {
        kind: "markdown",
        value: "The table element represents data with more than one dimension, in the form of a table."
      },
      attributes: [{
        name: "border"
      }, {
        name: "align",
        description: 'This enumerated attribute indicates how the table must be aligned inside the containing document. It may have the following values:\n\n*   left: the table is displayed on the left side of the document;\n*   center: the table is displayed in the center of the document;\n*   right: the table is displayed on the right side of the document.\n\n**Usage Note**\n\n*   **Do not use this attribute**, as it has been deprecated. The [`<table>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/table "The HTML <table> element represents tabular data — that is, information presented in a two-dimensional table comprised of rows and columns of cells containing data.") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/CSS). Set [`margin-left`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-left "The margin-left CSS property sets the margin area on the left side of an element. A positive value places it farther from its neighbors, while a negative value places it closer.") and [`margin-right`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-right "The margin-right CSS property sets the margin area on the right side of an element. A positive value places it farther from its neighbors, while a negative value places it closer.") to `auto` or [`margin`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin "The margin CSS property sets the margin area on all four sides of an element. It is a shorthand for margin-top, margin-right, margin-bottom, and margin-left.") to `0 auto` to achieve an effect that is similar to the align attribute.\n*   Prior to Firefox 4, Firefox also supported the `middle`, `absmiddle`, and `abscenter` values as synonyms of `center`, in quirks mode only.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/table"
      }]
    }, {
      name: "caption",
      description: {
        kind: "markdown",
        value: "The caption element represents the title of the table that is its parent, if it has a parent and that is a table element."
      },
      attributes: [{
        name: "align",
        description: `This enumerated attribute indicates how the caption must be aligned with respect to the table. It may have one of the following values:

\`left\`

The caption is displayed to the left of the table.

\`top\`

The caption is displayed above the table.

\`right\`

The caption is displayed to the right of the table.

\`bottom\`

The caption is displayed below the table.

**Usage note:** Do not use this attribute, as it has been deprecated. The [\`<caption>\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/caption "The HTML Table Caption element (<caption>) specifies the caption (or title) of a table, and if used is always the first child of a <table>.") element should be styled using the [CSS](https://developer.mozilla.org/en-US/docs/CSS) properties [\`caption-side\`](https://developer.mozilla.org/en-US/docs/Web/CSS/caption-side "The caption-side CSS property puts the content of a table's <caption> on the specified side. The values are relative to the writing-mode of the table.") and [\`text-align\`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.").`
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/caption"
      }]
    }, {
      name: "colgroup",
      description: {
        kind: "markdown",
        value: "The colgroup element represents a group of one or more columns in the table that is its parent, if it has a parent and that is a table element."
      },
      attributes: [{
        name: "span"
      }, {
        name: "align",
        description: 'This enumerated attribute specifies how horizontal alignment of each column cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-charoff) attributes Unimplemented (see [bug 2212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 "character alignment not implemented (align=char, charoff=, text-align:<string>)")).\n\nIf this attribute is not set, the `left` value is assumed. The descendant [`<col>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col "The HTML <col> element defines a column within a table and is used for defining common semantics on all common cells. It is generally found within a <colgroup> element.") elements may override this value using their own [`align`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-align) attribute.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values:\n    *   Do not try to set the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property on a selector giving a [`<colgroup>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup "The HTML <colgroup> element defines a group of columns within a table.") element. Because [`<td>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td "The HTML <td> element defines a cell of a table that contains data. It participates in the table model.") elements are not descendant of the [`<colgroup>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup "The HTML <colgroup> element defines a group of columns within a table.") element, they won\'t inherit it.\n    *   If the table doesn\'t use a [`colspan`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-colspan) attribute, use one `td:nth-child(an+b)` CSS selector per column, where a is the total number of the columns in the table and b is the ordinal position of this column in the table. Only after this selector the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property can be used.\n    *   If the table does use a [`colspan`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-colspan) attribute, the effect can be achieved by combining adequate CSS attribute selectors like `[colspan=n]`, though this is not trivial.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property Unimplemented.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/colgroup"
      }]
    }, {
      name: "col",
      description: {
        kind: "markdown",
        value: "If a col element has a parent and that is a colgroup element that itself has a parent that is a table element, then the col element represents one or more columns in the column group represented by that colgroup."
      },
      void: !0,
      attributes: [{
        name: "span"
      }, {
        name: "align",
        description: 'This enumerated attribute specifies how horizontal alignment of each column cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-charoff) attributes Unimplemented (see [bug 2212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 "character alignment not implemented (align=char, charoff=, text-align:<string>)")).\n\nIf this attribute is not set, its value is inherited from the [`align`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup#attr-align) of the [`<colgroup>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup "The HTML <colgroup> element defines a group of columns within a table.") element this `<col>` element belongs too. If there are none, the `left` value is assumed.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values:\n    *   Do not try to set the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property on a selector giving a [`<col>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col "The HTML <col> element defines a column within a table and is used for defining common semantics on all common cells. It is generally found within a <colgroup> element.") element. Because [`<td>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td "The HTML <td> element defines a cell of a table that contains data. It participates in the table model.") elements are not descendant of the [`<col>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col "The HTML <col> element defines a column within a table and is used for defining common semantics on all common cells. It is generally found within a <colgroup> element.") element, they won\'t inherit it.\n    *   If the table doesn\'t use a [`colspan`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-colspan) attribute, use the `td:nth-child(an+b)` CSS selector. Set `a` to zero and `b` to the position of the column in the table, e.g. `td:nth-child(2) { text-align: right; }` to right-align the second column.\n    *   If the table does use a [`colspan`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-colspan) attribute, the effect can be achieved by combining adequate CSS attribute selectors like `[colspan=n]`, though this is not trivial.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property Unimplemented.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/col"
      }]
    }, {
      name: "tbody",
      description: {
        kind: "markdown",
        value: "The tbody element represents a block of rows that consist of a body of data for the parent table element, if the tbody element has a parent and it is a table."
      },
      attributes: [{
        name: "align",
        description: 'This enumerated attribute specifies how horizontal alignment of each cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-charoff) attributes.\n\nIf this attribute is not set, the `left` value is assumed.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, use the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property on it.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property Unimplemented.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/tbody"
      }]
    }, {
      name: "thead",
      description: {
        kind: "markdown",
        value: "The thead element represents the block of rows that consist of the column labels (headers) for the parent table element, if the thead element has a parent and it is a table."
      },
      attributes: [{
        name: "align",
        description: 'This enumerated attribute specifies how horizontal alignment of each cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/thead#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/thead#attr-charoff) attributes Unimplemented (see [bug 2212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 "character alignment not implemented (align=char, charoff=, text-align:<string>)")).\n\nIf this attribute is not set, the `left` value is assumed.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, use the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property on it.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/thead#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property Unimplemented.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/thead"
      }]
    }, {
      name: "tfoot",
      description: {
        kind: "markdown",
        value: "The tfoot element represents the block of rows that consist of the column summaries (footers) for the parent table element, if the tfoot element has a parent and it is a table."
      },
      attributes: [{
        name: "align",
        description: 'This enumerated attribute specifies how horizontal alignment of each cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-charoff) attributes Unimplemented (see [bug 2212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 "character alignment not implemented (align=char, charoff=, text-align:<string>)")).\n\nIf this attribute is not set, the `left` value is assumed.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, use the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property on it.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tfoot#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property Unimplemented.'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/tfoot"
      }]
    }, {
      name: "tr",
      description: {
        kind: "markdown",
        value: "The tr element represents a row of cells in a table."
      },
      attributes: [{
        name: "align",
        description: 'A [`DOMString`](https://developer.mozilla.org/en-US/docs/Web/API/DOMString "DOMString is a UTF-16 String. As JavaScript already uses such strings, DOMString is mapped directly to a String.") which specifies how the cell\'s context should be aligned horizontally within the cells in the row; this is shorthand for using `align` on every cell in the row individually. Possible values are:\n\n`left`\n\nAlign the content of each cell at its left edge.\n\n`center`\n\nCenter the contents of each cell between their left and right edges.\n\n`right`\n\nAlign the content of each cell at its right edge.\n\n`justify`\n\nWiden whitespaces within the text of each cell so that the text fills the full width of each cell (full justification).\n\n`char`\n\nAlign each cell in the row on a specific character (such that each row in the column that is configured this way will horizontally align its cells on that character). This uses the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tr#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tr#attr-charoff) to establish the alignment character (typically "." or "," when aligning numerical data) and the number of characters that should follow the alignment character. This alignment type was never widely supported.\n\nIf no value is expressly set for `align`, the parent node\'s value is inherited.\n\nInstead of using the obsolete `align` attribute, you should instead use the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property to establish `left`, `center`, `right`, or `justify` alignment for the row\'s cells. To apply character-based alignment, set the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property to the alignment character (such as `"."` or `","`).'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/tr"
      }]
    }, {
      name: "td",
      description: {
        kind: "markdown",
        value: "The td element represents a data cell in a table."
      },
      attributes: [{
        name: "colspan"
      }, {
        name: "rowspan"
      }, {
        name: "headers"
      }, {
        name: "abbr",
        description: `This attribute contains a short abbreviated description of the cell's content. Some user-agents, such as speech readers, may present this description before the content itself.

**Note:** Do not use this attribute as it is obsolete in the latest standard. Alternatively, you can put the abbreviated description inside the cell and place the long content in the **title** attribute.`
      }, {
        name: "align",
        description: 'This enumerated attribute specifies how the cell content\'s horizontal alignment will be handled. Possible values are:\n\n*   `left`: The content is aligned to the left of the cell.\n*   `center`: The content is centered in the cell.\n*   `right`: The content is aligned to the right of the cell.\n*   `justify` (with text only): The content is stretched out inside the cell so that it covers its entire width.\n*   `char` (with text only): The content is aligned to a character inside the `<th>` element with minimal offset. This character is defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-charoff) attributes Unimplemented (see [bug 2212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 "character alignment not implemented (align=char, charoff=, text-align:<string>)")).\n\nThe default value when this attribute is not specified is `left`.\n\n**Note:** Do not use this attribute as it is obsolete in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, apply the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property to the element.\n*   To achieve the same effect as the `char` value, give the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property the same value you would use for the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-char). Unimplemented in CSS3.'
      }, {
        name: "axis",
        description: "This attribute contains a list of space-separated strings. Each string is the `id` of a group of cells that this header applies to.\n\n**Note:** Do not use this attribute as it is obsolete in the latest standard."
      }, {
        name: "bgcolor",
        description: `This attribute defines the background color of each cell in a column. It consists of a 6-digit hexadecimal code as defined in [sRGB](https://www.w3.org/Graphics/Color/sRGB) and is prefixed by '#'. This attribute may be used with one of sixteen predefined color strings:

 

\`black\` = "#000000"

 

\`green\` = "#008000"

 

\`silver\` = "#C0C0C0"

 

\`lime\` = "#00FF00"

 

\`gray\` = "#808080"

 

\`olive\` = "#808000"

 

\`white\` = "#FFFFFF"

 

\`yellow\` = "#FFFF00"

 

\`maroon\` = "#800000"

 

\`navy\` = "#000080"

 

\`red\` = "#FF0000"

 

\`blue\` = "#0000FF"

 

\`purple\` = "#800080"

 

\`teal\` = "#008080"

 

\`fuchsia\` = "#FF00FF"

 

\`aqua\` = "#00FFFF"

**Note:** Do not use this attribute, as it is non-standard and only implemented in some versions of Microsoft Internet Explorer: The [\`<td>\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td "The HTML <td> element defines a cell of a table that contains data. It participates in the table model.") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/CSS). To create a similar effect use the [\`background-color\`](https://developer.mozilla.org/en-US/docs/Web/CSS/background-color "The background-color CSS property sets the background color of an element.") property in [CSS](https://developer.mozilla.org/en-US/docs/CSS) instead.`
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/td"
      }]
    }, {
      name: "th",
      description: {
        kind: "markdown",
        value: "The th element represents a header cell in a table."
      },
      attributes: [{
        name: "colspan"
      }, {
        name: "rowspan"
      }, {
        name: "headers"
      }, {
        name: "scope",
        valueSet: "s"
      }, {
        name: "sorted"
      }, {
        name: "abbr",
        description: {
          kind: "markdown",
          value: "This attribute contains a short abbreviated description of the cell's content. Some user-agents, such as speech readers, may present this description before the content itself."
        }
      }, {
        name: "align",
        description: 'This enumerated attribute specifies how the cell content\'s horizontal alignment will be handled. Possible values are:\n\n*   `left`: The content is aligned to the left of the cell.\n*   `center`: The content is centered in the cell.\n*   `right`: The content is aligned to the right of the cell.\n*   `justify` (with text only): The content is stretched out inside the cell so that it covers its entire width.\n*   `char` (with text only): The content is aligned to a character inside the `<th>` element with minimal offset. This character is defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th#attr-charoff) attributes.\n\nThe default value when this attribute is not specified is `left`.\n\n**Note:** Do not use this attribute as it is obsolete in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, apply the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property to the element.\n*   To achieve the same effect as the `char` value, give the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align "The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.") property the same value you would use for the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th#attr-char). Unimplemented in CSS3.'
      }, {
        name: "axis",
        description: "This attribute contains a list of space-separated strings. Each string is the `id` of a group of cells that this header applies to.\n\n**Note:** Do not use this attribute as it is obsolete in the latest standard: use the [`scope`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th#attr-scope) attribute instead."
      }, {
        name: "bgcolor",
        description: `This attribute defines the background color of each cell in a column. It consists of a 6-digit hexadecimal code as defined in [sRGB](https://www.w3.org/Graphics/Color/sRGB) and is prefixed by '#'. This attribute may be used with one of sixteen predefined color strings:

 

\`black\` = "#000000"

 

\`green\` = "#008000"

 

\`silver\` = "#C0C0C0"

 

\`lime\` = "#00FF00"

 

\`gray\` = "#808080"

 

\`olive\` = "#808000"

 

\`white\` = "#FFFFFF"

 

\`yellow\` = "#FFFF00"

 

\`maroon\` = "#800000"

 

\`navy\` = "#000080"

 

\`red\` = "#FF0000"

 

\`blue\` = "#0000FF"

 

\`purple\` = "#800080"

 

\`teal\` = "#008080"

 

\`fuchsia\` = "#FF00FF"

 

\`aqua\` = "#00FFFF"

**Note:** Do not use this attribute, as it is non-standard and only implemented in some versions of Microsoft Internet Explorer: The [\`<th>\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th "The HTML <th> element defines a cell as header of a group of table cells. The exact nature of this group is defined by the scope and headers attributes.") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/Web/CSS). To create a similar effect use the [\`background-color\`](https://developer.mozilla.org/en-US/docs/Web/CSS/background-color "The background-color CSS property sets the background color of an element.") property in [CSS](https://developer.mozilla.org/en-US/docs/Web/CSS) instead.`
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/th"
      }]
    }, {
      name: "form",
      description: {
        kind: "markdown",
        value: "The form element represents a collection of form-associated elements, some of which can represent editable values that can be submitted to a server for processing."
      },
      attributes: [{
        name: "accept-charset",
        description: {
          kind: "markdown",
          value: 'A space- or comma-delimited list of character encodings that the server accepts. The browser uses them in the order in which they are listed. The default value, the reserved string `"UNKNOWN"`, indicates the same encoding as that of the document containing the form element.  \nIn previous versions of HTML, the different character encodings could be delimited by spaces or commas. In HTML5, only spaces are allowed as delimiters.'
        }
      }, {
        name: "action",
        description: {
          kind: "markdown",
          value: 'The URI of a program that processes the form information. This value can be overridden by a [`formaction`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formaction) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") element.'
        }
      }, {
        name: "autocomplete",
        valueSet: "o",
        description: {
          kind: "markdown",
          value: "Indicates whether input elements can by default have their values automatically completed by the browser. This setting can be overridden by an `autocomplete` attribute on an element belonging to the form. Possible values are:\n\n*   `off`: The user must explicitly enter a value into each field for every use, or the document provides its own auto-completion method; the browser does not automatically complete entries.\n*   `on`: The browser can automatically complete values based on values that the user has previously entered in the form.\n\nFor most modern browsers (including Firefox 38+, Google Chrome 34+, IE 11+) setting the autocomplete attribute will not prevent a browser's password manager from asking the user if they want to store login fields (username and password), if the user permits the storage the browser will autofill the login the next time the user visits the page. See [The autocomplete attribute and login fields](https://developer.mozilla.org/en-US/docs/Web/Security/Securing_your_site/Turning_off_form_autocompletion#The_autocomplete_attribute_and_login_fields).\n**Note:** If you set `autocomplete` to `off` in a form because the document provides its own auto-completion, then you should also set `autocomplete` to `off` for each of the form's `input` elements that the document can auto-complete. For details, see the note regarding Google Chrome in the [Browser Compatibility chart](#compatChart)."
        }
      }, {
        name: "enctype",
        valueSet: "et",
        description: {
          kind: "markdown",
          value: 'When the value of the `method` attribute is `post`, enctype is the [MIME type](https://en.wikipedia.org/wiki/Mime_type) of content that is used to submit the form to the server. Possible values are:\n\n*   `application/x-www-form-urlencoded`: The default value if the attribute is not specified.\n*   `multipart/form-data`: The value used for an [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") element with the `type` attribute set to "file".\n*   `text/plain`: (HTML5)\n\nThis value can be overridden by a [`formenctype`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formenctype) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") element.'
        }
      }, {
        name: "method",
        valueSet: "m",
        description: {
          kind: "markdown",
          value: 'The [HTTP](https://developer.mozilla.org/en-US/docs/Web/HTTP) method that the browser uses to submit the form. Possible values are:\n\n*   `post`: Corresponds to the HTTP [POST method](https://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html#sec9.5) ; form data are included in the body of the form and sent to the server.\n*   `get`: Corresponds to the HTTP [GET method](https://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html#sec9.3); form data are appended to the `action` attribute URI with a \'?\' as separator, and the resulting URI is sent to the server. Use this method when the form has no side-effects and contains only ASCII characters.\n*   `dialog`: Use when the form is inside a [`<dialog>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog "The HTML <dialog> element represents a dialog box or other interactive component, such as an inspector or window.") element to close the dialog when submitted.\n\nThis value can be overridden by a [`formmethod`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formmethod) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") element.'
        }
      }, {
        name: "name",
        description: {
          kind: "markdown",
          value: "The name of the form. In HTML 4, its use is deprecated (`id` should be used instead). It must be unique among the forms in a document and not just an empty string in HTML 5."
        }
      }, {
        name: "novalidate",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: 'This Boolean attribute indicates that the form is not to be validated when submitted. If this attribute is not specified (and therefore the form is validated), this default setting can be overridden by a [`formnovalidate`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formnovalidate) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") element belonging to the form.'
        }
      }, {
        name: "target",
        valueSet: "target",
        description: {
          kind: "markdown",
          value: 'A name or keyword indicating where to display the response that is received after submitting the form. In HTML 4, this is the name/keyword for a frame. In HTML5, it is a name/keyword for a _browsing context_ (for example, tab, window, or inline frame). The following keywords have special meanings:\n\n*   `_self`: Load the response into the same HTML 4 frame (or HTML5 browsing context) as the current one. This value is the default if the attribute is not specified.\n*   `_blank`: Load the response into a new unnamed HTML 4 window or HTML5 browsing context.\n*   `_parent`: Load the response into the HTML 4 frameset parent of the current frame, or HTML5 parent browsing context of the current one. If there is no parent, this option behaves the same way as `_self`.\n*   `_top`: HTML 4: Load the response into the full original window, and cancel all other frames. HTML5: Load the response into the top-level browsing context (i.e., the browsing context that is an ancestor of the current one, and has no parent). If there is no parent, this option behaves the same way as `_self`.\n*   _iframename_: The response is displayed in a named [`<iframe>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/iframe "The HTML Inline Frame element (<iframe>) represents a nested browsing context, embedding another HTML page into the current one.").\n\nHTML5: This value can be overridden by a [`formtarget`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formtarget) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") element.'
        }
      }, {
        name: "accept",
        description: 'A comma-separated list of content types that the server accepts.\n\n**Usage note:** This attribute has been removed in HTML5 and should no longer be used. Instead, use the [`accept`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-accept) attribute of the specific [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") element.'
      }, {
        name: "autocapitalize",
        description: "This is a nonstandard attribute used by iOS Safari Mobile which controls whether and how the text value for textual form control descendants should be automatically capitalized as it is entered/edited by the user. If the `autocapitalize` attribute is specified on an individual form control descendant, it trumps the form-wide `autocapitalize` setting. The non-deprecated values are available in iOS 5 and later. The default value is `sentences`. Possible values are:\n\n*   `none`: Completely disables automatic capitalization\n*   `sentences`: Automatically capitalize the first letter of sentences.\n*   `words`: Automatically capitalize the first letter of words.\n*   `characters`: Automatically capitalize all characters.\n*   `on`: Deprecated since iOS 5.\n*   `off`: Deprecated since iOS 5."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/form"
      }]
    }, {
      name: "label",
      description: {
        kind: "markdown",
        value: "The label element represents a caption in a user interface. The caption can be associated with a specific form control, known as the label element's labeled control, either using the for attribute, or by putting the form control inside the label element itself."
      },
      attributes: [{
        name: "form",
        description: {
          kind: "markdown",
          value: 'The [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.") element with which the label is associated (its _form owner_). If specified, the value of the attribute is the `id` of a [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.") element in the same document. This lets you place label elements anywhere within a document, not just as descendants of their form elements.'
        }
      }, {
        name: "for",
        description: {
          kind: "markdown",
          value: "The [`id`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes#attr-id) of a [labelable](https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Form_labelable) form-related element in the same document as the `<label>` element. The first element in the document with an `id` matching the value of the `for` attribute is the _labeled control_ for this label element, if it is a labelable element. If it is not labelable then the `for` attribute has no effect. If there are other elements which also match the `id` value, later in the document, they are not considered.\n\n**Note**: A `<label>` element can have both a `for` attribute and a contained control element, as long as the `for` attribute points to the contained control element."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/label"
      }]
    }, {
      name: "input",
      description: {
        kind: "markdown",
        value: "The input element represents a typed data field, usually with a form control to allow the user to edit the data."
      },
      void: !0,
      attributes: [{
        name: "accept"
      }, {
        name: "alt"
      }, {
        name: "autocomplete",
        valueSet: "inputautocomplete"
      }, {
        name: "autofocus",
        valueSet: "v"
      }, {
        name: "checked",
        valueSet: "v"
      }, {
        name: "dirname"
      }, {
        name: "disabled",
        valueSet: "v"
      }, {
        name: "form"
      }, {
        name: "formaction"
      }, {
        name: "formenctype",
        valueSet: "et"
      }, {
        name: "formmethod",
        valueSet: "fm"
      }, {
        name: "formnovalidate",
        valueSet: "v"
      }, {
        name: "formtarget"
      }, {
        name: "height"
      }, {
        name: "inputmode",
        valueSet: "im"
      }, {
        name: "list"
      }, {
        name: "max"
      }, {
        name: "maxlength"
      }, {
        name: "min"
      }, {
        name: "minlength"
      }, {
        name: "multiple",
        valueSet: "v"
      }, {
        name: "name"
      }, {
        name: "pattern"
      }, {
        name: "placeholder"
      }, {
        name: "readonly",
        valueSet: "v"
      }, {
        name: "required",
        valueSet: "v"
      }, {
        name: "size"
      }, {
        name: "src"
      }, {
        name: "step"
      }, {
        name: "type",
        valueSet: "t"
      }, {
        name: "value"
      }, {
        name: "width"
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/input"
      }]
    }, {
      name: "button",
      description: {
        kind: "markdown",
        value: "The button element represents a button labeled by its contents."
      },
      attributes: [{
        name: "autofocus",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This Boolean attribute lets you specify that the button should have input focus when the page loads, unless the user overrides it, for example by typing in a different control. Only one form-associated element in a document can have this attribute specified."
        }
      }, {
        name: "disabled",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: 'This Boolean attribute indicates that the user cannot interact with the button. If this attribute is not specified, the button inherits its setting from the containing element, for example [`<fieldset>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/fieldset "The HTML <fieldset> element is used to group several controls as well as labels (<label>) within a web form."); if there is no containing element with the **disabled** attribute set, then the button is enabled.\n\nFirefox will, unlike other browsers, by default, [persist the dynamic disabled state](https://stackoverflow.com/questions/5985839/bug-with-firefox-disabled-attribute-of-input-not-resetting-when-refreshing) of a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") across page loads. Use the [`autocomplete`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-autocomplete) attribute to control this feature.'
        }
      }, {
        name: "form",
        description: {
          kind: "markdown",
          value: 'The form element that the button is associated with (its _form owner_). The value of the attribute must be the **id** attribute of a [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.") element in the same document. If this attribute is not specified, the `<button>` element will be associated to an ancestor [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.") element, if one exists. This attribute enables you to associate `<button>` elements to [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.") elements anywhere within a document, not just as descendants of [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.") elements.'
        }
      }, {
        name: "formaction",
        description: {
          kind: "markdown",
          value: "The URI of a program that processes the information submitted by the button. If specified, it overrides the [`action`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-action) attribute of the button's form owner."
        }
      }, {
        name: "formenctype",
        valueSet: "et",
        description: {
          kind: "markdown",
          value: 'If the button is a submit button, this attribute specifies the type of content that is used to submit the form to the server. Possible values are:\n\n*   `application/x-www-form-urlencoded`: The default value if the attribute is not specified.\n*   `multipart/form-data`: Use this value if you are using an [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") element with the [`type`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-type) attribute set to `file`.\n*   `text/plain`\n\nIf this attribute is specified, it overrides the [`enctype`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-enctype) attribute of the button\'s form owner.'
        }
      }, {
        name: "formmethod",
        valueSet: "fm",
        description: {
          kind: "markdown",
          value: "If the button is a submit button, this attribute specifies the HTTP method that the browser uses to submit the form. Possible values are:\n\n*   `post`: The data from the form are included in the body of the form and sent to the server.\n*   `get`: The data from the form are appended to the **form** attribute URI, with a '?' as a separator, and the resulting URI is sent to the server. Use this method when the form has no side-effects and contains only ASCII characters.\n\nIf specified, this attribute overrides the [`method`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-method) attribute of the button's form owner."
        }
      }, {
        name: "formnovalidate",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "If the button is a submit button, this Boolean attribute specifies that the form is not to be validated when it is submitted. If this attribute is specified, it overrides the [`novalidate`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-novalidate) attribute of the button's form owner."
        }
      }, {
        name: "formtarget",
        description: {
          kind: "markdown",
          value: "If the button is a submit button, this attribute is a name or keyword indicating where to display the response that is received after submitting the form. This is a name of, or keyword for, a _browsing context_ (for example, tab, window, or inline frame). If this attribute is specified, it overrides the [`target`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-target) attribute of the button's form owner. The following keywords have special meanings:\n\n*   `_self`: Load the response into the same browsing context as the current one. This value is the default if the attribute is not specified.\n*   `_blank`: Load the response into a new unnamed browsing context.\n*   `_parent`: Load the response into the parent browsing context of the current one. If there is no parent, this option behaves the same way as `_self`.\n*   `_top`: Load the response into the top-level browsing context (that is, the browsing context that is an ancestor of the current one, and has no parent). If there is no parent, this option behaves the same way as `_self`."
        }
      }, {
        name: "name",
        description: {
          kind: "markdown",
          value: "The name of the button, which is submitted with the form data."
        }
      }, {
        name: "type",
        valueSet: "bt",
        description: {
          kind: "markdown",
          value: "The type of the button. Possible values are:\n\n*   `submit`: The button submits the form data to the server. This is the default if the attribute is not specified, or if the attribute is dynamically changed to an empty or invalid value.\n*   `reset`: The button resets all the controls to their initial values.\n*   `button`: The button has no default behavior. It can have client-side scripts associated with the element's events, which are triggered when the events occur."
        }
      }, {
        name: "value",
        description: {
          kind: "markdown",
          value: "The initial value of the button. It defines the value associated with the button which is submitted with the form data. This value is passed to the server in params when the form is submitted."
        }
      }, {
        name: "autocomplete",
        description: 'The use of this attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") is nonstandard and Firefox-specific. By default, unlike other browsers, [Firefox persists the dynamic disabled state](https://stackoverflow.com/questions/5985839/bug-with-firefox-disabled-attribute-of-input-not-resetting-when-refreshing) of a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button "The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.") across page loads. Setting the value of this attribute to `off` (i.e. `autocomplete="off"`) disables this feature. See [bug 654072](https://bugzilla.mozilla.org/show_bug.cgi?id=654072 "if disabled state is changed with javascript, the normal state doesn\'t return after refreshing the page").'
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/button"
      }]
    }, {
      name: "select",
      description: {
        kind: "markdown",
        value: "The select element represents a control for selecting amongst a set of options."
      },
      attributes: [{
        name: "autocomplete",
        valueSet: "inputautocomplete",
        description: {
          kind: "markdown",
          value: 'A [`DOMString`](https://developer.mozilla.org/en-US/docs/Web/API/DOMString "DOMString is a UTF-16 String. As JavaScript already uses such strings, DOMString is mapped directly to a String.") providing a hint for a [user agent\'s](https://developer.mozilla.org/en-US/docs/Glossary/user_agent "user agent\'s: A user agent is a computer program representing a person, for example, a browser in a Web context.") autocomplete feature. See [The HTML autocomplete attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes/autocomplete) for a complete list of values and details on how to use autocomplete.'
        }
      }, {
        name: "autofocus",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This Boolean attribute lets you specify that a form control should have input focus when the page loads. Only one form element in a document can have the `autofocus` attribute."
        }
      }, {
        name: "disabled",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This Boolean attribute indicates that the user cannot interact with the control. If this attribute is not specified, the control inherits its setting from the containing element, for example `fieldset`; if there is no containing element with the `disabled` attribute set, then the control is enabled."
        }
      }, {
        name: "form",
        description: {
          kind: "markdown",
          value: 'This attribute lets you specify the form element to which the select element is associated (that is, its "form owner"). If this attribute is specified, its value must be the same as the `id` of a form element in the same document. This enables you to place select elements anywhere within a document, not just as descendants of their form elements.'
        }
      }, {
        name: "multiple",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This Boolean attribute indicates that multiple options can be selected in the list. If it is not specified, then only one option can be selected at a time. When `multiple` is specified, most browsers will show a scrolling list box instead of a single line dropdown."
        }
      }, {
        name: "name",
        description: {
          kind: "markdown",
          value: "This attribute is used to specify the name of the control."
        }
      }, {
        name: "required",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "A Boolean attribute indicating that an option with a non-empty string value must be selected."
        }
      }, {
        name: "size",
        description: {
          kind: "markdown",
          value: "If the control is presented as a scrolling list box (e.g. when `multiple` is specified), this attribute represents the number of rows in the list that should be visible at one time. Browsers are not required to present a select element as a scrolled list box. The default value is 0.\n\n**Note:** According to the HTML5 specification, the default value for size should be 1; however, in practice, this has been found to break some web sites, and no other browser currently does that, so Mozilla has opted to continue to return 0 for the time being with Firefox."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/select"
      }]
    }, {
      name: "datalist",
      description: {
        kind: "markdown",
        value: "The datalist element represents a set of option elements that represent predefined options for other controls. In the rendering, the datalist element represents nothing and it, along with its children, should be hidden."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/datalist"
      }]
    }, {
      name: "optgroup",
      description: {
        kind: "markdown",
        value: "The optgroup element represents a group of option elements with a common label."
      },
      attributes: [{
        name: "disabled",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "If this Boolean attribute is set, none of the items in this option group is selectable. Often browsers grey out such control and it won't receive any browsing events, like mouse clicks or focus-related ones."
        }
      }, {
        name: "label",
        description: {
          kind: "markdown",
          value: "The name of the group of options, which the browser can use when labeling the options in the user interface. This attribute is mandatory if this element is used."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/optgroup"
      }]
    }, {
      name: "option",
      description: {
        kind: "markdown",
        value: "The option element represents an option in a select element or as part of a list of suggestions in a datalist element."
      },
      attributes: [{
        name: "disabled",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: 'If this Boolean attribute is set, this option is not checkable. Often browsers grey out such control and it won\'t receive any browsing event, like mouse clicks or focus-related ones. If this attribute is not set, the element can still be disabled if one of its ancestors is a disabled [`<optgroup>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/optgroup "The HTML <optgroup> element creates a grouping of options within a <select> element.") element.'
        }
      }, {
        name: "label",
        description: {
          kind: "markdown",
          value: "This attribute is text for the label indicating the meaning of the option. If the `label` attribute isn't defined, its value is that of the element text content."
        }
      }, {
        name: "selected",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: 'If present, this Boolean attribute indicates that the option is initially selected. If the `<option>` element is the descendant of a [`<select>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/select "The HTML <select> element represents a control that provides a menu of options") element whose [`multiple`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/select#attr-multiple) attribute is not set, only one single `<option>` of this [`<select>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/select "The HTML <select> element represents a control that provides a menu of options") element may have the `selected` attribute.'
        }
      }, {
        name: "value",
        description: {
          kind: "markdown",
          value: "The content of this attribute represents the value to be submitted with the form, should this option be selected. If this attribute is omitted, the value is taken from the text content of the option element."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/option"
      }]
    }, {
      name: "textarea",
      description: {
        kind: "markdown",
        value: "The textarea element represents a multiline plain text edit control for the element's raw value. The contents of the control represent the control's default value."
      },
      attributes: [{
        name: "autocomplete",
        valueSet: "inputautocomplete",
        description: {
          kind: "markdown",
          value: 'This attribute indicates whether the value of the control can be automatically completed by the browser. Possible values are:\n\n*   `off`: The user must explicitly enter a value into this field for every use, or the document provides its own auto-completion method; the browser does not automatically complete the entry.\n*   `on`: The browser can automatically complete the value based on values that the user has entered during previous uses.\n\nIf the `autocomplete` attribute is not specified on a `<textarea>` element, then the browser uses the `autocomplete` attribute value of the `<textarea>` element\'s form owner. The form owner is either the [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.") element that this `<textarea>` element is a descendant of or the form element whose `id` is specified by the `form` attribute of the input element. For more information, see the [`autocomplete`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-autocomplete) attribute in [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.").'
        }
      }, {
        name: "autofocus",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This Boolean attribute lets you specify that a form control should have input focus when the page loads. Only one form-associated element in a document can have this attribute specified."
        }
      }, {
        name: "cols",
        description: {
          kind: "markdown",
          value: "The visible width of the text control, in average character widths. If it is specified, it must be a positive integer. If it is not specified, the default value is `20`."
        }
      }, {
        name: "dirname"
      }, {
        name: "disabled",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: 'This Boolean attribute indicates that the user cannot interact with the control. If this attribute is not specified, the control inherits its setting from the containing element, for example [`<fieldset>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/fieldset "The HTML <fieldset> element is used to group several controls as well as labels (<label>) within a web form."); if there is no containing element when the `disabled` attribute is set, the control is enabled.'
        }
      }, {
        name: "form",
        description: {
          kind: "markdown",
          value: 'The form element that the `<textarea>` element is associated with (its "form owner"). The value of the attribute must be the `id` of a form element in the same document. If this attribute is not specified, the `<textarea>` element must be a descendant of a form element. This attribute enables you to place `<textarea>` elements anywhere within a document, not just as descendants of form elements.'
        }
      }, {
        name: "inputmode",
        valueSet: "im"
      }, {
        name: "maxlength",
        description: {
          kind: "markdown",
          value: "The maximum number of characters (unicode code points) that the user can enter. If this value isn't specified, the user can enter an unlimited number of characters."
        }
      }, {
        name: "minlength",
        description: {
          kind: "markdown",
          value: "The minimum number of characters (unicode code points) required that the user should enter."
        }
      }, {
        name: "name",
        description: {
          kind: "markdown",
          value: "The name of the control."
        }
      }, {
        name: "placeholder",
        description: {
          kind: "markdown",
          value: 'A hint to the user of what can be entered in the control. Carriage returns or line-feeds within the placeholder text must be treated as line breaks when rendering the hint.\n\n**Note:** Placeholders should only be used to show an example of the type of data that should be entered into a form; they are _not_ a substitute for a proper [`<label>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/label "The HTML <label> element represents a caption for an item in a user interface.") element tied to the input. See [Labels and placeholders](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Labels_and_placeholders "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") in [<input>: The Input (Form Input) element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") for a full explanation.'
        }
      }, {
        name: "readonly",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This Boolean attribute indicates that the user cannot modify the value of the control. Unlike the `disabled` attribute, the `readonly` attribute does not prevent the user from clicking or selecting in the control. The value of a read-only control is still submitted with the form."
        }
      }, {
        name: "required",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This attribute specifies that the user must fill in a value before submitting a form."
        }
      }, {
        name: "rows",
        description: {
          kind: "markdown",
          value: "The number of visible text lines for the control."
        }
      }, {
        name: "wrap",
        valueSet: "w",
        description: {
          kind: "markdown",
          value: "Indicates how the control wraps text. Possible values are:\n\n*   `hard`: The browser automatically inserts line breaks (CR+LF) so that each line has no more than the width of the control; the `cols` attribute must also be specified for this to take effect.\n*   `soft`: The browser ensures that all line breaks in the value consist of a CR+LF pair, but does not insert any additional line breaks.\n*   `off` : Like `soft` but changes appearance to `white-space: pre` so line segments exceeding `cols` are not wrapped and the `<textarea>` becomes horizontally scrollable.\n\nIf this attribute is not specified, `soft` is its default value."
        }
      }, {
        name: "autocapitalize",
        description: "This is a non-standard attribute supported by WebKit on iOS (therefore nearly all browsers running on iOS, including Safari, Firefox, and Chrome), which controls whether and how the text value should be automatically capitalized as it is entered/edited by the user. The non-deprecated values are available in iOS 5 and later. Possible values are:\n\n*   `none`: Completely disables automatic capitalization.\n*   `sentences`: Automatically capitalize the first letter of sentences.\n*   `words`: Automatically capitalize the first letter of words.\n*   `characters`: Automatically capitalize all characters.\n*   `on`: Deprecated since iOS 5.\n*   `off`: Deprecated since iOS 5."
      }, {
        name: "spellcheck",
        description: "Specifies whether the `<textarea>` is subject to spell checking by the underlying browser/OS. the value can be:\n\n*   `true`: Indicates that the element needs to have its spelling and grammar checked.\n*   `default` : Indicates that the element is to act according to a default behavior, possibly based on the parent element's own `spellcheck` value.\n*   `false` : Indicates that the element should not be spell checked."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/textarea"
      }]
    }, {
      name: "output",
      description: {
        kind: "markdown",
        value: "The output element represents the result of a calculation performed by the application, or the result of a user action."
      },
      attributes: [{
        name: "for",
        description: {
          kind: "markdown",
          value: "A space-separated list of other elements’ [`id`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/id)s, indicating that those elements contributed input values to (or otherwise affected) the calculation."
        }
      }, {
        name: "form",
        description: {
          kind: "markdown",
          value: 'The [form element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form) that this element is associated with (its "form owner"). The value of the attribute must be an `id` of a form element in the same document. If this attribute is not specified, the output element must be a descendant of a form element. This attribute enables you to place output elements anywhere within a document, not just as descendants of their form elements.'
        }
      }, {
        name: "name",
        description: {
          kind: "markdown",
          value: 'The name of the element, exposed in the [`HTMLFormElement`](https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement "The HTMLFormElement interface represents a <form> element in the DOM; it allows access to and in some cases modification of aspects of the form, as well as access to its component elements.") API.'
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/output"
      }]
    }, {
      name: "progress",
      description: {
        kind: "markdown",
        value: "The progress element represents the completion progress of a task. The progress is either indeterminate, indicating that progress is being made but that it is not clear how much more work remains to be done before the task is complete (e.g. because the task is waiting for a remote host to respond), or the progress is a number in the range zero to a maximum, giving the fraction of work that has so far been completed."
      },
      attributes: [{
        name: "value",
        description: {
          kind: "markdown",
          value: "This attribute specifies how much of the task that has been completed. It must be a valid floating point number between 0 and `max`, or between 0 and 1 if `max` is omitted. If there is no `value` attribute, the progress bar is indeterminate; this indicates that an activity is ongoing with no indication of how long it is expected to take."
        }
      }, {
        name: "max",
        description: {
          kind: "markdown",
          value: "This attribute describes how much work the task indicated by the `progress` element requires. The `max` attribute, if present, must have a value greater than zero and be a valid floating point number. The default value is 1."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/progress"
      }]
    }, {
      name: "meter",
      description: {
        kind: "markdown",
        value: "The meter element represents a scalar measurement within a known range, or a fractional value; for example disk usage, the relevance of a query result, or the fraction of a voting population to have selected a particular candidate."
      },
      attributes: [{
        name: "value",
        description: {
          kind: "markdown",
          value: "The current numeric value. This must be between the minimum and maximum values (`min` attribute and `max` attribute) if they are specified. If unspecified or malformed, the value is 0. If specified, but not within the range given by the `min` attribute and `max` attribute, the value is equal to the nearest end of the range.\n\n**Usage note:** Unless the `value` attribute is between `0` and `1` (inclusive), the `min` and `max` attributes should define the range so that the `value` attribute's value is within it."
        }
      }, {
        name: "min",
        description: {
          kind: "markdown",
          value: "The lower numeric bound of the measured range. This must be less than the maximum value (`max` attribute), if specified. If unspecified, the minimum value is 0."
        }
      }, {
        name: "max",
        description: {
          kind: "markdown",
          value: "The upper numeric bound of the measured range. This must be greater than the minimum value (`min` attribute), if specified. If unspecified, the maximum value is 1."
        }
      }, {
        name: "low",
        description: {
          kind: "markdown",
          value: "The upper numeric bound of the low end of the measured range. This must be greater than the minimum value (`min` attribute), and it also must be less than the high value and maximum value (`high` attribute and `max` attribute, respectively), if any are specified. If unspecified, or if less than the minimum value, the `low` value is equal to the minimum value."
        }
      }, {
        name: "high",
        description: {
          kind: "markdown",
          value: "The lower numeric bound of the high end of the measured range. This must be less than the maximum value (`max` attribute), and it also must be greater than the low value and minimum value (`low` attribute and **min** attribute, respectively), if any are specified. If unspecified, or if greater than the maximum value, the `high` value is equal to the maximum value."
        }
      }, {
        name: "optimum",
        description: {
          kind: "markdown",
          value: "This attribute indicates the optimal numeric value. It must be within the range (as defined by the `min` attribute and `max` attribute). When used with the `low` attribute and `high` attribute, it gives an indication where along the range is considered preferable. For example, if it is between the `min` attribute and the `low` attribute, then the lower range is considered preferred."
        }
      }, {
        name: "form",
        description: "This attribute associates the element with a `form` element that has ownership of the `meter` element. For example, a `meter` might be displaying a range corresponding to an `input` element of `type` _number_. This attribute is only used if the `meter` element is being used as a form-associated element; even then, it may be omitted if the element appears as a descendant of a `form` element."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/meter"
      }]
    }, {
      name: "fieldset",
      description: {
        kind: "markdown",
        value: "The fieldset element represents a set of form controls optionally grouped under a common name."
      },
      attributes: [{
        name: "disabled",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "If this Boolean attribute is set, all form controls that are descendants of the `<fieldset>`, are disabled, meaning they are not editable and won't be submitted along with the `<form>`. They won't receive any browsing events, like mouse clicks or focus-related events. By default browsers display such controls grayed out. Note that form elements inside the [`<legend>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/legend \"The HTML <legend> element represents a caption for the content of its parent <fieldset>.\") element won't be disabled."
        }
      }, {
        name: "form",
        description: {
          kind: "markdown",
          value: 'This attribute takes the value of the `id` attribute of a [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form "The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.") element you want the `<fieldset>` to be part of, even if it is not inside the form.'
        }
      }, {
        name: "name",
        description: {
          kind: "markdown",
          value: 'The name associated with the group.\n\n**Note**: The caption for the fieldset is given by the first [`<legend>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/legend "The HTML <legend> element represents a caption for the content of its parent <fieldset>.") element nested inside it.'
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/fieldset"
      }]
    }, {
      name: "legend",
      description: {
        kind: "markdown",
        value: "The legend element represents a caption for the rest of the contents of the legend element's parent fieldset element, if any."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/legend"
      }]
    }, {
      name: "details",
      description: {
        kind: "markdown",
        value: "The details element represents a disclosure widget from which the user can obtain additional information or controls."
      },
      attributes: [{
        name: "open",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: "This Boolean attribute indicates whether or not the details — that is, the contents of the `<details>` element — are currently visible. The default, `false`, means the details are not visible."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/details"
      }]
    }, {
      name: "summary",
      description: {
        kind: "markdown",
        value: "The summary element represents a summary, caption, or legend for the rest of the contents of the summary element's parent details element, if any."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/summary"
      }]
    }, {
      name: "dialog",
      description: {
        kind: "markdown",
        value: "The dialog element represents a part of an application that a user interacts with to perform a task, for example a dialog box, inspector, or window."
      },
      attributes: [{
        name: "open",
        description: "Indicates that the dialog is active and available for interaction. When the `open` attribute is not set, the dialog shouldn't be shown to the user."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/dialog"
      }]
    }, {
      name: "script",
      description: {
        kind: "markdown",
        value: "The script element allows authors to include dynamic script and data blocks in their documents. The element does not represent content for the user."
      },
      attributes: [{
        name: "src",
        description: {
          kind: "markdown",
          value: "This attribute specifies the URI of an external script; this can be used as an alternative to embedding a script directly within a document.\n\nIf a `script` element has a `src` attribute specified, it should not have a script embedded inside its tags."
        }
      }, {
        name: "type",
        description: {
          kind: "markdown",
          value: 'This attribute indicates the type of script represented. The value of this attribute will be in one of the following categories:\n\n*   **Omitted or a JavaScript MIME type:** For HTML5-compliant browsers this indicates the script is JavaScript. HTML5 specification urges authors to omit the attribute rather than provide a redundant MIME type. In earlier browsers, this identified the scripting language of the embedded or imported (via the `src` attribute) code. JavaScript MIME types are [listed in the specification](https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types#JavaScript_types).\n*   **`module`:** For HTML5-compliant browsers the code is treated as a JavaScript module. The processing of the script contents is not affected by the `charset` and `defer` attributes. For information on using `module`, see [ES6 in Depth: Modules](https://hacks.mozilla.org/2015/08/es6-in-depth-modules/). Code may behave differently when the `module` keyword is used.\n*   **Any other value:** The embedded content is treated as a data block which won\'t be processed by the browser. Developers must use a valid MIME type that is not a JavaScript MIME type to denote data blocks. The `src` attribute will be ignored.\n\n**Note:** in Firefox you could specify the version of JavaScript contained in a `<script>` element by including a non-standard `version` parameter inside the `type` attribute — for example `type="text/javascript;version=1.8"`. This has been removed in Firefox 59 (see [bug 1428745](https://bugzilla.mozilla.org/show_bug.cgi?id=1428745 "FIXED: Remove support for version parameter from script loader")).'
        }
      }, {
        name: "charset"
      }, {
        name: "async",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: `This is a Boolean attribute indicating that the browser should, if possible, load the script asynchronously.

This attribute must not be used if the \`src\` attribute is absent (i.e. for inline scripts). If it is included in this case it will have no effect.

Browsers usually assume the worst case scenario and load scripts synchronously, (i.e. \`async="false"\`) during HTML parsing.

Dynamically inserted scripts (using [\`document.createElement()\`](https://developer.mozilla.org/en-US/docs/Web/API/Document/createElement "In an HTML document, the document.createElement() method creates the HTML element specified by tagName, or an HTMLUnknownElement if tagName isn't recognized.")) load asynchronously by default, so to turn on synchronous loading (i.e. scripts load in the order they were inserted) set \`async="false"\`.

See [Browser compatibility](#Browser_compatibility) for notes on browser support. See also [Async scripts for asm.js](https://developer.mozilla.org/en-US/docs/Games/Techniques/Async_scripts).`
        }
      }, {
        name: "defer",
        valueSet: "v",
        description: {
          kind: "markdown",
          value: 'This Boolean attribute is set to indicate to a browser that the script is meant to be executed after the document has been parsed, but before firing [`DOMContentLoaded`](https://developer.mozilla.org/en-US/docs/Web/Events/DOMContentLoaded "/en-US/docs/Web/Events/DOMContentLoaded").\n\nScripts with the `defer` attribute will prevent the `DOMContentLoaded` event from firing until the script has loaded and finished evaluating.\n\nThis attribute must not be used if the `src` attribute is absent (i.e. for inline scripts), in this case it would have no effect.\n\nTo achieve a similar effect for dynamically inserted scripts use `async="false"` instead. Scripts with the `defer` attribute will execute in the order in which they appear in the document.'
        }
      }, {
        name: "crossorigin",
        valueSet: "xo",
        description: {
          kind: "markdown",
          value: 'Normal `script` elements pass minimal information to the [`window.onerror`](https://developer.mozilla.org/en-US/docs/Web/API/GlobalEventHandlers/onerror "The onerror property of the GlobalEventHandlers mixin is an EventHandler that processes error events.") for scripts which do not pass the standard [CORS](https://developer.mozilla.org/en-US/docs/Glossary/CORS "CORS: CORS (Cross-Origin Resource Sharing) is a system, consisting of transmitting HTTP headers, that determines whether browsers block frontend JavaScript code from accessing responses for cross-origin requests.") checks. To allow error logging for sites which use a separate domain for static media, use this attribute. See [CORS settings attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_settings_attributes) for a more descriptive explanation of its valid arguments.'
        }
      }, {
        name: "nonce",
        description: {
          kind: "markdown",
          value: "A cryptographic nonce (number used once) to list the allowed inline scripts in a [script-src Content-Security-Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Security-Policy/script-src). The server must generate a unique nonce value each time it transmits a policy. It is critical to provide a nonce that cannot be guessed as bypassing a resource's policy is otherwise trivial."
        }
      }, {
        name: "integrity",
        description: "This attribute contains inline metadata that a user agent can use to verify that a fetched resource has been delivered free of unexpected manipulation. See [Subresource Integrity](https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity)."
      }, {
        name: "nomodule",
        description: "This Boolean attribute is set to indicate that the script should not be executed in browsers that support [ES2015 modules](https://hacks.mozilla.org/2015/08/es6-in-depth-modules/) — in effect, this can be used to serve fallback scripts to older browsers that do not support modular JavaScript code."
      }, {
        name: "referrerpolicy",
        description: 'Indicates which [referrer](https://developer.mozilla.org/en-US/docs/Web/API/Document/referrer) to send when fetching the script, or resources fetched by the script:\n\n*   `no-referrer`: The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer "The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.") header will not be sent.\n*   `no-referrer-when-downgrade` (default): The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer "The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.") header will not be sent to [origin](https://developer.mozilla.org/en-US/docs/Glossary/origin "origin: Web content\'s origin is defined by the scheme (protocol), host (domain), and port of the URL used to access it. Two objects have the same origin only when the scheme, host, and port all match.")s without [TLS](https://developer.mozilla.org/en-US/docs/Glossary/TLS "TLS: Transport Layer Security (TLS), previously known as Secure Sockets Layer (SSL), is a protocol used by applications to communicate securely across a network, preventing tampering with and eavesdropping on email, web browsing, messaging, and other protocols.") ([HTTPS](https://developer.mozilla.org/en-US/docs/Glossary/HTTPS "HTTPS: HTTPS (HTTP Secure) is an encrypted version of the HTTP protocol. It usually uses SSL or TLS to encrypt all communication between a client and a server. This secure connection allows clients to safely exchange sensitive data with a server, for example for banking activities or online shopping.")).\n*   `origin`: The sent referrer will be limited to the origin of the referring page: its [scheme](https://developer.mozilla.org/en-US/docs/Archive/Mozilla/URIScheme), [host](https://developer.mozilla.org/en-US/docs/Glossary/host "host: A host is a device connected to the Internet (or a local network). Some hosts called servers offer additional services like serving webpages or storing files and emails."), and [port](https://developer.mozilla.org/en-US/docs/Glossary/port "port: For a computer connected to a network with an IP address, a port is a communication endpoint. Ports are designated by numbers, and below 1024 each port is associated by default with a specific protocol.").\n*   `origin-when-cross-origin`: The referrer sent to other origins will be limited to the scheme, the host, and the port. Navigations on the same origin will still include the path.\n*   `same-origin`: A referrer will be sent for [same origin](https://developer.mozilla.org/en-US/docs/Glossary/Same-origin_policy "same origin: The same-origin policy is a critical security mechanism that restricts how a document or script loaded from one origin can interact with a resource from another origin."), but cross-origin requests will contain no referrer information.\n*   `strict-origin`: Only send the origin of the document as the referrer when the protocol security level stays the same (e.g. HTTPS→HTTPS), but don\'t send it to a less secure destination (e.g. HTTPS→HTTP).\n*   `strict-origin-when-cross-origin`: Send a full URL when performing a same-origin request, but only send the origin when the protocol security level stays the same (e.g.HTTPS→HTTPS), and send no header to a less secure destination (e.g. HTTPS→HTTP).\n*   `unsafe-url`: The referrer will include the origin _and_ the path (but not the [fragment](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/hash), [password](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/password), or [username](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/username)). **This value is unsafe**, because it leaks origins and paths from TLS-protected resources to insecure origins.\n\n**Note**: An empty string value (`""`) is both the default value, and a fallback value if `referrerpolicy` is not supported. If `referrerpolicy` is not explicitly specified on the `<script>` element, it will adopt a higher-level referrer policy, i.e. one set on the whole document or domain. If a higher-level policy is not available, the empty string is treated as being equivalent to `no-referrer-when-downgrade`.'
      }, {
        name: "text",
        description: "Like the `textContent` attribute, this attribute sets the text content of the element. Unlike the `textContent` attribute, however, this attribute is evaluated as executable code after the node is inserted into the DOM."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/script"
      }]
    }, {
      name: "noscript",
      description: {
        kind: "markdown",
        value: "The noscript element represents nothing if scripting is enabled, and represents its children if scripting is disabled. It is used to present different markup to user agents that support scripting and those that don't support scripting, by affecting how the document is parsed."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/noscript"
      }]
    }, {
      name: "template",
      description: {
        kind: "markdown",
        value: "The template element is used to declare fragments of HTML that can be cloned and inserted in the document by script."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/template"
      }]
    }, {
      name: "canvas",
      description: {
        kind: "markdown",
        value: "The canvas element provides scripts with a resolution-dependent bitmap canvas, which can be used for rendering graphs, game graphics, art, or other visual images on the fly."
      },
      attributes: [{
        name: "width",
        description: {
          kind: "markdown",
          value: "The width of the coordinate space in CSS pixels. Defaults to 300."
        }
      }, {
        name: "height",
        description: {
          kind: "markdown",
          value: "The height of the coordinate space in CSS pixels. Defaults to 150."
        }
      }, {
        name: "moz-opaque",
        description: "Lets the canvas know whether or not translucency will be a factor. If the canvas knows there's no translucency, painting performance can be optimized. This is only supported by Mozilla-based browsers; use the standardized [`canvas.getContext('2d', { alpha: false })`](https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement/getContext \"The HTMLCanvasElement.getContext() method returns a drawing context on the canvas, or null if the context identifier is not supported.\") instead."
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/canvas"
      }]
    }, {
      name: "slot",
      description: {
        kind: "markdown",
        value: "The slot element is a placeholder inside a web component that you can fill with your own markup, which lets you create separate DOM trees and present them together."
      },
      attributes: [{
        name: "name",
        description: {
          kind: "markdown",
          value: "The slot's name.\nA **named slot** is a `<slot>` element with a `name` attribute."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/slot"
      }]
    }, {
      name: "data",
      description: {
        kind: "markdown",
        value: "The data element links a given piece of content with a machine-readable translation."
      },
      attributes: [{
        name: "value",
        description: {
          kind: "markdown",
          value: "This attribute specifies the machine-readable translation of the content of the element."
        }
      }],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/data"
      }]
    }, {
      name: "hgroup",
      description: {
        kind: "markdown",
        value: "The hgroup element represents a heading and related content. It groups a single h1–h6 element with one or more p."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/hgroup"
      }]
    }, {
      name: "menu",
      description: {
        kind: "markdown",
        value: "The menu element represents an unordered list of interactive items."
      },
      attributes: [],
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Element/menu"
      }]
    }],
    globalAttributes: [{
      name: "accesskey",
      description: {
        kind: "markdown",
        value: "Provides a hint for generating a keyboard shortcut for the current element. This attribute consists of a space-separated list of characters. The browser should use the first one that exists on the computer keyboard layout."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/accesskey"
      }]
    }, {
      name: "autocapitalize",
      description: {
        kind: "markdown",
        value: "Controls whether and how text input is automatically capitalized as it is entered/edited by the user. It can have the following values:\n\n*   `off` or `none`, no autocapitalization is applied (all letters default to lowercase)\n*   `on` or `sentences`, the first letter of each sentence defaults to a capital letter; all other letters default to lowercase\n*   `words`, the first letter of each word defaults to a capital letter; all other letters default to lowercase\n*   `characters`, all letters should default to uppercase"
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/autocapitalize"
      }]
    }, {
      name: "class",
      description: {
        kind: "markdown",
        value: 'A space-separated list of the classes of the element. Classes allows CSS and JavaScript to select and access specific elements via the [class selectors](https://developer.mozilla.org/docs/Web/CSS/Class_selectors) or functions like the method [`Document.getElementsByClassName()`](https://developer.mozilla.org/docs/Web/API/Document/getElementsByClassName "returns an array-like object of all child elements which have all of the given class names.").'
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/class"
      }]
    }, {
      name: "contenteditable",
      description: {
        kind: "markdown",
        value: "An enumerated attribute indicating if the element should be editable by the user. If so, the browser modifies its widget to allow editing. The attribute must take one of the following values:\n\n*   `true` or the _empty string_, which indicates that the element must be editable;\n*   `false`, which indicates that the element must not be editable."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/contenteditable"
      }]
    }, {
      name: "contextmenu",
      description: {
        kind: "markdown",
        value: 'The `[**id**](#attr-id)` of a [`<menu>`](https://developer.mozilla.org/docs/Web/HTML/Element/menu "The HTML <menu> element represents a group of commands that a user can perform or activate. This includes both list menus, which might appear across the top of a screen, as well as context menus, such as those that might appear underneath a button after it has been clicked.") to use as the contextual menu for this element.'
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/contextmenu"
      }]
    }, {
      name: "dir",
      description: {
        kind: "markdown",
        value: "An enumerated attribute indicating the directionality of the element's text. It can have the following values:\n\n*   `ltr`, which means _left to right_ and is to be used for languages that are written from the left to the right (like English);\n*   `rtl`, which means _right to left_ and is to be used for languages that are written from the right to the left (like Arabic);\n*   `auto`, which lets the user agent decide. It uses a basic algorithm as it parses the characters inside the element until it finds a character with a strong directionality, then it applies that directionality to the whole element."
      },
      valueSet: "d",
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/dir"
      }]
    }, {
      name: "draggable",
      description: {
        kind: "markdown",
        value: "An enumerated attribute indicating whether the element can be dragged, using the [Drag and Drop API](https://developer.mozilla.org/docs/DragDrop/Drag_and_Drop). It can have the following values:\n\n*   `true`, which indicates that the element may be dragged\n*   `false`, which indicates that the element may not be dragged."
      },
      valueSet: "b",
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/draggable"
      }]
    }, {
      name: "dropzone",
      description: {
        kind: "markdown",
        value: "An enumerated attribute indicating what types of content can be dropped on an element, using the [Drag and Drop API](https://developer.mozilla.org/docs/DragDrop/Drag_and_Drop). It can have the following values:\n\n*   `copy`, which indicates that dropping will create a copy of the element that was dragged\n*   `move`, which indicates that the element that was dragged will be moved to this new location.\n*   `link`, will create a link to the dragged data."
      }
    }, {
      name: "exportparts",
      description: {
        kind: "markdown",
        value: "Used to transitively export shadow parts from a nested shadow tree into a containing light tree."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/exportparts"
      }]
    }, {
      name: "hidden",
      description: {
        kind: "markdown",
        value: "A Boolean attribute indicates that the element is not yet, or is no longer, _relevant_. For example, it can be used to hide elements of the page that can't be used until the login process has been completed. The browser won't render such elements. This attribute must not be used to hide content that could legitimately be shown."
      },
      valueSet: "v",
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/hidden"
      }]
    }, {
      name: "id",
      description: {
        kind: "markdown",
        value: "Defines a unique identifier (ID) which must be unique in the whole document. Its purpose is to identify the element when linking (using a fragment identifier), scripting, or styling (with CSS)."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/id"
      }]
    }, {
      name: "inputmode",
      description: {
        kind: "markdown",
        value: 'Provides a hint to browsers as to the type of virtual keyboard configuration to use when editing this element or its contents. Used primarily on [`<input>`](https://developer.mozilla.org/docs/Web/HTML/Element/input "The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.") elements, but is usable on any element while in `[contenteditable](https://developer.mozilla.org/docs/Web/HTML/Global_attributes#attr-contenteditable)` mode.'
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/inputmode"
      }]
    }, {
      name: "is",
      description: {
        kind: "markdown",
        value: "Allows you to specify that a standard HTML element should behave like a registered custom built-in element (see [Using custom elements](https://developer.mozilla.org/docs/Web/Web_Components/Using_custom_elements) for more details)."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/is"
      }]
    }, {
      name: "itemid",
      description: {
        kind: "markdown",
        value: "The unique, global identifier of an item."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemid"
      }]
    }, {
      name: "itemprop",
      description: {
        kind: "markdown",
        value: "Used to add properties to an item. Every HTML element may have an `itemprop` attribute specified, where an `itemprop` consists of a name and value pair."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemprop"
      }]
    }, {
      name: "itemref",
      description: {
        kind: "markdown",
        value: "Properties that are not descendants of an element with the `itemscope` attribute can be associated with the item using an `itemref`. It provides a list of element ids (not `itemid`s) with additional properties elsewhere in the document."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemref"
      }]
    }, {
      name: "itemscope",
      description: {
        kind: "markdown",
        value: "`itemscope` (usually) works along with `[itemtype](https://developer.mozilla.org/docs/Web/HTML/Global_attributes#attr-itemtype)` to specify that the HTML contained in a block is about a particular item. `itemscope` creates the Item and defines the scope of the `itemtype` associated with it. `itemtype` is a valid URL of a vocabulary (such as [schema.org](https://schema.org/)) that describes the item and its properties context."
      },
      valueSet: "v",
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemscope"
      }]
    }, {
      name: "itemtype",
      description: {
        kind: "markdown",
        value: "Specifies the URL of the vocabulary that will be used to define `itemprop`s (item properties) in the data structure. `[itemscope](https://developer.mozilla.org/docs/Web/HTML/Global_attributes#attr-itemscope)` is used to set the scope of where in the data structure the vocabulary set by `itemtype` will be active."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemtype"
      }]
    }, {
      name: "lang",
      description: {
        kind: "markdown",
        value: "Helps define the language of an element: the language that non-editable elements are in, or the language that editable elements should be written in by the user. The attribute contains one “language tag” (made of hyphen-separated “language subtags”) in the format defined in [_Tags for Identifying Languages (BCP47)_](https://www.ietf.org/rfc/bcp/bcp47.txt). [**xml:lang**](#attr-xml:lang) has priority over it."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/lang"
      }]
    }, {
      name: "part",
      description: {
        kind: "markdown",
        value: 'A space-separated list of the part names of the element. Part names allows CSS to select and style specific elements in a shadow tree via the [`::part`](https://developer.mozilla.org/docs/Web/CSS/::part "The ::part CSS pseudo-element represents any element within a shadow tree that has a matching part attribute.") pseudo-element.'
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/part"
      }]
    }, {
      name: "role",
      valueSet: "roles"
    }, {
      name: "slot",
      description: {
        kind: "markdown",
        value: "Assigns a slot in a [shadow DOM](https://developer.mozilla.org/docs/Web/Web_Components/Shadow_DOM) shadow tree to an element: An element with a `slot` attribute is assigned to the slot created by the [`<slot>`](https://developer.mozilla.org/docs/Web/HTML/Element/slot \"The HTML <slot> element—part of the Web Components technology suite—is a placeholder inside a web component that you can fill with your own markup, which lets you create separate DOM trees and present them together.\") element whose `[name](https://developer.mozilla.org/docs/Web/HTML/Element/slot#attr-name)` attribute's value matches that `slot` attribute's value."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/slot"
      }]
    }, {
      name: "spellcheck",
      description: {
        kind: "markdown",
        value: "An enumerated attribute defines whether the element may be checked for spelling errors. It may have the following values:\n\n*   `true`, which indicates that the element should be, if possible, checked for spelling errors;\n*   `false`, which indicates that the element should not be checked for spelling errors."
      },
      valueSet: "b",
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/spellcheck"
      }]
    }, {
      name: "style",
      description: {
        kind: "markdown",
        value: 'Contains [CSS](https://developer.mozilla.org/docs/Web/CSS) styling declarations to be applied to the element. Note that it is recommended for styles to be defined in a separate file or files. This attribute and the [`<style>`](https://developer.mozilla.org/docs/Web/HTML/Element/style "The HTML <style> element contains style information for a document, or part of a document.") element have mainly the purpose of allowing for quick styling, for example for testing purposes.'
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/style"
      }]
    }, {
      name: "tabindex",
      description: {
        kind: "markdown",
        value: `An integer attribute indicating if the element can take input focus (is _focusable_), if it should participate to sequential keyboard navigation, and if so, at what position. It can take several values:

*   a _negative value_ means that the element should be focusable, but should not be reachable via sequential keyboard navigation;
*   \`0\` means that the element should be focusable and reachable via sequential keyboard navigation, but its relative order is defined by the platform convention;
*   a _positive value_ means that the element should be focusable and reachable via sequential keyboard navigation; the order in which the elements are focused is the increasing value of the [**tabindex**](#attr-tabindex). If several elements share the same tabindex, their relative order follows their relative positions in the document.`
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/tabindex"
      }]
    }, {
      name: "title",
      description: {
        kind: "markdown",
        value: "Contains a text representing advisory information related to the element it belongs to. Such information can typically, but not necessarily, be presented to the user as a tooltip."
      },
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/title"
      }]
    }, {
      name: "translate",
      description: {
        kind: "markdown",
        value: "An enumerated attribute that is used to specify whether an element's attribute values and the values of its [`Text`](https://developer.mozilla.org/docs/Web/API/Text \"The Text interface represents the textual content of Element or Attr. If an element has no markup within its content, it has a single child implementing Text that contains the element's text. However, if the element contains markup, it is parsed into information items and Text nodes that form its children.\") node children are to be translated when the page is localized, or whether to leave them unchanged. It can have the following values:\n\n*   empty string and `yes`, which indicates that the element will be translated.\n*   `no`, which indicates that the element will not be translated."
      },
      valueSet: "y",
      references: [{
        name: "MDN Reference",
        url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/translate"
      }]
    }, {
      name: "onabort",
      description: {
        kind: "markdown",
        value: "The loading of a resource has been aborted."
      }
    }, {
      name: "onblur",
      description: {
        kind: "markdown",
        value: "An element has lost focus (does not bubble)."
      }
    }, {
      name: "oncanplay",
      description: {
        kind: "markdown",
        value: "The user agent can play the media, but estimates that not enough data has been loaded to play the media up to its end without having to stop for further buffering of content."
      }
    }, {
      name: "oncanplaythrough",
      description: {
        kind: "markdown",
        value: "The user agent can play the media up to its end without having to stop for further buffering of content."
      }
    }, {
      name: "onchange",
      description: {
        kind: "markdown",
        value: "The change event is fired for <input>, <select>, and <textarea> elements when a change to the element's value is committed by the user."
      }
    }, {
      name: "onclick",
      description: {
        kind: "markdown",
        value: "A pointing device button has been pressed and released on an element."
      }
    }, {
      name: "oncontextmenu",
      description: {
        kind: "markdown",
        value: "The right button of the mouse is clicked (before the context menu is displayed)."
      }
    }, {
      name: "ondblclick",
      description: {
        kind: "markdown",
        value: "A pointing device button is clicked twice on an element."
      }
    }, {
      name: "ondrag",
      description: {
        kind: "markdown",
        value: "An element or text selection is being dragged (every 350ms)."
      }
    }, {
      name: "ondragend",
      description: {
        kind: "markdown",
        value: "A drag operation is being ended (by releasing a mouse button or hitting the escape key)."
      }
    }, {
      name: "ondragenter",
      description: {
        kind: "markdown",
        value: "A dragged element or text selection enters a valid drop target."
      }
    }, {
      name: "ondragleave",
      description: {
        kind: "markdown",
        value: "A dragged element or text selection leaves a valid drop target."
      }
    }, {
      name: "ondragover",
      description: {
        kind: "markdown",
        value: "An element or text selection is being dragged over a valid drop target (every 350ms)."
      }
    }, {
      name: "ondragstart",
      description: {
        kind: "markdown",
        value: "The user starts dragging an element or text selection."
      }
    }, {
      name: "ondrop",
      description: {
        kind: "markdown",
        value: "An element is dropped on a valid drop target."
      }
    }, {
      name: "ondurationchange",
      description: {
        kind: "markdown",
        value: "The duration attribute has been updated."
      }
    }, {
      name: "onemptied",
      description: {
        kind: "markdown",
        value: "The media has become empty; for example, this event is sent if the media has already been loaded (or partially loaded), and the load() method is called to reload it."
      }
    }, {
      name: "onended",
      description: {
        kind: "markdown",
        value: "Playback has stopped because the end of the media was reached."
      }
    }, {
      name: "onerror",
      description: {
        kind: "markdown",
        value: "A resource failed to load."
      }
    }, {
      name: "onfocus",
      description: {
        kind: "markdown",
        value: "An element has received focus (does not bubble)."
      }
    }, {
      name: "onformchange"
    }, {
      name: "onforminput"
    }, {
      name: "oninput",
      description: {
        kind: "markdown",
        value: "The value of an element changes or the content of an element with the attribute contenteditable is modified."
      }
    }, {
      name: "oninvalid",
      description: {
        kind: "markdown",
        value: "A submittable element has been checked and doesn't satisfy its constraints."
      }
    }, {
      name: "onkeydown",
      description: {
        kind: "markdown",
        value: "A key is pressed down."
      }
    }, {
      name: "onkeypress",
      description: {
        kind: "markdown",
        value: "A key is pressed down and that key normally produces a character value (use input instead)."
      }
    }, {
      name: "onkeyup",
      description: {
        kind: "markdown",
        value: "A key is released."
      }
    }, {
      name: "onload",
      description: {
        kind: "markdown",
        value: "A resource and its dependent resources have finished loading."
      }
    }, {
      name: "onloadeddata",
      description: {
        kind: "markdown",
        value: "The first frame of the media has finished loading."
      }
    }, {
      name: "onloadedmetadata",
      description: {
        kind: "markdown",
        value: "The metadata has been loaded."
      }
    }, {
      name: "onloadstart",
      description: {
        kind: "markdown",
        value: "Progress has begun."
      }
    }, {
      name: "onmousedown",
      description: {
        kind: "markdown",
        value: "A pointing device button (usually a mouse) is pressed on an element."
      }
    }, {
      name: "onmousemove",
      description: {
        kind: "markdown",
        value: "A pointing device is moved over an element."
      }
    }, {
      name: "onmouseout",
      description: {
        kind: "markdown",
        value: "A pointing device is moved off the element that has the listener attached or off one of its children."
      }
    }, {
      name: "onmouseover",
      description: {
        kind: "markdown",
        value: "A pointing device is moved onto the element that has the listener attached or onto one of its children."
      }
    }, {
      name: "onmouseup",
      description: {
        kind: "markdown",
        value: "A pointing device button is released over an element."
      }
    }, {
      name: "onmousewheel"
    }, {
      name: "onmouseenter",
      description: {
        kind: "markdown",
        value: "A pointing device is moved onto the element that has the listener attached."
      }
    }, {
      name: "onmouseleave",
      description: {
        kind: "markdown",
        value: "A pointing device is moved off the element that has the listener attached."
      }
    }, {
      name: "onpause",
      description: {
        kind: "markdown",
        value: "Playback has been paused."
      }
    }, {
      name: "onplay",
      description: {
        kind: "markdown",
        value: "Playback has begun."
      }
    }, {
      name: "onplaying",
      description: {
        kind: "markdown",
        value: "Playback is ready to start after having been paused or delayed due to lack of data."
      }
    }, {
      name: "onprogress",
      description: {
        kind: "markdown",
        value: "In progress."
      }
    }, {
      name: "onratechange",
      description: {
        kind: "markdown",
        value: "The playback rate has changed."
      }
    }, {
      name: "onreset",
      description: {
        kind: "markdown",
        value: "A form is reset."
      }
    }, {
      name: "onresize",
      description: {
        kind: "markdown",
        value: "The document view has been resized."
      }
    }, {
      name: "onreadystatechange",
      description: {
        kind: "markdown",
        value: "The readyState attribute of a document has changed."
      }
    }, {
      name: "onscroll",
      description: {
        kind: "markdown",
        value: "The document view or an element has been scrolled."
      }
    }, {
      name: "onseeked",
      description: {
        kind: "markdown",
        value: "A seek operation completed."
      }
    }, {
      name: "onseeking",
      description: {
        kind: "markdown",
        value: "A seek operation began."
      }
    }, {
      name: "onselect",
      description: {
        kind: "markdown",
        value: "Some text is being selected."
      }
    }, {
      name: "onshow",
      description: {
        kind: "markdown",
        value: "A contextmenu event was fired on/bubbled to an element that has a contextmenu attribute"
      }
    }, {
      name: "onstalled",
      description: {
        kind: "markdown",
        value: "The user agent is trying to fetch media data, but data is unexpectedly not forthcoming."
      }
    }, {
      name: "onsubmit",
      description: {
        kind: "markdown",
        value: "A form is submitted."
      }
    }, {
      name: "onsuspend",
      description: {
        kind: "markdown",
        value: "Media data loading has been suspended."
      }
    }, {
      name: "ontimeupdate",
      description: {
        kind: "markdown",
        value: "The time indicated by the currentTime attribute has been updated."
      }
    }, {
      name: "onvolumechange",
      description: {
        kind: "markdown",
        value: "The volume has changed."
      }
    }, {
      name: "onwaiting",
      description: {
        kind: "markdown",
        value: "Playback has stopped because of a temporary lack of data."
      }
    }, {
      name: "onpointercancel",
      description: {
        kind: "markdown",
        value: "The pointer is unlikely to produce any more events."
      }
    }, {
      name: "onpointerdown",
      description: {
        kind: "markdown",
        value: "The pointer enters the active buttons state."
      }
    }, {
      name: "onpointerenter",
      description: {
        kind: "markdown",
        value: "Pointing device is moved inside the hit-testing boundary."
      }
    }, {
      name: "onpointerleave",
      description: {
        kind: "markdown",
        value: "Pointing device is moved out of the hit-testing boundary."
      }
    }, {
      name: "onpointerlockchange",
      description: {
        kind: "markdown",
        value: "The pointer was locked or released."
      }
    }, {
      name: "onpointerlockerror",
      description: {
        kind: "markdown",
        value: "It was impossible to lock the pointer for technical reasons or because the permission was denied."
      }
    }, {
      name: "onpointermove",
      description: {
        kind: "markdown",
        value: "The pointer changed coordinates."
      }
    }, {
      name: "onpointerout",
      description: {
        kind: "markdown",
        value: "The pointing device moved out of hit-testing boundary or leaves detectable hover range."
      }
    }, {
      name: "onpointerover",
      description: {
        kind: "markdown",
        value: "The pointing device is moved into the hit-testing boundary."
      }
    }, {
      name: "onpointerup",
      description: {
        kind: "markdown",
        value: "The pointer leaves the active buttons state."
      }
    }, {
      name: "aria-activedescendant",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-activedescendant"
      }],
      description: {
        kind: "markdown",
        value: "Identifies the currently active element when DOM focus is on a [`composite`](https://www.w3.org/TR/wai-aria-1.1/#composite) widget, [`textbox`](https://www.w3.org/TR/wai-aria-1.1/#textbox), [`group`](https://www.w3.org/TR/wai-aria-1.1/#group), or [`application`](https://www.w3.org/TR/wai-aria-1.1/#application)."
      }
    }, {
      name: "aria-atomic",
      valueSet: "b",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-atomic"
      }],
      description: {
        kind: "markdown",
        value: "Indicates whether [assistive technologies](https://www.w3.org/TR/wai-aria-1.1/#dfn-assistive-technology) will present all, or only parts of, the changed region based on the change notifications defined by the [`aria-relevant`](https://www.w3.org/TR/wai-aria-1.1/#aria-relevant) attribute."
      }
    }, {
      name: "aria-autocomplete",
      valueSet: "autocomplete",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-autocomplete"
      }],
      description: {
        kind: "markdown",
        value: "Indicates whether inputting text could trigger display of one or more predictions of the user's intended value for an input and specifies how predictions would be presented if they are made."
      }
    }, {
      name: "aria-busy",
      valueSet: "b",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-busy"
      }],
      description: {
        kind: "markdown",
        value: "Indicates an element is being modified and that assistive technologies _MAY_ want to wait until the modifications are complete before exposing them to the user."
      }
    }, {
      name: "aria-checked",
      valueSet: "tristate",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-checked"
      }],
      description: {
        kind: "markdown",
        value: 'Indicates the current "checked" [state](https://www.w3.org/TR/wai-aria-1.1/#dfn-state) of checkboxes, radio buttons, and other [widgets](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget). See related [`aria-pressed`](https://www.w3.org/TR/wai-aria-1.1/#aria-pressed) and [`aria-selected`](https://www.w3.org/TR/wai-aria-1.1/#aria-selected).'
      }
    }, {
      name: "aria-colcount",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-colcount"
      }],
      description: {
        kind: "markdown",
        value: "Defines the total number of columns in a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-colindex`](https://www.w3.org/TR/wai-aria-1.1/#aria-colindex)."
      }
    }, {
      name: "aria-colindex",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-colindex"
      }],
      description: {
        kind: "markdown",
        value: "Defines an [element's](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) column index or position with respect to the total number of columns within a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-colcount`](https://www.w3.org/TR/wai-aria-1.1/#aria-colcount) and [`aria-colspan`](https://www.w3.org/TR/wai-aria-1.1/#aria-colspan)."
      }
    }, {
      name: "aria-colspan",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-colspan"
      }],
      description: {
        kind: "markdown",
        value: "Defines the number of columns spanned by a cell or gridcell within a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-colindex`](https://www.w3.org/TR/wai-aria-1.1/#aria-colindex) and [`aria-rowspan`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowspan)."
      }
    }, {
      name: "aria-controls",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-controls"
      }],
      description: {
        kind: "markdown",
        value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) whose contents or presence are controlled by the current element. See related [`aria-owns`](https://www.w3.org/TR/wai-aria-1.1/#aria-owns)."
      }
    }, {
      name: "aria-current",
      valueSet: "current",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-current"
      }],
      description: {
        kind: "markdown",
        value: "Indicates the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) that represents the current item within a container or set of related elements."
      }
    }, {
      name: "aria-describedby",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-describedby"
      }],
      description: {
        kind: "markdown",
        value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) that describes the [object](https://www.w3.org/TR/wai-aria-1.1/#dfn-object). See related [`aria-labelledby`](https://www.w3.org/TR/wai-aria-1.1/#aria-labelledby)."
      }
    }, {
      name: "aria-disabled",
      valueSet: "b",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-disabled"
      }],
      description: {
        kind: "markdown",
        value: "Indicates that the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) is [perceivable](https://www.w3.org/TR/wai-aria-1.1/#dfn-perceivable) but disabled, so it is not editable or otherwise [operable](https://www.w3.org/TR/wai-aria-1.1/#dfn-operable). See related [`aria-hidden`](https://www.w3.org/TR/wai-aria-1.1/#aria-hidden) and [`aria-readonly`](https://www.w3.org/TR/wai-aria-1.1/#aria-readonly)."
      }
    }, {
      name: "aria-dropeffect",
      valueSet: "dropeffect",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-dropeffect"
      }],
      description: {
        kind: "markdown",
        value: "\\[Deprecated in ARIA 1.1\\] Indicates what functions can be performed when a dragged object is released on the drop target."
      }
    }, {
      name: "aria-errormessage",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-errormessage"
      }],
      description: {
        kind: "markdown",
        value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) that provides an error message for the [object](https://www.w3.org/TR/wai-aria-1.1/#dfn-object). See related [`aria-invalid`](https://www.w3.org/TR/wai-aria-1.1/#aria-invalid) and [`aria-describedby`](https://www.w3.org/TR/wai-aria-1.1/#aria-describedby)."
      }
    }, {
      name: "aria-expanded",
      valueSet: "u",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-expanded"
      }],
      description: {
        kind: "markdown",
        value: "Indicates whether the element, or another grouping element it controls, is currently expanded or collapsed."
      }
    }, {
      name: "aria-flowto",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-flowto"
      }],
      description: {
        kind: "markdown",
        value: "Identifies the next [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) in an alternate reading order of content which, at the user's discretion, allows assistive technology to override the general default of reading in document source order."
      }
    }, {
      name: "aria-grabbed",
      valueSet: "u",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-grabbed"
      }],
      description: {
        kind: "markdown",
        value: `\\[Deprecated in ARIA 1.1\\] Indicates an element's "grabbed" [state](https://www.w3.org/TR/wai-aria-1.1/#dfn-state) in a drag-and-drop operation.`
      }
    }, {
      name: "aria-haspopup",
      valueSet: "haspopup",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-haspopup"
      }],
      description: {
        kind: "markdown",
        value: "Indicates the availability and type of interactive popup element, such as menu or dialog, that can be triggered by an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element)."
      }
    }, {
      name: "aria-hidden",
      valueSet: "b",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-hidden"
      }],
      description: {
        kind: "markdown",
        value: "Indicates whether the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) is exposed to an accessibility API. See related [`aria-disabled`](https://www.w3.org/TR/wai-aria-1.1/#aria-disabled)."
      }
    }, {
      name: "aria-invalid",
      valueSet: "invalid",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-invalid"
      }],
      description: {
        kind: "markdown",
        value: "Indicates the entered value does not conform to the format expected by the application. See related [`aria-errormessage`](https://www.w3.org/TR/wai-aria-1.1/#aria-errormessage)."
      }
    }, {
      name: "aria-label",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-label"
      }],
      description: {
        kind: "markdown",
        value: "Defines a string value that labels the current element. See related [`aria-labelledby`](https://www.w3.org/TR/wai-aria-1.1/#aria-labelledby)."
      }
    }, {
      name: "aria-labelledby",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-labelledby"
      }],
      description: {
        kind: "markdown",
        value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) that labels the current element. See related [`aria-describedby`](https://www.w3.org/TR/wai-aria-1.1/#aria-describedby)."
      }
    }, {
      name: "aria-level",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-level"
      }],
      description: {
        kind: "markdown",
        value: "Defines the hierarchical level of an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) within a structure."
      }
    }, {
      name: "aria-live",
      valueSet: "live",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-live"
      }],
      description: {
        kind: "markdown",
        value: "Indicates that an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) will be updated, and describes the types of updates the [user agents](https://www.w3.org/TR/wai-aria-1.1/#dfn-user-agent), [assistive technologies](https://www.w3.org/TR/wai-aria-1.1/#dfn-assistive-technology), and user can expect from the [live region](https://www.w3.org/TR/wai-aria-1.1/#dfn-live-region)."
      }
    }, {
      name: "aria-modal",
      valueSet: "b",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-modal"
      }],
      description: {
        kind: "markdown",
        value: "Indicates whether an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) is modal when displayed."
      }
    }, {
      name: "aria-multiline",
      valueSet: "b",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-multiline"
      }],
      description: {
        kind: "markdown",
        value: "Indicates whether a text box accepts multiple lines of input or only a single line."
      }
    }, {
      name: "aria-multiselectable",
      valueSet: "b",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-multiselectable"
      }],
      description: {
        kind: "markdown",
        value: "Indicates that the user may select more than one item from the current selectable descendants."
      }
    }, {
      name: "aria-orientation",
      valueSet: "orientation",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-orientation"
      }],
      description: {
        kind: "markdown",
        value: "Indicates whether the element's orientation is horizontal, vertical, or unknown/ambiguous."
      }
    }, {
      name: "aria-owns",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-owns"
      }],
      description: {
        kind: "markdown",
        value: "Identifies an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) in order to define a visual, functional, or contextual parent/child [relationship](https://www.w3.org/TR/wai-aria-1.1/#dfn-relationship) between DOM elements where the DOM hierarchy cannot be used to represent the relationship. See related [`aria-controls`](https://www.w3.org/TR/wai-aria-1.1/#aria-controls)."
      }
    }, {
      name: "aria-placeholder",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-placeholder"
      }],
      description: {
        kind: "markdown",
        value: "Defines a short hint (a word or short phrase) intended to aid the user with data entry when the control has no value. A hint could be a sample value or a brief description of the expected format."
      }
    }, {
      name: "aria-posinset",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-posinset"
      }],
      description: {
        kind: "markdown",
        value: "Defines an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element)'s number or position in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM. See related [`aria-setsize`](https://www.w3.org/TR/wai-aria-1.1/#aria-setsize)."
      }
    }, {
      name: "aria-pressed",
      valueSet: "tristate",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-pressed"
      }],
      description: {
        kind: "markdown",
        value: 'Indicates the current "pressed" [state](https://www.w3.org/TR/wai-aria-1.1/#dfn-state) of toggle buttons. See related [`aria-checked`](https://www.w3.org/TR/wai-aria-1.1/#aria-checked) and [`aria-selected`](https://www.w3.org/TR/wai-aria-1.1/#aria-selected).'
      }
    }, {
      name: "aria-readonly",
      valueSet: "b",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-readonly"
      }],
      description: {
        kind: "markdown",
        value: "Indicates that the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) is not editable, but is otherwise [operable](https://www.w3.org/TR/wai-aria-1.1/#dfn-operable). See related [`aria-disabled`](https://www.w3.org/TR/wai-aria-1.1/#aria-disabled)."
      }
    }, {
      name: "aria-relevant",
      valueSet: "relevant",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-relevant"
      }],
      description: {
        kind: "markdown",
        value: "Indicates what notifications the user agent will trigger when the accessibility tree within a live region is modified. See related [`aria-atomic`](https://www.w3.org/TR/wai-aria-1.1/#aria-atomic)."
      }
    }, {
      name: "aria-required",
      valueSet: "b",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-required"
      }],
      description: {
        kind: "markdown",
        value: "Indicates that user input is required on the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) before a form may be submitted."
      }
    }, {
      name: "aria-roledescription",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-roledescription"
      }],
      description: {
        kind: "markdown",
        value: "Defines a human-readable, author-localized description for the [role](https://www.w3.org/TR/wai-aria-1.1/#dfn-role) of an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element)."
      }
    }, {
      name: "aria-rowcount",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-rowcount"
      }],
      description: {
        kind: "markdown",
        value: "Defines the total number of rows in a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-rowindex`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowindex)."
      }
    }, {
      name: "aria-rowindex",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-rowindex"
      }],
      description: {
        kind: "markdown",
        value: "Defines an [element's](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) row index or position with respect to the total number of rows within a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-rowcount`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowcount) and [`aria-rowspan`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowspan)."
      }
    }, {
      name: "aria-rowspan",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-rowspan"
      }],
      description: {
        kind: "markdown",
        value: "Defines the number of rows spanned by a cell or gridcell within a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-rowindex`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowindex) and [`aria-colspan`](https://www.w3.org/TR/wai-aria-1.1/#aria-colspan)."
      }
    }, {
      name: "aria-selected",
      valueSet: "u",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-selected"
      }],
      description: {
        kind: "markdown",
        value: 'Indicates the current "selected" [state](https://www.w3.org/TR/wai-aria-1.1/#dfn-state) of various [widgets](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget). See related [`aria-checked`](https://www.w3.org/TR/wai-aria-1.1/#aria-checked) and [`aria-pressed`](https://www.w3.org/TR/wai-aria-1.1/#aria-pressed).'
      }
    }, {
      name: "aria-setsize",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-setsize"
      }],
      description: {
        kind: "markdown",
        value: "Defines the number of items in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM. See related [`aria-posinset`](https://www.w3.org/TR/wai-aria-1.1/#aria-posinset)."
      }
    }, {
      name: "aria-sort",
      valueSet: "sort",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-sort"
      }],
      description: {
        kind: "markdown",
        value: "Indicates if items in a table or grid are sorted in ascending or descending order."
      }
    }, {
      name: "aria-valuemax",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-valuemax"
      }],
      description: {
        kind: "markdown",
        value: "Defines the maximum allowed value for a range [widget](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget)."
      }
    }, {
      name: "aria-valuemin",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-valuemin"
      }],
      description: {
        kind: "markdown",
        value: "Defines the minimum allowed value for a range [widget](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget)."
      }
    }, {
      name: "aria-valuenow",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-valuenow"
      }],
      description: {
        kind: "markdown",
        value: "Defines the current value for a range [widget](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget). See related [`aria-valuetext`](https://www.w3.org/TR/wai-aria-1.1/#aria-valuetext)."
      }
    }, {
      name: "aria-valuetext",
      references: [{
        name: "WAI-ARIA Reference",
        url: "https://www.w3.org/TR/wai-aria-1.1/#aria-valuetext"
      }],
      description: {
        kind: "markdown",
        value: "Defines the human readable text alternative of [`aria-valuenow`](https://www.w3.org/TR/wai-aria-1.1/#aria-valuenow) for a range [widget](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget)."
      }
    }, {
      name: "aria-details",
      description: {
        kind: "markdown",
        value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) that provides a detailed, extended description for the [object](https://www.w3.org/TR/wai-aria-1.1/#dfn-object). See related [`aria-describedby`](https://www.w3.org/TR/wai-aria-1.1/#aria-describedby)."
      }
    }, {
      name: "aria-keyshortcuts",
      description: {
        kind: "markdown",
        value: "Indicates keyboard shortcuts that an author has implemented to activate or give focus to an element."
      }
    }],
    valueSets: [{
      name: "b",
      values: [{
        name: "true"
      }, {
        name: "false"
      }]
    }, {
      name: "u",
      values: [{
        name: "true"
      }, {
        name: "false"
      }, {
        name: "undefined"
      }]
    }, {
      name: "o",
      values: [{
        name: "on"
      }, {
        name: "off"
      }]
    }, {
      name: "y",
      values: [{
        name: "yes"
      }, {
        name: "no"
      }]
    }, {
      name: "w",
      values: [{
        name: "soft"
      }, {
        name: "hard"
      }]
    }, {
      name: "d",
      values: [{
        name: "ltr"
      }, {
        name: "rtl"
      }, {
        name: "auto"
      }]
    }, {
      name: "m",
      values: [{
        name: "get",
        description: {
          kind: "markdown",
          value: "Corresponds to the HTTP [GET method](https://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html#sec9.3); form data are appended to the `action` attribute URI with a '?' as separator, and the resulting URI is sent to the server. Use this method when the form has no side-effects and contains only ASCII characters."
        }
      }, {
        name: "post",
        description: {
          kind: "markdown",
          value: "Corresponds to the HTTP [POST method](https://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html#sec9.5); form data are included in the body of the form and sent to the server."
        }
      }, {
        name: "dialog",
        description: {
          kind: "markdown",
          value: "Use when the form is inside a [`<dialog>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog) element to close the dialog when submitted."
        }
      }]
    }, {
      name: "fm",
      values: [{
        name: "get"
      }, {
        name: "post"
      }]
    }, {
      name: "s",
      values: [{
        name: "row"
      }, {
        name: "col"
      }, {
        name: "rowgroup"
      }, {
        name: "colgroup"
      }]
    }, {
      name: "t",
      values: [{
        name: "hidden"
      }, {
        name: "text"
      }, {
        name: "search"
      }, {
        name: "tel"
      }, {
        name: "url"
      }, {
        name: "email"
      }, {
        name: "password"
      }, {
        name: "datetime"
      }, {
        name: "date"
      }, {
        name: "month"
      }, {
        name: "week"
      }, {
        name: "time"
      }, {
        name: "datetime-local"
      }, {
        name: "number"
      }, {
        name: "range"
      }, {
        name: "color"
      }, {
        name: "checkbox"
      }, {
        name: "radio"
      }, {
        name: "file"
      }, {
        name: "submit"
      }, {
        name: "image"
      }, {
        name: "reset"
      }, {
        name: "button"
      }]
    }, {
      name: "im",
      values: [{
        name: "verbatim"
      }, {
        name: "latin"
      }, {
        name: "latin-name"
      }, {
        name: "latin-prose"
      }, {
        name: "full-width-latin"
      }, {
        name: "kana"
      }, {
        name: "kana-name"
      }, {
        name: "katakana"
      }, {
        name: "numeric"
      }, {
        name: "tel"
      }, {
        name: "email"
      }, {
        name: "url"
      }]
    }, {
      name: "bt",
      values: [{
        name: "button"
      }, {
        name: "submit"
      }, {
        name: "reset"
      }, {
        name: "menu"
      }]
    }, {
      name: "lt",
      values: [{
        name: "1"
      }, {
        name: "a"
      }, {
        name: "A"
      }, {
        name: "i"
      }, {
        name: "I"
      }]
    }, {
      name: "mt",
      values: [{
        name: "context"
      }, {
        name: "toolbar"
      }]
    }, {
      name: "mit",
      values: [{
        name: "command"
      }, {
        name: "checkbox"
      }, {
        name: "radio"
      }]
    }, {
      name: "et",
      values: [{
        name: "application/x-www-form-urlencoded"
      }, {
        name: "multipart/form-data"
      }, {
        name: "text/plain"
      }]
    }, {
      name: "tk",
      values: [{
        name: "subtitles"
      }, {
        name: "captions"
      }, {
        name: "descriptions"
      }, {
        name: "chapters"
      }, {
        name: "metadata"
      }]
    }, {
      name: "pl",
      values: [{
        name: "none"
      }, {
        name: "metadata"
      }, {
        name: "auto"
      }]
    }, {
      name: "sh",
      values: [{
        name: "circle"
      }, {
        name: "default"
      }, {
        name: "poly"
      }, {
        name: "rect"
      }]
    }, {
      name: "xo",
      values: [{
        name: "anonymous"
      }, {
        name: "use-credentials"
      }]
    }, {
      name: "target",
      values: [{
        name: "_self"
      }, {
        name: "_blank"
      }, {
        name: "_parent"
      }, {
        name: "_top"
      }]
    }, {
      name: "sb",
      values: [{
        name: "allow-forms"
      }, {
        name: "allow-modals"
      }, {
        name: "allow-pointer-lock"
      }, {
        name: "allow-popups"
      }, {
        name: "allow-popups-to-escape-sandbox"
      }, {
        name: "allow-same-origin"
      }, {
        name: "allow-scripts"
      }, {
        name: "allow-top-navigation"
      }]
    }, {
      name: "tristate",
      values: [{
        name: "true"
      }, {
        name: "false"
      }, {
        name: "mixed"
      }, {
        name: "undefined"
      }]
    }, {
      name: "inputautocomplete",
      values: [{
        name: "additional-name"
      }, {
        name: "address-level1"
      }, {
        name: "address-level2"
      }, {
        name: "address-level3"
      }, {
        name: "address-level4"
      }, {
        name: "address-line1"
      }, {
        name: "address-line2"
      }, {
        name: "address-line3"
      }, {
        name: "bday"
      }, {
        name: "bday-year"
      }, {
        name: "bday-day"
      }, {
        name: "bday-month"
      }, {
        name: "billing"
      }, {
        name: "cc-additional-name"
      }, {
        name: "cc-csc"
      }, {
        name: "cc-exp"
      }, {
        name: "cc-exp-month"
      }, {
        name: "cc-exp-year"
      }, {
        name: "cc-family-name"
      }, {
        name: "cc-given-name"
      }, {
        name: "cc-name"
      }, {
        name: "cc-number"
      }, {
        name: "cc-type"
      }, {
        name: "country"
      }, {
        name: "country-name"
      }, {
        name: "current-password"
      }, {
        name: "email"
      }, {
        name: "family-name"
      }, {
        name: "fax"
      }, {
        name: "given-name"
      }, {
        name: "home"
      }, {
        name: "honorific-prefix"
      }, {
        name: "honorific-suffix"
      }, {
        name: "impp"
      }, {
        name: "language"
      }, {
        name: "mobile"
      }, {
        name: "name"
      }, {
        name: "new-password"
      }, {
        name: "nickname"
      }, {
        name: "off"
      }, {
        name: "on"
      }, {
        name: "organization"
      }, {
        name: "organization-title"
      }, {
        name: "pager"
      }, {
        name: "photo"
      }, {
        name: "postal-code"
      }, {
        name: "sex"
      }, {
        name: "shipping"
      }, {
        name: "street-address"
      }, {
        name: "tel-area-code"
      }, {
        name: "tel"
      }, {
        name: "tel-country-code"
      }, {
        name: "tel-extension"
      }, {
        name: "tel-local"
      }, {
        name: "tel-local-prefix"
      }, {
        name: "tel-local-suffix"
      }, {
        name: "tel-national"
      }, {
        name: "transaction-amount"
      }, {
        name: "transaction-currency"
      }, {
        name: "url"
      }, {
        name: "username"
      }, {
        name: "work"
      }]
    }, {
      name: "autocomplete",
      values: [{
        name: "inline"
      }, {
        name: "list"
      }, {
        name: "both"
      }, {
        name: "none"
      }]
    }, {
      name: "current",
      values: [{
        name: "page"
      }, {
        name: "step"
      }, {
        name: "location"
      }, {
        name: "date"
      }, {
        name: "time"
      }, {
        name: "true"
      }, {
        name: "false"
      }]
    }, {
      name: "dropeffect",
      values: [{
        name: "copy"
      }, {
        name: "move"
      }, {
        name: "link"
      }, {
        name: "execute"
      }, {
        name: "popup"
      }, {
        name: "none"
      }]
    }, {
      name: "invalid",
      values: [{
        name: "grammar"
      }, {
        name: "false"
      }, {
        name: "spelling"
      }, {
        name: "true"
      }]
    }, {
      name: "live",
      values: [{
        name: "off"
      }, {
        name: "polite"
      }, {
        name: "assertive"
      }]
    }, {
      name: "orientation",
      values: [{
        name: "vertical"
      }, {
        name: "horizontal"
      }, {
        name: "undefined"
      }]
    }, {
      name: "relevant",
      values: [{
        name: "additions"
      }, {
        name: "removals"
      }, {
        name: "text"
      }, {
        name: "all"
      }, {
        name: "additions text"
      }]
    }, {
      name: "sort",
      values: [{
        name: "ascending"
      }, {
        name: "descending"
      }, {
        name: "none"
      }, {
        name: "other"
      }]
    }, {
      name: "roles",
      values: [{
        name: "alert"
      }, {
        name: "alertdialog"
      }, {
        name: "button"
      }, {
        name: "checkbox"
      }, {
        name: "dialog"
      }, {
        name: "gridcell"
      }, {
        name: "link"
      }, {
        name: "log"
      }, {
        name: "marquee"
      }, {
        name: "menuitem"
      }, {
        name: "menuitemcheckbox"
      }, {
        name: "menuitemradio"
      }, {
        name: "option"
      }, {
        name: "progressbar"
      }, {
        name: "radio"
      }, {
        name: "scrollbar"
      }, {
        name: "searchbox"
      }, {
        name: "slider"
      }, {
        name: "spinbutton"
      }, {
        name: "status"
      }, {
        name: "switch"
      }, {
        name: "tab"
      }, {
        name: "tabpanel"
      }, {
        name: "textbox"
      }, {
        name: "timer"
      }, {
        name: "tooltip"
      }, {
        name: "treeitem"
      }, {
        name: "combobox"
      }, {
        name: "grid"
      }, {
        name: "listbox"
      }, {
        name: "menu"
      }, {
        name: "menubar"
      }, {
        name: "radiogroup"
      }, {
        name: "tablist"
      }, {
        name: "tree"
      }, {
        name: "treegrid"
      }, {
        name: "application"
      }, {
        name: "article"
      }, {
        name: "cell"
      }, {
        name: "columnheader"
      }, {
        name: "definition"
      }, {
        name: "directory"
      }, {
        name: "document"
      }, {
        name: "feed"
      }, {
        name: "figure"
      }, {
        name: "group"
      }, {
        name: "heading"
      }, {
        name: "img"
      }, {
        name: "list"
      }, {
        name: "listitem"
      }, {
        name: "math"
      }, {
        name: "none"
      }, {
        name: "note"
      }, {
        name: "presentation"
      }, {
        name: "region"
      }, {
        name: "row"
      }, {
        name: "rowgroup"
      }, {
        name: "rowheader"
      }, {
        name: "separator"
      }, {
        name: "table"
      }, {
        name: "term"
      }, {
        name: "text"
      }, {
        name: "toolbar"
      }, {
        name: "banner"
      }, {
        name: "complementary"
      }, {
        name: "contentinfo"
      }, {
        name: "form"
      }, {
        name: "main"
      }, {
        name: "navigation"
      }, {
        name: "region"
      }, {
        name: "search"
      }, {
        name: "doc-abstract"
      }, {
        name: "doc-acknowledgments"
      }, {
        name: "doc-afterword"
      }, {
        name: "doc-appendix"
      }, {
        name: "doc-backlink"
      }, {
        name: "doc-biblioentry"
      }, {
        name: "doc-bibliography"
      }, {
        name: "doc-biblioref"
      }, {
        name: "doc-chapter"
      }, {
        name: "doc-colophon"
      }, {
        name: "doc-conclusion"
      }, {
        name: "doc-cover"
      }, {
        name: "doc-credit"
      }, {
        name: "doc-credits"
      }, {
        name: "doc-dedication"
      }, {
        name: "doc-endnote"
      }, {
        name: "doc-endnotes"
      }, {
        name: "doc-epigraph"
      }, {
        name: "doc-epilogue"
      }, {
        name: "doc-errata"
      }, {
        name: "doc-example"
      }, {
        name: "doc-footnote"
      }, {
        name: "doc-foreword"
      }, {
        name: "doc-glossary"
      }, {
        name: "doc-glossref"
      }, {
        name: "doc-index"
      }, {
        name: "doc-introduction"
      }, {
        name: "doc-noteref"
      }, {
        name: "doc-notice"
      }, {
        name: "doc-pagebreak"
      }, {
        name: "doc-pagelist"
      }, {
        name: "doc-part"
      }, {
        name: "doc-preface"
      }, {
        name: "doc-prologue"
      }, {
        name: "doc-pullquote"
      }, {
        name: "doc-qna"
      }, {
        name: "doc-subtitle"
      }, {
        name: "doc-tip"
      }, {
        name: "doc-toc"
      }]
    }, {
      name: "metanames",
      values: [{
        name: "application-name"
      }, {
        name: "author"
      }, {
        name: "description"
      }, {
        name: "format-detection"
      }, {
        name: "generator"
      }, {
        name: "keywords"
      }, {
        name: "publisher"
      }, {
        name: "referrer"
      }, {
        name: "robots"
      }, {
        name: "theme-color"
      }, {
        name: "viewport"
      }]
    }, {
      name: "haspopup",
      values: [{
        name: "false",
        description: {
          kind: "markdown",
          value: "(default) Indicates the element does not have a popup."
        }
      }, {
        name: "true",
        description: {
          kind: "markdown",
          value: "Indicates the popup is a menu."
        }
      }, {
        name: "menu",
        description: {
          kind: "markdown",
          value: "Indicates the popup is a menu."
        }
      }, {
        name: "listbox",
        description: {
          kind: "markdown",
          value: "Indicates the popup is a listbox."
        }
      }, {
        name: "tree",
        description: {
          kind: "markdown",
          value: "Indicates the popup is a tree."
        }
      }, {
        name: "grid",
        description: {
          kind: "markdown",
          value: "Indicates the popup is a grid."
        }
      }, {
        name: "dialog",
        description: {
          kind: "markdown",
          value: "Indicates the popup is a dialog."
        }
      }]
    }, {
      name: "decoding",
      values: [{
        name: "sync"
      }, {
        name: "async"
      }, {
        name: "auto"
      }]
    }, {
      name: "loading",
      values: [{
        name: "eager",
        description: {
          kind: "markdown",
          value: "Loads the image immediately, regardless of whether or not the image is currently within the visible viewport (this is the default value)."
        }
      }, {
        name: "lazy",
        description: {
          kind: "markdown",
          value: "Defers loading the image until it reaches a calculated distance from the viewport, as defined by the browser. The intent is to avoid the network and storage bandwidth needed to handle the image until it's reasonably certain that it will be needed. This generally improves the performance of the content in most typical use cases."
        }
      }]
    }, {
      name: "referrerpolicy",
      values: [{
        name: "no-referrer"
      }, {
        name: "no-referrer-when-downgrade"
      }, {
        name: "origin"
      }, {
        name: "origin-when-cross-origin"
      }, {
        name: "same-origin"
      }, {
        name: "strict-origin"
      }, {
        name: "strict-origin-when-cross-origin"
      }, {
        name: "unsafe-url"
      }]
    }]
  };
  class ih {
    constructor(e) {
      this.dataProviders = [], this.setDataProviders(e.useDefaultDataProvider !== !1, e.customDataProviders || [])
    }
    setDataProviders(e, n) {
      this.dataProviders = [], e && this.dataProviders.push(new Ga("html5", nh)), this.dataProviders.push(...n)
    }
    getDataProviders() {
      return this.dataProviders
    }
    isVoidElement(e, n) {
      return !!e && hc(n, e.toLowerCase(), (i, r) => i.localeCompare(r)) >= 0
    }
    getVoidElements(e) {
      const n = Array.isArray(e) ? e : this.getDataProviders().filter(r => r.isApplicable(e)),
        i = [];
      return n.forEach(r => {
        r.provideTags().filter(s => s.void).forEach(s => i.push(s.name))
      }), i.sort()
    }
    isPathAttribute(e, n) {
      if (n === "src" || n === "href") return !0;
      const i = rh[e];
      return i ? typeof i == "string" ? i === n : i.indexOf(n) !== -1 : !1
    }
  }
  const rh = {
      a: "href",
      area: "href",
      body: "background",
      blockquote: "cite",
      del: "cite",
      form: "action",
      frame: ["src", "longdesc"],
      img: ["src", "longdesc"],
      ins: "cite",
      link: "href",
      object: "data",
      q: "cite",
      script: "src",
      audio: "src",
      button: "formaction",
      command: "icon",
      embed: "src",
      html: "manifest",
      input: ["src", "formaction"],
      source: "src",
      track: "src",
      video: ["src", "poster"]
    },
    sh = {};

  function ah(t = sh) {
    const e = new ih(t),
      n = new Mc(t, e),
      i = new Cc(t, e),
      r = new dc(e),
      s = new th(r),
      a = new eh(e),
      l = new Gc(e);
    return {
      setDataProviders: e.setDataProviders.bind(e),
      createScanner: be,
      parseHTMLDocument: r.parseDocument.bind(r),
      doComplete: i.doComplete.bind(i),
      doComplete2: i.doComplete2.bind(i),
      setCompletionParticipants: i.setCompletionParticipants.bind(i),
      doHover: n.doHover.bind(n),
      format: Uc,
      findDocumentHighlights: Xc,
      findDocumentLinks: l.findDocumentLinks.bind(l),
      findDocumentSymbols: Jc,
      findDocumentSymbols2: io,
      getFoldingRanges: a.getFoldingRanges.bind(a),
      getSelectionRanges: s.getSelectionRanges.bind(s),
      doQuoteComplete: i.doQuoteComplete.bind(i),
      doTagComplete: i.doTagComplete.bind(i),
      doRename: Yc,
      findMatchingTagPosition: Kc,
      findOnTypeRenameRanges: so,
      findLinkedEditingRanges: so
    }
  }

  function oh(t, e) {
    return new Ga(t, e)
  }
  class lh {
    constructor(e, n) {
      this._ctx = e, this._languageSettings = n.languageSettings, this._languageId = n.languageId;
      const i = this._languageSettings.data,
        r = i == null ? void 0 : i.useDefaultDataProvider,
        s = [];
      if (i != null && i.dataProviders)
        for (const a in i.dataProviders) s.push(oh(a, i.dataProviders[a]));
      this._languageService = ah({
        useDefaultDataProvider: r,
        customDataProviders: s
      })
    }
    async doComplete(e, n) {
      let i = this._getTextDocument(e);
      if (!i) return null;
      let r = this._languageService.parseHTMLDocument(i);
      return Promise.resolve(this._languageService.doComplete(i, n, r, this._languageSettings && this._languageSettings.suggest))
    }
    async format(e, n, i) {
      let r = this._getTextDocument(e);
      if (!r) return [];
      let s = {
          ...this._languageSettings.format,
          ...i
        },
        a = this._languageService.format(r, n, s);
      return Promise.resolve(a)
    }
    async doHover(e, n) {
      let i = this._getTextDocument(e);
      if (!i) return null;
      let r = this._languageService.parseHTMLDocument(i),
        s = this._languageService.doHover(i, n, r);
      return Promise.resolve(s)
    }
    async findDocumentHighlights(e, n) {
      let i = this._getTextDocument(e);
      if (!i) return [];
      let r = this._languageService.parseHTMLDocument(i),
        s = this._languageService.findDocumentHighlights(i, n, r);
      return Promise.resolve(s)
    }
    async findDocumentLinks(e) {
      let n = this._getTextDocument(e);
      if (!n) return [];
      let i = this._languageService.findDocumentLinks(n, null);
      return Promise.resolve(i)
    }
    async findDocumentSymbols(e) {
      let n = this._getTextDocument(e);
      if (!n) return [];
      let i = this._languageService.parseHTMLDocument(n),
        r = this._languageService.findDocumentSymbols(n, i);
      return Promise.resolve(r)
    }
    async getFoldingRanges(e, n) {
      let i = this._getTextDocument(e);
      if (!i) return [];
      let r = this._languageService.getFoldingRanges(i, n);
      return Promise.resolve(r)
    }
    async getSelectionRanges(e, n) {
      let i = this._getTextDocument(e);
      if (!i) return [];
      let r = this._languageService.getSelectionRanges(i, n);
      return Promise.resolve(r)
    }
    async doRename(e, n, i) {
      let r = this._getTextDocument(e);
      if (!r) return null;
      let s = this._languageService.parseHTMLDocument(r),
        a = this._languageService.doRename(r, n, i, s);
      return Promise.resolve(a)
    }
    _getTextDocument(e) {
      let n = this._ctx.getMirrorModels();
      for (let i of n)
        if (i.uri.toString() === e) return Ei.create(e, this._languageId, i.version, i.getValue());
      return null
    }
  }
  self.onmessage = () => {
    Qu((t, e) => new lh(t, e))
  }
})();