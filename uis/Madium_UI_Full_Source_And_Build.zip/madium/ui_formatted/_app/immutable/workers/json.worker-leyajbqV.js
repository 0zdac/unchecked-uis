var W1 = Object.defineProperty;
var H1 = (rt, Be, Ue) => Be in rt ? W1(rt, Be, {
  enumerable: !0,
  configurable: !0,
  writable: !0,
  value: Ue
}) : rt[Be] = Ue;
var nt = (rt, Be, Ue) => H1(rt, typeof Be != "symbol" ? Be + "" : Be, Ue);
(function() {
  "use strict";
  var jo, Wo, Ho, zo, me, J;
  class rt {
    constructor() {
      this.listeners = [], this.unexpectedErrorHandler = function(e) {
        setTimeout(() => {
          throw e.stack ? pt.isErrorNoTelemetry(e) ? new pt(e.message + `

` + e.stack) : new Error(e.message + `

` + e.stack) : e
        }, 0)
      }
    }
    emit(e) {
      this.listeners.forEach(n => {
        n(e)
      })
    }
    onUnexpectedError(e) {
      this.unexpectedErrorHandler(e), this.emit(e)
    }
    onUnexpectedExternalError(e) {
      this.unexpectedErrorHandler(e)
    }
  }
  const Be = new rt;

  function Ue(t) {
    Go(t) || Be.onUnexpectedError(t)
  }

  function Gn(t) {
    if (t instanceof Error) {
      const {
        name: e,
        message: n,
        cause: r
      } = t, i = t.stacktrace || t.stack;
      return {
        $isError: !0,
        name: e,
        message: n,
        stack: i,
        noTelemetry: pt.isErrorNoTelemetry(t),
        cause: r ? Gn(r) : void 0,
        code: t.code
      }
    }
    return t
  }
  const Jn = "Canceled";

  function Go(t) {
    return t instanceof li ? !0 : t instanceof Error && t.name === Jn && t.message === Jn
  }
  class li extends Error {
    constructor() {
      super(Jn), this.name = this.message
    }
  }
  class pt extends Error {
    constructor(e) {
      super(e), this.name = "CodeExpectedError"
    }
    static fromError(e) {
      if (e instanceof pt) return e;
      const n = new pt;
      return n.message = e.message, n.stack = e.stack, n
    }
    static isErrorNoTelemetry(e) {
      return e.name === "CodeExpectedError"
    }
  }
  class ue extends Error {
    constructor(e) {
      super(e || "An unexpected bug occurred."), Object.setPrototypeOf(this, ue.prototype)
    }
  }

  function Jo(t, e = "Unreachable") {
    throw new Error(e)
  }

  function Xo(t, e = "unexpected state") {
    if (!t) throw typeof e == "string" ? new ue(`Assertion Failed: ${e}`) : e
  }

  function hn(t) {
    if (!t()) {
      debugger;
      t(), Ue(new ue("Assertion Failed"))
    }
  }

  function ui(t, e) {
    let n = 0;
    for (; n < t.length - 1;) {
      const r = t[n],
        i = t[n + 1];
      if (!e(r, i)) return !1;
      n++
    }
    return !0
  }

  function Qo(t) {
    return typeof t == "string"
  }

  function Zo(t) {
    return !!t && typeof t[Symbol.iterator] == "function"
  }
  var mn;
  (function(t) {
    function e(v) {
      return !!v && typeof v == "object" && typeof v[Symbol.iterator] == "function"
    }
    t.is = e;
    const n = Object.freeze([]);

    function r() {
      return n
    }
    t.empty = r;

    function* i(v) {
      yield v
    }
    t.single = i;

    function s(v) {
      return e(v) ? v : i(v)
    }
    t.wrap = s;

    function a(v) {
      return v || n
    }
    t.from = a;

    function* o(v) {
      for (let k = v.length - 1; k >= 0; k--) yield v[k]
    }
    t.reverse = o;

    function u(v) {
      return !v || v[Symbol.iterator]().next().done === !0
    }
    t.isEmpty = u;

    function l(v) {
      return v[Symbol.iterator]().next().value
    }
    t.first = l;

    function h(v, k) {
      let M = 0;
      for (const V of v)
        if (k(V, M++)) return !0;
      return !1
    }
    t.some = h;

    function f(v, k) {
      let M = 0;
      for (const V of v)
        if (!k(V, M++)) return !1;
      return !0
    }
    t.every = f;

    function m(v, k) {
      for (const M of v)
        if (k(M)) return M
    }
    t.find = m;

    function* g(v, k) {
      for (const M of v) k(M) && (yield M)
    }
    t.filter = g;

    function* d(v, k) {
      let M = 0;
      for (const V of v) yield k(V, M++)
    }
    t.map = d;

    function* p(v, k) {
      let M = 0;
      for (const V of v) yield* k(V, M++)
    }
    t.flatMap = p;

    function* y(...v) {
      for (const k of v) Zo(k) ? yield* k: yield k
    }
    t.concat = y;

    function w(v, k, M) {
      let V = M;
      for (const T of v) V = k(V, T);
      return V
    }
    t.reduce = w;

    function N(v) {
      let k = 0;
      for (const M of v) k++;
      return k
    }
    t.length = N;

    function* b(v, k, M = v.length) {
      for (k < -v.length && (k = 0), k < 0 && (k += v.length), M < 0 ? M += v.length : M > v.length && (M = v.length); k < M; k++) yield v[k]
    }
    t.slice = b;

    function _(v, k = Number.POSITIVE_INFINITY) {
      const M = [];
      if (k === 0) return [M, v];
      const V = v[Symbol.iterator]();
      for (let T = 0; T < k; T++) {
        const x = V.next();
        if (x.done) return [M, t.empty()];
        M.push(x.value)
      }
      return [M, {
        [Symbol.iterator]() {
          return V
        }
      }]
    }
    t.consume = _;
    async function L(v) {
      const k = [];
      for await (const M of v) k.push(M);
      return k
    }
    t.asyncToArray = L;
    async function A(v) {
      let k = [];
      for await (const M of v) k = k.concat(M);
      return k
    }
    t.asyncToArrayFlat = A
  })(mn || (mn = {}));

  function z1(t, e) {}

  function ci(t) {
    if (mn.is(t)) {
      const e = [];
      for (const n of t)
        if (n) try {
          n.dispose()
        } catch (r) {
          e.push(r)
        }
      if (e.length === 1) throw e[0];
      if (e.length > 1) throw new AggregateError(e, "Encountered errors while disposing of store");
      return Array.isArray(t) ? [] : t
    } else if (t) return t.dispose(), t
  }

  function Yo(...t) {
    return dn(() => ci(t))
  }
  class Ko {
    constructor(e) {
      this._isDisposed = !1, this._fn = e
    }
    dispose() {
      if (!this._isDisposed) {
        if (!this._fn) throw new Error("Unbound disposable context: Need to use an arrow function to preserve the value of this");
        this._isDisposed = !0, this._fn()
      }
    }
  }

  function dn(t) {
    return new Ko(t)
  }
  const $n = class $n {
    constructor() {
      this._toDispose = new Set, this._isDisposed = !1
    }
    dispose() {
      this._isDisposed || (this._isDisposed = !0, this.clear())
    }
    get isDisposed() {
      return this._isDisposed
    }
    clear() {
      if (this._toDispose.size !== 0) try {
        ci(this._toDispose)
      } finally {
        this._toDispose.clear()
      }
    }
    add(e) {
      if (!e || e === it.None) return e;
      if (e === this) throw new Error("Cannot register a disposable on itself!");
      return this._isDisposed ? $n.DISABLE_DISPOSED_WARNING || console.warn(new Error("Trying to add a disposable to a DisposableStore that has already been disposed of. The added object will be leaked!").stack) : this._toDispose.add(e), e
    }
    delete(e) {
      if (e) {
        if (e === this) throw new Error("Cannot dispose a disposable on itself!");
        this._toDispose.delete(e), e.dispose()
      }
    }
  };
  $n.DISABLE_DISPOSED_WARNING = !1;
  let jt = $n;
  const ai = class ai {
    constructor() {
      this._store = new jt, this._store
    }
    dispose() {
      this._store.dispose()
    }
    _register(e) {
      if (e === this) throw new Error("Cannot register a disposable on itself!");
      return this._store.add(e)
    }
  };
  ai.None = Object.freeze({
    dispose() {}
  });
  let it = ai;
  const Ot = class Ot {
    constructor(e) {
      this.element = e, this.next = Ot.Undefined, this.prev = Ot.Undefined
    }
  };
  Ot.Undefined = new Ot(void 0);
  let Y = Ot;
  class el {
    constructor() {
      this._first = Y.Undefined, this._last = Y.Undefined, this._size = 0
    }
    get size() {
      return this._size
    }
    isEmpty() {
      return this._first === Y.Undefined
    }
    clear() {
      let e = this._first;
      for (; e !== Y.Undefined;) {
        const n = e.next;
        e.prev = Y.Undefined, e.next = Y.Undefined, e = n
      }
      this._first = Y.Undefined, this._last = Y.Undefined, this._size = 0
    }
    unshift(e) {
      return this._insert(e, !1)
    }
    push(e) {
      return this._insert(e, !0)
    }
    _insert(e, n) {
      const r = new Y(e);
      if (this._first === Y.Undefined) this._first = r, this._last = r;
      else if (n) {
        const s = this._last;
        this._last = r, r.prev = s, s.next = r
      } else {
        const s = this._first;
        this._first = r, r.next = s, s.prev = r
      }
      this._size += 1;
      let i = !1;
      return () => {
        i || (i = !0, this._remove(r))
      }
    }
    shift() {
      if (this._first !== Y.Undefined) {
        const e = this._first.element;
        return this._remove(this._first), e
      }
    }
    pop() {
      if (this._last !== Y.Undefined) {
        const e = this._last.element;
        return this._remove(this._last), e
      }
    }
    _remove(e) {
      if (e.prev !== Y.Undefined && e.next !== Y.Undefined) {
        const n = e.prev;
        n.next = e.next, e.next.prev = n
      } else e.prev === Y.Undefined && e.next === Y.Undefined ? (this._first = Y.Undefined, this._last = Y.Undefined) : e.next === Y.Undefined ? (this._last = this._last.prev, this._last.next = Y.Undefined) : e.prev === Y.Undefined && (this._first = this._first.next, this._first.prev = Y.Undefined);
      this._size -= 1
    }*[Symbol.iterator]() {
      let e = this._first;
      for (; e !== Y.Undefined;) yield e.element, e = e.next
    }
  }
  const tl = globalThis.performance.now.bind(globalThis.performance);
  class gn {
    static create(e) {
      return new gn(e)
    }
    constructor(e) {
      this._now = e === !1 ? Date.now : tl, this._startTime = this._now(), this._stopTime = -1
    }
    stop() {
      this._stopTime = this._now()
    }
    reset() {
      this._startTime = this._now(), this._stopTime = -1
    }
    elapsed() {
      return this._stopTime !== -1 ? this._stopTime - this._startTime : this._now() - this._startTime
    }
  }
  var Xn;
  (function(t) {
    t.None = () => it.None;

    function e(x, S) {
      return m(x, () => {}, 0, void 0, !0, void 0, S)
    }
    t.defer = e;

    function n(x) {
      return (S, C = null, I) => {
        let F = !1,
          D;
        return D = x(B => {
          if (!F) return D ? D.dispose() : F = !0, S.call(C, B)
        }, null, I), F && D.dispose(), D
      }
    }
    t.once = n;

    function r(x, S) {
      return t.once(t.filter(x, S))
    }
    t.onceIf = r;

    function i(x, S, C) {
      return h((I, F = null, D) => x(B => I.call(F, S(B)), null, D), C)
    }
    t.map = i;

    function s(x, S, C) {
      return h((I, F = null, D) => x(B => {
        S(B), I.call(F, B)
      }, null, D), C)
    }
    t.forEach = s;

    function a(x, S, C) {
      return h((I, F = null, D) => x(B => S(B) && I.call(F, B), null, D), C)
    }
    t.filter = a;

    function o(x) {
      return x
    }
    t.signal = o;

    function u(...x) {
      return (S, C = null, I) => {
        const F = Yo(...x.map(D => D(B => S.call(C, B))));
        return f(F, I)
      }
    }
    t.any = u;

    function l(x, S, C, I) {
      let F = C;
      return i(x, D => (F = S(F, D), F), I)
    }
    t.reduce = l;

    function h(x, S) {
      let C;
      const I = {
          onWillAddFirstListener() {
            C = x(F.fire, F)
          },
          onDidRemoveLastListener() {
            C == null || C.dispose()
          }
        },
        F = new Ce(I);
      return S == null || S.add(F), F.event
    }

    function f(x, S) {
      return S instanceof Array ? S.push(x) : S && S.add(x), x
    }

    function m(x, S, C = 100, I = !1, F = !1, D, B) {
      let X, z, Ae, Wn = 0,
        dt;
      const U1 = {
          leakWarningThreshold: D,
          onWillAddFirstListener() {
            X = x(q1 => {
              Wn++, z = S(z, q1), I && !Ae && (Hn.fire(z), z = void 0), dt = () => {
                const j1 = z;
                z = void 0, Ae = void 0, (!I || Wn > 1) && Hn.fire(j1), Wn = 0
              }, typeof C == "number" ? (Ae && clearTimeout(Ae), Ae = setTimeout(dt, C)) : Ae === void 0 && (Ae = null, queueMicrotask(dt))
            })
          },
          onWillRemoveListener() {
            F && Wn > 0 && (dt == null || dt())
          },
          onDidRemoveLastListener() {
            dt = void 0, X.dispose()
          }
        },
        Hn = new Ce(U1);
      return B == null || B.add(Hn), Hn.event
    }
    t.debounce = m;

    function g(x, S = 0, C) {
      return t.debounce(x, (I, F) => I ? (I.push(F), I) : [F], S, void 0, !0, void 0, C)
    }
    t.accumulate = g;

    function d(x, S = (I, F) => I === F, C) {
      let I = !0,
        F;
      return a(x, D => {
        const B = I || !S(D, F);
        return I = !1, F = D, B
      }, C)
    }
    t.latch = d;

    function p(x, S, C) {
      return [t.filter(x, S, C), t.filter(x, I => !S(I), C)]
    }
    t.split = p;

    function y(x, S = !1, C = [], I) {
      let F = C.slice(),
        D = x(z => {
          F ? F.push(z) : X.fire(z)
        });
      I && I.add(D);
      const B = () => {
          F == null || F.forEach(z => X.fire(z)), F = null
        },
        X = new Ce({
          onWillAddFirstListener() {
            D || (D = x(z => X.fire(z)), I && I.add(D))
          },
          onDidAddFirstListener() {
            F && (S ? setTimeout(B) : B())
          },
          onDidRemoveLastListener() {
            D && D.dispose(), D = null
          }
        });
      return I && I.add(X), X.event
    }
    t.buffer = y;

    function w(x, S) {
      return (I, F, D) => {
        const B = S(new b);
        return x(function(X) {
          const z = B.evaluate(X);
          z !== N && I.call(F, z)
        }, void 0, D)
      }
    }
    t.chain = w;
    const N = Symbol("HaltChainable");
    class b {
      constructor() {
        this.steps = []
      }
      map(S) {
        return this.steps.push(S), this
      }
      forEach(S) {
        return this.steps.push(C => (S(C), C)), this
      }
      filter(S) {
        return this.steps.push(C => S(C) ? C : N), this
      }
      reduce(S, C) {
        let I = C;
        return this.steps.push(F => (I = S(I, F), I)), this
      }
      latch(S = (C, I) => C === I) {
        let C = !0,
          I;
        return this.steps.push(F => {
          const D = C || !S(F, I);
          return C = !1, I = F, D ? F : N
        }), this
      }
      evaluate(S) {
        for (const C of this.steps)
          if (S = C(S), S === N) break;
        return S
      }
    }

    function _(x, S, C = I => I) {
      const I = (...X) => B.fire(C(...X)),
        F = () => x.on(S, I),
        D = () => x.removeListener(S, I),
        B = new Ce({
          onWillAddFirstListener: F,
          onDidRemoveLastListener: D
        });
      return B.event
    }
    t.fromNodeEventEmitter = _;

    function L(x, S, C = I => I) {
      const I = (...X) => B.fire(C(...X)),
        F = () => x.addEventListener(S, I),
        D = () => x.removeEventListener(S, I),
        B = new Ce({
          onWillAddFirstListener: F,
          onDidRemoveLastListener: D
        });
      return B.event
    }
    t.fromDOMEventEmitter = L;

    function A(x, S) {
      let C;
      const I = new Promise((F, D) => {
        const B = n(x)(F, null, S);
        C = () => B.dispose()
      });
      return I.cancel = C, I
    }
    t.toPromise = A;

    function v(x, S) {
      return x(C => S.fire(C))
    }
    t.forward = v;

    function k(x, S, C) {
      return S(C), x(I => S(I))
    }
    t.runAndSubscribe = k;
    class M {
      constructor(S, C) {
        this._observable = S, this._counter = 0, this._hasChanged = !1;
        const I = {
          onWillAddFirstListener: () => {
            S.addObserver(this), this._observable.reportChanges()
          },
          onDidRemoveLastListener: () => {
            S.removeObserver(this)
          }
        };
        this.emitter = new Ce(I), C && C.add(this.emitter)
      }
      beginUpdate(S) {
        this._counter++
      }
      handlePossibleChange(S) {}
      handleChange(S, C) {
        this._hasChanged = !0
      }
      endUpdate(S) {
        this._counter--, this._counter === 0 && (this._observable.reportChanges(), this._hasChanged && (this._hasChanged = !1, this.emitter.fire(this._observable.get())))
      }
    }

    function V(x, S) {
      return new M(x, S).emitter.event
    }
    t.fromObservable = V;

    function T(x) {
      return (S, C, I) => {
        let F = 0,
          D = !1;
        const B = {
          beginUpdate() {
            F++
          },
          endUpdate() {
            F--, F === 0 && (x.reportChanges(), D && (D = !1, S.call(C)))
          },
          handlePossibleChange() {},
          handleChange() {
            D = !0
          }
        };
        x.addObserver(B), x.reportChanges();
        const X = {
          dispose() {
            x.removeObserver(B)
          }
        };
        return I instanceof jt ? I.add(X) : Array.isArray(I) && I.push(X), X
      }
    }
    t.fromObservableLight = T
  })(Xn || (Xn = {}));
  const $t = class $t {
    constructor(e) {
      this.listenerCount = 0, this.invocationCount = 0, this.elapsedOverall = 0, this.durations = [], this.name = `${e}_${$t._idPool++}`, $t.all.add(this)
    }
    start(e) {
      this._stopWatch = new gn, this.listenerCount = e
    }
    stop() {
      if (this._stopWatch) {
        const e = this._stopWatch.elapsed();
        this.durations.push(e), this.elapsedOverall += e, this.invocationCount += 1, this._stopWatch = void 0
      }
    }
  };
  $t.all = new Set, $t._idPool = 0;
  let Qn = $t,
    nl = -1;
  const Bn = class Bn {
    constructor(e, n, r = (Bn._idPool++).toString(16).padStart(3, "0")) {
      this._errorHandler = e, this.threshold = n, this.name = r, this._warnCountdown = 0
    }
    dispose() {
      var e;
      (e = this._stacks) == null || e.clear()
    }
    check(e, n) {
      const r = this.threshold;
      if (r <= 0 || n < r) return;
      this._stacks || (this._stacks = new Map);
      const i = this._stacks.get(e.value) || 0;
      if (this._stacks.set(e.value, i + 1), this._warnCountdown -= 1, this._warnCountdown <= 0) {
        this._warnCountdown = r * .5;
        const [s, a] = this.getMostFrequentStack(), o = `[${this.name}] potential listener LEAK detected, having ${n} listeners already. MOST frequent listener (${a}):`;
        console.warn(o), console.warn(s);
        const u = new rl(o, s);
        this._errorHandler(u)
      }
      return () => {
        const s = this._stacks.get(e.value) || 0;
        this._stacks.set(e.value, s - 1)
      }
    }
    getMostFrequentStack() {
      if (!this._stacks) return;
      let e, n = 0;
      for (const [r, i] of this._stacks)(!e || n < i) && (e = [r, i], n = i);
      return e
    }
  };
  Bn._idPool = 1;
  let Zn = Bn;
  class Yn {
    static create() {
      const e = new Error;
      return new Yn(e.stack ?? "")
    }
    constructor(e) {
      this.value = e
    }
    print() {
      console.warn(this.value.split(`
`).slice(2).join(`
`))
    }
  }
  class rl extends Error {
    constructor(e, n) {
      super(e), this.name = "ListenerLeakError", this.stack = n
    }
  }
  class il extends Error {
    constructor(e, n) {
      super(e), this.name = "ListenerRefusalError", this.stack = n
    }
  }
  class Kn {
    constructor(e) {
      this.value = e
    }
  }
  const sl = 2;
  class Ce {
    constructor(e) {
      var n, r, i, s;
      this._size = 0, this._options = e, this._leakageMon = (n = this._options) != null && n.leakWarningThreshold ? new Zn((e == null ? void 0 : e.onListenerError) ?? Ue, ((r = this._options) == null ? void 0 : r.leakWarningThreshold) ?? nl) : void 0, this._perfMon = (i = this._options) != null && i._profName ? new Qn(this._options._profName) : void 0, this._deliveryQueue = (s = this._options) == null ? void 0 : s.deliveryQueue
    }
    dispose() {
      var e, n, r, i;
      this._disposed || (this._disposed = !0, ((e = this._deliveryQueue) == null ? void 0 : e.current) === this && this._deliveryQueue.reset(), this._listeners && (this._listeners = void 0, this._size = 0), (r = (n = this._options) == null ? void 0 : n.onDidRemoveLastListener) == null || r.call(n), (i = this._leakageMon) == null || i.dispose())
    }
    get event() {
      return this._event ?? (this._event = (e, n, r) => {
        var o, u, l, h, f, m, g;
        if (this._leakageMon && this._size > this._leakageMon.threshold ** 2) {
          const d = `[${this._leakageMon.name}] REFUSES to accept new listeners because it exceeded its threshold by far (${this._size} vs ${this._leakageMon.threshold})`;
          console.warn(d);
          const p = this._leakageMon.getMostFrequentStack() ?? ["UNKNOWN stack", -1],
            y = new il(`${d}. HINT: Stack shows most frequent listener (${p[1]}-times)`, p[0]);
          return (((o = this._options) == null ? void 0 : o.onListenerError) || Ue)(y), it.None
        }
        if (this._disposed) return it.None;
        n && (e = e.bind(n));
        const i = new Kn(e);
        let s;
        this._leakageMon && this._size >= Math.ceil(this._leakageMon.threshold * .2) && (i.stack = Yn.create(), s = this._leakageMon.check(i.stack, this._size + 1)), this._listeners ? this._listeners instanceof Kn ? (this._deliveryQueue ?? (this._deliveryQueue = new al), this._listeners = [this._listeners, i]) : this._listeners.push(i) : ((l = (u = this._options) == null ? void 0 : u.onWillAddFirstListener) == null || l.call(u, this), this._listeners = i, (f = (h = this._options) == null ? void 0 : h.onDidAddFirstListener) == null || f.call(h, this)), (g = (m = this._options) == null ? void 0 : m.onDidAddListener) == null || g.call(m, this), this._size++;
        const a = dn(() => {
          s == null || s(), this._removeListener(i)
        });
        return r instanceof jt ? r.add(a) : Array.isArray(r) && r.push(a), a
      }), this._event
    }
    _removeListener(e) {
      var s, a, o, u;
      if ((a = (s = this._options) == null ? void 0 : s.onWillRemoveListener) == null || a.call(s, this), !this._listeners) return;
      if (this._size === 1) {
        this._listeners = void 0, (u = (o = this._options) == null ? void 0 : o.onDidRemoveLastListener) == null || u.call(o, this), this._size = 0;
        return
      }
      const n = this._listeners,
        r = n.indexOf(e);
      if (r === -1) throw console.log("disposed?", this._disposed), console.log("size?", this._size), console.log("arr?", JSON.stringify(this._listeners)), new Error("Attempted to dispose unknown listener");
      this._size--, n[r] = void 0;
      const i = this._deliveryQueue.current === this;
      if (this._size * sl <= n.length) {
        let l = 0;
        for (let h = 0; h < n.length; h++) n[h] ? n[l++] = n[h] : i && l < this._deliveryQueue.end && (this._deliveryQueue.end--, l < this._deliveryQueue.i && this._deliveryQueue.i--);
        n.length = l
      }
    }
    _deliver(e, n) {
      var i;
      if (!e) return;
      const r = ((i = this._options) == null ? void 0 : i.onListenerError) || Ue;
      if (!r) {
        e.value(n);
        return
      }
      try {
        e.value(n)
      } catch (s) {
        r(s)
      }
    }
    _deliverQueue(e) {
      const n = e.current._listeners;
      for (; e.i < e.end;) this._deliver(n[e.i++], e.value);
      e.reset()
    }
    fire(e) {
      var n, r, i, s;
      if ((n = this._deliveryQueue) != null && n.current && (this._deliverQueue(this._deliveryQueue), (r = this._perfMon) == null || r.stop()), (i = this._perfMon) == null || i.start(this._size), this._listeners)
        if (this._listeners instanceof Kn) this._deliver(this._listeners, e);
        else {
          const a = this._deliveryQueue;
          a.enqueue(this, e, this._listeners.length), this._deliverQueue(a)
        }(s = this._perfMon) == null || s.stop()
    }
    hasListeners() {
      return this._size > 0
    }
  }
  class al {
    constructor() {
      this.i = -1, this.end = 0
    }
    enqueue(e, n, r) {
      this.i = 0, this.end = r, this.current = e, this.value = n
    }
    reset() {
      this.i = this.end, this.current = void 0, this.value = void 0
    }
  }

  function ol() {
    return globalThis._VSCODE_NLS_MESSAGES
  }

  function fi() {
    return globalThis._VSCODE_NLS_LANGUAGE
  }
  const ll = fi() === "pseudo" || typeof document < "u" && document.location && typeof document.location.hash == "string" && document.location.hash.indexOf("pseudo=true") >= 0;

  function hi(t, e) {
    let n;
    return e.length === 0 ? n = t : n = t.replace(/\{(\d+)\}/g, (r, i) => {
      const s = i[0],
        a = e[s];
      let o = r;
      return typeof a == "string" ? o = a : (typeof a == "number" || typeof a == "boolean" || a === void 0 || a === null) && (o = String(a)), o
    }), ll && (n = "［" + n.replace(/[aouei]/g, "$&$&") + "］"), n
  }

  function $(t, e, ...n) {
    return hi(typeof t == "number" ? ul(t, e) : e, n)
  }

  function ul(t, e) {
    var r;
    const n = (r = ol()) == null ? void 0 : r[t];
    if (typeof n != "string") {
      if (typeof e == "string") return e;
      throw new Error(`!!! NLS MISSING: ${t} !!!`)
    }
    return n
  }
  const bt = "en";
  let er = !1,
    tr = !1,
    nr = !1,
    pn, rr = bt,
    mi = bt,
    cl, ke;
  const st = globalThis;
  let ae;
  typeof st.vscode < "u" && typeof st.vscode.process < "u" ? ae = st.vscode.process : typeof process < "u" && typeof((jo = process == null ? void 0 : process.versions) == null ? void 0 : jo.node) == "string" && (ae = process);
  const fl = typeof((Wo = ae == null ? void 0 : ae.versions) == null ? void 0 : Wo.electron) == "string" && (ae == null ? void 0 : ae.type) === "renderer";
  if (typeof ae == "object") {
    er = ae.platform === "win32", tr = ae.platform === "darwin", nr = ae.platform === "linux", nr && ae.env.SNAP && ae.env.SNAP_REVISION, ae.env.CI || ae.env.BUILD_ARTIFACTSTAGINGDIRECTORY || ae.env.GITHUB_WORKSPACE, pn = bt, rr = bt;
    const t = ae.env.VSCODE_NLS_CONFIG;
    if (t) try {
      const e = JSON.parse(t);
      pn = e.userLocale, mi = e.osLocale, rr = e.resolvedLanguage || bt, cl = (Ho = e.languagePack) == null ? void 0 : Ho.translationsConfigFile
    } catch {}
  } else typeof navigator == "object" && !fl ? (ke = navigator.userAgent, er = ke.indexOf("Windows") >= 0, tr = ke.indexOf("Macintosh") >= 0, (ke.indexOf("Macintosh") >= 0 || ke.indexOf("iPad") >= 0 || ke.indexOf("iPhone") >= 0) && navigator.maxTouchPoints && navigator.maxTouchPoints > 0, nr = ke.indexOf("Linux") >= 0, (ke == null ? void 0 : ke.indexOf("Mobi")) >= 0, rr = fi() || bt, pn = navigator.language.toLowerCase(), mi = pn) : console.error("Unable to resolve platform.");
  const Wt = er,
    hl = tr,
    Ie = ke,
    ml = typeof st.postMessage == "function" && !st.importScripts;
  (() => {
    if (ml) {
      const t = [];
      st.addEventListener("message", n => {
        if (n.data && n.data.vscodeScheduleAsyncWork)
          for (let r = 0, i = t.length; r < i; r++) {
            const s = t[r];
            if (s.id === n.data.vscodeScheduleAsyncWork) {
              t.splice(r, 1), s.callback();
              return
            }
          }
      });
      let e = 0;
      return n => {
        const r = ++e;
        t.push({
          id: r,
          callback: n
        }), st.postMessage({
          vscodeScheduleAsyncWork: r
        }, "*")
      }
    }
    return t => setTimeout(t)
  })();
  const dl = !!(Ie && Ie.indexOf("Chrome") >= 0);
  Ie && Ie.indexOf("Firefox") >= 0, !dl && Ie && Ie.indexOf("Safari") >= 0, Ie && Ie.indexOf("Edg/") >= 0, Ie && Ie.indexOf("Android") >= 0;

  function gl(t) {
    return t
  }
  class pl {
    constructor(e, n) {
      this.lastCache = void 0, this.lastArgKey = void 0, typeof e == "function" ? (this._fn = e, this._computeKey = gl) : (this._fn = n, this._computeKey = e.getCacheKey)
    }
    get(e) {
      const n = this._computeKey(e);
      return this.lastArgKey !== n && (this.lastArgKey = n, this.lastCache = this._fn(e)), this.lastCache
    }
  }
  var at;
  (function(t) {
    t[t.Uninitialized = 0] = "Uninitialized", t[t.Running = 1] = "Running", t[t.Completed = 2] = "Completed"
  })(at || (at = {}));
  class ir {
    constructor(e) {
      this.executor = e, this._state = at.Uninitialized
    }
    get value() {
      if (this._state === at.Uninitialized) {
        this._state = at.Running;
        try {
          this._value = this.executor()
        } catch (e) {
          this._error = e
        } finally {
          this._state = at.Completed
        }
      } else if (this._state === at.Running) throw new Error("Cannot read the value of a lazy that is being initialized");
      if (this._error) throw this._error;
      return this._value
    }
    get rawValue() {
      return this._value
    }
  }

  function bl(t) {
    return t.replace(/[\\\{\}\*\+\?\|\^\$\.\[\]\(\)]/g, "\\$&")
  }

  function yl(t) {
    return t.source === "^" || t.source === "^$" || t.source === "$" || t.source === "^\\s*$" ? !1 : !!(t.exec("") && t.lastIndex === 0)
  }

  function wl(t) {
    return t.split(/\r\n|\r|\n/)
  }

  function xl(t) {
    for (let e = 0, n = t.length; e < n; e++) {
      const r = t.charCodeAt(e);
      if (r !== 32 && r !== 9) return e
    }
    return -1
  }

  function vl(t, e = t.length - 1) {
    for (let n = e; n >= 0; n--) {
      const r = t.charCodeAt(n);
      if (r !== 32 && r !== 9) return n
    }
    return -1
  }

  function di(t) {
    return t >= 65 && t <= 90
  }

  function Ll(t, e) {
    const n = Math.min(t.length, e.length);
    let r;
    for (r = 0; r < n; r++)
      if (t.charCodeAt(r) !== e.charCodeAt(r)) return r;
    return n
  }

  function Nl(t, e) {
    const n = Math.min(t.length, e.length);
    let r;
    const i = t.length - 1,
      s = e.length - 1;
    for (r = 0; r < n; r++)
      if (t.charCodeAt(i - r) !== e.charCodeAt(s - r)) return r;
    return n
  }

  function sr(t) {
    return 55296 <= t && t <= 56319
  }

  function _l(t) {
    return 56320 <= t && t <= 57343
  }

  function Sl(t, e) {
    return (t - 55296 << 10) + (e - 56320) + 65536
  }

  function Al(t, e, n) {
    const r = t.charCodeAt(n);
    if (sr(r) && n + 1 < e) {
      const i = t.charCodeAt(n + 1);
      if (_l(i)) return Sl(r, i)
    }
    return r
  }
  const kl = /^[\t\n\r\x20-\x7E]*$/;

  function Rl(t) {
    return kl.test(t)
  }
  const $e = class $e {
    static getInstance(e) {
      return $e.cache.get(Array.from(e))
    }
    static getLocales() {
      return $e._locales.value
    }
    constructor(e) {
      this.confusableDictionary = e
    }
    isAmbiguous(e) {
      return this.confusableDictionary.has(e)
    }
    getPrimaryConfusable(e) {
      return this.confusableDictionary.get(e)
    }
    getConfusableCodePoints() {
      return new Set(this.confusableDictionary.keys())
    }
  };
  $e.ambiguousCharacterData = new ir(() => JSON.parse('{"_common":[8232,32,8233,32,5760,32,8192,32,8193,32,8194,32,8195,32,8196,32,8197,32,8198,32,8200,32,8201,32,8202,32,8287,32,8199,32,8239,32,2042,95,65101,95,65102,95,65103,95,8208,45,8209,45,8210,45,65112,45,1748,45,8259,45,727,45,8722,45,10134,45,11450,45,1549,44,1643,44,184,44,42233,44,894,59,2307,58,2691,58,1417,58,1795,58,1796,58,5868,58,65072,58,6147,58,6153,58,8282,58,1475,58,760,58,42889,58,8758,58,720,58,42237,58,451,33,11601,33,660,63,577,63,2429,63,5038,63,42731,63,119149,46,8228,46,1793,46,1794,46,42510,46,68176,46,1632,46,1776,46,42232,46,1373,96,65287,96,8219,96,1523,96,8242,96,1370,96,8175,96,65344,96,900,96,8189,96,8125,96,8127,96,8190,96,697,96,884,96,712,96,714,96,715,96,756,96,699,96,701,96,700,96,702,96,42892,96,1497,96,2036,96,2037,96,5194,96,5836,96,94033,96,94034,96,65339,91,10088,40,10098,40,12308,40,64830,40,65341,93,10089,41,10099,41,12309,41,64831,41,10100,123,119060,123,10101,125,65342,94,8270,42,1645,42,8727,42,66335,42,5941,47,8257,47,8725,47,8260,47,9585,47,10187,47,10744,47,119354,47,12755,47,12339,47,11462,47,20031,47,12035,47,65340,92,65128,92,8726,92,10189,92,10741,92,10745,92,119311,92,119355,92,12756,92,20022,92,12034,92,42872,38,708,94,710,94,5869,43,10133,43,66203,43,8249,60,10094,60,706,60,119350,60,5176,60,5810,60,5120,61,11840,61,12448,61,42239,61,8250,62,10095,62,707,62,119351,62,5171,62,94015,62,8275,126,732,126,8128,126,8764,126,65372,124,65293,45,118002,50,120784,50,120794,50,120804,50,120814,50,120824,50,130034,50,42842,50,423,50,1000,50,42564,50,5311,50,42735,50,119302,51,118003,51,120785,51,120795,51,120805,51,120815,51,120825,51,130035,51,42923,51,540,51,439,51,42858,51,11468,51,1248,51,94011,51,71882,51,118004,52,120786,52,120796,52,120806,52,120816,52,120826,52,130036,52,5070,52,71855,52,118005,53,120787,53,120797,53,120807,53,120817,53,120827,53,130037,53,444,53,71867,53,118006,54,120788,54,120798,54,120808,54,120818,54,120828,54,130038,54,11474,54,5102,54,71893,54,119314,55,118007,55,120789,55,120799,55,120809,55,120819,55,120829,55,130039,55,66770,55,71878,55,2819,56,2538,56,2666,56,125131,56,118008,56,120790,56,120800,56,120810,56,120820,56,120830,56,130040,56,547,56,546,56,66330,56,2663,57,2920,57,2541,57,3437,57,118009,57,120791,57,120801,57,120811,57,120821,57,120831,57,130041,57,42862,57,11466,57,71884,57,71852,57,71894,57,9082,97,65345,97,119834,97,119886,97,119938,97,119990,97,120042,97,120094,97,120146,97,120198,97,120250,97,120302,97,120354,97,120406,97,120458,97,593,97,945,97,120514,97,120572,97,120630,97,120688,97,120746,97,65313,65,117974,65,119808,65,119860,65,119912,65,119964,65,120016,65,120068,65,120120,65,120172,65,120224,65,120276,65,120328,65,120380,65,120432,65,913,65,120488,65,120546,65,120604,65,120662,65,120720,65,5034,65,5573,65,42222,65,94016,65,66208,65,119835,98,119887,98,119939,98,119991,98,120043,98,120095,98,120147,98,120199,98,120251,98,120303,98,120355,98,120407,98,120459,98,388,98,5071,98,5234,98,5551,98,65314,66,8492,66,117975,66,119809,66,119861,66,119913,66,120017,66,120069,66,120121,66,120173,66,120225,66,120277,66,120329,66,120381,66,120433,66,42932,66,914,66,120489,66,120547,66,120605,66,120663,66,120721,66,5108,66,5623,66,42192,66,66178,66,66209,66,66305,66,65347,99,8573,99,119836,99,119888,99,119940,99,119992,99,120044,99,120096,99,120148,99,120200,99,120252,99,120304,99,120356,99,120408,99,120460,99,7428,99,1010,99,11429,99,43951,99,66621,99,128844,67,71913,67,71922,67,65315,67,8557,67,8450,67,8493,67,117976,67,119810,67,119862,67,119914,67,119966,67,120018,67,120174,67,120226,67,120278,67,120330,67,120382,67,120434,67,1017,67,11428,67,5087,67,42202,67,66210,67,66306,67,66581,67,66844,67,8574,100,8518,100,119837,100,119889,100,119941,100,119993,100,120045,100,120097,100,120149,100,120201,100,120253,100,120305,100,120357,100,120409,100,120461,100,1281,100,5095,100,5231,100,42194,100,8558,68,8517,68,117977,68,119811,68,119863,68,119915,68,119967,68,120019,68,120071,68,120123,68,120175,68,120227,68,120279,68,120331,68,120383,68,120435,68,5024,68,5598,68,5610,68,42195,68,8494,101,65349,101,8495,101,8519,101,119838,101,119890,101,119942,101,120046,101,120098,101,120150,101,120202,101,120254,101,120306,101,120358,101,120410,101,120462,101,43826,101,1213,101,8959,69,65317,69,8496,69,117978,69,119812,69,119864,69,119916,69,120020,69,120072,69,120124,69,120176,69,120228,69,120280,69,120332,69,120384,69,120436,69,917,69,120492,69,120550,69,120608,69,120666,69,120724,69,11577,69,5036,69,42224,69,71846,69,71854,69,66182,69,119839,102,119891,102,119943,102,119995,102,120047,102,120099,102,120151,102,120203,102,120255,102,120307,102,120359,102,120411,102,120463,102,43829,102,42905,102,383,102,7837,102,1412,102,119315,70,8497,70,117979,70,119813,70,119865,70,119917,70,120021,70,120073,70,120125,70,120177,70,120229,70,120281,70,120333,70,120385,70,120437,70,42904,70,988,70,120778,70,5556,70,42205,70,71874,70,71842,70,66183,70,66213,70,66853,70,65351,103,8458,103,119840,103,119892,103,119944,103,120048,103,120100,103,120152,103,120204,103,120256,103,120308,103,120360,103,120412,103,120464,103,609,103,7555,103,397,103,1409,103,117980,71,119814,71,119866,71,119918,71,119970,71,120022,71,120074,71,120126,71,120178,71,120230,71,120282,71,120334,71,120386,71,120438,71,1292,71,5056,71,5107,71,42198,71,65352,104,8462,104,119841,104,119945,104,119997,104,120049,104,120101,104,120153,104,120205,104,120257,104,120309,104,120361,104,120413,104,120465,104,1211,104,1392,104,5058,104,65320,72,8459,72,8460,72,8461,72,117981,72,119815,72,119867,72,119919,72,120023,72,120179,72,120231,72,120283,72,120335,72,120387,72,120439,72,919,72,120494,72,120552,72,120610,72,120668,72,120726,72,11406,72,5051,72,5500,72,42215,72,66255,72,731,105,9075,105,65353,105,8560,105,8505,105,8520,105,119842,105,119894,105,119946,105,119998,105,120050,105,120102,105,120154,105,120206,105,120258,105,120310,105,120362,105,120414,105,120466,105,120484,105,618,105,617,105,953,105,8126,105,890,105,120522,105,120580,105,120638,105,120696,105,120754,105,1110,105,42567,105,1231,105,43893,105,5029,105,71875,105,65354,106,8521,106,119843,106,119895,106,119947,106,119999,106,120051,106,120103,106,120155,106,120207,106,120259,106,120311,106,120363,106,120415,106,120467,106,1011,106,1112,106,65322,74,117983,74,119817,74,119869,74,119921,74,119973,74,120025,74,120077,74,120129,74,120181,74,120233,74,120285,74,120337,74,120389,74,120441,74,42930,74,895,74,1032,74,5035,74,5261,74,42201,74,119844,107,119896,107,119948,107,120000,107,120052,107,120104,107,120156,107,120208,107,120260,107,120312,107,120364,107,120416,107,120468,107,8490,75,65323,75,117984,75,119818,75,119870,75,119922,75,119974,75,120026,75,120078,75,120130,75,120182,75,120234,75,120286,75,120338,75,120390,75,120442,75,922,75,120497,75,120555,75,120613,75,120671,75,120729,75,11412,75,5094,75,5845,75,42199,75,66840,75,1472,108,8739,73,9213,73,65512,73,1633,108,1777,73,66336,108,125127,108,118001,108,120783,73,120793,73,120803,73,120813,73,120823,73,130033,73,65321,73,8544,73,8464,73,8465,73,117982,108,119816,73,119868,73,119920,73,120024,73,120128,73,120180,73,120232,73,120284,73,120336,73,120388,73,120440,73,65356,108,8572,73,8467,108,119845,108,119897,108,119949,108,120001,108,120053,108,120105,73,120157,73,120209,73,120261,73,120313,73,120365,73,120417,73,120469,73,448,73,120496,73,120554,73,120612,73,120670,73,120728,73,11410,73,1030,73,1216,73,1493,108,1503,108,1575,108,126464,108,126592,108,65166,108,65165,108,1994,108,11599,73,5825,73,42226,73,93992,73,66186,124,66313,124,119338,76,8556,76,8466,76,117985,76,119819,76,119871,76,119923,76,120027,76,120079,76,120131,76,120183,76,120235,76,120287,76,120339,76,120391,76,120443,76,11472,76,5086,76,5290,76,42209,76,93974,76,71843,76,71858,76,66587,76,66854,76,65325,77,8559,77,8499,77,117986,77,119820,77,119872,77,119924,77,120028,77,120080,77,120132,77,120184,77,120236,77,120288,77,120340,77,120392,77,120444,77,924,77,120499,77,120557,77,120615,77,120673,77,120731,77,1018,77,11416,77,5047,77,5616,77,5846,77,42207,77,66224,77,66321,77,119847,110,119899,110,119951,110,120003,110,120055,110,120107,110,120159,110,120211,110,120263,110,120315,110,120367,110,120419,110,120471,110,1400,110,1404,110,65326,78,8469,78,117987,78,119821,78,119873,78,119925,78,119977,78,120029,78,120081,78,120185,78,120237,78,120289,78,120341,78,120393,78,120445,78,925,78,120500,78,120558,78,120616,78,120674,78,120732,78,11418,78,42208,78,66835,78,3074,111,3202,111,3330,111,3458,111,2406,111,2662,111,2790,111,3046,111,3174,111,3302,111,3430,111,3664,111,3792,111,4160,111,1637,111,1781,111,65359,111,8500,111,119848,111,119900,111,119952,111,120056,111,120108,111,120160,111,120212,111,120264,111,120316,111,120368,111,120420,111,120472,111,7439,111,7441,111,43837,111,959,111,120528,111,120586,111,120644,111,120702,111,120760,111,963,111,120532,111,120590,111,120648,111,120706,111,120764,111,11423,111,4351,111,1413,111,1505,111,1607,111,126500,111,126564,111,126596,111,65259,111,65260,111,65258,111,65257,111,1726,111,64428,111,64429,111,64427,111,64426,111,1729,111,64424,111,64425,111,64423,111,64422,111,1749,111,3360,111,4125,111,66794,111,71880,111,71895,111,66604,111,1984,79,2534,79,2918,79,12295,79,70864,79,71904,79,118000,79,120782,79,120792,79,120802,79,120812,79,120822,79,130032,79,65327,79,117988,79,119822,79,119874,79,119926,79,119978,79,120030,79,120082,79,120134,79,120186,79,120238,79,120290,79,120342,79,120394,79,120446,79,927,79,120502,79,120560,79,120618,79,120676,79,120734,79,11422,79,1365,79,11604,79,4816,79,2848,79,66754,79,42227,79,71861,79,66194,79,66219,79,66564,79,66838,79,9076,112,65360,112,119849,112,119901,112,119953,112,120005,112,120057,112,120109,112,120161,112,120213,112,120265,112,120317,112,120369,112,120421,112,120473,112,961,112,120530,112,120544,112,120588,112,120602,112,120646,112,120660,112,120704,112,120718,112,120762,112,120776,112,11427,112,65328,80,8473,80,117989,80,119823,80,119875,80,119927,80,119979,80,120031,80,120083,80,120187,80,120239,80,120291,80,120343,80,120395,80,120447,80,929,80,120504,80,120562,80,120620,80,120678,80,120736,80,11426,80,5090,80,5229,80,42193,80,66197,80,119850,113,119902,113,119954,113,120006,113,120058,113,120110,113,120162,113,120214,113,120266,113,120318,113,120370,113,120422,113,120474,113,1307,113,1379,113,1382,113,8474,81,117990,81,119824,81,119876,81,119928,81,119980,81,120032,81,120084,81,120188,81,120240,81,120292,81,120344,81,120396,81,120448,81,11605,81,119851,114,119903,114,119955,114,120007,114,120059,114,120111,114,120163,114,120215,114,120267,114,120319,114,120371,114,120423,114,120475,114,43847,114,43848,114,7462,114,11397,114,43905,114,119318,82,8475,82,8476,82,8477,82,117991,82,119825,82,119877,82,119929,82,120033,82,120189,82,120241,82,120293,82,120345,82,120397,82,120449,82,422,82,5025,82,5074,82,66740,82,5511,82,42211,82,94005,82,65363,115,119852,115,119904,115,119956,115,120008,115,120060,115,120112,115,120164,115,120216,115,120268,115,120320,115,120372,115,120424,115,120476,115,42801,115,445,115,1109,115,43946,115,71873,115,66632,115,65331,83,117992,83,119826,83,119878,83,119930,83,119982,83,120034,83,120086,83,120138,83,120190,83,120242,83,120294,83,120346,83,120398,83,120450,83,1029,83,1359,83,5077,83,5082,83,42210,83,94010,83,66198,83,66592,83,119853,116,119905,116,119957,116,120009,116,120061,116,120113,116,120165,116,120217,116,120269,116,120321,116,120373,116,120425,116,120477,116,8868,84,10201,84,128872,84,65332,84,117993,84,119827,84,119879,84,119931,84,119983,84,120035,84,120087,84,120139,84,120191,84,120243,84,120295,84,120347,84,120399,84,120451,84,932,84,120507,84,120565,84,120623,84,120681,84,120739,84,11430,84,5026,84,42196,84,93962,84,71868,84,66199,84,66225,84,66325,84,119854,117,119906,117,119958,117,120010,117,120062,117,120114,117,120166,117,120218,117,120270,117,120322,117,120374,117,120426,117,120478,117,42911,117,7452,117,43854,117,43858,117,651,117,965,117,120534,117,120592,117,120650,117,120708,117,120766,117,1405,117,66806,117,71896,117,8746,85,8899,85,117994,85,119828,85,119880,85,119932,85,119984,85,120036,85,120088,85,120140,85,120192,85,120244,85,120296,85,120348,85,120400,85,120452,85,1357,85,4608,85,66766,85,5196,85,42228,85,94018,85,71864,85,8744,118,8897,118,65366,118,8564,118,119855,118,119907,118,119959,118,120011,118,120063,118,120115,118,120167,118,120219,118,120271,118,120323,118,120375,118,120427,118,120479,118,7456,118,957,118,120526,118,120584,118,120642,118,120700,118,120758,118,1141,118,1496,118,71430,118,43945,118,71872,118,119309,86,1639,86,1783,86,8548,86,117995,86,119829,86,119881,86,119933,86,119985,86,120037,86,120089,86,120141,86,120193,86,120245,86,120297,86,120349,86,120401,86,120453,86,1140,86,11576,86,5081,86,5167,86,42719,86,42214,86,93960,86,71840,86,66845,86,623,119,119856,119,119908,119,119960,119,120012,119,120064,119,120116,119,120168,119,120220,119,120272,119,120324,119,120376,119,120428,119,120480,119,7457,119,1121,119,1309,119,1377,119,71434,119,71438,119,71439,119,43907,119,71910,87,71919,87,117996,87,119830,87,119882,87,119934,87,119986,87,120038,87,120090,87,120142,87,120194,87,120246,87,120298,87,120350,87,120402,87,120454,87,1308,87,5043,87,5076,87,42218,87,5742,120,10539,120,10540,120,10799,120,65368,120,8569,120,119857,120,119909,120,119961,120,120013,120,120065,120,120117,120,120169,120,120221,120,120273,120,120325,120,120377,120,120429,120,120481,120,5441,120,5501,120,5741,88,9587,88,66338,88,71916,88,65336,88,8553,88,117997,88,119831,88,119883,88,119935,88,119987,88,120039,88,120091,88,120143,88,120195,88,120247,88,120299,88,120351,88,120403,88,120455,88,42931,88,935,88,120510,88,120568,88,120626,88,120684,88,120742,88,11436,88,11613,88,5815,88,42219,88,66192,88,66228,88,66327,88,66855,88,611,121,7564,121,65369,121,119858,121,119910,121,119962,121,120014,121,120066,121,120118,121,120170,121,120222,121,120274,121,120326,121,120378,121,120430,121,120482,121,655,121,7935,121,43866,121,947,121,8509,121,120516,121,120574,121,120632,121,120690,121,120748,121,1199,121,4327,121,71900,121,65337,89,117998,89,119832,89,119884,89,119936,89,119988,89,120040,89,120092,89,120144,89,120196,89,120248,89,120300,89,120352,89,120404,89,120456,89,933,89,978,89,120508,89,120566,89,120624,89,120682,89,120740,89,11432,89,1198,89,5033,89,5053,89,42220,89,94019,89,71844,89,66226,89,119859,122,119911,122,119963,122,120015,122,120067,122,120119,122,120171,122,120223,122,120275,122,120327,122,120379,122,120431,122,120483,122,7458,122,43923,122,71876,122,71909,90,66293,90,65338,90,8484,90,8488,90,117999,90,119833,90,119885,90,119937,90,119989,90,120041,90,120197,90,120249,90,120301,90,120353,90,120405,90,120457,90,918,90,120493,90,120551,90,120609,90,120667,90,120725,90,5059,90,42204,90,71849,90,65282,34,65283,35,65284,36,65285,37,65286,38,65290,42,65291,43,65294,46,65295,47,65296,48,65298,50,65299,51,65300,52,65301,53,65302,54,65303,55,65304,56,65305,57,65308,60,65309,61,65310,62,65312,64,65316,68,65318,70,65319,71,65324,76,65329,81,65330,82,65333,85,65334,86,65335,87,65343,95,65346,98,65348,100,65350,102,65355,107,65357,109,65358,110,65361,113,65362,114,65364,116,65365,117,65367,119,65370,122,65371,123,65373,125,119846,109],"_default":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8217,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"cs":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"de":[65374,126,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"es":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"fr":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"it":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"ja":[8211,45,8218,44,65281,33,8216,96,8245,96,180,96,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65292,44,65297,49,65307,59],"ko":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"pl":[65374,126,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"pt-BR":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"qps-ploc":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"ru":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,305,105,921,73,1009,112,215,120,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"tr":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],"zh-hans":[160,32,65374,126,8218,44,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65297,49],"zh-hant":[8211,45,65374,126,8218,44,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89]}')), $e.cache = new pl({
    getCacheKey: JSON.stringify
  }, e => {
    function n(h) {
      const f = new Map;
      for (let m = 0; m < h.length; m += 2) f.set(h[m], h[m + 1]);
      return f
    }

    function r(h, f) {
      const m = new Map(h);
      for (const [g, d] of f) m.set(g, d);
      return m
    }

    function i(h, f) {
      if (!h) return f;
      const m = new Map;
      for (const [g, d] of h) f.has(g) && m.set(g, d);
      return m
    }
    const s = $e.ambiguousCharacterData.value;
    let a = e.filter(h => !h.startsWith("_") && Object.hasOwn(s, h));
    a.length === 0 && (a = ["_default"]);
    let o;
    for (const h of a) {
      const f = n(s[h]);
      o = i(o, f)
    }
    const u = n(s._common),
      l = r(u, o);
    return new $e(l)
  }), $e._locales = new ir(() => Object.keys($e.ambiguousCharacterData.value).filter(e => !e.startsWith("_")));
  let Ht = $e;
  const Bt = class Bt {
    static getRawData() {
      return JSON.parse('{"_common":[11,12,13,127,847,1564,4447,4448,6068,6069,6155,6156,6157,6158,7355,7356,8192,8193,8194,8195,8196,8197,8198,8199,8200,8201,8202,8204,8205,8206,8207,8234,8235,8236,8237,8238,8239,8287,8288,8289,8290,8291,8292,8293,8294,8295,8296,8297,8298,8299,8300,8301,8302,8303,10240,12644,65024,65025,65026,65027,65028,65029,65030,65031,65032,65033,65034,65035,65036,65037,65038,65039,65279,65440,65520,65521,65522,65523,65524,65525,65526,65527,65528,65532,78844,119155,119156,119157,119158,119159,119160,119161,119162,917504,917505,917506,917507,917508,917509,917510,917511,917512,917513,917514,917515,917516,917517,917518,917519,917520,917521,917522,917523,917524,917525,917526,917527,917528,917529,917530,917531,917532,917533,917534,917535,917536,917537,917538,917539,917540,917541,917542,917543,917544,917545,917546,917547,917548,917549,917550,917551,917552,917553,917554,917555,917556,917557,917558,917559,917560,917561,917562,917563,917564,917565,917566,917567,917568,917569,917570,917571,917572,917573,917574,917575,917576,917577,917578,917579,917580,917581,917582,917583,917584,917585,917586,917587,917588,917589,917590,917591,917592,917593,917594,917595,917596,917597,917598,917599,917600,917601,917602,917603,917604,917605,917606,917607,917608,917609,917610,917611,917612,917613,917614,917615,917616,917617,917618,917619,917620,917621,917622,917623,917624,917625,917626,917627,917628,917629,917630,917631,917760,917761,917762,917763,917764,917765,917766,917767,917768,917769,917770,917771,917772,917773,917774,917775,917776,917777,917778,917779,917780,917781,917782,917783,917784,917785,917786,917787,917788,917789,917790,917791,917792,917793,917794,917795,917796,917797,917798,917799,917800,917801,917802,917803,917804,917805,917806,917807,917808,917809,917810,917811,917812,917813,917814,917815,917816,917817,917818,917819,917820,917821,917822,917823,917824,917825,917826,917827,917828,917829,917830,917831,917832,917833,917834,917835,917836,917837,917838,917839,917840,917841,917842,917843,917844,917845,917846,917847,917848,917849,917850,917851,917852,917853,917854,917855,917856,917857,917858,917859,917860,917861,917862,917863,917864,917865,917866,917867,917868,917869,917870,917871,917872,917873,917874,917875,917876,917877,917878,917879,917880,917881,917882,917883,917884,917885,917886,917887,917888,917889,917890,917891,917892,917893,917894,917895,917896,917897,917898,917899,917900,917901,917902,917903,917904,917905,917906,917907,917908,917909,917910,917911,917912,917913,917914,917915,917916,917917,917918,917919,917920,917921,917922,917923,917924,917925,917926,917927,917928,917929,917930,917931,917932,917933,917934,917935,917936,917937,917938,917939,917940,917941,917942,917943,917944,917945,917946,917947,917948,917949,917950,917951,917952,917953,917954,917955,917956,917957,917958,917959,917960,917961,917962,917963,917964,917965,917966,917967,917968,917969,917970,917971,917972,917973,917974,917975,917976,917977,917978,917979,917980,917981,917982,917983,917984,917985,917986,917987,917988,917989,917990,917991,917992,917993,917994,917995,917996,917997,917998,917999],"cs":[173,8203,12288],"de":[173,8203,12288],"es":[8203,12288],"fr":[173,8203,12288],"it":[160,173,12288],"ja":[173],"ko":[173,12288],"pl":[173,8203,12288],"pt-BR":[173,8203,12288],"qps-ploc":[160,173,8203,12288],"ru":[173,12288],"tr":[160,173,8203,12288],"zh-hans":[160,173,8203,12288],"zh-hant":[173,12288]}')
    }
    static getData() {
      return this._data || (this._data = new Set([...Object.values(Bt.getRawData())].flat())), this._data
    }
    static isInvisibleCharacter(e) {
      return Bt.getData().has(e)
    }
    static get codePoints() {
      return Bt.getData()
    }
  };
  Bt._data = void 0;
  let zt = Bt;
  const ar = "default",
    El = "$initialize";
  class Ml {
    constructor(e, n, r, i, s) {
      this.vsWorker = e, this.req = n, this.channel = r, this.method = i, this.args = s, this.type = 0
    }
  }
  class gi {
    constructor(e, n, r, i) {
      this.vsWorker = e, this.seq = n, this.res = r, this.err = i, this.type = 1
    }
  }
  class Tl {
    constructor(e, n, r, i, s) {
      this.vsWorker = e, this.req = n, this.channel = r, this.eventName = i, this.arg = s, this.type = 2
    }
  }
  class Pl {
    constructor(e, n, r) {
      this.vsWorker = e, this.req = n, this.event = r, this.type = 3
    }
  }
  class Cl {
    constructor(e, n) {
      this.vsWorker = e, this.req = n, this.type = 4
    }
  }
  class Il {
    constructor(e) {
      this._workerId = -1, this._handler = e, this._lastSentReq = 0, this._pendingReplies = Object.create(null), this._pendingEmitters = new Map, this._pendingEvents = new Map
    }
    setWorkerId(e) {
      this._workerId = e
    }
    async sendMessage(e, n, r) {
      const i = String(++this._lastSentReq);
      return new Promise((s, a) => {
        this._pendingReplies[i] = {
          resolve: s,
          reject: a
        }, this._send(new Ml(this._workerId, i, e, n, r))
      })
    }
    listen(e, n, r) {
      let i = null;
      const s = new Ce({
        onWillAddFirstListener: () => {
          i = String(++this._lastSentReq), this._pendingEmitters.set(i, s), this._send(new Tl(this._workerId, i, e, n, r))
        },
        onDidRemoveLastListener: () => {
          this._pendingEmitters.delete(i), this._send(new Cl(this._workerId, i)), i = null
        }
      });
      return s.event
    }
    handleMessage(e) {
      !e || !e.vsWorker || this._workerId !== -1 && e.vsWorker !== this._workerId || this._handleMessage(e)
    }
    createProxyToRemoteChannel(e, n) {
      const r = {
        get: (i, s) => (typeof s == "string" && !i[s] && (bi(s) ? i[s] = a => this.listen(e, s, a) : pi(s) ? i[s] = this.listen(e, s, void 0) : s.charCodeAt(0) === 36 && (i[s] = async (...a) => (await (n == null ? void 0 : n()), this.sendMessage(e, s, a)))), i[s])
      };
      return new Proxy(Object.create(null), r)
    }
    _handleMessage(e) {
      switch (e.type) {
        case 1:
          return this._handleReplyMessage(e);
        case 0:
          return this._handleRequestMessage(e);
        case 2:
          return this._handleSubscribeEventMessage(e);
        case 3:
          return this._handleEventMessage(e);
        case 4:
          return this._handleUnsubscribeEventMessage(e)
      }
    }
    _handleReplyMessage(e) {
      if (!this._pendingReplies[e.seq]) {
        console.warn("Got reply to unknown seq");
        return
      }
      const n = this._pendingReplies[e.seq];
      if (delete this._pendingReplies[e.seq], e.err) {
        let r = e.err;
        if (e.err.$isError) {
          const i = new Error;
          i.name = e.err.name, i.message = e.err.message, i.stack = e.err.stack, r = i
        }
        n.reject(r);
        return
      }
      n.resolve(e.res)
    }
    _handleRequestMessage(e) {
      const n = e.req;
      this._handler.handleMessage(e.channel, e.method, e.args).then(i => {
        this._send(new gi(this._workerId, n, i, void 0))
      }, i => {
        i.detail instanceof Error && (i.detail = Gn(i.detail)), this._send(new gi(this._workerId, n, void 0, Gn(i)))
      })
    }
    _handleSubscribeEventMessage(e) {
      const n = e.req,
        r = this._handler.handleEvent(e.channel, e.eventName, e.arg)(i => {
          this._send(new Pl(this._workerId, n, i))
        });
      this._pendingEvents.set(n, r)
    }
    _handleEventMessage(e) {
      if (!this._pendingEmitters.has(e.req)) {
        console.warn("Got event for unknown req");
        return
      }
      this._pendingEmitters.get(e.req).fire(e.event)
    }
    _handleUnsubscribeEventMessage(e) {
      if (!this._pendingEvents.has(e.req)) {
        console.warn("Got unsubscribe for unknown req");
        return
      }
      this._pendingEvents.get(e.req).dispose(), this._pendingEvents.delete(e.req)
    }
    _send(e) {
      const n = [];
      if (e.type === 0)
        for (let r = 0; r < e.args.length; r++) {
          const i = e.args[r];
          i instanceof ArrayBuffer && n.push(i)
        } else e.type === 1 && e.res instanceof ArrayBuffer && n.push(e.res);
      this._handler.sendMessage(e, n)
    }
  }

  function pi(t) {
    return t[0] === "o" && t[1] === "n" && di(t.charCodeAt(2))
  }

  function bi(t) {
    return /^onDynamic/.test(t) && di(t.charCodeAt(9))
  }
  class Fl {
    constructor(e, n) {
      this._localChannels = new Map, this._remoteChannels = new Map, this._protocol = new Il({
        sendMessage: (r, i) => {
          e(r, i)
        },
        handleMessage: (r, i, s) => this._handleMessage(r, i, s),
        handleEvent: (r, i, s) => this._handleEvent(r, i, s)
      }), this.requestHandler = n(this)
    }
    onmessage(e) {
      this._protocol.handleMessage(e)
    }
    _handleMessage(e, n, r) {
      if (e === ar && n === El) return this.initialize(r[0]);
      const i = e === ar ? this.requestHandler : this._localChannels.get(e);
      if (!i) return Promise.reject(new Error(`Missing channel ${e} on worker thread`));
      const s = i[n];
      if (typeof s != "function") return Promise.reject(new Error(`Missing method ${n} on worker thread channel ${e}`));
      try {
        return Promise.resolve(s.apply(i, r))
      } catch (a) {
        return Promise.reject(a)
      }
    }
    _handleEvent(e, n, r) {
      const i = e === ar ? this.requestHandler : this._localChannels.get(e);
      if (!i) throw new Error(`Missing channel ${e} on worker thread`);
      if (bi(n)) {
        const s = i[n];
        if (typeof s != "function") throw new Error(`Missing dynamic event ${n} on request handler.`);
        const a = s.call(i, r);
        if (typeof a != "function") throw new Error(`Missing dynamic event ${n} on request handler.`);
        return a
      }
      if (pi(n)) {
        const s = i[n];
        if (typeof s != "function") throw new Error(`Missing event ${n} on request handler.`);
        return s
      }
      throw new Error(`Malformed event name ${n}`)
    }
    getChannel(e) {
      if (!this._remoteChannels.has(e)) {
        const n = this._protocol.createProxyToRemoteChannel(e);
        this._remoteChannels.set(e, n)
      }
      return this._remoteChannels.get(e)
    }
    async initialize(e) {
      this._protocol.setWorkerId(e)
    }
  }
  let yi = !1;

  function Vl(t) {
    if (yi) throw new Error("WebWorker already initialized!");
    yi = !0;
    const e = new Fl(n => globalThis.postMessage(n), n => t(n));
    return globalThis.onmessage = n => {
      e.onmessage(n.data)
    }, e
  }
  class Je {
    constructor(e, n, r, i) {
      this.originalStart = e, this.originalLength = n, this.modifiedStart = r, this.modifiedLength = i
    }
    getOriginalEnd() {
      return this.originalStart + this.originalLength
    }
    getModifiedEnd() {
      return this.modifiedStart + this.modifiedLength
    }
  }
  new ir(() => new Uint8Array(256));

  function wi(t, e) {
    return (e << 5) - e + t | 0
  }

  function Dl(t, e) {
    e = wi(149417, e);
    for (let n = 0, r = t.length; n < r; n++) e = wi(t.charCodeAt(n), e);
    return e
  }
  class xi {
    constructor(e) {
      this.source = e
    }
    getElements() {
      const e = this.source,
        n = new Int32Array(e.length);
      for (let r = 0, i = e.length; r < i; r++) n[r] = e.charCodeAt(r);
      return n
    }
  }

  function Ol(t, e, n) {
    return new Xe(new xi(t), new xi(e)).ComputeDiff(n).changes
  }
  class yt {
    static Assert(e, n) {
      if (!e) throw new Error(n)
    }
  }
  class wt {
    static Copy(e, n, r, i, s) {
      for (let a = 0; a < s; a++) r[i + a] = e[n + a]
    }
    static Copy2(e, n, r, i, s) {
      for (let a = 0; a < s; a++) r[i + a] = e[n + a]
    }
  }
  class vi {
    constructor() {
      this.m_changes = [], this.m_originalStart = 1073741824, this.m_modifiedStart = 1073741824, this.m_originalCount = 0, this.m_modifiedCount = 0
    }
    MarkNextChange() {
      (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.m_changes.push(new Je(this.m_originalStart, this.m_originalCount, this.m_modifiedStart, this.m_modifiedCount)), this.m_originalCount = 0, this.m_modifiedCount = 0, this.m_originalStart = 1073741824, this.m_modifiedStart = 1073741824
    }
    AddOriginalElement(e, n) {
      this.m_originalStart = Math.min(this.m_originalStart, e), this.m_modifiedStart = Math.min(this.m_modifiedStart, n), this.m_originalCount++
    }
    AddModifiedElement(e, n) {
      this.m_originalStart = Math.min(this.m_originalStart, e), this.m_modifiedStart = Math.min(this.m_modifiedStart, n), this.m_modifiedCount++
    }
    getChanges() {
      return (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.MarkNextChange(), this.m_changes
    }
    getReverseChanges() {
      return (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.MarkNextChange(), this.m_changes.reverse(), this.m_changes
    }
  }
  class Xe {
    constructor(e, n, r = null) {
      this.ContinueProcessingPredicate = r, this._originalSequence = e, this._modifiedSequence = n;
      const [i, s, a] = Xe._getElements(e), [o, u, l] = Xe._getElements(n);
      this._hasStrings = a && l, this._originalStringElements = i, this._originalElementsOrHash = s, this._modifiedStringElements = o, this._modifiedElementsOrHash = u, this.m_forwardHistory = [], this.m_reverseHistory = []
    }
    static _isStringArray(e) {
      return e.length > 0 && typeof e[0] == "string"
    }
    static _getElements(e) {
      const n = e.getElements();
      if (Xe._isStringArray(n)) {
        const r = new Int32Array(n.length);
        for (let i = 0, s = n.length; i < s; i++) r[i] = Dl(n[i], 0);
        return [n, r, !0]
      }
      return n instanceof Int32Array ? [
        [], n, !1
      ] : [
        [], new Int32Array(n), !1
      ]
    }
    ElementsAreEqual(e, n) {
      return this._originalElementsOrHash[e] !== this._modifiedElementsOrHash[n] ? !1 : this._hasStrings ? this._originalStringElements[e] === this._modifiedStringElements[n] : !0
    }
    ElementsAreStrictEqual(e, n) {
      if (!this.ElementsAreEqual(e, n)) return !1;
      const r = Xe._getStrictElement(this._originalSequence, e),
        i = Xe._getStrictElement(this._modifiedSequence, n);
      return r === i
    }
    static _getStrictElement(e, n) {
      return typeof e.getStrictElement == "function" ? e.getStrictElement(n) : null
    }
    OriginalElementsAreEqual(e, n) {
      return this._originalElementsOrHash[e] !== this._originalElementsOrHash[n] ? !1 : this._hasStrings ? this._originalStringElements[e] === this._originalStringElements[n] : !0
    }
    ModifiedElementsAreEqual(e, n) {
      return this._modifiedElementsOrHash[e] !== this._modifiedElementsOrHash[n] ? !1 : this._hasStrings ? this._modifiedStringElements[e] === this._modifiedStringElements[n] : !0
    }
    ComputeDiff(e) {
      return this._ComputeDiff(0, this._originalElementsOrHash.length - 1, 0, this._modifiedElementsOrHash.length - 1, e)
    }
    _ComputeDiff(e, n, r, i, s) {
      const a = [!1];
      let o = this.ComputeDiffRecursive(e, n, r, i, a);
      return s && (o = this.PrettifyChanges(o)), {
        quitEarly: a[0],
        changes: o
      }
    }
    ComputeDiffRecursive(e, n, r, i, s) {
      for (s[0] = !1; e <= n && r <= i && this.ElementsAreEqual(e, r);) e++, r++;
      for (; n >= e && i >= r && this.ElementsAreEqual(n, i);) n--, i--;
      if (e > n || r > i) {
        let f;
        return r <= i ? (yt.Assert(e === n + 1, "originalStart should only be one more than originalEnd"), f = [new Je(e, 0, r, i - r + 1)]) : e <= n ? (yt.Assert(r === i + 1, "modifiedStart should only be one more than modifiedEnd"), f = [new Je(e, n - e + 1, r, 0)]) : (yt.Assert(e === n + 1, "originalStart should only be one more than originalEnd"), yt.Assert(r === i + 1, "modifiedStart should only be one more than modifiedEnd"), f = []), f
      }
      const a = [0],
        o = [0],
        u = this.ComputeRecursionPoint(e, n, r, i, a, o, s),
        l = a[0],
        h = o[0];
      if (u !== null) return u;
      if (!s[0]) {
        const f = this.ComputeDiffRecursive(e, l, r, h, s);
        let m = [];
        return s[0] ? m = [new Je(l + 1, n - (l + 1) + 1, h + 1, i - (h + 1) + 1)] : m = this.ComputeDiffRecursive(l + 1, n, h + 1, i, s), this.ConcatenateChanges(f, m)
      }
      return [new Je(e, n - e + 1, r, i - r + 1)]
    }
    WALKTRACE(e, n, r, i, s, a, o, u, l, h, f, m, g, d, p, y, w, N) {
      let b = null,
        _ = null,
        L = new vi,
        A = n,
        v = r,
        k = g[0] - y[0] - i,
        M = -1073741824,
        V = this.m_forwardHistory.length - 1;
      do {
        const T = k + e;
        T === A || T < v && l[T - 1] < l[T + 1] ? (f = l[T + 1], d = f - k - i, f < M && L.MarkNextChange(), M = f, L.AddModifiedElement(f + 1, d), k = T + 1 - e) : (f = l[T - 1] + 1, d = f - k - i, f < M && L.MarkNextChange(), M = f - 1, L.AddOriginalElement(f, d + 1), k = T - 1 - e), V >= 0 && (l = this.m_forwardHistory[V], e = l[0], A = 1, v = l.length - 1)
      } while (--V >= -1);
      if (b = L.getReverseChanges(), N[0]) {
        let T = g[0] + 1,
          x = y[0] + 1;
        if (b !== null && b.length > 0) {
          const S = b[b.length - 1];
          T = Math.max(T, S.getOriginalEnd()), x = Math.max(x, S.getModifiedEnd())
        }
        _ = [new Je(T, m - T + 1, x, p - x + 1)]
      } else {
        L = new vi, A = a, v = o, k = g[0] - y[0] - u, M = 1073741824, V = w ? this.m_reverseHistory.length - 1 : this.m_reverseHistory.length - 2;
        do {
          const T = k + s;
          T === A || T < v && h[T - 1] >= h[T + 1] ? (f = h[T + 1] - 1, d = f - k - u, f > M && L.MarkNextChange(), M = f + 1, L.AddOriginalElement(f + 1, d + 1), k = T + 1 - s) : (f = h[T - 1], d = f - k - u, f > M && L.MarkNextChange(), M = f, L.AddModifiedElement(f + 1, d + 1), k = T - 1 - s), V >= 0 && (h = this.m_reverseHistory[V], s = h[0], A = 1, v = h.length - 1)
        } while (--V >= -1);
        _ = L.getChanges()
      }
      return this.ConcatenateChanges(b, _)
    }
    ComputeRecursionPoint(e, n, r, i, s, a, o) {
      let u = 0,
        l = 0,
        h = 0,
        f = 0,
        m = 0,
        g = 0;
      e--, r--, s[0] = 0, a[0] = 0, this.m_forwardHistory = [], this.m_reverseHistory = [];
      const d = n - e + (i - r),
        p = d + 1,
        y = new Int32Array(p),
        w = new Int32Array(p),
        N = i - r,
        b = n - e,
        _ = e - r,
        L = n - i,
        v = (b - N) % 2 === 0;
      y[N] = e, w[b] = n, o[0] = !1;
      for (let k = 1; k <= d / 2 + 1; k++) {
        let M = 0,
          V = 0;
        h = this.ClipDiagonalBound(N - k, k, N, p), f = this.ClipDiagonalBound(N + k, k, N, p);
        for (let x = h; x <= f; x += 2) {
          x === h || x < f && y[x - 1] < y[x + 1] ? u = y[x + 1] : u = y[x - 1] + 1, l = u - (x - N) - _;
          const S = u;
          for (; u < n && l < i && this.ElementsAreEqual(u + 1, l + 1);) u++, l++;
          if (y[x] = u, u + l > M + V && (M = u, V = l), !v && Math.abs(x - b) <= k - 1 && u >= w[x]) return s[0] = u, a[0] = l, S <= w[x] && k <= 1448 ? this.WALKTRACE(N, h, f, _, b, m, g, L, y, w, u, n, s, l, i, a, v, o) : null
        }
        const T = (M - e + (V - r) - k) / 2;
        if (this.ContinueProcessingPredicate !== null && !this.ContinueProcessingPredicate(M, T)) return o[0] = !0, s[0] = M, a[0] = V, T > 0 && k <= 1448 ? this.WALKTRACE(N, h, f, _, b, m, g, L, y, w, u, n, s, l, i, a, v, o) : (e++, r++, [new Je(e, n - e + 1, r, i - r + 1)]);
        m = this.ClipDiagonalBound(b - k, k, b, p), g = this.ClipDiagonalBound(b + k, k, b, p);
        for (let x = m; x <= g; x += 2) {
          x === m || x < g && w[x - 1] >= w[x + 1] ? u = w[x + 1] - 1 : u = w[x - 1], l = u - (x - b) - L;
          const S = u;
          for (; u > e && l > r && this.ElementsAreEqual(u, l);) u--, l--;
          if (w[x] = u, v && Math.abs(x - N) <= k && u <= y[x]) return s[0] = u, a[0] = l, S >= y[x] && k <= 1448 ? this.WALKTRACE(N, h, f, _, b, m, g, L, y, w, u, n, s, l, i, a, v, o) : null
        }
        if (k <= 1447) {
          let x = new Int32Array(f - h + 2);
          x[0] = N - h + 1, wt.Copy2(y, h, x, 1, f - h + 1), this.m_forwardHistory.push(x), x = new Int32Array(g - m + 2), x[0] = b - m + 1, wt.Copy2(w, m, x, 1, g - m + 1), this.m_reverseHistory.push(x)
        }
      }
      return this.WALKTRACE(N, h, f, _, b, m, g, L, y, w, u, n, s, l, i, a, v, o)
    }
    PrettifyChanges(e) {
      for (let n = 0; n < e.length; n++) {
        const r = e[n],
          i = n < e.length - 1 ? e[n + 1].originalStart : this._originalElementsOrHash.length,
          s = n < e.length - 1 ? e[n + 1].modifiedStart : this._modifiedElementsOrHash.length,
          a = r.originalLength > 0,
          o = r.modifiedLength > 0;
        for (; r.originalStart + r.originalLength < i && r.modifiedStart + r.modifiedLength < s && (!a || this.OriginalElementsAreEqual(r.originalStart, r.originalStart + r.originalLength)) && (!o || this.ModifiedElementsAreEqual(r.modifiedStart, r.modifiedStart + r.modifiedLength));) {
          const l = this.ElementsAreStrictEqual(r.originalStart, r.modifiedStart);
          if (this.ElementsAreStrictEqual(r.originalStart + r.originalLength, r.modifiedStart + r.modifiedLength) && !l) break;
          r.originalStart++, r.modifiedStart++
        }
        const u = [null];
        if (n < e.length - 1 && this.ChangesOverlap(e[n], e[n + 1], u)) {
          e[n] = u[0], e.splice(n + 1, 1), n--;
          continue
        }
      }
      for (let n = e.length - 1; n >= 0; n--) {
        const r = e[n];
        let i = 0,
          s = 0;
        if (n > 0) {
          const f = e[n - 1];
          i = f.originalStart + f.originalLength, s = f.modifiedStart + f.modifiedLength
        }
        const a = r.originalLength > 0,
          o = r.modifiedLength > 0;
        let u = 0,
          l = this._boundaryScore(r.originalStart, r.originalLength, r.modifiedStart, r.modifiedLength);
        for (let f = 1;; f++) {
          const m = r.originalStart - f,
            g = r.modifiedStart - f;
          if (m < i || g < s || a && !this.OriginalElementsAreEqual(m, m + r.originalLength) || o && !this.ModifiedElementsAreEqual(g, g + r.modifiedLength)) break;
          const p = (m === i && g === s ? 5 : 0) + this._boundaryScore(m, r.originalLength, g, r.modifiedLength);
          p > l && (l = p, u = f)
        }
        r.originalStart -= u, r.modifiedStart -= u;
        const h = [null];
        if (n > 0 && this.ChangesOverlap(e[n - 1], e[n], h)) {
          e[n - 1] = h[0], e.splice(n, 1), n++;
          continue
        }
      }
      if (this._hasStrings)
        for (let n = 1, r = e.length; n < r; n++) {
          const i = e[n - 1],
            s = e[n],
            a = s.originalStart - i.originalStart - i.originalLength,
            o = i.originalStart,
            u = s.originalStart + s.originalLength,
            l = u - o,
            h = i.modifiedStart,
            f = s.modifiedStart + s.modifiedLength,
            m = f - h;
          if (a < 5 && l < 20 && m < 20) {
            const g = this._findBetterContiguousSequence(o, l, h, m, a);
            if (g) {
              const [d, p] = g;
              (d !== i.originalStart + i.originalLength || p !== i.modifiedStart + i.modifiedLength) && (i.originalLength = d - i.originalStart, i.modifiedLength = p - i.modifiedStart, s.originalStart = d + a, s.modifiedStart = p + a, s.originalLength = u - s.originalStart, s.modifiedLength = f - s.modifiedStart)
            }
          }
        }
      return e
    }
    _findBetterContiguousSequence(e, n, r, i, s) {
      if (n < s || i < s) return null;
      const a = e + n - s + 1,
        o = r + i - s + 1;
      let u = 0,
        l = 0,
        h = 0;
      for (let f = e; f < a; f++)
        for (let m = r; m < o; m++) {
          const g = this._contiguousSequenceScore(f, m, s);
          g > 0 && g > u && (u = g, l = f, h = m)
        }
      return u > 0 ? [l, h] : null
    }
    _contiguousSequenceScore(e, n, r) {
      let i = 0;
      for (let s = 0; s < r; s++) {
        if (!this.ElementsAreEqual(e + s, n + s)) return 0;
        i += this._originalStringElements[e + s].length
      }
      return i
    }
    _OriginalIsBoundary(e) {
      return e <= 0 || e >= this._originalElementsOrHash.length - 1 ? !0 : this._hasStrings && /^\s*$/.test(this._originalStringElements[e])
    }
    _OriginalRegionIsBoundary(e, n) {
      if (this._OriginalIsBoundary(e) || this._OriginalIsBoundary(e - 1)) return !0;
      if (n > 0) {
        const r = e + n;
        if (this._OriginalIsBoundary(r - 1) || this._OriginalIsBoundary(r)) return !0
      }
      return !1
    }
    _ModifiedIsBoundary(e) {
      return e <= 0 || e >= this._modifiedElementsOrHash.length - 1 ? !0 : this._hasStrings && /^\s*$/.test(this._modifiedStringElements[e])
    }
    _ModifiedRegionIsBoundary(e, n) {
      if (this._ModifiedIsBoundary(e) || this._ModifiedIsBoundary(e - 1)) return !0;
      if (n > 0) {
        const r = e + n;
        if (this._ModifiedIsBoundary(r - 1) || this._ModifiedIsBoundary(r)) return !0
      }
      return !1
    }
    _boundaryScore(e, n, r, i) {
      const s = this._OriginalRegionIsBoundary(e, n) ? 1 : 0,
        a = this._ModifiedRegionIsBoundary(r, i) ? 1 : 0;
      return s + a
    }
    ConcatenateChanges(e, n) {
      const r = [];
      if (e.length === 0 || n.length === 0) return n.length > 0 ? n : e;
      if (this.ChangesOverlap(e[e.length - 1], n[0], r)) {
        const i = new Array(e.length + n.length - 1);
        return wt.Copy(e, 0, i, 0, e.length - 1), i[e.length - 1] = r[0], wt.Copy(n, 1, i, e.length, n.length - 1), i
      } else {
        const i = new Array(e.length + n.length);
        return wt.Copy(e, 0, i, 0, e.length), wt.Copy(n, 0, i, e.length, n.length), i
      }
    }
    ChangesOverlap(e, n, r) {
      if (yt.Assert(e.originalStart <= n.originalStart, "Left change is not less than or equal to right change"), yt.Assert(e.modifiedStart <= n.modifiedStart, "Left change is not less than or equal to right change"), e.originalStart + e.originalLength >= n.originalStart || e.modifiedStart + e.modifiedLength >= n.modifiedStart) {
        const i = e.originalStart;
        let s = e.originalLength;
        const a = e.modifiedStart;
        let o = e.modifiedLength;
        return e.originalStart + e.originalLength >= n.originalStart && (s = n.originalStart + n.originalLength - e.originalStart), e.modifiedStart + e.modifiedLength >= n.modifiedStart && (o = n.modifiedStart + n.modifiedLength - e.modifiedStart), r[0] = new Je(i, s, a, o), !0
      } else return r[0] = null, !1
    }
    ClipDiagonalBound(e, n, r, i) {
      if (e >= 0 && e < i) return e;
      const s = r,
        a = i - r - 1,
        o = n % 2 === 0;
      if (e < 0) {
        const u = s % 2 === 0;
        return o === u ? 0 : 1
      } else {
        const u = a % 2 === 0;
        return o === u ? i - 1 : i - 2
      }
    }
  }
  let Q = class gt {
      constructor(e, n) {
        this.lineNumber = e, this.column = n
      }
      with(e = this.lineNumber, n = this.column) {
        return e === this.lineNumber && n === this.column ? this : new gt(e, n)
      }
      delta(e = 0, n = 0) {
        return this.with(Math.max(1, this.lineNumber + e), Math.max(1, this.column + n))
      }
      equals(e) {
        return gt.equals(this, e)
      }
      static equals(e, n) {
        return !e && !n ? !0 : !!e && !!n && e.lineNumber === n.lineNumber && e.column === n.column
      }
      isBefore(e) {
        return gt.isBefore(this, e)
      }
      static isBefore(e, n) {
        return e.lineNumber < n.lineNumber ? !0 : n.lineNumber < e.lineNumber ? !1 : e.column < n.column
      }
      isBeforeOrEqual(e) {
        return gt.isBeforeOrEqual(this, e)
      }
      static isBeforeOrEqual(e, n) {
        return e.lineNumber < n.lineNumber ? !0 : n.lineNumber < e.lineNumber ? !1 : e.column <= n.column
      }
      static compare(e, n) {
        const r = e.lineNumber | 0,
          i = n.lineNumber | 0;
        if (r === i) {
          const s = e.column | 0,
            a = n.column | 0;
          return s - a
        }
        return r - i
      }
      clone() {
        return new gt(this.lineNumber, this.column)
      }
      toString() {
        return "(" + this.lineNumber + "," + this.column + ")"
      }
      static lift(e) {
        return new gt(e.lineNumber, e.column)
      }
      static isIPosition(e) {
        return !!e && typeof e.lineNumber == "number" && typeof e.column == "number"
      }
      toJSON() {
        return {
          lineNumber: this.lineNumber,
          column: this.column
        }
      }
    },
    U = class re {
      constructor(e, n, r, i) {
        e > r || e === r && n > i ? (this.startLineNumber = r, this.startColumn = i, this.endLineNumber = e, this.endColumn = n) : (this.startLineNumber = e, this.startColumn = n, this.endLineNumber = r, this.endColumn = i)
      }
      isEmpty() {
        return re.isEmpty(this)
      }
      static isEmpty(e) {
        return e.startLineNumber === e.endLineNumber && e.startColumn === e.endColumn
      }
      containsPosition(e) {
        return re.containsPosition(this, e)
      }
      static containsPosition(e, n) {
        return !(n.lineNumber < e.startLineNumber || n.lineNumber > e.endLineNumber || n.lineNumber === e.startLineNumber && n.column < e.startColumn || n.lineNumber === e.endLineNumber && n.column > e.endColumn)
      }
      static strictContainsPosition(e, n) {
        return !(n.lineNumber < e.startLineNumber || n.lineNumber > e.endLineNumber || n.lineNumber === e.startLineNumber && n.column <= e.startColumn || n.lineNumber === e.endLineNumber && n.column >= e.endColumn)
      }
      containsRange(e) {
        return re.containsRange(this, e)
      }
      static containsRange(e, n) {
        return !(n.startLineNumber < e.startLineNumber || n.endLineNumber < e.startLineNumber || n.startLineNumber > e.endLineNumber || n.endLineNumber > e.endLineNumber || n.startLineNumber === e.startLineNumber && n.startColumn < e.startColumn || n.endLineNumber === e.endLineNumber && n.endColumn > e.endColumn)
      }
      strictContainsRange(e) {
        return re.strictContainsRange(this, e)
      }
      static strictContainsRange(e, n) {
        return !(n.startLineNumber < e.startLineNumber || n.endLineNumber < e.startLineNumber || n.startLineNumber > e.endLineNumber || n.endLineNumber > e.endLineNumber || n.startLineNumber === e.startLineNumber && n.startColumn <= e.startColumn || n.endLineNumber === e.endLineNumber && n.endColumn >= e.endColumn)
      }
      plusRange(e) {
        return re.plusRange(this, e)
      }
      static plusRange(e, n) {
        let r, i, s, a;
        return n.startLineNumber < e.startLineNumber ? (r = n.startLineNumber, i = n.startColumn) : n.startLineNumber === e.startLineNumber ? (r = n.startLineNumber, i = Math.min(n.startColumn, e.startColumn)) : (r = e.startLineNumber, i = e.startColumn), n.endLineNumber > e.endLineNumber ? (s = n.endLineNumber, a = n.endColumn) : n.endLineNumber === e.endLineNumber ? (s = n.endLineNumber, a = Math.max(n.endColumn, e.endColumn)) : (s = e.endLineNumber, a = e.endColumn), new re(r, i, s, a)
      }
      intersectRanges(e) {
        return re.intersectRanges(this, e)
      }
      static intersectRanges(e, n) {
        let r = e.startLineNumber,
          i = e.startColumn,
          s = e.endLineNumber,
          a = e.endColumn;
        const o = n.startLineNumber,
          u = n.startColumn,
          l = n.endLineNumber,
          h = n.endColumn;
        return r < o ? (r = o, i = u) : r === o && (i = Math.max(i, u)), s > l ? (s = l, a = h) : s === l && (a = Math.min(a, h)), r > s || r === s && i > a ? null : new re(r, i, s, a)
      }
      equalsRange(e) {
        return re.equalsRange(this, e)
      }
      static equalsRange(e, n) {
        return !e && !n ? !0 : !!e && !!n && e.startLineNumber === n.startLineNumber && e.startColumn === n.startColumn && e.endLineNumber === n.endLineNumber && e.endColumn === n.endColumn
      }
      getEndPosition() {
        return re.getEndPosition(this)
      }
      static getEndPosition(e) {
        return new Q(e.endLineNumber, e.endColumn)
      }
      getStartPosition() {
        return re.getStartPosition(this)
      }
      static getStartPosition(e) {
        return new Q(e.startLineNumber, e.startColumn)
      }
      toString() {
        return "[" + this.startLineNumber + "," + this.startColumn + " -> " + this.endLineNumber + "," + this.endColumn + "]"
      }
      setEndPosition(e, n) {
        return new re(this.startLineNumber, this.startColumn, e, n)
      }
      setStartPosition(e, n) {
        return new re(e, n, this.endLineNumber, this.endColumn)
      }
      collapseToStart() {
        return re.collapseToStart(this)
      }
      static collapseToStart(e) {
        return new re(e.startLineNumber, e.startColumn, e.startLineNumber, e.startColumn)
      }
      collapseToEnd() {
        return re.collapseToEnd(this)
      }
      static collapseToEnd(e) {
        return new re(e.endLineNumber, e.endColumn, e.endLineNumber, e.endColumn)
      }
      delta(e) {
        return new re(this.startLineNumber + e, this.startColumn, this.endLineNumber + e, this.endColumn)
      }
      isSingleLine() {
        return this.startLineNumber === this.endLineNumber
      }
      static fromPositions(e, n = e) {
        return new re(e.lineNumber, e.column, n.lineNumber, n.column)
      }
      static lift(e) {
        return e ? new re(e.startLineNumber, e.startColumn, e.endLineNumber, e.endColumn) : null
      }
      static isIRange(e) {
        return !!e && typeof e.startLineNumber == "number" && typeof e.startColumn == "number" && typeof e.endLineNumber == "number" && typeof e.endColumn == "number"
      }
      static areIntersectingOrTouching(e, n) {
        return !(e.endLineNumber < n.startLineNumber || e.endLineNumber === n.startLineNumber && e.endColumn < n.startColumn || n.endLineNumber < e.startLineNumber || n.endLineNumber === e.startLineNumber && n.endColumn < e.startColumn)
      }
      static areIntersecting(e, n) {
        return !(e.endLineNumber < n.startLineNumber || e.endLineNumber === n.startLineNumber && e.endColumn <= n.startColumn || n.endLineNumber < e.startLineNumber || n.endLineNumber === e.startLineNumber && n.endColumn <= e.startColumn)
      }
      static areOnlyIntersecting(e, n) {
        return !(e.endLineNumber < n.startLineNumber - 1 || e.endLineNumber === n.startLineNumber && e.endColumn < n.startColumn - 1 || n.endLineNumber < e.startLineNumber - 1 || n.endLineNumber === e.startLineNumber && n.endColumn < e.startColumn - 1)
      }
      static compareRangesUsingStarts(e, n) {
        if (e && n) {
          const s = e.startLineNumber | 0,
            a = n.startLineNumber | 0;
          if (s === a) {
            const o = e.startColumn | 0,
              u = n.startColumn | 0;
            if (o === u) {
              const l = e.endLineNumber | 0,
                h = n.endLineNumber | 0;
              if (l === h) {
                const f = e.endColumn | 0,
                  m = n.endColumn | 0;
                return f - m
              }
              return l - h
            }
            return o - u
          }
          return s - a
        }
        return (e ? 1 : 0) - (n ? 1 : 0)
      }
      static compareRangesUsingEnds(e, n) {
        return e.endLineNumber === n.endLineNumber ? e.endColumn === n.endColumn ? e.startLineNumber === n.startLineNumber ? e.startColumn - n.startColumn : e.startLineNumber - n.startLineNumber : e.endColumn - n.endColumn : e.endLineNumber - n.endLineNumber
      }
      static spansMultipleLines(e) {
        return e.endLineNumber > e.startLineNumber
      }
      toJSON() {
        return this
      }
    };

  function Li(t) {
    return t < 0 ? 0 : t > 255 ? 255 : t | 0
  }

  function xt(t) {
    return t < 0 ? 0 : t > 4294967295 ? 4294967295 : t | 0
  }
  class or {
    constructor(e) {
      const n = Li(e);
      this._defaultValue = n, this._asciiMap = or._createAsciiMap(n), this._map = new Map
    }
    static _createAsciiMap(e) {
      const n = new Uint8Array(256);
      return n.fill(e), n
    }
    set(e, n) {
      const r = Li(n);
      e >= 0 && e < 256 ? this._asciiMap[e] = r : this._map.set(e, r)
    }
    get(e) {
      return e >= 0 && e < 256 ? this._asciiMap[e] : this._map.get(e) || this._defaultValue
    }
    clear() {
      this._asciiMap.fill(this._defaultValue), this._map.clear()
    }
  }
  class $l {
    constructor(e, n, r) {
      const i = new Uint8Array(e * n);
      for (let s = 0, a = e * n; s < a; s++) i[s] = r;
      this._data = i, this.rows = e, this.cols = n
    }
    get(e, n) {
      return this._data[e * this.cols + n]
    }
    set(e, n, r) {
      this._data[e * this.cols + n] = r
    }
  }
  class Bl {
    constructor(e) {
      let n = 0,
        r = 0;
      for (let s = 0, a = e.length; s < a; s++) {
        const [o, u, l] = e[s];
        u > n && (n = u), o > r && (r = o), l > r && (r = l)
      }
      n++, r++;
      const i = new $l(r, n, 0);
      for (let s = 0, a = e.length; s < a; s++) {
        const [o, u, l] = e[s];
        i.set(o, u, l)
      }
      this._states = i, this._maxCharCode = n
    }
    nextState(e, n) {
      return n < 0 || n >= this._maxCharCode ? 0 : this._states.get(e, n)
    }
  }
  let lr = null;

  function Ul() {
    return lr === null && (lr = new Bl([
      [1, 104, 2],
      [1, 72, 2],
      [1, 102, 6],
      [1, 70, 6],
      [2, 116, 3],
      [2, 84, 3],
      [3, 116, 4],
      [3, 84, 4],
      [4, 112, 5],
      [4, 80, 5],
      [5, 115, 9],
      [5, 83, 9],
      [5, 58, 10],
      [6, 105, 7],
      [6, 73, 7],
      [7, 108, 8],
      [7, 76, 8],
      [8, 101, 9],
      [8, 69, 9],
      [9, 58, 10],
      [10, 47, 11],
      [11, 47, 12]
    ])), lr
  }
  let Gt = null;

  function ql() {
    if (Gt === null) {
      Gt = new or(0);
      const t = ` 	<>'"、。｡､，．：；‘〈「『〔（［｛｢｣｝］）〕』」〉’｀～…|`;
      for (let n = 0; n < t.length; n++) Gt.set(t.charCodeAt(n), 1);
      const e = ".,;:";
      for (let n = 0; n < e.length; n++) Gt.set(e.charCodeAt(n), 2)
    }
    return Gt
  }
  class bn {
    static _createLink(e, n, r, i, s) {
      let a = s - 1;
      do {
        const o = n.charCodeAt(a);
        if (e.get(o) !== 2) break;
        a--
      } while (a > i);
      if (i > 0) {
        const o = n.charCodeAt(i - 1),
          u = n.charCodeAt(a);
        (o === 40 && u === 41 || o === 91 && u === 93 || o === 123 && u === 125) && a--
      }
      return {
        range: {
          startLineNumber: r,
          startColumn: i + 1,
          endLineNumber: r,
          endColumn: a + 2
        },
        url: n.substring(i, a + 1)
      }
    }
    static computeLinks(e, n = Ul()) {
      const r = ql(),
        i = [];
      for (let s = 1, a = e.getLineCount(); s <= a; s++) {
        const o = e.getLineContent(s),
          u = o.length;
        let l = 0,
          h = 0,
          f = 0,
          m = 1,
          g = !1,
          d = !1,
          p = !1,
          y = !1;
        for (; l < u;) {
          let w = !1;
          const N = o.charCodeAt(l);
          if (m === 13) {
            let b;
            switch (N) {
              case 40:
                g = !0, b = 0;
                break;
              case 41:
                b = g ? 0 : 1;
                break;
              case 91:
                p = !0, d = !0, b = 0;
                break;
              case 93:
                p = !1, b = d ? 0 : 1;
                break;
              case 123:
                y = !0, b = 0;
                break;
              case 125:
                b = y ? 0 : 1;
                break;
              case 39:
              case 34:
              case 96:
                f === N ? b = 1 : f === 39 || f === 34 || f === 96 ? b = 0 : b = 1;
                break;
              case 42:
                b = f === 42 ? 1 : 0;
                break;
              case 32:
                b = p ? 0 : 1;
                break;
              default:
                b = r.get(N)
            }
            b === 1 && (i.push(bn._createLink(r, o, s, h, l)), w = !0)
          } else if (m === 12) {
            let b;
            N === 91 ? (d = !0, b = 0) : b = r.get(N), b === 1 ? w = !0 : m = 13
          } else m = n.nextState(m, N), m === 0 && (w = !0);
          w && (m = 1, g = !1, d = !1, y = !1, h = l + 1, f = N), l++
        }
        m === 13 && i.push(bn._createLink(r, o, s, h, u))
      }
      return i
    }
  }

  function jl(t) {
    return !t || typeof t.getLineCount != "function" || typeof t.getLineContent != "function" ? [] : bn.computeLinks(t)
  }
  const Un = class Un {
    constructor() {
      this._defaultValueSet = [
        ["true", "false"],
        ["True", "False"],
        ["Private", "Public", "Friend", "ReadOnly", "Partial", "Protected", "WriteOnly"],
        ["public", "protected", "private"]
      ]
    }
    navigateValueSet(e, n, r, i, s) {
      if (e && n) {
        const a = this.doNavigateValueSet(n, s);
        if (a) return {
          range: e,
          value: a
        }
      }
      if (r && i) {
        const a = this.doNavigateValueSet(i, s);
        if (a) return {
          range: r,
          value: a
        }
      }
      return null
    }
    doNavigateValueSet(e, n) {
      const r = this.numberReplace(e, n);
      return r !== null ? r : this.textReplace(e, n)
    }
    numberReplace(e, n) {
      const r = Math.pow(10, e.length - (e.lastIndexOf(".") + 1));
      let i = Number(e);
      const s = parseFloat(e);
      return !isNaN(i) && !isNaN(s) && i === s ? i === 0 && !n ? null : (i = Math.floor(i * r), i += n ? r : -r, String(i / r)) : null
    }
    textReplace(e, n) {
      return this.valueSetsReplace(this._defaultValueSet, e, n)
    }
    valueSetsReplace(e, n, r) {
      let i = null;
      for (let s = 0, a = e.length; i === null && s < a; s++) i = this.valueSetReplace(e[s], n, r);
      return i
    }
    valueSetReplace(e, n, r) {
      let i = e.indexOf(n);
      return i >= 0 ? (i += r ? 1 : -1, i < 0 ? i = e.length - 1 : i %= e.length, e[i]) : null
    }
  };
  Un.INSTANCE = new Un;
  let ur = Un;
  const Ni = Object.freeze(function(t, e) {
    const n = setTimeout(t.bind(e), 0);
    return {
      dispose() {
        clearTimeout(n)
      }
    }
  });
  var yn;
  (function(t) {
    function e(n) {
      return n === t.None || n === t.Cancelled || n instanceof wn ? !0 : !n || typeof n != "object" ? !1 : typeof n.isCancellationRequested == "boolean" && typeof n.onCancellationRequested == "function"
    }
    t.isCancellationToken = e, t.None = Object.freeze({
      isCancellationRequested: !1,
      onCancellationRequested: Xn.None
    }), t.Cancelled = Object.freeze({
      isCancellationRequested: !0,
      onCancellationRequested: Ni
    })
  })(yn || (yn = {}));
  class wn {
    constructor() {
      this._isCancelled = !1, this._emitter = null
    }
    cancel() {
      this._isCancelled || (this._isCancelled = !0, this._emitter && (this._emitter.fire(void 0), this.dispose()))
    }
    get isCancellationRequested() {
      return this._isCancelled
    }
    get onCancellationRequested() {
      return this._isCancelled ? Ni : (this._emitter || (this._emitter = new Ce), this._emitter.event)
    }
    dispose() {
      this._emitter && (this._emitter.dispose(), this._emitter = null)
    }
  }
  class Wl {
    constructor(e) {
      this._token = void 0, this._parentListener = void 0, this._parentListener = e && e.onCancellationRequested(this.cancel, this)
    }
    get token() {
      return this._token || (this._token = new wn), this._token
    }
    cancel() {
      this._token ? this._token instanceof wn && this._token.cancel() : this._token = yn.Cancelled
    }
    dispose(e = !1) {
      var n;
      e && this.cancel(), (n = this._parentListener) == null || n.dispose(), this._token ? this._token instanceof wn && this._token.dispose() : this._token = yn.None
    }
  }
  class cr {
    constructor() {
      this._keyCodeToStr = [], this._strToKeyCode = Object.create(null)
    }
    define(e, n) {
      this._keyCodeToStr[e] = n, this._strToKeyCode[n.toLowerCase()] = e
    }
    keyCodeToStr(e) {
      return this._keyCodeToStr[e]
    }
    strToKeyCode(e) {
      return this._strToKeyCode[e.toLowerCase()] || 0
    }
  }
  const xn = new cr,
    fr = new cr,
    hr = new cr,
    Hl = new Array(230),
    zl = Object.create(null),
    Gl = Object.create(null);
  (function() {
    const e = [
        [1, 0, "None", 0, "unknown", 0, "VK_UNKNOWN", "", ""],
        [1, 1, "Hyper", 0, "", 0, "", "", ""],
        [1, 2, "Super", 0, "", 0, "", "", ""],
        [1, 3, "Fn", 0, "", 0, "", "", ""],
        [1, 4, "FnLock", 0, "", 0, "", "", ""],
        [1, 5, "Suspend", 0, "", 0, "", "", ""],
        [1, 6, "Resume", 0, "", 0, "", "", ""],
        [1, 7, "Turbo", 0, "", 0, "", "", ""],
        [1, 8, "Sleep", 0, "", 0, "VK_SLEEP", "", ""],
        [1, 9, "WakeUp", 0, "", 0, "", "", ""],
        [0, 10, "KeyA", 31, "A", 65, "VK_A", "", ""],
        [0, 11, "KeyB", 32, "B", 66, "VK_B", "", ""],
        [0, 12, "KeyC", 33, "C", 67, "VK_C", "", ""],
        [0, 13, "KeyD", 34, "D", 68, "VK_D", "", ""],
        [0, 14, "KeyE", 35, "E", 69, "VK_E", "", ""],
        [0, 15, "KeyF", 36, "F", 70, "VK_F", "", ""],
        [0, 16, "KeyG", 37, "G", 71, "VK_G", "", ""],
        [0, 17, "KeyH", 38, "H", 72, "VK_H", "", ""],
        [0, 18, "KeyI", 39, "I", 73, "VK_I", "", ""],
        [0, 19, "KeyJ", 40, "J", 74, "VK_J", "", ""],
        [0, 20, "KeyK", 41, "K", 75, "VK_K", "", ""],
        [0, 21, "KeyL", 42, "L", 76, "VK_L", "", ""],
        [0, 22, "KeyM", 43, "M", 77, "VK_M", "", ""],
        [0, 23, "KeyN", 44, "N", 78, "VK_N", "", ""],
        [0, 24, "KeyO", 45, "O", 79, "VK_O", "", ""],
        [0, 25, "KeyP", 46, "P", 80, "VK_P", "", ""],
        [0, 26, "KeyQ", 47, "Q", 81, "VK_Q", "", ""],
        [0, 27, "KeyR", 48, "R", 82, "VK_R", "", ""],
        [0, 28, "KeyS", 49, "S", 83, "VK_S", "", ""],
        [0, 29, "KeyT", 50, "T", 84, "VK_T", "", ""],
        [0, 30, "KeyU", 51, "U", 85, "VK_U", "", ""],
        [0, 31, "KeyV", 52, "V", 86, "VK_V", "", ""],
        [0, 32, "KeyW", 53, "W", 87, "VK_W", "", ""],
        [0, 33, "KeyX", 54, "X", 88, "VK_X", "", ""],
        [0, 34, "KeyY", 55, "Y", 89, "VK_Y", "", ""],
        [0, 35, "KeyZ", 56, "Z", 90, "VK_Z", "", ""],
        [0, 36, "Digit1", 22, "1", 49, "VK_1", "", ""],
        [0, 37, "Digit2", 23, "2", 50, "VK_2", "", ""],
        [0, 38, "Digit3", 24, "3", 51, "VK_3", "", ""],
        [0, 39, "Digit4", 25, "4", 52, "VK_4", "", ""],
        [0, 40, "Digit5", 26, "5", 53, "VK_5", "", ""],
        [0, 41, "Digit6", 27, "6", 54, "VK_6", "", ""],
        [0, 42, "Digit7", 28, "7", 55, "VK_7", "", ""],
        [0, 43, "Digit8", 29, "8", 56, "VK_8", "", ""],
        [0, 44, "Digit9", 30, "9", 57, "VK_9", "", ""],
        [0, 45, "Digit0", 21, "0", 48, "VK_0", "", ""],
        [1, 46, "Enter", 3, "Enter", 13, "VK_RETURN", "", ""],
        [1, 47, "Escape", 9, "Escape", 27, "VK_ESCAPE", "", ""],
        [1, 48, "Backspace", 1, "Backspace", 8, "VK_BACK", "", ""],
        [1, 49, "Tab", 2, "Tab", 9, "VK_TAB", "", ""],
        [1, 50, "Space", 10, "Space", 32, "VK_SPACE", "", ""],
        [0, 51, "Minus", 88, "-", 189, "VK_OEM_MINUS", "-", "OEM_MINUS"],
        [0, 52, "Equal", 86, "=", 187, "VK_OEM_PLUS", "=", "OEM_PLUS"],
        [0, 53, "BracketLeft", 92, "[", 219, "VK_OEM_4", "[", "OEM_4"],
        [0, 54, "BracketRight", 94, "]", 221, "VK_OEM_6", "]", "OEM_6"],
        [0, 55, "Backslash", 93, "\\", 220, "VK_OEM_5", "\\", "OEM_5"],
        [0, 56, "IntlHash", 0, "", 0, "", "", ""],
        [0, 57, "Semicolon", 85, ";", 186, "VK_OEM_1", ";", "OEM_1"],
        [0, 58, "Quote", 95, "'", 222, "VK_OEM_7", "'", "OEM_7"],
        [0, 59, "Backquote", 91, "`", 192, "VK_OEM_3", "`", "OEM_3"],
        [0, 60, "Comma", 87, ",", 188, "VK_OEM_COMMA", ",", "OEM_COMMA"],
        [0, 61, "Period", 89, ".", 190, "VK_OEM_PERIOD", ".", "OEM_PERIOD"],
        [0, 62, "Slash", 90, "/", 191, "VK_OEM_2", "/", "OEM_2"],
        [1, 63, "CapsLock", 8, "CapsLock", 20, "VK_CAPITAL", "", ""],
        [1, 64, "F1", 59, "F1", 112, "VK_F1", "", ""],
        [1, 65, "F2", 60, "F2", 113, "VK_F2", "", ""],
        [1, 66, "F3", 61, "F3", 114, "VK_F3", "", ""],
        [1, 67, "F4", 62, "F4", 115, "VK_F4", "", ""],
        [1, 68, "F5", 63, "F5", 116, "VK_F5", "", ""],
        [1, 69, "F6", 64, "F6", 117, "VK_F6", "", ""],
        [1, 70, "F7", 65, "F7", 118, "VK_F7", "", ""],
        [1, 71, "F8", 66, "F8", 119, "VK_F8", "", ""],
        [1, 72, "F9", 67, "F9", 120, "VK_F9", "", ""],
        [1, 73, "F10", 68, "F10", 121, "VK_F10", "", ""],
        [1, 74, "F11", 69, "F11", 122, "VK_F11", "", ""],
        [1, 75, "F12", 70, "F12", 123, "VK_F12", "", ""],
        [1, 76, "PrintScreen", 0, "", 0, "", "", ""],
        [1, 77, "ScrollLock", 84, "ScrollLock", 145, "VK_SCROLL", "", ""],
        [1, 78, "Pause", 7, "PauseBreak", 19, "VK_PAUSE", "", ""],
        [1, 79, "Insert", 19, "Insert", 45, "VK_INSERT", "", ""],
        [1, 80, "Home", 14, "Home", 36, "VK_HOME", "", ""],
        [1, 81, "PageUp", 11, "PageUp", 33, "VK_PRIOR", "", ""],
        [1, 82, "Delete", 20, "Delete", 46, "VK_DELETE", "", ""],
        [1, 83, "End", 13, "End", 35, "VK_END", "", ""],
        [1, 84, "PageDown", 12, "PageDown", 34, "VK_NEXT", "", ""],
        [1, 85, "ArrowRight", 17, "RightArrow", 39, "VK_RIGHT", "Right", ""],
        [1, 86, "ArrowLeft", 15, "LeftArrow", 37, "VK_LEFT", "Left", ""],
        [1, 87, "ArrowDown", 18, "DownArrow", 40, "VK_DOWN", "Down", ""],
        [1, 88, "ArrowUp", 16, "UpArrow", 38, "VK_UP", "Up", ""],
        [1, 89, "NumLock", 83, "NumLock", 144, "VK_NUMLOCK", "", ""],
        [1, 90, "NumpadDivide", 113, "NumPad_Divide", 111, "VK_DIVIDE", "", ""],
        [1, 91, "NumpadMultiply", 108, "NumPad_Multiply", 106, "VK_MULTIPLY", "", ""],
        [1, 92, "NumpadSubtract", 111, "NumPad_Subtract", 109, "VK_SUBTRACT", "", ""],
        [1, 93, "NumpadAdd", 109, "NumPad_Add", 107, "VK_ADD", "", ""],
        [1, 94, "NumpadEnter", 3, "", 0, "", "", ""],
        [1, 95, "Numpad1", 99, "NumPad1", 97, "VK_NUMPAD1", "", ""],
        [1, 96, "Numpad2", 100, "NumPad2", 98, "VK_NUMPAD2", "", ""],
        [1, 97, "Numpad3", 101, "NumPad3", 99, "VK_NUMPAD3", "", ""],
        [1, 98, "Numpad4", 102, "NumPad4", 100, "VK_NUMPAD4", "", ""],
        [1, 99, "Numpad5", 103, "NumPad5", 101, "VK_NUMPAD5", "", ""],
        [1, 100, "Numpad6", 104, "NumPad6", 102, "VK_NUMPAD6", "", ""],
        [1, 101, "Numpad7", 105, "NumPad7", 103, "VK_NUMPAD7", "", ""],
        [1, 102, "Numpad8", 106, "NumPad8", 104, "VK_NUMPAD8", "", ""],
        [1, 103, "Numpad9", 107, "NumPad9", 105, "VK_NUMPAD9", "", ""],
        [1, 104, "Numpad0", 98, "NumPad0", 96, "VK_NUMPAD0", "", ""],
        [1, 105, "NumpadDecimal", 112, "NumPad_Decimal", 110, "VK_DECIMAL", "", ""],
        [0, 106, "IntlBackslash", 97, "OEM_102", 226, "VK_OEM_102", "", ""],
        [1, 107, "ContextMenu", 58, "ContextMenu", 93, "", "", ""],
        [1, 108, "Power", 0, "", 0, "", "", ""],
        [1, 109, "NumpadEqual", 0, "", 0, "", "", ""],
        [1, 110, "F13", 71, "F13", 124, "VK_F13", "", ""],
        [1, 111, "F14", 72, "F14", 125, "VK_F14", "", ""],
        [1, 112, "F15", 73, "F15", 126, "VK_F15", "", ""],
        [1, 113, "F16", 74, "F16", 127, "VK_F16", "", ""],
        [1, 114, "F17", 75, "F17", 128, "VK_F17", "", ""],
        [1, 115, "F18", 76, "F18", 129, "VK_F18", "", ""],
        [1, 116, "F19", 77, "F19", 130, "VK_F19", "", ""],
        [1, 117, "F20", 78, "F20", 131, "VK_F20", "", ""],
        [1, 118, "F21", 79, "F21", 132, "VK_F21", "", ""],
        [1, 119, "F22", 80, "F22", 133, "VK_F22", "", ""],
        [1, 120, "F23", 81, "F23", 134, "VK_F23", "", ""],
        [1, 121, "F24", 82, "F24", 135, "VK_F24", "", ""],
        [1, 122, "Open", 0, "", 0, "", "", ""],
        [1, 123, "Help", 0, "", 0, "", "", ""],
        [1, 124, "Select", 0, "", 0, "", "", ""],
        [1, 125, "Again", 0, "", 0, "", "", ""],
        [1, 126, "Undo", 0, "", 0, "", "", ""],
        [1, 127, "Cut", 0, "", 0, "", "", ""],
        [1, 128, "Copy", 0, "", 0, "", "", ""],
        [1, 129, "Paste", 0, "", 0, "", "", ""],
        [1, 130, "Find", 0, "", 0, "", "", ""],
        [1, 131, "AudioVolumeMute", 117, "AudioVolumeMute", 173, "VK_VOLUME_MUTE", "", ""],
        [1, 132, "AudioVolumeUp", 118, "AudioVolumeUp", 175, "VK_VOLUME_UP", "", ""],
        [1, 133, "AudioVolumeDown", 119, "AudioVolumeDown", 174, "VK_VOLUME_DOWN", "", ""],
        [1, 134, "NumpadComma", 110, "NumPad_Separator", 108, "VK_SEPARATOR", "", ""],
        [0, 135, "IntlRo", 115, "ABNT_C1", 193, "VK_ABNT_C1", "", ""],
        [1, 136, "KanaMode", 0, "", 0, "", "", ""],
        [0, 137, "IntlYen", 0, "", 0, "", "", ""],
        [1, 138, "Convert", 0, "", 0, "", "", ""],
        [1, 139, "NonConvert", 0, "", 0, "", "", ""],
        [1, 140, "Lang1", 0, "", 0, "", "", ""],
        [1, 141, "Lang2", 0, "", 0, "", "", ""],
        [1, 142, "Lang3", 0, "", 0, "", "", ""],
        [1, 143, "Lang4", 0, "", 0, "", "", ""],
        [1, 144, "Lang5", 0, "", 0, "", "", ""],
        [1, 145, "Abort", 0, "", 0, "", "", ""],
        [1, 146, "Props", 0, "", 0, "", "", ""],
        [1, 147, "NumpadParenLeft", 0, "", 0, "", "", ""],
        [1, 148, "NumpadParenRight", 0, "", 0, "", "", ""],
        [1, 149, "NumpadBackspace", 0, "", 0, "", "", ""],
        [1, 150, "NumpadMemoryStore", 0, "", 0, "", "", ""],
        [1, 151, "NumpadMemoryRecall", 0, "", 0, "", "", ""],
        [1, 152, "NumpadMemoryClear", 0, "", 0, "", "", ""],
        [1, 153, "NumpadMemoryAdd", 0, "", 0, "", "", ""],
        [1, 154, "NumpadMemorySubtract", 0, "", 0, "", "", ""],
        [1, 155, "NumpadClear", 131, "Clear", 12, "VK_CLEAR", "", ""],
        [1, 156, "NumpadClearEntry", 0, "", 0, "", "", ""],
        [1, 0, "", 5, "Ctrl", 17, "VK_CONTROL", "", ""],
        [1, 0, "", 4, "Shift", 16, "VK_SHIFT", "", ""],
        [1, 0, "", 6, "Alt", 18, "VK_MENU", "", ""],
        [1, 0, "", 57, "Meta", 91, "VK_COMMAND", "", ""],
        [1, 157, "ControlLeft", 5, "", 0, "VK_LCONTROL", "", ""],
        [1, 158, "ShiftLeft", 4, "", 0, "VK_LSHIFT", "", ""],
        [1, 159, "AltLeft", 6, "", 0, "VK_LMENU", "", ""],
        [1, 160, "MetaLeft", 57, "", 0, "VK_LWIN", "", ""],
        [1, 161, "ControlRight", 5, "", 0, "VK_RCONTROL", "", ""],
        [1, 162, "ShiftRight", 4, "", 0, "VK_RSHIFT", "", ""],
        [1, 163, "AltRight", 6, "", 0, "VK_RMENU", "", ""],
        [1, 164, "MetaRight", 57, "", 0, "VK_RWIN", "", ""],
        [1, 165, "BrightnessUp", 0, "", 0, "", "", ""],
        [1, 166, "BrightnessDown", 0, "", 0, "", "", ""],
        [1, 167, "MediaPlay", 0, "", 0, "", "", ""],
        [1, 168, "MediaRecord", 0, "", 0, "", "", ""],
        [1, 169, "MediaFastForward", 0, "", 0, "", "", ""],
        [1, 170, "MediaRewind", 0, "", 0, "", "", ""],
        [1, 171, "MediaTrackNext", 124, "MediaTrackNext", 176, "VK_MEDIA_NEXT_TRACK", "", ""],
        [1, 172, "MediaTrackPrevious", 125, "MediaTrackPrevious", 177, "VK_MEDIA_PREV_TRACK", "", ""],
        [1, 173, "MediaStop", 126, "MediaStop", 178, "VK_MEDIA_STOP", "", ""],
        [1, 174, "Eject", 0, "", 0, "", "", ""],
        [1, 175, "MediaPlayPause", 127, "MediaPlayPause", 179, "VK_MEDIA_PLAY_PAUSE", "", ""],
        [1, 176, "MediaSelect", 128, "LaunchMediaPlayer", 181, "VK_MEDIA_LAUNCH_MEDIA_SELECT", "", ""],
        [1, 177, "LaunchMail", 129, "LaunchMail", 180, "VK_MEDIA_LAUNCH_MAIL", "", ""],
        [1, 178, "LaunchApp2", 130, "LaunchApp2", 183, "VK_MEDIA_LAUNCH_APP2", "", ""],
        [1, 179, "LaunchApp1", 0, "", 0, "VK_MEDIA_LAUNCH_APP1", "", ""],
        [1, 180, "SelectTask", 0, "", 0, "", "", ""],
        [1, 181, "LaunchScreenSaver", 0, "", 0, "", "", ""],
        [1, 182, "BrowserSearch", 120, "BrowserSearch", 170, "VK_BROWSER_SEARCH", "", ""],
        [1, 183, "BrowserHome", 121, "BrowserHome", 172, "VK_BROWSER_HOME", "", ""],
        [1, 184, "BrowserBack", 122, "BrowserBack", 166, "VK_BROWSER_BACK", "", ""],
        [1, 185, "BrowserForward", 123, "BrowserForward", 167, "VK_BROWSER_FORWARD", "", ""],
        [1, 186, "BrowserStop", 0, "", 0, "VK_BROWSER_STOP", "", ""],
        [1, 187, "BrowserRefresh", 0, "", 0, "VK_BROWSER_REFRESH", "", ""],
        [1, 188, "BrowserFavorites", 0, "", 0, "VK_BROWSER_FAVORITES", "", ""],
        [1, 189, "ZoomToggle", 0, "", 0, "", "", ""],
        [1, 190, "MailReply", 0, "", 0, "", "", ""],
        [1, 191, "MailForward", 0, "", 0, "", "", ""],
        [1, 192, "MailSend", 0, "", 0, "", "", ""],
        [1, 0, "", 114, "KeyInComposition", 229, "", "", ""],
        [1, 0, "", 116, "ABNT_C2", 194, "VK_ABNT_C2", "", ""],
        [1, 0, "", 96, "OEM_8", 223, "VK_OEM_8", "", ""],
        [1, 0, "", 0, "", 0, "VK_KANA", "", ""],
        [1, 0, "", 0, "", 0, "VK_HANGUL", "", ""],
        [1, 0, "", 0, "", 0, "VK_JUNJA", "", ""],
        [1, 0, "", 0, "", 0, "VK_FINAL", "", ""],
        [1, 0, "", 0, "", 0, "VK_HANJA", "", ""],
        [1, 0, "", 0, "", 0, "VK_KANJI", "", ""],
        [1, 0, "", 0, "", 0, "VK_CONVERT", "", ""],
        [1, 0, "", 0, "", 0, "VK_NONCONVERT", "", ""],
        [1, 0, "", 0, "", 0, "VK_ACCEPT", "", ""],
        [1, 0, "", 0, "", 0, "VK_MODECHANGE", "", ""],
        [1, 0, "", 0, "", 0, "VK_SELECT", "", ""],
        [1, 0, "", 0, "", 0, "VK_PRINT", "", ""],
        [1, 0, "", 0, "", 0, "VK_EXECUTE", "", ""],
        [1, 0, "", 0, "", 0, "VK_SNAPSHOT", "", ""],
        [1, 0, "", 0, "", 0, "VK_HELP", "", ""],
        [1, 0, "", 0, "", 0, "VK_APPS", "", ""],
        [1, 0, "", 0, "", 0, "VK_PROCESSKEY", "", ""],
        [1, 0, "", 0, "", 0, "VK_PACKET", "", ""],
        [1, 0, "", 0, "", 0, "VK_DBE_SBCSCHAR", "", ""],
        [1, 0, "", 0, "", 0, "VK_DBE_DBCSCHAR", "", ""],
        [1, 0, "", 0, "", 0, "VK_ATTN", "", ""],
        [1, 0, "", 0, "", 0, "VK_CRSEL", "", ""],
        [1, 0, "", 0, "", 0, "VK_EXSEL", "", ""],
        [1, 0, "", 0, "", 0, "VK_EREOF", "", ""],
        [1, 0, "", 0, "", 0, "VK_PLAY", "", ""],
        [1, 0, "", 0, "", 0, "VK_ZOOM", "", ""],
        [1, 0, "", 0, "", 0, "VK_NONAME", "", ""],
        [1, 0, "", 0, "", 0, "VK_PA1", "", ""],
        [1, 0, "", 0, "", 0, "VK_OEM_CLEAR", "", ""]
      ],
      n = [],
      r = [];
    for (const i of e) {
      const [s, a, o, u, l, h, f, m, g] = i;
      if (r[a] || (r[a] = !0, zl[o] = a, Gl[o.toLowerCase()] = a), !n[u]) {
        if (n[u] = !0, !l) throw new Error(`String representation missing for key code ${u} around scan code ${o}`);
        xn.define(u, l), fr.define(u, m || l), hr.define(u, g || m || l)
      }
      h && (Hl[h] = u)
    }
  })();
  var _i;
  (function(t) {
    function e(o) {
      return xn.keyCodeToStr(o)
    }
    t.toString = e;

    function n(o) {
      return xn.strToKeyCode(o)
    }
    t.fromString = n;

    function r(o) {
      return fr.keyCodeToStr(o)
    }
    t.toUserSettingsUS = r;

    function i(o) {
      return hr.keyCodeToStr(o)
    }
    t.toUserSettingsGeneral = i;

    function s(o) {
      return fr.strToKeyCode(o) || hr.strToKeyCode(o)
    }
    t.fromUserSettings = s;

    function a(o) {
      if (o >= 98 && o <= 113) return null;
      switch (o) {
        case 16:
          return "Up";
        case 18:
          return "Down";
        case 15:
          return "Left";
        case 17:
          return "Right"
      }
      return xn.keyCodeToStr(o)
    }
    t.toElectronAccelerator = a
  })(_i || (_i = {}));

  function Jl(t, e) {
    const n = (e & 65535) << 16 >>> 0;
    return (t | n) >>> 0
  }
  var Si = {};
  let vt;
  const mr = globalThis.vscode;
  if (typeof mr < "u" && typeof mr.process < "u") {
    const t = mr.process;
    vt = {
      get platform() {
        return t.platform
      },
      get arch() {
        return t.arch
      },
      get env() {
        return t.env
      },
      cwd() {
        return t.cwd()
      }
    }
  } else typeof process < "u" && typeof((zo = process == null ? void 0 : process.versions) == null ? void 0 : zo.node) == "string" ? vt = {
    get platform() {
      return process.platform
    },
    get arch() {
      return process.arch
    },
    get env() {
      return Si
    },
    cwd() {
      return Si.VSCODE_CWD || process.cwd()
    }
  } : vt = {
    get platform() {
      return Wt ? "win32" : hl ? "darwin" : "linux"
    },
    get arch() {},
    get env() {
      return {}
    },
    cwd() {
      return "/"
    }
  };
  const vn = vt.cwd,
    Xl = vt.env,
    Ql = vt.platform,
    Zl = 65,
    Yl = 97,
    Kl = 90,
    eu = 122,
    ot = 46,
    oe = 47,
    de = 92,
    qe = 58,
    tu = 63;
  class Ai extends Error {
    constructor(e, n, r) {
      let i;
      typeof n == "string" && n.indexOf("not ") === 0 ? (i = "must not be", n = n.replace(/^not /, "")) : i = "must be";
      const s = e.indexOf(".") !== -1 ? "property" : "argument";
      let a = `The "${e}" ${s} ${i} of type ${n}`;
      a += `. Received type ${typeof r}`, super(a), this.code = "ERR_INVALID_ARG_TYPE"
    }
  }

  function nu(t, e) {
    if (t === null || typeof t != "object") throw new Ai(e, "Object", t)
  }

  function te(t, e) {
    if (typeof t != "string") throw new Ai(e, "string", t)
  }
  const Qe = Ql === "win32";

  function q(t) {
    return t === oe || t === de
  }

  function dr(t) {
    return t === oe
  }

  function je(t) {
    return t >= Zl && t <= Kl || t >= Yl && t <= eu
  }

  function Ln(t, e, n, r) {
    let i = "",
      s = 0,
      a = -1,
      o = 0,
      u = 0;
    for (let l = 0; l <= t.length; ++l) {
      if (l < t.length) u = t.charCodeAt(l);
      else {
        if (r(u)) break;
        u = oe
      }
      if (r(u)) {
        if (!(a === l - 1 || o === 1))
          if (o === 2) {
            if (i.length < 2 || s !== 2 || i.charCodeAt(i.length - 1) !== ot || i.charCodeAt(i.length - 2) !== ot) {
              if (i.length > 2) {
                const h = i.lastIndexOf(n);
                h === -1 ? (i = "", s = 0) : (i = i.slice(0, h), s = i.length - 1 - i.lastIndexOf(n)), a = l, o = 0;
                continue
              } else if (i.length !== 0) {
                i = "", s = 0, a = l, o = 0;
                continue
              }
            }
            e && (i += i.length > 0 ? `${n}..` : "..", s = 2)
          } else i.length > 0 ? i += `${n}${t.slice(a+1,l)}` : i = t.slice(a + 1, l), s = l - a - 1;
        a = l, o = 0
      } else u === ot && o !== -1 ? ++o : o = -1
    }
    return i
  }

  function ru(t) {
    return t ? `${t[0]==="."?"":"."}${t}` : ""
  }

  function ki(t, e) {
    nu(e, "pathObject");
    const n = e.dir || e.root,
      r = e.base || `${e.name||""}${ru(e.ext)}`;
    return n ? n === e.root ? `${n}${r}` : `${n}${t}${r}` : r
  }
  const he = {
      resolve(...t) {
        let e = "",
          n = "",
          r = !1;
        for (let i = t.length - 1; i >= -1; i--) {
          let s;
          if (i >= 0) {
            if (s = t[i], te(s, `paths[${i}]`), s.length === 0) continue
          } else e.length === 0 ? s = vn() : (s = Xl[`=${e}`] || vn(), (s === void 0 || s.slice(0, 2).toLowerCase() !== e.toLowerCase() && s.charCodeAt(2) === de) && (s = `${e}\\`));
          const a = s.length;
          let o = 0,
            u = "",
            l = !1;
          const h = s.charCodeAt(0);
          if (a === 1) q(h) && (o = 1, l = !0);
          else if (q(h))
            if (l = !0, q(s.charCodeAt(1))) {
              let f = 2,
                m = f;
              for (; f < a && !q(s.charCodeAt(f));) f++;
              if (f < a && f !== m) {
                const g = s.slice(m, f);
                for (m = f; f < a && q(s.charCodeAt(f));) f++;
                if (f < a && f !== m) {
                  for (m = f; f < a && !q(s.charCodeAt(f));) f++;
                  (f === a || f !== m) && (u = `\\\\${g}\\${s.slice(m,f)}`, o = f)
                }
              }
            } else o = 1;
          else je(h) && s.charCodeAt(1) === qe && (u = s.slice(0, 2), o = 2, a > 2 && q(s.charCodeAt(2)) && (l = !0, o = 3));
          if (u.length > 0)
            if (e.length > 0) {
              if (u.toLowerCase() !== e.toLowerCase()) continue
            } else e = u;
          if (r) {
            if (e.length > 0) break
          } else if (n = `${s.slice(o)}\\${n}`, r = l, l && e.length > 0) break
        }
        return n = Ln(n, !r, "\\", q), r ? `${e}\\${n}` : `${e}${n}` || "."
      },
      normalize(t) {
        te(t, "path");
        const e = t.length;
        if (e === 0) return ".";
        let n = 0,
          r, i = !1;
        const s = t.charCodeAt(0);
        if (e === 1) return dr(s) ? "\\" : t;
        if (q(s))
          if (i = !0, q(t.charCodeAt(1))) {
            let o = 2,
              u = o;
            for (; o < e && !q(t.charCodeAt(o));) o++;
            if (o < e && o !== u) {
              const l = t.slice(u, o);
              for (u = o; o < e && q(t.charCodeAt(o));) o++;
              if (o < e && o !== u) {
                for (u = o; o < e && !q(t.charCodeAt(o));) o++;
                if (o === e) return `\\\\${l}\\${t.slice(u)}\\`;
                o !== u && (r = `\\\\${l}\\${t.slice(u,o)}`, n = o)
              }
            }
          } else n = 1;
        else je(s) && t.charCodeAt(1) === qe && (r = t.slice(0, 2), n = 2, e > 2 && q(t.charCodeAt(2)) && (i = !0, n = 3));
        let a = n < e ? Ln(t.slice(n), !i, "\\", q) : "";
        if (a.length === 0 && !i && (a = "."), a.length > 0 && q(t.charCodeAt(e - 1)) && (a += "\\"), !i && r === void 0 && t.includes(":")) {
          if (a.length >= 2 && je(a.charCodeAt(0)) && a.charCodeAt(1) === qe) return `.\\${a}`;
          let o = t.indexOf(":");
          do
            if (o === e - 1 || q(t.charCodeAt(o + 1))) return `.\\${a}`; while ((o = t.indexOf(":", o + 1)) !== -1)
        }
        return r === void 0 ? i ? `\\${a}` : a : i ? `${r}\\${a}` : `${r}${a}`
      },
      isAbsolute(t) {
        te(t, "path");
        const e = t.length;
        if (e === 0) return !1;
        const n = t.charCodeAt(0);
        return q(n) || e > 2 && je(n) && t.charCodeAt(1) === qe && q(t.charCodeAt(2))
      },
      join(...t) {
        if (t.length === 0) return ".";
        let e, n;
        for (let s = 0; s < t.length; ++s) {
          const a = t[s];
          te(a, "path"), a.length > 0 && (e === void 0 ? e = n = a : e += `\\${a}`)
        }
        if (e === void 0) return ".";
        let r = !0,
          i = 0;
        if (typeof n == "string" && q(n.charCodeAt(0))) {
          ++i;
          const s = n.length;
          s > 1 && q(n.charCodeAt(1)) && (++i, s > 2 && (q(n.charCodeAt(2)) ? ++i : r = !1))
        }
        if (r) {
          for (; i < e.length && q(e.charCodeAt(i));) i++;
          i >= 2 && (e = `\\${e.slice(i)}`)
        }
        return he.normalize(e)
      },
      relative(t, e) {
        if (te(t, "from"), te(e, "to"), t === e) return "";
        const n = he.resolve(t),
          r = he.resolve(e);
        if (n === r || (t = n.toLowerCase(), e = r.toLowerCase(), t === e)) return "";
        if (n.length !== t.length || r.length !== e.length) {
          const d = n.split("\\"),
            p = r.split("\\");
          d[d.length - 1] === "" && d.pop(), p[p.length - 1] === "" && p.pop();
          const y = d.length,
            w = p.length,
            N = y < w ? y : w;
          let b;
          for (b = 0; b < N && d[b].toLowerCase() === p[b].toLowerCase(); b++);
          return b === 0 ? r : b === N ? w > N ? p.slice(b).join("\\") : y > N ? "..\\".repeat(y - 1 - b) + ".." : "" : "..\\".repeat(y - b) + p.slice(b).join("\\")
        }
        let i = 0;
        for (; i < t.length && t.charCodeAt(i) === de;) i++;
        let s = t.length;
        for (; s - 1 > i && t.charCodeAt(s - 1) === de;) s--;
        const a = s - i;
        let o = 0;
        for (; o < e.length && e.charCodeAt(o) === de;) o++;
        let u = e.length;
        for (; u - 1 > o && e.charCodeAt(u - 1) === de;) u--;
        const l = u - o,
          h = a < l ? a : l;
        let f = -1,
          m = 0;
        for (; m < h; m++) {
          const d = t.charCodeAt(i + m);
          if (d !== e.charCodeAt(o + m)) break;
          d === de && (f = m)
        }
        if (m !== h) {
          if (f === -1) return r
        } else {
          if (l > h) {
            if (e.charCodeAt(o + m) === de) return r.slice(o + m + 1);
            if (m === 2) return r.slice(o + m)
          }
          a > h && (t.charCodeAt(i + m) === de ? f = m : m === 2 && (f = 3)), f === -1 && (f = 0)
        }
        let g = "";
        for (m = i + f + 1; m <= s; ++m)(m === s || t.charCodeAt(m) === de) && (g += g.length === 0 ? ".." : "\\..");
        return o += f, g.length > 0 ? `${g}${r.slice(o,u)}` : (r.charCodeAt(o) === de && ++o, r.slice(o, u))
      },
      toNamespacedPath(t) {
        if (typeof t != "string" || t.length === 0) return t;
        const e = he.resolve(t);
        if (e.length <= 2) return t;
        if (e.charCodeAt(0) === de) {
          if (e.charCodeAt(1) === de) {
            const n = e.charCodeAt(2);
            if (n !== tu && n !== ot) return `\\\\?\\UNC\\${e.slice(2)}`
          }
        } else if (je(e.charCodeAt(0)) && e.charCodeAt(1) === qe && e.charCodeAt(2) === de) return `\\\\?\\${e}`;
        return e
      },
      dirname(t) {
        te(t, "path");
        const e = t.length;
        if (e === 0) return ".";
        let n = -1,
          r = 0;
        const i = t.charCodeAt(0);
        if (e === 1) return q(i) ? t : ".";
        if (q(i)) {
          if (n = r = 1, q(t.charCodeAt(1))) {
            let o = 2,
              u = o;
            for (; o < e && !q(t.charCodeAt(o));) o++;
            if (o < e && o !== u) {
              for (u = o; o < e && q(t.charCodeAt(o));) o++;
              if (o < e && o !== u) {
                for (u = o; o < e && !q(t.charCodeAt(o));) o++;
                if (o === e) return t;
                o !== u && (n = r = o + 1)
              }
            }
          }
        } else je(i) && t.charCodeAt(1) === qe && (n = e > 2 && q(t.charCodeAt(2)) ? 3 : 2, r = n);
        let s = -1,
          a = !0;
        for (let o = e - 1; o >= r; --o)
          if (q(t.charCodeAt(o))) {
            if (!a) {
              s = o;
              break
            }
          } else a = !1;
        if (s === -1) {
          if (n === -1) return ".";
          s = n
        }
        return t.slice(0, s)
      },
      basename(t, e) {
        e !== void 0 && te(e, "suffix"), te(t, "path");
        let n = 0,
          r = -1,
          i = !0,
          s;
        if (t.length >= 2 && je(t.charCodeAt(0)) && t.charCodeAt(1) === qe && (n = 2), e !== void 0 && e.length > 0 && e.length <= t.length) {
          if (e === t) return "";
          let a = e.length - 1,
            o = -1;
          for (s = t.length - 1; s >= n; --s) {
            const u = t.charCodeAt(s);
            if (q(u)) {
              if (!i) {
                n = s + 1;
                break
              }
            } else o === -1 && (i = !1, o = s + 1), a >= 0 && (u === e.charCodeAt(a) ? --a === -1 && (r = s) : (a = -1, r = o))
          }
          return n === r ? r = o : r === -1 && (r = t.length), t.slice(n, r)
        }
        for (s = t.length - 1; s >= n; --s)
          if (q(t.charCodeAt(s))) {
            if (!i) {
              n = s + 1;
              break
            }
          } else r === -1 && (i = !1, r = s + 1);
        return r === -1 ? "" : t.slice(n, r)
      },
      extname(t) {
        te(t, "path");
        let e = 0,
          n = -1,
          r = 0,
          i = -1,
          s = !0,
          a = 0;
        t.length >= 2 && t.charCodeAt(1) === qe && je(t.charCodeAt(0)) && (e = r = 2);
        for (let o = t.length - 1; o >= e; --o) {
          const u = t.charCodeAt(o);
          if (q(u)) {
            if (!s) {
              r = o + 1;
              break
            }
            continue
          }
          i === -1 && (s = !1, i = o + 1), u === ot ? n === -1 ? n = o : a !== 1 && (a = 1) : n !== -1 && (a = -1)
        }
        return n === -1 || i === -1 || a === 0 || a === 1 && n === i - 1 && n === r + 1 ? "" : t.slice(n, i)
      },
      format: ki.bind(null, "\\"),
      parse(t) {
        te(t, "path");
        const e = {
          root: "",
          dir: "",
          base: "",
          ext: "",
          name: ""
        };
        if (t.length === 0) return e;
        const n = t.length;
        let r = 0,
          i = t.charCodeAt(0);
        if (n === 1) return q(i) ? (e.root = e.dir = t, e) : (e.base = e.name = t, e);
        if (q(i)) {
          if (r = 1, q(t.charCodeAt(1))) {
            let f = 2,
              m = f;
            for (; f < n && !q(t.charCodeAt(f));) f++;
            if (f < n && f !== m) {
              for (m = f; f < n && q(t.charCodeAt(f));) f++;
              if (f < n && f !== m) {
                for (m = f; f < n && !q(t.charCodeAt(f));) f++;
                f === n ? r = f : f !== m && (r = f + 1)
              }
            }
          }
        } else if (je(i) && t.charCodeAt(1) === qe) {
          if (n <= 2) return e.root = e.dir = t, e;
          if (r = 2, q(t.charCodeAt(2))) {
            if (n === 3) return e.root = e.dir = t, e;
            r = 3
          }
        }
        r > 0 && (e.root = t.slice(0, r));
        let s = -1,
          a = r,
          o = -1,
          u = !0,
          l = t.length - 1,
          h = 0;
        for (; l >= r; --l) {
          if (i = t.charCodeAt(l), q(i)) {
            if (!u) {
              a = l + 1;
              break
            }
            continue
          }
          o === -1 && (u = !1, o = l + 1), i === ot ? s === -1 ? s = l : h !== 1 && (h = 1) : s !== -1 && (h = -1)
        }
        return o !== -1 && (s === -1 || h === 0 || h === 1 && s === o - 1 && s === a + 1 ? e.base = e.name = t.slice(a, o) : (e.name = t.slice(a, s), e.base = t.slice(a, o), e.ext = t.slice(s, o))), a > 0 && a !== r ? e.dir = t.slice(0, a - 1) : e.dir = e.root, e
      },
      sep: "\\",
      delimiter: ";",
      win32: null,
      posix: null
    },
    iu = (() => {
      if (Qe) {
        const t = /\\/g;
        return () => {
          const e = vn().replace(t, "/");
          return e.slice(e.indexOf("/"))
        }
      }
      return () => vn()
    })(),
    ge = {
      resolve(...t) {
        let e = "",
          n = !1;
        for (let r = t.length - 1; r >= 0 && !n; r--) {
          const i = t[r];
          te(i, `paths[${r}]`), i.length !== 0 && (e = `${i}/${e}`, n = i.charCodeAt(0) === oe)
        }
        if (!n) {
          const r = iu();
          e = `${r}/${e}`, n = r.charCodeAt(0) === oe
        }
        return e = Ln(e, !n, "/", dr), n ? `/${e}` : e.length > 0 ? e : "."
      },
      normalize(t) {
        if (te(t, "path"), t.length === 0) return ".";
        const e = t.charCodeAt(0) === oe,
          n = t.charCodeAt(t.length - 1) === oe;
        return t = Ln(t, !e, "/", dr), t.length === 0 ? e ? "/" : n ? "./" : "." : (n && (t += "/"), e ? `/${t}` : t)
      },
      isAbsolute(t) {
        return te(t, "path"), t.length > 0 && t.charCodeAt(0) === oe
      },
      join(...t) {
        if (t.length === 0) return ".";
        const e = [];
        for (let n = 0; n < t.length; ++n) {
          const r = t[n];
          te(r, "path"), r.length > 0 && e.push(r)
        }
        return e.length === 0 ? "." : ge.normalize(e.join("/"))
      },
      relative(t, e) {
        if (te(t, "from"), te(e, "to"), t === e || (t = ge.resolve(t), e = ge.resolve(e), t === e)) return "";
        const n = 1,
          r = t.length,
          i = r - n,
          s = 1,
          a = e.length - s,
          o = i < a ? i : a;
        let u = -1,
          l = 0;
        for (; l < o; l++) {
          const f = t.charCodeAt(n + l);
          if (f !== e.charCodeAt(s + l)) break;
          f === oe && (u = l)
        }
        if (l === o)
          if (a > o) {
            if (e.charCodeAt(s + l) === oe) return e.slice(s + l + 1);
            if (l === 0) return e.slice(s + l)
          } else i > o && (t.charCodeAt(n + l) === oe ? u = l : l === 0 && (u = 0));
        let h = "";
        for (l = n + u + 1; l <= r; ++l)(l === r || t.charCodeAt(l) === oe) && (h += h.length === 0 ? ".." : "/..");
        return `${h}${e.slice(s+u)}`
      },
      toNamespacedPath(t) {
        return t
      },
      dirname(t) {
        if (te(t, "path"), t.length === 0) return ".";
        const e = t.charCodeAt(0) === oe;
        let n = -1,
          r = !0;
        for (let i = t.length - 1; i >= 1; --i)
          if (t.charCodeAt(i) === oe) {
            if (!r) {
              n = i;
              break
            }
          } else r = !1;
        return n === -1 ? e ? "/" : "." : e && n === 1 ? "//" : t.slice(0, n)
      },
      basename(t, e) {
        e !== void 0 && te(e, "suffix"), te(t, "path");
        let n = 0,
          r = -1,
          i = !0,
          s;
        if (e !== void 0 && e.length > 0 && e.length <= t.length) {
          if (e === t) return "";
          let a = e.length - 1,
            o = -1;
          for (s = t.length - 1; s >= 0; --s) {
            const u = t.charCodeAt(s);
            if (u === oe) {
              if (!i) {
                n = s + 1;
                break
              }
            } else o === -1 && (i = !1, o = s + 1), a >= 0 && (u === e.charCodeAt(a) ? --a === -1 && (r = s) : (a = -1, r = o))
          }
          return n === r ? r = o : r === -1 && (r = t.length), t.slice(n, r)
        }
        for (s = t.length - 1; s >= 0; --s)
          if (t.charCodeAt(s) === oe) {
            if (!i) {
              n = s + 1;
              break
            }
          } else r === -1 && (i = !1, r = s + 1);
        return r === -1 ? "" : t.slice(n, r)
      },
      extname(t) {
        te(t, "path");
        let e = -1,
          n = 0,
          r = -1,
          i = !0,
          s = 0;
        for (let a = t.length - 1; a >= 0; --a) {
          const o = t[a];
          if (o === "/") {
            if (!i) {
              n = a + 1;
              break
            }
            continue
          }
          r === -1 && (i = !1, r = a + 1), o === "." ? e === -1 ? e = a : s !== 1 && (s = 1) : e !== -1 && (s = -1)
        }
        return e === -1 || r === -1 || s === 0 || s === 1 && e === r - 1 && e === n + 1 ? "" : t.slice(e, r)
      },
      format: ki.bind(null, "/"),
      parse(t) {
        te(t, "path");
        const e = {
          root: "",
          dir: "",
          base: "",
          ext: "",
          name: ""
        };
        if (t.length === 0) return e;
        const n = t.charCodeAt(0) === oe;
        let r;
        n ? (e.root = "/", r = 1) : r = 0;
        let i = -1,
          s = 0,
          a = -1,
          o = !0,
          u = t.length - 1,
          l = 0;
        for (; u >= r; --u) {
          const h = t.charCodeAt(u);
          if (h === oe) {
            if (!o) {
              s = u + 1;
              break
            }
            continue
          }
          a === -1 && (o = !1, a = u + 1), h === ot ? i === -1 ? i = u : l !== 1 && (l = 1) : i !== -1 && (l = -1)
        }
        if (a !== -1) {
          const h = s === 0 && n ? 1 : s;
          i === -1 || l === 0 || l === 1 && i === a - 1 && i === s + 1 ? e.base = e.name = t.slice(h, a) : (e.name = t.slice(h, i), e.base = t.slice(h, a), e.ext = t.slice(i, a))
        }
        return s > 0 ? e.dir = t.slice(0, s - 1) : n && (e.dir = "/"), e
      },
      sep: "/",
      delimiter: ":",
      win32: null,
      posix: null
    };
  ge.win32 = he.win32 = he, ge.posix = he.posix = ge, Qe ? he.normalize : ge.normalize, Qe ? he.resolve : ge.resolve, Qe ? he.relative : ge.relative, Qe ? he.dirname : ge.dirname, Qe ? he.basename : ge.basename, Qe ? he.extname : ge.extname, Qe ? he.sep : ge.sep;
  const su = /^\w[\w\d+.-]*$/,
    au = /^\//,
    ou = /^\/\//;

  function lu(t, e) {
    if (!t.scheme && e) throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${t.authority}", path: "${t.path}", query: "${t.query}", fragment: "${t.fragment}"}`);
    if (t.scheme && !su.test(t.scheme)) throw new Error("[UriError]: Scheme contains illegal characters.");
    if (t.path) {
      if (t.authority) {
        if (!au.test(t.path)) throw new Error('[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash ("/") character')
      } else if (ou.test(t.path)) throw new Error('[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters ("//")')
    }
  }

  function uu(t, e) {
    return !t && !e ? "file" : t
  }

  function cu(t, e) {
    switch (t) {
      case "https":
      case "http":
      case "file":
        e ? e[0] !== Re && (e = Re + e) : e = Re;
        break
    }
    return e
  }
  const Z = "",
    Re = "/",
    fu = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
  let gr = class zn {
    static isUri(e) {
      return e instanceof zn ? !0 : !e || typeof e != "object" ? !1 : typeof e.authority == "string" && typeof e.fragment == "string" && typeof e.path == "string" && typeof e.query == "string" && typeof e.scheme == "string" && typeof e.fsPath == "string" && typeof e.with == "function" && typeof e.toString == "function"
    }
    constructor(e, n, r, i, s, a = !1) {
      typeof e == "object" ? (this.scheme = e.scheme || Z, this.authority = e.authority || Z, this.path = e.path || Z, this.query = e.query || Z, this.fragment = e.fragment || Z) : (this.scheme = uu(e, a), this.authority = n || Z, this.path = cu(this.scheme, r || Z), this.query = i || Z, this.fragment = s || Z, lu(this, a))
    }
    get fsPath() {
      return pr(this, !1)
    }
    with(e) {
      if (!e) return this;
      let {
        scheme: n,
        authority: r,
        path: i,
        query: s,
        fragment: a
      } = e;
      return n === void 0 ? n = this.scheme : n === null && (n = Z), r === void 0 ? r = this.authority : r === null && (r = Z), i === void 0 ? i = this.path : i === null && (i = Z), s === void 0 ? s = this.query : s === null && (s = Z), a === void 0 ? a = this.fragment : a === null && (a = Z), n === this.scheme && r === this.authority && i === this.path && s === this.query && a === this.fragment ? this : new Lt(n, r, i, s, a)
    }
    static parse(e, n = !1) {
      const r = fu.exec(e);
      return r ? new Lt(r[2] || Z, Nn(r[4] || Z), Nn(r[5] || Z), Nn(r[7] || Z), Nn(r[9] || Z), n) : new Lt(Z, Z, Z, Z, Z)
    }
    static file(e) {
      let n = Z;
      if (Wt && (e = e.replace(/\\/g, Re)), e[0] === Re && e[1] === Re) {
        const r = e.indexOf(Re, 2);
        r === -1 ? (n = e.substring(2), e = Re) : (n = e.substring(2, r), e = e.substring(r) || Re)
      }
      return new Lt("file", n, e, Z, Z)
    }
    static from(e, n) {
      return new Lt(e.scheme, e.authority, e.path, e.query, e.fragment, n)
    }
    static joinPath(e, ...n) {
      if (!e.path) throw new Error("[UriError]: cannot call joinPath on URI without path");
      let r;
      return Wt && e.scheme === "file" ? r = zn.file(he.join(pr(e, !0), ...n)).path : r = ge.join(e.path, ...n), e.with({
        path: r
      })
    }
    toString(e = !1) {
      return br(this, e)
    }
    toJSON() {
      return this
    }
    static revive(e) {
      if (e) {
        if (e instanceof zn) return e;
        {
          const n = new Lt(e);
          return n._formatted = e.external ?? null, n._fsPath = e._sep === Ri ? e.fsPath ?? null : null, n
        }
      } else return e
    }
  };
  const Ri = Wt ? 1 : void 0;
  class Lt extends gr {
    constructor() {
      super(...arguments), this._formatted = null, this._fsPath = null
    }
    get fsPath() {
      return this._fsPath || (this._fsPath = pr(this, !1)), this._fsPath
    }
    toString(e = !1) {
      return e ? br(this, !0) : (this._formatted || (this._formatted = br(this, !1)), this._formatted)
    }
    toJSON() {
      const e = {
        $mid: 1
      };
      return this._fsPath && (e.fsPath = this._fsPath, e._sep = Ri), this._formatted && (e.external = this._formatted), this.path && (e.path = this.path), this.scheme && (e.scheme = this.scheme), this.authority && (e.authority = this.authority), this.query && (e.query = this.query), this.fragment && (e.fragment = this.fragment), e
    }
  }
  const Ei = {
    58: "%3A",
    47: "%2F",
    63: "%3F",
    35: "%23",
    91: "%5B",
    93: "%5D",
    64: "%40",
    33: "%21",
    36: "%24",
    38: "%26",
    39: "%27",
    40: "%28",
    41: "%29",
    42: "%2A",
    43: "%2B",
    44: "%2C",
    59: "%3B",
    61: "%3D",
    32: "%20"
  };

  function Mi(t, e, n) {
    let r, i = -1;
    for (let s = 0; s < t.length; s++) {
      const a = t.charCodeAt(s);
      if (a >= 97 && a <= 122 || a >= 65 && a <= 90 || a >= 48 && a <= 57 || a === 45 || a === 46 || a === 95 || a === 126 || e && a === 47 || n && a === 91 || n && a === 93 || n && a === 58) i !== -1 && (r += encodeURIComponent(t.substring(i, s)), i = -1), r !== void 0 && (r += t.charAt(s));
      else {
        r === void 0 && (r = t.substr(0, s));
        const o = Ei[a];
        o !== void 0 ? (i !== -1 && (r += encodeURIComponent(t.substring(i, s)), i = -1), r += o) : i === -1 && (i = s)
      }
    }
    return i !== -1 && (r += encodeURIComponent(t.substring(i))), r !== void 0 ? r : t
  }

  function hu(t) {
    let e;
    for (let n = 0; n < t.length; n++) {
      const r = t.charCodeAt(n);
      r === 35 || r === 63 ? (e === void 0 && (e = t.substr(0, n)), e += Ei[r]) : e !== void 0 && (e += t[n])
    }
    return e !== void 0 ? e : t
  }

  function pr(t, e) {
    let n;
    return t.authority && t.path.length > 1 && t.scheme === "file" ? n = `//${t.authority}${t.path}` : t.path.charCodeAt(0) === 47 && (t.path.charCodeAt(1) >= 65 && t.path.charCodeAt(1) <= 90 || t.path.charCodeAt(1) >= 97 && t.path.charCodeAt(1) <= 122) && t.path.charCodeAt(2) === 58 ? e ? n = t.path.substr(1) : n = t.path[1].toLowerCase() + t.path.substr(2) : n = t.path, Wt && (n = n.replace(/\//g, "\\")), n
  }

  function br(t, e) {
    const n = e ? hu : Mi;
    let r = "",
      {
        scheme: i,
        authority: s,
        path: a,
        query: o,
        fragment: u
      } = t;
    if (i && (r += i, r += ":"), (s || i === "file") && (r += Re, r += Re), s) {
      let l = s.indexOf("@");
      if (l !== -1) {
        const h = s.substr(0, l);
        s = s.substr(l + 1), l = h.lastIndexOf(":"), l === -1 ? r += n(h, !1, !1) : (r += n(h.substr(0, l), !1, !1), r += ":", r += n(h.substr(l + 1), !1, !0)), r += "@"
      }
      s = s.toLowerCase(), l = s.lastIndexOf(":"), l === -1 ? r += n(s, !1, !0) : (r += n(s.substr(0, l), !1, !0), r += s.substr(l))
    }
    if (a) {
      if (a.length >= 3 && a.charCodeAt(0) === 47 && a.charCodeAt(2) === 58) {
        const l = a.charCodeAt(1);
        l >= 65 && l <= 90 && (a = `/${String.fromCharCode(l+32)}:${a.substr(3)}`)
      } else if (a.length >= 2 && a.charCodeAt(1) === 58) {
        const l = a.charCodeAt(0);
        l >= 65 && l <= 90 && (a = `${String.fromCharCode(l+32)}:${a.substr(2)}`)
      }
      r += n(a, !0, !1)
    }
    return o && (r += "?", r += n(o, !1, !1)), u && (r += "#", r += e ? u : Mi(u, !1, !1)), r
  }

  function Ti(t) {
    try {
      return decodeURIComponent(t)
    } catch {
      return t.length > 3 ? t.substr(0, 3) + Ti(t.substr(3)) : t
    }
  }
  const Pi = /(%[0-9A-Za-z][0-9A-Za-z])+/g;

  function Nn(t) {
    return t.match(Pi) ? t.replace(Pi, e => Ti(e)) : t
  }
  class be extends U {
    constructor(e, n, r, i) {
      super(e, n, r, i), this.selectionStartLineNumber = e, this.selectionStartColumn = n, this.positionLineNumber = r, this.positionColumn = i
    }
    toString() {
      return "[" + this.selectionStartLineNumber + "," + this.selectionStartColumn + " -> " + this.positionLineNumber + "," + this.positionColumn + "]"
    }
    equalsSelection(e) {
      return be.selectionsEqual(this, e)
    }
    static selectionsEqual(e, n) {
      return e.selectionStartLineNumber === n.selectionStartLineNumber && e.selectionStartColumn === n.selectionStartColumn && e.positionLineNumber === n.positionLineNumber && e.positionColumn === n.positionColumn
    }
    getDirection() {
      return this.selectionStartLineNumber === this.startLineNumber && this.selectionStartColumn === this.startColumn ? 0 : 1
    }
    setEndPosition(e, n) {
      return this.getDirection() === 0 ? new be(this.startLineNumber, this.startColumn, e, n) : new be(e, n, this.startLineNumber, this.startColumn)
    }
    getPosition() {
      return new Q(this.positionLineNumber, this.positionColumn)
    }
    getSelectionStart() {
      return new Q(this.selectionStartLineNumber, this.selectionStartColumn)
    }
    setStartPosition(e, n) {
      return this.getDirection() === 0 ? new be(e, n, this.endLineNumber, this.endColumn) : new be(this.endLineNumber, this.endColumn, e, n)
    }
    static fromPositions(e, n = e) {
      return new be(e.lineNumber, e.column, n.lineNumber, n.column)
    }
    static fromRange(e, n) {
      return n === 0 ? new be(e.startLineNumber, e.startColumn, e.endLineNumber, e.endColumn) : new be(e.endLineNumber, e.endColumn, e.startLineNumber, e.startColumn)
    }
    static liftSelection(e) {
      return new be(e.selectionStartLineNumber, e.selectionStartColumn, e.positionLineNumber, e.positionColumn)
    }
    static selectionsArrEqual(e, n) {
      if (e && !n || !e && n) return !1;
      if (!e && !n) return !0;
      if (e.length !== n.length) return !1;
      for (let r = 0, i = e.length; r < i; r++)
        if (!this.selectionsEqual(e[r], n[r])) return !1;
      return !0
    }
    static isISelection(e) {
      return !!e && typeof e.selectionStartLineNumber == "number" && typeof e.selectionStartColumn == "number" && typeof e.positionLineNumber == "number" && typeof e.positionColumn == "number"
    }
    static createWithDirection(e, n, r, i, s) {
      return s === 0 ? new be(e, n, r, i) : new be(r, i, e, n)
    }
  }
  const Ci = Object.create(null);

  function c(t, e) {
    if (Qo(e)) {
      const n = Ci[e];
      if (n === void 0) throw new Error(`${t} references an unknown codicon: ${e}`);
      e = n
    }
    return Ci[t] = e, {
      id: t
    }
  }
  const mu = {
      add: c("add", 6e4),
      plus: c("plus", 6e4),
      gistNew: c("gist-new", 6e4),
      repoCreate: c("repo-create", 6e4),
      lightbulb: c("lightbulb", 60001),
      lightBulb: c("light-bulb", 60001),
      repo: c("repo", 60002),
      repoDelete: c("repo-delete", 60002),
      gistFork: c("gist-fork", 60003),
      repoForked: c("repo-forked", 60003),
      gitPullRequest: c("git-pull-request", 60004),
      gitPullRequestAbandoned: c("git-pull-request-abandoned", 60004),
      recordKeys: c("record-keys", 60005),
      keyboard: c("keyboard", 60005),
      tag: c("tag", 60006),
      gitPullRequestLabel: c("git-pull-request-label", 60006),
      tagAdd: c("tag-add", 60006),
      tagRemove: c("tag-remove", 60006),
      person: c("person", 60007),
      personFollow: c("person-follow", 60007),
      personOutline: c("person-outline", 60007),
      personFilled: c("person-filled", 60007),
      sourceControl: c("source-control", 60008),
      mirror: c("mirror", 60009),
      mirrorPublic: c("mirror-public", 60009),
      star: c("star", 60010),
      starAdd: c("star-add", 60010),
      starDelete: c("star-delete", 60010),
      starEmpty: c("star-empty", 60010),
      comment: c("comment", 60011),
      commentAdd: c("comment-add", 60011),
      alert: c("alert", 60012),
      warning: c("warning", 60012),
      search: c("search", 60013),
      searchSave: c("search-save", 60013),
      logOut: c("log-out", 60014),
      signOut: c("sign-out", 60014),
      logIn: c("log-in", 60015),
      signIn: c("sign-in", 60015),
      eye: c("eye", 60016),
      eyeUnwatch: c("eye-unwatch", 60016),
      eyeWatch: c("eye-watch", 60016),
      circleFilled: c("circle-filled", 60017),
      primitiveDot: c("primitive-dot", 60017),
      closeDirty: c("close-dirty", 60017),
      debugBreakpoint: c("debug-breakpoint", 60017),
      debugBreakpointDisabled: c("debug-breakpoint-disabled", 60017),
      debugHint: c("debug-hint", 60017),
      terminalDecorationSuccess: c("terminal-decoration-success", 60017),
      primitiveSquare: c("primitive-square", 60018),
      edit: c("edit", 60019),
      pencil: c("pencil", 60019),
      info: c("info", 60020),
      issueOpened: c("issue-opened", 60020),
      gistPrivate: c("gist-private", 60021),
      gitForkPrivate: c("git-fork-private", 60021),
      lock: c("lock", 60021),
      mirrorPrivate: c("mirror-private", 60021),
      close: c("close", 60022),
      removeClose: c("remove-close", 60022),
      x: c("x", 60022),
      repoSync: c("repo-sync", 60023),
      sync: c("sync", 60023),
      clone: c("clone", 60024),
      desktopDownload: c("desktop-download", 60024),
      beaker: c("beaker", 60025),
      microscope: c("microscope", 60025),
      vm: c("vm", 60026),
      deviceDesktop: c("device-desktop", 60026),
      file: c("file", 60027),
      more: c("more", 60028),
      ellipsis: c("ellipsis", 60028),
      kebabHorizontal: c("kebab-horizontal", 60028),
      mailReply: c("mail-reply", 60029),
      reply: c("reply", 60029),
      organization: c("organization", 60030),
      organizationFilled: c("organization-filled", 60030),
      organizationOutline: c("organization-outline", 60030),
      newFile: c("new-file", 60031),
      fileAdd: c("file-add", 60031),
      newFolder: c("new-folder", 60032),
      fileDirectoryCreate: c("file-directory-create", 60032),
      trash: c("trash", 60033),
      trashcan: c("trashcan", 60033),
      history: c("history", 60034),
      clock: c("clock", 60034),
      folder: c("folder", 60035),
      fileDirectory: c("file-directory", 60035),
      symbolFolder: c("symbol-folder", 60035),
      logoGithub: c("logo-github", 60036),
      markGithub: c("mark-github", 60036),
      github: c("github", 60036),
      terminal: c("terminal", 60037),
      console: c("console", 60037),
      repl: c("repl", 60037),
      zap: c("zap", 60038),
      symbolEvent: c("symbol-event", 60038),
      error: c("error", 60039),
      stop: c("stop", 60039),
      variable: c("variable", 60040),
      symbolVariable: c("symbol-variable", 60040),
      array: c("array", 60042),
      symbolArray: c("symbol-array", 60042),
      symbolModule: c("symbol-module", 60043),
      symbolPackage: c("symbol-package", 60043),
      symbolNamespace: c("symbol-namespace", 60043),
      symbolObject: c("symbol-object", 60043),
      symbolMethod: c("symbol-method", 60044),
      symbolFunction: c("symbol-function", 60044),
      symbolConstructor: c("symbol-constructor", 60044),
      symbolBoolean: c("symbol-boolean", 60047),
      symbolNull: c("symbol-null", 60047),
      symbolNumeric: c("symbol-numeric", 60048),
      symbolNumber: c("symbol-number", 60048),
      symbolStructure: c("symbol-structure", 60049),
      symbolStruct: c("symbol-struct", 60049),
      symbolParameter: c("symbol-parameter", 60050),
      symbolTypeParameter: c("symbol-type-parameter", 60050),
      symbolKey: c("symbol-key", 60051),
      symbolText: c("symbol-text", 60051),
      symbolReference: c("symbol-reference", 60052),
      goToFile: c("go-to-file", 60052),
      symbolEnum: c("symbol-enum", 60053),
      symbolValue: c("symbol-value", 60053),
      symbolRuler: c("symbol-ruler", 60054),
      symbolUnit: c("symbol-unit", 60054),
      activateBreakpoints: c("activate-breakpoints", 60055),
      archive: c("archive", 60056),
      arrowBoth: c("arrow-both", 60057),
      arrowDown: c("arrow-down", 60058),
      arrowLeft: c("arrow-left", 60059),
      arrowRight: c("arrow-right", 60060),
      arrowSmallDown: c("arrow-small-down", 60061),
      arrowSmallLeft: c("arrow-small-left", 60062),
      arrowSmallRight: c("arrow-small-right", 60063),
      arrowSmallUp: c("arrow-small-up", 60064),
      arrowUp: c("arrow-up", 60065),
      bell: c("bell", 60066),
      bold: c("bold", 60067),
      book: c("book", 60068),
      bookmark: c("bookmark", 60069),
      debugBreakpointConditionalUnverified: c("debug-breakpoint-conditional-unverified", 60070),
      debugBreakpointConditional: c("debug-breakpoint-conditional", 60071),
      debugBreakpointConditionalDisabled: c("debug-breakpoint-conditional-disabled", 60071),
      debugBreakpointDataUnverified: c("debug-breakpoint-data-unverified", 60072),
      debugBreakpointData: c("debug-breakpoint-data", 60073),
      debugBreakpointDataDisabled: c("debug-breakpoint-data-disabled", 60073),
      debugBreakpointLogUnverified: c("debug-breakpoint-log-unverified", 60074),
      debugBreakpointLog: c("debug-breakpoint-log", 60075),
      debugBreakpointLogDisabled: c("debug-breakpoint-log-disabled", 60075),
      briefcase: c("briefcase", 60076),
      broadcast: c("broadcast", 60077),
      browser: c("browser", 60078),
      bug: c("bug", 60079),
      calendar: c("calendar", 60080),
      caseSensitive: c("case-sensitive", 60081),
      check: c("check", 60082),
      checklist: c("checklist", 60083),
      chevronDown: c("chevron-down", 60084),
      chevronLeft: c("chevron-left", 60085),
      chevronRight: c("chevron-right", 60086),
      chevronUp: c("chevron-up", 60087),
      chromeClose: c("chrome-close", 60088),
      chromeMaximize: c("chrome-maximize", 60089),
      chromeMinimize: c("chrome-minimize", 60090),
      chromeRestore: c("chrome-restore", 60091),
      circleOutline: c("circle-outline", 60092),
      circle: c("circle", 60092),
      debugBreakpointUnverified: c("debug-breakpoint-unverified", 60092),
      terminalDecorationIncomplete: c("terminal-decoration-incomplete", 60092),
      circleSlash: c("circle-slash", 60093),
      circuitBoard: c("circuit-board", 60094),
      clearAll: c("clear-all", 60095),
      clippy: c("clippy", 60096),
      closeAll: c("close-all", 60097),
      cloudDownload: c("cloud-download", 60098),
      cloudUpload: c("cloud-upload", 60099),
      code: c("code", 60100),
      collapseAll: c("collapse-all", 60101),
      colorMode: c("color-mode", 60102),
      commentDiscussion: c("comment-discussion", 60103),
      creditCard: c("credit-card", 60105),
      dash: c("dash", 60108),
      dashboard: c("dashboard", 60109),
      database: c("database", 60110),
      debugContinue: c("debug-continue", 60111),
      debugDisconnect: c("debug-disconnect", 60112),
      debugPause: c("debug-pause", 60113),
      debugRestart: c("debug-restart", 60114),
      debugStart: c("debug-start", 60115),
      debugStepInto: c("debug-step-into", 60116),
      debugStepOut: c("debug-step-out", 60117),
      debugStepOver: c("debug-step-over", 60118),
      debugStop: c("debug-stop", 60119),
      debug: c("debug", 60120),
      deviceCameraVideo: c("device-camera-video", 60121),
      deviceCamera: c("device-camera", 60122),
      deviceMobile: c("device-mobile", 60123),
      diffAdded: c("diff-added", 60124),
      diffIgnored: c("diff-ignored", 60125),
      diffModified: c("diff-modified", 60126),
      diffRemoved: c("diff-removed", 60127),
      diffRenamed: c("diff-renamed", 60128),
      diff: c("diff", 60129),
      diffSidebyside: c("diff-sidebyside", 60129),
      discard: c("discard", 60130),
      editorLayout: c("editor-layout", 60131),
      emptyWindow: c("empty-window", 60132),
      exclude: c("exclude", 60133),
      extensions: c("extensions", 60134),
      eyeClosed: c("eye-closed", 60135),
      fileBinary: c("file-binary", 60136),
      fileCode: c("file-code", 60137),
      fileMedia: c("file-media", 60138),
      filePdf: c("file-pdf", 60139),
      fileSubmodule: c("file-submodule", 60140),
      fileSymlinkDirectory: c("file-symlink-directory", 60141),
      fileSymlinkFile: c("file-symlink-file", 60142),
      fileZip: c("file-zip", 60143),
      files: c("files", 60144),
      filter: c("filter", 60145),
      flame: c("flame", 60146),
      foldDown: c("fold-down", 60147),
      foldUp: c("fold-up", 60148),
      fold: c("fold", 60149),
      folderActive: c("folder-active", 60150),
      folderOpened: c("folder-opened", 60151),
      gear: c("gear", 60152),
      gift: c("gift", 60153),
      gistSecret: c("gist-secret", 60154),
      gist: c("gist", 60155),
      gitCommit: c("git-commit", 60156),
      gitCompare: c("git-compare", 60157),
      compareChanges: c("compare-changes", 60157),
      gitMerge: c("git-merge", 60158),
      githubAction: c("github-action", 60159),
      githubAlt: c("github-alt", 60160),
      globe: c("globe", 60161),
      grabber: c("grabber", 60162),
      graph: c("graph", 60163),
      gripper: c("gripper", 60164),
      heart: c("heart", 60165),
      home: c("home", 60166),
      horizontalRule: c("horizontal-rule", 60167),
      hubot: c("hubot", 60168),
      inbox: c("inbox", 60169),
      issueReopened: c("issue-reopened", 60171),
      issues: c("issues", 60172),
      italic: c("italic", 60173),
      jersey: c("jersey", 60174),
      json: c("json", 60175),
      kebabVertical: c("kebab-vertical", 60176),
      key: c("key", 60177),
      law: c("law", 60178),
      lightbulbAutofix: c("lightbulb-autofix", 60179),
      linkExternal: c("link-external", 60180),
      link: c("link", 60181),
      listOrdered: c("list-ordered", 60182),
      listUnordered: c("list-unordered", 60183),
      liveShare: c("live-share", 60184),
      loading: c("loading", 60185),
      location: c("location", 60186),
      mailRead: c("mail-read", 60187),
      mail: c("mail", 60188),
      markdown: c("markdown", 60189),
      megaphone: c("megaphone", 60190),
      mention: c("mention", 60191),
      milestone: c("milestone", 60192),
      gitPullRequestMilestone: c("git-pull-request-milestone", 60192),
      mortarBoard: c("mortar-board", 60193),
      move: c("move", 60194),
      multipleWindows: c("multiple-windows", 60195),
      mute: c("mute", 60196),
      noNewline: c("no-newline", 60197),
      note: c("note", 60198),
      octoface: c("octoface", 60199),
      openPreview: c("open-preview", 60200),
      package: c("package", 60201),
      paintcan: c("paintcan", 60202),
      pin: c("pin", 60203),
      play: c("play", 60204),
      run: c("run", 60204),
      plug: c("plug", 60205),
      preserveCase: c("preserve-case", 60206),
      preview: c("preview", 60207),
      project: c("project", 60208),
      pulse: c("pulse", 60209),
      question: c("question", 60210),
      quote: c("quote", 60211),
      radioTower: c("radio-tower", 60212),
      reactions: c("reactions", 60213),
      references: c("references", 60214),
      refresh: c("refresh", 60215),
      regex: c("regex", 60216),
      remoteExplorer: c("remote-explorer", 60217),
      remote: c("remote", 60218),
      remove: c("remove", 60219),
      replaceAll: c("replace-all", 60220),
      replace: c("replace", 60221),
      repoClone: c("repo-clone", 60222),
      repoForcePush: c("repo-force-push", 60223),
      repoPull: c("repo-pull", 60224),
      repoPush: c("repo-push", 60225),
      report: c("report", 60226),
      requestChanges: c("request-changes", 60227),
      rocket: c("rocket", 60228),
      rootFolderOpened: c("root-folder-opened", 60229),
      rootFolder: c("root-folder", 60230),
      rss: c("rss", 60231),
      ruby: c("ruby", 60232),
      saveAll: c("save-all", 60233),
      saveAs: c("save-as", 60234),
      save: c("save", 60235),
      screenFull: c("screen-full", 60236),
      screenNormal: c("screen-normal", 60237),
      searchStop: c("search-stop", 60238),
      server: c("server", 60240),
      settingsGear: c("settings-gear", 60241),
      settings: c("settings", 60242),
      shield: c("shield", 60243),
      smiley: c("smiley", 60244),
      sortPrecedence: c("sort-precedence", 60245),
      splitHorizontal: c("split-horizontal", 60246),
      splitVertical: c("split-vertical", 60247),
      squirrel: c("squirrel", 60248),
      starFull: c("star-full", 60249),
      starHalf: c("star-half", 60250),
      symbolClass: c("symbol-class", 60251),
      symbolColor: c("symbol-color", 60252),
      symbolConstant: c("symbol-constant", 60253),
      symbolEnumMember: c("symbol-enum-member", 60254),
      symbolField: c("symbol-field", 60255),
      symbolFile: c("symbol-file", 60256),
      symbolInterface: c("symbol-interface", 60257),
      symbolKeyword: c("symbol-keyword", 60258),
      symbolMisc: c("symbol-misc", 60259),
      symbolOperator: c("symbol-operator", 60260),
      symbolProperty: c("symbol-property", 60261),
      wrench: c("wrench", 60261),
      wrenchSubaction: c("wrench-subaction", 60261),
      symbolSnippet: c("symbol-snippet", 60262),
      tasklist: c("tasklist", 60263),
      telescope: c("telescope", 60264),
      textSize: c("text-size", 60265),
      threeBars: c("three-bars", 60266),
      thumbsdown: c("thumbsdown", 60267),
      thumbsup: c("thumbsup", 60268),
      tools: c("tools", 60269),
      triangleDown: c("triangle-down", 60270),
      triangleLeft: c("triangle-left", 60271),
      triangleRight: c("triangle-right", 60272),
      triangleUp: c("triangle-up", 60273),
      twitter: c("twitter", 60274),
      unfold: c("unfold", 60275),
      unlock: c("unlock", 60276),
      unmute: c("unmute", 60277),
      unverified: c("unverified", 60278),
      verified: c("verified", 60279),
      versions: c("versions", 60280),
      vmActive: c("vm-active", 60281),
      vmOutline: c("vm-outline", 60282),
      vmRunning: c("vm-running", 60283),
      watch: c("watch", 60284),
      whitespace: c("whitespace", 60285),
      wholeWord: c("whole-word", 60286),
      window: c("window", 60287),
      wordWrap: c("word-wrap", 60288),
      zoomIn: c("zoom-in", 60289),
      zoomOut: c("zoom-out", 60290),
      listFilter: c("list-filter", 60291),
      listFlat: c("list-flat", 60292),
      listSelection: c("list-selection", 60293),
      selection: c("selection", 60293),
      listTree: c("list-tree", 60294),
      debugBreakpointFunctionUnverified: c("debug-breakpoint-function-unverified", 60295),
      debugBreakpointFunction: c("debug-breakpoint-function", 60296),
      debugBreakpointFunctionDisabled: c("debug-breakpoint-function-disabled", 60296),
      debugStackframeActive: c("debug-stackframe-active", 60297),
      circleSmallFilled: c("circle-small-filled", 60298),
      debugStackframeDot: c("debug-stackframe-dot", 60298),
      terminalDecorationMark: c("terminal-decoration-mark", 60298),
      debugStackframe: c("debug-stackframe", 60299),
      debugStackframeFocused: c("debug-stackframe-focused", 60299),
      debugBreakpointUnsupported: c("debug-breakpoint-unsupported", 60300),
      symbolString: c("symbol-string", 60301),
      debugReverseContinue: c("debug-reverse-continue", 60302),
      debugStepBack: c("debug-step-back", 60303),
      debugRestartFrame: c("debug-restart-frame", 60304),
      debugAlt: c("debug-alt", 60305),
      callIncoming: c("call-incoming", 60306),
      callOutgoing: c("call-outgoing", 60307),
      menu: c("menu", 60308),
      expandAll: c("expand-all", 60309),
      feedback: c("feedback", 60310),
      gitPullRequestReviewer: c("git-pull-request-reviewer", 60310),
      groupByRefType: c("group-by-ref-type", 60311),
      ungroupByRefType: c("ungroup-by-ref-type", 60312),
      account: c("account", 60313),
      gitPullRequestAssignee: c("git-pull-request-assignee", 60313),
      bellDot: c("bell-dot", 60314),
      debugConsole: c("debug-console", 60315),
      library: c("library", 60316),
      output: c("output", 60317),
      runAll: c("run-all", 60318),
      syncIgnored: c("sync-ignored", 60319),
      pinned: c("pinned", 60320),
      githubInverted: c("github-inverted", 60321),
      serverProcess: c("server-process", 60322),
      serverEnvironment: c("server-environment", 60323),
      pass: c("pass", 60324),
      issueClosed: c("issue-closed", 60324),
      stopCircle: c("stop-circle", 60325),
      playCircle: c("play-circle", 60326),
      record: c("record", 60327),
      debugAltSmall: c("debug-alt-small", 60328),
      vmConnect: c("vm-connect", 60329),
      cloud: c("cloud", 60330),
      merge: c("merge", 60331),
      export: c("export", 60332),
      graphLeft: c("graph-left", 60333),
      magnet: c("magnet", 60334),
      notebook: c("notebook", 60335),
      redo: c("redo", 60336),
      checkAll: c("check-all", 60337),
      pinnedDirty: c("pinned-dirty", 60338),
      passFilled: c("pass-filled", 60339),
      circleLargeFilled: c("circle-large-filled", 60340),
      circleLarge: c("circle-large", 60341),
      circleLargeOutline: c("circle-large-outline", 60341),
      combine: c("combine", 60342),
      gather: c("gather", 60342),
      table: c("table", 60343),
      variableGroup: c("variable-group", 60344),
      typeHierarchy: c("type-hierarchy", 60345),
      typeHierarchySub: c("type-hierarchy-sub", 60346),
      typeHierarchySuper: c("type-hierarchy-super", 60347),
      gitPullRequestCreate: c("git-pull-request-create", 60348),
      runAbove: c("run-above", 60349),
      runBelow: c("run-below", 60350),
      notebookTemplate: c("notebook-template", 60351),
      debugRerun: c("debug-rerun", 60352),
      workspaceTrusted: c("workspace-trusted", 60353),
      workspaceUntrusted: c("workspace-untrusted", 60354),
      workspaceUnknown: c("workspace-unknown", 60355),
      terminalCmd: c("terminal-cmd", 60356),
      terminalDebian: c("terminal-debian", 60357),
      terminalLinux: c("terminal-linux", 60358),
      terminalPowershell: c("terminal-powershell", 60359),
      terminalTmux: c("terminal-tmux", 60360),
      terminalUbuntu: c("terminal-ubuntu", 60361),
      terminalBash: c("terminal-bash", 60362),
      arrowSwap: c("arrow-swap", 60363),
      copy: c("copy", 60364),
      personAdd: c("person-add", 60365),
      filterFilled: c("filter-filled", 60366),
      wand: c("wand", 60367),
      debugLineByLine: c("debug-line-by-line", 60368),
      inspect: c("inspect", 60369),
      layers: c("layers", 60370),
      layersDot: c("layers-dot", 60371),
      layersActive: c("layers-active", 60372),
      compass: c("compass", 60373),
      compassDot: c("compass-dot", 60374),
      compassActive: c("compass-active", 60375),
      azure: c("azure", 60376),
      issueDraft: c("issue-draft", 60377),
      gitPullRequestClosed: c("git-pull-request-closed", 60378),
      gitPullRequestDraft: c("git-pull-request-draft", 60379),
      debugAll: c("debug-all", 60380),
      debugCoverage: c("debug-coverage", 60381),
      runErrors: c("run-errors", 60382),
      folderLibrary: c("folder-library", 60383),
      debugContinueSmall: c("debug-continue-small", 60384),
      beakerStop: c("beaker-stop", 60385),
      graphLine: c("graph-line", 60386),
      graphScatter: c("graph-scatter", 60387),
      pieChart: c("pie-chart", 60388),
      bracket: c("bracket", 60175),
      bracketDot: c("bracket-dot", 60389),
      bracketError: c("bracket-error", 60390),
      lockSmall: c("lock-small", 60391),
      azureDevops: c("azure-devops", 60392),
      verifiedFilled: c("verified-filled", 60393),
      newline: c("newline", 60394),
      layout: c("layout", 60395),
      layoutActivitybarLeft: c("layout-activitybar-left", 60396),
      layoutActivitybarRight: c("layout-activitybar-right", 60397),
      layoutPanelLeft: c("layout-panel-left", 60398),
      layoutPanelCenter: c("layout-panel-center", 60399),
      layoutPanelJustify: c("layout-panel-justify", 60400),
      layoutPanelRight: c("layout-panel-right", 60401),
      layoutPanel: c("layout-panel", 60402),
      layoutSidebarLeft: c("layout-sidebar-left", 60403),
      layoutSidebarRight: c("layout-sidebar-right", 60404),
      layoutStatusbar: c("layout-statusbar", 60405),
      layoutMenubar: c("layout-menubar", 60406),
      layoutCentered: c("layout-centered", 60407),
      target: c("target", 60408),
      indent: c("indent", 60409),
      recordSmall: c("record-small", 60410),
      errorSmall: c("error-small", 60411),
      terminalDecorationError: c("terminal-decoration-error", 60411),
      arrowCircleDown: c("arrow-circle-down", 60412),
      arrowCircleLeft: c("arrow-circle-left", 60413),
      arrowCircleRight: c("arrow-circle-right", 60414),
      arrowCircleUp: c("arrow-circle-up", 60415),
      layoutSidebarRightOff: c("layout-sidebar-right-off", 60416),
      layoutPanelOff: c("layout-panel-off", 60417),
      layoutSidebarLeftOff: c("layout-sidebar-left-off", 60418),
      blank: c("blank", 60419),
      heartFilled: c("heart-filled", 60420),
      map: c("map", 60421),
      mapHorizontal: c("map-horizontal", 60421),
      foldHorizontal: c("fold-horizontal", 60421),
      mapFilled: c("map-filled", 60422),
      mapHorizontalFilled: c("map-horizontal-filled", 60422),
      foldHorizontalFilled: c("fold-horizontal-filled", 60422),
      circleSmall: c("circle-small", 60423),
      bellSlash: c("bell-slash", 60424),
      bellSlashDot: c("bell-slash-dot", 60425),
      commentUnresolved: c("comment-unresolved", 60426),
      gitPullRequestGoToChanges: c("git-pull-request-go-to-changes", 60427),
      gitPullRequestNewChanges: c("git-pull-request-new-changes", 60428),
      searchFuzzy: c("search-fuzzy", 60429),
      commentDraft: c("comment-draft", 60430),
      send: c("send", 60431),
      sparkle: c("sparkle", 60432),
      insert: c("insert", 60433),
      mic: c("mic", 60434),
      thumbsdownFilled: c("thumbsdown-filled", 60435),
      thumbsupFilled: c("thumbsup-filled", 60436),
      coffee: c("coffee", 60437),
      snake: c("snake", 60438),
      game: c("game", 60439),
      vr: c("vr", 60440),
      chip: c("chip", 60441),
      piano: c("piano", 60442),
      music: c("music", 60443),
      micFilled: c("mic-filled", 60444),
      repoFetch: c("repo-fetch", 60445),
      copilot: c("copilot", 60446),
      lightbulbSparkle: c("lightbulb-sparkle", 60447),
      robot: c("robot", 60448),
      sparkleFilled: c("sparkle-filled", 60449),
      diffSingle: c("diff-single", 60450),
      diffMultiple: c("diff-multiple", 60451),
      surroundWith: c("surround-with", 60452),
      share: c("share", 60453),
      gitStash: c("git-stash", 60454),
      gitStashApply: c("git-stash-apply", 60455),
      gitStashPop: c("git-stash-pop", 60456),
      vscode: c("vscode", 60457),
      vscodeInsiders: c("vscode-insiders", 60458),
      codeOss: c("code-oss", 60459),
      runCoverage: c("run-coverage", 60460),
      runAllCoverage: c("run-all-coverage", 60461),
      coverage: c("coverage", 60462),
      githubProject: c("github-project", 60463),
      mapVertical: c("map-vertical", 60464),
      foldVertical: c("fold-vertical", 60464),
      mapVerticalFilled: c("map-vertical-filled", 60465),
      foldVerticalFilled: c("fold-vertical-filled", 60465),
      goToSearch: c("go-to-search", 60466),
      percentage: c("percentage", 60467),
      sortPercentage: c("sort-percentage", 60467),
      attach: c("attach", 60468),
      goToEditingSession: c("go-to-editing-session", 60469),
      editSession: c("edit-session", 60470),
      codeReview: c("code-review", 60471),
      copilotWarning: c("copilot-warning", 60472),
      python: c("python", 60473),
      copilotLarge: c("copilot-large", 60474),
      copilotWarningLarge: c("copilot-warning-large", 60475),
      keyboardTab: c("keyboard-tab", 60476),
      copilotBlocked: c("copilot-blocked", 60477),
      copilotNotConnected: c("copilot-not-connected", 60478),
      flag: c("flag", 60479),
      lightbulbEmpty: c("lightbulb-empty", 60480),
      symbolMethodArrow: c("symbol-method-arrow", 60481),
      copilotUnavailable: c("copilot-unavailable", 60482),
      repoPinned: c("repo-pinned", 60483),
      keyboardTabAbove: c("keyboard-tab-above", 60484),
      keyboardTabBelow: c("keyboard-tab-below", 60485),
      gitPullRequestDone: c("git-pull-request-done", 60486),
      mcp: c("mcp", 60487),
      extensionsLarge: c("extensions-large", 60488),
      layoutPanelDock: c("layout-panel-dock", 60489),
      layoutSidebarLeftDock: c("layout-sidebar-left-dock", 60490),
      layoutSidebarRightDock: c("layout-sidebar-right-dock", 60491),
      copilotInProgress: c("copilot-in-progress", 60492),
      copilotError: c("copilot-error", 60493),
      copilotSuccess: c("copilot-success", 60494),
      chatSparkle: c("chat-sparkle", 60495),
      searchSparkle: c("search-sparkle", 60496),
      editSparkle: c("edit-sparkle", 60497),
      copilotSnooze: c("copilot-snooze", 60498),
      sendToRemoteAgent: c("send-to-remote-agent", 60499),
      commentDiscussionSparkle: c("comment-discussion-sparkle", 60500),
      chatSparkleWarning: c("chat-sparkle-warning", 60501),
      chatSparkleError: c("chat-sparkle-error", 60502),
      collection: c("collection", 60503),
      newCollection: c("new-collection", 60504),
      thinking: c("thinking", 60505),
      build: c("build", 60506),
      commentDiscussionQuote: c("comment-discussion-quote", 60507),
      cursor: c("cursor", 60508),
      eraser: c("eraser", 60509),
      fileText: c("file-text", 60510),
      gitLens: c("git-lens", 60511),
      quotes: c("quotes", 60512),
      rename: c("rename", 60513),
      runWithDeps: c("run-with-deps", 60514),
      debugConnected: c("debug-connected", 60515),
      strikethrough: c("strikethrough", 60516),
      openInProduct: c("open-in-product", 60517),
      indexZero: c("index-zero", 60518),
      agent: c("agent", 60519),
      editCode: c("edit-code", 60520),
      repoSelected: c("repo-selected", 60521),
      skip: c("skip", 60522),
      mergeInto: c("merge-into", 60523),
      gitBranchChanges: c("git-branch-changes", 60524),
      gitBranchStagedChanges: c("git-branch-staged-changes", 60525),
      gitBranchConflicts: c("git-branch-conflicts", 60526),
      gitBranch: c("git-branch", 60527),
      gitBranchCreate: c("git-branch-create", 60527),
      gitBranchDelete: c("git-branch-delete", 60527),
      searchLarge: c("search-large", 60528),
      terminalGitBash: c("terminal-git-bash", 60529)
    },
    du = {
      dialogError: c("dialog-error", "error"),
      dialogWarning: c("dialog-warning", "warning"),
      dialogInfo: c("dialog-info", "info"),
      dialogClose: c("dialog-close", "close"),
      treeItemExpanded: c("tree-item-expanded", "chevron-down"),
      treeFilterOnTypeOn: c("tree-filter-on-type-on", "list-filter"),
      treeFilterOnTypeOff: c("tree-filter-on-type-off", "list-selection"),
      treeFilterClear: c("tree-filter-clear", "close"),
      treeItemLoading: c("tree-item-loading", "loading"),
      menuSelection: c("menu-selection", "check"),
      menuSubmenu: c("menu-submenu", "chevron-right"),
      menuBarMore: c("menubar-more", "more"),
      scrollbarButtonLeft: c("scrollbar-button-left", "triangle-left"),
      scrollbarButtonRight: c("scrollbar-button-right", "triangle-right"),
      scrollbarButtonUp: c("scrollbar-button-up", "triangle-up"),
      scrollbarButtonDown: c("scrollbar-button-down", "triangle-down"),
      toolBarMore: c("toolbar-more", "more"),
      quickInputBack: c("quick-input-back", "arrow-left"),
      dropDownButton: c("drop-down-button", 60084),
      symbolCustomColor: c("symbol-customcolor", 60252),
      exportIcon: c("export", 60332),
      workspaceUnspecified: c("workspace-unspecified", 60355),
      newLine: c("newline", 60394),
      thumbsDownFilled: c("thumbsdown-filled", 60435),
      thumbsUpFilled: c("thumbsup-filled", 60436),
      gitFetch: c("git-fetch", 60445),
      lightbulbSparkleAutofix: c("lightbulb-sparkle-autofix", 60447),
      debugBreakpointPending: c("debug-breakpoint-pending", 60377)
    },
    O = {
      ...mu,
      ...du
    };
  class gu {
    constructor() {
      this._tokenizationSupports = new Map, this._factories = new Map, this._onDidChange = new Ce, this.onDidChange = this._onDidChange.event, this._colorMap = null
    }
    handleChange(e) {
      this._onDidChange.fire({
        changedLanguages: e,
        changedColorMap: !1
      })
    }
    register(e, n) {
      return this._tokenizationSupports.set(e, n), this.handleChange([e]), dn(() => {
        this._tokenizationSupports.get(e) === n && (this._tokenizationSupports.delete(e), this.handleChange([e]))
      })
    }
    get(e) {
      return this._tokenizationSupports.get(e) || null
    }
    registerFactory(e, n) {
      var i;
      (i = this._factories.get(e)) == null || i.dispose();
      const r = new pu(this, e, n);
      return this._factories.set(e, r), dn(() => {
        const s = this._factories.get(e);
        !s || s !== r || (this._factories.delete(e), s.dispose())
      })
    }
    async getOrCreate(e) {
      const n = this.get(e);
      if (n) return n;
      const r = this._factories.get(e);
      return !r || r.isResolved ? null : (await r.resolve(), this.get(e))
    }
    isResolved(e) {
      if (this.get(e)) return !0;
      const r = this._factories.get(e);
      return !!(!r || r.isResolved)
    }
    setColorMap(e) {
      this._colorMap = e, this._onDidChange.fire({
        changedLanguages: Array.from(this._tokenizationSupports.keys()),
        changedColorMap: !0
      })
    }
    getColorMap() {
      return this._colorMap
    }
    getDefaultBackground() {
      return this._colorMap && this._colorMap.length > 2 ? this._colorMap[2] : null
    }
  }
  class pu extends it {
    get isResolved() {
      return this._isResolved
    }
    constructor(e, n, r) {
      super(), this._registry = e, this._languageId = n, this._factory = r, this._isDisposed = !1, this._resolvePromise = null, this._isResolved = !1
    }
    dispose() {
      this._isDisposed = !0, super.dispose()
    }
    async resolve() {
      return this._resolvePromise || (this._resolvePromise = this._create()), this._resolvePromise
    }
    async _create() {
      const e = await this._factory.tokenizationSupport;
      this._isResolved = !0, e && !this._isDisposed && this._register(this._registry.register(this._languageId, e))
    }
  }
  class bu {
    constructor(e, n, r) {
      this.offset = e, this.type = n, this.language = r, this._tokenBrand = void 0
    }
    toString() {
      return "(" + this.offset + ", " + this.type + ")"
    }
  }
  var Ii;
  (function(t) {
    t[t.Increase = 0] = "Increase", t[t.Decrease = 1] = "Decrease"
  })(Ii || (Ii = {}));
  var Fi;
  (function(t) {
    const e = new Map;
    e.set(0, O.symbolMethod), e.set(1, O.symbolFunction), e.set(2, O.symbolConstructor), e.set(3, O.symbolField), e.set(4, O.symbolVariable), e.set(5, O.symbolClass), e.set(6, O.symbolStruct), e.set(7, O.symbolInterface), e.set(8, O.symbolModule), e.set(9, O.symbolProperty), e.set(10, O.symbolEvent), e.set(11, O.symbolOperator), e.set(12, O.symbolUnit), e.set(13, O.symbolValue), e.set(15, O.symbolEnum), e.set(14, O.symbolConstant), e.set(15, O.symbolEnum), e.set(16, O.symbolEnumMember), e.set(17, O.symbolKeyword), e.set(28, O.symbolSnippet), e.set(18, O.symbolText), e.set(19, O.symbolColor), e.set(20, O.symbolFile), e.set(21, O.symbolReference), e.set(22, O.symbolCustomColor), e.set(23, O.symbolFolder), e.set(24, O.symbolTypeParameter), e.set(25, O.account), e.set(26, O.issues), e.set(27, O.tools);

    function n(a) {
      let o = e.get(a);
      return o || (console.info("No codicon found for CompletionItemKind " + a), o = O.symbolProperty), o
    }
    t.toIcon = n;

    function r(a) {
      switch (a) {
        case 0:
          return $(728, "Method");
        case 1:
          return $(729, "Function");
        case 2:
          return $(730, "Constructor");
        case 3:
          return $(731, "Field");
        case 4:
          return $(732, "Variable");
        case 5:
          return $(733, "Class");
        case 6:
          return $(734, "Struct");
        case 7:
          return $(735, "Interface");
        case 8:
          return $(736, "Module");
        case 9:
          return $(737, "Property");
        case 10:
          return $(738, "Event");
        case 11:
          return $(739, "Operator");
        case 12:
          return $(740, "Unit");
        case 13:
          return $(741, "Value");
        case 14:
          return $(742, "Constant");
        case 15:
          return $(743, "Enum");
        case 16:
          return $(744, "Enum Member");
        case 17:
          return $(745, "Keyword");
        case 18:
          return $(746, "Text");
        case 19:
          return $(747, "Color");
        case 20:
          return $(748, "File");
        case 21:
          return $(749, "Reference");
        case 22:
          return $(750, "Custom Color");
        case 23:
          return $(751, "Folder");
        case 24:
          return $(752, "Type Parameter");
        case 25:
          return $(753, "User");
        case 26:
          return $(754, "Issue");
        case 27:
          return $(755, "Tool");
        case 28:
          return $(756, "Snippet");
        default:
          return ""
      }
    }
    t.toLabel = r;
    const i = new Map;
    i.set("method", 0), i.set("function", 1), i.set("constructor", 2), i.set("field", 3), i.set("variable", 4), i.set("class", 5), i.set("struct", 6), i.set("interface", 7), i.set("module", 8), i.set("property", 9), i.set("event", 10), i.set("operator", 11), i.set("unit", 12), i.set("value", 13), i.set("constant", 14), i.set("enum", 15), i.set("enum-member", 16), i.set("enumMember", 16), i.set("keyword", 17), i.set("snippet", 28), i.set("text", 18), i.set("color", 19), i.set("file", 20), i.set("reference", 21), i.set("customcolor", 22), i.set("folder", 23), i.set("type-parameter", 24), i.set("typeParameter", 24), i.set("account", 25), i.set("issue", 26), i.set("tool", 27);

    function s(a, o) {
      let u = i.get(a);
      return typeof u > "u" && !o && (u = 9), u
    }
    t.fromString = s
  })(Fi || (Fi = {}));
  var Vi;
  (function(t) {
    t[t.Automatic = 0] = "Automatic", t[t.Explicit = 1] = "Explicit"
  })(Vi || (Vi = {}));
  var Di;
  (function(t) {
    t[t.Code = 1] = "Code", t[t.Label = 2] = "Label"
  })(Di || (Di = {}));
  var Oi;
  (function(t) {
    t[t.Accepted = 0] = "Accepted", t[t.Rejected = 1] = "Rejected", t[t.Ignored = 2] = "Ignored"
  })(Oi || (Oi = {}));
  var $i;
  (function(t) {
    t[t.Automatic = 0] = "Automatic", t[t.PasteAs = 1] = "PasteAs"
  })($i || ($i = {}));
  var Bi;
  (function(t) {
    t[t.Invoke = 1] = "Invoke", t[t.TriggerCharacter = 2] = "TriggerCharacter", t[t.ContentChange = 3] = "ContentChange"
  })(Bi || (Bi = {}));
  var Ui;
  (function(t) {
    t[t.Text = 0] = "Text", t[t.Read = 1] = "Read", t[t.Write = 2] = "Write"
  })(Ui || (Ui = {})), $(757, "array"), $(758, "boolean"), $(759, "class"), $(760, "constant"), $(761, "constructor"), $(762, "enumeration"), $(763, "enumeration member"), $(764, "event"), $(765, "field"), $(766, "file"), $(767, "function"), $(768, "interface"), $(769, "key"), $(770, "method"), $(771, "module"), $(772, "namespace"), $(773, "null"), $(774, "number"), $(775, "object"), $(776, "operator"), $(777, "package"), $(778, "property"), $(779, "string"), $(780, "struct"), $(781, "type parameter"), $(782, "variable");
  var qi;
  (function(t) {
    const e = new Map;
    e.set(0, O.symbolFile), e.set(1, O.symbolModule), e.set(2, O.symbolNamespace), e.set(3, O.symbolPackage), e.set(4, O.symbolClass), e.set(5, O.symbolMethod), e.set(6, O.symbolProperty), e.set(7, O.symbolField), e.set(8, O.symbolConstructor), e.set(9, O.symbolEnum), e.set(10, O.symbolInterface), e.set(11, O.symbolFunction), e.set(12, O.symbolVariable), e.set(13, O.symbolConstant), e.set(14, O.symbolString), e.set(15, O.symbolNumber), e.set(16, O.symbolBoolean), e.set(17, O.symbolArray), e.set(18, O.symbolObject), e.set(19, O.symbolKey), e.set(20, O.symbolNull), e.set(21, O.symbolEnumMember), e.set(22, O.symbolStruct), e.set(23, O.symbolEvent), e.set(24, O.symbolOperator), e.set(25, O.symbolTypeParameter);

    function n(s) {
      let a = e.get(s);
      return a || (console.info("No codicon found for SymbolKind " + s), a = O.symbolProperty), a
    }
    t.toIcon = n;
    const r = new Map;
    r.set(0, 20), r.set(1, 8), r.set(2, 8), r.set(3, 8), r.set(4, 5), r.set(5, 0), r.set(6, 9), r.set(7, 3), r.set(8, 2), r.set(9, 15), r.set(10, 7), r.set(11, 1), r.set(12, 4), r.set(13, 14), r.set(14, 18), r.set(15, 13), r.set(16, 13), r.set(17, 13), r.set(18, 13), r.set(19, 17), r.set(20, 13), r.set(21, 16), r.set(22, 6), r.set(23, 10), r.set(24, 11), r.set(25, 24);

    function i(s) {
      let a = r.get(s);
      return a === void 0 && (console.info("No completion kind found for SymbolKind " + s), a = 20), a
    }
    t.toCompletionKind = i
  })(qi || (qi = {}));
  let J1 = (me = class {
    static fromValue(e) {
      switch (e) {
        case "comment":
          return me.Comment;
        case "imports":
          return me.Imports;
        case "region":
          return me.Region
      }
      return new me(e)
    }
    constructor(e) {
      this.value = e
    }
  }, me.Comment = new me("comment"), me.Imports = new me("imports"), me.Region = new me("region"), me);
  var ji;
  (function(t) {
    t[t.AIGenerated = 1] = "AIGenerated"
  })(ji || (ji = {}));
  var Wi;
  (function(t) {
    t[t.Invoke = 0] = "Invoke", t[t.Automatic = 1] = "Automatic"
  })(Wi || (Wi = {}));
  var Hi;
  (function(t) {
    function e(n) {
      return !n || typeof n != "object" ? !1 : typeof n.id == "string" && typeof n.title == "string"
    }
    t.is = e
  })(Hi || (Hi = {}));
  var zi;
  (function(t) {
    t[t.Type = 1] = "Type", t[t.Parameter = 2] = "Parameter"
  })(zi || (zi = {})), new gu;
  var Gi;
  (function(t) {
    t[t.Unknown = 0] = "Unknown", t[t.Disabled = 1] = "Disabled", t[t.Enabled = 2] = "Enabled"
  })(Gi || (Gi = {}));
  var Ji;
  (function(t) {
    t[t.Invoke = 1] = "Invoke", t[t.Auto = 2] = "Auto"
  })(Ji || (Ji = {}));
  var Xi;
  (function(t) {
    t[t.None = 0] = "None", t[t.KeepWhitespace = 1] = "KeepWhitespace", t[t.InsertAsSnippet = 4] = "InsertAsSnippet"
  })(Xi || (Xi = {}));
  var Qi;
  (function(t) {
    t[t.Method = 0] = "Method", t[t.Function = 1] = "Function", t[t.Constructor = 2] = "Constructor", t[t.Field = 3] = "Field", t[t.Variable = 4] = "Variable", t[t.Class = 5] = "Class", t[t.Struct = 6] = "Struct", t[t.Interface = 7] = "Interface", t[t.Module = 8] = "Module", t[t.Property = 9] = "Property", t[t.Event = 10] = "Event", t[t.Operator = 11] = "Operator", t[t.Unit = 12] = "Unit", t[t.Value = 13] = "Value", t[t.Constant = 14] = "Constant", t[t.Enum = 15] = "Enum", t[t.EnumMember = 16] = "EnumMember", t[t.Keyword = 17] = "Keyword", t[t.Text = 18] = "Text", t[t.Color = 19] = "Color", t[t.File = 20] = "File", t[t.Reference = 21] = "Reference", t[t.Customcolor = 22] = "Customcolor", t[t.Folder = 23] = "Folder", t[t.TypeParameter = 24] = "TypeParameter", t[t.User = 25] = "User", t[t.Issue = 26] = "Issue", t[t.Tool = 27] = "Tool", t[t.Snippet = 28] = "Snippet"
  })(Qi || (Qi = {}));
  var Zi;
  (function(t) {
    t[t.Deprecated = 1] = "Deprecated"
  })(Zi || (Zi = {}));
  var Yi;
  (function(t) {
    t[t.Invoke = 0] = "Invoke", t[t.TriggerCharacter = 1] = "TriggerCharacter", t[t.TriggerForIncompleteCompletions = 2] = "TriggerForIncompleteCompletions"
  })(Yi || (Yi = {}));
  var Ki;
  (function(t) {
    t[t.EXACT = 0] = "EXACT", t[t.ABOVE = 1] = "ABOVE", t[t.BELOW = 2] = "BELOW"
  })(Ki || (Ki = {}));
  var es;
  (function(t) {
    t[t.NotSet = 0] = "NotSet", t[t.ContentFlush = 1] = "ContentFlush", t[t.RecoverFromMarkers = 2] = "RecoverFromMarkers", t[t.Explicit = 3] = "Explicit", t[t.Paste = 4] = "Paste", t[t.Undo = 5] = "Undo", t[t.Redo = 6] = "Redo"
  })(es || (es = {}));
  var ts;
  (function(t) {
    t[t.LF = 1] = "LF", t[t.CRLF = 2] = "CRLF"
  })(ts || (ts = {}));
  var ns;
  (function(t) {
    t[t.Text = 0] = "Text", t[t.Read = 1] = "Read", t[t.Write = 2] = "Write"
  })(ns || (ns = {}));
  var rs;
  (function(t) {
    t[t.None = 0] = "None", t[t.Keep = 1] = "Keep", t[t.Brackets = 2] = "Brackets", t[t.Advanced = 3] = "Advanced", t[t.Full = 4] = "Full"
  })(rs || (rs = {}));
  var is;
  (function(t) {
    t[t.acceptSuggestionOnCommitCharacter = 0] = "acceptSuggestionOnCommitCharacter", t[t.acceptSuggestionOnEnter = 1] = "acceptSuggestionOnEnter", t[t.accessibilitySupport = 2] = "accessibilitySupport", t[t.accessibilityPageSize = 3] = "accessibilityPageSize", t[t.allowOverflow = 4] = "allowOverflow", t[t.allowVariableLineHeights = 5] = "allowVariableLineHeights", t[t.allowVariableFonts = 6] = "allowVariableFonts", t[t.allowVariableFontsInAccessibilityMode = 7] = "allowVariableFontsInAccessibilityMode", t[t.ariaLabel = 8] = "ariaLabel", t[t.ariaRequired = 9] = "ariaRequired", t[t.autoClosingBrackets = 10] = "autoClosingBrackets", t[t.autoClosingComments = 11] = "autoClosingComments", t[t.screenReaderAnnounceInlineSuggestion = 12] = "screenReaderAnnounceInlineSuggestion", t[t.autoClosingDelete = 13] = "autoClosingDelete", t[t.autoClosingOvertype = 14] = "autoClosingOvertype", t[t.autoClosingQuotes = 15] = "autoClosingQuotes", t[t.autoIndent = 16] = "autoIndent", t[t.autoIndentOnPaste = 17] = "autoIndentOnPaste", t[t.autoIndentOnPasteWithinString = 18] = "autoIndentOnPasteWithinString", t[t.automaticLayout = 19] = "automaticLayout", t[t.autoSurround = 20] = "autoSurround", t[t.bracketPairColorization = 21] = "bracketPairColorization", t[t.guides = 22] = "guides", t[t.codeLens = 23] = "codeLens", t[t.codeLensFontFamily = 24] = "codeLensFontFamily", t[t.codeLensFontSize = 25] = "codeLensFontSize", t[t.colorDecorators = 26] = "colorDecorators", t[t.colorDecoratorsLimit = 27] = "colorDecoratorsLimit", t[t.columnSelection = 28] = "columnSelection", t[t.comments = 29] = "comments", t[t.contextmenu = 30] = "contextmenu", t[t.copyWithSyntaxHighlighting = 31] = "copyWithSyntaxHighlighting", t[t.cursorBlinking = 32] = "cursorBlinking", t[t.cursorSmoothCaretAnimation = 33] = "cursorSmoothCaretAnimation", t[t.cursorStyle = 34] = "cursorStyle", t[t.cursorSurroundingLines = 35] = "cursorSurroundingLines", t[t.cursorSurroundingLinesStyle = 36] = "cursorSurroundingLinesStyle", t[t.cursorWidth = 37] = "cursorWidth", t[t.cursorHeight = 38] = "cursorHeight", t[t.disableLayerHinting = 39] = "disableLayerHinting", t[t.disableMonospaceOptimizations = 40] = "disableMonospaceOptimizations", t[t.domReadOnly = 41] = "domReadOnly", t[t.dragAndDrop = 42] = "dragAndDrop", t[t.dropIntoEditor = 43] = "dropIntoEditor", t[t.editContext = 44] = "editContext", t[t.emptySelectionClipboard = 45] = "emptySelectionClipboard", t[t.experimentalGpuAcceleration = 46] = "experimentalGpuAcceleration", t[t.experimentalWhitespaceRendering = 47] = "experimentalWhitespaceRendering", t[t.extraEditorClassName = 48] = "extraEditorClassName", t[t.fastScrollSensitivity = 49] = "fastScrollSensitivity", t[t.find = 50] = "find", t[t.fixedOverflowWidgets = 51] = "fixedOverflowWidgets", t[t.folding = 52] = "folding", t[t.foldingStrategy = 53] = "foldingStrategy", t[t.foldingHighlight = 54] = "foldingHighlight", t[t.foldingImportsByDefault = 55] = "foldingImportsByDefault", t[t.foldingMaximumRegions = 56] = "foldingMaximumRegions", t[t.unfoldOnClickAfterEndOfLine = 57] = "unfoldOnClickAfterEndOfLine", t[t.fontFamily = 58] = "fontFamily", t[t.fontInfo = 59] = "fontInfo", t[t.fontLigatures = 60] = "fontLigatures", t[t.fontSize = 61] = "fontSize", t[t.fontWeight = 62] = "fontWeight", t[t.fontVariations = 63] = "fontVariations", t[t.formatOnPaste = 64] = "formatOnPaste", t[t.formatOnType = 65] = "formatOnType", t[t.glyphMargin = 66] = "glyphMargin", t[t.gotoLocation = 67] = "gotoLocation", t[t.hideCursorInOverviewRuler = 68] = "hideCursorInOverviewRuler", t[t.hover = 69] = "hover", t[t.inDiffEditor = 70] = "inDiffEditor", t[t.inlineSuggest = 71] = "inlineSuggest", t[t.letterSpacing = 72] = "letterSpacing", t[t.lightbulb = 73] = "lightbulb", t[t.lineDecorationsWidth = 74] = "lineDecorationsWidth", t[t.lineHeight = 75] = "lineHeight", t[t.lineNumbers = 76] = "lineNumbers", t[t.lineNumbersMinChars = 77] = "lineNumbersMinChars", t[t.linkedEditing = 78] = "linkedEditing", t[t.links = 79] = "links", t[t.matchBrackets = 80] = "matchBrackets", t[t.minimap = 81] = "minimap", t[t.mouseStyle = 82] = "mouseStyle", t[t.mouseWheelScrollSensitivity = 83] = "mouseWheelScrollSensitivity", t[t.mouseWheelZoom = 84] = "mouseWheelZoom", t[t.multiCursorMergeOverlapping = 85] = "multiCursorMergeOverlapping", t[t.multiCursorModifier = 86] = "multiCursorModifier", t[t.mouseMiddleClickAction = 87] = "mouseMiddleClickAction", t[t.multiCursorPaste = 88] = "multiCursorPaste", t[t.multiCursorLimit = 89] = "multiCursorLimit", t[t.occurrencesHighlight = 90] = "occurrencesHighlight", t[t.occurrencesHighlightDelay = 91] = "occurrencesHighlightDelay", t[t.overtypeCursorStyle = 92] = "overtypeCursorStyle", t[t.overtypeOnPaste = 93] = "overtypeOnPaste", t[t.overviewRulerBorder = 94] = "overviewRulerBorder", t[t.overviewRulerLanes = 95] = "overviewRulerLanes", t[t.padding = 96] = "padding", t[t.pasteAs = 97] = "pasteAs", t[t.parameterHints = 98] = "parameterHints", t[t.peekWidgetDefaultFocus = 99] = "peekWidgetDefaultFocus", t[t.placeholder = 100] = "placeholder", t[t.definitionLinkOpensInPeek = 101] = "definitionLinkOpensInPeek", t[t.quickSuggestions = 102] = "quickSuggestions", t[t.quickSuggestionsDelay = 103] = "quickSuggestionsDelay", t[t.readOnly = 104] = "readOnly", t[t.readOnlyMessage = 105] = "readOnlyMessage", t[t.renameOnType = 106] = "renameOnType", t[t.renderRichScreenReaderContent = 107] = "renderRichScreenReaderContent", t[t.renderControlCharacters = 108] = "renderControlCharacters", t[t.renderFinalNewline = 109] = "renderFinalNewline", t[t.renderLineHighlight = 110] = "renderLineHighlight", t[t.renderLineHighlightOnlyWhenFocus = 111] = "renderLineHighlightOnlyWhenFocus", t[t.renderValidationDecorations = 112] = "renderValidationDecorations", t[t.renderWhitespace = 113] = "renderWhitespace", t[t.revealHorizontalRightPadding = 114] = "revealHorizontalRightPadding", t[t.roundedSelection = 115] = "roundedSelection", t[t.rulers = 116] = "rulers", t[t.scrollbar = 117] = "scrollbar", t[t.scrollBeyondLastColumn = 118] = "scrollBeyondLastColumn", t[t.scrollBeyondLastLine = 119] = "scrollBeyondLastLine", t[t.scrollPredominantAxis = 120] = "scrollPredominantAxis", t[t.selectionClipboard = 121] = "selectionClipboard", t[t.selectionHighlight = 122] = "selectionHighlight", t[t.selectionHighlightMaxLength = 123] = "selectionHighlightMaxLength", t[t.selectionHighlightMultiline = 124] = "selectionHighlightMultiline", t[t.selectOnLineNumbers = 125] = "selectOnLineNumbers", t[t.showFoldingControls = 126] = "showFoldingControls", t[t.showUnused = 127] = "showUnused", t[t.snippetSuggestions = 128] = "snippetSuggestions", t[t.smartSelect = 129] = "smartSelect", t[t.smoothScrolling = 130] = "smoothScrolling", t[t.stickyScroll = 131] = "stickyScroll", t[t.stickyTabStops = 132] = "stickyTabStops", t[t.stopRenderingLineAfter = 133] = "stopRenderingLineAfter", t[t.suggest = 134] = "suggest", t[t.suggestFontSize = 135] = "suggestFontSize", t[t.suggestLineHeight = 136] = "suggestLineHeight", t[t.suggestOnTriggerCharacters = 137] = "suggestOnTriggerCharacters", t[t.suggestSelection = 138] = "suggestSelection", t[t.tabCompletion = 139] = "tabCompletion", t[t.tabIndex = 140] = "tabIndex", t[t.trimWhitespaceOnDelete = 141] = "trimWhitespaceOnDelete", t[t.unicodeHighlighting = 142] = "unicodeHighlighting", t[t.unusualLineTerminators = 143] = "unusualLineTerminators", t[t.useShadowDOM = 144] = "useShadowDOM", t[t.useTabStops = 145] = "useTabStops", t[t.wordBreak = 146] = "wordBreak", t[t.wordSegmenterLocales = 147] = "wordSegmenterLocales", t[t.wordSeparators = 148] = "wordSeparators", t[t.wordWrap = 149] = "wordWrap", t[t.wordWrapBreakAfterCharacters = 150] = "wordWrapBreakAfterCharacters", t[t.wordWrapBreakBeforeCharacters = 151] = "wordWrapBreakBeforeCharacters", t[t.wordWrapColumn = 152] = "wordWrapColumn", t[t.wordWrapOverride1 = 153] = "wordWrapOverride1", t[t.wordWrapOverride2 = 154] = "wordWrapOverride2", t[t.wrappingIndent = 155] = "wrappingIndent", t[t.wrappingStrategy = 156] = "wrappingStrategy", t[t.showDeprecated = 157] = "showDeprecated", t[t.inertialScroll = 158] = "inertialScroll", t[t.inlayHints = 159] = "inlayHints", t[t.wrapOnEscapedLineFeeds = 160] = "wrapOnEscapedLineFeeds", t[t.effectiveCursorStyle = 161] = "effectiveCursorStyle", t[t.editorClassName = 162] = "editorClassName", t[t.pixelRatio = 163] = "pixelRatio", t[t.tabFocusMode = 164] = "tabFocusMode", t[t.layoutInfo = 165] = "layoutInfo", t[t.wrappingInfo = 166] = "wrappingInfo", t[t.defaultColorDecorators = 167] = "defaultColorDecorators", t[t.colorDecoratorsActivatedOn = 168] = "colorDecoratorsActivatedOn", t[t.inlineCompletionsAccessibilityVerbose = 169] = "inlineCompletionsAccessibilityVerbose", t[t.effectiveEditContext = 170] = "effectiveEditContext", t[t.scrollOnMiddleClick = 171] = "scrollOnMiddleClick", t[t.effectiveAllowVariableFonts = 172] = "effectiveAllowVariableFonts"
  })(is || (is = {}));
  var ss;
  (function(t) {
    t[t.TextDefined = 0] = "TextDefined", t[t.LF = 1] = "LF", t[t.CRLF = 2] = "CRLF"
  })(ss || (ss = {}));
  var as;
  (function(t) {
    t[t.LF = 0] = "LF", t[t.CRLF = 1] = "CRLF"
  })(as || (as = {}));
  var os;
  (function(t) {
    t[t.Left = 1] = "Left", t[t.Center = 2] = "Center", t[t.Right = 3] = "Right"
  })(os || (os = {}));
  var ls;
  (function(t) {
    t[t.Increase = 0] = "Increase", t[t.Decrease = 1] = "Decrease"
  })(ls || (ls = {}));
  var us;
  (function(t) {
    t[t.None = 0] = "None", t[t.Indent = 1] = "Indent", t[t.IndentOutdent = 2] = "IndentOutdent", t[t.Outdent = 3] = "Outdent"
  })(us || (us = {}));
  var cs;
  (function(t) {
    t[t.Both = 0] = "Both", t[t.Right = 1] = "Right", t[t.Left = 2] = "Left", t[t.None = 3] = "None"
  })(cs || (cs = {}));
  var fs;
  (function(t) {
    t[t.Type = 1] = "Type", t[t.Parameter = 2] = "Parameter"
  })(fs || (fs = {}));
  var hs;
  (function(t) {
    t[t.Accepted = 0] = "Accepted", t[t.Rejected = 1] = "Rejected", t[t.Ignored = 2] = "Ignored"
  })(hs || (hs = {}));
  var ms;
  (function(t) {
    t[t.Code = 1] = "Code", t[t.Label = 2] = "Label"
  })(ms || (ms = {}));
  var ds;
  (function(t) {
    t[t.Automatic = 0] = "Automatic", t[t.Explicit = 1] = "Explicit"
  })(ds || (ds = {}));
  var yr;
  (function(t) {
    t[t.DependsOnKbLayout = -1] = "DependsOnKbLayout", t[t.Unknown = 0] = "Unknown", t[t.Backspace = 1] = "Backspace", t[t.Tab = 2] = "Tab", t[t.Enter = 3] = "Enter", t[t.Shift = 4] = "Shift", t[t.Ctrl = 5] = "Ctrl", t[t.Alt = 6] = "Alt", t[t.PauseBreak = 7] = "PauseBreak", t[t.CapsLock = 8] = "CapsLock", t[t.Escape = 9] = "Escape", t[t.Space = 10] = "Space", t[t.PageUp = 11] = "PageUp", t[t.PageDown = 12] = "PageDown", t[t.End = 13] = "End", t[t.Home = 14] = "Home", t[t.LeftArrow = 15] = "LeftArrow", t[t.UpArrow = 16] = "UpArrow", t[t.RightArrow = 17] = "RightArrow", t[t.DownArrow = 18] = "DownArrow", t[t.Insert = 19] = "Insert", t[t.Delete = 20] = "Delete", t[t.Digit0 = 21] = "Digit0", t[t.Digit1 = 22] = "Digit1", t[t.Digit2 = 23] = "Digit2", t[t.Digit3 = 24] = "Digit3", t[t.Digit4 = 25] = "Digit4", t[t.Digit5 = 26] = "Digit5", t[t.Digit6 = 27] = "Digit6", t[t.Digit7 = 28] = "Digit7", t[t.Digit8 = 29] = "Digit8", t[t.Digit9 = 30] = "Digit9", t[t.KeyA = 31] = "KeyA", t[t.KeyB = 32] = "KeyB", t[t.KeyC = 33] = "KeyC", t[t.KeyD = 34] = "KeyD", t[t.KeyE = 35] = "KeyE", t[t.KeyF = 36] = "KeyF", t[t.KeyG = 37] = "KeyG", t[t.KeyH = 38] = "KeyH", t[t.KeyI = 39] = "KeyI", t[t.KeyJ = 40] = "KeyJ", t[t.KeyK = 41] = "KeyK", t[t.KeyL = 42] = "KeyL", t[t.KeyM = 43] = "KeyM", t[t.KeyN = 44] = "KeyN", t[t.KeyO = 45] = "KeyO", t[t.KeyP = 46] = "KeyP", t[t.KeyQ = 47] = "KeyQ", t[t.KeyR = 48] = "KeyR", t[t.KeyS = 49] = "KeyS", t[t.KeyT = 50] = "KeyT", t[t.KeyU = 51] = "KeyU", t[t.KeyV = 52] = "KeyV", t[t.KeyW = 53] = "KeyW", t[t.KeyX = 54] = "KeyX", t[t.KeyY = 55] = "KeyY", t[t.KeyZ = 56] = "KeyZ", t[t.Meta = 57] = "Meta", t[t.ContextMenu = 58] = "ContextMenu", t[t.F1 = 59] = "F1", t[t.F2 = 60] = "F2", t[t.F3 = 61] = "F3", t[t.F4 = 62] = "F4", t[t.F5 = 63] = "F5", t[t.F6 = 64] = "F6", t[t.F7 = 65] = "F7", t[t.F8 = 66] = "F8", t[t.F9 = 67] = "F9", t[t.F10 = 68] = "F10", t[t.F11 = 69] = "F11", t[t.F12 = 70] = "F12", t[t.F13 = 71] = "F13", t[t.F14 = 72] = "F14", t[t.F15 = 73] = "F15", t[t.F16 = 74] = "F16", t[t.F17 = 75] = "F17", t[t.F18 = 76] = "F18", t[t.F19 = 77] = "F19", t[t.F20 = 78] = "F20", t[t.F21 = 79] = "F21", t[t.F22 = 80] = "F22", t[t.F23 = 81] = "F23", t[t.F24 = 82] = "F24", t[t.NumLock = 83] = "NumLock", t[t.ScrollLock = 84] = "ScrollLock", t[t.Semicolon = 85] = "Semicolon", t[t.Equal = 86] = "Equal", t[t.Comma = 87] = "Comma", t[t.Minus = 88] = "Minus", t[t.Period = 89] = "Period", t[t.Slash = 90] = "Slash", t[t.Backquote = 91] = "Backquote", t[t.BracketLeft = 92] = "BracketLeft", t[t.Backslash = 93] = "Backslash", t[t.BracketRight = 94] = "BracketRight", t[t.Quote = 95] = "Quote", t[t.OEM_8 = 96] = "OEM_8", t[t.IntlBackslash = 97] = "IntlBackslash", t[t.Numpad0 = 98] = "Numpad0", t[t.Numpad1 = 99] = "Numpad1", t[t.Numpad2 = 100] = "Numpad2", t[t.Numpad3 = 101] = "Numpad3", t[t.Numpad4 = 102] = "Numpad4", t[t.Numpad5 = 103] = "Numpad5", t[t.Numpad6 = 104] = "Numpad6", t[t.Numpad7 = 105] = "Numpad7", t[t.Numpad8 = 106] = "Numpad8", t[t.Numpad9 = 107] = "Numpad9", t[t.NumpadMultiply = 108] = "NumpadMultiply", t[t.NumpadAdd = 109] = "NumpadAdd", t[t.NUMPAD_SEPARATOR = 110] = "NUMPAD_SEPARATOR", t[t.NumpadSubtract = 111] = "NumpadSubtract", t[t.NumpadDecimal = 112] = "NumpadDecimal", t[t.NumpadDivide = 113] = "NumpadDivide", t[t.KEY_IN_COMPOSITION = 114] = "KEY_IN_COMPOSITION", t[t.ABNT_C1 = 115] = "ABNT_C1", t[t.ABNT_C2 = 116] = "ABNT_C2", t[t.AudioVolumeMute = 117] = "AudioVolumeMute", t[t.AudioVolumeUp = 118] = "AudioVolumeUp", t[t.AudioVolumeDown = 119] = "AudioVolumeDown", t[t.BrowserSearch = 120] = "BrowserSearch", t[t.BrowserHome = 121] = "BrowserHome", t[t.BrowserBack = 122] = "BrowserBack", t[t.BrowserForward = 123] = "BrowserForward", t[t.MediaTrackNext = 124] = "MediaTrackNext", t[t.MediaTrackPrevious = 125] = "MediaTrackPrevious", t[t.MediaStop = 126] = "MediaStop", t[t.MediaPlayPause = 127] = "MediaPlayPause", t[t.LaunchMediaPlayer = 128] = "LaunchMediaPlayer", t[t.LaunchMail = 129] = "LaunchMail", t[t.LaunchApp2 = 130] = "LaunchApp2", t[t.Clear = 131] = "Clear", t[t.MAX_VALUE = 132] = "MAX_VALUE"
  })(yr || (yr = {}));
  var wr;
  (function(t) {
    t[t.Hint = 1] = "Hint", t[t.Info = 2] = "Info", t[t.Warning = 4] = "Warning", t[t.Error = 8] = "Error"
  })(wr || (wr = {}));
  var xr;
  (function(t) {
    t[t.Unnecessary = 1] = "Unnecessary", t[t.Deprecated = 2] = "Deprecated"
  })(xr || (xr = {}));
  var gs;
  (function(t) {
    t[t.Inline = 1] = "Inline", t[t.Gutter = 2] = "Gutter"
  })(gs || (gs = {}));
  var ps;
  (function(t) {
    t[t.Normal = 1] = "Normal", t[t.Underlined = 2] = "Underlined"
  })(ps || (ps = {}));
  var bs;
  (function(t) {
    t[t.UNKNOWN = 0] = "UNKNOWN", t[t.TEXTAREA = 1] = "TEXTAREA", t[t.GUTTER_GLYPH_MARGIN = 2] = "GUTTER_GLYPH_MARGIN", t[t.GUTTER_LINE_NUMBERS = 3] = "GUTTER_LINE_NUMBERS", t[t.GUTTER_LINE_DECORATIONS = 4] = "GUTTER_LINE_DECORATIONS", t[t.GUTTER_VIEW_ZONE = 5] = "GUTTER_VIEW_ZONE", t[t.CONTENT_TEXT = 6] = "CONTENT_TEXT", t[t.CONTENT_EMPTY = 7] = "CONTENT_EMPTY", t[t.CONTENT_VIEW_ZONE = 8] = "CONTENT_VIEW_ZONE", t[t.CONTENT_WIDGET = 9] = "CONTENT_WIDGET", t[t.OVERVIEW_RULER = 10] = "OVERVIEW_RULER", t[t.SCROLLBAR = 11] = "SCROLLBAR", t[t.OVERLAY_WIDGET = 12] = "OVERLAY_WIDGET", t[t.OUTSIDE_EDITOR = 13] = "OUTSIDE_EDITOR"
  })(bs || (bs = {}));
  var ys;
  (function(t) {
    t[t.AIGenerated = 1] = "AIGenerated"
  })(ys || (ys = {}));
  var ws;
  (function(t) {
    t[t.Invoke = 0] = "Invoke", t[t.Automatic = 1] = "Automatic"
  })(ws || (ws = {}));
  var xs;
  (function(t) {
    t[t.TOP_RIGHT_CORNER = 0] = "TOP_RIGHT_CORNER", t[t.BOTTOM_RIGHT_CORNER = 1] = "BOTTOM_RIGHT_CORNER", t[t.TOP_CENTER = 2] = "TOP_CENTER"
  })(xs || (xs = {}));
  var vs;
  (function(t) {
    t[t.Left = 1] = "Left", t[t.Center = 2] = "Center", t[t.Right = 4] = "Right", t[t.Full = 7] = "Full"
  })(vs || (vs = {}));
  var Ls;
  (function(t) {
    t[t.Word = 0] = "Word", t[t.Line = 1] = "Line", t[t.Suggest = 2] = "Suggest"
  })(Ls || (Ls = {}));
  var Ns;
  (function(t) {
    t[t.Left = 0] = "Left", t[t.Right = 1] = "Right", t[t.None = 2] = "None", t[t.LeftOfInjectedText = 3] = "LeftOfInjectedText", t[t.RightOfInjectedText = 4] = "RightOfInjectedText"
  })(Ns || (Ns = {}));
  var _s;
  (function(t) {
    t[t.Off = 0] = "Off", t[t.On = 1] = "On", t[t.Relative = 2] = "Relative", t[t.Interval = 3] = "Interval", t[t.Custom = 4] = "Custom"
  })(_s || (_s = {}));
  var Ss;
  (function(t) {
    t[t.None = 0] = "None", t[t.Text = 1] = "Text", t[t.Blocks = 2] = "Blocks"
  })(Ss || (Ss = {}));
  var As;
  (function(t) {
    t[t.Smooth = 0] = "Smooth", t[t.Immediate = 1] = "Immediate"
  })(As || (As = {}));
  var ks;
  (function(t) {
    t[t.Auto = 1] = "Auto", t[t.Hidden = 2] = "Hidden", t[t.Visible = 3] = "Visible"
  })(ks || (ks = {}));
  var vr;
  (function(t) {
    t[t.LTR = 0] = "LTR", t[t.RTL = 1] = "RTL"
  })(vr || (vr = {}));
  var Rs;
  (function(t) {
    t.Off = "off", t.OnCode = "onCode", t.On = "on"
  })(Rs || (Rs = {}));
  var Es;
  (function(t) {
    t[t.Invoke = 1] = "Invoke", t[t.TriggerCharacter = 2] = "TriggerCharacter", t[t.ContentChange = 3] = "ContentChange"
  })(Es || (Es = {}));
  var Ms;
  (function(t) {
    t[t.File = 0] = "File", t[t.Module = 1] = "Module", t[t.Namespace = 2] = "Namespace", t[t.Package = 3] = "Package", t[t.Class = 4] = "Class", t[t.Method = 5] = "Method", t[t.Property = 6] = "Property", t[t.Field = 7] = "Field", t[t.Constructor = 8] = "Constructor", t[t.Enum = 9] = "Enum", t[t.Interface = 10] = "Interface", t[t.Function = 11] = "Function", t[t.Variable = 12] = "Variable", t[t.Constant = 13] = "Constant", t[t.String = 14] = "String", t[t.Number = 15] = "Number", t[t.Boolean = 16] = "Boolean", t[t.Array = 17] = "Array", t[t.Object = 18] = "Object", t[t.Key = 19] = "Key", t[t.Null = 20] = "Null", t[t.EnumMember = 21] = "EnumMember", t[t.Struct = 22] = "Struct", t[t.Event = 23] = "Event", t[t.Operator = 24] = "Operator", t[t.TypeParameter = 25] = "TypeParameter"
  })(Ms || (Ms = {}));
  var Ts;
  (function(t) {
    t[t.Deprecated = 1] = "Deprecated"
  })(Ts || (Ts = {}));
  var Ps;
  (function(t) {
    t[t.LTR = 0] = "LTR", t[t.RTL = 1] = "RTL"
  })(Ps || (Ps = {}));
  var Cs;
  (function(t) {
    t[t.Hidden = 0] = "Hidden", t[t.Blink = 1] = "Blink", t[t.Smooth = 2] = "Smooth", t[t.Phase = 3] = "Phase", t[t.Expand = 4] = "Expand", t[t.Solid = 5] = "Solid"
  })(Cs || (Cs = {}));
  var Is;
  (function(t) {
    t[t.Line = 1] = "Line", t[t.Block = 2] = "Block", t[t.Underline = 3] = "Underline", t[t.LineThin = 4] = "LineThin", t[t.BlockOutline = 5] = "BlockOutline", t[t.UnderlineThin = 6] = "UnderlineThin"
  })(Is || (Is = {}));
  var Fs;
  (function(t) {
    t[t.AlwaysGrowsWhenTypingAtEdges = 0] = "AlwaysGrowsWhenTypingAtEdges", t[t.NeverGrowsWhenTypingAtEdges = 1] = "NeverGrowsWhenTypingAtEdges", t[t.GrowsOnlyWhenTypingBefore = 2] = "GrowsOnlyWhenTypingBefore", t[t.GrowsOnlyWhenTypingAfter = 3] = "GrowsOnlyWhenTypingAfter"
  })(Fs || (Fs = {}));
  var Vs;
  (function(t) {
    t[t.None = 0] = "None", t[t.Same = 1] = "Same", t[t.Indent = 2] = "Indent", t[t.DeepIndent = 3] = "DeepIndent"
  })(Vs || (Vs = {}));
  const Ut = class Ut {
    static chord(e, n) {
      return Jl(e, n)
    }
  };
  Ut.CtrlCmd = 2048, Ut.Shift = 1024, Ut.Alt = 512, Ut.WinCtrl = 256;
  let Lr = Ut;

  function yu() {
    return {
      editor: void 0,
      languages: void 0,
      CancellationTokenSource: Wl,
      Emitter: Ce,
      KeyCode: yr,
      KeyMod: Lr,
      Position: Q,
      Range: U,
      Selection: be,
      SelectionDirection: vr,
      MarkerSeverity: wr,
      MarkerTag: xr,
      Uri: gr,
      Token: bu
    }
  }
  var Ds;
  class wu {
    constructor() {
      this[Ds] = "LinkedMap", this._map = new Map, this._head = void 0, this._tail = void 0, this._size = 0, this._state = 0
    }
    clear() {
      this._map.clear(), this._head = void 0, this._tail = void 0, this._size = 0, this._state++
    }
    isEmpty() {
      return !this._head && !this._tail
    }
    get size() {
      return this._size
    }
    get first() {
      var e;
      return (e = this._head) == null ? void 0 : e.value
    }
    get last() {
      var e;
      return (e = this._tail) == null ? void 0 : e.value
    }
    has(e) {
      return this._map.has(e)
    }
    get(e, n = 0) {
      const r = this._map.get(e);
      if (r) return n !== 0 && this.touch(r, n), r.value
    }
    set(e, n, r = 0) {
      let i = this._map.get(e);
      if (i) i.value = n, r !== 0 && this.touch(i, r);
      else {
        switch (i = {
            key: e,
            value: n,
            next: void 0,
            previous: void 0
          }, r) {
          case 0:
            this.addItemLast(i);
            break;
          case 1:
            this.addItemFirst(i);
            break;
          case 2:
            this.addItemLast(i);
            break;
          default:
            this.addItemLast(i);
            break
        }
        this._map.set(e, i), this._size++
      }
      return this
    }
    delete(e) {
      return !!this.remove(e)
    }
    remove(e) {
      const n = this._map.get(e);
      if (n) return this._map.delete(e), this.removeItem(n), this._size--, n.value
    }
    shift() {
      if (!this._head && !this._tail) return;
      if (!this._head || !this._tail) throw new Error("Invalid list");
      const e = this._head;
      return this._map.delete(e.key), this.removeItem(e), this._size--, e.value
    }
    forEach(e, n) {
      const r = this._state;
      let i = this._head;
      for (; i;) {
        if (n ? e.bind(n)(i.value, i.key, this) : e(i.value, i.key, this), this._state !== r) throw new Error("LinkedMap got modified during iteration.");
        i = i.next
      }
    }
    keys() {
      const e = this,
        n = this._state;
      let r = this._head;
      const i = {
        [Symbol.iterator]() {
          return i
        },
        next() {
          if (e._state !== n) throw new Error("LinkedMap got modified during iteration.");
          if (r) {
            const s = {
              value: r.key,
              done: !1
            };
            return r = r.next, s
          } else return {
            value: void 0,
            done: !0
          }
        }
      };
      return i
    }
    values() {
      const e = this,
        n = this._state;
      let r = this._head;
      const i = {
        [Symbol.iterator]() {
          return i
        },
        next() {
          if (e._state !== n) throw new Error("LinkedMap got modified during iteration.");
          if (r) {
            const s = {
              value: r.value,
              done: !1
            };
            return r = r.next, s
          } else return {
            value: void 0,
            done: !0
          }
        }
      };
      return i
    }
    entries() {
      const e = this,
        n = this._state;
      let r = this._head;
      const i = {
        [Symbol.iterator]() {
          return i
        },
        next() {
          if (e._state !== n) throw new Error("LinkedMap got modified during iteration.");
          if (r) {
            const s = {
              value: [r.key, r.value],
              done: !1
            };
            return r = r.next, s
          } else return {
            value: void 0,
            done: !0
          }
        }
      };
      return i
    } [(Ds = Symbol.toStringTag, Symbol.iterator)]() {
      return this.entries()
    }
    trimOld(e) {
      if (e >= this.size) return;
      if (e === 0) {
        this.clear();
        return
      }
      let n = this._head,
        r = this.size;
      for (; n && r > e;) this._map.delete(n.key), n = n.next, r--;
      this._head = n, this._size = r, n && (n.previous = void 0), this._state++
    }
    trimNew(e) {
      if (e >= this.size) return;
      if (e === 0) {
        this.clear();
        return
      }
      let n = this._tail,
        r = this.size;
      for (; n && r > e;) this._map.delete(n.key), n = n.previous, r--;
      this._tail = n, this._size = r, n && (n.next = void 0), this._state++
    }
    addItemFirst(e) {
      if (!this._head && !this._tail) this._tail = e;
      else if (this._head) e.next = this._head, this._head.previous = e;
      else throw new Error("Invalid list");
      this._head = e, this._state++
    }
    addItemLast(e) {
      if (!this._head && !this._tail) this._head = e;
      else if (this._tail) e.previous = this._tail, this._tail.next = e;
      else throw new Error("Invalid list");
      this._tail = e, this._state++
    }
    removeItem(e) {
      if (e === this._head && e === this._tail) this._head = void 0, this._tail = void 0;
      else if (e === this._head) {
        if (!e.next) throw new Error("Invalid list");
        e.next.previous = void 0, this._head = e.next
      } else if (e === this._tail) {
        if (!e.previous) throw new Error("Invalid list");
        e.previous.next = void 0, this._tail = e.previous
      } else {
        const n = e.next,
          r = e.previous;
        if (!n || !r) throw new Error("Invalid list");
        n.previous = r, r.next = n
      }
      e.next = void 0, e.previous = void 0, this._state++
    }
    touch(e, n) {
      if (!this._head || !this._tail) throw new Error("Invalid list");
      if (!(n !== 1 && n !== 2)) {
        if (n === 1) {
          if (e === this._head) return;
          const r = e.next,
            i = e.previous;
          e === this._tail ? (i.next = void 0, this._tail = i) : (r.previous = i, i.next = r), e.previous = void 0, e.next = this._head, this._head.previous = e, this._head = e, this._state++
        } else if (n === 2) {
          if (e === this._tail) return;
          const r = e.next,
            i = e.previous;
          e === this._head ? (r.previous = void 0, this._head = r) : (r.previous = i, i.next = r), e.next = void 0, e.previous = this._tail, this._tail.next = e, this._tail = e, this._state++
        }
      }
    }
    toJSON() {
      const e = [];
      return this.forEach((n, r) => {
        e.push([r, n])
      }), e
    }
    fromJSON(e) {
      this.clear();
      for (const [n, r] of e) this.set(n, r)
    }
  }
  class xu extends wu {
    constructor(e, n = 1) {
      super(), this._limit = e, this._ratio = Math.min(Math.max(0, n), 1)
    }
    get limit() {
      return this._limit
    }
    set limit(e) {
      this._limit = e, this.checkTrim()
    }
    get(e, n = 2) {
      return super.get(e, n)
    }
    peek(e) {
      return super.get(e, 0)
    }
    set(e, n) {
      return super.set(e, n, 2), this
    }
    checkTrim() {
      this.size > this._limit && this.trim(Math.round(this._limit * this._ratio))
    }
  }
  class vu extends xu {
    constructor(e, n = 1) {
      super(e, n)
    }
    trim(e) {
      this.trimOld(e)
    }
    set(e, n) {
      return super.set(e, n), this.checkTrim(), this
    }
  }
  class Lu {
    constructor() {
      this.map = new Map
    }
    add(e, n) {
      let r = this.map.get(e);
      r || (r = new Set, this.map.set(e, r)), r.add(n)
    }
    delete(e, n) {
      const r = this.map.get(e);
      r && (r.delete(n), r.size === 0 && this.map.delete(e))
    }
    forEach(e, n) {
      const r = this.map.get(e);
      r && r.forEach(n)
    }
  }
  new vu(10);
  var Os;
  (function(t) {
    t[t.Left = 1] = "Left", t[t.Center = 2] = "Center", t[t.Right = 4] = "Right", t[t.Full = 7] = "Full"
  })(Os || (Os = {}));
  var $s;
  (function(t) {
    t[t.Left = 1] = "Left", t[t.Center = 2] = "Center", t[t.Right = 3] = "Right"
  })($s || ($s = {}));
  var Bs;
  (function(t) {
    t[t.LTR = 0] = "LTR", t[t.RTL = 1] = "RTL"
  })(Bs || (Bs = {}));
  var Us;
  (function(t) {
    t[t.Both = 0] = "Both", t[t.Right = 1] = "Right", t[t.Left = 2] = "Left", t[t.None = 3] = "None"
  })(Us || (Us = {}));

  function Nu(t) {
    if (!t || t.length === 0) return !1;
    for (let e = 0, n = t.length; e < n; e++) {
      const r = t.charCodeAt(e);
      if (r === 10) return !0;
      if (r === 92) {
        if (e++, e >= n) break;
        const i = t.charCodeAt(e);
        if (i === 110 || i === 114 || i === 87) return !0
      }
    }
    return !1
  }

  function _u(t, e, n, r, i) {
    if (r === 0) return !0;
    const s = e.charCodeAt(r - 1);
    if (t.get(s) !== 0 || s === 13 || s === 10) return !0;
    if (i > 0) {
      const a = e.charCodeAt(r);
      if (t.get(a) !== 0) return !0
    }
    return !1
  }

  function Su(t, e, n, r, i) {
    if (r + i === n) return !0;
    const s = e.charCodeAt(r + i);
    if (t.get(s) !== 0 || s === 13 || s === 10) return !0;
    if (i > 0) {
      const a = e.charCodeAt(r + i - 1);
      if (t.get(a) !== 0) return !0
    }
    return !1
  }

  function Au(t, e, n, r, i) {
    return _u(t, e, n, r, i) && Su(t, e, n, r, i)
  }
  class ku {
    constructor(e, n) {
      this._wordSeparators = e, this._searchRegex = n, this._prevMatchStartIndex = -1, this._prevMatchLength = 0
    }
    reset(e) {
      this._searchRegex.lastIndex = e, this._prevMatchStartIndex = -1, this._prevMatchLength = 0
    }
    next(e) {
      const n = e.length;
      let r;
      do {
        if (this._prevMatchStartIndex + this._prevMatchLength === n || (r = this._searchRegex.exec(e), !r)) return null;
        const i = r.index,
          s = r[0].length;
        if (i === this._prevMatchStartIndex && s === this._prevMatchLength) {
          if (s === 0) {
            Al(e, n, this._searchRegex.lastIndex) > 65535 ? this._searchRegex.lastIndex += 2 : this._searchRegex.lastIndex += 1;
            continue
          }
          return null
        }
        if (this._prevMatchStartIndex = i, this._prevMatchLength = s, !this._wordSeparators || Au(this._wordSeparators, e, n, i, s)) return r
      } while (r);
      return null
    }
  }
  const Ru = "`~!@#$%^&*()-=+[{]}\\|;:'\",.<>/?";

  function Eu(t = "") {
    let e = "(-?\\d*\\.\\d\\w*)|([^";
    for (const n of Ru) t.indexOf(n) >= 0 || (e += "\\" + n);
    return e += "\\s]+)", new RegExp(e, "g")
  }
  const qs = Eu();

  function js(t) {
    let e = qs;
    if (t && t instanceof RegExp)
      if (t.global) e = t;
      else {
        let n = "g";
        t.ignoreCase && (n += "i"), t.multiline && (n += "m"), t.unicode && (n += "u"), e = new RegExp(t.source, n)
      } return e.lastIndex = 0, e
  }
  const Ws = new el;
  Ws.unshift({
    maxLen: 1e3,
    windowSize: 15,
    timeBudget: 150
  });

  function Nr(t, e, n, r, i) {
    if (e = js(e), i || (i = mn.first(Ws)), n.length > i.maxLen) {
      let l = t - i.maxLen / 2;
      return l < 0 ? l = 0 : r += l, n = n.substring(l, t + i.maxLen / 2), Nr(t, e, n, r, i)
    }
    const s = Date.now(),
      a = t - 1 - r;
    let o = -1,
      u = null;
    for (let l = 1; !(Date.now() - s >= i.timeBudget); l++) {
      const h = a - i.windowSize * l;
      e.lastIndex = Math.max(0, h);
      const f = Mu(e, n, a, o);
      if (!f && u || (u = f, h <= 0)) break;
      o = h
    }
    if (u) {
      const l = {
        word: u[0],
        startColumn: r + 1 + u.index,
        endColumn: r + 1 + u.index + u[0].length
      };
      return e.lastIndex = 0, l
    }
    return null
  }

  function Mu(t, e, n, r) {
    let i;
    for (; i = t.exec(e);) {
      const s = i.index || 0;
      if (s <= n && t.lastIndex >= n) return i;
      if (r > 0 && s > r) return null
    }
    return null
  }
  class Tu {
    static computeUnicodeHighlights(e, n, r) {
      const i = r ? r.startLineNumber : 1,
        s = r ? r.endLineNumber : e.getLineCount(),
        a = new Hs(n),
        o = a.getCandidateCodePoints();
      let u;
      o === "allNonBasicAscii" ? u = new RegExp("[^\\t\\n\\r\\x20-\\x7E]", "g") : u = new RegExp(`${Pu(Array.from(o))}`, "g");
      const l = new ku(null, u),
        h = [];
      let f = !1,
        m, g = 0,
        d = 0,
        p = 0;
      e: for (let y = i, w = s; y <= w; y++) {
        const N = e.getLineContent(y),
          b = N.length;
        l.reset(0);
        do
          if (m = l.next(N), m) {
            let _ = m.index,
              L = m.index + m[0].length;
            if (_ > 0) {
              const M = N.charCodeAt(_ - 1);
              sr(M) && _--
            }
            if (L + 1 < b) {
              const M = N.charCodeAt(L - 1);
              sr(M) && L++
            }
            const A = N.substring(_, L);
            let v = Nr(_ + 1, qs, N, 0);
            v && v.endColumn <= _ + 1 && (v = null);
            const k = a.shouldHighlightNonBasicASCII(A, v ? v.word : null);
            if (k !== 0) {
              if (k === 3 ? g++ : k === 2 ? d++ : k === 1 ? p++ : Jo(), h.length >= 1e3) {
                f = !0;
                break e
              }
              h.push(new U(y, _ + 1, y, L + 1))
            }
          } while (m)
      }
      return {
        ranges: h,
        hasMore: f,
        ambiguousCharacterCount: g,
        invisibleCharacterCount: d,
        nonBasicAsciiCharacterCount: p
      }
    }
    static computeUnicodeHighlightReason(e, n) {
      const r = new Hs(n);
      switch (r.shouldHighlightNonBasicASCII(e, null)) {
        case 0:
          return null;
        case 2:
          return {
            kind: 1
          };
        case 3: {
          const s = e.codePointAt(0),
            a = r.ambiguousCharacters.getPrimaryConfusable(s),
            o = Ht.getLocales().filter(u => !Ht.getInstance(new Set([...n.allowedLocales, u])).isAmbiguous(s));
          return {
            kind: 0,
            confusableWith: String.fromCodePoint(a),
            notAmbiguousInLocales: o
          }
        }
        case 1:
          return {
            kind: 2
          }
      }
    }
  }

  function Pu(t, e) {
    return `[${bl(t.map(r=>String.fromCodePoint(r)).join(""))}]`
  }
  class Hs {
    constructor(e) {
      this.options = e, this.allowedCodePoints = new Set(e.allowedCodePoints), this.ambiguousCharacters = Ht.getInstance(new Set(e.allowedLocales))
    }
    getCandidateCodePoints() {
      if (this.options.nonBasicASCII) return "allNonBasicAscii";
      const e = new Set;
      if (this.options.invisibleCharacters)
        for (const n of zt.codePoints) zs(String.fromCodePoint(n)) || e.add(n);
      if (this.options.ambiguousCharacters)
        for (const n of this.ambiguousCharacters.getConfusableCodePoints()) e.add(n);
      for (const n of this.allowedCodePoints) e.delete(n);
      return e
    }
    shouldHighlightNonBasicASCII(e, n) {
      const r = e.codePointAt(0);
      if (this.allowedCodePoints.has(r)) return 0;
      if (this.options.nonBasicASCII) return 1;
      let i = !1,
        s = !1;
      if (n)
        for (const a of n) {
          const o = a.codePointAt(0),
            u = Rl(a);
          i = i || u, !u && !this.ambiguousCharacters.isAmbiguous(o) && !zt.isInvisibleCharacter(o) && (s = !0)
        }
      return !i && s ? 0 : this.options.invisibleCharacters && !zs(e) && zt.isInvisibleCharacter(r) ? 2 : this.options.ambiguousCharacters && this.ambiguousCharacters.isAmbiguous(r) ? 3 : 0
    }
  }

  function zs(t) {
    return t === " " || t === `
` || t === "	"
  }
  class _n {
    constructor(e, n, r) {
      this.changes = e, this.moves = n, this.hitTimeout = r
    }
  }
  class Cu {
    constructor(e, n) {
      this.lineRangeMapping = e, this.changes = n
    }
  }

  function Iu(t, e, n = (r, i) => r === i) {
    if (t === e) return !0;
    if (!t || !e || t.length !== e.length) return !1;
    for (let r = 0, i = t.length; r < i; r++)
      if (!n(t[r], e[r])) return !1;
    return !0
  }

  function* Fu(t, e) {
    let n, r;
    for (const i of t) r !== void 0 && e(r, i) ? n.push(i) : (n && (yield n), n = [i]), r = i;
    n && (yield n)
  }

  function Vu(t, e) {
    for (let n = 0; n <= t.length; n++) e(n === 0 ? void 0 : t[n - 1], n === t.length ? void 0 : t[n])
  }

  function Du(t, e) {
    for (let n = 0; n < t.length; n++) e(n === 0 ? void 0 : t[n - 1], t[n], n + 1 === t.length ? void 0 : t[n + 1])
  }

  function Ou(t, e) {
    for (const n of e) t.push(n)
  }
  var _r;
  (function(t) {
    function e(s) {
      return s < 0
    }
    t.isLessThan = e;

    function n(s) {
      return s <= 0
    }
    t.isLessThanOrEqual = n;

    function r(s) {
      return s > 0
    }
    t.isGreaterThan = r;

    function i(s) {
      return s === 0
    }
    t.isNeitherLessOrGreaterThan = i, t.greaterThan = 1, t.lessThan = -1, t.neitherLessOrGreaterThan = 0
  })(_r || (_r = {}));

  function Jt(t, e) {
    return (n, r) => e(t(n), t(r))
  }
  const Xt = (t, e) => t - e;

  function $u(t) {
    return (e, n) => -t(e, n)
  }
  const qt = class qt {
    constructor(e) {
      this.iterate = e
    }
    toArray() {
      const e = [];
      return this.iterate(n => (e.push(n), !0)), e
    }
    filter(e) {
      return new qt(n => this.iterate(r => e(r) ? n(r) : !0))
    }
    map(e) {
      return new qt(n => this.iterate(r => n(e(r))))
    }
    findLast(e) {
      let n;
      return this.iterate(r => (e(r) && (n = r), !0)), n
    }
    findLastMaxBy(e) {
      let n, r = !0;
      return this.iterate(i => ((r || _r.isGreaterThan(e(i, n))) && (r = !1, n = i), !0)), n
    }
  };
  qt.empty = new qt(e => {});
  let Gs = qt;
  class j {
    static fromTo(e, n) {
      return new j(e, n)
    }
    static addRange(e, n) {
      let r = 0;
      for (; r < n.length && n[r].endExclusive < e.start;) r++;
      let i = r;
      for (; i < n.length && n[i].start <= e.endExclusive;) i++;
      if (r === i) n.splice(r, 0, e);
      else {
        const s = Math.min(e.start, n[r].start),
          a = Math.max(e.endExclusive, n[i - 1].endExclusive);
        n.splice(r, i - r, new j(s, a))
      }
    }
    static tryCreate(e, n) {
      if (!(e > n)) return new j(e, n)
    }
    static ofLength(e) {
      return new j(0, e)
    }
    static ofStartAndLength(e, n) {
      return new j(e, e + n)
    }
    static emptyAt(e) {
      return new j(e, e)
    }
    constructor(e, n) {
      if (this.start = e, this.endExclusive = n, e > n) throw new ue(`Invalid range: ${this.toString()}`)
    }
    get isEmpty() {
      return this.start === this.endExclusive
    }
    delta(e) {
      return new j(this.start + e, this.endExclusive + e)
    }
    deltaStart(e) {
      return new j(this.start + e, this.endExclusive)
    }
    deltaEnd(e) {
      return new j(this.start, this.endExclusive + e)
    }
    get length() {
      return this.endExclusive - this.start
    }
    toString() {
      return `[${this.start}, ${this.endExclusive})`
    }
    equals(e) {
      return this.start === e.start && this.endExclusive === e.endExclusive
    }
    contains(e) {
      return this.start <= e && e < this.endExclusive
    }
    join(e) {
      return new j(Math.min(this.start, e.start), Math.max(this.endExclusive, e.endExclusive))
    }
    intersect(e) {
      const n = Math.max(this.start, e.start),
        r = Math.min(this.endExclusive, e.endExclusive);
      if (n <= r) return new j(n, r)
    }
    intersectionLength(e) {
      const n = Math.max(this.start, e.start),
        r = Math.min(this.endExclusive, e.endExclusive);
      return Math.max(0, r - n)
    }
    intersects(e) {
      const n = Math.max(this.start, e.start),
        r = Math.min(this.endExclusive, e.endExclusive);
      return n < r
    }
    intersectsOrTouches(e) {
      const n = Math.max(this.start, e.start),
        r = Math.min(this.endExclusive, e.endExclusive);
      return n <= r
    }
    isBefore(e) {
      return this.endExclusive <= e.start
    }
    isAfter(e) {
      return this.start >= e.endExclusive
    }
    slice(e) {
      return e.slice(this.start, this.endExclusive)
    }
    substring(e) {
      return e.substring(this.start, this.endExclusive)
    }
    clip(e) {
      if (this.isEmpty) throw new ue(`Invalid clipping range: ${this.toString()}`);
      return Math.max(this.start, Math.min(this.endExclusive - 1, e))
    }
    clipCyclic(e) {
      if (this.isEmpty) throw new ue(`Invalid clipping range: ${this.toString()}`);
      return e < this.start ? this.endExclusive - (this.start - e) % this.length : e >= this.endExclusive ? this.start + (e - this.start) % this.length : e
    }
    forEach(e) {
      for (let n = this.start; n < this.endExclusive; n++) e(n)
    }
    joinRightTouching(e) {
      if (this.endExclusive !== e.start) throw new ue(`Invalid join: ${this.toString()} and ${e.toString()}`);
      return new j(this.start, e.endExclusive)
    }
  }

  function Nt(t, e) {
    const n = _t(t, e);
    return n === -1 ? void 0 : t[n]
  }

  function _t(t, e, n = 0, r = t.length) {
    let i = n,
      s = r;
    for (; i < s;) {
      const a = Math.floor((i + s) / 2);
      e(t[a]) ? i = a + 1 : s = a
    }
    return i - 1
  }

  function Bu(t, e) {
    const n = Sr(t, e);
    return n === t.length ? void 0 : t[n]
  }

  function Sr(t, e, n = 0, r = t.length) {
    let i = n,
      s = r;
    for (; i < s;) {
      const a = Math.floor((i + s) / 2);
      e(t[a]) ? s = a : i = a + 1
    }
    return i
  }
  const qn = class qn {
    constructor(e) {
      this._array = e, this._findLastMonotonousLastIdx = 0
    }
    findLastMonotonous(e) {
      if (qn.assertInvariants) {
        if (this._prevFindLastPredicate) {
          for (const r of this._array)
            if (this._prevFindLastPredicate(r) && !e(r)) throw new Error("MonotonousArray: current predicate must be weaker than (or equal to) the previous predicate.")
        }
        this._prevFindLastPredicate = e
      }
      const n = _t(this._array, e, this._findLastMonotonousLastIdx);
      return this._findLastMonotonousLastIdx = n + 1, n === -1 ? void 0 : this._array[n]
    }
  };
  qn.assertInvariants = !1;
  let Sn = qn;
  const ve = class ve {
    static ofLength(e, n) {
      return new ve(e, e + n)
    }
    static fromRange(e) {
      return new ve(e.startLineNumber, e.endLineNumber)
    }
    static fromRangeInclusive(e) {
      return new ve(e.startLineNumber, e.endLineNumber + 1)
    }
    static joinMany(e) {
      if (e.length === 0) return [];
      let n = new Fe(e[0].slice());
      for (let r = 1; r < e.length; r++) n = n.getUnion(new Fe(e[r].slice()));
      return n.ranges
    }
    static join(e) {
      if (e.length === 0) throw new ue("lineRanges cannot be empty");
      let n = e[0].startLineNumber,
        r = e[0].endLineNumberExclusive;
      for (let i = 1; i < e.length; i++) n = Math.min(n, e[i].startLineNumber), r = Math.max(r, e[i].endLineNumberExclusive);
      return new ve(n, r)
    }
    static deserialize(e) {
      return new ve(e[0], e[1])
    }
    constructor(e, n) {
      if (e > n) throw new ue(`startLineNumber ${e} cannot be after endLineNumberExclusive ${n}`);
      this.startLineNumber = e, this.endLineNumberExclusive = n
    }
    contains(e) {
      return this.startLineNumber <= e && e < this.endLineNumberExclusive
    }
    get isEmpty() {
      return this.startLineNumber === this.endLineNumberExclusive
    }
    delta(e) {
      return new ve(this.startLineNumber + e, this.endLineNumberExclusive + e)
    }
    deltaLength(e) {
      return new ve(this.startLineNumber, this.endLineNumberExclusive + e)
    }
    get length() {
      return this.endLineNumberExclusive - this.startLineNumber
    }
    join(e) {
      return new ve(Math.min(this.startLineNumber, e.startLineNumber), Math.max(this.endLineNumberExclusive, e.endLineNumberExclusive))
    }
    toString() {
      return `[${this.startLineNumber},${this.endLineNumberExclusive})`
    }
    intersect(e) {
      const n = Math.max(this.startLineNumber, e.startLineNumber),
        r = Math.min(this.endLineNumberExclusive, e.endLineNumberExclusive);
      if (n <= r) return new ve(n, r)
    }
    intersectsStrict(e) {
      return this.startLineNumber < e.endLineNumberExclusive && e.startLineNumber < this.endLineNumberExclusive
    }
    intersectsOrTouches(e) {
      return this.startLineNumber <= e.endLineNumberExclusive && e.startLineNumber <= this.endLineNumberExclusive
    }
    equals(e) {
      return this.startLineNumber === e.startLineNumber && this.endLineNumberExclusive === e.endLineNumberExclusive
    }
    toInclusiveRange() {
      return this.isEmpty ? null : new U(this.startLineNumber, 1, this.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER)
    }
    toExclusiveRange() {
      return new U(this.startLineNumber, 1, this.endLineNumberExclusive, 1)
    }
    mapToLineArray(e) {
      const n = [];
      for (let r = this.startLineNumber; r < this.endLineNumberExclusive; r++) n.push(e(r));
      return n
    }
    forEach(e) {
      for (let n = this.startLineNumber; n < this.endLineNumberExclusive; n++) e(n)
    }
    serialize() {
      return [this.startLineNumber, this.endLineNumberExclusive]
    }
    toOffsetRange() {
      return new j(this.startLineNumber - 1, this.endLineNumberExclusive - 1)
    }
    addMargin(e, n) {
      return new ve(this.startLineNumber - e, this.endLineNumberExclusive + n)
    }
  };
  ve.compareByStart = Jt(e => e.startLineNumber, Xt);
  let H = ve;
  class Fe {
    constructor(e = []) {
      this._normalizedRanges = e
    }
    get ranges() {
      return this._normalizedRanges
    }
    addRange(e) {
      if (e.length === 0) return;
      const n = Sr(this._normalizedRanges, i => i.endLineNumberExclusive >= e.startLineNumber),
        r = _t(this._normalizedRanges, i => i.startLineNumber <= e.endLineNumberExclusive) + 1;
      if (n === r) this._normalizedRanges.splice(n, 0, e);
      else if (n === r - 1) {
        const i = this._normalizedRanges[n];
        this._normalizedRanges[n] = i.join(e)
      } else {
        const i = this._normalizedRanges[n].join(this._normalizedRanges[r - 1]).join(e);
        this._normalizedRanges.splice(n, r - n, i)
      }
    }
    contains(e) {
      const n = Nt(this._normalizedRanges, r => r.startLineNumber <= e);
      return !!n && n.endLineNumberExclusive > e
    }
    intersects(e) {
      const n = Nt(this._normalizedRanges, r => r.startLineNumber < e.endLineNumberExclusive);
      return !!n && n.endLineNumberExclusive > e.startLineNumber
    }
    getUnion(e) {
      if (this._normalizedRanges.length === 0) return e;
      if (e._normalizedRanges.length === 0) return this;
      const n = [];
      let r = 0,
        i = 0,
        s = null;
      for (; r < this._normalizedRanges.length || i < e._normalizedRanges.length;) {
        let a = null;
        if (r < this._normalizedRanges.length && i < e._normalizedRanges.length) {
          const o = this._normalizedRanges[r],
            u = e._normalizedRanges[i];
          o.startLineNumber < u.startLineNumber ? (a = o, r++) : (a = u, i++)
        } else r < this._normalizedRanges.length ? (a = this._normalizedRanges[r], r++) : (a = e._normalizedRanges[i], i++);
        s === null ? s = a : s.endLineNumberExclusive >= a.startLineNumber ? s = new H(s.startLineNumber, Math.max(s.endLineNumberExclusive, a.endLineNumberExclusive)) : (n.push(s), s = a)
      }
      return s !== null && n.push(s), new Fe(n)
    }
    subtractFrom(e) {
      const n = Sr(this._normalizedRanges, a => a.endLineNumberExclusive >= e.startLineNumber),
        r = _t(this._normalizedRanges, a => a.startLineNumber <= e.endLineNumberExclusive) + 1;
      if (n === r) return new Fe([e]);
      const i = [];
      let s = e.startLineNumber;
      for (let a = n; a < r; a++) {
        const o = this._normalizedRanges[a];
        o.startLineNumber > s && i.push(new H(s, o.startLineNumber)), s = o.endLineNumberExclusive
      }
      return s < e.endLineNumberExclusive && i.push(new H(s, e.endLineNumberExclusive)), new Fe(i)
    }
    toString() {
      return this._normalizedRanges.map(e => e.toString()).join(", ")
    }
    getIntersection(e) {
      const n = [];
      let r = 0,
        i = 0;
      for (; r < this._normalizedRanges.length && i < e._normalizedRanges.length;) {
        const s = this._normalizedRanges[r],
          a = e._normalizedRanges[i],
          o = s.intersect(a);
        o && !o.isEmpty && n.push(o), s.endLineNumberExclusive < a.endLineNumberExclusive ? r++ : i++
      }
      return new Fe(n)
    }
    getWithDelta(e) {
      return new Fe(this._normalizedRanges.map(n => n.delta(e)))
    }
  }
  const Pe = class Pe {
    static betweenPositions(e, n) {
      return e.lineNumber === n.lineNumber ? new Pe(0, n.column - e.column) : new Pe(n.lineNumber - e.lineNumber, n.column - 1)
    }
    static fromPosition(e) {
      return new Pe(e.lineNumber - 1, e.column - 1)
    }
    static ofRange(e) {
      return Pe.betweenPositions(e.getStartPosition(), e.getEndPosition())
    }
    static ofText(e) {
      let n = 0,
        r = 0;
      for (const i of e) i === `
` ? (n++, r = 0) : r++;
      return new Pe(n, r)
    }
    constructor(e, n) {
      this.lineCount = e, this.columnCount = n
    }
    isGreaterThanOrEqualTo(e) {
      return this.lineCount !== e.lineCount ? this.lineCount > e.lineCount : this.columnCount >= e.columnCount
    }
    add(e) {
      return e.lineCount === 0 ? new Pe(this.lineCount, this.columnCount + e.columnCount) : new Pe(this.lineCount + e.lineCount, e.columnCount)
    }
    createRange(e) {
      return this.lineCount === 0 ? new U(e.lineNumber, e.column, e.lineNumber, e.column + this.columnCount) : new U(e.lineNumber, e.column, e.lineNumber + this.lineCount, this.columnCount + 1)
    }
    toRange() {
      return new U(1, 1, this.lineCount + 1, this.columnCount + 1)
    }
    toLineRange() {
      return H.ofLength(1, this.lineCount + 1)
    }
    addToPosition(e) {
      return this.lineCount === 0 ? new Q(e.lineNumber, e.column + this.columnCount) : new Q(e.lineNumber + this.lineCount, this.columnCount + 1)
    }
    toString() {
      return `${this.lineCount},${this.columnCount}`
    }
  };
  Pe.zero = new Pe(0, 0);
  let Qt = Pe;
  class Uu {
    getOffsetRange(e) {
      return new j(this.getOffset(e.getStartPosition()), this.getOffset(e.getEndPosition()))
    }
    getRange(e) {
      return U.fromPositions(this.getPosition(e.start), this.getPosition(e.endExclusive))
    }
    getStringReplacement(e) {
      return new St.deps.StringReplacement(this.getOffsetRange(e.range), e.text)
    }
    getTextReplacement(e) {
      return new St.deps.TextReplacement(this.getRange(e.replaceRange), e.newText)
    }
    getTextEdit(e) {
      const n = e.replacements.map(r => this.getTextReplacement(r));
      return new St.deps.TextEdit(n)
    }
  }
  const oi = class oi {
    static get deps() {
      if (!this._deps) throw new Error("Dependencies not set. Call _setDependencies first.");
      return this._deps
    }
  };
  oi._deps = void 0;
  let St = oi;
  class qu extends Uu {
    constructor(e) {
      super(), this.text = e, this.lineStartOffsetByLineIdx = [], this.lineEndOffsetByLineIdx = [], this.lineStartOffsetByLineIdx.push(0);
      for (let n = 0; n < e.length; n++) e.charAt(n) === `
` && (this.lineStartOffsetByLineIdx.push(n + 1), n > 0 && e.charAt(n - 1) === "\r" ? this.lineEndOffsetByLineIdx.push(n - 1) : this.lineEndOffsetByLineIdx.push(n));
      this.lineEndOffsetByLineIdx.push(e.length)
    }
    getOffset(e) {
      const n = this._validatePosition(e);
      return this.lineStartOffsetByLineIdx[n.lineNumber - 1] + n.column - 1
    }
    _validatePosition(e) {
      if (e.lineNumber < 1) return new Q(1, 1);
      const n = this.textLength.lineCount + 1;
      if (e.lineNumber > n) {
        const i = this.getLineLength(n);
        return new Q(n, i + 1)
      }
      if (e.column < 1) return new Q(e.lineNumber, 1);
      const r = this.getLineLength(e.lineNumber);
      return e.column - 1 > r ? new Q(e.lineNumber, r + 1) : e
    }
    getPosition(e) {
      const n = _t(this.lineStartOffsetByLineIdx, s => s <= e),
        r = n + 1,
        i = e - this.lineStartOffsetByLineIdx[n] + 1;
      return new Q(r, i)
    }
    get textLength() {
      const e = this.lineStartOffsetByLineIdx.length - 1;
      return new St.deps.TextLength(e, this.text.length - this.lineStartOffsetByLineIdx[e])
    }
    getLineLength(e) {
      return this.lineEndOffsetByLineIdx[e - 1] - this.lineStartOffsetByLineIdx[e - 1]
    }
  }
  class ju {
    constructor() {
      this._transformer = void 0
    }
    get endPositionExclusive() {
      return this.length.addToPosition(new Q(1, 1))
    }
    get lineRange() {
      return this.length.toLineRange()
    }
    getValue() {
      return this.getValueOfRange(this.length.toRange())
    }
    getValueOfOffsetRange(e) {
      return this.getValueOfRange(this.getTransformer().getRange(e))
    }
    getLineLength(e) {
      return this.getValueOfRange(new U(e, 1, e, Number.MAX_SAFE_INTEGER)).length
    }
    getTransformer() {
      return this._transformer || (this._transformer = new qu(this.getValue())), this._transformer
    }
    getLineAt(e) {
      return this.getValueOfRange(new U(e, 1, e, Number.MAX_SAFE_INTEGER))
    }
  }
  class Wu extends ju {
    constructor(e, n) {
      Xo(n >= 1), super(), this._getLineContent = e, this._lineCount = n
    }
    getValueOfRange(e) {
      if (e.startLineNumber === e.endLineNumber) return this._getLineContent(e.startLineNumber).substring(e.startColumn - 1, e.endColumn - 1);
      let n = this._getLineContent(e.startLineNumber).substring(e.startColumn - 1);
      for (let r = e.startLineNumber + 1; r < e.endLineNumber; r++) n += `
` + this._getLineContent(r);
      return n += `
` + this._getLineContent(e.endLineNumber).substring(0, e.endColumn - 1), n
    }
    getLineLength(e) {
      return this._getLineContent(e).length
    }
    get length() {
      const e = this._getLineContent(this._lineCount);
      return new Qt(this._lineCount - 1, e.length)
    }
  }
  class An extends Wu {
    constructor(e) {
      super(n => e[n - 1], e.length)
    }
  }
  class Ze {
    static joinReplacements(e, n) {
      if (e.length === 0) throw new ue;
      if (e.length === 1) return e[0];
      const r = e[0].range.getStartPosition(),
        i = e[e.length - 1].range.getEndPosition();
      let s = "";
      for (let a = 0; a < e.length; a++) {
        const o = e[a];
        if (s += o.text, a < e.length - 1) {
          const u = e[a + 1],
            l = U.fromPositions(o.range.getEndPosition(), u.range.getStartPosition()),
            h = n.getValueOfRange(l);
          s += h
        }
      }
      return new Ze(U.fromPositions(r, i), s)
    }
    static fromStringReplacement(e, n) {
      return new Ze(n.getTransformer().getRange(e.replaceRange), e.newText)
    }
    static delete(e) {
      return new Ze(e, "")
    }
    constructor(e, n) {
      this.range = e, this.text = n
    }
    get isEmpty() {
      return this.range.isEmpty() && this.text.length === 0
    }
    static equals(e, n) {
      return e.range.equalsRange(n.range) && e.text === n.text
    }
    equals(e) {
      return Ze.equals(this, e)
    }
    removeCommonPrefixAndSuffix(e) {
      return this.removeCommonPrefix(e).removeCommonSuffix(e)
    }
    removeCommonPrefix(e) {
      const n = e.getValueOfRange(this.range).replaceAll(`\r
`, `
`),
        r = this.text.replaceAll(`\r
`, `
`),
        i = Ll(n, r),
        s = Qt.ofText(n.substring(0, i)).addToPosition(this.range.getStartPosition()),
        a = r.substring(i),
        o = U.fromPositions(s, this.range.getEndPosition());
      return new Ze(o, a)
    }
    removeCommonSuffix(e) {
      const n = e.getValueOfRange(this.range).replaceAll(`\r
`, `
`),
        r = this.text.replaceAll(`\r
`, `
`),
        i = Nl(n, r),
        s = Qt.ofText(n.substring(0, n.length - i)).addToPosition(this.range.getStartPosition()),
        a = r.substring(0, r.length - i),
        o = U.fromPositions(this.range.getStartPosition(), s);
      return new Ze(o, a)
    }
    toString() {
      const e = this.range.getStartPosition(),
        n = this.range.getEndPosition();
      return `(${e.lineNumber},${e.column} -> ${n.lineNumber},${n.column}): "${this.text}"`
    }
  }
  class Le {
    static inverse(e, n, r) {
      const i = [];
      let s = 1,
        a = 1;
      for (const u of e) {
        const l = new Le(new H(s, u.original.startLineNumber), new H(a, u.modified.startLineNumber));
        l.modified.isEmpty || i.push(l), s = u.original.endLineNumberExclusive, a = u.modified.endLineNumberExclusive
      }
      const o = new Le(new H(s, n + 1), new H(a, r + 1));
      return o.modified.isEmpty || i.push(o), i
    }
    static clip(e, n, r) {
      const i = [];
      for (const s of e) {
        const a = s.original.intersect(n),
          o = s.modified.intersect(r);
        a && !a.isEmpty && o && !o.isEmpty && i.push(new Le(a, o))
      }
      return i
    }
    constructor(e, n) {
      this.original = e, this.modified = n
    }
    toString() {
      return `{${this.original.toString()}->${this.modified.toString()}}`
    }
    flip() {
      return new Le(this.modified, this.original)
    }
    join(e) {
      return new Le(this.original.join(e.original), this.modified.join(e.modified))
    }
    toRangeMapping() {
      const e = this.original.toInclusiveRange(),
        n = this.modified.toInclusiveRange();
      if (e && n) return new Ne(e, n);
      if (this.original.startLineNumber === 1 || this.modified.startLineNumber === 1) {
        if (!(this.modified.startLineNumber === 1 && this.original.startLineNumber === 1)) throw new ue("not a valid diff");
        return new Ne(new U(this.original.startLineNumber, 1, this.original.endLineNumberExclusive, 1), new U(this.modified.startLineNumber, 1, this.modified.endLineNumberExclusive, 1))
      } else return new Ne(new U(this.original.startLineNumber - 1, Number.MAX_SAFE_INTEGER, this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), new U(this.modified.startLineNumber - 1, Number.MAX_SAFE_INTEGER, this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER))
    }
    toRangeMapping2(e, n) {
      if (Js(this.original.endLineNumberExclusive, e) && Js(this.modified.endLineNumberExclusive, n)) return new Ne(new U(this.original.startLineNumber, 1, this.original.endLineNumberExclusive, 1), new U(this.modified.startLineNumber, 1, this.modified.endLineNumberExclusive, 1));
      if (!this.original.isEmpty && !this.modified.isEmpty) return new Ne(U.fromPositions(new Q(this.original.startLineNumber, 1), At(new Q(this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), e)), U.fromPositions(new Q(this.modified.startLineNumber, 1), At(new Q(this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), n)));
      if (this.original.startLineNumber > 1 && this.modified.startLineNumber > 1) return new Ne(U.fromPositions(At(new Q(this.original.startLineNumber - 1, Number.MAX_SAFE_INTEGER), e), At(new Q(this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), e)), U.fromPositions(At(new Q(this.modified.startLineNumber - 1, Number.MAX_SAFE_INTEGER), n), At(new Q(this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), n)));
      throw new ue
    }
  }

  function At(t, e) {
    if (t.lineNumber < 1) return new Q(1, 1);
    if (t.lineNumber > e.length) return new Q(e.length, e[e.length - 1].length + 1);
    const n = e[t.lineNumber - 1];
    return t.column > n.length + 1 ? new Q(t.lineNumber, n.length + 1) : t
  }

  function Js(t, e) {
    return t >= 1 && t <= e.length
  }
  class We extends Le {
    static fromRangeMappings(e) {
      const n = H.join(e.map(i => H.fromRangeInclusive(i.originalRange))),
        r = H.join(e.map(i => H.fromRangeInclusive(i.modifiedRange)));
      return new We(n, r, e)
    }
    constructor(e, n, r) {
      super(e, n), this.innerChanges = r
    }
    flip() {
      var e;
      return new We(this.modified, this.original, (e = this.innerChanges) == null ? void 0 : e.map(n => n.flip()))
    }
    withInnerChangesFromLineRanges() {
      return new We(this.original, this.modified, [this.toRangeMapping()])
    }
  }
  class Ne {
    static fromEdit(e) {
      const n = e.getNewRanges();
      return e.replacements.map((i, s) => new Ne(i.range, n[s]))
    }
    static assertSorted(e) {
      for (let n = 1; n < e.length; n++) {
        const r = e[n - 1],
          i = e[n];
        if (!(r.originalRange.getEndPosition().isBeforeOrEqual(i.originalRange.getStartPosition()) && r.modifiedRange.getEndPosition().isBeforeOrEqual(i.modifiedRange.getStartPosition()))) throw new ue("Range mappings must be sorted")
      }
    }
    constructor(e, n) {
      this.originalRange = e, this.modifiedRange = n
    }
    toString() {
      return `{${this.originalRange.toString()}->${this.modifiedRange.toString()}}`
    }
    flip() {
      return new Ne(this.modifiedRange, this.originalRange)
    }
    toTextEdit(e) {
      const n = e.getValueOfRange(this.modifiedRange);
      return new Ze(this.originalRange, n)
    }
  }

  function Xs(t, e, n, r = !1) {
    const i = [];
    for (const s of Fu(t.map(a => Hu(a, e, n)), (a, o) => a.original.intersectsOrTouches(o.original) || a.modified.intersectsOrTouches(o.modified))) {
      const a = s[0],
        o = s[s.length - 1];
      i.push(new We(a.original.join(o.original), a.modified.join(o.modified), s.map(u => u.innerChanges[0])))
    }
    return hn(() => !r && i.length > 0 && (i[0].modified.startLineNumber !== i[0].original.startLineNumber || n.length.lineCount - i[i.length - 1].modified.endLineNumberExclusive !== e.length.lineCount - i[i.length - 1].original.endLineNumberExclusive) ? !1 : ui(i, (s, a) => a.original.startLineNumber - s.original.endLineNumberExclusive === a.modified.startLineNumber - s.modified.endLineNumberExclusive && s.original.endLineNumberExclusive < a.original.startLineNumber && s.modified.endLineNumberExclusive < a.modified.startLineNumber)), i
  }

  function Hu(t, e, n) {
    let r = 0,
      i = 0;
    t.modifiedRange.endColumn === 1 && t.originalRange.endColumn === 1 && t.originalRange.startLineNumber + r <= t.originalRange.endLineNumber && t.modifiedRange.startLineNumber + r <= t.modifiedRange.endLineNumber && (i = -1), t.modifiedRange.startColumn - 1 >= n.getLineLength(t.modifiedRange.startLineNumber) && t.originalRange.startColumn - 1 >= e.getLineLength(t.originalRange.startLineNumber) && t.originalRange.startLineNumber <= t.originalRange.endLineNumber + i && t.modifiedRange.startLineNumber <= t.modifiedRange.endLineNumber + i && (r = 1);
    const s = new H(t.originalRange.startLineNumber + r, t.originalRange.endLineNumber + 1 + i),
      a = new H(t.modifiedRange.startLineNumber + r, t.modifiedRange.endLineNumber + 1 + i);
    return new We(s, a, [t])
  }
  const zu = 3;
  class Gu {
    computeDiff(e, n, r) {
      var u;
      const s = new Qu(e, n, {
          maxComputationTime: r.maxComputationTimeMs,
          shouldIgnoreTrimWhitespace: r.ignoreTrimWhitespace,
          shouldComputeCharChanges: !0,
          shouldMakePrettyDiff: !0,
          shouldPostProcessCharChanges: !0
        }).computeDiff(),
        a = [];
      let o = null;
      for (const l of s.changes) {
        let h;
        l.originalEndLineNumber === 0 ? h = new H(l.originalStartLineNumber + 1, l.originalStartLineNumber + 1) : h = new H(l.originalStartLineNumber, l.originalEndLineNumber + 1);
        let f;
        l.modifiedEndLineNumber === 0 ? f = new H(l.modifiedStartLineNumber + 1, l.modifiedStartLineNumber + 1) : f = new H(l.modifiedStartLineNumber, l.modifiedEndLineNumber + 1);
        let m = new We(h, f, (u = l.charChanges) == null ? void 0 : u.map(g => new Ne(new U(g.originalStartLineNumber, g.originalStartColumn, g.originalEndLineNumber, g.originalEndColumn), new U(g.modifiedStartLineNumber, g.modifiedStartColumn, g.modifiedEndLineNumber, g.modifiedEndColumn))));
        o && (o.modified.endLineNumberExclusive === m.modified.startLineNumber || o.original.endLineNumberExclusive === m.original.startLineNumber) && (m = new We(o.original.join(m.original), o.modified.join(m.modified), o.innerChanges && m.innerChanges ? o.innerChanges.concat(m.innerChanges) : void 0), a.pop()), a.push(m), o = m
      }
      return hn(() => ui(a, (l, h) => h.original.startLineNumber - l.original.endLineNumberExclusive === h.modified.startLineNumber - l.modified.endLineNumberExclusive && l.original.endLineNumberExclusive < h.original.startLineNumber && l.modified.endLineNumberExclusive < h.modified.startLineNumber)), new _n(a, [], s.quitEarly)
    }
  }

  function Qs(t, e, n, r) {
    return new Xe(t, e, n).ComputeDiff(r)
  }
  let Zs = class {
    constructor(e) {
      const n = [],
        r = [];
      for (let i = 0, s = e.length; i < s; i++) n[i] = Ar(e[i], 1), r[i] = kr(e[i], 1);
      this.lines = e, this._startColumns = n, this._endColumns = r
    }
    getElements() {
      const e = [];
      for (let n = 0, r = this.lines.length; n < r; n++) e[n] = this.lines[n].substring(this._startColumns[n] - 1, this._endColumns[n] - 1);
      return e
    }
    getStrictElement(e) {
      return this.lines[e]
    }
    getStartLineNumber(e) {
      return e + 1
    }
    getEndLineNumber(e) {
      return e + 1
    }
    createCharSequence(e, n, r) {
      const i = [],
        s = [],
        a = [];
      let o = 0;
      for (let u = n; u <= r; u++) {
        const l = this.lines[u],
          h = e ? this._startColumns[u] : 1,
          f = e ? this._endColumns[u] : l.length + 1;
        for (let m = h; m < f; m++) i[o] = l.charCodeAt(m - 1), s[o] = u + 1, a[o] = m, o++;
        !e && u < r && (i[o] = 10, s[o] = u + 1, a[o] = l.length + 1, o++)
      }
      return new Ju(i, s, a)
    }
  };
  class Ju {
    constructor(e, n, r) {
      this._charCodes = e, this._lineNumbers = n, this._columns = r
    }
    toString() {
      return "[" + this._charCodes.map((e, n) => (e === 10 ? "\\n" : String.fromCharCode(e)) + `-(${this._lineNumbers[n]},${this._columns[n]})`).join(", ") + "]"
    }
    _assertIndex(e, n) {
      if (e < 0 || e >= n.length) throw new Error("Illegal index")
    }
    getElements() {
      return this._charCodes
    }
    getStartLineNumber(e) {
      return e > 0 && e === this._lineNumbers.length ? this.getEndLineNumber(e - 1) : (this._assertIndex(e, this._lineNumbers), this._lineNumbers[e])
    }
    getEndLineNumber(e) {
      return e === -1 ? this.getStartLineNumber(e + 1) : (this._assertIndex(e, this._lineNumbers), this._charCodes[e] === 10 ? this._lineNumbers[e] + 1 : this._lineNumbers[e])
    }
    getStartColumn(e) {
      return e > 0 && e === this._columns.length ? this.getEndColumn(e - 1) : (this._assertIndex(e, this._columns), this._columns[e])
    }
    getEndColumn(e) {
      return e === -1 ? this.getStartColumn(e + 1) : (this._assertIndex(e, this._columns), this._charCodes[e] === 10 ? 1 : this._columns[e] + 1)
    }
  }
  class kt {
    constructor(e, n, r, i, s, a, o, u) {
      this.originalStartLineNumber = e, this.originalStartColumn = n, this.originalEndLineNumber = r, this.originalEndColumn = i, this.modifiedStartLineNumber = s, this.modifiedStartColumn = a, this.modifiedEndLineNumber = o, this.modifiedEndColumn = u
    }
    static createFromDiffChange(e, n, r) {
      const i = n.getStartLineNumber(e.originalStart),
        s = n.getStartColumn(e.originalStart),
        a = n.getEndLineNumber(e.originalStart + e.originalLength - 1),
        o = n.getEndColumn(e.originalStart + e.originalLength - 1),
        u = r.getStartLineNumber(e.modifiedStart),
        l = r.getStartColumn(e.modifiedStart),
        h = r.getEndLineNumber(e.modifiedStart + e.modifiedLength - 1),
        f = r.getEndColumn(e.modifiedStart + e.modifiedLength - 1);
      return new kt(i, s, a, o, u, l, h, f)
    }
  }

  function Xu(t) {
    if (t.length <= 1) return t;
    const e = [t[0]];
    let n = e[0];
    for (let r = 1, i = t.length; r < i; r++) {
      const s = t[r],
        a = s.originalStart - (n.originalStart + n.originalLength),
        o = s.modifiedStart - (n.modifiedStart + n.modifiedLength);
      Math.min(a, o) < zu ? (n.originalLength = s.originalStart + s.originalLength - n.originalStart, n.modifiedLength = s.modifiedStart + s.modifiedLength - n.modifiedStart) : (e.push(s), n = s)
    }
    return e
  }
  class Zt {
    constructor(e, n, r, i, s) {
      this.originalStartLineNumber = e, this.originalEndLineNumber = n, this.modifiedStartLineNumber = r, this.modifiedEndLineNumber = i, this.charChanges = s
    }
    static createFromDiffResult(e, n, r, i, s, a, o) {
      let u, l, h, f, m;
      if (n.originalLength === 0 ? (u = r.getStartLineNumber(n.originalStart) - 1, l = 0) : (u = r.getStartLineNumber(n.originalStart), l = r.getEndLineNumber(n.originalStart + n.originalLength - 1)), n.modifiedLength === 0 ? (h = i.getStartLineNumber(n.modifiedStart) - 1, f = 0) : (h = i.getStartLineNumber(n.modifiedStart), f = i.getEndLineNumber(n.modifiedStart + n.modifiedLength - 1)), a && n.originalLength > 0 && n.originalLength < 20 && n.modifiedLength > 0 && n.modifiedLength < 20 && s()) {
        const g = r.createCharSequence(e, n.originalStart, n.originalStart + n.originalLength - 1),
          d = i.createCharSequence(e, n.modifiedStart, n.modifiedStart + n.modifiedLength - 1);
        if (g.getElements().length > 0 && d.getElements().length > 0) {
          let p = Qs(g, d, s, !0).changes;
          o && (p = Xu(p)), m = [];
          for (let y = 0, w = p.length; y < w; y++) m.push(kt.createFromDiffChange(p[y], g, d))
        }
      }
      return new Zt(u, l, h, f, m)
    }
  }
  class Qu {
    constructor(e, n, r) {
      this.shouldComputeCharChanges = r.shouldComputeCharChanges, this.shouldPostProcessCharChanges = r.shouldPostProcessCharChanges, this.shouldIgnoreTrimWhitespace = r.shouldIgnoreTrimWhitespace, this.shouldMakePrettyDiff = r.shouldMakePrettyDiff, this.originalLines = e, this.modifiedLines = n, this.original = new Zs(e), this.modified = new Zs(n), this.continueLineDiff = Ys(r.maxComputationTime), this.continueCharDiff = Ys(r.maxComputationTime === 0 ? 0 : Math.min(r.maxComputationTime, 5e3))
    }
    computeDiff() {
      if (this.original.lines.length === 1 && this.original.lines[0].length === 0) return this.modified.lines.length === 1 && this.modified.lines[0].length === 0 ? {
        quitEarly: !1,
        changes: []
      } : {
        quitEarly: !1,
        changes: [{
          originalStartLineNumber: 1,
          originalEndLineNumber: 1,
          modifiedStartLineNumber: 1,
          modifiedEndLineNumber: this.modified.lines.length,
          charChanges: void 0
        }]
      };
      if (this.modified.lines.length === 1 && this.modified.lines[0].length === 0) return {
        quitEarly: !1,
        changes: [{
          originalStartLineNumber: 1,
          originalEndLineNumber: this.original.lines.length,
          modifiedStartLineNumber: 1,
          modifiedEndLineNumber: 1,
          charChanges: void 0
        }]
      };
      const e = Qs(this.original, this.modified, this.continueLineDiff, this.shouldMakePrettyDiff),
        n = e.changes,
        r = e.quitEarly;
      if (this.shouldIgnoreTrimWhitespace) {
        const o = [];
        for (let u = 0, l = n.length; u < l; u++) o.push(Zt.createFromDiffResult(this.shouldIgnoreTrimWhitespace, n[u], this.original, this.modified, this.continueCharDiff, this.shouldComputeCharChanges, this.shouldPostProcessCharChanges));
        return {
          quitEarly: r,
          changes: o
        }
      }
      const i = [];
      let s = 0,
        a = 0;
      for (let o = -1, u = n.length; o < u; o++) {
        const l = o + 1 < u ? n[o + 1] : null,
          h = l ? l.originalStart : this.originalLines.length,
          f = l ? l.modifiedStart : this.modifiedLines.length;
        for (; s < h && a < f;) {
          const m = this.originalLines[s],
            g = this.modifiedLines[a];
          if (m !== g) {
            {
              let d = Ar(m, 1),
                p = Ar(g, 1);
              for (; d > 1 && p > 1;) {
                const y = m.charCodeAt(d - 2),
                  w = g.charCodeAt(p - 2);
                if (y !== w) break;
                d--, p--
              }(d > 1 || p > 1) && this._pushTrimWhitespaceCharChange(i, s + 1, 1, d, a + 1, 1, p)
            } {
              let d = kr(m, 1),
                p = kr(g, 1);
              const y = m.length + 1,
                w = g.length + 1;
              for (; d < y && p < w;) {
                const N = m.charCodeAt(d - 1),
                  b = m.charCodeAt(p - 1);
                if (N !== b) break;
                d++, p++
              }(d < y || p < w) && this._pushTrimWhitespaceCharChange(i, s + 1, d, y, a + 1, p, w)
            }
          }
          s++, a++
        }
        l && (i.push(Zt.createFromDiffResult(this.shouldIgnoreTrimWhitespace, l, this.original, this.modified, this.continueCharDiff, this.shouldComputeCharChanges, this.shouldPostProcessCharChanges)), s += l.originalLength, a += l.modifiedLength)
      }
      return {
        quitEarly: r,
        changes: i
      }
    }
    _pushTrimWhitespaceCharChange(e, n, r, i, s, a, o) {
      if (this._mergeTrimWhitespaceCharChange(e, n, r, i, s, a, o)) return;
      let u;
      this.shouldComputeCharChanges && (u = [new kt(n, r, n, i, s, a, s, o)]), e.push(new Zt(n, n, s, s, u))
    }
    _mergeTrimWhitespaceCharChange(e, n, r, i, s, a, o) {
      const u = e.length;
      if (u === 0) return !1;
      const l = e[u - 1];
      return l.originalEndLineNumber === 0 || l.modifiedEndLineNumber === 0 ? !1 : l.originalEndLineNumber === n && l.modifiedEndLineNumber === s ? (this.shouldComputeCharChanges && l.charChanges && l.charChanges.push(new kt(n, r, n, i, s, a, s, o)), !0) : l.originalEndLineNumber + 1 === n && l.modifiedEndLineNumber + 1 === s ? (l.originalEndLineNumber = n, l.modifiedEndLineNumber = s, this.shouldComputeCharChanges && l.charChanges && l.charChanges.push(new kt(n, r, n, i, s, a, s, o)), !0) : !1
    }
  }

  function Ar(t, e) {
    const n = xl(t);
    return n === -1 ? e : n + 1
  }

  function kr(t, e) {
    const n = vl(t);
    return n === -1 ? e : n + 2
  }

  function Ys(t) {
    if (t === 0) return () => !0;
    const e = Date.now();
    return () => Date.now() - e < t
  }
  class He {
    static trivial(e, n) {
      return new He([new K(j.ofLength(e.length), j.ofLength(n.length))], !1)
    }
    static trivialTimedOut(e, n) {
      return new He([new K(j.ofLength(e.length), j.ofLength(n.length))], !0)
    }
    constructor(e, n) {
      this.diffs = e, this.hitTimeout = n
    }
  }
  class K {
    static invert(e, n) {
      const r = [];
      return Vu(e, (i, s) => {
        r.push(K.fromOffsetPairs(i ? i.getEndExclusives() : ze.zero, s ? s.getStarts() : new ze(n, (i ? i.seq2Range.endExclusive - i.seq1Range.endExclusive : 0) + n)))
      }), r
    }
    static fromOffsetPairs(e, n) {
      return new K(new j(e.offset1, n.offset1), new j(e.offset2, n.offset2))
    }
    static assertSorted(e) {
      let n;
      for (const r of e) {
        if (n && !(n.seq1Range.endExclusive <= r.seq1Range.start && n.seq2Range.endExclusive <= r.seq2Range.start)) throw new ue("Sequence diffs must be sorted");
        n = r
      }
    }
    constructor(e, n) {
      this.seq1Range = e, this.seq2Range = n
    }
    swap() {
      return new K(this.seq2Range, this.seq1Range)
    }
    toString() {
      return `${this.seq1Range} <-> ${this.seq2Range}`
    }
    join(e) {
      return new K(this.seq1Range.join(e.seq1Range), this.seq2Range.join(e.seq2Range))
    }
    delta(e) {
      return e === 0 ? this : new K(this.seq1Range.delta(e), this.seq2Range.delta(e))
    }
    deltaStart(e) {
      return e === 0 ? this : new K(this.seq1Range.deltaStart(e), this.seq2Range.deltaStart(e))
    }
    deltaEnd(e) {
      return e === 0 ? this : new K(this.seq1Range.deltaEnd(e), this.seq2Range.deltaEnd(e))
    }
    intersect(e) {
      const n = this.seq1Range.intersect(e.seq1Range),
        r = this.seq2Range.intersect(e.seq2Range);
      if (!(!n || !r)) return new K(n, r)
    }
    getStarts() {
      return new ze(this.seq1Range.start, this.seq2Range.start)
    }
    getEndExclusives() {
      return new ze(this.seq1Range.endExclusive, this.seq2Range.endExclusive)
    }
  }
  const ht = class ht {
    constructor(e, n) {
      this.offset1 = e, this.offset2 = n
    }
    toString() {
      return `${this.offset1} <-> ${this.offset2}`
    }
    delta(e) {
      return e === 0 ? this : new ht(this.offset1 + e, this.offset2 + e)
    }
    equals(e) {
      return this.offset1 === e.offset1 && this.offset2 === e.offset2
    }
  };
  ht.zero = new ht(0, 0), ht.max = new ht(Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
  let ze = ht;
  const jn = class jn {
    isValid() {
      return !0
    }
  };
  jn.instance = new jn;
  let Yt = jn;
  class Zu {
    constructor(e) {
      if (this.timeout = e, this.startTime = Date.now(), this.valid = !0, e <= 0) throw new ue("timeout must be positive")
    }
    isValid() {
      return !(Date.now() - this.startTime < this.timeout) && this.valid && (this.valid = !1), this.valid
    }
  }
  class Rr {
    constructor(e, n) {
      this.width = e, this.height = n, this.array = [], this.array = new Array(e * n)
    }
    get(e, n) {
      return this.array[e + n * this.width]
    }
    set(e, n, r) {
      this.array[e + n * this.width] = r
    }
  }

  function Er(t) {
    return t === 32 || t === 9
  }
  const cn = class cn {
    static getKey(e) {
      let n = this.chrKeys.get(e);
      return n === void 0 && (n = this.chrKeys.size, this.chrKeys.set(e, n)), n
    }
    constructor(e, n, r) {
      this.range = e, this.lines = n, this.source = r, this.histogram = [];
      let i = 0;
      for (let s = e.startLineNumber - 1; s < e.endLineNumberExclusive - 1; s++) {
        const a = n[s];
        for (let u = 0; u < a.length; u++) {
          i++;
          const l = a[u],
            h = cn.getKey(l);
          this.histogram[h] = (this.histogram[h] || 0) + 1
        }
        i++;
        const o = cn.getKey(`
`);
        this.histogram[o] = (this.histogram[o] || 0) + 1
      }
      this.totalCount = i
    }
    computeSimilarity(e) {
      let n = 0;
      const r = Math.max(this.histogram.length, e.histogram.length);
      for (let i = 0; i < r; i++) n += Math.abs((this.histogram[i] ?? 0) - (e.histogram[i] ?? 0));
      return 1 - n / (this.totalCount + e.totalCount)
    }
  };
  cn.chrKeys = new Map;
  let kn = cn;
  class Yu {
    compute(e, n, r = Yt.instance, i) {
      if (e.length === 0 || n.length === 0) return He.trivial(e, n);
      const s = new Rr(e.length, n.length),
        a = new Rr(e.length, n.length),
        o = new Rr(e.length, n.length);
      for (let d = 0; d < e.length; d++)
        for (let p = 0; p < n.length; p++) {
          if (!r.isValid()) return He.trivialTimedOut(e, n);
          const y = d === 0 ? 0 : s.get(d - 1, p),
            w = p === 0 ? 0 : s.get(d, p - 1);
          let N;
          e.getElement(d) === n.getElement(p) ? (d === 0 || p === 0 ? N = 0 : N = s.get(d - 1, p - 1), d > 0 && p > 0 && a.get(d - 1, p - 1) === 3 && (N += o.get(d - 1, p - 1)), N += i ? i(d, p) : 1) : N = -1;
          const b = Math.max(y, w, N);
          if (b === N) {
            const _ = d > 0 && p > 0 ? o.get(d - 1, p - 1) : 0;
            o.set(d, p, _ + 1), a.set(d, p, 3)
          } else b === y ? (o.set(d, p, 0), a.set(d, p, 1)) : b === w && (o.set(d, p, 0), a.set(d, p, 2));
          s.set(d, p, b)
        }
      const u = [];
      let l = e.length,
        h = n.length;

      function f(d, p) {
        (d + 1 !== l || p + 1 !== h) && u.push(new K(new j(d + 1, l), new j(p + 1, h))), l = d, h = p
      }
      let m = e.length - 1,
        g = n.length - 1;
      for (; m >= 0 && g >= 0;) a.get(m, g) === 3 ? (f(m, g), m--, g--) : a.get(m, g) === 1 ? m-- : g--;
      return f(-1, -1), u.reverse(), new He(u, !1)
    }
  }
  class Ks {
    compute(e, n, r = Yt.instance) {
      if (e.length === 0 || n.length === 0) return He.trivial(e, n);
      const i = e,
        s = n;

      function a(p, y) {
        for (; p < i.length && y < s.length && i.getElement(p) === s.getElement(y);) p++, y++;
        return p
      }
      let o = 0;
      const u = new Ku;
      u.set(0, a(0, 0));
      const l = new ec;
      l.set(0, u.get(0) === 0 ? null : new ea(null, 0, 0, u.get(0)));
      let h = 0;
      e: for (;;) {
        if (o++, !r.isValid()) return He.trivialTimedOut(i, s);
        const p = -Math.min(o, s.length + o % 2),
          y = Math.min(o, i.length + o % 2);
        for (h = p; h <= y; h += 2) {
          const w = h === y ? -1 : u.get(h + 1),
            N = h === p ? -1 : u.get(h - 1) + 1,
            b = Math.min(Math.max(w, N), i.length),
            _ = b - h;
          if (b > i.length || _ > s.length) continue;
          const L = a(b, _);
          u.set(h, L);
          const A = b === w ? l.get(h + 1) : l.get(h - 1);
          if (l.set(h, L !== b ? new ea(A, b, _, L - b) : A), u.get(h) === i.length && u.get(h) - h === s.length) break e
        }
      }
      let f = l.get(h);
      const m = [];
      let g = i.length,
        d = s.length;
      for (;;) {
        const p = f ? f.x + f.length : 0,
          y = f ? f.y + f.length : 0;
        if ((p !== g || y !== d) && m.push(new K(new j(p, g), new j(y, d))), !f) break;
        g = f.x, d = f.y, f = f.prev
      }
      return m.reverse(), new He(m, !1)
    }
  }
  class ea {
    constructor(e, n, r, i) {
      this.prev = e, this.x = n, this.y = r, this.length = i
    }
  }
  class Ku {
    constructor() {
      this.positiveArr = new Int32Array(10), this.negativeArr = new Int32Array(10)
    }
    get(e) {
      return e < 0 ? (e = -e - 1, this.negativeArr[e]) : this.positiveArr[e]
    }
    set(e, n) {
      if (e < 0) {
        if (e = -e - 1, e >= this.negativeArr.length) {
          const r = this.negativeArr;
          this.negativeArr = new Int32Array(r.length * 2), this.negativeArr.set(r)
        }
        this.negativeArr[e] = n
      } else {
        if (e >= this.positiveArr.length) {
          const r = this.positiveArr;
          this.positiveArr = new Int32Array(r.length * 2), this.positiveArr.set(r)
        }
        this.positiveArr[e] = n
      }
    }
  }
  class ec {
    constructor() {
      this.positiveArr = [], this.negativeArr = []
    }
    get(e) {
      return e < 0 ? (e = -e - 1, this.negativeArr[e]) : this.positiveArr[e]
    }
    set(e, n) {
      e < 0 ? (e = -e - 1, this.negativeArr[e] = n) : this.positiveArr[e] = n
    }
  }
  class Rn {
    constructor(e, n, r) {
      this.lines = e, this.range = n, this.considerWhitespaceChanges = r, this.elements = [], this.firstElementOffsetByLineIdx = [], this.lineStartOffsets = [], this.trimmedWsLengthsByLineIdx = [], this.firstElementOffsetByLineIdx.push(0);
      for (let i = this.range.startLineNumber; i <= this.range.endLineNumber; i++) {
        let s = e[i - 1],
          a = 0;
        i === this.range.startLineNumber && this.range.startColumn > 1 && (a = this.range.startColumn - 1, s = s.substring(a)), this.lineStartOffsets.push(a);
        let o = 0;
        if (!r) {
          const l = s.trimStart();
          o = s.length - l.length, s = l.trimEnd()
        }
        this.trimmedWsLengthsByLineIdx.push(o);
        const u = i === this.range.endLineNumber ? Math.min(this.range.endColumn - 1 - a - o, s.length) : s.length;
        for (let l = 0; l < u; l++) this.elements.push(s.charCodeAt(l));
        i < this.range.endLineNumber && (this.elements.push(10), this.firstElementOffsetByLineIdx.push(this.elements.length))
      }
    }
    toString() {
      return `Slice: "${this.text}"`
    }
    get text() {
      return this.getText(new j(0, this.length))
    }
    getText(e) {
      return this.elements.slice(e.start, e.endExclusive).map(n => String.fromCharCode(n)).join("")
    }
    getElement(e) {
      return this.elements[e]
    }
    get length() {
      return this.elements.length
    }
    getBoundaryScore(e) {
      const n = ra(e > 0 ? this.elements[e - 1] : -1),
        r = ra(e < this.elements.length ? this.elements[e] : -1);
      if (n === 7 && r === 8) return 0;
      if (n === 8) return 150;
      let i = 0;
      return n !== r && (i += 10, n === 0 && r === 1 && (i += 1)), i += na(n), i += na(r), i
    }
    translateOffset(e, n = "right") {
      const r = _t(this.firstElementOffsetByLineIdx, s => s <= e),
        i = e - this.firstElementOffsetByLineIdx[r];
      return new Q(this.range.startLineNumber + r, 1 + this.lineStartOffsets[r] + i + (i === 0 && n === "left" ? 0 : this.trimmedWsLengthsByLineIdx[r]))
    }
    translateRange(e) {
      const n = this.translateOffset(e.start, "right"),
        r = this.translateOffset(e.endExclusive, "left");
      return r.isBefore(n) ? U.fromPositions(r, r) : U.fromPositions(n, r)
    }
    findWordContaining(e) {
      if (e < 0 || e >= this.elements.length || !Rt(this.elements[e])) return;
      let n = e;
      for (; n > 0 && Rt(this.elements[n - 1]);) n--;
      let r = e;
      for (; r < this.elements.length && Rt(this.elements[r]);) r++;
      return new j(n, r)
    }
    findSubWordContaining(e) {
      if (e < 0 || e >= this.elements.length || !Rt(this.elements[e])) return;
      let n = e;
      for (; n > 0 && Rt(this.elements[n - 1]) && !ta(this.elements[n]);) n--;
      let r = e;
      for (; r < this.elements.length && Rt(this.elements[r]) && !ta(this.elements[r]);) r++;
      return new j(n, r)
    }
    countLinesIn(e) {
      return this.translateOffset(e.endExclusive).lineNumber - this.translateOffset(e.start).lineNumber
    }
    isStronglyEqual(e, n) {
      return this.elements[e] === this.elements[n]
    }
    extendToFullLines(e) {
      const n = Nt(this.firstElementOffsetByLineIdx, i => i <= e.start) ?? 0,
        r = Bu(this.firstElementOffsetByLineIdx, i => e.endExclusive <= i) ?? this.elements.length;
      return new j(n, r)
    }
  }

  function Rt(t) {
    return t >= 97 && t <= 122 || t >= 65 && t <= 90 || t >= 48 && t <= 57
  }

  function ta(t) {
    return t >= 65 && t <= 90
  }
  const tc = {
    0: 0,
    1: 0,
    2: 0,
    3: 10,
    4: 2,
    5: 30,
    6: 3,
    7: 10,
    8: 10
  };

  function na(t) {
    return tc[t]
  }

  function ra(t) {
    return t === 10 ? 8 : t === 13 ? 7 : Er(t) ? 6 : t >= 97 && t <= 122 ? 0 : t >= 65 && t <= 90 ? 1 : t >= 48 && t <= 57 ? 2 : t === -1 ? 3 : t === 44 || t === 59 ? 5 : 4
  }

  function nc(t, e, n, r, i, s) {
    let {
      moves: a,
      excludedChanges: o
    } = ic(t, e, n, s);
    if (!s.isValid()) return [];
    const u = t.filter(h => !o.has(h)),
      l = sc(u, r, i, e, n, s);
    return Ou(a, l), a = ac(a), a = a.filter(h => {
      const f = h.original.toOffsetRange().slice(e).map(g => g.trim());
      return f.join(`
`).length >= 15 && rc(f, g => g.length >= 2) >= 2
    }), a = oc(t, a), a
  }

  function rc(t, e) {
    let n = 0;
    for (const r of t) e(r) && n++;
    return n
  }

  function ic(t, e, n, r) {
    const i = [],
      s = t.filter(u => u.modified.isEmpty && u.original.length >= 3).map(u => new kn(u.original, e, u)),
      a = new Set(t.filter(u => u.original.isEmpty && u.modified.length >= 3).map(u => new kn(u.modified, n, u))),
      o = new Set;
    for (const u of s) {
      let l = -1,
        h;
      for (const f of a) {
        const m = u.computeSimilarity(f);
        m > l && (l = m, h = f)
      }
      if (l > .9 && h && (a.delete(h), i.push(new Le(u.range, h.range)), o.add(u.source), o.add(h.source)), !r.isValid()) return {
        moves: i,
        excludedChanges: o
      }
    }
    return {
      moves: i,
      excludedChanges: o
    }
  }

  function sc(t, e, n, r, i, s) {
    const a = [],
      o = new Lu;
    for (const m of t)
      for (let g = m.original.startLineNumber; g < m.original.endLineNumberExclusive - 2; g++) {
        const d = `${e[g-1]}:${e[g+1-1]}:${e[g+2-1]}`;
        o.add(d, {
          range: new H(g, g + 3)
        })
      }
    const u = [];
    t.sort(Jt(m => m.modified.startLineNumber, Xt));
    for (const m of t) {
      let g = [];
      for (let d = m.modified.startLineNumber; d < m.modified.endLineNumberExclusive - 2; d++) {
        const p = `${n[d-1]}:${n[d+1-1]}:${n[d+2-1]}`,
          y = new H(d, d + 3),
          w = [];
        o.forEach(p, ({
          range: N
        }) => {
          for (const _ of g)
            if (_.originalLineRange.endLineNumberExclusive + 1 === N.endLineNumberExclusive && _.modifiedLineRange.endLineNumberExclusive + 1 === y.endLineNumberExclusive) {
              _.originalLineRange = new H(_.originalLineRange.startLineNumber, N.endLineNumberExclusive), _.modifiedLineRange = new H(_.modifiedLineRange.startLineNumber, y.endLineNumberExclusive), w.push(_);
              return
            } const b = {
            modifiedLineRange: y,
            originalLineRange: N
          };
          u.push(b), w.push(b)
        }), g = w
      }
      if (!s.isValid()) return []
    }
    u.sort($u(Jt(m => m.modifiedLineRange.length, Xt)));
    const l = new Fe,
      h = new Fe;
    for (const m of u) {
      const g = m.modifiedLineRange.startLineNumber - m.originalLineRange.startLineNumber,
        d = l.subtractFrom(m.modifiedLineRange),
        p = h.subtractFrom(m.originalLineRange).getWithDelta(g),
        y = d.getIntersection(p);
      for (const w of y.ranges) {
        if (w.length < 3) continue;
        const N = w,
          b = w.delta(-g);
        a.push(new Le(b, N)), l.addRange(N), h.addRange(b)
      }
    }
    a.sort(Jt(m => m.original.startLineNumber, Xt));
    const f = new Sn(t);
    for (let m = 0; m < a.length; m++) {
      const g = a[m],
        d = f.findLastMonotonous(A => A.original.startLineNumber <= g.original.startLineNumber),
        p = Nt(t, A => A.modified.startLineNumber <= g.modified.startLineNumber),
        y = Math.max(g.original.startLineNumber - d.original.startLineNumber, g.modified.startLineNumber - p.modified.startLineNumber),
        w = f.findLastMonotonous(A => A.original.startLineNumber < g.original.endLineNumberExclusive),
        N = Nt(t, A => A.modified.startLineNumber < g.modified.endLineNumberExclusive),
        b = Math.max(w.original.endLineNumberExclusive - g.original.endLineNumberExclusive, N.modified.endLineNumberExclusive - g.modified.endLineNumberExclusive);
      let _;
      for (_ = 0; _ < y; _++) {
        const A = g.original.startLineNumber - _ - 1,
          v = g.modified.startLineNumber - _ - 1;
        if (A > r.length || v > i.length || l.contains(v) || h.contains(A) || !ia(r[A - 1], i[v - 1], s)) break
      }
      _ > 0 && (h.addRange(new H(g.original.startLineNumber - _, g.original.startLineNumber)), l.addRange(new H(g.modified.startLineNumber - _, g.modified.startLineNumber)));
      let L;
      for (L = 0; L < b; L++) {
        const A = g.original.endLineNumberExclusive + L,
          v = g.modified.endLineNumberExclusive + L;
        if (A > r.length || v > i.length || l.contains(v) || h.contains(A) || !ia(r[A - 1], i[v - 1], s)) break
      }
      L > 0 && (h.addRange(new H(g.original.endLineNumberExclusive, g.original.endLineNumberExclusive + L)), l.addRange(new H(g.modified.endLineNumberExclusive, g.modified.endLineNumberExclusive + L))), (_ > 0 || L > 0) && (a[m] = new Le(new H(g.original.startLineNumber - _, g.original.endLineNumberExclusive + L), new H(g.modified.startLineNumber - _, g.modified.endLineNumberExclusive + L)))
    }
    return a
  }

  function ia(t, e, n) {
    if (t.trim() === e.trim()) return !0;
    if (t.length > 300 && e.length > 300) return !1;
    const i = new Ks().compute(new Rn([t], new U(1, 1, 1, t.length), !1), new Rn([e], new U(1, 1, 1, e.length), !1), n);
    let s = 0;
    const a = K.invert(i.diffs, t.length);
    for (const h of a) h.seq1Range.forEach(f => {
      Er(t.charCodeAt(f)) || s++
    });

    function o(h) {
      let f = 0;
      for (let m = 0; m < t.length; m++) Er(h.charCodeAt(m)) || f++;
      return f
    }
    const u = o(t.length > e.length ? t : e);
    return s / u > .6 && u > 10
  }

  function ac(t) {
    if (t.length === 0) return t;
    t.sort(Jt(n => n.original.startLineNumber, Xt));
    const e = [t[0]];
    for (let n = 1; n < t.length; n++) {
      const r = e[e.length - 1],
        i = t[n],
        s = i.original.startLineNumber - r.original.endLineNumberExclusive,
        a = i.modified.startLineNumber - r.modified.endLineNumberExclusive;
      if (s >= 0 && a >= 0 && s + a <= 2) {
        e[e.length - 1] = r.join(i);
        continue
      }
      e.push(i)
    }
    return e
  }

  function oc(t, e) {
    const n = new Sn(t);
    return e = e.filter(r => {
      const i = n.findLastMonotonous(o => o.original.startLineNumber < r.original.endLineNumberExclusive) || new Le(new H(1, 1), new H(1, 1)),
        s = Nt(t, o => o.modified.startLineNumber < r.modified.endLineNumberExclusive);
      return i !== s
    }), e
  }

  function sa(t, e, n) {
    let r = n;
    return r = aa(t, e, r), r = aa(t, e, r), r = lc(t, e, r), r
  }

  function aa(t, e, n) {
    if (n.length === 0) return n;
    const r = [];
    r.push(n[0]);
    for (let s = 1; s < n.length; s++) {
      const a = r[r.length - 1];
      let o = n[s];
      if (o.seq1Range.isEmpty || o.seq2Range.isEmpty) {
        const u = o.seq1Range.start - a.seq1Range.endExclusive;
        let l;
        for (l = 1; l <= u && !(t.getElement(o.seq1Range.start - l) !== t.getElement(o.seq1Range.endExclusive - l) || e.getElement(o.seq2Range.start - l) !== e.getElement(o.seq2Range.endExclusive - l)); l++);
        if (l--, l === u) {
          r[r.length - 1] = new K(new j(a.seq1Range.start, o.seq1Range.endExclusive - u), new j(a.seq2Range.start, o.seq2Range.endExclusive - u));
          continue
        }
        o = o.delta(-l)
      }
      r.push(o)
    }
    const i = [];
    for (let s = 0; s < r.length - 1; s++) {
      const a = r[s + 1];
      let o = r[s];
      if (o.seq1Range.isEmpty || o.seq2Range.isEmpty) {
        const u = a.seq1Range.start - o.seq1Range.endExclusive;
        let l;
        for (l = 0; l < u && !(!t.isStronglyEqual(o.seq1Range.start + l, o.seq1Range.endExclusive + l) || !e.isStronglyEqual(o.seq2Range.start + l, o.seq2Range.endExclusive + l)); l++);
        if (l === u) {
          r[s + 1] = new K(new j(o.seq1Range.start + u, a.seq1Range.endExclusive), new j(o.seq2Range.start + u, a.seq2Range.endExclusive));
          continue
        }
        l > 0 && (o = o.delta(l))
      }
      i.push(o)
    }
    return r.length > 0 && i.push(r[r.length - 1]), i
  }

  function lc(t, e, n) {
    if (!t.getBoundaryScore || !e.getBoundaryScore) return n;
    for (let r = 0; r < n.length; r++) {
      const i = r > 0 ? n[r - 1] : void 0,
        s = n[r],
        a = r + 1 < n.length ? n[r + 1] : void 0,
        o = new j(i ? i.seq1Range.endExclusive + 1 : 0, a ? a.seq1Range.start - 1 : t.length),
        u = new j(i ? i.seq2Range.endExclusive + 1 : 0, a ? a.seq2Range.start - 1 : e.length);
      s.seq1Range.isEmpty ? n[r] = oa(s, t, e, o, u) : s.seq2Range.isEmpty && (n[r] = oa(s.swap(), e, t, u, o).swap())
    }
    return n
  }

  function oa(t, e, n, r, i) {
    let a = 1;
    for (; t.seq1Range.start - a >= r.start && t.seq2Range.start - a >= i.start && n.isStronglyEqual(t.seq2Range.start - a, t.seq2Range.endExclusive - a) && a < 100;) a++;
    a--;
    let o = 0;
    for (; t.seq1Range.start + o < r.endExclusive && t.seq2Range.endExclusive + o < i.endExclusive && n.isStronglyEqual(t.seq2Range.start + o, t.seq2Range.endExclusive + o) && o < 100;) o++;
    if (a === 0 && o === 0) return t;
    let u = 0,
      l = -1;
    for (let h = -a; h <= o; h++) {
      const f = t.seq2Range.start + h,
        m = t.seq2Range.endExclusive + h,
        g = t.seq1Range.start + h,
        d = e.getBoundaryScore(g) + n.getBoundaryScore(f) + n.getBoundaryScore(m);
      d > l && (l = d, u = h)
    }
    return t.delta(u)
  }

  function uc(t, e, n) {
    const r = [];
    for (const i of n) {
      const s = r[r.length - 1];
      if (!s) {
        r.push(i);
        continue
      }
      i.seq1Range.start - s.seq1Range.endExclusive <= 2 || i.seq2Range.start - s.seq2Range.endExclusive <= 2 ? r[r.length - 1] = new K(s.seq1Range.join(i.seq1Range), s.seq2Range.join(i.seq2Range)) : r.push(i)
    }
    return r
  }

  function la(t, e, n, r, i = !1) {
    const s = K.invert(n, t.length),
      a = [];
    let o = new ze(0, 0);

    function u(h, f) {
      if (h.offset1 < o.offset1 || h.offset2 < o.offset2) return;
      const m = r(t, h.offset1),
        g = r(e, h.offset2);
      if (!m || !g) return;
      let d = new K(m, g);
      const p = d.intersect(f);
      let y = p.seq1Range.length,
        w = p.seq2Range.length;
      for (; s.length > 0;) {
        const N = s[0];
        if (!(N.seq1Range.intersects(d.seq1Range) || N.seq2Range.intersects(d.seq2Range))) break;
        const _ = r(t, N.seq1Range.start),
          L = r(e, N.seq2Range.start),
          A = new K(_, L),
          v = A.intersect(N);
        if (y += v.seq1Range.length, w += v.seq2Range.length, d = d.join(A), d.seq1Range.endExclusive >= N.seq1Range.endExclusive) s.shift();
        else break
      }(i && y + w < d.seq1Range.length + d.seq2Range.length || y + w < (d.seq1Range.length + d.seq2Range.length) * 2 / 3) && a.push(d), o = d.getEndExclusives()
    }
    for (; s.length > 0;) {
      const h = s.shift();
      h.seq1Range.isEmpty || (u(h.getStarts(), h), u(h.getEndExclusives().delta(-1), h))
    }
    return cc(n, a)
  }

  function cc(t, e) {
    const n = [];
    for (; t.length > 0 || e.length > 0;) {
      const r = t[0],
        i = e[0];
      let s;
      r && (!i || r.seq1Range.start < i.seq1Range.start) ? s = t.shift() : s = e.shift(), n.length > 0 && n[n.length - 1].seq1Range.endExclusive >= s.seq1Range.start ? n[n.length - 1] = n[n.length - 1].join(s) : n.push(s)
    }
    return n
  }

  function fc(t, e, n) {
    let r = n;
    if (r.length === 0) return r;
    let i = 0,
      s;
    do {
      s = !1;
      const a = [r[0]];
      for (let o = 1; o < r.length; o++) {
        let h = function(m, g) {
          const d = new j(l.seq1Range.endExclusive, u.seq1Range.start);
          return t.getText(d).replace(/\s/g, "").length <= 4 && (m.seq1Range.length + m.seq2Range.length > 5 || g.seq1Range.length + g.seq2Range.length > 5)
        };
        const u = r[o],
          l = a[a.length - 1];
        h(l, u) ? (s = !0, a[a.length - 1] = a[a.length - 1].join(u)) : a.push(u)
      }
      r = a
    } while (i++ < 10 && s);
    return r
  }

  function hc(t, e, n) {
    let r = n;
    if (r.length === 0) return r;
    let i = 0,
      s;
    do {
      s = !1;
      const o = [r[0]];
      for (let u = 1; u < r.length; u++) {
        let f = function(g, d) {
          const p = new j(h.seq1Range.endExclusive, l.seq1Range.start);
          if (t.countLinesIn(p) > 5 || p.length > 500) return !1;
          const w = t.getText(p).trim();
          if (w.length > 20 || w.split(/\r\n|\r|\n/).length > 1) return !1;
          const N = t.countLinesIn(g.seq1Range),
            b = g.seq1Range.length,
            _ = e.countLinesIn(g.seq2Range),
            L = g.seq2Range.length,
            A = t.countLinesIn(d.seq1Range),
            v = d.seq1Range.length,
            k = e.countLinesIn(d.seq2Range),
            M = d.seq2Range.length,
            V = 130;

          function T(x) {
            return Math.min(x, V)
          }
          return Math.pow(Math.pow(T(N * 40 + b), 1.5) + Math.pow(T(_ * 40 + L), 1.5), 1.5) + Math.pow(Math.pow(T(A * 40 + v), 1.5) + Math.pow(T(k * 40 + M), 1.5), 1.5) > (V ** 1.5) ** 1.5 * 1.3
        };
        const l = r[u],
          h = o[o.length - 1];
        f(h, l) ? (s = !0, o[o.length - 1] = o[o.length - 1].join(l)) : o.push(l)
      }
      r = o
    } while (i++ < 10 && s);
    const a = [];
    return Du(r, (o, u, l) => {
      let h = u;

      function f(w) {
        return w.length > 0 && w.trim().length <= 3 && u.seq1Range.length + u.seq2Range.length > 100
      }
      const m = t.extendToFullLines(u.seq1Range),
        g = t.getText(new j(m.start, u.seq1Range.start));
      f(g) && (h = h.deltaStart(-g.length));
      const d = t.getText(new j(u.seq1Range.endExclusive, m.endExclusive));
      f(d) && (h = h.deltaEnd(d.length));
      const p = K.fromOffsetPairs(o ? o.getEndExclusives() : ze.zero, l ? l.getStarts() : ze.max),
        y = h.intersect(p);
      a.length > 0 && y.getStarts().equals(a[a.length - 1].getEndExclusives()) ? a[a.length - 1] = a[a.length - 1].join(y) : a.push(y)
    }), a
  }
  class ua {
    constructor(e, n) {
      this.trimmedHash = e, this.lines = n
    }
    getElement(e) {
      return this.trimmedHash[e]
    }
    get length() {
      return this.trimmedHash.length
    }
    getBoundaryScore(e) {
      const n = e === 0 ? 0 : ca(this.lines[e - 1]),
        r = e === this.lines.length ? 0 : ca(this.lines[e]);
      return 1e3 - (n + r)
    }
    getText(e) {
      return this.lines.slice(e.start, e.endExclusive).join(`
`)
    }
    isStronglyEqual(e, n) {
      return this.lines[e] === this.lines[n]
    }
  }

  function ca(t) {
    let e = 0;
    for (; e < t.length && (t.charCodeAt(e) === 32 || t.charCodeAt(e) === 9);) e++;
    return e
  }
  class mc {
    constructor() {
      this.dynamicProgrammingDiffing = new Yu, this.myersDiffingAlgorithm = new Ks
    }
    computeDiff(e, n, r) {
      if (e.length <= 1 && Iu(e, n, (v, k) => v === k)) return new _n([], [], !1);
      if (e.length === 1 && e[0].length === 0 || n.length === 1 && n[0].length === 0) return new _n([new We(new H(1, e.length + 1), new H(1, n.length + 1), [new Ne(new U(1, 1, e.length, e[e.length - 1].length + 1), new U(1, 1, n.length, n[n.length - 1].length + 1))])], [], !1);
      const i = r.maxComputationTimeMs === 0 ? Yt.instance : new Zu(r.maxComputationTimeMs),
        s = !r.ignoreTrimWhitespace,
        a = new Map;

      function o(v) {
        let k = a.get(v);
        return k === void 0 && (k = a.size, a.set(v, k)), k
      }
      const u = e.map(v => o(v.trim())),
        l = n.map(v => o(v.trim())),
        h = new ua(u, e),
        f = new ua(l, n),
        m = h.length + f.length < 1700 ? this.dynamicProgrammingDiffing.compute(h, f, i, (v, k) => e[v] === n[k] ? n[k].length === 0 ? .1 : 1 + Math.log(1 + n[k].length) : .99) : this.myersDiffingAlgorithm.compute(h, f, i);
      let g = m.diffs,
        d = m.hitTimeout;
      g = sa(h, f, g), g = fc(h, f, g);
      const p = [],
        y = v => {
          if (s)
            for (let k = 0; k < v; k++) {
              const M = w + k,
                V = N + k;
              if (e[M] !== n[V]) {
                const T = this.refineDiff(e, n, new K(new j(M, M + 1), new j(V, V + 1)), i, s, r);
                for (const x of T.mappings) p.push(x);
                T.hitTimeout && (d = !0)
              }
            }
        };
      let w = 0,
        N = 0;
      for (const v of g) {
        hn(() => v.seq1Range.start - w === v.seq2Range.start - N);
        const k = v.seq1Range.start - w;
        y(k), w = v.seq1Range.endExclusive, N = v.seq2Range.endExclusive;
        const M = this.refineDiff(e, n, v, i, s, r);
        M.hitTimeout && (d = !0);
        for (const V of M.mappings) p.push(V)
      }
      y(e.length - w);
      const b = new An(e),
        _ = new An(n),
        L = Xs(p, b, _);
      let A = [];
      return r.computeMoves && (A = this.computeMoves(L, e, n, u, l, i, s, r)), hn(() => {
        function v(M, V) {
          if (M.lineNumber < 1 || M.lineNumber > V.length) return !1;
          const T = V[M.lineNumber - 1];
          return !(M.column < 1 || M.column > T.length + 1)
        }

        function k(M, V) {
          return !(M.startLineNumber < 1 || M.startLineNumber > V.length + 1 || M.endLineNumberExclusive < 1 || M.endLineNumberExclusive > V.length + 1)
        }
        for (const M of L) {
          if (!M.innerChanges) return !1;
          for (const V of M.innerChanges)
            if (!(v(V.modifiedRange.getStartPosition(), n) && v(V.modifiedRange.getEndPosition(), n) && v(V.originalRange.getStartPosition(), e) && v(V.originalRange.getEndPosition(), e))) return !1;
          if (!k(M.modified, n) || !k(M.original, e)) return !1
        }
        return !0
      }), new _n(L, A, d)
    }
    computeMoves(e, n, r, i, s, a, o, u) {
      return nc(e, n, r, i, s, a).map(f => {
        const m = this.refineDiff(n, r, new K(f.original.toOffsetRange(), f.modified.toOffsetRange()), a, o, u),
          g = Xs(m.mappings, new An(n), new An(r), !0);
        return new Cu(f, g)
      })
    }
    refineDiff(e, n, r, i, s, a) {
      const u = dc(r).toRangeMapping2(e, n),
        l = new Rn(e, u.originalRange, s),
        h = new Rn(n, u.modifiedRange, s),
        f = l.length + h.length < 500 ? this.dynamicProgrammingDiffing.compute(l, h, i) : this.myersDiffingAlgorithm.compute(l, h, i);
      let m = f.diffs;
      return m = sa(l, h, m), m = la(l, h, m, (d, p) => d.findWordContaining(p)), a.extendToSubwords && (m = la(l, h, m, (d, p) => d.findSubWordContaining(p), !0)), m = uc(l, h, m), m = hc(l, h, m), {
        mappings: m.map(d => new Ne(l.translateRange(d.seq1Range), h.translateRange(d.seq2Range))),
        hitTimeout: f.hitTimeout
      }
    }
  }

  function dc(t) {
    return new Le(new H(t.seq1Range.start + 1, t.seq1Range.endExclusive + 1), new H(t.seq2Range.start + 1, t.seq2Range.endExclusive + 1))
  }
  const fa = {
    getLegacy: () => new Gu,
    getDefault: () => new mc
  };

  function Ye(t, e) {
    const n = Math.pow(10, e);
    return Math.round(t * n) / n
  }
  class R {
    constructor(e, n, r, i = 1) {
      this._rgbaBrand = void 0, this.r = Math.min(255, Math.max(0, e)) | 0, this.g = Math.min(255, Math.max(0, n)) | 0, this.b = Math.min(255, Math.max(0, r)) | 0, this.a = Ye(Math.max(Math.min(1, i), 0), 3)
    }
    static equals(e, n) {
      return e.r === n.r && e.g === n.g && e.b === n.b && e.a === n.a
    }
  }
  class _e {
    constructor(e, n, r, i) {
      this._hslaBrand = void 0, this.h = Math.max(Math.min(360, e), 0) | 0, this.s = Ye(Math.max(Math.min(1, n), 0), 3), this.l = Ye(Math.max(Math.min(1, r), 0), 3), this.a = Ye(Math.max(Math.min(1, i), 0), 3)
    }
    static equals(e, n) {
      return e.h === n.h && e.s === n.s && e.l === n.l && e.a === n.a
    }
    static fromRGBA(e) {
      const n = e.r / 255,
        r = e.g / 255,
        i = e.b / 255,
        s = e.a,
        a = Math.max(n, r, i),
        o = Math.min(n, r, i);
      let u = 0,
        l = 0;
      const h = (o + a) / 2,
        f = a - o;
      if (f > 0) {
        switch (l = Math.min(h <= .5 ? f / (2 * h) : f / (2 - 2 * h), 1), a) {
          case n:
            u = (r - i) / f + (r < i ? 6 : 0);
            break;
          case r:
            u = (i - n) / f + 2;
            break;
          case i:
            u = (n - r) / f + 4;
            break
        }
        u *= 60, u = Math.round(u)
      }
      return new _e(u, l, h, s)
    }
    static _hue2rgb(e, n, r) {
      return r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + (n - e) * 6 * r : r < 1 / 2 ? n : r < 2 / 3 ? e + (n - e) * (2 / 3 - r) * 6 : e
    }
    static toRGBA(e) {
      const n = e.h / 360,
        {
          s: r,
          l: i,
          a: s
        } = e;
      let a, o, u;
      if (r === 0) a = o = u = i;
      else {
        const l = i < .5 ? i * (1 + r) : i + r - i * r,
          h = 2 * i - l;
        a = _e._hue2rgb(h, l, n + 1 / 3), o = _e._hue2rgb(h, l, n), u = _e._hue2rgb(h, l, n - 1 / 3)
      }
      return new R(Math.round(a * 255), Math.round(o * 255), Math.round(u * 255), s)
    }
  }
  class Et {
    constructor(e, n, r, i) {
      this._hsvaBrand = void 0, this.h = Math.max(Math.min(360, e), 0) | 0, this.s = Ye(Math.max(Math.min(1, n), 0), 3), this.v = Ye(Math.max(Math.min(1, r), 0), 3), this.a = Ye(Math.max(Math.min(1, i), 0), 3)
    }
    static equals(e, n) {
      return e.h === n.h && e.s === n.s && e.v === n.v && e.a === n.a
    }
    static fromRGBA(e) {
      const n = e.r / 255,
        r = e.g / 255,
        i = e.b / 255,
        s = Math.max(n, r, i),
        a = Math.min(n, r, i),
        o = s - a,
        u = s === 0 ? 0 : o / s;
      let l;
      return o === 0 ? l = 0 : s === n ? l = ((r - i) / o % 6 + 6) % 6 : s === r ? l = (i - n) / o + 2 : l = (n - r) / o + 4, new Et(Math.round(l * 60), u, s, e.a)
    }
    static toRGBA(e) {
      const {
        h: n,
        s: r,
        v: i,
        a: s
      } = e, a = i * r, o = a * (1 - Math.abs(n / 60 % 2 - 1)), u = i - a;
      let [l, h, f] = [0, 0, 0];
      return n < 60 ? (l = a, h = o) : n < 120 ? (l = o, h = a) : n < 180 ? (h = a, f = o) : n < 240 ? (h = o, f = a) : n < 300 ? (l = o, f = a) : n <= 360 && (l = a, f = o), l = Math.round((l + u) * 255), h = Math.round((h + u) * 255), f = Math.round((f + u) * 255), new R(l, h, f, s)
    }
  }
  let En = (J = class {
    static fromHex(e) {
      return J.Format.CSS.parseHex(e) || J.red
    }
    static equals(e, n) {
      return !e && !n ? !0 : !e || !n ? !1 : e.equals(n)
    }
    get hsla() {
      return this._hsla ? this._hsla : _e.fromRGBA(this.rgba)
    }
    get hsva() {
      return this._hsva ? this._hsva : Et.fromRGBA(this.rgba)
    }
    constructor(e) {
      if (e)
        if (e instanceof R) this.rgba = e;
        else if (e instanceof _e) this._hsla = e, this.rgba = _e.toRGBA(e);
      else if (e instanceof Et) this._hsva = e, this.rgba = Et.toRGBA(e);
      else throw new Error("Invalid color ctor argument");
      else throw new Error("Color needs a value")
    }
    equals(e) {
      return !!e && R.equals(this.rgba, e.rgba) && _e.equals(this.hsla, e.hsla) && Et.equals(this.hsva, e.hsva)
    }
    getRelativeLuminance() {
      const e = J._relativeLuminanceForComponent(this.rgba.r),
        n = J._relativeLuminanceForComponent(this.rgba.g),
        r = J._relativeLuminanceForComponent(this.rgba.b),
        i = .2126 * e + .7152 * n + .0722 * r;
      return Ye(i, 4)
    }
    static _relativeLuminanceForComponent(e) {
      const n = e / 255;
      return n <= .03928 ? n / 12.92 : Math.pow((n + .055) / 1.055, 2.4)
    }
    isLighter() {
      return (this.rgba.r * 299 + this.rgba.g * 587 + this.rgba.b * 114) / 1e3 >= 128
    }
    isLighterThan(e) {
      const n = this.getRelativeLuminance(),
        r = e.getRelativeLuminance();
      return n > r
    }
    isDarkerThan(e) {
      const n = this.getRelativeLuminance(),
        r = e.getRelativeLuminance();
      return n < r
    }
    lighten(e) {
      return new J(new _e(this.hsla.h, this.hsla.s, this.hsla.l + this.hsla.l * e, this.hsla.a))
    }
    darken(e) {
      return new J(new _e(this.hsla.h, this.hsla.s, this.hsla.l - this.hsla.l * e, this.hsla.a))
    }
    transparent(e) {
      const {
        r: n,
        g: r,
        b: i,
        a: s
      } = this.rgba;
      return new J(new R(n, r, i, s * e))
    }
    isTransparent() {
      return this.rgba.a === 0
    }
    isOpaque() {
      return this.rgba.a === 1
    }
    opposite() {
      return new J(new R(255 - this.rgba.r, 255 - this.rgba.g, 255 - this.rgba.b, this.rgba.a))
    }
    mix(e, n = .5) {
      const r = Math.min(Math.max(n, 0), 1),
        i = this.rgba,
        s = e.rgba,
        a = i.r + (s.r - i.r) * r,
        o = i.g + (s.g - i.g) * r,
        u = i.b + (s.b - i.b) * r,
        l = i.a + (s.a - i.a) * r;
      return new J(new R(a, o, u, l))
    }
    makeOpaque(e) {
      if (this.isOpaque() || e.rgba.a !== 1) return this;
      const {
        r: n,
        g: r,
        b: i,
        a: s
      } = this.rgba;
      return new J(new R(e.rgba.r - s * (e.rgba.r - n), e.rgba.g - s * (e.rgba.g - r), e.rgba.b - s * (e.rgba.b - i), 1))
    }
    toString() {
      return this._toString || (this._toString = J.Format.CSS.format(this)), this._toString
    }
    toNumber32Bit() {
      return this._toNumber32Bit || (this._toNumber32Bit = (this.rgba.r << 24 | this.rgba.g << 16 | this.rgba.b << 8 | this.rgba.a * 255 << 0) >>> 0), this._toNumber32Bit
    }
    static getLighterColor(e, n, r) {
      if (e.isLighterThan(n)) return e;
      r = r || .5;
      const i = e.getRelativeLuminance(),
        s = n.getRelativeLuminance();
      return r = r * (s - i) / s, e.lighten(r)
    }
    static getDarkerColor(e, n, r) {
      if (e.isDarkerThan(n)) return e;
      r = r || .5;
      const i = e.getRelativeLuminance(),
        s = n.getRelativeLuminance();
      return r = r * (i - s) / i, e.darken(r)
    }
  }, J.white = new J(new R(255, 255, 255, 1)), J.black = new J(new R(0, 0, 0, 1)), J.red = new J(new R(255, 0, 0, 1)), J.blue = new J(new R(0, 0, 255, 1)), J.green = new J(new R(0, 255, 0, 1)), J.cyan = new J(new R(0, 255, 255, 1)), J.lightgrey = new J(new R(211, 211, 211, 1)), J.transparent = new J(new R(0, 0, 0, 0)), J);
  (function(t) {
    (function(e) {
      (function(n) {
        function r(p) {
          return p.rgba.a === 1 ? `rgb(${p.rgba.r}, ${p.rgba.g}, ${p.rgba.b})` : t.Format.CSS.formatRGBA(p)
        }
        n.formatRGB = r;

        function i(p) {
          return `rgba(${p.rgba.r}, ${p.rgba.g}, ${p.rgba.b}, ${+p.rgba.a.toFixed(2)})`
        }
        n.formatRGBA = i;

        function s(p) {
          return p.hsla.a === 1 ? `hsl(${p.hsla.h}, ${Math.round(p.hsla.s*100)}%, ${Math.round(p.hsla.l*100)}%)` : t.Format.CSS.formatHSLA(p)
        }
        n.formatHSL = s;

        function a(p) {
          return `hsla(${p.hsla.h}, ${Math.round(p.hsla.s*100)}%, ${Math.round(p.hsla.l*100)}%, ${p.hsla.a.toFixed(2)})`
        }
        n.formatHSLA = a;

        function o(p) {
          const y = p.toString(16);
          return y.length !== 2 ? "0" + y : y
        }

        function u(p) {
          return `#${o(p.rgba.r)}${o(p.rgba.g)}${o(p.rgba.b)}`
        }
        n.formatHex = u;

        function l(p, y = !1) {
          return y && p.rgba.a === 1 ? t.Format.CSS.formatHex(p) : `#${o(p.rgba.r)}${o(p.rgba.g)}${o(p.rgba.b)}${o(Math.round(p.rgba.a*255))}`
        }
        n.formatHexA = l;

        function h(p) {
          return p.isOpaque() ? t.Format.CSS.formatHex(p) : t.Format.CSS.formatRGBA(p)
        }
        n.format = h;

        function f(p) {
          var y, w, N, b, _, L, A;
          if (p === "transparent") return t.transparent;
          if (p.startsWith("#")) return g(p);
          if (p.startsWith("rgba(")) {
            const v = p.match(/rgba\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+), *(?<a>(?:\+|-)?\d+(\.\d+)?)\)/);
            if (!v) throw new Error("Invalid color format " + p);
            const k = parseInt(((y = v.groups) == null ? void 0 : y.r) ?? "0"),
              M = parseInt(((w = v.groups) == null ? void 0 : w.g) ?? "0"),
              V = parseInt(((N = v.groups) == null ? void 0 : N.b) ?? "0"),
              T = parseFloat(((b = v.groups) == null ? void 0 : b.a) ?? "0");
            return new t(new R(k, M, V, T))
          }
          if (p.startsWith("rgb(")) {
            const v = p.match(/rgb\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+)\)/);
            if (!v) throw new Error("Invalid color format " + p);
            const k = parseInt(((_ = v.groups) == null ? void 0 : _.r) ?? "0"),
              M = parseInt(((L = v.groups) == null ? void 0 : L.g) ?? "0"),
              V = parseInt(((A = v.groups) == null ? void 0 : A.b) ?? "0");
            return new t(new R(k, M, V))
          }
          return m(p)
        }
        n.parse = f;

        function m(p) {
          switch (p) {
            case "aliceblue":
              return new t(new R(240, 248, 255, 1));
            case "antiquewhite":
              return new t(new R(250, 235, 215, 1));
            case "aqua":
              return new t(new R(0, 255, 255, 1));
            case "aquamarine":
              return new t(new R(127, 255, 212, 1));
            case "azure":
              return new t(new R(240, 255, 255, 1));
            case "beige":
              return new t(new R(245, 245, 220, 1));
            case "bisque":
              return new t(new R(255, 228, 196, 1));
            case "black":
              return new t(new R(0, 0, 0, 1));
            case "blanchedalmond":
              return new t(new R(255, 235, 205, 1));
            case "blue":
              return new t(new R(0, 0, 255, 1));
            case "blueviolet":
              return new t(new R(138, 43, 226, 1));
            case "brown":
              return new t(new R(165, 42, 42, 1));
            case "burlywood":
              return new t(new R(222, 184, 135, 1));
            case "cadetblue":
              return new t(new R(95, 158, 160, 1));
            case "chartreuse":
              return new t(new R(127, 255, 0, 1));
            case "chocolate":
              return new t(new R(210, 105, 30, 1));
            case "coral":
              return new t(new R(255, 127, 80, 1));
            case "cornflowerblue":
              return new t(new R(100, 149, 237, 1));
            case "cornsilk":
              return new t(new R(255, 248, 220, 1));
            case "crimson":
              return new t(new R(220, 20, 60, 1));
            case "cyan":
              return new t(new R(0, 255, 255, 1));
            case "darkblue":
              return new t(new R(0, 0, 139, 1));
            case "darkcyan":
              return new t(new R(0, 139, 139, 1));
            case "darkgoldenrod":
              return new t(new R(184, 134, 11, 1));
            case "darkgray":
              return new t(new R(169, 169, 169, 1));
            case "darkgreen":
              return new t(new R(0, 100, 0, 1));
            case "darkgrey":
              return new t(new R(169, 169, 169, 1));
            case "darkkhaki":
              return new t(new R(189, 183, 107, 1));
            case "darkmagenta":
              return new t(new R(139, 0, 139, 1));
            case "darkolivegreen":
              return new t(new R(85, 107, 47, 1));
            case "darkorange":
              return new t(new R(255, 140, 0, 1));
            case "darkorchid":
              return new t(new R(153, 50, 204, 1));
            case "darkred":
              return new t(new R(139, 0, 0, 1));
            case "darksalmon":
              return new t(new R(233, 150, 122, 1));
            case "darkseagreen":
              return new t(new R(143, 188, 143, 1));
            case "darkslateblue":
              return new t(new R(72, 61, 139, 1));
            case "darkslategray":
              return new t(new R(47, 79, 79, 1));
            case "darkslategrey":
              return new t(new R(47, 79, 79, 1));
            case "darkturquoise":
              return new t(new R(0, 206, 209, 1));
            case "darkviolet":
              return new t(new R(148, 0, 211, 1));
            case "deeppink":
              return new t(new R(255, 20, 147, 1));
            case "deepskyblue":
              return new t(new R(0, 191, 255, 1));
            case "dimgray":
              return new t(new R(105, 105, 105, 1));
            case "dimgrey":
              return new t(new R(105, 105, 105, 1));
            case "dodgerblue":
              return new t(new R(30, 144, 255, 1));
            case "firebrick":
              return new t(new R(178, 34, 34, 1));
            case "floralwhite":
              return new t(new R(255, 250, 240, 1));
            case "forestgreen":
              return new t(new R(34, 139, 34, 1));
            case "fuchsia":
              return new t(new R(255, 0, 255, 1));
            case "gainsboro":
              return new t(new R(220, 220, 220, 1));
            case "ghostwhite":
              return new t(new R(248, 248, 255, 1));
            case "gold":
              return new t(new R(255, 215, 0, 1));
            case "goldenrod":
              return new t(new R(218, 165, 32, 1));
            case "gray":
              return new t(new R(128, 128, 128, 1));
            case "green":
              return new t(new R(0, 128, 0, 1));
            case "greenyellow":
              return new t(new R(173, 255, 47, 1));
            case "grey":
              return new t(new R(128, 128, 128, 1));
            case "honeydew":
              return new t(new R(240, 255, 240, 1));
            case "hotpink":
              return new t(new R(255, 105, 180, 1));
            case "indianred":
              return new t(new R(205, 92, 92, 1));
            case "indigo":
              return new t(new R(75, 0, 130, 1));
            case "ivory":
              return new t(new R(255, 255, 240, 1));
            case "khaki":
              return new t(new R(240, 230, 140, 1));
            case "lavender":
              return new t(new R(230, 230, 250, 1));
            case "lavenderblush":
              return new t(new R(255, 240, 245, 1));
            case "lawngreen":
              return new t(new R(124, 252, 0, 1));
            case "lemonchiffon":
              return new t(new R(255, 250, 205, 1));
            case "lightblue":
              return new t(new R(173, 216, 230, 1));
            case "lightcoral":
              return new t(new R(240, 128, 128, 1));
            case "lightcyan":
              return new t(new R(224, 255, 255, 1));
            case "lightgoldenrodyellow":
              return new t(new R(250, 250, 210, 1));
            case "lightgray":
              return new t(new R(211, 211, 211, 1));
            case "lightgreen":
              return new t(new R(144, 238, 144, 1));
            case "lightgrey":
              return new t(new R(211, 211, 211, 1));
            case "lightpink":
              return new t(new R(255, 182, 193, 1));
            case "lightsalmon":
              return new t(new R(255, 160, 122, 1));
            case "lightseagreen":
              return new t(new R(32, 178, 170, 1));
            case "lightskyblue":
              return new t(new R(135, 206, 250, 1));
            case "lightslategray":
              return new t(new R(119, 136, 153, 1));
            case "lightslategrey":
              return new t(new R(119, 136, 153, 1));
            case "lightsteelblue":
              return new t(new R(176, 196, 222, 1));
            case "lightyellow":
              return new t(new R(255, 255, 224, 1));
            case "lime":
              return new t(new R(0, 255, 0, 1));
            case "limegreen":
              return new t(new R(50, 205, 50, 1));
            case "linen":
              return new t(new R(250, 240, 230, 1));
            case "magenta":
              return new t(new R(255, 0, 255, 1));
            case "maroon":
              return new t(new R(128, 0, 0, 1));
            case "mediumaquamarine":
              return new t(new R(102, 205, 170, 1));
            case "mediumblue":
              return new t(new R(0, 0, 205, 1));
            case "mediumorchid":
              return new t(new R(186, 85, 211, 1));
            case "mediumpurple":
              return new t(new R(147, 112, 219, 1));
            case "mediumseagreen":
              return new t(new R(60, 179, 113, 1));
            case "mediumslateblue":
              return new t(new R(123, 104, 238, 1));
            case "mediumspringgreen":
              return new t(new R(0, 250, 154, 1));
            case "mediumturquoise":
              return new t(new R(72, 209, 204, 1));
            case "mediumvioletred":
              return new t(new R(199, 21, 133, 1));
            case "midnightblue":
              return new t(new R(25, 25, 112, 1));
            case "mintcream":
              return new t(new R(245, 255, 250, 1));
            case "mistyrose":
              return new t(new R(255, 228, 225, 1));
            case "moccasin":
              return new t(new R(255, 228, 181, 1));
            case "navajowhite":
              return new t(new R(255, 222, 173, 1));
            case "navy":
              return new t(new R(0, 0, 128, 1));
            case "oldlace":
              return new t(new R(253, 245, 230, 1));
            case "olive":
              return new t(new R(128, 128, 0, 1));
            case "olivedrab":
              return new t(new R(107, 142, 35, 1));
            case "orange":
              return new t(new R(255, 165, 0, 1));
            case "orangered":
              return new t(new R(255, 69, 0, 1));
            case "orchid":
              return new t(new R(218, 112, 214, 1));
            case "palegoldenrod":
              return new t(new R(238, 232, 170, 1));
            case "palegreen":
              return new t(new R(152, 251, 152, 1));
            case "paleturquoise":
              return new t(new R(175, 238, 238, 1));
            case "palevioletred":
              return new t(new R(219, 112, 147, 1));
            case "papayawhip":
              return new t(new R(255, 239, 213, 1));
            case "peachpuff":
              return new t(new R(255, 218, 185, 1));
            case "peru":
              return new t(new R(205, 133, 63, 1));
            case "pink":
              return new t(new R(255, 192, 203, 1));
            case "plum":
              return new t(new R(221, 160, 221, 1));
            case "powderblue":
              return new t(new R(176, 224, 230, 1));
            case "purple":
              return new t(new R(128, 0, 128, 1));
            case "rebeccapurple":
              return new t(new R(102, 51, 153, 1));
            case "red":
              return new t(new R(255, 0, 0, 1));
            case "rosybrown":
              return new t(new R(188, 143, 143, 1));
            case "royalblue":
              return new t(new R(65, 105, 225, 1));
            case "saddlebrown":
              return new t(new R(139, 69, 19, 1));
            case "salmon":
              return new t(new R(250, 128, 114, 1));
            case "sandybrown":
              return new t(new R(244, 164, 96, 1));
            case "seagreen":
              return new t(new R(46, 139, 87, 1));
            case "seashell":
              return new t(new R(255, 245, 238, 1));
            case "sienna":
              return new t(new R(160, 82, 45, 1));
            case "silver":
              return new t(new R(192, 192, 192, 1));
            case "skyblue":
              return new t(new R(135, 206, 235, 1));
            case "slateblue":
              return new t(new R(106, 90, 205, 1));
            case "slategray":
              return new t(new R(112, 128, 144, 1));
            case "slategrey":
              return new t(new R(112, 128, 144, 1));
            case "snow":
              return new t(new R(255, 250, 250, 1));
            case "springgreen":
              return new t(new R(0, 255, 127, 1));
            case "steelblue":
              return new t(new R(70, 130, 180, 1));
            case "tan":
              return new t(new R(210, 180, 140, 1));
            case "teal":
              return new t(new R(0, 128, 128, 1));
            case "thistle":
              return new t(new R(216, 191, 216, 1));
            case "tomato":
              return new t(new R(255, 99, 71, 1));
            case "turquoise":
              return new t(new R(64, 224, 208, 1));
            case "violet":
              return new t(new R(238, 130, 238, 1));
            case "wheat":
              return new t(new R(245, 222, 179, 1));
            case "white":
              return new t(new R(255, 255, 255, 1));
            case "whitesmoke":
              return new t(new R(245, 245, 245, 1));
            case "yellow":
              return new t(new R(255, 255, 0, 1));
            case "yellowgreen":
              return new t(new R(154, 205, 50, 1));
            default:
              return null
          }
        }

        function g(p) {
          const y = p.length;
          if (y === 0 || p.charCodeAt(0) !== 35) return null;
          if (y === 7) {
            const w = 16 * d(p.charCodeAt(1)) + d(p.charCodeAt(2)),
              N = 16 * d(p.charCodeAt(3)) + d(p.charCodeAt(4)),
              b = 16 * d(p.charCodeAt(5)) + d(p.charCodeAt(6));
            return new t(new R(w, N, b, 1))
          }
          if (y === 9) {
            const w = 16 * d(p.charCodeAt(1)) + d(p.charCodeAt(2)),
              N = 16 * d(p.charCodeAt(3)) + d(p.charCodeAt(4)),
              b = 16 * d(p.charCodeAt(5)) + d(p.charCodeAt(6)),
              _ = 16 * d(p.charCodeAt(7)) + d(p.charCodeAt(8));
            return new t(new R(w, N, b, _ / 255))
          }
          if (y === 4) {
            const w = d(p.charCodeAt(1)),
              N = d(p.charCodeAt(2)),
              b = d(p.charCodeAt(3));
            return new t(new R(16 * w + w, 16 * N + N, 16 * b + b))
          }
          if (y === 5) {
            const w = d(p.charCodeAt(1)),
              N = d(p.charCodeAt(2)),
              b = d(p.charCodeAt(3)),
              _ = d(p.charCodeAt(4));
            return new t(new R(16 * w + w, 16 * N + N, 16 * b + b, (16 * _ + _) / 255))
          }
          return null
        }
        n.parseHex = g;

        function d(p) {
          switch (p) {
            case 48:
              return 0;
            case 49:
              return 1;
            case 50:
              return 2;
            case 51:
              return 3;
            case 52:
              return 4;
            case 53:
              return 5;
            case 54:
              return 6;
            case 55:
              return 7;
            case 56:
              return 8;
            case 57:
              return 9;
            case 97:
              return 10;
            case 65:
              return 10;
            case 98:
              return 11;
            case 66:
              return 11;
            case 99:
              return 12;
            case 67:
              return 12;
            case 100:
              return 13;
            case 68:
              return 13;
            case 101:
              return 14;
            case 69:
              return 14;
            case 102:
              return 15;
            case 70:
              return 15
          }
          return 0
        }
      })(e.CSS || (e.CSS = {}))
    })(t.Format || (t.Format = {}))
  })(En || (En = {}));

  function ha(t) {
    const e = [];
    for (const n of t) {
      const r = Number(n);
      (r || r === 0 && n.replace(/\s/g, "") !== "") && e.push(r)
    }
    return e
  }

  function Mr(t, e, n, r) {
    return {
      red: t / 255,
      blue: n / 255,
      green: e / 255,
      alpha: r
    }
  }

  function Kt(t, e) {
    const n = e.index,
      r = e[0].length;
    if (n === void 0) return;
    const i = t.positionAt(n);
    return {
      startLineNumber: i.lineNumber,
      startColumn: i.column,
      endLineNumber: i.lineNumber,
      endColumn: i.column + r
    }
  }

  function gc(t, e) {
    if (!t) return;
    const n = En.Format.CSS.parseHex(e);
    if (n) return {
      range: t,
      color: Mr(n.rgba.r, n.rgba.g, n.rgba.b, n.rgba.a)
    }
  }

  function ma(t, e, n) {
    if (!t || e.length !== 1) return;
    const i = e[0].values(),
      s = ha(i);
    return {
      range: t,
      color: Mr(s[0], s[1], s[2], n ? s[3] : 1)
    }
  }

  function da(t, e, n) {
    if (!t || e.length !== 1) return;
    const i = e[0].values(),
      s = ha(i),
      a = new En(new _e(s[0], s[1] / 100, s[2] / 100, n ? s[3] : 1));
    return {
      range: t,
      color: Mr(a.rgba.r, a.rgba.g, a.rgba.b, a.rgba.a)
    }
  }

  function en(t, e) {
    return typeof t == "string" ? [...t.matchAll(e)] : t.findMatches(e)
  }

  function pc(t) {
    const e = [],
      n = new RegExp(`\\b(rgb|rgba|hsl|hsla)(\\([0-9\\s,.\\%]*\\))|^(#)([A-Fa-f0-9]{3})\\b|^(#)([A-Fa-f0-9]{4})\\b|^(#)([A-Fa-f0-9]{6})\\b|^(#)([A-Fa-f0-9]{8})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{3})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{4})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{6})\\b|(?<=['"\\s])(#)([A-Fa-f0-9]{8})\\b`, "gm"),
      r = en(t, n);
    if (r.length > 0)
      for (const i of r) {
        const s = i.filter(l => l !== void 0),
          a = s[1],
          o = s[2];
        if (!o) continue;
        let u;
        if (a === "rgb") {
          const l = /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*\)$/gm;
          u = ma(Kt(t, i), en(o, l), !1)
        } else if (a === "rgba") {
          const l = /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(0[.][0-9]+|[.][0-9]+|[01][.]|[01])\s*\)$/gm;
          u = ma(Kt(t, i), en(o, l), !0)
        } else if (a === "hsl") {
          const l = /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*\)$/gm;
          u = da(Kt(t, i), en(o, l), !1)
        } else if (a === "hsla") {
          const l = /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(0[.][0-9]+|[.][0-9]+|[01][.]0*|[01])\s*\)$/gm;
          u = da(Kt(t, i), en(o, l), !0)
        } else a === "#" && (u = gc(Kt(t, i), a + o));
        u && e.push(u)
      }
    return e
  }

  function bc(t) {
    return !t || typeof t.getValue != "function" || typeof t.positionAt != "function" ? [] : pc(t)
  }
  const yc = /^-+|-+$/g,
    ga = 100,
    wc = 5;

  function xc(t, e) {
    var r;
    let n = [];
    if (e.findRegionSectionHeaders && ((r = e.foldingRules) != null && r.markers)) {
      const i = vc(t, e);
      n = n.concat(i)
    }
    if (e.findMarkSectionHeaders) {
      const i = Lc(t, e);
      n = n.concat(i)
    }
    return n
  }

  function vc(t, e) {
    const n = [],
      r = t.getLineCount();
    for (let i = 1; i <= r; i++) {
      const s = t.getLineContent(i),
        a = s.match(e.foldingRules.markers.start);
      if (a) {
        const o = {
          startLineNumber: i,
          startColumn: a[0].length + 1,
          endLineNumber: i,
          endColumn: s.length + 1
        };
        if (o.endColumn > o.startColumn) {
          const u = {
            range: o,
            ...Nc(s.substring(a[0].length)),
            shouldBeInComments: !1
          };
          (u.text || u.hasSeparatorLine) && n.push(u)
        }
      }
    }
    return n
  }

  function Lc(t, e) {
    const n = [],
      r = t.getLineCount();
    if (!e.markSectionHeaderRegex || e.markSectionHeaderRegex.trim() === "") return n;
    const i = Nu(e.markSectionHeaderRegex),
      s = new RegExp(e.markSectionHeaderRegex, `gdm${i?"s":""}`);
    if (yl(s)) return n;
    for (let a = 1; a <= r; a += ga - wc) {
      const o = Math.min(a + ga - 1, r),
        u = [];
      for (let f = a; f <= o; f++) u.push(t.getLineContent(f));
      const l = u.join(`
`);
      s.lastIndex = 0;
      let h;
      for (;
        (h = s.exec(l)) !== null;) {
        const f = l.substring(0, h.index),
          m = (f.match(/\n/g) || []).length,
          g = a + m,
          d = h[0].split(`
`),
          p = d.length,
          y = g + p - 1,
          w = f.lastIndexOf(`
`) + 1,
          N = h.index - w + 1,
          b = d[d.length - 1],
          _ = p === 1 ? N + h[0].length : b.length + 1,
          L = {
            startLineNumber: g,
            startColumn: N,
            endLineNumber: y,
            endColumn: _
          },
          A = (h.groups ?? {}).label ?? "",
          v = ((h.groups ?? {}).separator ?? "") !== "",
          k = {
            range: L,
            text: A,
            hasSeparatorLine: v,
            shouldBeInComments: !0
          };
        (k.text || k.hasSeparatorLine) && (n.length === 0 || n[n.length - 1].range.endLineNumber < k.range.startLineNumber) && n.push(k), s.lastIndex = h.index + h[0].length
      }
    }
    return n
  }

  function Nc(t) {
    t = t.trim();
    const e = t.startsWith("-");
    return t = t.replace(yc, ""), {
      text: t,
      hasSeparatorLine: e
    }
  }
  class _c {
    get isRejected() {
      var e;
      return ((e = this.outcome) == null ? void 0 : e.outcome) === 1
    }
    get isSettled() {
      return !!this.outcome
    }
    constructor() {
      this.p = new Promise((e, n) => {
        this.completeCallback = e, this.errorCallback = n
      })
    }
    complete(e) {
      return this.isSettled ? Promise.resolve() : new Promise(n => {
        this.completeCallback(e), this.outcome = {
          outcome: 0,
          value: e
        }, n()
      })
    }
    error(e) {
      return this.isSettled ? Promise.resolve() : new Promise(n => {
        this.errorCallback(e), this.outcome = {
          outcome: 1,
          value: e
        }, n()
      })
    }
    cancel() {
      return this.error(new li)
    }
  }
  var pa;
  (function(t) {
    async function e(r) {
      let i;
      const s = await Promise.all(r.map(a => a.then(o => o, o => {
        i || (i = o)
      })));
      if (typeof i < "u") throw i;
      return s
    }
    t.settled = e;

    function n(r) {
      return new Promise(async (i, s) => {
        try {
          await r(i, s)
        } catch (a) {
          s(a)
        }
      })
    }
    t.withAsyncBody = n
  })(pa || (pa = {}));
  class Sc {
    constructor() {
      this._unsatisfiedConsumers = [], this._unconsumedValues = []
    }
    get hasFinalValue() {
      return !!this._finalValue
    }
    produce(e) {
      if (this._ensureNoFinalValue(), this._unsatisfiedConsumers.length > 0) {
        const n = this._unsatisfiedConsumers.shift();
        this._resolveOrRejectDeferred(n, e)
      } else this._unconsumedValues.push(e)
    }
    produceFinal(e) {
      this._ensureNoFinalValue(), this._finalValue = e;
      for (const n of this._unsatisfiedConsumers) this._resolveOrRejectDeferred(n, e);
      this._unsatisfiedConsumers.length = 0
    }
    _ensureNoFinalValue() {
      if (this._finalValue) throw new ue("ProducerConsumer: cannot produce after final value has been set")
    }
    _resolveOrRejectDeferred(e, n) {
      n.ok ? e.complete(n.value) : e.error(n.error)
    }
    consume() {
      if (this._unconsumedValues.length > 0 || this._finalValue) {
        const e = this._unconsumedValues.length > 0 ? this._unconsumedValues.shift() : this._finalValue;
        return e.ok ? Promise.resolve(e.value) : Promise.reject(e.error)
      } else {
        const e = new _c;
        return this._unsatisfiedConsumers.push(e), e.p
      }
    }
  }
  const pe = class pe {
    constructor(e, n) {
      this._onReturn = n, this._producerConsumer = new Sc, this._iterator = {
        next: () => this._producerConsumer.consume(),
        return: () => {
          var r;
          return (r = this._onReturn) == null || r.call(this), Promise.resolve({
            done: !0,
            value: void 0
          })
        },
        throw: async r => (this._finishError(r), {
          done: !0,
          value: void 0
        })
      }, queueMicrotask(async () => {
        const r = e({
          emitOne: i => this._producerConsumer.produce({
            ok: !0,
            value: {
              done: !1,
              value: i
            }
          }),
          emitMany: i => {
            for (const s of i) this._producerConsumer.produce({
              ok: !0,
              value: {
                done: !1,
                value: s
              }
            })
          },
          reject: i => this._finishError(i)
        });
        if (!this._producerConsumer.hasFinalValue) try {
          await r, this._finishOk()
        } catch (i) {
          this._finishError(i)
        }
      })
    }
    static fromArray(e) {
      return new pe(n => {
        n.emitMany(e)
      })
    }
    static fromPromise(e) {
      return new pe(async n => {
        n.emitMany(await e)
      })
    }
    static fromPromisesResolveOrder(e) {
      return new pe(async n => {
        await Promise.all(e.map(async r => n.emitOne(await r)))
      })
    }
    static merge(e) {
      return new pe(async n => {
        await Promise.all(e.map(async r => {
          for await (const i of r) n.emitOne(i)
        }))
      })
    }
    static map(e, n) {
      return new pe(async r => {
        for await (const i of e) r.emitOne(n(i))
      })
    }
    map(e) {
      return pe.map(this, e)
    }
    static coalesce(e) {
      return pe.filter(e, n => !!n)
    }
    coalesce() {
      return pe.coalesce(this)
    }
    static filter(e, n) {
      return new pe(async r => {
        for await (const i of e) n(i) && r.emitOne(i)
      })
    }
    filter(e) {
      return pe.filter(this, e)
    }
    _finishOk() {
      this._producerConsumer.hasFinalValue || this._producerConsumer.produceFinal({
        ok: !0,
        value: {
          done: !0,
          value: void 0
        }
      })
    }
    _finishError(e) {
      this._producerConsumer.hasFinalValue || this._producerConsumer.produceFinal({
        ok: !1,
        error: e
      })
    } [Symbol.asyncIterator]() {
      return this._iterator
    }
  };
  pe.EMPTY = pe.fromArray([]);
  let ba = pe;
  class Ac {
    constructor(e) {
      this.values = e, this.prefixSum = new Uint32Array(e.length), this.prefixSumValidIndex = new Int32Array(1), this.prefixSumValidIndex[0] = -1
    }
    insertValues(e, n) {
      e = xt(e);
      const r = this.values,
        i = this.prefixSum,
        s = n.length;
      return s === 0 ? !1 : (this.values = new Uint32Array(r.length + s), this.values.set(r.subarray(0, e), 0), this.values.set(r.subarray(e), e + s), this.values.set(n, e), e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), this.prefixSum = new Uint32Array(this.values.length), this.prefixSumValidIndex[0] >= 0 && this.prefixSum.set(i.subarray(0, this.prefixSumValidIndex[0] + 1)), !0)
    }
    setValue(e, n) {
      return e = xt(e), n = xt(n), this.values[e] === n ? !1 : (this.values[e] = n, e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), !0)
    }
    removeValues(e, n) {
      e = xt(e), n = xt(n);
      const r = this.values,
        i = this.prefixSum;
      if (e >= r.length) return !1;
      const s = r.length - e;
      return n >= s && (n = s), n === 0 ? !1 : (this.values = new Uint32Array(r.length - n), this.values.set(r.subarray(0, e), 0), this.values.set(r.subarray(e + n), e), this.prefixSum = new Uint32Array(this.values.length), e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), this.prefixSumValidIndex[0] >= 0 && this.prefixSum.set(i.subarray(0, this.prefixSumValidIndex[0] + 1)), !0)
    }
    getTotalSum() {
      return this.values.length === 0 ? 0 : this._getPrefixSum(this.values.length - 1)
    }
    getPrefixSum(e) {
      return e < 0 ? 0 : (e = xt(e), this._getPrefixSum(e))
    }
    _getPrefixSum(e) {
      if (e <= this.prefixSumValidIndex[0]) return this.prefixSum[e];
      let n = this.prefixSumValidIndex[0] + 1;
      n === 0 && (this.prefixSum[0] = this.values[0], n++), e >= this.values.length && (e = this.values.length - 1);
      for (let r = n; r <= e; r++) this.prefixSum[r] = this.prefixSum[r - 1] + this.values[r];
      return this.prefixSumValidIndex[0] = Math.max(this.prefixSumValidIndex[0], e), this.prefixSum[e]
    }
    getIndexOf(e) {
      e = Math.floor(e), this.getTotalSum();
      let n = 0,
        r = this.values.length - 1,
        i = 0,
        s = 0,
        a = 0;
      for (; n <= r;)
        if (i = n + (r - n) / 2 | 0, s = this.prefixSum[i], a = s - this.values[i], e < a) r = i - 1;
        else if (e >= s) n = i + 1;
      else break;
      return new kc(i, e - a)
    }
  }
  class kc {
    constructor(e, n) {
      this.index = e, this.remainder = n, this._prefixSumIndexOfResultBrand = void 0, this.index = e, this.remainder = n
    }
  }
  class Rc {
    constructor(e, n, r, i) {
      this._uri = e, this._lines = n, this._eol = r, this._versionId = i, this._lineStarts = null, this._cachedTextValue = null
    }
    dispose() {
      this._lines.length = 0
    }
    get version() {
      return this._versionId
    }
    getText() {
      return this._cachedTextValue === null && (this._cachedTextValue = this._lines.join(this._eol)), this._cachedTextValue
    }
    onEvents(e) {
      e.eol && e.eol !== this._eol && (this._eol = e.eol, this._lineStarts = null);
      const n = e.changes;
      for (const r of n) this._acceptDeleteRange(r.range), this._acceptInsertText(new Q(r.range.startLineNumber, r.range.startColumn), r.text);
      this._versionId = e.versionId, this._cachedTextValue = null
    }
    _ensureLineStarts() {
      if (!this._lineStarts) {
        const e = this._eol.length,
          n = this._lines.length,
          r = new Uint32Array(n);
        for (let i = 0; i < n; i++) r[i] = this._lines[i].length + e;
        this._lineStarts = new Ac(r)
      }
    }
    _setLineText(e, n) {
      this._lines[e] = n, this._lineStarts && this._lineStarts.setValue(e, this._lines[e].length + this._eol.length)
    }
    _acceptDeleteRange(e) {
      if (e.startLineNumber === e.endLineNumber) {
        if (e.startColumn === e.endColumn) return;
        this._setLineText(e.startLineNumber - 1, this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) + this._lines[e.startLineNumber - 1].substring(e.endColumn - 1));
        return
      }
      this._setLineText(e.startLineNumber - 1, this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) + this._lines[e.endLineNumber - 1].substring(e.endColumn - 1)), this._lines.splice(e.startLineNumber, e.endLineNumber - e.startLineNumber), this._lineStarts && this._lineStarts.removeValues(e.startLineNumber, e.endLineNumber - e.startLineNumber)
    }
    _acceptInsertText(e, n) {
      if (n.length === 0) return;
      const r = wl(n);
      if (r.length === 1) {
        this._setLineText(e.lineNumber - 1, this._lines[e.lineNumber - 1].substring(0, e.column - 1) + r[0] + this._lines[e.lineNumber - 1].substring(e.column - 1));
        return
      }
      r[r.length - 1] += this._lines[e.lineNumber - 1].substring(e.column - 1), this._setLineText(e.lineNumber - 1, this._lines[e.lineNumber - 1].substring(0, e.column - 1) + r[0]);
      const i = new Uint32Array(r.length - 1);
      for (let s = 1; s < r.length; s++) this._lines.splice(e.lineNumber + s - 1, 0, r[s]), i[s - 1] = r[s].length + this._eol.length;
      this._lineStarts && this._lineStarts.insertValues(e.lineNumber, i)
    }
  }
  class Ec {
    constructor() {
      this._models = Object.create(null)
    }
    getModel(e) {
      return this._models[e]
    }
    getModels() {
      const e = [];
      return Object.keys(this._models).forEach(n => e.push(this._models[n])), e
    }
    $acceptNewModel(e) {
      this._models[e.url] = new Mc(gr.parse(e.url), e.lines, e.EOL, e.versionId)
    }
    $acceptModelChanged(e, n) {
      if (!this._models[e]) return;
      this._models[e].onEvents(n)
    }
    $acceptRemovedModel(e) {
      this._models[e] && delete this._models[e]
    }
  }
  class Mc extends Rc {
    get uri() {
      return this._uri
    }
    get eol() {
      return this._eol
    }
    getValue() {
      return this.getText()
    }
    findMatches(e) {
      const n = [];
      for (let r = 0; r < this._lines.length; r++) {
        const i = this._lines[r],
          s = this.offsetAt(new Q(r + 1, 1)),
          a = i.matchAll(e);
        for (const o of a)(o.index || o.index === 0) && (o.index = o.index + s), n.push(o)
      }
      return n
    }
    getLinesContent() {
      return this._lines.slice(0)
    }
    getLineCount() {
      return this._lines.length
    }
    getLineContent(e) {
      return this._lines[e - 1]
    }
    getWordAtPosition(e, n) {
      const r = Nr(e.column, js(n), this._lines[e.lineNumber - 1], 0);
      return r ? new U(e.lineNumber, r.startColumn, e.lineNumber, r.endColumn) : null
    }
    words(e) {
      const n = this._lines,
        r = this._wordenize.bind(this);
      let i = 0,
        s = "",
        a = 0,
        o = [];
      return {
        *[Symbol.iterator]() {
          for (;;)
            if (a < o.length) {
              const u = s.substring(o[a].start, o[a].end);
              a += 1, yield u
            } else if (i < n.length) s = n[i], o = r(s, e), a = 0, i += 1;
          else break
        }
      }
    }
    getLineWords(e, n) {
      const r = this._lines[e - 1],
        i = this._wordenize(r, n),
        s = [];
      for (const a of i) s.push({
        word: r.substring(a.start, a.end),
        startColumn: a.start + 1,
        endColumn: a.end + 1
      });
      return s
    }
    _wordenize(e, n) {
      const r = [];
      let i;
      for (n.lastIndex = 0;
        (i = n.exec(e)) && i[0].length !== 0;) r.push({
        start: i.index,
        end: i.index + i[0].length
      });
      return r
    }
    getValueInRange(e) {
      if (e = this._validateRange(e), e.startLineNumber === e.endLineNumber) return this._lines[e.startLineNumber - 1].substring(e.startColumn - 1, e.endColumn - 1);
      const n = this._eol,
        r = e.startLineNumber - 1,
        i = e.endLineNumber - 1,
        s = [];
      s.push(this._lines[r].substring(e.startColumn - 1));
      for (let a = r + 1; a < i; a++) s.push(this._lines[a]);
      return s.push(this._lines[i].substring(0, e.endColumn - 1)), s.join(n)
    }
    offsetAt(e) {
      return e = this._validatePosition(e), this._ensureLineStarts(), this._lineStarts.getPrefixSum(e.lineNumber - 2) + (e.column - 1)
    }
    positionAt(e) {
      e = Math.floor(e), e = Math.max(0, e), this._ensureLineStarts();
      const n = this._lineStarts.getIndexOf(e),
        r = this._lines[n.index].length;
      return {
        lineNumber: 1 + n.index,
        column: 1 + Math.min(n.remainder, r)
      }
    }
    _validateRange(e) {
      const n = this._validatePosition({
          lineNumber: e.startLineNumber,
          column: e.startColumn
        }),
        r = this._validatePosition({
          lineNumber: e.endLineNumber,
          column: e.endColumn
        });
      return n.lineNumber !== e.startLineNumber || n.column !== e.startColumn || r.lineNumber !== e.endLineNumber || r.column !== e.endColumn ? {
        startLineNumber: n.lineNumber,
        startColumn: n.column,
        endLineNumber: r.lineNumber,
        endColumn: r.column
      } : e
    }
    _validatePosition(e) {
      if (!Q.isIPosition(e)) throw new Error("bad position");
      let {
        lineNumber: n,
        column: r
      } = e, i = !1;
      if (n < 1) n = 1, r = 1, i = !0;
      else if (n > this._lines.length) n = this._lines.length, r = this._lines[n - 1].length + 1, i = !0;
      else {
        const s = this._lines[n - 1].length + 1;
        r < 1 ? (r = 1, i = !0) : r > s && (r = s, i = !0)
      }
      return i ? {
        lineNumber: n,
        column: r
      } : e
    }
  }
  const mt = class mt {
    constructor(e = null) {
      this._foreignModule = e, this._requestHandlerBrand = void 0, this._workerTextModelSyncServer = new Ec
    }
    dispose() {}
    async $ping() {
      return "pong"
    }
    _getModel(e) {
      return this._workerTextModelSyncServer.getModel(e)
    }
    getModels() {
      return this._workerTextModelSyncServer.getModels()
    }
    $acceptNewModel(e) {
      this._workerTextModelSyncServer.$acceptNewModel(e)
    }
    $acceptModelChanged(e, n) {
      this._workerTextModelSyncServer.$acceptModelChanged(e, n)
    }
    $acceptRemovedModel(e) {
      this._workerTextModelSyncServer.$acceptRemovedModel(e)
    }
    async $computeUnicodeHighlights(e, n, r) {
      const i = this._getModel(e);
      return i ? Tu.computeUnicodeHighlights(i, n, r) : {
        ranges: [],
        hasMore: !1,
        ambiguousCharacterCount: 0,
        invisibleCharacterCount: 0,
        nonBasicAsciiCharacterCount: 0
      }
    }
    async $findSectionHeaders(e, n) {
      const r = this._getModel(e);
      return r ? xc(r, n) : []
    }
    async $computeDiff(e, n, r, i) {
      const s = this._getModel(e),
        a = this._getModel(n);
      return !s || !a ? null : mt.computeDiff(s, a, r, i)
    }
    static computeDiff(e, n, r, i) {
      const s = i === "advanced" ? fa.getDefault() : fa.getLegacy(),
        a = e.getLinesContent(),
        o = n.getLinesContent(),
        u = s.computeDiff(a, o, r),
        l = u.changes.length > 0 ? !1 : this._modelsAreIdentical(e, n);

      function h(f) {
        return f.map(m => {
          var g;
          return [m.original.startLineNumber, m.original.endLineNumberExclusive, m.modified.startLineNumber, m.modified.endLineNumberExclusive, (g = m.innerChanges) == null ? void 0 : g.map(d => [d.originalRange.startLineNumber, d.originalRange.startColumn, d.originalRange.endLineNumber, d.originalRange.endColumn, d.modifiedRange.startLineNumber, d.modifiedRange.startColumn, d.modifiedRange.endLineNumber, d.modifiedRange.endColumn])]
        })
      }
      return {
        identical: l,
        quitEarly: u.hitTimeout,
        changes: h(u.changes),
        moves: u.moves.map(f => [f.lineRangeMapping.original.startLineNumber, f.lineRangeMapping.original.endLineNumberExclusive, f.lineRangeMapping.modified.startLineNumber, f.lineRangeMapping.modified.endLineNumberExclusive, h(f.changes)])
      }
    }
    static _modelsAreIdentical(e, n) {
      const r = e.getLineCount(),
        i = n.getLineCount();
      if (r !== i) return !1;
      for (let s = 1; s <= r; s++) {
        const a = e.getLineContent(s),
          o = n.getLineContent(s);
        if (a !== o) return !1
      }
      return !0
    }
    async $computeMoreMinimalEdits(e, n, r) {
      const i = this._getModel(e);
      if (!i) return n;
      const s = [];
      let a;
      n = n.slice(0).sort((u, l) => {
        if (u.range && l.range) return U.compareRangesUsingStarts(u.range, l.range);
        const h = u.range ? 0 : 1,
          f = l.range ? 0 : 1;
        return h - f
      });
      let o = 0;
      for (let u = 1; u < n.length; u++) U.getEndPosition(n[o].range).equals(U.getStartPosition(n[u].range)) ? (n[o].range = U.fromPositions(U.getStartPosition(n[o].range), U.getEndPosition(n[u].range)), n[o].text += n[u].text) : (o++, n[o] = n[u]);
      n.length = o + 1;
      for (let {
          range: u,
          text: l,
          eol: h
        }
        of n) {
        if (typeof h == "number" && (a = h), U.isEmpty(u) && !l) continue;
        const f = i.getValueInRange(u);
        if (l = l.replace(/\r\n|\n|\r/g, i.eol), f === l) continue;
        if (Math.max(l.length, f.length) > mt._diffLimit) {
          s.push({
            range: u,
            text: l
          });
          continue
        }
        const m = Ol(f, l, r),
          g = i.offsetAt(U.lift(u).getStartPosition());
        for (const d of m) {
          const p = i.positionAt(g + d.originalStart),
            y = i.positionAt(g + d.originalStart + d.originalLength),
            w = {
              text: l.substr(d.modifiedStart, d.modifiedLength),
              range: {
                startLineNumber: p.lineNumber,
                startColumn: p.column,
                endLineNumber: y.lineNumber,
                endColumn: y.column
              }
            };
          i.getValueInRange(w.range) !== w.text && s.push(w)
        }
      }
      return typeof a == "number" && s.push({
        eol: a,
        text: "",
        range: {
          startLineNumber: 0,
          startColumn: 0,
          endLineNumber: 0,
          endColumn: 0
        }
      }), s
    }
    async $computeLinks(e) {
      const n = this._getModel(e);
      return n ? jl(n) : null
    }
    async $computeDefaultDocumentColors(e) {
      const n = this._getModel(e);
      return n ? bc(n) : null
    }
    async $textualSuggest(e, n, r, i) {
      const s = new gn,
        a = new RegExp(r, i),
        o = new Set;
      e: for (const u of e) {
        const l = this._getModel(u);
        if (l) {
          for (const h of l.words(a))
            if (!(h === n || !isNaN(Number(h))) && (o.add(h), o.size > mt._suggestionsLimit)) break e
        }
      }
      return {
        words: Array.from(o),
        duration: s.elapsed()
      }
    }
    async $computeWordRanges(e, n, r, i) {
      const s = this._getModel(e);
      if (!s) return Object.create(null);
      const a = new RegExp(r, i),
        o = Object.create(null);
      for (let u = n.startLineNumber; u < n.endLineNumber; u++) {
        const l = s.getLineWords(u, a);
        for (const h of l) {
          if (!isNaN(Number(h.word))) continue;
          let f = o[h.word];
          f || (f = [], o[h.word] = f), f.push({
            startLineNumber: u,
            startColumn: h.startColumn,
            endLineNumber: u,
            endColumn: h.endColumn
          })
        }
      }
      return o
    }
    async $navigateValueSet(e, n, r, i, s) {
      const a = this._getModel(e);
      if (!a) return null;
      const o = new RegExp(i, s);
      n.startColumn === n.endColumn && (n = {
        startLineNumber: n.startLineNumber,
        startColumn: n.startColumn,
        endLineNumber: n.endLineNumber,
        endColumn: n.endColumn + 1
      });
      const u = a.getValueInRange(n),
        l = a.getWordAtPosition({
          lineNumber: n.startLineNumber,
          column: n.startColumn
        }, o);
      if (!l) return null;
      const h = a.getValueInRange(l);
      return ur.INSTANCE.navigateValueSet(n, u, l, h, r)
    }
    $fmr(e, n) {
      if (!this._foreignModule || typeof this._foreignModule[e] != "function") return Promise.reject(new Error("Missing requestHandler or method: " + e));
      try {
        return Promise.resolve(this._foreignModule[e].apply(this._foreignModule, n))
      } catch (r) {
        return Promise.reject(r)
      }
    }
  };
  mt._diffLimit = 1e5, mt._suggestionsLimit = 1e4;
  let Tr = mt;
  typeof importScripts == "function" && (globalThis.monaco = yu());
  const fn = class fn {
    static getChannel(e) {
      return e.getChannel(fn.CHANNEL_NAME)
    }
    static setChannel(e, n) {
      e.setChannel(fn.CHANNEL_NAME, n)
    }
  };
  fn.CHANNEL_NAME = "editorWorkerHost";
  let Pr = fn;

  function Tc(t) {
    let e;
    const n = Vl(r => {
      const i = Pr.getChannel(r),
        a = {
          host: new Proxy({}, {
            get(o, u, l) {
              if (u !== "then") {
                if (typeof u != "string") throw new Error("Not supported");
                return (...h) => i.$fhr(u, h)
              }
            }
          }),
          getMirrorModels: () => n.requestHandler.getModels()
        };
      return e = t(a), new Tr(e)
    });
    return e
  }

  function Pc(t) {
    self.onmessage = e => {
      Tc(n => t(n, e.data))
    }
  }

  function Cr(t, e = !1) {
    const n = t.length;
    let r = 0,
      i = "",
      s = 0,
      a = 16,
      o = 0,
      u = 0,
      l = 0,
      h = 0,
      f = 0;

    function m(b, _) {
      let L = 0,
        A = 0;
      for (; L < b;) {
        let v = t.charCodeAt(r);
        if (v >= 48 && v <= 57) A = A * 16 + v - 48;
        else if (v >= 65 && v <= 70) A = A * 16 + v - 65 + 10;
        else if (v >= 97 && v <= 102) A = A * 16 + v - 97 + 10;
        else break;
        r++, L++
      }
      return L < b && (A = -1), A
    }

    function g(b) {
      r = b, i = "", s = 0, a = 16, f = 0
    }

    function d() {
      let b = r;
      if (t.charCodeAt(r) === 48) r++;
      else
        for (r++; r < t.length && Mt(t.charCodeAt(r));) r++;
      if (r < t.length && t.charCodeAt(r) === 46)
        if (r++, r < t.length && Mt(t.charCodeAt(r)))
          for (r++; r < t.length && Mt(t.charCodeAt(r));) r++;
        else return f = 3, t.substring(b, r);
      let _ = r;
      if (r < t.length && (t.charCodeAt(r) === 69 || t.charCodeAt(r) === 101))
        if (r++, (r < t.length && t.charCodeAt(r) === 43 || t.charCodeAt(r) === 45) && r++, r < t.length && Mt(t.charCodeAt(r))) {
          for (r++; r < t.length && Mt(t.charCodeAt(r));) r++;
          _ = r
        } else f = 3;
      return t.substring(b, _)
    }

    function p() {
      let b = "",
        _ = r;
      for (;;) {
        if (r >= n) {
          b += t.substring(_, r), f = 2;
          break
        }
        const L = t.charCodeAt(r);
        if (L === 34) {
          b += t.substring(_, r), r++;
          break
        }
        if (L === 92) {
          if (b += t.substring(_, r), r++, r >= n) {
            f = 2;
            break
          }
          switch (t.charCodeAt(r++)) {
            case 34:
              b += '"';
              break;
            case 92:
              b += "\\";
              break;
            case 47:
              b += "/";
              break;
            case 98:
              b += "\b";
              break;
            case 102:
              b += "\f";
              break;
            case 110:
              b += `
`;
              break;
            case 114:
              b += "\r";
              break;
            case 116:
              b += "	";
              break;
            case 117:
              const v = m(4);
              v >= 0 ? b += String.fromCharCode(v) : f = 4;
              break;
            default:
              f = 5
          }
          _ = r;
          continue
        }
        if (L >= 0 && L <= 31)
          if (tn(L)) {
            b += t.substring(_, r), f = 2;
            break
          } else f = 6;
        r++
      }
      return b
    }

    function y() {
      if (i = "", f = 0, s = r, u = o, h = l, r >= n) return s = n, a = 17;
      let b = t.charCodeAt(r);
      if (Ir(b)) {
        do r++, i += String.fromCharCode(b), b = t.charCodeAt(r); while (Ir(b));
        return a = 15
      }
      if (tn(b)) return r++, i += String.fromCharCode(b), b === 13 && t.charCodeAt(r) === 10 && (r++, i += `
`), o++, l = r, a = 14;
      switch (b) {
        case 123:
          return r++, a = 1;
        case 125:
          return r++, a = 2;
        case 91:
          return r++, a = 3;
        case 93:
          return r++, a = 4;
        case 58:
          return r++, a = 6;
        case 44:
          return r++, a = 5;
        case 34:
          return r++, i = p(), a = 10;
        case 47:
          const _ = r - 1;
          if (t.charCodeAt(r + 1) === 47) {
            for (r += 2; r < n && !tn(t.charCodeAt(r));) r++;
            return i = t.substring(_, r), a = 12
          }
          if (t.charCodeAt(r + 1) === 42) {
            r += 2;
            const L = n - 1;
            let A = !1;
            for (; r < L;) {
              const v = t.charCodeAt(r);
              if (v === 42 && t.charCodeAt(r + 1) === 47) {
                r += 2, A = !0;
                break
              }
              r++, tn(v) && (v === 13 && t.charCodeAt(r) === 10 && r++, o++, l = r)
            }
            return A || (r++, f = 1), i = t.substring(_, r), a = 13
          }
          return i += String.fromCharCode(b), r++, a = 16;
        case 45:
          if (i += String.fromCharCode(b), r++, r === n || !Mt(t.charCodeAt(r))) return a = 16;
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:
          return i += d(), a = 11;
        default:
          for (; r < n && w(b);) r++, b = t.charCodeAt(r);
          if (s !== r) {
            switch (i = t.substring(s, r), i) {
              case "true":
                return a = 8;
              case "false":
                return a = 9;
              case "null":
                return a = 7
            }
            return a = 16
          }
          return i += String.fromCharCode(b), r++, a = 16
      }
    }

    function w(b) {
      if (Ir(b) || tn(b)) return !1;
      switch (b) {
        case 125:
        case 93:
        case 123:
        case 91:
        case 34:
        case 58:
        case 44:
        case 47:
          return !1
      }
      return !0
    }

    function N() {
      let b;
      do b = y(); while (b >= 12 && b <= 15);
      return b
    }
    return {
      setPosition: g,
      getPosition: () => r,
      scan: e ? N : y,
      getToken: () => a,
      getTokenValue: () => i,
      getTokenOffset: () => s,
      getTokenLength: () => r - s,
      getTokenStartLine: () => u,
      getTokenStartCharacter: () => s - h,
      getTokenError: () => f
    }
  }

  function Ir(t) {
    return t === 32 || t === 9
  }

  function tn(t) {
    return t === 10 || t === 13
  }

  function Mt(t) {
    return t >= 48 && t <= 57
  }
  var ya;
  (function(t) {
    t[t.lineFeed = 10] = "lineFeed", t[t.carriageReturn = 13] = "carriageReturn", t[t.space = 32] = "space", t[t._0 = 48] = "_0", t[t._1 = 49] = "_1", t[t._2 = 50] = "_2", t[t._3 = 51] = "_3", t[t._4 = 52] = "_4", t[t._5 = 53] = "_5", t[t._6 = 54] = "_6", t[t._7 = 55] = "_7", t[t._8 = 56] = "_8", t[t._9 = 57] = "_9", t[t.a = 97] = "a", t[t.b = 98] = "b", t[t.c = 99] = "c", t[t.d = 100] = "d", t[t.e = 101] = "e", t[t.f = 102] = "f", t[t.g = 103] = "g", t[t.h = 104] = "h", t[t.i = 105] = "i", t[t.j = 106] = "j", t[t.k = 107] = "k", t[t.l = 108] = "l", t[t.m = 109] = "m", t[t.n = 110] = "n", t[t.o = 111] = "o", t[t.p = 112] = "p", t[t.q = 113] = "q", t[t.r = 114] = "r", t[t.s = 115] = "s", t[t.t = 116] = "t", t[t.u = 117] = "u", t[t.v = 118] = "v", t[t.w = 119] = "w", t[t.x = 120] = "x", t[t.y = 121] = "y", t[t.z = 122] = "z", t[t.A = 65] = "A", t[t.B = 66] = "B", t[t.C = 67] = "C", t[t.D = 68] = "D", t[t.E = 69] = "E", t[t.F = 70] = "F", t[t.G = 71] = "G", t[t.H = 72] = "H", t[t.I = 73] = "I", t[t.J = 74] = "J", t[t.K = 75] = "K", t[t.L = 76] = "L", t[t.M = 77] = "M", t[t.N = 78] = "N", t[t.O = 79] = "O", t[t.P = 80] = "P", t[t.Q = 81] = "Q", t[t.R = 82] = "R", t[t.S = 83] = "S", t[t.T = 84] = "T", t[t.U = 85] = "U", t[t.V = 86] = "V", t[t.W = 87] = "W", t[t.X = 88] = "X", t[t.Y = 89] = "Y", t[t.Z = 90] = "Z", t[t.asterisk = 42] = "asterisk", t[t.backslash = 92] = "backslash", t[t.closeBrace = 125] = "closeBrace", t[t.closeBracket = 93] = "closeBracket", t[t.colon = 58] = "colon", t[t.comma = 44] = "comma", t[t.dot = 46] = "dot", t[t.doubleQuote = 34] = "doubleQuote", t[t.minus = 45] = "minus", t[t.openBrace = 123] = "openBrace", t[t.openBracket = 91] = "openBracket", t[t.plus = 43] = "plus", t[t.slash = 47] = "slash", t[t.formFeed = 12] = "formFeed", t[t.tab = 9] = "tab"
  })(ya || (ya = {}));
  const Se = new Array(20).fill(0).map((t, e) => " ".repeat(e)),
    Tt = 200,
    wa = {
      " ": {
        "\n": new Array(Tt).fill(0).map((t, e) => `
` + " ".repeat(e)),
        "\r": new Array(Tt).fill(0).map((t, e) => "\r" + " ".repeat(e)),
        "\r\n": new Array(Tt).fill(0).map((t, e) => `\r
` + " ".repeat(e))
      },
      "	": {
        "\n": new Array(Tt).fill(0).map((t, e) => `
` + "	".repeat(e)),
        "\r": new Array(Tt).fill(0).map((t, e) => "\r" + "	".repeat(e)),
        "\r\n": new Array(Tt).fill(0).map((t, e) => `\r
` + "	".repeat(e))
      }
    },
    Cc = [`
`, "\r", `\r
`];

  function Ic(t, e, n) {
    let r, i, s, a, o;
    if (e) {
      for (a = e.offset, o = a + e.length, s = a; s > 0 && !xa(t, s - 1);) s--;
      let L = o;
      for (; L < t.length && !xa(t, L);) L++;
      i = t.substring(s, L), r = Fc(i, n)
    } else i = t, r = 0, s = 0, a = 0, o = t.length;
    const u = Vc(n, t),
      l = Cc.includes(u);
    let h = 0,
      f = 0,
      m;
    n.insertSpaces ? m = Se[n.tabSize || 4] ?? Pt(Se[1], n.tabSize || 4) : m = "	";
    const g = m === "	" ? "	" : " ";
    let d = Cr(i, !1),
      p = !1;

    function y() {
      if (h > 1) return Pt(u, h) + Pt(m, r + f);
      const L = m.length * (r + f);
      return !l || L > wa[g][u].length ? u + Pt(m, r + f) : L <= 0 ? u : wa[g][u][L]
    }

    function w() {
      let L = d.scan();
      for (h = 0; L === 15 || L === 14;) L === 14 && n.keepLines ? h += 1 : L === 14 && (h = 1), L = d.scan();
      return p = L === 16 || d.getTokenError() !== 0, L
    }
    const N = [];

    function b(L, A, v) {
      !p && (!e || A < o && v > a) && t.substring(A, v) !== L && N.push({
        offset: A,
        length: v - A,
        content: L
      })
    }
    let _ = w();
    if (n.keepLines && h > 0 && b(Pt(u, h), 0, 0), _ !== 17) {
      let L = d.getTokenOffset() + s,
        A = m.length * r < 20 && n.insertSpaces ? Se[m.length * r] : Pt(m, r);
      b(A, s, L)
    }
    for (; _ !== 17;) {
      let L = d.getTokenOffset() + d.getTokenLength() + s,
        A = w(),
        v = "",
        k = !1;
      for (; h === 0 && (A === 12 || A === 13);) {
        let V = d.getTokenOffset() + s;
        b(Se[1], L, V), L = d.getTokenOffset() + d.getTokenLength() + s, k = A === 12, v = k ? y() : "", A = w()
      }
      if (A === 2) _ !== 1 && f--, n.keepLines && h > 0 || !n.keepLines && _ !== 1 ? v = y() : n.keepLines && (v = Se[1]);
      else if (A === 4) _ !== 3 && f--, n.keepLines && h > 0 || !n.keepLines && _ !== 3 ? v = y() : n.keepLines && (v = Se[1]);
      else {
        switch (_) {
          case 3:
          case 1:
            f++, n.keepLines && h > 0 || !n.keepLines ? v = y() : v = Se[1];
            break;
          case 5:
            n.keepLines && h > 0 || !n.keepLines ? v = y() : v = Se[1];
            break;
          case 12:
            v = y();
            break;
          case 13:
            h > 0 ? v = y() : k || (v = Se[1]);
            break;
          case 6:
            n.keepLines && h > 0 ? v = y() : k || (v = Se[1]);
            break;
          case 10:
            n.keepLines && h > 0 ? v = y() : A === 6 && !k && (v = "");
            break;
          case 7:
          case 8:
          case 9:
          case 11:
          case 2:
          case 4:
            n.keepLines && h > 0 ? v = y() : (A === 12 || A === 13) && !k ? v = Se[1] : A !== 5 && A !== 17 && (p = !0);
            break;
          case 16:
            p = !0;
            break
        }
        h > 0 && (A === 12 || A === 13) && (v = y())
      }
      A === 17 && (n.keepLines && h > 0 ? v = y() : v = n.insertFinalNewline ? u : "");
      const M = d.getTokenOffset() + s;
      b(v, L, M), _ = A
    }
    return N
  }

  function Pt(t, e) {
    let n = "";
    for (let r = 0; r < e; r++) n += t;
    return n
  }

  function Fc(t, e) {
    let n = 0,
      r = 0;
    const i = e.tabSize || 4;
    for (; n < t.length;) {
      let s = t.charAt(n);
      if (s === Se[1]) r++;
      else if (s === "	") r += i;
      else break;
      n++
    }
    return Math.floor(r / i)
  }

  function Vc(t, e) {
    for (let n = 0; n < e.length; n++) {
      const r = e.charAt(n);
      if (r === "\r") return n + 1 < e.length && e.charAt(n + 1) === `
` ? `\r
` : "\r";
      if (r === `
`) return `
`
    }
    return t && t.eol || `
`
  }

  function xa(t, e) {
    return `\r
`.indexOf(t.charAt(e)) !== -1
  }
  var Mn;
  (function(t) {
    t.DEFAULT = {
      allowTrailingComma: !1
    }
  })(Mn || (Mn = {}));

  function Dc(t, e = [], n = Mn.DEFAULT) {
    let r = null,
      i = [];
    const s = [];

    function a(u) {
      Array.isArray(i) ? i.push(u) : r !== null && (i[r] = u)
    }
    return $c(t, {
      onObjectBegin: () => {
        const u = {};
        a(u), s.push(i), i = u, r = null
      },
      onObjectProperty: u => {
        r = u
      },
      onObjectEnd: () => {
        i = s.pop()
      },
      onArrayBegin: () => {
        const u = [];
        a(u), s.push(i), i = u, r = null
      },
      onArrayEnd: () => {
        i = s.pop()
      },
      onLiteralValue: a,
      onError: (u, l, h) => {
        e.push({
          error: u,
          offset: l,
          length: h
        })
      }
    }, n), i[0]
  }

  function va(t) {
    if (!t.parent || !t.parent.children) return [];
    const e = va(t.parent);
    if (t.parent.type === "property") {
      const n = t.parent.children[0].value;
      e.push(n)
    } else if (t.parent.type === "array") {
      const n = t.parent.children.indexOf(t);
      n !== -1 && e.push(n)
    }
    return e
  }

  function Fr(t) {
    switch (t.type) {
      case "array":
        return t.children.map(Fr);
      case "object":
        const e = Object.create(null);
        for (let n of t.children) {
          const r = n.children[1];
          r && (e[n.children[0].value] = Fr(r))
        }
        return e;
      case "null":
      case "string":
      case "number":
      case "boolean":
        return t.value;
      default:
        return
    }
  }

  function Oc(t, e, n = !1) {
    return e >= t.offset && e < t.offset + t.length || n && e === t.offset + t.length
  }

  function La(t, e, n = !1) {
    if (Oc(t, e, n)) {
      const r = t.children;
      if (Array.isArray(r))
        for (let i = 0; i < r.length && r[i].offset <= e; i++) {
          const s = La(r[i], e, n);
          if (s) return s
        }
      return t
    }
  }

  function $c(t, e, n = Mn.DEFAULT) {
    const r = Cr(t, !1),
      i = [];

    function s(x) {
      return x ? () => x(r.getTokenOffset(), r.getTokenLength(), r.getTokenStartLine(), r.getTokenStartCharacter()) : () => !0
    }

    function a(x) {
      return x ? () => x(r.getTokenOffset(), r.getTokenLength(), r.getTokenStartLine(), r.getTokenStartCharacter(), () => i.slice()) : () => !0
    }

    function o(x) {
      return x ? S => x(S, r.getTokenOffset(), r.getTokenLength(), r.getTokenStartLine(), r.getTokenStartCharacter()) : () => !0
    }

    function u(x) {
      return x ? S => x(S, r.getTokenOffset(), r.getTokenLength(), r.getTokenStartLine(), r.getTokenStartCharacter(), () => i.slice()) : () => !0
    }
    const l = a(e.onObjectBegin),
      h = u(e.onObjectProperty),
      f = s(e.onObjectEnd),
      m = a(e.onArrayBegin),
      g = s(e.onArrayEnd),
      d = u(e.onLiteralValue),
      p = o(e.onSeparator),
      y = s(e.onComment),
      w = o(e.onError),
      N = n && n.disallowComments,
      b = n && n.allowTrailingComma;

    function _() {
      for (;;) {
        const x = r.scan();
        switch (r.getTokenError()) {
          case 4:
            L(14);
            break;
          case 5:
            L(15);
            break;
          case 3:
            L(13);
            break;
          case 1:
            N || L(11);
            break;
          case 2:
            L(12);
            break;
          case 6:
            L(16);
            break
        }
        switch (x) {
          case 12:
          case 13:
            N ? L(10) : y();
            break;
          case 16:
            L(1);
            break;
          case 15:
          case 14:
            break;
          default:
            return x
        }
      }
    }

    function L(x, S = [], C = []) {
      if (w(x), S.length + C.length > 0) {
        let I = r.getToken();
        for (; I !== 17;) {
          if (S.indexOf(I) !== -1) {
            _();
            break
          } else if (C.indexOf(I) !== -1) break;
          I = _()
        }
      }
    }

    function A(x) {
      const S = r.getTokenValue();
      return x ? d(S) : (h(S), i.push(S)), _(), !0
    }

    function v() {
      switch (r.getToken()) {
        case 11:
          const x = r.getTokenValue();
          let S = Number(x);
          isNaN(S) && (L(2), S = 0), d(S);
          break;
        case 7:
          d(null);
          break;
        case 8:
          d(!0);
          break;
        case 9:
          d(!1);
          break;
        default:
          return !1
      }
      return _(), !0
    }

    function k() {
      return r.getToken() !== 10 ? (L(3, [], [2, 5]), !1) : (A(!1), r.getToken() === 6 ? (p(":"), _(), T() || L(4, [], [2, 5])) : L(5, [], [2, 5]), i.pop(), !0)
    }

    function M() {
      l(), _();
      let x = !1;
      for (; r.getToken() !== 2 && r.getToken() !== 17;) {
        if (r.getToken() === 5) {
          if (x || L(4, [], []), p(","), _(), r.getToken() === 2 && b) break
        } else x && L(6, [], []);
        k() || L(4, [], [2, 5]), x = !0
      }
      return f(), r.getToken() !== 2 ? L(7, [2], []) : _(), !0
    }

    function V() {
      m(), _();
      let x = !0,
        S = !1;
      for (; r.getToken() !== 4 && r.getToken() !== 17;) {
        if (r.getToken() === 5) {
          if (S || L(4, [], []), p(","), _(), r.getToken() === 4 && b) break
        } else S && L(6, [], []);
        x ? (i.push(0), x = !1) : i[i.length - 1]++, T() || L(4, [], [4, 5]), S = !0
      }
      return g(), x || i.pop(), r.getToken() !== 4 ? L(8, [4], []) : _(), !0
    }

    function T() {
      switch (r.getToken()) {
        case 3:
          return V();
        case 1:
          return M();
        case 10:
          return A(!0);
        default:
          return v()
      }
    }
    return _(), r.getToken() === 17 ? n.allowEmptyContent ? !0 : (L(4, [], []), !1) : T() ? (r.getToken() !== 17 && L(9, [], []), !0) : (L(4, [], []), !1)
  }
  const lt = Cr;
  var Na;
  (function(t) {
    t[t.None = 0] = "None", t[t.UnexpectedEndOfComment = 1] = "UnexpectedEndOfComment", t[t.UnexpectedEndOfString = 2] = "UnexpectedEndOfString", t[t.UnexpectedEndOfNumber = 3] = "UnexpectedEndOfNumber", t[t.InvalidUnicode = 4] = "InvalidUnicode", t[t.InvalidEscapeCharacter = 5] = "InvalidEscapeCharacter", t[t.InvalidCharacter = 6] = "InvalidCharacter"
  })(Na || (Na = {}));
  var _a;
  (function(t) {
    t[t.OpenBraceToken = 1] = "OpenBraceToken", t[t.CloseBraceToken = 2] = "CloseBraceToken", t[t.OpenBracketToken = 3] = "OpenBracketToken", t[t.CloseBracketToken = 4] = "CloseBracketToken", t[t.CommaToken = 5] = "CommaToken", t[t.ColonToken = 6] = "ColonToken", t[t.NullKeyword = 7] = "NullKeyword", t[t.TrueKeyword = 8] = "TrueKeyword", t[t.FalseKeyword = 9] = "FalseKeyword", t[t.StringLiteral = 10] = "StringLiteral", t[t.NumericLiteral = 11] = "NumericLiteral", t[t.LineCommentTrivia = 12] = "LineCommentTrivia", t[t.BlockCommentTrivia = 13] = "BlockCommentTrivia", t[t.LineBreakTrivia = 14] = "LineBreakTrivia", t[t.Trivia = 15] = "Trivia", t[t.Unknown = 16] = "Unknown", t[t.EOF = 17] = "EOF"
  })(_a || (_a = {}));
  const Bc = Dc,
    Uc = La,
    qc = va,
    jc = Fr;
  var Sa;
  (function(t) {
    t[t.InvalidSymbol = 1] = "InvalidSymbol", t[t.InvalidNumberFormat = 2] = "InvalidNumberFormat", t[t.PropertyNameExpected = 3] = "PropertyNameExpected", t[t.ValueExpected = 4] = "ValueExpected", t[t.ColonExpected = 5] = "ColonExpected", t[t.CommaExpected = 6] = "CommaExpected", t[t.CloseBraceExpected = 7] = "CloseBraceExpected", t[t.CloseBracketExpected = 8] = "CloseBracketExpected", t[t.EndOfFileExpected = 9] = "EndOfFileExpected", t[t.InvalidCommentToken = 10] = "InvalidCommentToken", t[t.UnexpectedEndOfComment = 11] = "UnexpectedEndOfComment", t[t.UnexpectedEndOfString = 12] = "UnexpectedEndOfString", t[t.UnexpectedEndOfNumber = 13] = "UnexpectedEndOfNumber", t[t.InvalidUnicode = 14] = "InvalidUnicode", t[t.InvalidEscapeCharacter = 15] = "InvalidEscapeCharacter", t[t.InvalidCharacter = 16] = "InvalidCharacter"
  })(Sa || (Sa = {}));

  function Wc(t, e, n) {
    return Ic(t, e, n)
  }

  function Ct(t, e) {
    if (t === e) return !0;
    if (t == null || e === null || e === void 0 || typeof t != typeof e || typeof t != "object" || Array.isArray(t) !== Array.isArray(e)) return !1;
    let n, r;
    if (Array.isArray(t)) {
      if (t.length !== e.length) return !1;
      for (n = 0; n < t.length; n++)
        if (!Ct(t[n], e[n])) return !1
    } else {
      const i = [];
      for (r in t) i.push(r);
      i.sort();
      const s = [];
      for (r in e) s.push(r);
      if (s.sort(), !Ct(i, s)) return !1;
      for (n = 0; n < i.length; n++)
        if (!Ct(t[i[n]], e[i[n]])) return !1
    }
    return !0
  }

  function ce(t) {
    return typeof t == "number"
  }

  function Ee(t) {
    return typeof t < "u"
  }

  function Ve(t) {
    return typeof t == "boolean"
  }

  function Aa(t) {
    return typeof t == "string"
  }

  function Ke(t) {
    return typeof t == "object" && t !== null && !Array.isArray(t)
  }

  function Hc(t, e) {
    if (t.length < e.length) return !1;
    for (let n = 0; n < e.length; n++)
      if (t[n] !== e[n]) return !1;
    return !0
  }

  function nn(t, e) {
    const n = t.length - e.length;
    return n > 0 ? t.lastIndexOf(e) === n : n === 0 ? t === e : !1
  }

  function Tn(t) {
    let e = "";
    Hc(t, "(?i)") && (t = t.substring(4), e = "i");
    try {
      return new RegExp(t, e + "u")
    } catch {
      try {
        return new RegExp(t, e)
      } catch {
        return
      }
    }
  }

  function ka(t) {
    let e = 0;
    for (let n = 0; n < t.length; n++) {
      e++;
      const r = t.charCodeAt(n);
      55296 <= r && r <= 56319 && n++
    }
    return e
  }
  var Ra;
  (function(t) {
    function e(n) {
      return typeof n == "string"
    }
    t.is = e
  })(Ra || (Ra = {}));
  var Vr;
  (function(t) {
    function e(n) {
      return typeof n == "string"
    }
    t.is = e
  })(Vr || (Vr = {}));
  var Ea;
  (function(t) {
    t.MIN_VALUE = -2147483648, t.MAX_VALUE = 2147483647;

    function e(n) {
      return typeof n == "number" && t.MIN_VALUE <= n && n <= t.MAX_VALUE
    }
    t.is = e
  })(Ea || (Ea = {}));
  var Pn;
  (function(t) {
    t.MIN_VALUE = 0, t.MAX_VALUE = 2147483647;

    function e(n) {
      return typeof n == "number" && t.MIN_VALUE <= n && n <= t.MAX_VALUE
    }
    t.is = e
  })(Pn || (Pn = {}));
  var ee;
  (function(t) {
    function e(r, i) {
      return r === Number.MAX_VALUE && (r = Pn.MAX_VALUE), i === Number.MAX_VALUE && (i = Pn.MAX_VALUE), {
        line: r,
        character: i
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.objectLiteral(i) && E.uinteger(i.line) && E.uinteger(i.character)
    }
    t.is = n
  })(ee || (ee = {}));
  var W;
  (function(t) {
    function e(r, i, s, a) {
      if (E.uinteger(r) && E.uinteger(i) && E.uinteger(s) && E.uinteger(a)) return {
        start: ee.create(r, i),
        end: ee.create(s, a)
      };
      if (ee.is(r) && ee.is(i)) return {
        start: r,
        end: i
      };
      throw new Error(`Range#create called with invalid arguments[${r}, ${i}, ${s}, ${a}]`)
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.objectLiteral(i) && ee.is(i.start) && ee.is(i.end)
    }
    t.is = n
  })(W || (W = {}));
  var It;
  (function(t) {
    function e(r, i) {
      return {
        uri: r,
        range: i
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.objectLiteral(i) && W.is(i.range) && (E.string(i.uri) || E.undefined(i.uri))
    }
    t.is = n
  })(It || (It = {}));
  var Ma;
  (function(t) {
    function e(r, i, s, a) {
      return {
        targetUri: r,
        targetRange: i,
        targetSelectionRange: s,
        originSelectionRange: a
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.objectLiteral(i) && W.is(i.targetRange) && E.string(i.targetUri) && W.is(i.targetSelectionRange) && (W.is(i.originSelectionRange) || E.undefined(i.originSelectionRange))
    }
    t.is = n
  })(Ma || (Ma = {}));
  var Dr;
  (function(t) {
    function e(r, i, s, a) {
      return {
        red: r,
        green: i,
        blue: s,
        alpha: a
      }
    }
    t.create = e;

    function n(r) {
      const i = r;
      return E.objectLiteral(i) && E.numberRange(i.red, 0, 1) && E.numberRange(i.green, 0, 1) && E.numberRange(i.blue, 0, 1) && E.numberRange(i.alpha, 0, 1)
    }
    t.is = n
  })(Dr || (Dr = {}));
  var Ta;
  (function(t) {
    function e(r, i) {
      return {
        range: r,
        color: i
      }
    }
    t.create = e;

    function n(r) {
      const i = r;
      return E.objectLiteral(i) && W.is(i.range) && Dr.is(i.color)
    }
    t.is = n
  })(Ta || (Ta = {}));
  var Pa;
  (function(t) {
    function e(r, i, s) {
      return {
        label: r,
        textEdit: i,
        additionalTextEdits: s
      }
    }
    t.create = e;

    function n(r) {
      const i = r;
      return E.objectLiteral(i) && E.string(i.label) && (E.undefined(i.textEdit) || De.is(i)) && (E.undefined(i.additionalTextEdits) || E.typedArray(i.additionalTextEdits, De.is))
    }
    t.is = n
  })(Pa || (Pa = {}));
  var rn;
  (function(t) {
    t.Comment = "comment", t.Imports = "imports", t.Region = "region"
  })(rn || (rn = {}));
  var Ca;
  (function(t) {
    function e(r, i, s, a, o, u) {
      const l = {
        startLine: r,
        endLine: i
      };
      return E.defined(s) && (l.startCharacter = s), E.defined(a) && (l.endCharacter = a), E.defined(o) && (l.kind = o), E.defined(u) && (l.collapsedText = u), l
    }
    t.create = e;

    function n(r) {
      const i = r;
      return E.objectLiteral(i) && E.uinteger(i.startLine) && E.uinteger(i.startLine) && (E.undefined(i.startCharacter) || E.uinteger(i.startCharacter)) && (E.undefined(i.endCharacter) || E.uinteger(i.endCharacter)) && (E.undefined(i.kind) || E.string(i.kind))
    }
    t.is = n
  })(Ca || (Ca = {}));
  var Or;
  (function(t) {
    function e(r, i) {
      return {
        location: r,
        message: i
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && It.is(i.location) && E.string(i.message)
    }
    t.is = n
  })(Or || (Or = {}));
  var ye;
  (function(t) {
    t.Error = 1, t.Warning = 2, t.Information = 3, t.Hint = 4
  })(ye || (ye = {}));
  var Ia;
  (function(t) {
    t.Unnecessary = 1, t.Deprecated = 2
  })(Ia || (Ia = {}));
  var Fa;
  (function(t) {
    function e(n) {
      const r = n;
      return E.objectLiteral(r) && E.string(r.href)
    }
    t.is = e
  })(Fa || (Fa = {}));
  var Ge;
  (function(t) {
    function e(r, i, s, a, o, u) {
      let l = {
        range: r,
        message: i
      };
      return E.defined(s) && (l.severity = s), E.defined(a) && (l.code = a), E.defined(o) && (l.source = o), E.defined(u) && (l.relatedInformation = u), l
    }
    t.create = e;

    function n(r) {
      var i;
      let s = r;
      return E.defined(s) && W.is(s.range) && E.string(s.message) && (E.number(s.severity) || E.undefined(s.severity)) && (E.integer(s.code) || E.string(s.code) || E.undefined(s.code)) && (E.undefined(s.codeDescription) || E.string((i = s.codeDescription) === null || i === void 0 ? void 0 : i.href)) && (E.string(s.source) || E.undefined(s.source)) && (E.undefined(s.relatedInformation) || E.typedArray(s.relatedInformation, Or.is))
    }
    t.is = n
  })(Ge || (Ge = {}));
  var Ft;
  (function(t) {
    function e(r, i, ...s) {
      let a = {
        title: r,
        command: i
      };
      return E.defined(s) && s.length > 0 && (a.arguments = s), a
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && E.string(i.title) && E.string(i.command)
    }
    t.is = n
  })(Ft || (Ft = {}));
  var De;
  (function(t) {
    function e(s, a) {
      return {
        range: s,
        newText: a
      }
    }
    t.replace = e;

    function n(s, a) {
      return {
        range: {
          start: s,
          end: s
        },
        newText: a
      }
    }
    t.insert = n;

    function r(s) {
      return {
        range: s,
        newText: ""
      }
    }
    t.del = r;

    function i(s) {
      const a = s;
      return E.objectLiteral(a) && E.string(a.newText) && W.is(a.range)
    }
    t.is = i
  })(De || (De = {}));
  var $r;
  (function(t) {
    function e(r, i, s) {
      const a = {
        label: r
      };
      return i !== void 0 && (a.needsConfirmation = i), s !== void 0 && (a.description = s), a
    }
    t.create = e;

    function n(r) {
      const i = r;
      return E.objectLiteral(i) && E.string(i.label) && (E.boolean(i.needsConfirmation) || i.needsConfirmation === void 0) && (E.string(i.description) || i.description === void 0)
    }
    t.is = n
  })($r || ($r = {}));
  var Vt;
  (function(t) {
    function e(n) {
      const r = n;
      return E.string(r)
    }
    t.is = e
  })(Vt || (Vt = {}));
  var Va;
  (function(t) {
    function e(s, a, o) {
      return {
        range: s,
        newText: a,
        annotationId: o
      }
    }
    t.replace = e;

    function n(s, a, o) {
      return {
        range: {
          start: s,
          end: s
        },
        newText: a,
        annotationId: o
      }
    }
    t.insert = n;

    function r(s, a) {
      return {
        range: s,
        newText: "",
        annotationId: a
      }
    }
    t.del = r;

    function i(s) {
      const a = s;
      return De.is(a) && ($r.is(a.annotationId) || Vt.is(a.annotationId))
    }
    t.is = i
  })(Va || (Va = {}));
  var Br;
  (function(t) {
    function e(r, i) {
      return {
        textDocument: r,
        edits: i
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && Hr.is(i.textDocument) && Array.isArray(i.edits)
    }
    t.is = n
  })(Br || (Br = {}));
  var Ur;
  (function(t) {
    function e(r, i, s) {
      let a = {
        kind: "create",
        uri: r
      };
      return i !== void 0 && (i.overwrite !== void 0 || i.ignoreIfExists !== void 0) && (a.options = i), s !== void 0 && (a.annotationId = s), a
    }
    t.create = e;

    function n(r) {
      let i = r;
      return i && i.kind === "create" && E.string(i.uri) && (i.options === void 0 || (i.options.overwrite === void 0 || E.boolean(i.options.overwrite)) && (i.options.ignoreIfExists === void 0 || E.boolean(i.options.ignoreIfExists))) && (i.annotationId === void 0 || Vt.is(i.annotationId))
    }
    t.is = n
  })(Ur || (Ur = {}));
  var qr;
  (function(t) {
    function e(r, i, s, a) {
      let o = {
        kind: "rename",
        oldUri: r,
        newUri: i
      };
      return s !== void 0 && (s.overwrite !== void 0 || s.ignoreIfExists !== void 0) && (o.options = s), a !== void 0 && (o.annotationId = a), o
    }
    t.create = e;

    function n(r) {
      let i = r;
      return i && i.kind === "rename" && E.string(i.oldUri) && E.string(i.newUri) && (i.options === void 0 || (i.options.overwrite === void 0 || E.boolean(i.options.overwrite)) && (i.options.ignoreIfExists === void 0 || E.boolean(i.options.ignoreIfExists))) && (i.annotationId === void 0 || Vt.is(i.annotationId))
    }
    t.is = n
  })(qr || (qr = {}));
  var jr;
  (function(t) {
    function e(r, i, s) {
      let a = {
        kind: "delete",
        uri: r
      };
      return i !== void 0 && (i.recursive !== void 0 || i.ignoreIfNotExists !== void 0) && (a.options = i), s !== void 0 && (a.annotationId = s), a
    }
    t.create = e;

    function n(r) {
      let i = r;
      return i && i.kind === "delete" && E.string(i.uri) && (i.options === void 0 || (i.options.recursive === void 0 || E.boolean(i.options.recursive)) && (i.options.ignoreIfNotExists === void 0 || E.boolean(i.options.ignoreIfNotExists))) && (i.annotationId === void 0 || Vt.is(i.annotationId))
    }
    t.is = n
  })(jr || (jr = {}));
  var Wr;
  (function(t) {
    function e(n) {
      let r = n;
      return r && (r.changes !== void 0 || r.documentChanges !== void 0) && (r.documentChanges === void 0 || r.documentChanges.every(i => E.string(i.kind) ? Ur.is(i) || qr.is(i) || jr.is(i) : Br.is(i)))
    }
    t.is = e
  })(Wr || (Wr = {}));
  var Da;
  (function(t) {
    function e(r) {
      return {
        uri: r
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && E.string(i.uri)
    }
    t.is = n
  })(Da || (Da = {}));
  var Oa;
  (function(t) {
    function e(r, i) {
      return {
        uri: r,
        version: i
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && E.string(i.uri) && E.integer(i.version)
    }
    t.is = n
  })(Oa || (Oa = {}));
  var Hr;
  (function(t) {
    function e(r, i) {
      return {
        uri: r,
        version: i
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && E.string(i.uri) && (i.version === null || E.integer(i.version))
    }
    t.is = n
  })(Hr || (Hr = {}));
  var $a;
  (function(t) {
    function e(r, i, s, a) {
      return {
        uri: r,
        languageId: i,
        version: s,
        text: a
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && E.string(i.uri) && E.string(i.languageId) && E.integer(i.version) && E.string(i.text)
    }
    t.is = n
  })($a || ($a = {}));
  var ut;
  (function(t) {
    t.PlainText = "plaintext", t.Markdown = "markdown";

    function e(n) {
      const r = n;
      return r === t.PlainText || r === t.Markdown
    }
    t.is = e
  })(ut || (ut = {}));
  var sn;
  (function(t) {
    function e(n) {
      const r = n;
      return E.objectLiteral(n) && ut.is(r.kind) && E.string(r.value)
    }
    t.is = e
  })(sn || (sn = {}));
  var we;
  (function(t) {
    t.Text = 1, t.Method = 2, t.Function = 3, t.Constructor = 4, t.Field = 5, t.Variable = 6, t.Class = 7, t.Interface = 8, t.Module = 9, t.Property = 10, t.Unit = 11, t.Value = 12, t.Enum = 13, t.Keyword = 14, t.Snippet = 15, t.Color = 16, t.File = 17, t.Reference = 18, t.Folder = 19, t.EnumMember = 20, t.Constant = 21, t.Struct = 22, t.Event = 23, t.Operator = 24, t.TypeParameter = 25
  })(we || (we = {}));
  var ie;
  (function(t) {
    t.PlainText = 1, t.Snippet = 2
  })(ie || (ie = {}));
  var Ba;
  (function(t) {
    t.Deprecated = 1
  })(Ba || (Ba = {}));
  var Ua;
  (function(t) {
    function e(r, i, s) {
      return {
        newText: r,
        insert: i,
        replace: s
      }
    }
    t.create = e;

    function n(r) {
      const i = r;
      return i && E.string(i.newText) && W.is(i.insert) && W.is(i.replace)
    }
    t.is = n
  })(Ua || (Ua = {}));
  var qa;
  (function(t) {
    t.asIs = 1, t.adjustIndentation = 2
  })(qa || (qa = {}));
  var ja;
  (function(t) {
    function e(n) {
      const r = n;
      return r && (E.string(r.detail) || r.detail === void 0) && (E.string(r.description) || r.description === void 0)
    }
    t.is = e
  })(ja || (ja = {}));
  var zr;
  (function(t) {
    function e(n) {
      return {
        label: n
      }
    }
    t.create = e
  })(zr || (zr = {}));
  var Wa;
  (function(t) {
    function e(n, r) {
      return {
        items: n || [],
        isIncomplete: !!r
      }
    }
    t.create = e
  })(Wa || (Wa = {}));
  var Cn;
  (function(t) {
    function e(r) {
      return r.replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&")
    }
    t.fromPlainText = e;

    function n(r) {
      const i = r;
      return E.string(i) || E.objectLiteral(i) && E.string(i.language) && E.string(i.value)
    }
    t.is = n
  })(Cn || (Cn = {}));
  var Ha;
  (function(t) {
    function e(n) {
      let r = n;
      return !!r && E.objectLiteral(r) && (sn.is(r.contents) || Cn.is(r.contents) || E.typedArray(r.contents, Cn.is)) && (n.range === void 0 || W.is(n.range))
    }
    t.is = e
  })(Ha || (Ha = {}));
  var za;
  (function(t) {
    function e(n, r) {
      return r ? {
        label: n,
        documentation: r
      } : {
        label: n
      }
    }
    t.create = e
  })(za || (za = {}));
  var Ga;
  (function(t) {
    function e(n, r, ...i) {
      let s = {
        label: n
      };
      return E.defined(r) && (s.documentation = r), E.defined(i) ? s.parameters = i : s.parameters = [], s
    }
    t.create = e
  })(Ga || (Ga = {}));
  var Ja;
  (function(t) {
    t.Text = 1, t.Read = 2, t.Write = 3
  })(Ja || (Ja = {}));
  var Xa;
  (function(t) {
    function e(n, r) {
      let i = {
        range: n
      };
      return E.number(r) && (i.kind = r), i
    }
    t.create = e
  })(Xa || (Xa = {}));
  var Oe;
  (function(t) {
    t.File = 1, t.Module = 2, t.Namespace = 3, t.Package = 4, t.Class = 5, t.Method = 6, t.Property = 7, t.Field = 8, t.Constructor = 9, t.Enum = 10, t.Interface = 11, t.Function = 12, t.Variable = 13, t.Constant = 14, t.String = 15, t.Number = 16, t.Boolean = 17, t.Array = 18, t.Object = 19, t.Key = 20, t.Null = 21, t.EnumMember = 22, t.Struct = 23, t.Event = 24, t.Operator = 25, t.TypeParameter = 26
  })(Oe || (Oe = {}));
  var Qa;
  (function(t) {
    t.Deprecated = 1
  })(Qa || (Qa = {}));
  var Za;
  (function(t) {
    function e(n, r, i, s, a) {
      let o = {
        name: n,
        kind: r,
        location: {
          uri: s,
          range: i
        }
      };
      return a && (o.containerName = a), o
    }
    t.create = e
  })(Za || (Za = {}));
  var Ya;
  (function(t) {
    function e(n, r, i, s) {
      return s !== void 0 ? {
        name: n,
        kind: r,
        location: {
          uri: i,
          range: s
        }
      } : {
        name: n,
        kind: r,
        location: {
          uri: i
        }
      }
    }
    t.create = e
  })(Ya || (Ya = {}));
  var Ka;
  (function(t) {
    function e(r, i, s, a, o, u) {
      let l = {
        name: r,
        detail: i,
        kind: s,
        range: a,
        selectionRange: o
      };
      return u !== void 0 && (l.children = u), l
    }
    t.create = e;

    function n(r) {
      let i = r;
      return i && E.string(i.name) && E.number(i.kind) && W.is(i.range) && W.is(i.selectionRange) && (i.detail === void 0 || E.string(i.detail)) && (i.deprecated === void 0 || E.boolean(i.deprecated)) && (i.children === void 0 || Array.isArray(i.children)) && (i.tags === void 0 || Array.isArray(i.tags))
    }
    t.is = n
  })(Ka || (Ka = {}));
  var eo;
  (function(t) {
    t.Empty = "", t.QuickFix = "quickfix", t.Refactor = "refactor", t.RefactorExtract = "refactor.extract", t.RefactorInline = "refactor.inline", t.RefactorRewrite = "refactor.rewrite", t.Source = "source", t.SourceOrganizeImports = "source.organizeImports", t.SourceFixAll = "source.fixAll"
  })(eo || (eo = {}));
  var In;
  (function(t) {
    t.Invoked = 1, t.Automatic = 2
  })(In || (In = {}));
  var to;
  (function(t) {
    function e(r, i, s) {
      let a = {
        diagnostics: r
      };
      return i != null && (a.only = i), s != null && (a.triggerKind = s), a
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && E.typedArray(i.diagnostics, Ge.is) && (i.only === void 0 || E.typedArray(i.only, E.string)) && (i.triggerKind === void 0 || i.triggerKind === In.Invoked || i.triggerKind === In.Automatic)
    }
    t.is = n
  })(to || (to = {}));
  var no;
  (function(t) {
    function e(r, i, s) {
      let a = {
          title: r
        },
        o = !0;
      return typeof i == "string" ? (o = !1, a.kind = i) : Ft.is(i) ? a.command = i : a.edit = i, o && s !== void 0 && (a.kind = s), a
    }
    t.create = e;

    function n(r) {
      let i = r;
      return i && E.string(i.title) && (i.diagnostics === void 0 || E.typedArray(i.diagnostics, Ge.is)) && (i.kind === void 0 || E.string(i.kind)) && (i.edit !== void 0 || i.command !== void 0) && (i.command === void 0 || Ft.is(i.command)) && (i.isPreferred === void 0 || E.boolean(i.isPreferred)) && (i.edit === void 0 || Wr.is(i.edit))
    }
    t.is = n
  })(no || (no = {}));
  var ro;
  (function(t) {
    function e(r, i) {
      let s = {
        range: r
      };
      return E.defined(i) && (s.data = i), s
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && W.is(i.range) && (E.undefined(i.command) || Ft.is(i.command))
    }
    t.is = n
  })(ro || (ro = {}));
  var io;
  (function(t) {
    function e(r, i) {
      return {
        tabSize: r,
        insertSpaces: i
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && E.uinteger(i.tabSize) && E.boolean(i.insertSpaces)
    }
    t.is = n
  })(io || (io = {}));
  var so;
  (function(t) {
    function e(r, i, s) {
      return {
        range: r,
        target: i,
        data: s
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.defined(i) && W.is(i.range) && (E.undefined(i.target) || E.string(i.target))
    }
    t.is = n
  })(so || (so = {}));
  var Fn;
  (function(t) {
    function e(r, i) {
      return {
        range: r,
        parent: i
      }
    }
    t.create = e;

    function n(r) {
      let i = r;
      return E.objectLiteral(i) && W.is(i.range) && (i.parent === void 0 || t.is(i.parent))
    }
    t.is = n
  })(Fn || (Fn = {}));
  var ao;
  (function(t) {
    t.namespace = "namespace", t.type = "type", t.class = "class", t.enum = "enum", t.interface = "interface", t.struct = "struct", t.typeParameter = "typeParameter", t.parameter = "parameter", t.variable = "variable", t.property = "property", t.enumMember = "enumMember", t.event = "event", t.function = "function", t.method = "method", t.macro = "macro", t.keyword = "keyword", t.modifier = "modifier", t.comment = "comment", t.string = "string", t.number = "number", t.regexp = "regexp", t.operator = "operator", t.decorator = "decorator"
  })(ao || (ao = {}));
  var oo;
  (function(t) {
    t.declaration = "declaration", t.definition = "definition", t.readonly = "readonly", t.static = "static", t.deprecated = "deprecated", t.abstract = "abstract", t.async = "async", t.modification = "modification", t.documentation = "documentation", t.defaultLibrary = "defaultLibrary"
  })(oo || (oo = {}));
  var lo;
  (function(t) {
    function e(n) {
      const r = n;
      return E.objectLiteral(r) && (r.resultId === void 0 || typeof r.resultId == "string") && Array.isArray(r.data) && (r.data.length === 0 || typeof r.data[0] == "number")
    }
    t.is = e
  })(lo || (lo = {}));
  var uo;
  (function(t) {
    function e(r, i) {
      return {
        range: r,
        text: i
      }
    }
    t.create = e;

    function n(r) {
      const i = r;
      return i != null && W.is(i.range) && E.string(i.text)
    }
    t.is = n
  })(uo || (uo = {}));
  var co;
  (function(t) {
    function e(r, i, s) {
      return {
        range: r,
        variableName: i,
        caseSensitiveLookup: s
      }
    }
    t.create = e;

    function n(r) {
      const i = r;
      return i != null && W.is(i.range) && E.boolean(i.caseSensitiveLookup) && (E.string(i.variableName) || i.variableName === void 0)
    }
    t.is = n
  })(co || (co = {}));
  var fo;
  (function(t) {
    function e(r, i) {
      return {
        range: r,
        expression: i
      }
    }
    t.create = e;

    function n(r) {
      const i = r;
      return i != null && W.is(i.range) && (E.string(i.expression) || i.expression === void 0)
    }
    t.is = n
  })(fo || (fo = {}));
  var ho;
  (function(t) {
    function e(r, i) {
      return {
        frameId: r,
        stoppedLocation: i
      }
    }
    t.create = e;

    function n(r) {
      const i = r;
      return E.defined(i) && W.is(r.stoppedLocation)
    }
    t.is = n
  })(ho || (ho = {}));
  var Gr;
  (function(t) {
    t.Type = 1, t.Parameter = 2;

    function e(n) {
      return n === 1 || n === 2
    }
    t.is = e
  })(Gr || (Gr = {}));
  var Jr;
  (function(t) {
    function e(r) {
      return {
        value: r
      }
    }
    t.create = e;

    function n(r) {
      const i = r;
      return E.objectLiteral(i) && (i.tooltip === void 0 || E.string(i.tooltip) || sn.is(i.tooltip)) && (i.location === void 0 || It.is(i.location)) && (i.command === void 0 || Ft.is(i.command))
    }
    t.is = n
  })(Jr || (Jr = {}));
  var mo;
  (function(t) {
    function e(r, i, s) {
      const a = {
        position: r,
        label: i
      };
      return s !== void 0 && (a.kind = s), a
    }
    t.create = e;

    function n(r) {
      const i = r;
      return E.objectLiteral(i) && ee.is(i.position) && (E.string(i.label) || E.typedArray(i.label, Jr.is)) && (i.kind === void 0 || Gr.is(i.kind)) && i.textEdits === void 0 || E.typedArray(i.textEdits, De.is) && (i.tooltip === void 0 || E.string(i.tooltip) || sn.is(i.tooltip)) && (i.paddingLeft === void 0 || E.boolean(i.paddingLeft)) && (i.paddingRight === void 0 || E.boolean(i.paddingRight))
    }
    t.is = n
  })(mo || (mo = {}));
  var go;
  (function(t) {
    function e(n) {
      return {
        kind: "snippet",
        value: n
      }
    }
    t.createSnippet = e
  })(go || (go = {}));
  var po;
  (function(t) {
    function e(n, r, i, s) {
      return {
        insertText: n,
        filterText: r,
        range: i,
        command: s
      }
    }
    t.create = e
  })(po || (po = {}));
  var bo;
  (function(t) {
    function e(n) {
      return {
        items: n
      }
    }
    t.create = e
  })(bo || (bo = {}));
  var yo;
  (function(t) {
    t.Invoked = 0, t.Automatic = 1
  })(yo || (yo = {}));
  var wo;
  (function(t) {
    function e(n, r) {
      return {
        range: n,
        text: r
      }
    }
    t.create = e
  })(wo || (wo = {}));
  var xo;
  (function(t) {
    function e(n, r) {
      return {
        triggerKind: n,
        selectedCompletionInfo: r
      }
    }
    t.create = e
  })(xo || (xo = {}));
  var vo;
  (function(t) {
    function e(n) {
      const r = n;
      return E.objectLiteral(r) && Vr.is(r.uri) && E.string(r.name)
    }
    t.is = e
  })(vo || (vo = {}));
  var Lo;
  (function(t) {
    function e(s, a, o, u) {
      return new zc(s, a, o, u)
    }
    t.create = e;

    function n(s) {
      let a = s;
      return !!(E.defined(a) && E.string(a.uri) && (E.undefined(a.languageId) || E.string(a.languageId)) && E.uinteger(a.lineCount) && E.func(a.getText) && E.func(a.positionAt) && E.func(a.offsetAt))
    }
    t.is = n;

    function r(s, a) {
      let o = s.getText(),
        u = i(a, (h, f) => {
          let m = h.range.start.line - f.range.start.line;
          return m === 0 ? h.range.start.character - f.range.start.character : m
        }),
        l = o.length;
      for (let h = u.length - 1; h >= 0; h--) {
        let f = u[h],
          m = s.offsetAt(f.range.start),
          g = s.offsetAt(f.range.end);
        if (g <= l) o = o.substring(0, m) + f.newText + o.substring(g, o.length);
        else throw new Error("Overlapping edit");
        l = m
      }
      return o
    }
    t.applyEdits = r;

    function i(s, a) {
      if (s.length <= 1) return s;
      const o = s.length / 2 | 0,
        u = s.slice(0, o),
        l = s.slice(o);
      i(u, a), i(l, a);
      let h = 0,
        f = 0,
        m = 0;
      for (; h < u.length && f < l.length;) a(u[h], l[f]) <= 0 ? s[m++] = u[h++] : s[m++] = l[f++];
      for (; h < u.length;) s[m++] = u[h++];
      for (; f < l.length;) s[m++] = l[f++];
      return s
    }
  })(Lo || (Lo = {}));
  let zc = class {
    constructor(e, n, r, i) {
      this._uri = e, this._languageId = n, this._version = r, this._content = i, this._lineOffsets = void 0
    }
    get uri() {
      return this._uri
    }
    get languageId() {
      return this._languageId
    }
    get version() {
      return this._version
    }
    getText(e) {
      if (e) {
        let n = this.offsetAt(e.start),
          r = this.offsetAt(e.end);
        return this._content.substring(n, r)
      }
      return this._content
    }
    update(e, n) {
      this._content = e.text, this._version = n, this._lineOffsets = void 0
    }
    getLineOffsets() {
      if (this._lineOffsets === void 0) {
        let e = [],
          n = this._content,
          r = !0;
        for (let i = 0; i < n.length; i++) {
          r && (e.push(i), r = !1);
          let s = n.charAt(i);
          r = s === "\r" || s === `
`, s === "\r" && i + 1 < n.length && n.charAt(i + 1) === `
` && i++
        }
        r && n.length > 0 && e.push(n.length), this._lineOffsets = e
      }
      return this._lineOffsets
    }
    positionAt(e) {
      e = Math.max(Math.min(e, this._content.length), 0);
      let n = this.getLineOffsets(),
        r = 0,
        i = n.length;
      if (i === 0) return ee.create(0, e);
      for (; r < i;) {
        let a = Math.floor((r + i) / 2);
        n[a] > e ? i = a : r = a + 1
      }
      let s = r - 1;
      return ee.create(s, e - n[s])
    }
    offsetAt(e) {
      let n = this.getLineOffsets();
      if (e.line >= n.length) return this._content.length;
      if (e.line < 0) return 0;
      let r = n[e.line],
        i = e.line + 1 < n.length ? n[e.line + 1] : this._content.length;
      return Math.max(Math.min(r + e.character, i), r)
    }
    get lineCount() {
      return this.getLineOffsets().length
    }
  };
  var E;
  (function(t) {
    const e = Object.prototype.toString;

    function n(g) {
      return typeof g < "u"
    }
    t.defined = n;

    function r(g) {
      return typeof g > "u"
    }
    t.undefined = r;

    function i(g) {
      return g === !0 || g === !1
    }
    t.boolean = i;

    function s(g) {
      return e.call(g) === "[object String]"
    }
    t.string = s;

    function a(g) {
      return e.call(g) === "[object Number]"
    }
    t.number = a;

    function o(g, d, p) {
      return e.call(g) === "[object Number]" && d <= g && g <= p
    }
    t.numberRange = o;

    function u(g) {
      return e.call(g) === "[object Number]" && -2147483648 <= g && g <= 2147483647
    }
    t.integer = u;

    function l(g) {
      return e.call(g) === "[object Number]" && 0 <= g && g <= 2147483647
    }
    t.uinteger = l;

    function h(g) {
      return e.call(g) === "[object Function]"
    }
    t.func = h;

    function f(g) {
      return g !== null && typeof g == "object"
    }
    t.objectLiteral = f;

    function m(g, d) {
      return Array.isArray(g) && g.every(d)
    }
    t.typedArray = m
  })(E || (E = {}));
  class an {
    constructor(e, n, r, i) {
      this._uri = e, this._languageId = n, this._version = r, this._content = i, this._lineOffsets = void 0
    }
    get uri() {
      return this._uri
    }
    get languageId() {
      return this._languageId
    }
    get version() {
      return this._version
    }
    getText(e) {
      if (e) {
        const n = this.offsetAt(e.start),
          r = this.offsetAt(e.end);
        return this._content.substring(n, r)
      }
      return this._content
    }
    update(e, n) {
      for (let r of e)
        if (an.isIncremental(r)) {
          const i = _o(r.range),
            s = this.offsetAt(i.start),
            a = this.offsetAt(i.end);
          this._content = this._content.substring(0, s) + r.text + this._content.substring(a, this._content.length);
          const o = Math.max(i.start.line, 0),
            u = Math.max(i.end.line, 0);
          let l = this._lineOffsets;
          const h = No(r.text, !1, s);
          if (u - o === h.length)
            for (let m = 0, g = h.length; m < g; m++) l[m + o + 1] = h[m];
          else h.length < 1e4 ? l.splice(o + 1, u - o, ...h) : this._lineOffsets = l = l.slice(0, o + 1).concat(h, l.slice(u + 1));
          const f = r.text.length - (a - s);
          if (f !== 0)
            for (let m = o + 1 + h.length, g = l.length; m < g; m++) l[m] = l[m] + f
        } else if (an.isFull(r)) this._content = r.text, this._lineOffsets = void 0;
      else throw new Error("Unknown change event received");
      this._version = n
    }
    getLineOffsets() {
      return this._lineOffsets === void 0 && (this._lineOffsets = No(this._content, !0)), this._lineOffsets
    }
    positionAt(e) {
      e = Math.max(Math.min(e, this._content.length), 0);
      let n = this.getLineOffsets(),
        r = 0,
        i = n.length;
      if (i === 0) return {
        line: 0,
        character: e
      };
      for (; r < i;) {
        let a = Math.floor((r + i) / 2);
        n[a] > e ? i = a : r = a + 1
      }
      let s = r - 1;
      return {
        line: s,
        character: e - n[s]
      }
    }
    offsetAt(e) {
      let n = this.getLineOffsets();
      if (e.line >= n.length) return this._content.length;
      if (e.line < 0) return 0;
      let r = n[e.line],
        i = e.line + 1 < n.length ? n[e.line + 1] : this._content.length;
      return Math.max(Math.min(r + e.character, i), r)
    }
    get lineCount() {
      return this.getLineOffsets().length
    }
    static isIncremental(e) {
      let n = e;
      return n != null && typeof n.text == "string" && n.range !== void 0 && (n.rangeLength === void 0 || typeof n.rangeLength == "number")
    }
    static isFull(e) {
      let n = e;
      return n != null && typeof n.text == "string" && n.range === void 0 && n.rangeLength === void 0
    }
  }
  var Me;
  (function(t) {
    function e(i, s, a, o) {
      return new an(i, s, a, o)
    }
    t.create = e;

    function n(i, s, a) {
      if (i instanceof an) return i.update(s, a), i;
      throw new Error("TextDocument.update: document must be created by TextDocument.create")
    }
    t.update = n;

    function r(i, s) {
      let a = i.getText(),
        o = Xr(s.map(Gc), (h, f) => {
          let m = h.range.start.line - f.range.start.line;
          return m === 0 ? h.range.start.character - f.range.start.character : m
        }),
        u = 0;
      const l = [];
      for (const h of o) {
        let f = i.offsetAt(h.range.start);
        if (f < u) throw new Error("Overlapping edit");
        f > u && l.push(a.substring(u, f)), h.newText.length && l.push(h.newText), u = i.offsetAt(h.range.end)
      }
      return l.push(a.substr(u)), l.join("")
    }
    t.applyEdits = r
  })(Me || (Me = {}));

  function Xr(t, e) {
    if (t.length <= 1) return t;
    const n = t.length / 2 | 0,
      r = t.slice(0, n),
      i = t.slice(n);
    Xr(r, e), Xr(i, e);
    let s = 0,
      a = 0,
      o = 0;
    for (; s < r.length && a < i.length;) e(r[s], i[a]) <= 0 ? t[o++] = r[s++] : t[o++] = i[a++];
    for (; s < r.length;) t[o++] = r[s++];
    for (; a < i.length;) t[o++] = i[a++];
    return t
  }

  function No(t, e, n = 0) {
    const r = e ? [n] : [];
    for (let i = 0; i < t.length; i++) {
      let s = t.charCodeAt(i);
      (s === 13 || s === 10) && (s === 13 && i + 1 < t.length && t.charCodeAt(i + 1) === 10 && i++, r.push(n + i + 1))
    }
    return r
  }

  function _o(t) {
    const e = t.start,
      n = t.end;
    return e.line > n.line || e.line === n.line && e.character > n.character ? {
      start: n,
      end: e
    } : t
  }

  function Gc(t) {
    const e = _o(t.range);
    return e !== t.range ? {
      newText: t.newText,
      range: e
    } : t
  }
  var G;
  (function(t) {
    t[t.Undefined = 0] = "Undefined", t[t.EnumValueMismatch = 1] = "EnumValueMismatch", t[t.Deprecated = 2] = "Deprecated", t[t.UnexpectedEndOfComment = 257] = "UnexpectedEndOfComment", t[t.UnexpectedEndOfString = 258] = "UnexpectedEndOfString", t[t.UnexpectedEndOfNumber = 259] = "UnexpectedEndOfNumber", t[t.InvalidUnicode = 260] = "InvalidUnicode", t[t.InvalidEscapeCharacter = 261] = "InvalidEscapeCharacter", t[t.InvalidCharacter = 262] = "InvalidCharacter", t[t.PropertyExpected = 513] = "PropertyExpected", t[t.CommaExpected = 514] = "CommaExpected", t[t.ColonExpected = 515] = "ColonExpected", t[t.ValueExpected = 516] = "ValueExpected", t[t.CommaOrCloseBacketExpected = 517] = "CommaOrCloseBacketExpected", t[t.CommaOrCloseBraceExpected = 518] = "CommaOrCloseBraceExpected", t[t.TrailingComma = 519] = "TrailingComma", t[t.DuplicateKey = 520] = "DuplicateKey", t[t.CommentNotPermitted = 521] = "CommentNotPermitted", t[t.PropertyKeysMustBeDoublequoted = 528] = "PropertyKeysMustBeDoublequoted", t[t.SchemaResolveError = 768] = "SchemaResolveError", t[t.SchemaUnsupportedFeature = 769] = "SchemaUnsupportedFeature"
  })(G || (G = {}));
  var Te;
  (function(t) {
    t[t.v3 = 3] = "v3", t[t.v4 = 4] = "v4", t[t.v6 = 6] = "v6", t[t.v7 = 7] = "v7", t[t.v2019_09 = 19] = "v2019_09", t[t.v2020_12 = 20] = "v2020_12"
  })(Te || (Te = {}));
  var Qr;
  (function(t) {
    t.LATEST = {
      textDocument: {
        completion: {
          completionItem: {
            documentationFormat: [ut.Markdown, ut.PlainText],
            commitCharactersSupport: !0,
            labelDetailsSupport: !0
          }
        }
      }
    }
  })(Qr || (Qr = {}));

  function P(...t) {
    const e = t[0];
    let n, r, i;
    if (typeof e == "string") n = e, r = e, t.splice(0, 1), i = !t || typeof t[0] != "object" ? t : t[0];
    else if (e instanceof Array) {
      const s = t.slice(1);
      if (e.length !== s.length + 1) throw new Error("expected a string as the first argument to l10n.t");
      let a = e[0];
      for (let o = 1; o < e.length; o++) a += `{${o-1}}` + e[o];
      return P(a, ...s)
    } else r = e.message, n = r, e.comment && e.comment.length > 0 && (n += `/${Array.isArray(e.comment)?e.comment.join(""):e.comment}`), i = e.args ?? {};
    return Xc(r, i)
  }
  var Jc = /{([^}]+)}/g;

  function Xc(t, e) {
    return Object.keys(e).length === 0 ? t : t.replace(Jc, (n, r) => e[r] ?? n)
  }
  const Qc = {
    "color-hex": {
      errorMessage: P("Invalid color format. Use #RGB, #RGBA, #RRGGBB or #RRGGBBAA."),
      pattern: /^#([0-9A-Fa-f]{3,4}|([0-9A-Fa-f]{2}){3,4})$/
    },
    "date-time": {
      errorMessage: P("String is not a RFC3339 date-time."),
      pattern: /^(\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])T([01][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9]|60)(\.[0-9]+)?(Z|(\+|-)([01][0-9]|2[0-3]):([0-5][0-9]))$/i
    },
    date: {
      errorMessage: P("String is not a RFC3339 date."),
      pattern: /^(\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/i
    },
    time: {
      errorMessage: P("String is not a RFC3339 time."),
      pattern: /^([01][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9]|60)(\.[0-9]+)?(Z|(\+|-)([01][0-9]|2[0-3]):([0-5][0-9]))$/i
    },
    email: {
      errorMessage: P("String is not an e-mail address."),
      pattern: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}))$/
    },
    hostname: {
      errorMessage: P("String is not a hostname."),
      pattern: /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i
    },
    ipv4: {
      errorMessage: P("String is not an IPv4 address."),
      pattern: /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/
    },
    ipv6: {
      errorMessage: P("String is not an IPv6 address."),
      pattern: /^((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))$/i
    }
  };
  class ct {
    constructor(e, n, r = 0) {
      this.offset = n, this.length = r, this.parent = e
    }
    get children() {
      return []
    }
    toString() {
      return "type: " + this.type + " (" + this.offset + "/" + this.length + ")" + (this.parent ? " parent: {" + this.parent.toString() + "}" : "")
    }
  }
  class Zc extends ct {
    constructor(e, n) {
      super(e, n), this.type = "null", this.value = null
    }
  }
  class So extends ct {
    constructor(e, n, r) {
      super(e, r), this.type = "boolean", this.value = n
    }
  }
  class Yc extends ct {
    constructor(e, n) {
      super(e, n), this.type = "array", this.items = []
    }
    get children() {
      return this.items
    }
  }
  class Kc extends ct {
    constructor(e, n) {
      super(e, n), this.type = "number", this.isInteger = !0, this.value = Number.NaN
    }
  }
  class Zr extends ct {
    constructor(e, n, r) {
      super(e, n, r), this.type = "string", this.value = ""
    }
  }
  class e1 extends ct {
    constructor(e, n, r) {
      super(e, n), this.type = "property", this.colonOffset = -1, this.keyNode = r
    }
    get children() {
      return this.valueNode ? [this.keyNode, this.valueNode] : [this.keyNode]
    }
  }
  class t1 extends ct {
    constructor(e, n) {
      super(e, n), this.type = "object", this.properties = []
    }
    get children() {
      return this.properties
    }
  }

  function xe(t) {
    return Ve(t) ? t ? {} : {
      not: {}
    } : t
  }
  var Ao;
  (function(t) {
    t[t.Key = 0] = "Key", t[t.Enum = 1] = "Enum"
  })(Ao || (Ao = {}));
  const n1 = {
    "http://json-schema.org/draft-03/schema#": Te.v3,
    "http://json-schema.org/draft-04/schema#": Te.v4,
    "http://json-schema.org/draft-06/schema#": Te.v6,
    "http://json-schema.org/draft-07/schema#": Te.v7,
    "https://json-schema.org/draft/2019-09/schema": Te.v2019_09,
    "https://json-schema.org/draft/2020-12/schema": Te.v2020_12
  };
  class ko {
    constructor(e) {
      this.schemaDraft = e
    }
  }
  class Yr {
    constructor(e = -1, n) {
      this.focusOffset = e, this.exclude = n, this.schemas = []
    }
    add(e) {
      this.schemas.push(e)
    }
    merge(e) {
      Array.prototype.push.apply(this.schemas, e.schemas)
    }
    include(e) {
      return (this.focusOffset === -1 || Ro(e, this.focusOffset)) && e !== this.exclude
    }
    newSub() {
      return new Yr(-1, this.exclude)
    }
  }
  class on {
    constructor() {}
    get schemas() {
      return []
    }
    add(e) {}
    merge(e) {}
    include(e) {
      return !0
    }
    newSub() {
      return this
    }
  }
  on.instance = new on;
  class fe {
    constructor() {
      this.problems = [], this.propertiesMatches = 0, this.processedProperties = new Set, this.propertiesValueMatches = 0, this.primaryValueMatches = 0, this.enumValueMatch = !1, this.enumValues = void 0
    }
    hasProblems() {
      return !!this.problems.length
    }
    merge(e) {
      this.problems = this.problems.concat(e.problems), this.propertiesMatches += e.propertiesMatches, this.propertiesValueMatches += e.propertiesValueMatches, this.mergeProcessedProperties(e)
    }
    mergeEnumValues(e) {
      if (!this.enumValueMatch && !e.enumValueMatch && this.enumValues && e.enumValues) {
        this.enumValues = this.enumValues.concat(e.enumValues);
        for (const n of this.problems) n.code === G.EnumValueMismatch && (n.message = P("Value is not accepted. Valid values: {0}.", this.enumValues.map(r => JSON.stringify(r)).join(", ")))
      }
    }
    mergePropertyMatch(e) {
      this.problems = this.problems.concat(e.problems), this.propertiesMatches++, (e.enumValueMatch || !e.hasProblems() && e.propertiesMatches) && this.propertiesValueMatches++, e.enumValueMatch && e.enumValues && e.enumValues.length === 1 && this.primaryValueMatches++
    }
    mergeProcessedProperties(e) {
      e.processedProperties.forEach(n => this.processedProperties.add(n))
    }
    compare(e) {
      const n = this.hasProblems();
      return n !== e.hasProblems() ? n ? -1 : 1 : this.enumValueMatch !== e.enumValueMatch ? e.enumValueMatch ? -1 : 1 : this.primaryValueMatches !== e.primaryValueMatches ? this.primaryValueMatches - e.primaryValueMatches : this.propertiesValueMatches !== e.propertiesValueMatches ? this.propertiesValueMatches - e.propertiesValueMatches : this.propertiesMatches - e.propertiesMatches
    }
  }

  function r1(t, e = []) {
    return new Eo(t, e, [])
  }

  function ft(t) {
    return jc(t)
  }

  function Kr(t) {
    return qc(t)
  }

  function Ro(t, e, n = !1) {
    return e >= t.offset && e < t.offset + t.length || n && e === t.offset + t.length
  }
  class Eo {
    constructor(e, n = [], r = []) {
      this.root = e, this.syntaxErrors = n, this.comments = r
    }
    getNodeFromOffset(e, n = !1) {
      if (this.root) return Uc(this.root, e, n)
    }
    visit(e) {
      if (this.root) {
        const n = r => {
          let i = e(r);
          const s = r.children;
          if (Array.isArray(s))
            for (let a = 0; a < s.length && i; a++) i = n(s[a]);
          return i
        };
        n(this.root)
      }
    }
    validate(e, n, r = ye.Warning, i) {
      if (this.root && n) {
        const s = new fe;
        return le(this.root, n, s, on.instance, new ko(i ?? Mo(n))), s.problems.map(a => {
          const o = W.create(e.positionAt(a.location.offset), e.positionAt(a.location.offset + a.location.length));
          return Ge.create(o, a.message, a.severity ?? r, a.code)
        })
      }
    }
    getMatchingSchemas(e, n = -1, r) {
      if (this.root && e) {
        const i = new Yr(n, r),
          s = Mo(e),
          a = new ko(s);
        return le(this.root, e, new fe, i, a), i.schemas
      }
      return []
    }
  }

  function Mo(t, e = Te.v2020_12) {
    let n = t.$schema;
    return n ? n1[n] ?? e : e
  }

  function le(t, e, n, r, i) {
    if (!t || !r.include(t)) return;
    if (t.type === "property") return le(t.valueNode, e, n, r, i);
    const s = t;
    switch (a(), s.type) {
      case "object":
        h(s);
        break;
      case "array":
        l(s);
        break;
      case "string":
        u(s);
        break;
      case "number":
        o(s);
        break
    }
    r.add({
      node: s,
      schema: e
    });

    function a() {
      var N;

      function f(b) {
        return s.type === b || b === "integer" && s.type === "number" && s.isInteger
      }
      if (Array.isArray(e.type) ? e.type.some(f) || n.problems.push({
          location: {
            offset: s.offset,
            length: s.length
          },
          message: e.errorMessage || P("Incorrect type. Expected one of {0}.", e.type.join(", "))
        }) : e.type && (f(e.type) || n.problems.push({
          location: {
            offset: s.offset,
            length: s.length
          },
          message: e.errorMessage || P('Incorrect type. Expected "{0}".', e.type)
        })), Array.isArray(e.allOf))
        for (const b of e.allOf) {
          const _ = new fe,
            L = r.newSub();
          le(s, xe(b), _, L, i), n.merge(_), r.merge(L)
        }
      const m = xe(e.not);
      if (m) {
        const b = new fe,
          _ = r.newSub();
        le(s, m, b, _, i), b.hasProblems() || n.problems.push({
          location: {
            offset: s.offset,
            length: s.length
          },
          message: e.errorMessage || P("Matches a schema that is not allowed.")
        });
        for (const L of _.schemas) L.inverted = !L.inverted, r.add(L)
      }
      const g = (b, _) => {
        const L = [];
        let A;
        for (const v of b) {
          const k = xe(v),
            M = new fe,
            V = r.newSub();
          if (le(s, k, M, V, i), M.hasProblems() || L.push(k), !A) A = {
            schema: k,
            validationResult: M,
            matchingSchemas: V
          };
          else if (!_ && !M.hasProblems() && !A.validationResult.hasProblems()) A.matchingSchemas.merge(V), A.validationResult.propertiesMatches += M.propertiesMatches, A.validationResult.propertiesValueMatches += M.propertiesValueMatches, A.validationResult.mergeProcessedProperties(M);
          else {
            const T = M.compare(A.validationResult);
            T > 0 ? A = {
              schema: k,
              validationResult: M,
              matchingSchemas: V
            } : T === 0 && (A.matchingSchemas.merge(V), A.validationResult.mergeEnumValues(M))
          }
        }
        return L.length > 1 && _ && n.problems.push({
          location: {
            offset: s.offset,
            length: 1
          },
          message: P("Matches multiple schemas when only one must validate.")
        }), A && (n.merge(A.validationResult), r.merge(A.matchingSchemas)), L.length
      };
      Array.isArray(e.anyOf) && g(e.anyOf, !1), Array.isArray(e.oneOf) && g(e.oneOf, !0);
      const d = b => {
          const _ = new fe,
            L = r.newSub();
          le(s, xe(b), _, L, i), n.merge(_), r.merge(L)
        },
        p = (b, _, L) => {
          const A = xe(b),
            v = new fe,
            k = r.newSub();
          le(s, A, v, k, i), r.merge(k), n.mergeProcessedProperties(v), v.hasProblems() ? L && d(L) : _ && d(_)
        },
        y = xe(e.if);
      if (y && p(y, xe(e.then), xe(e.else)), Array.isArray(e.enum)) {
        const b = ft(s);
        let _ = !1;
        for (const L of e.enum)
          if (Ct(b, L)) {
            _ = !0;
            break
          } n.enumValues = e.enum, n.enumValueMatch = _, _ || n.problems.push({
          location: {
            offset: s.offset,
            length: s.length
          },
          code: G.EnumValueMismatch,
          message: e.errorMessage || P("Value is not accepted. Valid values: {0}.", e.enum.map(L => JSON.stringify(L)).join(", "))
        })
      }
      if (Ee(e.const)) {
        const b = ft(s);
        Ct(b, e.const) ? n.enumValueMatch = !0 : (n.problems.push({
          location: {
            offset: s.offset,
            length: s.length
          },
          code: G.EnumValueMismatch,
          message: e.errorMessage || P("Value must be {0}.", JSON.stringify(e.const))
        }), n.enumValueMatch = !1), n.enumValues = [e.const]
      }
      let w = e.deprecationMessage;
      if (w || e.deprecated) {
        w = w || P("Value is deprecated");
        let b = ((N = s.parent) == null ? void 0 : N.type) === "property" ? s.parent : s;
        n.problems.push({
          location: {
            offset: b.offset,
            length: b.length
          },
          severity: ye.Warning,
          message: w,
          code: G.Deprecated
        })
      }
    }

    function o(f) {
      const m = f.value;

      function g(_) {
        var A;
        const L = /^(-?\d+)(?:\.(\d+))?(?:e([-+]\d+))?$/.exec(_.toString());
        return L && {
          value: Number(L[1] + (L[2] || "")),
          multiplier: (((A = L[2]) == null ? void 0 : A.length) || 0) - (parseInt(L[3]) || 0)
        }
      }
      if (ce(e.multipleOf)) {
        let _ = -1;
        if (Number.isInteger(e.multipleOf)) _ = m % e.multipleOf;
        else {
          let L = g(e.multipleOf),
            A = g(m);
          if (L && A) {
            const v = 10 ** Math.abs(A.multiplier - L.multiplier);
            A.multiplier < L.multiplier ? A.value *= v : L.value *= v, _ = A.value % L.value
          }
        }
        _ !== 0 && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: P("Value is not divisible by {0}.", e.multipleOf)
        })
      }

      function d(_, L) {
        if (ce(L)) return L;
        if (Ve(L) && L) return _
      }

      function p(_, L) {
        if (!Ve(L) || !L) return _
      }
      const y = d(e.minimum, e.exclusiveMinimum);
      ce(y) && m <= y && n.problems.push({
        location: {
          offset: f.offset,
          length: f.length
        },
        message: P("Value is below the exclusive minimum of {0}.", y)
      });
      const w = d(e.maximum, e.exclusiveMaximum);
      ce(w) && m >= w && n.problems.push({
        location: {
          offset: f.offset,
          length: f.length
        },
        message: P("Value is above the exclusive maximum of {0}.", w)
      });
      const N = p(e.minimum, e.exclusiveMinimum);
      ce(N) && m < N && n.problems.push({
        location: {
          offset: f.offset,
          length: f.length
        },
        message: P("Value is below the minimum of {0}.", N)
      });
      const b = p(e.maximum, e.exclusiveMaximum);
      ce(b) && m > b && n.problems.push({
        location: {
          offset: f.offset,
          length: f.length
        },
        message: P("Value is above the maximum of {0}.", b)
      })
    }

    function u(f) {
      if (ce(e.minLength) && ka(f.value) < e.minLength && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: P("String is shorter than the minimum length of {0}.", e.minLength)
        }), ce(e.maxLength) && ka(f.value) > e.maxLength && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: P("String is longer than the maximum length of {0}.", e.maxLength)
        }), Aa(e.pattern)) {
        const m = Tn(e.pattern);
        m != null && m.test(f.value) || n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: e.patternErrorMessage || e.errorMessage || P('String does not match the pattern of "{0}".', e.pattern)
        })
      }
      if (e.format) switch (e.format) {
        case "uri":
        case "uri-reference": {
          let g;
          if (!f.value) g = P("URI expected.");
          else {
            const d = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/.exec(f.value);
            d ? !d[2] && e.format === "uri" && (g = P("URI with a scheme is expected.")) : g = P("URI is expected.")
          }
          g && n.problems.push({
            location: {
              offset: f.offset,
              length: f.length
            },
            message: e.patternErrorMessage || e.errorMessage || P("String is not a URI: {0}", g)
          })
        }
        break;
        case "color-hex":
        case "date-time":
        case "date":
        case "time":
        case "email":
        case "hostname":
        case "ipv4":
        case "ipv6":
          const m = Qc[e.format];
          (!f.value || !m.pattern.exec(f.value)) && n.problems.push({
            location: {
              offset: f.offset,
              length: f.length
            },
            message: e.patternErrorMessage || e.errorMessage || m.errorMessage
          })
      }
    }

    function l(f) {
      let m, g;
      i.schemaDraft >= Te.v2020_12 ? (m = e.prefixItems, g = Array.isArray(e.items) ? void 0 : e.items) : (m = Array.isArray(e.items) ? e.items : void 0, g = Array.isArray(e.items) ? e.additionalItems : e.items);
      let d = 0;
      if (m !== void 0) {
        const w = Math.min(m.length, f.items.length);
        for (; d < w; d++) {
          const N = m[d],
            b = xe(N),
            _ = new fe,
            L = f.items[d];
          L && (le(L, b, _, r, i), n.mergePropertyMatch(_)), n.processedProperties.add(String(d))
        }
      }
      if (g !== void 0 && d < f.items.length)
        if (typeof g == "boolean")
          for (g === !1 && n.problems.push({
              location: {
                offset: f.offset,
                length: f.length
              },
              message: P("Array has too many items according to schema. Expected {0} or fewer.", d)
            }); d < f.items.length; d++) n.processedProperties.add(String(d)), n.propertiesValueMatches++;
        else
          for (; d < f.items.length; d++) {
            const w = new fe;
            le(f.items[d], g, w, r, i), n.mergePropertyMatch(w), n.processedProperties.add(String(d))
          }
      const p = xe(e.contains);
      if (p) {
        let w = 0;
        for (let N = 0; N < f.items.length; N++) {
          const b = f.items[N],
            _ = new fe;
          le(b, p, _, on.instance, i), _.hasProblems() || (w++, i.schemaDraft >= Te.v2020_12 && n.processedProperties.add(String(N)))
        }
        w === 0 && !ce(e.minContains) && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: e.errorMessage || P("Array does not contain required item.")
        }), ce(e.minContains) && w < e.minContains && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: e.errorMessage || P("Array has too few items that match the contains contraint. Expected {0} or more.", e.minContains)
        }), ce(e.maxContains) && w > e.maxContains && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: e.errorMessage || P("Array has too many items that match the contains contraint. Expected {0} or less.", e.maxContains)
        })
      }
      const y = e.unevaluatedItems;
      if (y !== void 0)
        for (let w = 0; w < f.items.length; w++) {
          if (!n.processedProperties.has(String(w)))
            if (y === !1) n.problems.push({
              location: {
                offset: f.offset,
                length: f.length
              },
              message: P("Item does not match any validation rule from the array.")
            });
            else {
              const N = new fe;
              le(f.items[w], e.unevaluatedItems, N, r, i), n.mergePropertyMatch(N)
            } n.processedProperties.add(String(w)), n.propertiesValueMatches++
        }
      if (ce(e.minItems) && f.items.length < e.minItems && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: P("Array has too few items. Expected {0} or more.", e.minItems)
        }), ce(e.maxItems) && f.items.length > e.maxItems && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: P("Array has too many items. Expected {0} or fewer.", e.maxItems)
        }), e.uniqueItems === !0) {
        let N = function() {
          for (let b = 0; b < w.length - 1; b++) {
            const _ = w[b];
            for (let L = b + 1; L < w.length; L++)
              if (Ct(_, w[L])) return !0
          }
          return !1
        };
        const w = ft(f);
        N() && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: P("Array has duplicate items.")
        })
      }
    }

    function h(f) {
      const m = Object.create(null),
        g = new Set;
      for (const b of f.properties) {
        const _ = b.keyNode.value;
        m[_] = b.valueNode, g.add(_)
      }
      if (Array.isArray(e.required)) {
        for (const b of e.required)
          if (!m[b]) {
            const _ = f.parent && f.parent.type === "property" && f.parent.keyNode,
              L = _ ? {
                offset: _.offset,
                length: _.length
              } : {
                offset: f.offset,
                length: 1
              };
            n.problems.push({
              location: L,
              message: P('Missing property "{0}".', b)
            })
          }
      }
      const d = b => {
        g.delete(b), n.processedProperties.add(b)
      };
      if (e.properties)
        for (const b of Object.keys(e.properties)) {
          d(b);
          const _ = e.properties[b],
            L = m[b];
          if (L)
            if (Ve(_))
              if (_) n.propertiesMatches++, n.propertiesValueMatches++;
              else {
                const A = L.parent;
                n.problems.push({
                  location: {
                    offset: A.keyNode.offset,
                    length: A.keyNode.length
                  },
                  message: e.errorMessage || P("Property {0} is not allowed.", b)
                })
              }
          else {
            const A = new fe;
            le(L, _, A, r, i), n.mergePropertyMatch(A)
          }
        }
      if (e.patternProperties)
        for (const b of Object.keys(e.patternProperties)) {
          const _ = Tn(b);
          if (_) {
            const L = [];
            for (const A of g)
              if (_.test(A)) {
                L.push(A);
                const v = m[A];
                if (v) {
                  const k = e.patternProperties[b];
                  if (Ve(k))
                    if (k) n.propertiesMatches++, n.propertiesValueMatches++;
                    else {
                      const M = v.parent;
                      n.problems.push({
                        location: {
                          offset: M.keyNode.offset,
                          length: M.keyNode.length
                        },
                        message: e.errorMessage || P("Property {0} is not allowed.", A)
                      })
                    }
                  else {
                    const M = new fe;
                    le(v, k, M, r, i), n.mergePropertyMatch(M)
                  }
                }
              } L.forEach(d)
          }
        }
      const p = e.additionalProperties;
      if (p !== void 0)
        for (const b of g) {
          d(b);
          const _ = m[b];
          if (_) {
            if (p === !1) {
              const L = _.parent;
              n.problems.push({
                location: {
                  offset: L.keyNode.offset,
                  length: L.keyNode.length
                },
                message: e.errorMessage || P("Property {0} is not allowed.", b)
              })
            } else if (p !== !0) {
              const L = new fe;
              le(_, p, L, r, i), n.mergePropertyMatch(L)
            }
          }
        }
      const y = e.unevaluatedProperties;
      if (y !== void 0) {
        const b = [];
        for (const _ of g)
          if (!n.processedProperties.has(_)) {
            b.push(_);
            const L = m[_];
            if (L) {
              if (y === !1) {
                const A = L.parent;
                n.problems.push({
                  location: {
                    offset: A.keyNode.offset,
                    length: A.keyNode.length
                  },
                  message: e.errorMessage || P("Property {0} is not allowed.", _)
                })
              } else if (y !== !0) {
                const A = new fe;
                le(L, y, A, r, i), n.mergePropertyMatch(A)
              }
            }
          } b.forEach(d)
      }
      if (ce(e.maxProperties) && f.properties.length > e.maxProperties && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: P("Object has more properties than limit of {0}.", e.maxProperties)
        }), ce(e.minProperties) && f.properties.length < e.minProperties && n.problems.push({
          location: {
            offset: f.offset,
            length: f.length
          },
          message: P("Object has fewer properties than the required number of {0}", e.minProperties)
        }), e.dependentRequired)
        for (const b in e.dependentRequired) {
          const _ = m[b],
            L = e.dependentRequired[b];
          _ && Array.isArray(L) && N(b, L)
        }
      if (e.dependentSchemas)
        for (const b in e.dependentSchemas) {
          const _ = m[b],
            L = e.dependentSchemas[b];
          _ && Ke(L) && N(b, L)
        }
      if (e.dependencies)
        for (const b in e.dependencies) m[b] && N(b, e.dependencies[b]);
      const w = xe(e.propertyNames);
      if (w)
        for (const b of f.properties) {
          const _ = b.keyNode;
          _ && le(_, w, n, on.instance, i)
        }

      function N(b, _) {
        if (Array.isArray(_))
          for (const L of _) m[L] ? n.propertiesValueMatches++ : n.problems.push({
            location: {
              offset: f.offset,
              length: f.length
            },
            message: P("Object is missing property {0} required by property {1}.", L, b)
          });
        else {
          const L = xe(_);
          if (L) {
            const A = new fe;
            le(f, L, A, r, i), n.mergePropertyMatch(A)
          }
        }
      }
    }
  }

  function i1(t, e) {
    const n = [];
    let r = -1;
    const i = t.getText(),
      s = lt(i, !1),
      a = e && e.collectComments ? [] : void 0;

    function o() {
      for (;;) {
        const A = s.scan();
        switch (h(), A) {
          case 12:
          case 13:
            Array.isArray(a) && a.push(W.create(t.positionAt(s.getTokenOffset()), t.positionAt(s.getTokenOffset() + s.getTokenLength())));
            break;
          case 15:
          case 14:
            break;
          default:
            return A
        }
      }
    }

    function u(A, v, k, M, V = ye.Error) {
      if (n.length === 0 || k !== r) {
        const T = W.create(t.positionAt(k), t.positionAt(M));
        n.push(Ge.create(T, A, V, v, t.languageId)), r = k
      }
    }

    function l(A, v, k = void 0, M = [], V = []) {
      let T = s.getTokenOffset(),
        x = s.getTokenOffset() + s.getTokenLength();
      if (T === x && T > 0) {
        for (T--; T > 0 && /\s/.test(i.charAt(T));) T--;
        x = T + 1
      }
      if (u(A, v, T, x), k && f(k, !1), M.length + V.length > 0) {
        let S = s.getToken();
        for (; S !== 17;) {
          if (M.indexOf(S) !== -1) {
            o();
            break
          } else if (V.indexOf(S) !== -1) break;
          S = o()
        }
      }
      return k
    }

    function h() {
      switch (s.getTokenError()) {
        case 4:
          return l(P("Invalid unicode sequence in string."), G.InvalidUnicode), !0;
        case 5:
          return l(P("Invalid escape character in string."), G.InvalidEscapeCharacter), !0;
        case 3:
          return l(P("Unexpected end of number."), G.UnexpectedEndOfNumber), !0;
        case 1:
          return l(P("Unexpected end of comment."), G.UnexpectedEndOfComment), !0;
        case 2:
          return l(P("Unexpected end of string."), G.UnexpectedEndOfString), !0;
        case 6:
          return l(P("Invalid characters in string. Control characters must be escaped."), G.InvalidCharacter), !0
      }
      return !1
    }

    function f(A, v) {
      return A.length = s.getTokenOffset() + s.getTokenLength() - A.offset, v && o(), A
    }

    function m(A) {
      if (s.getToken() !== 3) return;
      const v = new Yc(A, s.getTokenOffset());
      o();
      let k = !1;
      for (; s.getToken() !== 4 && s.getToken() !== 17;) {
        if (s.getToken() === 5) {
          k || l(P("Value expected"), G.ValueExpected);
          const V = s.getTokenOffset();
          if (o(), s.getToken() === 4) {
            k && u(P("Trailing comma"), G.TrailingComma, V, V + 1);
            continue
          }
        } else k && l(P("Expected comma"), G.CommaExpected);
        const M = b(v);
        M ? v.items.push(M) : l(P("Value expected"), G.ValueExpected, void 0, [], [4, 5]), k = !0
      }
      return s.getToken() !== 4 ? l(P("Expected comma or closing bracket"), G.CommaOrCloseBacketExpected, v) : f(v, !0)
    }
    const g = new Zr(void 0, 0, 0);

    function d(A, v) {
      const k = new e1(A, s.getTokenOffset(), g);
      let M = y(k);
      if (!M)
        if (s.getToken() === 16) {
          l(P("Property keys must be doublequoted"), G.PropertyKeysMustBeDoublequoted);
          const T = new Zr(k, s.getTokenOffset(), s.getTokenLength());
          T.value = s.getTokenValue(), M = T, o()
        } else return;
      if (k.keyNode = M, M.value !== "//") {
        const T = v[M.value];
        T ? (u(P("Duplicate object key"), G.DuplicateKey, k.keyNode.offset, k.keyNode.offset + k.keyNode.length, ye.Warning), Ke(T) && u(P("Duplicate object key"), G.DuplicateKey, T.keyNode.offset, T.keyNode.offset + T.keyNode.length, ye.Warning), v[M.value] = !0) : v[M.value] = k
      }
      if (s.getToken() === 6) k.colonOffset = s.getTokenOffset(), o();
      else if (l(P("Colon expected"), G.ColonExpected), s.getToken() === 10 && t.positionAt(M.offset + M.length).line < t.positionAt(s.getTokenOffset()).line) return k.length = M.length, k;
      const V = b(k);
      return V ? (k.valueNode = V, k.length = V.offset + V.length - k.offset, k) : l(P("Value expected"), G.ValueExpected, k, [], [2, 5])
    }

    function p(A) {
      if (s.getToken() !== 1) return;
      const v = new t1(A, s.getTokenOffset()),
        k = Object.create(null);
      o();
      let M = !1;
      for (; s.getToken() !== 2 && s.getToken() !== 17;) {
        if (s.getToken() === 5) {
          M || l(P("Property expected"), G.PropertyExpected);
          const T = s.getTokenOffset();
          if (o(), s.getToken() === 2) {
            M && u(P("Trailing comma"), G.TrailingComma, T, T + 1);
            continue
          }
        } else M && l(P("Expected comma"), G.CommaExpected);
        const V = d(v, k);
        V ? v.properties.push(V) : l(P("Property expected"), G.PropertyExpected, void 0, [], [2, 5]), M = !0
      }
      return s.getToken() !== 2 ? l(P("Expected comma or closing brace"), G.CommaOrCloseBraceExpected, v) : f(v, !0)
    }

    function y(A) {
      if (s.getToken() !== 10) return;
      const v = new Zr(A, s.getTokenOffset());
      return v.value = s.getTokenValue(), f(v, !0)
    }

    function w(A) {
      if (s.getToken() !== 11) return;
      const v = new Kc(A, s.getTokenOffset());
      if (s.getTokenError() === 0) {
        const k = s.getTokenValue();
        try {
          const M = JSON.parse(k);
          if (!ce(M)) return l(P("Invalid number format."), G.Undefined, v);
          v.value = M
        } catch {
          return l(P("Invalid number format."), G.Undefined, v)
        }
        v.isInteger = k.indexOf(".") === -1
      }
      return f(v, !0)
    }

    function N(A) {
      switch (s.getToken()) {
        case 7:
          return f(new Zc(A, s.getTokenOffset()), !0);
        case 8:
          return f(new So(A, !0, s.getTokenOffset()), !0);
        case 9:
          return f(new So(A, !1, s.getTokenOffset()), !0);
        default:
          return
      }
    }

    function b(A) {
      return m(A) || p(A) || y(A) || w(A) || N(A)
    }
    let _;
    return o() !== 17 && (_ = b(_), _ ? s.getToken() !== 17 && l(P("End of file expected."), G.Undefined) : l(P("Expected a JSON object, array or literal."), G.Undefined)), new Eo(_, n, a)
  }

  function ei(t, e, n) {
    if (t !== null && typeof t == "object") {
      const r = e + "	";
      if (Array.isArray(t)) {
        if (t.length === 0) return "[]";
        let i = `[
`;
        for (let s = 0; s < t.length; s++) i += r + ei(t[s], r, n), s < t.length - 1 && (i += ","), i += `
`;
        return i += e + "]", i
      } else {
        const i = Object.keys(t);
        if (i.length === 0) return "{}";
        let s = `{
`;
        for (let a = 0; a < i.length; a++) {
          const o = i[a];
          s += r + JSON.stringify(o) + ": " + ei(t[o], r, n), a < i.length - 1 && (s += ","), s += `
`
        }
        return s += e + "}", s
      }
    }
    return n(t)
  }
  class s1 {
    constructor(e, n = [], r = Promise, i = {}) {
      this.schemaService = e, this.contributions = n, this.promiseConstructor = r, this.clientCapabilities = i
    }
    doResolve(e) {
      for (let n = this.contributions.length - 1; n >= 0; n--) {
        const r = this.contributions[n].resolveCompletion;
        if (r) {
          const i = r(e);
          if (i) return i
        }
      }
      return this.promiseConstructor.resolve(e)
    }
    doComplete(e, n, r) {
      const i = {
          items: [],
          isIncomplete: !1
        },
        s = e.getText(),
        a = e.offsetAt(n);
      let o = r.getNodeFromOffset(a, !0);
      if (this.isInComment(e, o ? o.offset : 0, a)) return Promise.resolve(i);
      if (o && a === o.offset + o.length && a > 0) {
        const m = s[a - 1];
        (o.type === "object" && m === "}" || o.type === "array" && m === "]") && (o = o.parent)
      }
      const u = this.getCurrentWord(e, a);
      let l;
      if (o && (o.type === "string" || o.type === "number" || o.type === "boolean" || o.type === "null")) l = W.create(e.positionAt(o.offset), e.positionAt(o.offset + o.length));
      else {
        let m = a - u.length;
        m > 0 && s[m - 1] === '"' && m--, l = W.create(e.positionAt(m), n)
      }
      const h = new Map,
        f = {
          add: m => {
            let g = m.label;
            const d = h.get(g);
            if (d) d.documentation || (d.documentation = m.documentation), d.detail || (d.detail = m.detail), d.labelDetails || (d.labelDetails = m.labelDetails);
            else {
              if (g = g.replace(/[\n]/g, "↵"), g.length > 60) {
                const p = g.substr(0, 57).trim() + "...";
                h.has(p) || (g = p)
              }
              m.textEdit = De.replace(l, m.insertText), m.label = g, h.set(g, m), i.items.push(m)
            }
          },
          setAsIncomplete: () => {
            i.isIncomplete = !0
          },
          error: m => {
            console.error(m)
          },
          getNumberOfProposals: () => i.items.length
        };
      return this.schemaService.getSchemaForResource(e.uri, r).then(m => {
        const g = [];
        let d = !0,
          p = "",
          y;
        if (o && o.type === "string") {
          const N = o.parent;
          N && N.type === "property" && N.keyNode === o && (d = !N.valueNode, y = N, p = s.substr(o.offset + 1, o.length - 2), N && (o = N.parent))
        }
        if (o && o.type === "object") {
          if (o.offset === a) return i;
          o.properties.forEach(L => {
            (!y || y !== L) && h.set(L.keyNode.value, zr.create("__"))
          });
          let b = "";
          d && (b = this.evaluateSeparatorAfter(e, e.offsetAt(l.end))), m ? this.getPropertyCompletions(m, r, o, d, b, f) : this.getSchemaLessPropertyCompletions(r, o, p, f);
          const _ = Kr(o);
          this.contributions.forEach(L => {
            const A = L.collectPropertyCompletions(e.uri, _, u, d, b === "", f);
            A && g.push(A)
          }), !m && u.length > 0 && s.charAt(a - u.length - 1) !== '"' && (f.add({
            kind: we.Property,
            label: this.getLabelForValue(u),
            insertText: this.getInsertTextForProperty(u, void 0, !1, b),
            insertTextFormat: ie.Snippet,
            documentation: ""
          }), f.setAsIncomplete())
        }
        const w = {};
        return m ? this.getValueCompletions(m, r, o, a, e, f, w) : this.getSchemaLessValueCompletions(r, o, a, e, f), this.contributions.length > 0 && this.getContributedValueCompletions(r, o, a, e, f, g), this.promiseConstructor.all(g).then(() => {
          if (f.getNumberOfProposals() === 0) {
            let N = a;
            o && (o.type === "string" || o.type === "number" || o.type === "boolean" || o.type === "null") && (N = o.offset + o.length);
            const b = this.evaluateSeparatorAfter(e, N);
            this.addFillerValueCompletions(w, b, f)
          }
          return i
        })
      })
    }
    getPropertyCompletions(e, n, r, i, s, a) {
      n.getMatchingSchemas(e.schema, r.offset).forEach(u => {
        if (u.node === r && !u.inverted) {
          const l = u.schema.properties;
          l && Object.keys(l).forEach(f => {
            const m = l[f];
            if (typeof m == "object" && !m.deprecationMessage && !m.doNotSuggest) {
              const g = {
                kind: we.Property,
                label: f,
                insertText: this.getInsertTextForProperty(f, m, i, s),
                insertTextFormat: ie.Snippet,
                filterText: this.getFilterTextForValue(f),
                documentation: this.fromMarkup(m.markdownDescription) || m.description || ""
              };
              m.suggestSortText !== void 0 && (g.sortText = m.suggestSortText), g.insertText && nn(g.insertText, `$1${s}`) && (g.command = {
                title: "Suggest",
                command: "editor.action.triggerSuggest"
              }), a.add(g)
            }
          });
          const h = u.schema.propertyNames;
          if (typeof h == "object" && !h.deprecationMessage && !h.doNotSuggest) {
            const f = (m, g = void 0) => {
              const d = {
                kind: we.Property,
                label: m,
                insertText: this.getInsertTextForProperty(m, void 0, i, s),
                insertTextFormat: ie.Snippet,
                filterText: this.getFilterTextForValue(m),
                documentation: g || this.fromMarkup(h.markdownDescription) || h.description || ""
              };
              h.suggestSortText !== void 0 && (d.sortText = h.suggestSortText), d.insertText && nn(d.insertText, `$1${s}`) && (d.command = {
                title: "Suggest",
                command: "editor.action.triggerSuggest"
              }), a.add(d)
            };
            if (h.enum)
              for (let m = 0; m < h.enum.length; m++) {
                let g;
                h.markdownEnumDescriptions && m < h.markdownEnumDescriptions.length ? g = this.fromMarkup(h.markdownEnumDescriptions[m]) : h.enumDescriptions && m < h.enumDescriptions.length && (g = h.enumDescriptions[m]), f(h.enum[m], g)
              }
            h.const && f(h.const)
          }
        }
      })
    }
    getSchemaLessPropertyCompletions(e, n, r, i) {
      const s = a => {
        a.properties.forEach(o => {
          const u = o.keyNode.value;
          i.add({
            kind: we.Property,
            label: u,
            insertText: this.getInsertTextForValue(u, ""),
            insertTextFormat: ie.Snippet,
            filterText: this.getFilterTextForValue(u),
            documentation: ""
          })
        })
      };
      if (n.parent)
        if (n.parent.type === "property") {
          const a = n.parent.keyNode.value;
          e.visit(o => (o.type === "property" && o !== n.parent && o.keyNode.value === a && o.valueNode && o.valueNode.type === "object" && s(o.valueNode), !0))
        } else n.parent.type === "array" && n.parent.items.forEach(a => {
          a.type === "object" && a !== n && s(a)
        });
      else n.type === "object" && i.add({
        kind: we.Property,
        label: "$schema",
        insertText: this.getInsertTextForProperty("$schema", void 0, !0, ""),
        insertTextFormat: ie.Snippet,
        documentation: "",
        filterText: this.getFilterTextForValue("$schema")
      })
    }
    getSchemaLessValueCompletions(e, n, r, i, s) {
      let a = r;
      if (n && (n.type === "string" || n.type === "number" || n.type === "boolean" || n.type === "null") && (a = n.offset + n.length, n = n.parent), !n) {
        s.add({
          kind: this.getSuggestionKind("object"),
          label: "Empty object",
          insertText: this.getInsertTextForValue({}, ""),
          insertTextFormat: ie.Snippet,
          documentation: ""
        }), s.add({
          kind: this.getSuggestionKind("array"),
          label: "Empty array",
          insertText: this.getInsertTextForValue([], ""),
          insertTextFormat: ie.Snippet,
          documentation: ""
        });
        return
      }
      const o = this.evaluateSeparatorAfter(i, a),
        u = l => {
          l.parent && !Ro(l.parent, r, !0) && s.add({
            kind: this.getSuggestionKind(l.type),
            label: this.getLabelTextForMatchingNode(l, i),
            insertText: this.getInsertTextForMatchingNode(l, i, o),
            insertTextFormat: ie.Snippet,
            documentation: ""
          }), l.type === "boolean" && this.addBooleanValueCompletion(!l.value, o, s)
        };
      if (n.type === "property" && r > (n.colonOffset || 0)) {
        const l = n.valueNode;
        if (l && (r > l.offset + l.length || l.type === "object" || l.type === "array")) return;
        const h = n.keyNode.value;
        e.visit(f => (f.type === "property" && f.keyNode.value === h && f.valueNode && u(f.valueNode), !0)), h === "$schema" && n.parent && !n.parent.parent && this.addDollarSchemaCompletions(o, s)
      }
      if (n.type === "array")
        if (n.parent && n.parent.type === "property") {
          const l = n.parent.keyNode.value;
          e.visit(h => (h.type === "property" && h.keyNode.value === l && h.valueNode && h.valueNode.type === "array" && h.valueNode.items.forEach(u), !0))
        } else n.items.forEach(u)
    }
    getValueCompletions(e, n, r, i, s, a, o) {
      let u = i,
        l, h;
      if (r && (r.type === "string" || r.type === "number" || r.type === "boolean" || r.type === "null") && (u = r.offset + r.length, h = r, r = r.parent), !r) {
        this.addSchemaValueCompletions(e.schema, "", a, o);
        return
      }
      if (r.type === "property" && i > (r.colonOffset || 0)) {
        const f = r.valueNode;
        if (f && i > f.offset + f.length) return;
        l = r.keyNode.value, r = r.parent
      }
      if (r && (l !== void 0 || r.type === "array")) {
        const f = this.evaluateSeparatorAfter(s, u),
          m = n.getMatchingSchemas(e.schema, r.offset, h);
        for (const g of m)
          if (g.node === r && !g.inverted && g.schema) {
            if (r.type === "array" && g.schema.items) {
              let d = a;
              if (g.schema.uniqueItems) {
                const p = new Set;
                r.children.forEach(y => {
                  y.type !== "array" && y.type !== "object" && p.add(this.getLabelForValue(ft(y)))
                }), d = {
                  ...a,
                  add(y) {
                    p.has(y.label) || a.add(y)
                  }
                }
              }
              if (Array.isArray(g.schema.items)) {
                const p = this.findItemAtOffset(r, s, i);
                p < g.schema.items.length && this.addSchemaValueCompletions(g.schema.items[p], f, d, o)
              } else this.addSchemaValueCompletions(g.schema.items, f, d, o)
            }
            if (l !== void 0) {
              let d = !1;
              if (g.schema.properties) {
                const p = g.schema.properties[l];
                p && (d = !0, this.addSchemaValueCompletions(p, f, a, o))
              }
              if (g.schema.patternProperties && !d)
                for (const p of Object.keys(g.schema.patternProperties)) {
                  const y = Tn(p);
                  if (y != null && y.test(l)) {
                    d = !0;
                    const w = g.schema.patternProperties[p];
                    this.addSchemaValueCompletions(w, f, a, o)
                  }
                }
              if (g.schema.additionalProperties && !d) {
                const p = g.schema.additionalProperties;
                this.addSchemaValueCompletions(p, f, a, o)
              }
            }
          } l === "$schema" && !r.parent && this.addDollarSchemaCompletions(f, a), o.boolean && (this.addBooleanValueCompletion(!0, f, a), this.addBooleanValueCompletion(!1, f, a)), o.null && this.addNullValueCompletion(f, a)
      }
    }
    getContributedValueCompletions(e, n, r, i, s, a) {
      if (!n) this.contributions.forEach(o => {
        const u = o.collectDefaultCompletions(i.uri, s);
        u && a.push(u)
      });
      else if ((n.type === "string" || n.type === "number" || n.type === "boolean" || n.type === "null") && (n = n.parent), n && n.type === "property" && r > (n.colonOffset || 0)) {
        const o = n.keyNode.value,
          u = n.valueNode;
        if ((!u || r <= u.offset + u.length) && n.parent) {
          const l = Kr(n.parent);
          this.contributions.forEach(h => {
            const f = h.collectValueCompletions(i.uri, l, o, s);
            f && a.push(f)
          })
        }
      }
    }
    addSchemaValueCompletions(e, n, r, i) {
      typeof e == "object" && (this.addEnumValueCompletions(e, n, r), this.addDefaultValueCompletions(e, n, r), this.collectTypes(e, i), Array.isArray(e.allOf) && e.allOf.forEach(s => this.addSchemaValueCompletions(s, n, r, i)), Array.isArray(e.anyOf) && e.anyOf.forEach(s => this.addSchemaValueCompletions(s, n, r, i)), Array.isArray(e.oneOf) && e.oneOf.forEach(s => this.addSchemaValueCompletions(s, n, r, i)))
    }
    addDefaultValueCompletions(e, n, r, i = 0) {
      let s = !1;
      if (Ee(e.default)) {
        let a = e.type,
          o = e.default;
        for (let l = i; l > 0; l--) o = [o], a = "array";
        const u = {
          kind: this.getSuggestionKind(a),
          label: this.getLabelForValue(o),
          insertText: this.getInsertTextForValue(o, n),
          insertTextFormat: ie.Snippet
        };
        this.doesSupportsLabelDetails() ? u.labelDetails = {
          description: P("Default value")
        } : u.detail = P("Default value"), r.add(u), s = !0
      }
      Array.isArray(e.examples) && e.examples.forEach(a => {
        let o = e.type,
          u = a;
        for (let l = i; l > 0; l--) u = [u], o = "array";
        r.add({
          kind: this.getSuggestionKind(o),
          label: this.getLabelForValue(u),
          insertText: this.getInsertTextForValue(u, n),
          insertTextFormat: ie.Snippet
        }), s = !0
      }), Array.isArray(e.defaultSnippets) && e.defaultSnippets.forEach(a => {
        let o = e.type,
          u = a.body,
          l = a.label,
          h, f;
        if (Ee(u)) {
          e.type;
          for (let m = i; m > 0; m--) u = [u];
          h = this.getInsertTextForSnippetValue(u, n), f = this.getFilterTextForSnippetValue(u), l = l || this.getLabelForSnippetValue(u)
        } else if (typeof a.bodyText == "string") {
          let m = "",
            g = "",
            d = "";
          for (let p = i; p > 0; p--) m = m + d + `[
`, g = g + `
` + d + "]", d += "	", o = "array";
          h = m + d + a.bodyText.split(`
`).join(`
` + d) + g + n, l = l || h, f = h.replace(/[\n]/g, "")
        } else return;
        r.add({
          kind: this.getSuggestionKind(o),
          label: l,
          documentation: this.fromMarkup(a.markdownDescription) || a.description,
          insertText: h,
          insertTextFormat: ie.Snippet,
          filterText: f
        }), s = !0
      }), !s && typeof e.items == "object" && !Array.isArray(e.items) && i < 5 && this.addDefaultValueCompletions(e.items, n, r, i + 1)
    }
    addEnumValueCompletions(e, n, r) {
      if (Ee(e.const) && r.add({
          kind: this.getSuggestionKind(e.type),
          label: this.getLabelForValue(e.const),
          insertText: this.getInsertTextForValue(e.const, n),
          insertTextFormat: ie.Snippet,
          documentation: this.fromMarkup(e.markdownDescription) || e.description
        }), Array.isArray(e.enum))
        for (let i = 0, s = e.enum.length; i < s; i++) {
          const a = e.enum[i];
          let o = this.fromMarkup(e.markdownDescription) || e.description;
          e.markdownEnumDescriptions && i < e.markdownEnumDescriptions.length && this.doesSupportMarkdown() ? o = this.fromMarkup(e.markdownEnumDescriptions[i]) : e.enumDescriptions && i < e.enumDescriptions.length && (o = e.enumDescriptions[i]), r.add({
            kind: this.getSuggestionKind(e.type),
            label: this.getLabelForValue(a),
            insertText: this.getInsertTextForValue(a, n),
            insertTextFormat: ie.Snippet,
            documentation: o
          })
        }
    }
    collectTypes(e, n) {
      if (Array.isArray(e.enum) || Ee(e.const)) return;
      const r = e.type;
      Array.isArray(r) ? r.forEach(i => n[i] = !0) : r && (n[r] = !0)
    }
    addFillerValueCompletions(e, n, r) {
      e.object && r.add({
        kind: this.getSuggestionKind("object"),
        label: "{}",
        insertText: this.getInsertTextForGuessedValue({}, n),
        insertTextFormat: ie.Snippet,
        detail: P("New object"),
        documentation: ""
      }), e.array && r.add({
        kind: this.getSuggestionKind("array"),
        label: "[]",
        insertText: this.getInsertTextForGuessedValue([], n),
        insertTextFormat: ie.Snippet,
        detail: P("New array"),
        documentation: ""
      })
    }
    addBooleanValueCompletion(e, n, r) {
      r.add({
        kind: this.getSuggestionKind("boolean"),
        label: e ? "true" : "false",
        insertText: this.getInsertTextForValue(e, n),
        insertTextFormat: ie.Snippet,
        documentation: ""
      })
    }
    addNullValueCompletion(e, n) {
      n.add({
        kind: this.getSuggestionKind("null"),
        label: "null",
        insertText: "null" + e,
        insertTextFormat: ie.Snippet,
        documentation: ""
      })
    }
    addDollarSchemaCompletions(e, n) {
      this.schemaService.getRegisteredSchemaIds(i => i === "http" || i === "https").forEach(i => {
        i.startsWith("http://json-schema.org/draft-") && (i = i + "#"), n.add({
          kind: we.Module,
          label: this.getLabelForValue(i),
          filterText: this.getFilterTextForValue(i),
          insertText: this.getInsertTextForValue(i, e),
          insertTextFormat: ie.Snippet,
          documentation: ""
        })
      })
    }
    getLabelForValue(e) {
      return JSON.stringify(e)
    }
    getValueFromLabel(e) {
      return JSON.parse(e)
    }
    getFilterTextForValue(e) {
      return JSON.stringify(e)
    }
    getFilterTextForSnippetValue(e) {
      return JSON.stringify(e).replace(/\$\{\d+:([^}]+)\}|\$\d+/g, "$1")
    }
    getLabelForSnippetValue(e) {
      return JSON.stringify(e).replace(/\$\{\d+:([^}]+)\}|\$\d+/g, "$1")
    }
    getInsertTextForPlainText(e) {
      return e.replace(/[\\\$\}]/g, "\\$&")
    }
    getInsertTextForValue(e, n) {
      const r = JSON.stringify(e, null, "	");
      return r === "{}" ? "{$1}" + n : r === "[]" ? "[$1]" + n : this.getInsertTextForPlainText(r + n)
    }
    getInsertTextForSnippetValue(e, n) {
      return ei(e, "", i => typeof i == "string" && i[0] === "^" ? i.substr(1) : JSON.stringify(i)) + n
    }
    getInsertTextForGuessedValue(e, n) {
      switch (typeof e) {
        case "object":
          return e === null ? "${1:null}" + n : this.getInsertTextForValue(e, n);
        case "string":
          let r = JSON.stringify(e);
          return r = r.substr(1, r.length - 2), r = this.getInsertTextForPlainText(r), '"${1:' + r + '}"' + n;
        case "number":
        case "boolean":
          return "${1:" + JSON.stringify(e) + "}" + n
      }
      return this.getInsertTextForValue(e, n)
    }
    getSuggestionKind(e) {
      if (Array.isArray(e)) {
        const n = e;
        e = n.length > 0 ? n[0] : void 0
      }
      if (!e) return we.Value;
      switch (e) {
        case "string":
          return we.Value;
        case "object":
          return we.Module;
        case "property":
          return we.Property;
        default:
          return we.Value
      }
    }
    getLabelTextForMatchingNode(e, n) {
      switch (e.type) {
        case "array":
          return "[]";
        case "object":
          return "{}";
        default:
          return n.getText().substr(e.offset, e.length)
      }
    }
    getInsertTextForMatchingNode(e, n, r) {
      switch (e.type) {
        case "array":
          return this.getInsertTextForValue([], r);
        case "object":
          return this.getInsertTextForValue({}, r);
        default:
          const i = n.getText().substr(e.offset, e.length) + r;
          return this.getInsertTextForPlainText(i)
      }
    }
    getInsertTextForProperty(e, n, r, i) {
      const s = this.getInsertTextForValue(e, "");
      if (!r) return s;
      const a = s + ": ";
      let o, u = 0;
      if (n) {
        if (Array.isArray(n.defaultSnippets)) {
          if (n.defaultSnippets.length === 1) {
            const l = n.defaultSnippets[0].body;
            Ee(l) && (o = this.getInsertTextForSnippetValue(l, ""))
          }
          u += n.defaultSnippets.length
        }
        if (n.enum && (!o && n.enum.length === 1 && (o = this.getInsertTextForGuessedValue(n.enum[0], "")), u += n.enum.length), Ee(n.const) && (o || (o = this.getInsertTextForGuessedValue(n.const, "")), u++), Ee(n.default) && (o || (o = this.getInsertTextForGuessedValue(n.default, "")), u++), Array.isArray(n.examples) && n.examples.length && (o || (o = this.getInsertTextForGuessedValue(n.examples[0], "")), u += n.examples.length), u === 0) {
          let l = Array.isArray(n.type) ? n.type[0] : n.type;
          switch (l || (n.properties ? l = "object" : n.items && (l = "array")), l) {
            case "boolean":
              o = "$1";
              break;
            case "string":
              o = '"$1"';
              break;
            case "object":
              o = "{$1}";
              break;
            case "array":
              o = "[$1]";
              break;
            case "number":
            case "integer":
              o = "${1:0}";
              break;
            case "null":
              o = "${1:null}";
              break;
            default:
              return s
          }
        }
      }
      return (!o || u > 1) && (o = "$1"), a + o + i
    }
    getCurrentWord(e, n) {
      let r = n - 1;
      const i = e.getText();
      for (; r >= 0 && ` 	
\r\v":{[,]}`.indexOf(i.charAt(r)) === -1;) r--;
      return i.substring(r + 1, n)
    }
    evaluateSeparatorAfter(e, n) {
      const r = lt(e.getText(), !0);
      switch (r.setPosition(n), r.scan()) {
        case 5:
        case 2:
        case 4:
        case 17:
          return "";
        default:
          return ","
      }
    }
    findItemAtOffset(e, n, r) {
      const i = lt(n.getText(), !0),
        s = e.items;
      for (let a = s.length - 1; a >= 0; a--) {
        const o = s[a];
        if (r > o.offset + o.length) return i.setPosition(o.offset + o.length), i.scan() === 5 && r >= i.getTokenOffset() + i.getTokenLength() ? a + 1 : a;
        if (r >= o.offset) return a
      }
      return 0
    }
    isInComment(e, n, r) {
      const i = lt(e.getText(), !1);
      i.setPosition(n);
      let s = i.scan();
      for (; s !== 17 && i.getTokenOffset() + i.getTokenLength() < r;) s = i.scan();
      return (s === 12 || s === 13) && i.getTokenOffset() <= r
    }
    fromMarkup(e) {
      if (e && this.doesSupportMarkdown()) return {
        kind: ut.Markdown,
        value: e
      }
    }
    doesSupportMarkdown() {
      var e, n, r;
      if (!Ee(this.supportsMarkdown)) {
        const i = (r = (n = (e = this.clientCapabilities.textDocument) == null ? void 0 : e.completion) == null ? void 0 : n.completionItem) == null ? void 0 : r.documentationFormat;
        this.supportsMarkdown = Array.isArray(i) && i.indexOf(ut.Markdown) !== -1
      }
      return this.supportsMarkdown
    }
    doesSupportsCommitCharacters() {
      var e, n, r;
      return Ee(this.supportsCommitCharacters) || (this.labelDetailsSupport = (r = (n = (e = this.clientCapabilities.textDocument) == null ? void 0 : e.completion) == null ? void 0 : n.completionItem) == null ? void 0 : r.commitCharactersSupport), this.supportsCommitCharacters
    }
    doesSupportsLabelDetails() {
      var e, n, r;
      return Ee(this.labelDetailsSupport) || (this.labelDetailsSupport = (r = (n = (e = this.clientCapabilities.textDocument) == null ? void 0 : e.completion) == null ? void 0 : n.completionItem) == null ? void 0 : r.labelDetailsSupport), this.labelDetailsSupport
    }
  }
  class a1 {
    constructor(e, n = [], r) {
      this.schemaService = e, this.contributions = n, this.promise = r || Promise
    }
    doHover(e, n, r) {
      const i = e.offsetAt(n);
      let s = r.getNodeFromOffset(i);
      if (!s || (s.type === "object" || s.type === "array") && i > s.offset + 1 && i < s.offset + s.length - 1) return this.promise.resolve(null);
      const a = s;
      if (s.type === "string") {
        const h = s.parent;
        if (h && h.type === "property" && h.keyNode === s && (s = h.valueNode, !s)) return this.promise.resolve(null)
      }
      const o = W.create(e.positionAt(a.offset), e.positionAt(a.offset + a.length)),
        u = h => ({
          contents: h,
          range: o
        }),
        l = Kr(s);
      for (let h = this.contributions.length - 1; h >= 0; h--) {
        const m = this.contributions[h].getInfoContribution(e.uri, l);
        if (m) return m.then(g => u(g))
      }
      return this.schemaService.getSchemaForResource(e.uri, r).then(h => {
        if (h && s) {
          const f = r.getMatchingSchemas(h.schema, s.offset);
          let m, g, d, p;
          f.every(w => {
            if (w.node === s && !w.inverted && w.schema && (m = m || w.schema.title, g = g || w.schema.markdownDescription || ti(w.schema.description), w.schema.enum)) {
              const N = w.schema.enum.indexOf(ft(s));
              w.schema.markdownEnumDescriptions ? d = w.schema.markdownEnumDescriptions[N] : w.schema.enumDescriptions && (d = ti(w.schema.enumDescriptions[N])), d && (p = w.schema.enum[N], typeof p != "string" && (p = JSON.stringify(p)))
            }
            return !0
          });
          let y = "";
          return m && (y = ti(m)), g && (y.length > 0 && (y += `

`), y += g), d && (y.length > 0 && (y += `

`), y += `\`${o1(p)}\`: ${d}`), u([y])
        }
        return null
      })
    }
  }

  function ti(t) {
    if (t) return t.replace(/([^\n\r])(\r?\n)([^\n\r])/gm, `$1

$3`).replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&")
  }

  function o1(t) {
    return t.indexOf("`") !== -1 ? "`` " + t + " ``" : t
  }
  class l1 {
    constructor(e, n) {
      this.jsonSchemaService = e, this.promise = n, this.validationEnabled = !0
    }
    configure(e) {
      e && (this.validationEnabled = e.validate !== !1, this.commentSeverity = e.allowComments ? void 0 : ye.Error)
    }
    doValidation(e, n, r, i) {
      if (!this.validationEnabled) return this.promise.resolve([]);
      const s = [],
        a = {},
        o = l => {
          const h = l.range.start.line + " " + l.range.start.character + " " + l.message;
          a[h] || (a[h] = !0, s.push(l))
        },
        u = l => {
          let h = r != null && r.trailingCommas ? Vn(r.trailingCommas) : ye.Error,
            f = r != null && r.comments ? Vn(r.comments) : this.commentSeverity,
            m = r != null && r.schemaValidation ? Vn(r.schemaValidation) : ye.Warning,
            g = r != null && r.schemaRequest ? Vn(r.schemaRequest) : ye.Warning;
          if (l) {
            const d = (p, y) => {
              if (n.root && g) {
                const w = n.root,
                  N = w.type === "object" ? w.properties[0] : void 0;
                if (N && N.keyNode.value === "$schema") {
                  const b = N.valueNode || N,
                    _ = W.create(e.positionAt(b.offset), e.positionAt(b.offset + b.length));
                  o(Ge.create(_, p, g, y))
                } else {
                  const b = W.create(e.positionAt(w.offset), e.positionAt(w.offset + 1));
                  o(Ge.create(b, p, g, y))
                }
              }
            };
            if (l.errors.length) d(l.errors[0], G.SchemaResolveError);
            else if (m) {
              for (const y of l.warnings) d(y, G.SchemaUnsupportedFeature);
              const p = n.validate(e, l.schema, m, r == null ? void 0 : r.schemaDraft);
              p && p.forEach(o)
            }
            To(l.schema) && (f = void 0), Po(l.schema) && (h = void 0)
          }
          for (const d of n.syntaxErrors) {
            if (d.code === G.TrailingComma) {
              if (typeof h != "number") continue;
              d.severity = h
            }
            o(d)
          }
          if (typeof f == "number") {
            const d = P("Comments are not permitted in JSON.");
            n.comments.forEach(p => {
              o(Ge.create(p, d, f, G.CommentNotPermitted))
            })
          }
          return s
        };
      if (i) {
        const l = i.id || "schemaservice://untitled/" + u1++;
        return this.jsonSchemaService.registerExternalSchema({
          uri: l,
          schema: i
        }).getResolvedSchema().then(f => u(f))
      }
      return this.jsonSchemaService.getSchemaForResource(e.uri, n).then(l => u(l))
    }
    getLanguageStatus(e, n) {
      return {
        schemas: this.jsonSchemaService.getSchemaURIsForResource(e.uri, n)
      }
    }
  }
  let u1 = 0;

  function To(t) {
    if (t && typeof t == "object") {
      if (Ve(t.allowComments)) return t.allowComments;
      if (t.allOf)
        for (const e of t.allOf) {
          const n = To(e);
          if (Ve(n)) return n
        }
    }
  }

  function Po(t) {
    if (t && typeof t == "object") {
      if (Ve(t.allowTrailingCommas)) return t.allowTrailingCommas;
      const e = t;
      if (Ve(e.allowsTrailingCommas)) return e.allowsTrailingCommas;
      if (t.allOf)
        for (const n of t.allOf) {
          const r = Po(n);
          if (Ve(r)) return r
        }
    }
  }

  function Vn(t) {
    switch (t) {
      case "error":
        return ye.Error;
      case "warning":
        return ye.Warning;
      case "ignore":
        return
    }
  }
  const Co = 48,
    c1 = 57,
    f1 = 65,
    Dn = 97,
    h1 = 102;

  function ne(t) {
    return t < Co ? 0 : t <= c1 ? t - Co : (t < Dn && (t += Dn - f1), t >= Dn && t <= h1 ? t - Dn + 10 : 0)
  }

  function m1(t) {
    if (t[0] === "#") switch (t.length) {
      case 4:
        return {
          red: ne(t.charCodeAt(1)) * 17 / 255, green: ne(t.charCodeAt(2)) * 17 / 255, blue: ne(t.charCodeAt(3)) * 17 / 255, alpha: 1
        };
      case 5:
        return {
          red: ne(t.charCodeAt(1)) * 17 / 255, green: ne(t.charCodeAt(2)) * 17 / 255, blue: ne(t.charCodeAt(3)) * 17 / 255, alpha: ne(t.charCodeAt(4)) * 17 / 255
        };
      case 7:
        return {
          red: (ne(t.charCodeAt(1)) * 16 + ne(t.charCodeAt(2))) / 255, green: (ne(t.charCodeAt(3)) * 16 + ne(t.charCodeAt(4))) / 255, blue: (ne(t.charCodeAt(5)) * 16 + ne(t.charCodeAt(6))) / 255, alpha: 1
        };
      case 9:
        return {
          red: (ne(t.charCodeAt(1)) * 16 + ne(t.charCodeAt(2))) / 255, green: (ne(t.charCodeAt(3)) * 16 + ne(t.charCodeAt(4))) / 255, blue: (ne(t.charCodeAt(5)) * 16 + ne(t.charCodeAt(6))) / 255, alpha: (ne(t.charCodeAt(7)) * 16 + ne(t.charCodeAt(8))) / 255
        }
    }
  }
  class d1 {
    constructor(e) {
      this.schemaService = e
    }
    findDocumentSymbols(e, n, r = {
      resultLimit: Number.MAX_VALUE
    }) {
      const i = n.root;
      if (!i) return [];
      let s = r.resultLimit || Number.MAX_VALUE;
      const a = e.uri;
      if ((a === "vscode://defaultsettings/keybindings.json" || nn(a.toLowerCase(), "/user/keybindings.json")) && i.type === "array") {
        const m = [];
        for (const g of i.items)
          if (g.type === "object") {
            for (const d of g.properties)
              if (d.keyNode.value === "key" && d.valueNode) {
                const p = It.create(e.uri, et(e, g));
                if (m.push({
                    name: Io(d.valueNode),
                    kind: Oe.Function,
                    location: p
                  }), s--, s <= 0) return r && r.onResultLimitExceeded && r.onResultLimitExceeded(a), m
              }
          } return m
      }
      const o = [{
        node: i,
        containerName: ""
      }];
      let u = 0,
        l = !1;
      const h = [],
        f = (m, g) => {
          m.type === "array" ? m.items.forEach(d => {
            d && o.push({
              node: d,
              containerName: g
            })
          }) : m.type === "object" && m.properties.forEach(d => {
            const p = d.valueNode;
            if (p)
              if (s > 0) {
                s--;
                const y = It.create(e.uri, et(e, d)),
                  w = g ? g + "." + d.keyNode.value : d.keyNode.value;
                h.push({
                  name: this.getKeyLabel(d),
                  kind: this.getSymbolKind(p.type),
                  location: y,
                  containerName: g
                }), o.push({
                  node: p,
                  containerName: w
                })
              } else l = !0
          })
        };
      for (; u < o.length;) {
        const m = o[u++];
        f(m.node, m.containerName)
      }
      return l && r && r.onResultLimitExceeded && r.onResultLimitExceeded(a), h
    }
    findDocumentSymbols2(e, n, r = {
      resultLimit: Number.MAX_VALUE
    }) {
      const i = n.root;
      if (!i) return [];
      let s = r.resultLimit || Number.MAX_VALUE;
      const a = e.uri;
      if ((a === "vscode://defaultsettings/keybindings.json" || nn(a.toLowerCase(), "/user/keybindings.json")) && i.type === "array") {
        const m = [];
        for (const g of i.items)
          if (g.type === "object") {
            for (const d of g.properties)
              if (d.keyNode.value === "key" && d.valueNode) {
                const p = et(e, g),
                  y = et(e, d.keyNode);
                if (m.push({
                    name: Io(d.valueNode),
                    kind: Oe.Function,
                    range: p,
                    selectionRange: y
                  }), s--, s <= 0) return r && r.onResultLimitExceeded && r.onResultLimitExceeded(a), m
              }
          } return m
      }
      const o = [],
        u = [{
          node: i,
          result: o
        }];
      let l = 0,
        h = !1;
      const f = (m, g) => {
        m.type === "array" ? m.items.forEach((d, p) => {
          if (d)
            if (s > 0) {
              s--;
              const y = et(e, d),
                w = y,
                b = {
                  name: String(p),
                  kind: this.getSymbolKind(d.type),
                  range: y,
                  selectionRange: w,
                  children: []
                };
              g.push(b), u.push({
                result: b.children,
                node: d
              })
            } else h = !0
        }) : m.type === "object" && m.properties.forEach(d => {
          const p = d.valueNode;
          if (p)
            if (s > 0) {
              s--;
              const y = et(e, d),
                w = et(e, d.keyNode),
                N = [],
                b = {
                  name: this.getKeyLabel(d),
                  kind: this.getSymbolKind(p.type),
                  range: y,
                  selectionRange: w,
                  children: N,
                  detail: this.getDetail(p)
                };
              g.push(b), u.push({
                result: N,
                node: p
              })
            } else h = !0
        })
      };
      for (; l < u.length;) {
        const m = u[l++];
        f(m.node, m.result)
      }
      return h && r && r.onResultLimitExceeded && r.onResultLimitExceeded(a), o
    }
    getSymbolKind(e) {
      switch (e) {
        case "object":
          return Oe.Module;
        case "string":
          return Oe.String;
        case "number":
          return Oe.Number;
        case "array":
          return Oe.Array;
        case "boolean":
          return Oe.Boolean;
        default:
          return Oe.Variable
      }
    }
    getKeyLabel(e) {
      let n = e.keyNode.value;
      return n && (n = n.replace(/[\n]/g, "↵")), n && n.trim() ? n : `"${n}"`
    }
    getDetail(e) {
      if (e) {
        if (e.type === "boolean" || e.type === "number" || e.type === "null" || e.type === "string") return String(e.value);
        if (e.type === "array") return e.children.length ? void 0 : "[]";
        if (e.type === "object") return e.children.length ? void 0 : "{}"
      }
    }
    findDocumentColors(e, n, r) {
      return this.schemaService.getSchemaForResource(e.uri, n).then(i => {
        const s = [];
        if (i) {
          let a = r && typeof r.resultLimit == "number" ? r.resultLimit : Number.MAX_VALUE;
          const o = n.getMatchingSchemas(i.schema),
            u = {};
          for (const l of o)
            if (!l.inverted && l.schema && (l.schema.format === "color" || l.schema.format === "color-hex") && l.node && l.node.type === "string") {
              const h = String(l.node.offset);
              if (!u[h]) {
                const f = m1(ft(l.node));
                if (f) {
                  const m = et(e, l.node);
                  s.push({
                    color: f,
                    range: m
                  })
                }
                if (u[h] = !0, a--, a <= 0) return r && r.onResultLimitExceeded && r.onResultLimitExceeded(e.uri), s
              }
            }
        }
        return s
      })
    }
    getColorPresentations(e, n, r, i) {
      const s = [],
        a = Math.round(r.red * 255),
        o = Math.round(r.green * 255),
        u = Math.round(r.blue * 255);

      function l(f) {
        const m = f.toString(16);
        return m.length !== 2 ? "0" + m : m
      }
      let h;
      return r.alpha === 1 ? h = `#${l(a)}${l(o)}${l(u)}` : h = `#${l(a)}${l(o)}${l(u)}${l(Math.round(r.alpha*255))}`, s.push({
        label: h,
        textEdit: De.replace(i, JSON.stringify(h))
      }), s
    }
  }

  function et(t, e) {
    return W.create(t.positionAt(e.offset), t.positionAt(e.offset + e.length))
  }

  function Io(t) {
    return ft(t) || P("<empty>")
  }
  const ni = {
      schemaAssociations: [],
      schemas: {
        "http://json-schema.org/draft-04/schema#": {
          $schema: "http://json-schema.org/draft-04/schema#",
          definitions: {
            schemaArray: {
              type: "array",
              minItems: 1,
              items: {
                $ref: "#"
              }
            },
            positiveInteger: {
              type: "integer",
              minimum: 0
            },
            positiveIntegerDefault0: {
              allOf: [{
                $ref: "#/definitions/positiveInteger"
              }, {
                default: 0
              }]
            },
            simpleTypes: {
              type: "string",
              enum: ["array", "boolean", "integer", "null", "number", "object", "string"]
            },
            stringArray: {
              type: "array",
              items: {
                type: "string"
              },
              minItems: 1,
              uniqueItems: !0
            }
          },
          type: "object",
          properties: {
            id: {
              type: "string",
              format: "uri"
            },
            $schema: {
              type: "string",
              format: "uri"
            },
            title: {
              type: "string"
            },
            description: {
              type: "string"
            },
            default: {},
            multipleOf: {
              type: "number",
              minimum: 0,
              exclusiveMinimum: !0
            },
            maximum: {
              type: "number"
            },
            exclusiveMaximum: {
              type: "boolean",
              default: !1
            },
            minimum: {
              type: "number"
            },
            exclusiveMinimum: {
              type: "boolean",
              default: !1
            },
            maxLength: {
              allOf: [{
                $ref: "#/definitions/positiveInteger"
              }]
            },
            minLength: {
              allOf: [{
                $ref: "#/definitions/positiveIntegerDefault0"
              }]
            },
            pattern: {
              type: "string",
              format: "regex"
            },
            additionalItems: {
              anyOf: [{
                type: "boolean"
              }, {
                $ref: "#"
              }],
              default: {}
            },
            items: {
              anyOf: [{
                $ref: "#"
              }, {
                $ref: "#/definitions/schemaArray"
              }],
              default: {}
            },
            maxItems: {
              allOf: [{
                $ref: "#/definitions/positiveInteger"
              }]
            },
            minItems: {
              allOf: [{
                $ref: "#/definitions/positiveIntegerDefault0"
              }]
            },
            uniqueItems: {
              type: "boolean",
              default: !1
            },
            maxProperties: {
              allOf: [{
                $ref: "#/definitions/positiveInteger"
              }]
            },
            minProperties: {
              allOf: [{
                $ref: "#/definitions/positiveIntegerDefault0"
              }]
            },
            required: {
              allOf: [{
                $ref: "#/definitions/stringArray"
              }]
            },
            additionalProperties: {
              anyOf: [{
                type: "boolean"
              }, {
                $ref: "#"
              }],
              default: {}
            },
            definitions: {
              type: "object",
              additionalProperties: {
                $ref: "#"
              },
              default: {}
            },
            properties: {
              type: "object",
              additionalProperties: {
                $ref: "#"
              },
              default: {}
            },
            patternProperties: {
              type: "object",
              additionalProperties: {
                $ref: "#"
              },
              default: {}
            },
            dependencies: {
              type: "object",
              additionalProperties: {
                anyOf: [{
                  $ref: "#"
                }, {
                  $ref: "#/definitions/stringArray"
                }]
              }
            },
            enum: {
              type: "array",
              minItems: 1,
              uniqueItems: !0
            },
            type: {
              anyOf: [{
                $ref: "#/definitions/simpleTypes"
              }, {
                type: "array",
                items: {
                  $ref: "#/definitions/simpleTypes"
                },
                minItems: 1,
                uniqueItems: !0
              }]
            },
            format: {
              anyOf: [{
                type: "string",
                enum: ["date-time", "uri", "email", "hostname", "ipv4", "ipv6", "regex"]
              }, {
                type: "string"
              }]
            },
            allOf: {
              allOf: [{
                $ref: "#/definitions/schemaArray"
              }]
            },
            anyOf: {
              allOf: [{
                $ref: "#/definitions/schemaArray"
              }]
            },
            oneOf: {
              allOf: [{
                $ref: "#/definitions/schemaArray"
              }]
            },
            not: {
              allOf: [{
                $ref: "#"
              }]
            }
          },
          dependencies: {
            exclusiveMaximum: ["maximum"],
            exclusiveMinimum: ["minimum"]
          },
          default: {}
        },
        "http://json-schema.org/draft-07/schema#": {
          definitions: {
            schemaArray: {
              type: "array",
              minItems: 1,
              items: {
                $ref: "#"
              }
            },
            nonNegativeInteger: {
              type: "integer",
              minimum: 0
            },
            nonNegativeIntegerDefault0: {
              allOf: [{
                $ref: "#/definitions/nonNegativeInteger"
              }, {
                default: 0
              }]
            },
            simpleTypes: {
              enum: ["array", "boolean", "integer", "null", "number", "object", "string"]
            },
            stringArray: {
              type: "array",
              items: {
                type: "string"
              },
              uniqueItems: !0,
              default: []
            }
          },
          type: ["object", "boolean"],
          properties: {
            $id: {
              type: "string",
              format: "uri-reference"
            },
            $schema: {
              type: "string",
              format: "uri"
            },
            $ref: {
              type: "string",
              format: "uri-reference"
            },
            $comment: {
              type: "string"
            },
            title: {
              type: "string"
            },
            description: {
              type: "string"
            },
            default: !0,
            readOnly: {
              type: "boolean",
              default: !1
            },
            examples: {
              type: "array",
              items: !0
            },
            multipleOf: {
              type: "number",
              exclusiveMinimum: 0
            },
            maximum: {
              type: "number"
            },
            exclusiveMaximum: {
              type: "number"
            },
            minimum: {
              type: "number"
            },
            exclusiveMinimum: {
              type: "number"
            },
            maxLength: {
              $ref: "#/definitions/nonNegativeInteger"
            },
            minLength: {
              $ref: "#/definitions/nonNegativeIntegerDefault0"
            },
            pattern: {
              type: "string",
              format: "regex"
            },
            additionalItems: {
              $ref: "#"
            },
            items: {
              anyOf: [{
                $ref: "#"
              }, {
                $ref: "#/definitions/schemaArray"
              }],
              default: !0
            },
            maxItems: {
              $ref: "#/definitions/nonNegativeInteger"
            },
            minItems: {
              $ref: "#/definitions/nonNegativeIntegerDefault0"
            },
            uniqueItems: {
              type: "boolean",
              default: !1
            },
            contains: {
              $ref: "#"
            },
            maxProperties: {
              $ref: "#/definitions/nonNegativeInteger"
            },
            minProperties: {
              $ref: "#/definitions/nonNegativeIntegerDefault0"
            },
            required: {
              $ref: "#/definitions/stringArray"
            },
            additionalProperties: {
              $ref: "#"
            },
            definitions: {
              type: "object",
              additionalProperties: {
                $ref: "#"
              },
              default: {}
            },
            properties: {
              type: "object",
              additionalProperties: {
                $ref: "#"
              },
              default: {}
            },
            patternProperties: {
              type: "object",
              additionalProperties: {
                $ref: "#"
              },
              propertyNames: {
                format: "regex"
              },
              default: {}
            },
            dependencies: {
              type: "object",
              additionalProperties: {
                anyOf: [{
                  $ref: "#"
                }, {
                  $ref: "#/definitions/stringArray"
                }]
              }
            },
            propertyNames: {
              $ref: "#"
            },
            const: !0,
            enum: {
              type: "array",
              items: !0,
              minItems: 1,
              uniqueItems: !0
            },
            type: {
              anyOf: [{
                $ref: "#/definitions/simpleTypes"
              }, {
                type: "array",
                items: {
                  $ref: "#/definitions/simpleTypes"
                },
                minItems: 1,
                uniqueItems: !0
              }]
            },
            format: {
              type: "string"
            },
            contentMediaType: {
              type: "string"
            },
            contentEncoding: {
              type: "string"
            },
            if: {
              $ref: "#"
            },
            then: {
              $ref: "#"
            },
            else: {
              $ref: "#"
            },
            allOf: {
              $ref: "#/definitions/schemaArray"
            },
            anyOf: {
              $ref: "#/definitions/schemaArray"
            },
            oneOf: {
              $ref: "#/definitions/schemaArray"
            },
            not: {
              $ref: "#"
            }
          },
          default: !0
        }
      }
    },
    g1 = {
      id: P("A unique identifier for the schema."),
      $schema: P("The schema to verify this document against."),
      title: P("A descriptive title of the element."),
      description: P("A long description of the element. Used in hover menus and suggestions."),
      default: P("A default value. Used by suggestions."),
      multipleOf: P("A number that should cleanly divide the current value (i.e. have no remainder)."),
      maximum: P("The maximum numerical value, inclusive by default."),
      exclusiveMaximum: P("Makes the maximum property exclusive."),
      minimum: P("The minimum numerical value, inclusive by default."),
      exclusiveMinimum: P("Makes the minimum property exclusive."),
      maxLength: P("The maximum length of a string."),
      minLength: P("The minimum length of a string."),
      pattern: P("A regular expression to match the string against. It is not implicitly anchored."),
      additionalItems: P("For arrays, only when items is set as an array. If it is a schema, then this schema validates items after the ones specified by the items array. If it is false, then additional items will cause validation to fail."),
      items: P("For arrays. Can either be a schema to validate every element against or an array of schemas to validate each item against in order (the first schema will validate the first element, the second schema will validate the second element, and so on."),
      maxItems: P("The maximum number of items that can be inside an array. Inclusive."),
      minItems: P("The minimum number of items that can be inside an array. Inclusive."),
      uniqueItems: P("If all of the items in the array must be unique. Defaults to false."),
      maxProperties: P("The maximum number of properties an object can have. Inclusive."),
      minProperties: P("The minimum number of properties an object can have. Inclusive."),
      required: P("An array of strings that lists the names of all properties required on this object."),
      additionalProperties: P("Either a schema or a boolean. If a schema, then used to validate all properties not matched by 'properties' or 'patternProperties'. If false, then any properties not matched by either will cause this schema to fail."),
      definitions: P("Not used for validation. Place subschemas here that you wish to reference inline with $ref."),
      properties: P("A map of property names to schemas for each property."),
      patternProperties: P("A map of regular expressions on property names to schemas for matching properties."),
      dependencies: P("A map of property names to either an array of property names or a schema. An array of property names means the property named in the key depends on the properties in the array being present in the object in order to be valid. If the value is a schema, then the schema is only applied to the object if the property in the key exists on the object."),
      enum: P("The set of literal values that are valid."),
      type: P("Either a string of one of the basic schema types (number, integer, null, array, object, boolean, string) or an array of strings specifying a subset of those types."),
      format: P("Describes the format expected for the value."),
      allOf: P("An array of schemas, all of which must match."),
      anyOf: P("An array of schemas, where at least one must match."),
      oneOf: P("An array of schemas, exactly one of which must match."),
      not: P("A schema which must not match."),
      $id: P("A unique identifier for the schema."),
      $ref: P("Reference a definition hosted on any location."),
      $comment: P("Comments from schema authors to readers or maintainers of the schema."),
      readOnly: P("Indicates that the value of the instance is managed exclusively by the owning authority."),
      examples: P("Sample JSON values associated with a particular schema, for the purpose of illustrating usage."),
      contains: P('An array instance is valid against "contains" if at least one of its elements is valid against the given schema.'),
      propertyNames: P("If the instance is an object, this keyword validates if every property name in the instance validates against the provided schema."),
      const: P("An instance validates successfully against this keyword if its value is equal to the value of the keyword."),
      contentMediaType: P("Describes the media type of a string property."),
      contentEncoding: P("Describes the content encoding of a string property."),
      if: P('The validation outcome of the "if" subschema controls which of the "then" or "else" keywords are evaluated.'),
      then: P('The "if" subschema is used for validation when the "if" subschema succeeds.'),
      else: P('The "else" subschema is used for validation when the "if" subschema fails.')
    };
  for (const t in ni.schemas) {
    const e = ni.schemas[t];
    for (const n in e.properties) {
      let r = e.properties[n];
      typeof r == "boolean" && (r = e.properties[n] = {});
      const i = g1[n];
      i && (r.description = i)
    }
  }
  var Fo;
  (() => {
    var t = {
        470: i => {
          function s(u) {
            if (typeof u != "string") throw new TypeError("Path must be a string. Received " + JSON.stringify(u))
          }

          function a(u, l) {
            for (var h, f = "", m = 0, g = -1, d = 0, p = 0; p <= u.length; ++p) {
              if (p < u.length) h = u.charCodeAt(p);
              else {
                if (h === 47) break;
                h = 47
              }
              if (h === 47) {
                if (!(g === p - 1 || d === 1))
                  if (g !== p - 1 && d === 2) {
                    if (f.length < 2 || m !== 2 || f.charCodeAt(f.length - 1) !== 46 || f.charCodeAt(f.length - 2) !== 46) {
                      if (f.length > 2) {
                        var y = f.lastIndexOf("/");
                        if (y !== f.length - 1) {
                          y === -1 ? (f = "", m = 0) : m = (f = f.slice(0, y)).length - 1 - f.lastIndexOf("/"), g = p, d = 0;
                          continue
                        }
                      } else if (f.length === 2 || f.length === 1) {
                        f = "", m = 0, g = p, d = 0;
                        continue
                      }
                    }
                    l && (f.length > 0 ? f += "/.." : f = "..", m = 2)
                  } else f.length > 0 ? f += "/" + u.slice(g + 1, p) : f = u.slice(g + 1, p), m = p - g - 1;
                g = p, d = 0
              } else h === 46 && d !== -1 ? ++d : d = -1
            }
            return f
          }
          var o = {
            resolve: function() {
              for (var u, l = "", h = !1, f = arguments.length - 1; f >= -1 && !h; f--) {
                var m;
                f >= 0 ? m = arguments[f] : (u === void 0 && (u = process.cwd()), m = u), s(m), m.length !== 0 && (l = m + "/" + l, h = m.charCodeAt(0) === 47)
              }
              return l = a(l, !h), h ? l.length > 0 ? "/" + l : "/" : l.length > 0 ? l : "."
            },
            normalize: function(u) {
              if (s(u), u.length === 0) return ".";
              var l = u.charCodeAt(0) === 47,
                h = u.charCodeAt(u.length - 1) === 47;
              return (u = a(u, !l)).length !== 0 || l || (u = "."), u.length > 0 && h && (u += "/"), l ? "/" + u : u
            },
            isAbsolute: function(u) {
              return s(u), u.length > 0 && u.charCodeAt(0) === 47
            },
            join: function() {
              if (arguments.length === 0) return ".";
              for (var u, l = 0; l < arguments.length; ++l) {
                var h = arguments[l];
                s(h), h.length > 0 && (u === void 0 ? u = h : u += "/" + h)
              }
              return u === void 0 ? "." : o.normalize(u)
            },
            relative: function(u, l) {
              if (s(u), s(l), u === l || (u = o.resolve(u)) === (l = o.resolve(l))) return "";
              for (var h = 1; h < u.length && u.charCodeAt(h) === 47; ++h);
              for (var f = u.length, m = f - h, g = 1; g < l.length && l.charCodeAt(g) === 47; ++g);
              for (var d = l.length - g, p = m < d ? m : d, y = -1, w = 0; w <= p; ++w) {
                if (w === p) {
                  if (d > p) {
                    if (l.charCodeAt(g + w) === 47) return l.slice(g + w + 1);
                    if (w === 0) return l.slice(g + w)
                  } else m > p && (u.charCodeAt(h + w) === 47 ? y = w : w === 0 && (y = 0));
                  break
                }
                var N = u.charCodeAt(h + w);
                if (N !== l.charCodeAt(g + w)) break;
                N === 47 && (y = w)
              }
              var b = "";
              for (w = h + y + 1; w <= f; ++w) w !== f && u.charCodeAt(w) !== 47 || (b.length === 0 ? b += ".." : b += "/..");
              return b.length > 0 ? b + l.slice(g + y) : (g += y, l.charCodeAt(g) === 47 && ++g, l.slice(g))
            },
            _makeLong: function(u) {
              return u
            },
            dirname: function(u) {
              if (s(u), u.length === 0) return ".";
              for (var l = u.charCodeAt(0), h = l === 47, f = -1, m = !0, g = u.length - 1; g >= 1; --g)
                if ((l = u.charCodeAt(g)) === 47) {
                  if (!m) {
                    f = g;
                    break
                  }
                } else m = !1;
              return f === -1 ? h ? "/" : "." : h && f === 1 ? "//" : u.slice(0, f)
            },
            basename: function(u, l) {
              if (l !== void 0 && typeof l != "string") throw new TypeError('"ext" argument must be a string');
              s(u);
              var h, f = 0,
                m = -1,
                g = !0;
              if (l !== void 0 && l.length > 0 && l.length <= u.length) {
                if (l.length === u.length && l === u) return "";
                var d = l.length - 1,
                  p = -1;
                for (h = u.length - 1; h >= 0; --h) {
                  var y = u.charCodeAt(h);
                  if (y === 47) {
                    if (!g) {
                      f = h + 1;
                      break
                    }
                  } else p === -1 && (g = !1, p = h + 1), d >= 0 && (y === l.charCodeAt(d) ? --d == -1 && (m = h) : (d = -1, m = p))
                }
                return f === m ? m = p : m === -1 && (m = u.length), u.slice(f, m)
              }
              for (h = u.length - 1; h >= 0; --h)
                if (u.charCodeAt(h) === 47) {
                  if (!g) {
                    f = h + 1;
                    break
                  }
                } else m === -1 && (g = !1, m = h + 1);
              return m === -1 ? "" : u.slice(f, m)
            },
            extname: function(u) {
              s(u);
              for (var l = -1, h = 0, f = -1, m = !0, g = 0, d = u.length - 1; d >= 0; --d) {
                var p = u.charCodeAt(d);
                if (p !== 47) f === -1 && (m = !1, f = d + 1), p === 46 ? l === -1 ? l = d : g !== 1 && (g = 1) : l !== -1 && (g = -1);
                else if (!m) {
                  h = d + 1;
                  break
                }
              }
              return l === -1 || f === -1 || g === 0 || g === 1 && l === f - 1 && l === h + 1 ? "" : u.slice(l, f)
            },
            format: function(u) {
              if (u === null || typeof u != "object") throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof u);
              return (function(l, h) {
                var f = h.dir || h.root,
                  m = h.base || (h.name || "") + (h.ext || "");
                return f ? f === h.root ? f + m : f + "/" + m : m
              })(0, u)
            },
            parse: function(u) {
              s(u);
              var l = {
                root: "",
                dir: "",
                base: "",
                ext: "",
                name: ""
              };
              if (u.length === 0) return l;
              var h, f = u.charCodeAt(0),
                m = f === 47;
              m ? (l.root = "/", h = 1) : h = 0;
              for (var g = -1, d = 0, p = -1, y = !0, w = u.length - 1, N = 0; w >= h; --w)
                if ((f = u.charCodeAt(w)) !== 47) p === -1 && (y = !1, p = w + 1), f === 46 ? g === -1 ? g = w : N !== 1 && (N = 1) : g !== -1 && (N = -1);
                else if (!y) {
                d = w + 1;
                break
              }
              return g === -1 || p === -1 || N === 0 || N === 1 && g === p - 1 && g === d + 1 ? p !== -1 && (l.base = l.name = d === 0 && m ? u.slice(1, p) : u.slice(d, p)) : (d === 0 && m ? (l.name = u.slice(1, g), l.base = u.slice(1, p)) : (l.name = u.slice(d, g), l.base = u.slice(d, p)), l.ext = u.slice(g, p)), d > 0 ? l.dir = u.slice(0, d - 1) : m && (l.dir = "/"), l
            },
            sep: "/",
            delimiter: ":",
            win32: null,
            posix: null
          };
          o.posix = o, i.exports = o
        }
      },
      e = {};

    function n(i) {
      var s = e[i];
      if (s !== void 0) return s.exports;
      var a = e[i] = {
        exports: {}
      };
      return t[i](a, a.exports, n), a.exports
    }
    n.d = (i, s) => {
      for (var a in s) n.o(s, a) && !n.o(i, a) && Object.defineProperty(i, a, {
        enumerable: !0,
        get: s[a]
      })
    }, n.o = (i, s) => Object.prototype.hasOwnProperty.call(i, s), n.r = i => {
      typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(i, Symbol.toStringTag, {
        value: "Module"
      }), Object.defineProperty(i, "__esModule", {
        value: !0
      })
    };
    var r = {};
    (() => {
      let i;
      n.r(r), n.d(r, {
        URI: () => m,
        Utils: () => V
      }), typeof process == "object" ? i = process.platform === "win32" : typeof navigator == "object" && (i = navigator.userAgent.indexOf("Windows") >= 0);
      const s = /^\w[\w\d+.-]*$/,
        a = /^\//,
        o = /^\/\//;

      function u(T, x) {
        if (!T.scheme && x) throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${T.authority}", path: "${T.path}", query: "${T.query}", fragment: "${T.fragment}"}`);
        if (T.scheme && !s.test(T.scheme)) throw new Error("[UriError]: Scheme contains illegal characters.");
        if (T.path) {
          if (T.authority) {
            if (!a.test(T.path)) throw new Error('[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash ("/") character')
          } else if (o.test(T.path)) throw new Error('[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters ("//")')
        }
      }
      const l = "",
        h = "/",
        f = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
      class m {
        constructor(x, S, C, I, F, D = !1) {
          nt(this, "scheme");
          nt(this, "authority");
          nt(this, "path");
          nt(this, "query");
          nt(this, "fragment");
          typeof x == "object" ? (this.scheme = x.scheme || l, this.authority = x.authority || l, this.path = x.path || l, this.query = x.query || l, this.fragment = x.fragment || l) : (this.scheme = (function(B, X) {
            return B || X ? B : "file"
          })(x, D), this.authority = S || l, this.path = (function(B, X) {
            switch (B) {
              case "https":
              case "http":
              case "file":
                X ? X[0] !== h && (X = h + X) : X = h
            }
            return X
          })(this.scheme, C || l), this.query = I || l, this.fragment = F || l, u(this, D))
        }
        static isUri(x) {
          return x instanceof m || !!x && typeof x.authority == "string" && typeof x.fragment == "string" && typeof x.path == "string" && typeof x.query == "string" && typeof x.scheme == "string" && typeof x.fsPath == "string" && typeof x.with == "function" && typeof x.toString == "function"
        }
        get fsPath() {
          return N(this)
        }
        with(x) {
          if (!x) return this;
          let {
            scheme: S,
            authority: C,
            path: I,
            query: F,
            fragment: D
          } = x;
          return S === void 0 ? S = this.scheme : S === null && (S = l), C === void 0 ? C = this.authority : C === null && (C = l), I === void 0 ? I = this.path : I === null && (I = l), F === void 0 ? F = this.query : F === null && (F = l), D === void 0 ? D = this.fragment : D === null && (D = l), S === this.scheme && C === this.authority && I === this.path && F === this.query && D === this.fragment ? this : new d(S, C, I, F, D)
        }
        static parse(x, S = !1) {
          const C = f.exec(x);
          return C ? new d(C[2] || l, A(C[4] || l), A(C[5] || l), A(C[7] || l), A(C[9] || l), S) : new d(l, l, l, l, l)
        }
        static file(x) {
          let S = l;
          if (i && (x = x.replace(/\\/g, h)), x[0] === h && x[1] === h) {
            const C = x.indexOf(h, 2);
            C === -1 ? (S = x.substring(2), x = h) : (S = x.substring(2, C), x = x.substring(C) || h)
          }
          return new d("file", S, x, l, l)
        }
        static from(x) {
          const S = new d(x.scheme, x.authority, x.path, x.query, x.fragment);
          return u(S, !0), S
        }
        toString(x = !1) {
          return b(this, x)
        }
        toJSON() {
          return this
        }
        static revive(x) {
          if (x) {
            if (x instanceof m) return x;
            {
              const S = new d(x);
              return S._formatted = x.external, S._fsPath = x._sep === g ? x.fsPath : null, S
            }
          }
          return x
        }
      }
      const g = i ? 1 : void 0;
      class d extends m {
        constructor() {
          super(...arguments);
          nt(this, "_formatted", null);
          nt(this, "_fsPath", null)
        }
        get fsPath() {
          return this._fsPath || (this._fsPath = N(this)), this._fsPath
        }
        toString(S = !1) {
          return S ? b(this, !0) : (this._formatted || (this._formatted = b(this, !1)), this._formatted)
        }
        toJSON() {
          const S = {
            $mid: 1
          };
          return this._fsPath && (S.fsPath = this._fsPath, S._sep = g), this._formatted && (S.external = this._formatted), this.path && (S.path = this.path), this.scheme && (S.scheme = this.scheme), this.authority && (S.authority = this.authority), this.query && (S.query = this.query), this.fragment && (S.fragment = this.fragment), S
        }
      }
      const p = {
        58: "%3A",
        47: "%2F",
        63: "%3F",
        35: "%23",
        91: "%5B",
        93: "%5D",
        64: "%40",
        33: "%21",
        36: "%24",
        38: "%26",
        39: "%27",
        40: "%28",
        41: "%29",
        42: "%2A",
        43: "%2B",
        44: "%2C",
        59: "%3B",
        61: "%3D",
        32: "%20"
      };

      function y(T, x, S) {
        let C, I = -1;
        for (let F = 0; F < T.length; F++) {
          const D = T.charCodeAt(F);
          if (D >= 97 && D <= 122 || D >= 65 && D <= 90 || D >= 48 && D <= 57 || D === 45 || D === 46 || D === 95 || D === 126 || x && D === 47 || S && D === 91 || S && D === 93 || S && D === 58) I !== -1 && (C += encodeURIComponent(T.substring(I, F)), I = -1), C !== void 0 && (C += T.charAt(F));
          else {
            C === void 0 && (C = T.substr(0, F));
            const B = p[D];
            B !== void 0 ? (I !== -1 && (C += encodeURIComponent(T.substring(I, F)), I = -1), C += B) : I === -1 && (I = F)
          }
        }
        return I !== -1 && (C += encodeURIComponent(T.substring(I))), C !== void 0 ? C : T
      }

      function w(T) {
        let x;
        for (let S = 0; S < T.length; S++) {
          const C = T.charCodeAt(S);
          C === 35 || C === 63 ? (x === void 0 && (x = T.substr(0, S)), x += p[C]) : x !== void 0 && (x += T[S])
        }
        return x !== void 0 ? x : T
      }

      function N(T, x) {
        let S;
        return S = T.authority && T.path.length > 1 && T.scheme === "file" ? `//${T.authority}${T.path}` : T.path.charCodeAt(0) === 47 && (T.path.charCodeAt(1) >= 65 && T.path.charCodeAt(1) <= 90 || T.path.charCodeAt(1) >= 97 && T.path.charCodeAt(1) <= 122) && T.path.charCodeAt(2) === 58 ? T.path[1].toLowerCase() + T.path.substr(2) : T.path, i && (S = S.replace(/\//g, "\\")), S
      }

      function b(T, x) {
        const S = x ? w : y;
        let C = "",
          {
            scheme: I,
            authority: F,
            path: D,
            query: B,
            fragment: X
          } = T;
        if (I && (C += I, C += ":"), (F || I === "file") && (C += h, C += h), F) {
          let z = F.indexOf("@");
          if (z !== -1) {
            const Ae = F.substr(0, z);
            F = F.substr(z + 1), z = Ae.lastIndexOf(":"), z === -1 ? C += S(Ae, !1, !1) : (C += S(Ae.substr(0, z), !1, !1), C += ":", C += S(Ae.substr(z + 1), !1, !0)), C += "@"
          }
          F = F.toLowerCase(), z = F.lastIndexOf(":"), z === -1 ? C += S(F, !1, !0) : (C += S(F.substr(0, z), !1, !0), C += F.substr(z))
        }
        if (D) {
          if (D.length >= 3 && D.charCodeAt(0) === 47 && D.charCodeAt(2) === 58) {
            const z = D.charCodeAt(1);
            z >= 65 && z <= 90 && (D = `/${String.fromCharCode(z+32)}:${D.substr(3)}`)
          } else if (D.length >= 2 && D.charCodeAt(1) === 58) {
            const z = D.charCodeAt(0);
            z >= 65 && z <= 90 && (D = `${String.fromCharCode(z+32)}:${D.substr(2)}`)
          }
          C += S(D, !0, !1)
        }
        return B && (C += "?", C += S(B, !1, !1)), X && (C += "#", C += x ? X : y(X, !1, !1)), C
      }

      function _(T) {
        try {
          return decodeURIComponent(T)
        } catch {
          return T.length > 3 ? T.substr(0, 3) + _(T.substr(3)) : T
        }
      }
      const L = /(%[0-9A-Za-z][0-9A-Za-z])+/g;

      function A(T) {
        return T.match(L) ? T.replace(L, (x => _(x))) : T
      }
      var v = n(470);
      const k = v.posix || v,
        M = "/";
      var V;
      (function(T) {
        T.joinPath = function(x, ...S) {
          return x.with({
            path: k.join(x.path, ...S)
          })
        }, T.resolvePath = function(x, ...S) {
          let C = x.path,
            I = !1;
          C[0] !== M && (C = M + C, I = !0);
          let F = k.resolve(C, ...S);
          return I && F[0] === M && !x.authority && (F = F.substring(1)), x.with({
            path: F
          })
        }, T.dirname = function(x) {
          if (x.path.length === 0 || x.path === M) return x;
          let S = k.dirname(x.path);
          return S.length === 1 && S.charCodeAt(0) === 46 && (S = ""), x.with({
            path: S
          })
        }, T.basename = function(x) {
          return k.basename(x.path)
        }, T.extname = function(x) {
          return k.extname(x.path)
        }
      })(V || (V = {}))
    })(), Fo = r
  })();
  const {
    URI: Dt,
    Utils: X1
  } = Fo;

  function p1(t, e) {
    if (typeof t != "string") throw new TypeError("Expected a string");
    const n = String(t);
    let r = "";
    const i = !!e,
      s = !!e;
    let a = !1;
    const o = e && typeof e.flags == "string" ? e.flags : "";
    let u;
    for (let l = 0, h = n.length; l < h; l++) switch (u = n[l], u) {
      case "/":
      case "$":
      case "^":
      case "+":
      case ".":
      case "(":
      case ")":
      case "=":
      case "!":
      case "|":
        r += "\\" + u;
        break;
      case "?":
        if (i) {
          r += ".";
          break
        }
      case "[":
      case "]":
        if (i) {
          r += u;
          break
        }
      case "{":
        if (i) {
          a = !0, r += "(";
          break
        }
      case "}":
        if (i) {
          a = !1, r += ")";
          break
        }
      case ",":
        if (a) {
          r += "|";
          break
        }
        r += "\\" + u;
        break;
      case "*":
        const f = n[l - 1];
        let m = 1;
        for (; n[l + 1] === "*";) m++, l++;
        const g = n[l + 1];
        s ? m > 1 && (f === "/" || f === void 0 || f === "{" || f === ",") && (g === "/" || g === void 0 || g === "," || g === "}") ? (g === "/" ? l++ : f === "/" && r.endsWith("\\/") && (r = r.substr(0, r.length - 2)), r += "((?:[^/]*(?:/|$))*)") : r += "([^/]*)" : r += ".*";
        break;
      default:
        r += u
    }
    return (!o || !~o.indexOf("g")) && (r = "^" + r + "$"), new RegExp(r, o)
  }
  const b1 = "!",
    y1 = "/";
  class w1 {
    constructor(e, n, r) {
      this.folderUri = n, this.uris = r, this.globWrappers = [];
      try {
        for (let i of e) {
          const s = i[0] !== b1;
          s || (i = i.substring(1)), i.length > 0 && (i[0] === y1 && (i = i.substring(1)), this.globWrappers.push({
            regexp: p1("**/" + i, {
              extended: !0,
              globstar: !0
            }),
            include: s
          }))
        }
        n && (n = Do(n), n.endsWith("/") || (n = n + "/"), this.folderUri = n)
      } catch {
        this.globWrappers.length = 0, this.uris = []
      }
    }
    matchesPattern(e) {
      if (this.folderUri && !e.startsWith(this.folderUri)) return !1;
      let n = !1;
      for (const {
          regexp: r,
          include: i
        }
        of this.globWrappers) r.test(e) && (n = i);
      return n
    }
    getURIs() {
      return this.uris
    }
  }
  class x1 {
    constructor(e, n, r) {
      this.service = e, this.uri = n, this.dependencies = new Set, this.anchors = void 0, r && (this.unresolvedSchema = this.service.promise.resolve(new ln(r)))
    }
    getUnresolvedSchema() {
      return this.unresolvedSchema || (this.unresolvedSchema = this.service.loadSchema(this.uri)), this.unresolvedSchema
    }
    getResolvedSchema() {
      return this.resolvedSchema || (this.resolvedSchema = this.getUnresolvedSchema().then(e => this.service.resolveSchemaContent(e, this))), this.resolvedSchema
    }
    clearSchema() {
      const e = !!this.unresolvedSchema;
      return this.resolvedSchema = void 0, this.unresolvedSchema = void 0, this.dependencies.clear(), this.anchors = void 0, e
    }
  }
  class ln {
    constructor(e, n = []) {
      this.schema = e, this.errors = n
    }
  }
  class Vo {
    constructor(e, n = [], r = [], i) {
      this.schema = e, this.errors = n, this.warnings = r, this.schemaDraft = i
    }
    getSection(e) {
      const n = this.getSectionRecursive(e, this.schema);
      if (n) return xe(n)
    }
    getSectionRecursive(e, n) {
      if (!n || typeof n == "boolean" || e.length === 0) return n;
      const r = e.shift();
      if (n.properties && typeof n.properties[r]) return this.getSectionRecursive(e, n.properties[r]);
      if (n.patternProperties)
        for (const i of Object.keys(n.patternProperties)) {
          const s = Tn(i);
          if (s != null && s.test(r)) return this.getSectionRecursive(e, n.patternProperties[i])
        } else {
          if (typeof n.additionalProperties == "object") return this.getSectionRecursive(e, n.additionalProperties);
          if (r.match("[0-9]+")) {
            if (Array.isArray(n.items)) {
              const i = parseInt(r, 10);
              if (!isNaN(i) && n.items[i]) return this.getSectionRecursive(e, n.items[i])
            } else if (n.items) return this.getSectionRecursive(e, n.items)
          }
        }
    }
  }
  class v1 {
    constructor(e, n, r) {
      this.contextService = n, this.requestService = e, this.promiseConstructor = r || Promise, this.callOnDispose = [], this.contributionSchemas = {}, this.contributionAssociations = [], this.schemasById = {}, this.filePatternAssociations = [], this.registeredSchemasIds = {}
    }
    getRegisteredSchemaIds(e) {
      return Object.keys(this.registeredSchemasIds).filter(n => {
        const r = Dt.parse(n).scheme;
        return r !== "schemaservice" && (!e || e(r))
      })
    }
    get promise() {
      return this.promiseConstructor
    }
    dispose() {
      for (; this.callOnDispose.length > 0;) this.callOnDispose.pop()()
    }
    onResourceChange(e) {
      this.cachedSchemaForResource = void 0;
      let n = !1;
      e = tt(e);
      const r = [e],
        i = Object.keys(this.schemasById).map(s => this.schemasById[s]);
      for (; r.length;) {
        const s = r.pop();
        for (let a = 0; a < i.length; a++) {
          const o = i[a];
          o && (o.uri === s || o.dependencies.has(s)) && (o.uri !== s && r.push(o.uri), o.clearSchema() && (n = !0), i[a] = void 0)
        }
      }
      return n
    }
    setSchemaContributions(e) {
      if (e.schemas) {
        const n = e.schemas;
        for (const r in n) {
          const i = tt(r);
          this.contributionSchemas[i] = this.addSchemaHandle(i, n[r])
        }
      }
      if (Array.isArray(e.schemaAssociations)) {
        const n = e.schemaAssociations;
        for (let r of n) {
          const i = r.uris.map(tt),
            s = this.addFilePatternAssociation(r.pattern, r.folderUri, i);
          this.contributionAssociations.push(s)
        }
      }
    }
    addSchemaHandle(e, n) {
      const r = new x1(this, e, n);
      return this.schemasById[e] = r, r
    }
    getOrAddSchemaHandle(e, n) {
      return this.schemasById[e] || this.addSchemaHandle(e, n)
    }
    addFilePatternAssociation(e, n, r) {
      const i = new w1(e, n, r);
      return this.filePatternAssociations.push(i), i
    }
    registerExternalSchema(e) {
      const n = tt(e.uri);
      return this.registeredSchemasIds[n] = !0, this.cachedSchemaForResource = void 0, e.fileMatch && e.fileMatch.length && this.addFilePatternAssociation(e.fileMatch, e.folderUri, [n]), e.schema ? this.addSchemaHandle(n, e.schema) : this.getOrAddSchemaHandle(n)
    }
    clearExternalSchemas() {
      this.schemasById = {}, this.filePatternAssociations = [], this.registeredSchemasIds = {}, this.cachedSchemaForResource = void 0;
      for (const e in this.contributionSchemas) this.schemasById[e] = this.contributionSchemas[e], this.registeredSchemasIds[e] = !0;
      for (const e of this.contributionAssociations) this.filePatternAssociations.push(e)
    }
    getResolvedSchema(e) {
      const n = tt(e),
        r = this.schemasById[n];
      return r ? r.getResolvedSchema() : this.promise.resolve(void 0)
    }
    loadSchema(e) {
      if (!this.requestService) {
        const n = P("Unable to load schema from '{0}'. No schema request service available", un(e));
        return this.promise.resolve(new ln({}, [n]))
      }
      return e.startsWith("http://json-schema.org/") && (e = "https" + e.substring(4)), this.requestService(e).then(n => {
        if (!n) {
          const a = P("Unable to load schema from '{0}': No content.", un(e));
          return new ln({}, [a])
        }
        const r = [];
        n.charCodeAt(0) === 65279 && (r.push(P("Problem reading content from '{0}': UTF-8 with BOM detected, only UTF 8 is allowed.", un(e))), n = n.trimStart());
        let i = {};
        const s = [];
        return i = Bc(n, s), s.length && r.push(P("Unable to parse content from '{0}': Parse error at offset {1}.", un(e), s[0].offset)), new ln(i, r)
      }, n => {
        let r = n.toString();
        const i = n.toString().split("Error: ");
        return i.length > 1 && (r = i[1]), nn(r, ".") && (r = r.substr(0, r.length - 1)), new ln({}, [P("Unable to load schema from '{0}': {1}.", un(e), r)])
      })
    }
    resolveSchemaContent(e, n) {
      const r = e.errors.slice(0),
        i = e.schema;
      let s = i.$schema ? tt(i.$schema) : void 0;
      if (s === "http://json-schema.org/draft-03/schema") return this.promise.resolve(new Vo({}, [P("Draft-03 schemas are not supported.")], [], s));
      let a = new Set;
      const o = this.contextService,
        u = (p, y) => {
          y = decodeURIComponent(y);
          let w = p;
          return y[0] === "/" && (y = y.substring(1)), y.split("/").some(N => (N = N.replace(/~1/g, "/").replace(/~0/g, "~"), w = w[N], !w)), w
        },
        l = (p, y, w) => (y.anchors || (y.anchors = d(p)), y.anchors.get(w)),
        h = (p, y) => {
          for (const w in y) y.hasOwnProperty(w) && w !== "id" && w !== "$id" && (p[w] = y[w])
        },
        f = (p, y, w, N) => {
          let b;
          N === void 0 || N.length === 0 ? b = y : N.charAt(0) === "/" ? b = u(y, N) : b = l(y, w, N), b ? h(p, b) : r.push(P("$ref '{0}' in '{1}' can not be resolved.", N || "", w.uri))
        },
        m = (p, y, w, N) => {
          o && !/^[A-Za-z][A-Za-z0-9+\-.+]*:\/\/.*/.test(y) && (y = o.resolveRelativePath(y, N.uri)), y = tt(y);
          const b = this.getOrAddSchemaHandle(y);
          return b.getUnresolvedSchema().then(_ => {
            if (N.dependencies.add(y), _.errors.length) {
              const L = w ? y + "#" + w : y;
              r.push(P("Problems loading reference '{0}': {1}", L, _.errors[0]))
            }
            return f(p, _.schema, b, w), g(p, _.schema, b)
          })
        },
        g = (p, y, w) => {
          const N = [];
          return this.traverseNodes(p, b => {
            const _ = new Set;
            for (; b.$ref;) {
              const L = b.$ref,
                A = L.split("#", 2);
              if (delete b.$ref, A[0].length > 0) {
                N.push(m(b, A[0], A[1], w));
                return
              } else if (!_.has(L)) {
                const v = A[1];
                f(b, y, w, v), _.add(L)
              }
            }
            b.$recursiveRef && a.add("$recursiveRef"), b.$dynamicRef && a.add("$dynamicRef")
          }), this.promise.all(N)
        },
        d = p => {
          const y = new Map;
          return this.traverseNodes(p, w => {
            const N = w.$id || w.id,
              b = Aa(N) && N.charAt(0) === "#" ? N.substring(1) : w.$anchor;
            b && (y.has(b) ? r.push(P("Duplicate anchor declaration: '{0}'", b)) : y.set(b, w)), w.$recursiveAnchor && a.add("$recursiveAnchor"), w.$dynamicAnchor && a.add("$dynamicAnchor")
          }), y
        };
      return g(i, i, n).then(p => {
        let y = [];
        return a.size && y.push(P("The schema uses meta-schema features ({0}) that are not yet supported by the validator.", Array.from(a.keys()).join(", "))), new Vo(i, r, y, s)
      })
    }
    traverseNodes(e, n) {
      if (!e || typeof e != "object") return Promise.resolve(null);
      const r = new Set,
        i = (...h) => {
          for (const f of h) Ke(f) && u.push(f)
        },
        s = (...h) => {
          for (const f of h)
            if (Ke(f))
              for (const m in f) {
                const d = f[m];
                Ke(d) && u.push(d)
              }
        },
        a = (...h) => {
          for (const f of h)
            if (Array.isArray(f))
              for (const m of f) Ke(m) && u.push(m)
        },
        o = h => {
          if (Array.isArray(h))
            for (const f of h) Ke(f) && u.push(f);
          else Ke(h) && u.push(h)
        },
        u = [e];
      let l = u.pop();
      for (; l;) r.has(l) || (r.add(l), n(l), i(l.additionalItems, l.additionalProperties, l.not, l.contains, l.propertyNames, l.if, l.then, l.else, l.unevaluatedItems, l.unevaluatedProperties), s(l.definitions, l.$defs, l.properties, l.patternProperties, l.dependencies, l.dependentSchemas), a(l.anyOf, l.allOf, l.oneOf, l.prefixItems), o(l.items)), l = u.pop()
    }
    getSchemaFromProperty(e, n) {
      var r, i;
      if (((r = n.root) == null ? void 0 : r.type) === "object") {
        for (const s of n.root.properties)
          if (s.keyNode.value === "$schema" && ((i = s.valueNode) == null ? void 0 : i.type) === "string") {
            let a = s.valueNode.value;
            return this.contextService && !/^\w[\w\d+.-]*:/.test(a) && (a = this.contextService.resolveRelativePath(a, e)), a
          }
      }
    }
    getAssociatedSchemas(e) {
      const n = Object.create(null),
        r = [],
        i = Do(e);
      for (const s of this.filePatternAssociations)
        if (s.matchesPattern(i))
          for (const a of s.getURIs()) n[a] || (r.push(a), n[a] = !0);
      return r
    }
    getSchemaURIsForResource(e, n) {
      let r = n && this.getSchemaFromProperty(e, n);
      return r ? [r] : this.getAssociatedSchemas(e)
    }
    getSchemaForResource(e, n) {
      if (n) {
        let s = this.getSchemaFromProperty(e, n);
        if (s) {
          const a = tt(s);
          return this.getOrAddSchemaHandle(a).getResolvedSchema()
        }
      }
      if (this.cachedSchemaForResource && this.cachedSchemaForResource.resource === e) return this.cachedSchemaForResource.resolvedSchema;
      const r = this.getAssociatedSchemas(e),
        i = r.length > 0 ? this.createCombinedSchema(e, r).getResolvedSchema() : this.promise.resolve(void 0);
      return this.cachedSchemaForResource = {
        resource: e,
        resolvedSchema: i
      }, i
    }
    createCombinedSchema(e, n) {
      if (n.length === 1) return this.getOrAddSchemaHandle(n[0]);
      {
        const r = "schemaservice://combinedSchema/" + encodeURIComponent(e),
          i = {
            allOf: n.map(s => ({
              $ref: s
            }))
          };
        return this.addSchemaHandle(r, i)
      }
    }
    getMatchingSchemas(e, n, r) {
      if (r) {
        const i = r.id || "schemaservice://untitled/matchingSchemas/" + L1++;
        return this.addSchemaHandle(i, r).getResolvedSchema().then(a => n.getMatchingSchemas(a.schema).filter(o => !o.inverted))
      }
      return this.getSchemaForResource(e.uri, n).then(i => i ? n.getMatchingSchemas(i.schema).filter(s => !s.inverted) : [])
    }
  }
  let L1 = 0;

  function tt(t) {
    try {
      return Dt.parse(t).toString(!0)
    } catch {
      return t
    }
  }

  function Do(t) {
    try {
      return Dt.parse(t).with({
        fragment: null,
        query: null
      }).toString(!0)
    } catch {
      return t
    }
  }

  function un(t) {
    try {
      const e = Dt.parse(t);
      if (e.scheme === "file") return e.fsPath
    } catch {}
    return t
  }

  function N1(t, e) {
    const n = [],
      r = [],
      i = [];
    let s = -1;
    const a = lt(t.getText(), !1);
    let o = a.scan();

    function u(d) {
      n.push(d), r.push(i.length)
    }
    for (; o !== 17;) {
      switch (o) {
        case 1:
        case 3: {
          const d = t.positionAt(a.getTokenOffset()).line,
            p = {
              startLine: d,
              endLine: d,
              kind: o === 1 ? "object" : "array"
            };
          i.push(p);
          break
        }
        case 2:
        case 4: {
          const d = o === 2 ? "object" : "array";
          if (i.length > 0 && i[i.length - 1].kind === d) {
            const p = i.pop(),
              y = t.positionAt(a.getTokenOffset()).line;
            p && y > p.startLine + 1 && s !== p.startLine && (p.endLine = y - 1, u(p), s = p.startLine)
          }
          break
        }
        case 13: {
          const d = t.positionAt(a.getTokenOffset()).line,
            p = t.positionAt(a.getTokenOffset() + a.getTokenLength()).line;
          a.getTokenError() === 1 && d + 1 < t.lineCount ? a.setPosition(t.offsetAt(ee.create(d + 1, 0))) : d < p && (u({
            startLine: d,
            endLine: p,
            kind: rn.Comment
          }), s = d);
          break
        }
        case 12: {
          const p = t.getText().substr(a.getTokenOffset(), a.getTokenLength()).match(/^\/\/\s*#(region\b)|(endregion\b)/);
          if (p) {
            const y = t.positionAt(a.getTokenOffset()).line;
            if (p[1]) {
              const w = {
                startLine: y,
                endLine: y,
                kind: rn.Region
              };
              i.push(w)
            } else {
              let w = i.length - 1;
              for (; w >= 0 && i[w].kind !== rn.Region;) w--;
              if (w >= 0) {
                const N = i[w];
                i.length = w, y > N.startLine && s !== N.startLine && (N.endLine = y, u(N), s = N.startLine)
              }
            }
          }
          break
        }
      }
      o = a.scan()
    }
    const l = e && e.rangeLimit;
    if (typeof l != "number" || n.length <= l) return n;
    e && e.onRangeLimitExceeded && e.onRangeLimitExceeded(t.uri);
    const h = [];
    for (let d of r) d < 30 && (h[d] = (h[d] || 0) + 1);
    let f = 0,
      m = 0;
    for (let d = 0; d < h.length; d++) {
      const p = h[d];
      if (p) {
        if (p + f > l) {
          m = d;
          break
        }
        f += p
      }
    }
    const g = [];
    for (let d = 0; d < n.length; d++) {
      const p = r[d];
      typeof p == "number" && (p < m || p === m && f++ < l) && g.push(n[d])
    }
    return g
  }

  function _1(t, e, n) {
    function r(o) {
      let u = t.offsetAt(o),
        l = n.getNodeFromOffset(u, !0);
      const h = [];
      for (; l;) {
        switch (l.type) {
          case "string":
          case "object":
          case "array":
            const m = l.offset + 1,
              g = l.offset + l.length - 1;
            m < g && u >= m && u <= g && h.push(i(m, g)), h.push(i(l.offset, l.offset + l.length));
            break;
          case "number":
          case "boolean":
          case "null":
          case "property":
            h.push(i(l.offset, l.offset + l.length));
            break
        }
        if (l.type === "property" || l.parent && l.parent.type === "array") {
          const m = a(l.offset + l.length, 5);
          m !== -1 && h.push(i(l.offset, m))
        }
        l = l.parent
      }
      let f;
      for (let m = h.length - 1; m >= 0; m--) f = Fn.create(h[m], f);
      return f || (f = Fn.create(W.create(o, o))), f
    }

    function i(o, u) {
      return W.create(t.positionAt(o), t.positionAt(u))
    }
    const s = lt(t.getText(), !0);

    function a(o, u) {
      return s.setPosition(o), s.scan() === u ? s.getTokenOffset() + s.getTokenLength() : -1
    }
    return e.map(r)
  }

  function ri(t, e, n) {
    let r;
    if (n) {
      const s = t.offsetAt(n.start),
        a = t.offsetAt(n.end) - s;
      r = {
        offset: s,
        length: a
      }
    }
    const i = {
      tabSize: e ? e.tabSize : 4,
      insertSpaces: (e == null ? void 0 : e.insertSpaces) === !0,
      insertFinalNewline: (e == null ? void 0 : e.insertFinalNewline) === !0,
      eol: `
`,
      keepLines: (e == null ? void 0 : e.keepLines) === !0
    };
    return Wc(t.getText(), r, i).map(s => De.replace(W.create(t.positionAt(s.offset), t.positionAt(s.offset + s.length)), s.content))
  }
  var se;
  (function(t) {
    t[t.Object = 0] = "Object", t[t.Array = 1] = "Array"
  })(se || (se = {}));
  class On {
    constructor(e, n) {
      this.propertyName = e ?? "", this.beginningLineNumber = n, this.childrenProperties = [], this.lastProperty = !1, this.noKeyName = !1
    }
    addChildProperty(e) {
      if (e.parent = this, this.childrenProperties.length > 0) {
        let n = 0;
        e.noKeyName ? n = this.childrenProperties.length : n = A1(this.childrenProperties, e, S1), n < 0 && (n = n * -1 - 1), this.childrenProperties.splice(n, 0, e)
      } else this.childrenProperties.push(e);
      return e
    }
  }

  function S1(t, e) {
    const n = t.propertyName.toLowerCase(),
      r = e.propertyName.toLowerCase();
    return n < r ? -1 : n > r ? 1 : 0
  }

  function A1(t, e, n) {
    const r = e.propertyName.toLowerCase(),
      i = t[0].propertyName.toLowerCase(),
      s = t[t.length - 1].propertyName.toLowerCase();
    if (r < i) return 0;
    if (r > s) return t.length;
    let a = 0,
      o = t.length - 1;
    for (; a <= o;) {
      let u = o + a >> 1,
        l = n(e, t[u]);
      if (l > 0) a = u + 1;
      else if (l < 0) o = u - 1;
      else return u
    }
    return -a - 1
  }

  function k1(t, e) {
    const n = {
        ...e,
        keepLines: !1
      },
      r = Me.applyEdits(t, ri(t, n, void 0)),
      i = Me.create("test://test.json", "json", 0, r),
      s = R1(i),
      a = E1(i, s),
      o = ri(a, n, void 0),
      u = Me.applyEdits(a, o);
    return [De.replace(W.create(ee.create(0, 0), t.positionAt(t.getText().length)), u)]
  }

  function R1(t) {
    const e = t.getText(),
      n = lt(e, !1);
    let r = new On,
      i = r,
      s = r,
      a = r,
      o, u = 0,
      l = 0,
      h, f, m = -1,
      g = -1,
      d = 0,
      p = 0,
      y = [],
      w = !1,
      N = !1;
    for (;
      (o = n.scan()) !== 17;) {
      if (w === !0 && o !== 14 && o !== 15 && o !== 12 && o !== 13 && s.endLineNumber === void 0) {
        let b = n.getTokenStartLine();
        f === 2 || f === 4 ? a.endLineNumber = b - 1 : s.endLineNumber = b - 1, d = b, w = !1
      }
      if (N === !0 && o !== 14 && o !== 15 && o !== 12 && o !== 13 && (d = n.getTokenStartLine(), N = !1), n.getTokenStartLine() !== u) {
        for (let b = u; b < n.getTokenStartLine(); b++) {
          const _ = t.getText(W.create(ee.create(b, 0), ee.create(b + 1, 0))).length;
          l = l + _
        }
        u = n.getTokenStartLine()
      }
      switch (o) {
        case 10: {
          if (h === void 0 || h === 1 || h === 5 && y[y.length - 1] === se.Object) {
            const b = new On(n.getTokenValue(), d);
            a = s, s = i.addChildProperty(b)
          }
          break
        }
        case 3: {
          if (r.beginningLineNumber === void 0 && (r.beginningLineNumber = n.getTokenStartLine()), y[y.length - 1] === se.Object) i = s;
          else if (y[y.length - 1] === se.Array) {
            const b = new On(n.getTokenValue(), d);
            b.noKeyName = !0, a = s, s = i.addChildProperty(b), i = s
          }
          y.push(se.Array), s.type = se.Array, d = n.getTokenStartLine(), d++;
          break
        }
        case 1: {
          if (r.beginningLineNumber === void 0) r.beginningLineNumber = n.getTokenStartLine();
          else if (y[y.length - 1] === se.Array) {
            const b = new On(n.getTokenValue(), d);
            b.noKeyName = !0, a = s, s = i.addChildProperty(b)
          }
          s.type = se.Object, y.push(se.Object), i = s, d = n.getTokenStartLine(), d++;
          break
        }
        case 4: {
          p = n.getTokenStartLine(), y.pop(), s.endLineNumber === void 0 && (h === 2 || h === 4) && (s.endLineNumber = p - 1, s.lastProperty = !0, s.lineWhereToAddComma = m, s.indexWhereToAddComa = g, a = s, s = s ? s.parent : void 0, i = s), r.endLineNumber = p, d = p + 1;
          break
        }
        case 2: {
          p = n.getTokenStartLine(), y.pop(), h !== 1 && (s.endLineNumber === void 0 && (s.endLineNumber = p - 1, s.lastProperty = !0, s.lineWhereToAddComma = m, s.indexWhereToAddComa = g), a = s, s = s ? s.parent : void 0, i = s), r.endLineNumber = n.getTokenStartLine(), d = p + 1;
          break
        }
        case 5: {
          p = n.getTokenStartLine(), s.endLineNumber === void 0 && (y[y.length - 1] === se.Object || y[y.length - 1] === se.Array && (h === 2 || h === 4)) && (s.endLineNumber = p, s.commaIndex = n.getTokenOffset() - l, s.commaLine = p), (h === 2 || h === 4) && (a = s, s = s ? s.parent : void 0, i = s), d = p + 1;
          break
        }
        case 13: {
          h === 5 && m === n.getTokenStartLine() && (y[y.length - 1] === se.Array && (f === 2 || f === 4) || y[y.length - 1] === se.Object) && (y[y.length - 1] === se.Array && (f === 2 || f === 4) || y[y.length - 1] === se.Object) && (s.endLineNumber = void 0, w = !0), (h === 1 || h === 3) && m === n.getTokenStartLine() && (N = !0);
          break
        }
      }
      o !== 14 && o !== 13 && o !== 12 && o !== 15 && (f = h, h = o, m = n.getTokenStartLine(), g = n.getTokenOffset() + n.getTokenLength() - l)
    }
    return r
  }

  function E1(t, e) {
    if (e.childrenProperties.length === 0) return t;
    const n = Me.create("test://test.json", "json", 0, t.getText()),
      r = [];
    for (Oo(r, e, e.beginningLineNumber); r.length > 0;) {
      const i = r.shift(),
        s = i.propertyTreeArray;
      let a = i.beginningLineNumber;
      for (let o = 0; o < s.length; o++) {
        const u = s[o],
          l = W.create(ee.create(u.beginningLineNumber, 0), ee.create(u.endLineNumber + 1, 0)),
          h = t.getText(l),
          f = Me.create("test://test.json", "json", 0, h);
        if (u.lastProperty === !0 && o !== s.length - 1) {
          const d = u.lineWhereToAddComma - u.beginningLineNumber,
            p = u.indexWhereToAddComa,
            y = {
              range: W.create(ee.create(d, p), ee.create(d, p)),
              text: ","
            };
          Me.update(f, [y], 1)
        } else if (u.lastProperty === !1 && o === s.length - 1) {
          const d = u.commaIndex,
            y = u.commaLine - u.beginningLineNumber,
            w = {
              range: W.create(ee.create(y, d), ee.create(y, d + 1)),
              text: ""
            };
          Me.update(f, [w], 1)
        }
        const m = u.endLineNumber - u.beginningLineNumber + 1,
          g = {
            range: W.create(ee.create(a, 0), ee.create(a + m, 0)),
            text: f.getText()
          };
        Me.update(n, [g], 1), Oo(r, u, a), a = a + m
      }
    }
    return n
  }

  function Oo(t, e, n) {
    if (e.childrenProperties.length !== 0)
      if (e.type === se.Object) {
        let r = 1 / 0;
        for (const s of e.childrenProperties) s.beginningLineNumber < r && (r = s.beginningLineNumber);
        const i = r - e.beginningLineNumber;
        n = n + i, t.push(new Bo(n, e.childrenProperties))
      } else e.type === se.Array && $o(t, e, n)
  }

  function $o(t, e, n) {
    for (const r of e.childrenProperties) {
      if (r.type === se.Object) {
        let i = 1 / 0;
        for (const a of r.childrenProperties) a.beginningLineNumber < i && (i = a.beginningLineNumber);
        const s = i - r.beginningLineNumber;
        t.push(new Bo(n + r.beginningLineNumber - e.beginningLineNumber + s, r.childrenProperties))
      }
      r.type === se.Array && $o(t, r, n + r.beginningLineNumber - e.beginningLineNumber)
    }
  }
  class Bo {
    constructor(e, n) {
      this.beginningLineNumber = e, this.propertyTreeArray = n
    }
  }

  function M1(t, e) {
    const n = [];
    return e.visit(r => {
      var i;
      if (r.type === "property" && r.keyNode.value === "$ref" && ((i = r.valueNode) == null ? void 0 : i.type) === "string") {
        const s = r.valueNode.value,
          a = P1(e, s);
        if (a) {
          const o = t.positionAt(a.offset);
          n.push({
            target: `${t.uri}#${o.line+1},${o.character+1}`,
            range: T1(t, r.valueNode)
          })
        }
      }
      return !0
    }), Promise.resolve(n)
  }

  function T1(t, e) {
    return W.create(t.positionAt(e.offset + 1), t.positionAt(e.offset + e.length - 1))
  }

  function P1(t, e) {
    const n = C1(e);
    return n ? ii(n, t.root) : null
  }

  function ii(t, e) {
    if (!e) return null;
    if (t.length === 0) return e;
    const n = t.shift();
    if (e && e.type === "object") {
      const r = e.properties.find(i => i.keyNode.value === n);
      return r ? ii(t, r.valueNode) : null
    } else if (e && e.type === "array" && n.match(/^(0|[1-9][0-9]*)$/)) {
      const r = Number.parseInt(n),
        i = e.items[r];
      return i ? ii(t, i) : null
    }
    return null
  }

  function C1(t) {
    return t === "#" ? [] : t[0] !== "#" || t[1] !== "/" ? null : t.substring(2).split(/\//).map(I1)
  }

  function I1(t) {
    return t.replace(/~1/g, "/").replace(/~0/g, "~")
  }

  function F1(t) {
    const e = t.promiseConstructor || Promise,
      n = new v1(t.schemaRequestService, t.workspaceContext, e);
    n.setSchemaContributions(ni);
    const r = new s1(n, t.contributions, e, t.clientCapabilities),
      i = new a1(n, t.contributions, e),
      s = new d1(n),
      a = new l1(n, e);
    return {
      configure: o => {
        var u;
        n.clearExternalSchemas(), (u = o.schemas) == null || u.forEach(n.registerExternalSchema.bind(n)), a.configure(o)
      },
      resetSchema: o => n.onResourceChange(o),
      doValidation: a.doValidation.bind(a),
      getLanguageStatus: a.getLanguageStatus.bind(a),
      parseJSONDocument: o => i1(o, {
        collectComments: !0
      }),
      newJSONDocument: (o, u) => r1(o, u),
      getMatchingSchemas: n.getMatchingSchemas.bind(n),
      doResolve: r.doResolve.bind(r),
      doComplete: r.doComplete.bind(r),
      findDocumentSymbols: s.findDocumentSymbols.bind(s),
      findDocumentSymbols2: s.findDocumentSymbols2.bind(s),
      findDocumentColors: s.findDocumentColors.bind(s),
      getColorPresentations: s.getColorPresentations.bind(s),
      doHover: i.doHover.bind(i),
      getFoldingRanges: N1,
      getSelectionRanges: _1,
      findDefinition: () => Promise.resolve([]),
      findLinks: M1,
      format: (o, u, l) => ri(o, l, u),
      sort: (o, u) => k1(o, u)
    }
  }
  let Uo;
  typeof fetch < "u" && (Uo = function(t) {
    return fetch(t).then(e => e.text())
  });
  class V1 {
    constructor(e, n) {
      this._ctx = e, this._languageSettings = n.languageSettings, this._languageId = n.languageId, this._languageService = F1({
        workspaceContext: {
          resolveRelativePath: (r, i) => {
            const s = i.substr(0, i.lastIndexOf("/") + 1);
            return $1(s, r)
          }
        },
        schemaRequestService: n.enableSchemaRequest ? Uo : void 0,
        clientCapabilities: Qr.LATEST
      }), this._languageService.configure(this._languageSettings)
    }
    async doValidation(e) {
      let n = this._getTextDocument(e);
      if (n) {
        let r = this._languageService.parseJSONDocument(n);
        return this._languageService.doValidation(n, r, this._languageSettings)
      }
      return Promise.resolve([])
    }
    async doComplete(e, n) {
      let r = this._getTextDocument(e);
      if (!r) return null;
      let i = this._languageService.parseJSONDocument(r);
      return this._languageService.doComplete(r, n, i)
    }
    async doResolve(e) {
      return this._languageService.doResolve(e)
    }
    async doHover(e, n) {
      let r = this._getTextDocument(e);
      if (!r) return null;
      let i = this._languageService.parseJSONDocument(r);
      return this._languageService.doHover(r, n, i)
    }
    async format(e, n, r) {
      let i = this._getTextDocument(e);
      if (!i) return [];
      let s = this._languageService.format(i, n, r);
      return Promise.resolve(s)
    }
    async resetSchema(e) {
      return Promise.resolve(this._languageService.resetSchema(e))
    }
    async findDocumentSymbols(e) {
      let n = this._getTextDocument(e);
      if (!n) return [];
      let r = this._languageService.parseJSONDocument(n),
        i = this._languageService.findDocumentSymbols2(n, r);
      return Promise.resolve(i)
    }
    async findDocumentColors(e) {
      let n = this._getTextDocument(e);
      if (!n) return [];
      let r = this._languageService.parseJSONDocument(n),
        i = this._languageService.findDocumentColors(n, r);
      return Promise.resolve(i)
    }
    async getColorPresentations(e, n, r) {
      let i = this._getTextDocument(e);
      if (!i) return [];
      let s = this._languageService.parseJSONDocument(i),
        a = this._languageService.getColorPresentations(i, s, n, r);
      return Promise.resolve(a)
    }
    async getFoldingRanges(e, n) {
      let r = this._getTextDocument(e);
      if (!r) return [];
      let i = this._languageService.getFoldingRanges(r, n);
      return Promise.resolve(i)
    }
    async getSelectionRanges(e, n) {
      let r = this._getTextDocument(e);
      if (!r) return [];
      let i = this._languageService.parseJSONDocument(r),
        s = this._languageService.getSelectionRanges(r, n, i);
      return Promise.resolve(s)
    }
    async parseJSONDocument(e) {
      let n = this._getTextDocument(e);
      if (!n) return null;
      let r = this._languageService.parseJSONDocument(n);
      return Promise.resolve(r)
    }
    async getMatchingSchemas(e) {
      let n = this._getTextDocument(e);
      if (!n) return [];
      let r = this._languageService.parseJSONDocument(n);
      return Promise.resolve(this._languageService.getMatchingSchemas(n, r))
    }
    _getTextDocument(e) {
      let n = this._ctx.getMirrorModels();
      for (let r of n)
        if (r.uri.toString() === e) return Me.create(e, this._languageId, r.version, r.getValue());
      return null
    }
  }
  const D1 = 47,
    si = 46;

  function O1(t) {
    return t.charCodeAt(0) === D1
  }

  function $1(t, e) {
    if (O1(e)) {
      const n = Dt.parse(t),
        r = e.split("/");
      return n.with({
        path: qo(r)
      }).toString()
    }
    return B1(t, e)
  }

  function qo(t) {
    const e = [];
    for (const r of t) r.length === 0 || r.length === 1 && r.charCodeAt(0) === si || (r.length === 2 && r.charCodeAt(0) === si && r.charCodeAt(1) === si ? e.pop() : e.push(r));
    t.length > 1 && t[t.length - 1].length === 0 && e.push("");
    let n = e.join("/");
    return t[0].length === 0 && (n = "/" + n), n
  }

  function B1(t, ...e) {
    const n = Dt.parse(t),
      r = n.path.split("/");
    for (let i of e) r.push(...i.split("/"));
    return n.with({
      path: qo(r)
    }).toString()
  }
  self.onmessage = () => {
    Pc((t, e) => new V1(t, e))
  }
})();