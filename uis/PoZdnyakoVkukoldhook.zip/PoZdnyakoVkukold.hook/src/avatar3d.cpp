#include "avatar3d.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <Windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <winhttp.h>

#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "d3dcompiler.lib")

namespace Avatar3D {
namespace {

constexpr wchar_t kHost[] = L"hriskido-avatar3d.piquant-moon.workers.dev";
constexpr char kToken[] = "ab3oulp70gjcixd5hnfesvtk24yr6mz8";

struct Vtx {
    float p[3];
    float n[3];
    float uv[2];
    float c[4];
};

struct DrawBatch {
    UINT start = 0;
    UINT count = 0;
    int tex = 0;
};

struct Cam {
    float pos[3]{ 0.f, 105.f, -10.f };
    float dir[3]{ 0.f, 0.26f, -0.97f };
    float fov = 30.f;
    float aabb_min[3]{ -2.f, 100.f, -1.f };
    float aabb_max[3]{ 2.f, 105.f, 1.f };
};

struct Mesh {
    std::vector<Vtx> v;
    std::vector<std::uint32_t> i;
    std::vector<std::vector<std::uint8_t>> pngs;
    std::vector<DrawBatch> batches;
    Cam cam{};
    std::int64_t uid = 0;
};

struct GpuMesh {
    ID3D11Buffer* vb = nullptr;
    ID3D11Buffer* ib = nullptr;
    std::vector<ID3D11ShaderResourceView*> texs;
    std::vector<DrawBatch> batches;
    UINT index_count = 0;
    Cam cam{};
};

std::mutex g_mu;
Mesh g_mesh;
std::thread g_thr;
std::atomic<bool> g_run{ false };
std::atomic<bool> g_cpu{ false };
std::atomic<bool> g_gpu_ok{ false };
std::atomic<bool> g_fail{ false };
std::atomic<bool> g_loading{ false };
HINTERNET g_ses = nullptr;
ID3D11Device* g_dev = nullptr;
ID3D11DeviceContext* g_ctx = nullptr;
GpuMesh g_gpu{};
ID3D11Texture2D* g_rt_tex = nullptr;
ID3D11RenderTargetView* g_rtv = nullptr;
ID3D11ShaderResourceView* g_srv = nullptr;
ID3D11Texture2D* g_depth = nullptr;
ID3D11DepthStencilView* g_dsv = nullptr;
ID3D11VertexShader* g_vs = nullptr;
ID3D11PixelShader* g_ps = nullptr;
ID3D11InputLayout* g_il = nullptr;
ID3D11Buffer* g_cb = nullptr;
ID3D11SamplerState* g_samp = nullptr;
ID3D11RasterizerState* g_rs = nullptr;
ID3D11DepthStencilState* g_dss = nullptr;
ID3D11BlendState* g_bs = nullptr;
bool g_pipe = false;
int g_rt_w = 512;
int g_rt_h = 512;
constexpr int k_rt_max = 1024;
constexpr float k_yaw0 = 3.14159265f;
float g_yaw = k_yaw0;
float g_pitch = 0.f;
float g_zoom = 1.f;
bool g_spin_hold = false;
ULONGLONG g_spin_t = 0;

constexpr char k_hlsl[] = R"HLSL(
cbuffer CB : register(b0)
{
    row_major float4x4 mvp;
    float3 light_dir;
    float pad0;
    float3 camera;
    float pad1;
};
struct VSIn {
    float3 pos : POSITION;
    float3 nrm : NORMAL;
    float2 uv  : TEXCOORD0;
    float4 col : COLOR0;
};
struct PSIn {
    float4 pos : SV_POSITION;
    float3 nrm : NORMAL;
    float2 uv  : TEXCOORD0;
    float3 wpos : TEXCOORD1;
};
Texture2D tex0 : register(t0);
SamplerState samp0 : register(s0);
PSIn vs_main(VSIn i) {
    PSIn o;
    o.pos = mul(mvp, float4(i.pos, 1));
    o.nrm = i.nrm;
    o.uv = i.uv;
    o.wpos = i.pos;
    return o;
}
float4 ps_main(PSIn i) : SV_TARGET {
    float3 N = normalize(i.nrm);
    float3 V = normalize(camera - i.wpos);
    if (dot(N, V) < 0.0) N = -N;
    float ndl = saturate(dot(N, normalize(-light_dir)));
    float4 t = tex0.Sample(samp0, i.uv);
    if (t.a < 0.05) discard;
    return float4(t.rgb * (ndl * 0.4 + 0.6), 1.0);
}
)HLSL";

bool HttpOpen()
{
    if (g_ses)
        return true;
    g_ses = WinHttpOpen(L"hriskido/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!g_ses)
        return false;
    DWORD t = 12000;
    WinHttpSetTimeouts(g_ses, t, t, t, t);
#ifdef WINHTTP_OPTION_DECOMPRESSION
    {
        DWORD d = WINHTTP_DECOMPRESSION_FLAG_GZIP | WINHTTP_DECOMPRESSION_FLAG_DEFLATE;
        WinHttpSetOption(g_ses, WINHTTP_OPTION_DECOMPRESSION, &d, sizeof(d));
    }
#endif
#ifdef WINHTTP_OPTION_ENABLE_HTTP_PROTOCOL
    {
        DWORD proto = WINHTTP_PROTOCOL_FLAG_HTTP2;
        WinHttpSetOption(g_ses, WINHTTP_OPTION_ENABLE_HTTP_PROTOCOL, &proto, sizeof(proto));
    }
#endif
    DWORD n = 16;
    WinHttpSetOption(g_ses, WINHTTP_OPTION_MAX_CONNS_PER_SERVER, &n, sizeof(n));
    WinHttpSetOption(g_ses, WINHTTP_OPTION_MAX_CONNS_PER_1_0_SERVER, &n, sizeof(n));
    return true;
}

void HttpClose()
{
    if (!g_ses)
        return;
    WinHttpCloseHandle(g_ses);
    g_ses = nullptr;
}

bool HttpGet(const wchar_t* host, const wchar_t* path, std::vector<std::uint8_t>& out)
{
    out.clear();
    if (!g_ses)
        return false;
    HINTERNET con = WinHttpConnect(g_ses, host, INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!con)
        return false;
    HINTERNET req = WinHttpOpenRequest(con, L"GET", path, nullptr, WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
    if (!req)
    {
        WinHttpCloseHandle(con);
        return false;
    }
    DWORD redir = WINHTTP_OPTION_REDIRECT_POLICY_ALWAYS;
    WinHttpSetOption(req, WINHTTP_OPTION_REDIRECT_POLICY, &redir, sizeof(redir));
    BOOL ok = WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, nullptr, 0, 0, 0);
    if (!ok || !WinHttpReceiveResponse(req, nullptr))
    {
        WinHttpCloseHandle(req);
        WinHttpCloseHandle(con);
        return false;
    }
    DWORD status = 0;
    DWORD status_sz = sizeof(status);
    if (!WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
            WINHTTP_HEADER_NAME_BY_INDEX, &status, &status_sz, WINHTTP_NO_HEADER_INDEX) ||
        status != 200)
    {
        WinHttpCloseHandle(req);
        WinHttpCloseHandle(con);
        return false;
    }
    std::uint8_t buf[65536];
    for (;;)
    {
        DWORD got = 0;
        if (!WinHttpReadData(req, buf, sizeof(buf), &got) || got == 0)
            break;
        const std::size_t old = out.size();
        if (old + got > (16u << 20))
            break;
        out.resize(old + got);
        std::memcpy(out.data() + old, buf, got);
    }
    WinHttpCloseHandle(req);
    WinHttpCloseHandle(con);
    return !out.empty();
}

bool ParseUrl(const std::string& url, std::wstring& host, std::wstring& path)
{
    const char* p = url.c_str();
    if (!std::strncmp(p, "https://", 8))
        p += 8;
    else if (!std::strncmp(p, "http://", 7))
        p += 7;
    else
        return false;
    const char* slash = std::strchr(p, '/');
    std::string h = slash ? std::string(p, slash) : std::string(p);
    std::string pa = slash ? slash : "/";
    if (h.empty())
        return false;
    host.assign(h.begin(), h.end());
    path.assign(pa.begin(), pa.end());
    return true;
}

bool IsHttpUrl(const std::string& s)
{
    return s.size() >= 8 &&
        (s.compare(0, 8, "https://") == 0 || s.compare(0, 7, "http://") == 0);
}

std::string FileName(const std::string& s)
{
    const auto p = s.find_last_of("/\\");
    return p == std::string::npos ? s : s.substr(p + 1);
}

std::string CdnUrl(const std::string& hash)
{
    if (hash.empty())
        return {};
    int i = 31;
    for (int t = 0; t < 38 && t < (int)hash.size(); ++t)
        i ^= (unsigned char)hash[(std::size_t)t];
    char buf[192];
    std::snprintf(buf, sizeof(buf), "https://t%d.rbxcdn.com/%s", i % 8, hash.c_str());
    return buf;
}

bool HttpGetUrl(const std::string& url, std::vector<std::uint8_t>& out)
{
    std::wstring host, path;
    if (!ParseUrl(url, host, path))
        return false;
    return HttpGet(host.c_str(), path.c_str(), out);
}

std::string JsonStr(const std::string& j, const char* key)
{
    std::string pat = std::string("\"") + key + "\"";
    std::size_t u = j.find(pat);
    if (u == std::string::npos)
        return {};
    u = j.find(':', u);
    if (u == std::string::npos)
        return {};
    u = j.find('"', u);
    if (u == std::string::npos)
        return {};
    const std::size_t a = u + 1;
    std::size_t b = a;
    while (b < j.size())
    {
        if (j[b] == '\\' && b + 1 < j.size())
        {
            b += 2;
            continue;
        }
        if (j[b] == '"')
            break;
        ++b;
    }
    if (b >= j.size())
        return {};
    std::string s = j.substr(a, b - a);
    for (std::size_t i = 0; i + 1 < s.size();)
    {
        if (s[i] == '\\' && s[i + 1] == '/')
            s.erase(i, 1);
        else
            ++i;
    }
    return s;
}

bool JsonVec3(const std::string& j, const char* obj, const char* field, float out[3])
{
    std::string pat = std::string("\"") + obj + "\"";
    std::size_t u = j.find(pat);
    if (u == std::string::npos)
        return false;
    std::size_t f = j.find(std::string("\"") + field + "\"", u);
    if (f == std::string::npos || f > u + 400)
        return false;
    f = j.find('{', f);
    if (f == std::string::npos)
        return false;
    float x = 0, y = 0, z = 0;
    if (sscanf_s(j.c_str() + f, "{\"x\":%f,\"y\":%f,\"z\":%f", &x, &y, &z) < 3)
        return false;
    out[0] = x;
    out[1] = y;
    out[2] = z;
    return true;
}

float JsonNum(const std::string& j, const char* key, float def)
{
    std::string pat = std::string("\"") + key + "\"";
    std::size_t u = j.find(pat);
    if (u == std::string::npos)
        return def;
    u = j.find(':', u);
    if (u == std::string::npos)
        return def;
    ++u;
    while (u < j.size() && (j[u] == ' ' || j[u] == '\t'))
        ++u;
    char* end = nullptr;
    const float v = std::strtof(j.c_str() + u, &end);
    return end != j.c_str() + u ? v : def;
}

bool IsGzip(const std::vector<std::uint8_t>& data)
{
    return data.size() >= 10 && data[0] == 0x1f && data[1] == 0x8b;
}

bool IsPng(const std::vector<std::uint8_t>& data)
{
    return data.size() >= 8 && data[0] == 0x89 && data[1] == 0x50 && data[2] == 0x4e && data[3] == 0x47;
}

void MaybeGunzip(std::vector<std::uint8_t>& data)
{
    if (!IsGzip(data))
        return;
    std::size_t i = 10;
    const std::uint8_t flags = data[3];
    if (flags & 4)
    {
        if (i + 2 > data.size())
            return;
        const std::uint16_t xlen = (std::uint16_t)(data[i] | (data[i + 1] << 8));
        i += 2 + xlen;
    }
    if (flags & 8)
    {
        while (i < data.size() && data[i])
            ++i;
        ++i;
    }
    if (flags & 16)
    {
        while (i < data.size() && data[i])
            ++i;
        ++i;
    }
    if (flags & 2)
        i += 2;
    if (i + 8 >= data.size())
        return;
    const int in_len = (int)(data.size() - i - 8);
    if (in_len <= 0)
        return;
    int outlen = 0;
    char* dec = stbi_zlib_decode_noheader_malloc((const char*)data.data() + i, in_len, &outlen);
    if (!dec || outlen <= 0)
    {
        if (dec)
            free(dec);
        outlen = 0;
        dec = stbi_zlib_decode_malloc((const char*)data.data() + i, in_len, &outlen);
        if (!dec || outlen <= 0)
        {
            if (dec)
                free(dec);
            return;
        }
    }
    data.assign((std::uint8_t*)dec, (std::uint8_t*)dec + outlen);
    free(dec);
}

void ParseMtl(const std::string& text, std::unordered_map<std::string, std::string>& mat_url)
{
    std::string cur;
    const char* s = text.c_str();
    const char* end = s + text.size();
    while (s < end)
    {
        while (s < end && (*s == ' ' || *s == '\t'))
            ++s;
        if (s >= end)
            break;
        if (std::strncmp(s, "newmtl", 6) == 0 && (s[6] == ' ' || s[6] == '\t'))
        {
            const char* a = s + 6;
            while (a < end && (*a == ' ' || *a == '\t'))
                ++a;
            const char* b = a;
            while (b < end && *b != '\n' && *b != '\r')
                ++b;
            while (b > a && (b[-1] == ' ' || b[-1] == '\t'))
                --b;
            cur.assign(a, b);
        }
        else if ((std::strncmp(s, "map_Kd", 6) == 0 || std::strncmp(s, "map_Ka", 6) == 0 || std::strncmp(s, "map_d", 5) == 0) &&
            !cur.empty())
        {
            const char* key = s;
            while (key < end && *key != ' ' && *key != '\t' && *key != '\n' && *key != '\r')
                ++key;
            while (key < end && (*key == ' ' || *key == '\t'))
                ++key;
            const char* b = key;
            while (b < end && *b != '\n' && *b != '\r')
                ++b;
            while (b > key && (b[-1] == ' ' || b[-1] == '\t'))
                --b;
            if (b > key && mat_url.find(cur) == mat_url.end())
                mat_url.emplace(cur, std::string(key, b));
        }
        while (s < end && *s != '\n')
            ++s;
        if (s < end)
            ++s;
    }
}

bool ParseObj(const std::string& text, Mesh& mesh, const std::unordered_map<std::string, int>* mat_tex)
{
    struct P { float x, y, z, r, g, b, a; };
    struct N { float x, y, z; };
    struct T { float u, v; };
    std::vector<P> pos;
    std::vector<N> nrm;
    std::vector<T> uv;
    std::string cur_mtl;
    int cur_tex = 0;
    int batch_tex = -1;
    UINT batch_start = 0;
    pos.reserve(9000);
    nrm.reserve(9000);
    uv.reserve(9000);
    mesh.v.clear();
    mesh.i.clear();
    mesh.batches.clear();
    mesh.v.reserve(20000);
    mesh.i.reserve(40000);

    auto flush_batch = [&]() {
        const UINT end_i = (UINT)mesh.i.size();
        if (batch_tex >= 0 && end_i > batch_start)
            mesh.batches.push_back({ batch_start, end_i - batch_start, batch_tex });
        batch_start = end_i;
        batch_tex = -1;
    };
    auto ensure_batch = [&]() {
        if (batch_tex != cur_tex)
        {
            flush_batch();
            batch_tex = cur_tex;
            batch_start = (UINT)mesh.i.size();
        }
    };

    const char* s = text.c_str();
    const char* end = s + text.size();
    while (s < end)
    {
        while (s < end && (*s == ' ' || *s == '\t'))
            ++s;
        if (s >= end)
            break;
        if (*s == 'v' && s + 1 < end && s[1] == ' ')
        {
            P p{ 0, 0, 0, 1, 1, 1, 1 };
            int n = sscanf_s(s + 2, "%f %f %f %f %f %f %f", &p.x, &p.y, &p.z, &p.r, &p.g, &p.b, &p.a);
            if (n >= 3)
                pos.push_back(p);
        }
        else if (*s == 'v' && s + 2 < end && s[1] == 'n' && s[2] == ' ')
        {
            N n{};
            if (sscanf_s(s + 3, "%f %f %f", &n.x, &n.y, &n.z) == 3)
                nrm.push_back(n);
        }
        else if (*s == 'v' && s + 2 < end && s[1] == 't' && s[2] == ' ')
        {
            T t{};
            if (sscanf_s(s + 3, "%f %f", &t.u, &t.v) >= 1)
                uv.push_back(t);
        }
        else if (std::strncmp(s, "usemtl", 6) == 0 && (s[6] == ' ' || s[6] == '\t'))
        {
            const char* a = s + 6;
            while (a < end && (*a == ' ' || *a == '\t'))
                ++a;
            const char* b = a;
            while (b < end && *b != '\n' && *b != '\r')
                ++b;
            while (b > a && (b[-1] == ' ' || b[-1] == '\t'))
                --b;
            cur_mtl.assign(a, b);
            cur_tex = 0;
            if (mat_tex)
            {
                const auto it = mat_tex->find(cur_mtl);
                if (it != mat_tex->end())
                    cur_tex = it->second;
            }
        }
        else if (*s == 'f' && s + 1 < end && s[1] == ' ')
        {
            const char* line_end = s;
            while (line_end < end && *line_end != '\n')
                ++line_end;
            int vi[4]{}, ti[4]{}, ni[4]{};
            int corners = 0;
            const char* p = s + 2;
            while (p < line_end && corners < 4)
            {
                while (p < line_end && (*p == ' ' || *p == '\t' || *p == '\r'))
                    ++p;
                if (p >= line_end)
                    break;
                int v = 0, t = 0, n = 0;
                if (sscanf_s(p, "%d/%d/%d", &v, &t, &n) == 3)
                {
                    vi[corners] = v;
                    ti[corners] = t;
                    ni[corners] = n;
                    ++corners;
                }
                else if (sscanf_s(p, "%d//%d", &v, &n) == 2)
                {
                    vi[corners] = v;
                    ni[corners] = n;
                    ++corners;
                }
                else if (sscanf_s(p, "%d/%d", &v, &t) == 2)
                {
                    vi[corners] = v;
                    ti[corners] = t;
                    ++corners;
                }
                else if (sscanf_s(p, "%d", &v) == 1)
                {
                    vi[corners] = v;
                    ++corners;
                }
                while (p < line_end && *p != ' ' && *p != '\t' && *p != '\r')
                    ++p;
            }
            auto push = [&](int idx) {
                Vtx vtx{};
                const int pv = vi[idx] > 0 ? vi[idx] - 1 : (int)pos.size() + vi[idx];
                if (pv < 0 || pv >= (int)pos.size())
                    return false;
                vtx.p[0] = pos[pv].x;
                vtx.p[1] = pos[pv].y;
                vtx.p[2] = pos[pv].z;
                vtx.c[0] = pos[pv].r;
                vtx.c[1] = pos[pv].g;
                vtx.c[2] = pos[pv].b;
                vtx.c[3] = pos[pv].a;
                if (ni[idx])
                {
                    const int nn = ni[idx] > 0 ? ni[idx] - 1 : (int)nrm.size() + ni[idx];
                    if (nn >= 0 && nn < (int)nrm.size())
                    {
                        vtx.n[0] = nrm[nn].x;
                        vtx.n[1] = nrm[nn].y;
                        vtx.n[2] = nrm[nn].z;
                    }
                    else
                        vtx.n[1] = 1.f;
                }
                else
                    vtx.n[1] = 1.f;
                if (ti[idx])
                {
                    const int tt = ti[idx] > 0 ? ti[idx] - 1 : (int)uv.size() + ti[idx];
                    if (tt >= 0 && tt < (int)uv.size())
                    {
                        vtx.uv[0] = uv[tt].u;
                        vtx.uv[1] = 1.f - uv[tt].v;
                    }
                }
                if (mesh.v.size() >= 300000)
                    return false;
                ensure_batch();
                mesh.i.push_back((std::uint32_t)mesh.v.size());
                mesh.v.push_back(vtx);
                return true;
            };
            if (corners >= 3)
            {
                if (!push(0) || !push(1) || !push(2))
                    return !mesh.i.empty();
                if (corners == 4 && (!push(0) || !push(2) || !push(3)))
                    return !mesh.i.empty();
            }
        }
        while (s < end && *s != '\n')
            ++s;
        if (s < end)
            ++s;
    }
    flush_batch();
    if (mesh.v.size() < 3 || mesh.i.empty())
        return false;
    if (mesh.batches.empty())
        mesh.batches.push_back({ 0, (UINT)mesh.i.size(), 0 });

    float mn[3]{ mesh.v[0].p[0], mesh.v[0].p[1], mesh.v[0].p[2] };
    float mx[3]{ mn[0], mn[1], mn[2] };
    for (const auto& v : mesh.v)
    {
        if (v.p[0] < mn[0]) mn[0] = v.p[0];
        if (v.p[1] < mn[1]) mn[1] = v.p[1];
        if (v.p[2] < mn[2]) mn[2] = v.p[2];
        if (v.p[0] > mx[0]) mx[0] = v.p[0];
        if (v.p[1] > mx[1]) mx[1] = v.p[1];
        if (v.p[2] > mx[2]) mx[2] = v.p[2];
    }
    mesh.cam.aabb_min[0] = mn[0];
    mesh.cam.aabb_min[1] = mn[1];
    mesh.cam.aabb_min[2] = mn[2];
    mesh.cam.aabb_max[0] = mx[0];
    mesh.cam.aabb_max[1] = mx[1];
    mesh.cam.aabb_max[2] = mx[2];
    return true;
}

bool LoadPngBytes(std::vector<std::uint8_t>& bytes)
{
    if (bytes.empty())
        return false;
    MaybeGunzip(bytes);
    if (IsGzip(bytes) || bytes.empty())
    {
        bytes.clear();
        return false;
    }
    return true;
}

void CollectTexUrls(const std::string& json, std::vector<std::string>& tex_urls, std::unordered_map<std::string, int>& url_tex)
{
    auto add = [&](const std::string& u) {
        if (u.empty() || !IsHttpUrl(u) || url_tex.find(u) != url_tex.end())
            return;
        url_tex.emplace(u, (int)tex_urls.size());
        tex_urls.push_back(u);
    };
    std::size_t t = json.find("\"textures\"");
    if (t == std::string::npos)
        return;
    std::size_t a = json.find('[', t);
    std::size_t b = a != std::string::npos ? json.find(']', a) : std::string::npos;
    if (a == std::string::npos || b == std::string::npos)
        return;
    std::size_t i = a + 1;
    while (i < b)
    {
        std::size_t q0 = json.find('"', i);
        if (q0 == std::string::npos || q0 >= b)
            break;
        std::size_t q1 = q0 + 1;
        while (q1 < b)
        {
            if (json[q1] == '\\' && q1 + 1 < b)
            {
                q1 += 2;
                continue;
            }
            if (json[q1] == '"')
                break;
            ++q1;
        }
        if (q1 >= b)
            break;
        std::string u = json.substr(q0 + 1, q1 - q0 - 1);
        for (std::size_t k = 0; k + 1 < u.size();)
        {
            if (u[k] == '\\' && u[k + 1] == '/')
                u.erase(k, 1);
            else
                ++k;
        }
        add(u);
        i = q1 + 1;
    }
}

std::wstring CacheRoot(std::int64_t uid)
{
    wchar_t tmp[MAX_PATH]{};
    GetTempPathW(MAX_PATH, tmp);
    wchar_t dir[MAX_PATH]{};
    _snwprintf_s(dir, _TRUNCATE, L"%shriskido_a3d\\%lld\\", tmp, (long long)uid);
    return dir;
}

bool ReadFileBytes(const std::wstring& path, std::vector<std::uint8_t>& out)
{
    out.clear();
    HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE)
        return false;
    LARGE_INTEGER sz{};
    if (!GetFileSizeEx(f, &sz) || sz.QuadPart <= 0 || sz.QuadPart > (16ll << 20))
    {
        CloseHandle(f);
        return false;
    }
    out.resize((std::size_t)sz.QuadPart);
    DWORD got = 0;
    const BOOL ok = ReadFile(f, out.data(), (DWORD)out.size(), &got, nullptr);
    CloseHandle(f);
    if (!ok || got != out.size())
    {
        out.clear();
        return false;
    }
    return true;
}

bool WriteFileBytes(const std::wstring& path, const void* data, std::size_t n)
{
    HANDLE f = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE)
        return false;
    DWORD put = 0;
    const BOOL ok = WriteFile(f, data, (DWORD)n, &put, nullptr);
    CloseHandle(f);
    return ok && put == n;
}

void SaveCache(std::int64_t uid, const std::string& json, const std::string& obj, const std::string& mtl, const std::vector<std::vector<std::uint8_t>>& pngs)
{
    const std::wstring root = CacheRoot(uid);
    const std::wstring parent = root.substr(0, root.find_last_of(L'\\', root.size() - 2) + 1);
    CreateDirectoryW(parent.c_str(), nullptr);
    CreateDirectoryW(root.c_str(), nullptr);
    WriteFileBytes(root + L"meta.json", json.data(), json.size());
    WriteFileBytes(root + L"mesh.obj", obj.data(), obj.size());
    if (!mtl.empty())
        WriteFileBytes(root + L"mesh.mtl", mtl.data(), mtl.size());
    for (std::size_t i = 0; i < pngs.size(); ++i)
    {
        wchar_t name[32]{};
        _snwprintf_s(name, _TRUNCATE, L"tex%u.bin", (unsigned)i);
        WriteFileBytes(root + name, pngs[i].data(), pngs[i].size());
    }
}

bool FinishMesh(Mesh& out, const std::string& json, const std::string& obj_text, const std::string& mtl_text, std::vector<std::vector<std::uint8_t>> pngs)
{
    JsonVec3(json, "camera", "position", out.cam.pos);
    JsonVec3(json, "camera", "direction", out.cam.dir);
    out.cam.fov = JsonNum(json, "fov", 30.f);
    float aabb_mn[3]{}, aabb_mx[3]{};
    const bool has_aabb = JsonVec3(json, "aabb", "min", aabb_mn) && JsonVec3(json, "aabb", "max", aabb_mx);

    std::vector<std::string> tex_urls;
    std::unordered_map<std::string, int> url_tex;
    CollectTexUrls(json, tex_urls, url_tex);
    std::unordered_map<std::string, std::string> mat_url;
    if (!mtl_text.empty())
        ParseMtl(mtl_text, mat_url);
    auto add_tex_url = [&](const std::string& u) {
        if (u.empty() || !IsHttpUrl(u) || url_tex.find(u) != url_tex.end())
            return;
        url_tex.emplace(u, (int)tex_urls.size());
        tex_urls.push_back(u);
    };
    auto resolve_tex = [&](const std::string& s) -> std::string {
        if (s.empty())
            return {};
        if (IsHttpUrl(s))
            return s;
        const std::string key = FileName(s);
        if (key.empty())
            return {};
        for (const auto& u : tex_urls)
        {
            if (FileName(u) == key)
                return u;
        }
        return CdnUrl(key);
    };
    for (const auto& kv : mat_url)
        add_tex_url(resolve_tex(kv.second));
    std::unordered_map<std::string, int> mat_tex;
    for (const auto& kv : mat_url)
    {
        const std::string u = resolve_tex(kv.second);
        const auto it = url_tex.find(u);
        if (it != url_tex.end())
            mat_tex.emplace(kv.first, it->second);
    }
    if (!ParseObj(obj_text, out, mat_tex.empty() ? nullptr : &mat_tex))
        return false;
    if (has_aabb)
    {
        for (int i = 0; i < 3; ++i)
        {
            if (aabb_mn[i] < out.cam.aabb_min[i])
                out.cam.aabb_min[i] = aabb_mn[i];
            if (aabb_mx[i] > out.cam.aabb_max[i])
                out.cam.aabb_max[i] = aabb_mx[i];
        }
    }
    {
        float c[3], h[3];
        for (int i = 0; i < 3; ++i)
        {
            c[i] = (out.cam.aabb_min[i] + out.cam.aabb_max[i]) * 0.5f;
            h[i] = (out.cam.aabb_max[i] - out.cam.aabb_min[i]) * 0.5f;
        }
        out.cam.aabb_min[0] = c[0] - h[0] * 1.06f;
        out.cam.aabb_max[0] = c[0] + h[0] * 1.06f;
        out.cam.aabb_min[1] = c[1] - h[1] * 1.08f;
        out.cam.aabb_max[1] = c[1] + h[1] * 1.08f;
        out.cam.aabb_min[2] = c[2] - h[2] * 1.06f;
        out.cam.aabb_max[2] = c[2] + h[2] * 1.06f;
    }
    out.pngs = std::move(pngs);
    return !out.v.empty() && !out.i.empty();
}

bool LoadCache(std::int64_t uid, Mesh& out)
{
    const std::wstring root = CacheRoot(uid);
    std::vector<std::uint8_t> json_b, obj_b, mtl_b;
    if (!ReadFileBytes(root + L"meta.json", json_b) || !ReadFileBytes(root + L"mesh.obj", obj_b))
        return false;
    ReadFileBytes(root + L"mesh.mtl", mtl_b);
    const std::string json(json_b.begin(), json_b.end());
    std::vector<std::string> tex_urls;
    std::unordered_map<std::string, int> url_tex;
    CollectTexUrls(json, tex_urls, url_tex);
    std::vector<std::vector<std::uint8_t>> pngs(tex_urls.size());
    for (std::size_t i = 0; i < pngs.size(); ++i)
    {
        wchar_t name[32]{};
        _snwprintf_s(name, _TRUNCATE, L"tex%u.bin", (unsigned)i);
        ReadFileBytes(root + name, pngs[i]);
    }
    out = {};
    out.uid = uid;
    return FinishMesh(out, json, std::string(obj_b.begin(), obj_b.end()),
        mtl_b.empty() ? std::string() : std::string(mtl_b.begin(), mtl_b.end()), std::move(pngs));
}

bool FetchUser(std::int64_t uid, Mesh& out)
{
    out = {};
    out.uid = uid;
    wchar_t path[320]{};
    _snwprintf_s(path, _TRUNCATE, L"/v1/avatar-3d/%lld?token=%hs", (long long)uid, kToken);
    std::vector<std::uint8_t> raw;
    if (!HttpGet(kHost, path, raw))
        return false;
    const std::string json(raw.begin(), raw.end());
    if (json.find("\"ok\":true") == std::string::npos && json.find("\"ok\": true") == std::string::npos)
        return false;

    const std::string obj_url = JsonStr(json, "obj");
    const std::string mtl_url = JsonStr(json, "mtl");
    if (obj_url.empty())
        return false;

    std::vector<std::string> tex_urls;
    std::unordered_map<std::string, int> url_tex;
    CollectTexUrls(json, tex_urls, url_tex);

    std::vector<std::uint8_t> obj_bytes;
    std::vector<std::uint8_t> mtl_bytes;
    std::vector<std::vector<std::uint8_t>> tex_bytes(tex_urls.size());
    std::vector<std::thread> jobs;
    jobs.emplace_back([&] {
        if (HttpGetUrl(obj_url, obj_bytes) && obj_bytes.size() >= 16)
            MaybeGunzip(obj_bytes);
    });
    jobs.emplace_back([&] {
        if (!mtl_url.empty() && HttpGetUrl(mtl_url, mtl_bytes) && mtl_bytes.size() > 8)
            MaybeGunzip(mtl_bytes);
    });
    for (std::size_t i = 0; i < tex_urls.size(); ++i)
    {
        jobs.emplace_back([&, i] {
            if (!HttpGetUrl(tex_urls[i], tex_bytes[i]) || !LoadPngBytes(tex_bytes[i]))
                tex_bytes[i].clear();
        });
    }
    for (auto& t : jobs)
        t.join();
    if (obj_bytes.empty() || obj_bytes[0] == 0x1f)
        return false;

    std::string obj_text((const char*)obj_bytes.data(), obj_bytes.size());
    std::string mtl_text;
    if (!IsGzip(mtl_bytes) && !mtl_bytes.empty())
        mtl_text.assign((const char*)mtl_bytes.data(), mtl_bytes.size());
    obj_bytes.clear();
    obj_bytes.shrink_to_fit();
    mtl_bytes.clear();
    mtl_bytes.shrink_to_fit();
    if (!FinishMesh(out, json, obj_text, mtl_text, std::move(tex_bytes)))
        return false;
    SaveCache(uid, json, obj_text, mtl_text, out.pngs);
    return true;
}

void Worker()
{
    Mesh mesh;
    bool ok = LoadCache(kUserId, mesh);
    if (!ok)
        ok = FetchUser(kUserId, mesh);
    std::lock_guard<std::mutex> lk(g_mu);
    if (ok)
    {
        g_mesh = std::move(mesh);
        g_cpu.store(true);
    }
    else
        g_fail.store(true);
    g_loading.store(false);
}

template<typename T>
void Rel(T*& p)
{
    if (p)
    {
        p->Release();
        p = nullptr;
    }
}

void ReleaseGpu()
{
    Rel(g_gpu.vb);
    Rel(g_gpu.ib);
    for (auto*& t : g_gpu.texs)
        Rel(t);
    g_gpu = {};
    g_gpu_ok.store(false);
}

void ReleaseRt()
{
    Rel(g_srv);
    Rel(g_rtv);
    Rel(g_rt_tex);
    Rel(g_dsv);
    Rel(g_depth);
}

void ReleasePipe()
{
    Rel(g_vs);
    Rel(g_ps);
    Rel(g_il);
    Rel(g_cb);
    Rel(g_samp);
    Rel(g_rs);
    Rel(g_dss);
    Rel(g_bs);
    g_pipe = false;
}

bool EnsurePipe(ID3D11Device* dev)
{
    if (g_pipe)
        return true;
    ID3DBlob* vsb = nullptr;
    ID3DBlob* psb = nullptr;
    ID3DBlob* err = nullptr;
    if (FAILED(D3DCompile(k_hlsl, sizeof(k_hlsl) - 1, nullptr, nullptr, nullptr, "vs_main", "vs_5_0", 0, 0, &vsb, &err)))
    {
        if (err)
            err->Release();
        return false;
    }
    if (err)
    {
        err->Release();
        err = nullptr;
    }
    if (FAILED(D3DCompile(k_hlsl, sizeof(k_hlsl) - 1, nullptr, nullptr, nullptr, "ps_main", "ps_5_0", 0, 0, &psb, &err)))
    {
        if (err)
            err->Release();
        vsb->Release();
        return false;
    }
    if (err)
        err->Release();
    if (FAILED(dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs)) ||
        FAILED(dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ps)))
    {
        vsb->Release();
        psb->Release();
        ReleasePipe();
        return false;
    }
    D3D11_INPUT_ELEMENT_DESC il[] = {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 24, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 32, D3D11_INPUT_PER_VERTEX_DATA, 0 },
    };
    if (FAILED(dev->CreateInputLayout(il, 4, vsb->GetBufferPointer(), vsb->GetBufferSize(), &g_il)))
    {
        vsb->Release();
        psb->Release();
        ReleasePipe();
        return false;
    }
    vsb->Release();
    psb->Release();
    D3D11_BUFFER_DESC cbd{};
    cbd.ByteWidth = 256;
    cbd.Usage = D3D11_USAGE_DYNAMIC;
    cbd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    cbd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    if (FAILED(dev->CreateBuffer(&cbd, nullptr, &g_cb)))
    {
        ReleasePipe();
        return false;
    }
    D3D11_SAMPLER_DESC sd{};
    sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sd.MaxLOD = D3D11_FLOAT32_MAX;
    if (FAILED(dev->CreateSamplerState(&sd, &g_samp)))
    {
        ReleasePipe();
        return false;
    }
    D3D11_RASTERIZER_DESC rd{};
    rd.FillMode = D3D11_FILL_SOLID;
    rd.CullMode = D3D11_CULL_NONE;
    rd.DepthClipEnable = TRUE;
    if (FAILED(dev->CreateRasterizerState(&rd, &g_rs)))
    {
        ReleasePipe();
        return false;
    }
    D3D11_DEPTH_STENCIL_DESC dd{};
    dd.DepthEnable = TRUE;
    dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    dd.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;
    if (FAILED(dev->CreateDepthStencilState(&dd, &g_dss)))
    {
        ReleasePipe();
        return false;
    }
    D3D11_BLEND_DESC bd{};
    bd.RenderTarget[0].BlendEnable = TRUE;
    bd.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
    bd.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
    bd.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bd.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    bd.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
    bd.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bd.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    if (FAILED(dev->CreateBlendState(&bd, &g_bs)))
    {
        ReleasePipe();
        return false;
    }
    g_pipe = true;
    return true;
}

bool EnsureRt(ID3D11Device* dev)
{
    int w = g_rt_w;
    int h = g_rt_h;
    if (w < 64)
        w = 64;
    if (h < 64)
        h = 64;
    if (w > k_rt_max)
        w = k_rt_max;
    if (h > k_rt_max)
        h = k_rt_max;
    if (g_rtv && g_srv && g_dsv && g_rt_tex)
    {
        D3D11_TEXTURE2D_DESC cur{};
        g_rt_tex->GetDesc(&cur);
        if ((int)cur.Width == w && (int)cur.Height == h)
            return true;
    }
    ReleaseRt();
    g_rt_w = w;
    g_rt_h = h;
    D3D11_TEXTURE2D_DESC td{};
    td.Width = (UINT)w;
    td.Height = (UINT)h;
    td.MipLevels = 1;
    td.ArraySize = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_DEFAULT;
    td.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
    if (FAILED(dev->CreateTexture2D(&td, nullptr, &g_rt_tex)))
        return false;
    if (FAILED(dev->CreateRenderTargetView(g_rt_tex, nullptr, &g_rtv)))
        return false;
    if (FAILED(dev->CreateShaderResourceView(g_rt_tex, nullptr, &g_srv)))
        return false;
    td.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
    td.BindFlags = D3D11_BIND_DEPTH_STENCIL;
    if (FAILED(dev->CreateTexture2D(&td, nullptr, &g_depth)))
        return false;
    if (FAILED(dev->CreateDepthStencilView(g_depth, nullptr, &g_dsv)))
        return false;
    return true;
}

ID3D11ShaderResourceView* MakeTex(ID3D11Device* dev, const std::vector<std::uint8_t>& png)
{
    int w = 0, h = 0, n = 0;
    unsigned char* px = stbi_load_from_memory(png.data(), (int)png.size(), &w, &h, &n, 4);
    if (!px)
        return nullptr;
    D3D11_TEXTURE2D_DESC td{};
    td.Width = (UINT)w;
    td.Height = (UINT)h;
    td.MipLevels = 1;
    td.ArraySize = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_DEFAULT;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA sd{};
    sd.pSysMem = px;
    sd.SysMemPitch = (UINT)(w * 4);
    ID3D11Texture2D* tex = nullptr;
    ID3D11ShaderResourceView* srv = nullptr;
    if (SUCCEEDED(dev->CreateTexture2D(&td, &sd, &tex)))
        dev->CreateShaderResourceView(tex, nullptr, &srv);
    if (tex)
        tex->Release();
    stbi_image_free(px);
    return srv;
}

bool UploadMesh(ID3D11Device* dev, Mesh& cpu)
{
    ReleaseGpu();
    if (!dev || cpu.v.empty() || cpu.i.empty() || cpu.v.size() > 300000 || cpu.i.size() > 900000)
        return false;
    D3D11_BUFFER_DESC vd{};
    vd.ByteWidth = (UINT)(cpu.v.size() * sizeof(Vtx));
    vd.Usage = D3D11_USAGE_IMMUTABLE;
    vd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
    D3D11_SUBRESOURCE_DATA vsd{};
    vsd.pSysMem = cpu.v.data();
    if (FAILED(dev->CreateBuffer(&vd, &vsd, &g_gpu.vb)))
    {
        ReleaseGpu();
        return false;
    }
    D3D11_BUFFER_DESC id{};
    id.ByteWidth = (UINT)(cpu.i.size() * sizeof(std::uint32_t));
    id.Usage = D3D11_USAGE_IMMUTABLE;
    id.BindFlags = D3D11_BIND_INDEX_BUFFER;
    D3D11_SUBRESOURCE_DATA isd{};
    isd.pSysMem = cpu.i.data();
    if (FAILED(dev->CreateBuffer(&id, &isd, &g_gpu.ib)))
    {
        ReleaseGpu();
        return false;
    }
    g_gpu.index_count = (UINT)cpu.i.size();
    g_gpu.cam = cpu.cam;
    g_gpu.batches = std::move(cpu.batches);
    if (g_gpu.batches.empty())
        g_gpu.batches.push_back({ 0, g_gpu.index_count, 0 });
    g_gpu.texs.reserve(cpu.pngs.size() + 1);
    for (const auto& png : cpu.pngs)
        g_gpu.texs.push_back(MakeTex(dev, png));
    ID3D11ShaderResourceView* grey = nullptr;
    auto make_grey = [&]() -> ID3D11ShaderResourceView* {
        if (grey)
        {
            grey->AddRef();
            return grey;
        }
        unsigned char px[4]{ 220, 220, 220, 255 };
        D3D11_TEXTURE2D_DESC td{};
        td.Width = td.Height = 1;
        td.MipLevels = td.ArraySize = 1;
        td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        td.SampleDesc.Count = 1;
        td.Usage = D3D11_USAGE_IMMUTABLE;
        td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        D3D11_SUBRESOURCE_DATA sd{};
        sd.pSysMem = px;
        sd.SysMemPitch = 4;
        ID3D11Texture2D* t = nullptr;
        if (SUCCEEDED(dev->CreateTexture2D(&td, &sd, &t)))
        {
            dev->CreateShaderResourceView(t, nullptr, &grey);
            t->Release();
        }
        return grey;
    };
    for (auto& srv : g_gpu.texs)
    {
        if (!srv)
            srv = make_grey();
    }
    if (g_gpu.texs.empty())
    {
        ID3D11ShaderResourceView* srv = make_grey();
        if (!srv)
        {
            ReleaseGpu();
            return false;
        }
        g_gpu.texs.push_back(srv);
    }
    g_gpu_ok.store(true);
    return true;
}

void Mul4(float o[16], const float a[16], const float b[16])
{
    float t[16]{};
    for (int r = 0; r < 4; ++r)
        for (int c = 0; c < 4; ++c)
            t[r * 4 + c] = a[r * 4 + 0] * b[0 * 4 + c] + a[r * 4 + 1] * b[1 * 4 + c] + a[r * 4 + 2] * b[2 * 4 + c] + a[r * 4 + 3] * b[3 * 4 + c];
    std::memcpy(o, t, sizeof(t));
}

void LookAt(float m[16], const float eye[3], const float at[3], const float up[3])
{
    float zx = eye[0] - at[0], zy = eye[1] - at[1], zz = eye[2] - at[2];
    float zl = std::sqrt(zx * zx + zy * zy + zz * zz);
    if (zl < 1e-6f)
        zl = 1e-6f;
    zx /= zl;
    zy /= zl;
    zz /= zl;
    float xx = up[1] * zz - up[2] * zy;
    float xy = up[2] * zx - up[0] * zz;
    float xz = up[0] * zy - up[1] * zx;
    float xl = std::sqrt(xx * xx + xy * xy + xz * xz);
    if (xl < 1e-6f)
        xl = 1e-6f;
    xx /= xl;
    xy /= xl;
    xz /= xl;
    float yx = zy * xz - zz * xy;
    float yy = zz * xx - zx * xz;
    float yz = zx * xy - zy * xx;
    const float tx = -(xx * eye[0] + xy * eye[1] + xz * eye[2]);
    const float ty = -(yx * eye[0] + yy * eye[1] + yz * eye[2]);
    const float tz = -(zx * eye[0] + zy * eye[1] + zz * eye[2]);
    m[0] = xx;
    m[1] = xy;
    m[2] = xz;
    m[3] = tx;
    m[4] = yx;
    m[5] = yy;
    m[6] = yz;
    m[7] = ty;
    m[8] = zx;
    m[9] = zy;
    m[10] = zz;
    m[11] = tz;
    m[12] = 0.f;
    m[13] = 0.f;
    m[14] = 0.f;
    m[15] = 1.f;
}

void Perspective(float m[16], float fov_y_deg, float aspect, float zn, float zf)
{
    const float f = 1.f / std::tan(fov_y_deg * 0.01745329252f * 0.5f);
    std::memset(m, 0, 16 * sizeof(float));
    m[0] = f / aspect;
    m[5] = f;
    m[10] = zf / (zn - zf);
    m[11] = (zn * zf) / (zn - zf);
    m[14] = -1.f;
    m[15] = 0.f;
}

}

void Start(ID3D11Device* dev, ID3D11DeviceContext* ctx)
{
    g_dev = dev;
    g_ctx = ctx;
    if (g_run.exchange(true))
        return;
    g_cpu.store(false);
    g_gpu_ok.store(false);
    g_fail.store(false);
    g_loading.store(true);
    if (!HttpOpen())
    {
        g_fail.store(true);
        g_loading.store(false);
        g_run.store(false);
        return;
    }
    g_thr = std::thread(Worker);
}

void Stop()
{
    g_run.store(false);
    if (g_thr.joinable())
        g_thr.join();
    ReleaseGpu();
    ReleaseRt();
    ReleasePipe();
    HttpClose();
    std::lock_guard<std::mutex> lk(g_mu);
    g_mesh = {};
    g_cpu.store(false);
    g_fail.store(false);
    g_loading.store(false);
    g_dev = nullptr;
    g_ctx = nullptr;
}

void Tick()
{
    if (!g_dev)
        return;
    if (g_gpu_ok.load() || !g_cpu.load())
        return;
    Mesh pending;
    {
        std::lock_guard<std::mutex> lk(g_mu);
        if (!g_cpu.load())
            return;
        pending = std::move(g_mesh);
        g_mesh = {};
        g_cpu.store(false);
    }
    if (!pending.v.empty())
        UploadMesh(g_dev, pending);
}

void SetViewSize(int w, int h)
{
    if (w < 64)
        w = 64;
    if (h < 64)
        h = 64;
    if (w > k_rt_max)
        w = k_rt_max;
    if (h > k_rt_max)
        h = k_rt_max;
    g_rt_w = w;
    g_rt_h = h;
}

void Orbit(float dx, float dy)
{
    g_spin_hold = true;
    g_yaw += dx * 0.01f;
    g_pitch += dy * 0.01f;
    if (g_pitch > 1.2f)
        g_pitch = 1.2f;
    if (g_pitch < -1.2f)
        g_pitch = -1.2f;
}

void Zoom(float wheel)
{
    if (wheel == 0.f)
        return;
    g_zoom *= (1.f - wheel * 0.03f);
    if (g_zoom < 0.55f)
        g_zoom = 0.55f;
    if (g_zoom > 2.8f)
        g_zoom = 2.8f;
}

void Render()
{
    ID3D11Device* dev = g_dev;
    ID3D11DeviceContext* ctx = g_ctx;
    if (!dev || !ctx || !g_gpu.vb || !g_gpu.ib || g_gpu.texs.empty() || !g_gpu.texs[0])
        return;
    if (!EnsurePipe(dev) || !EnsureRt(dev) || !g_vs || !g_ps || !g_il || !g_cb || !g_rtv || !g_dsv)
        return;

    const ULONGLONG now = GetTickCount64();
    const float dt = g_spin_t ? (float)(now - g_spin_t) * 0.001f : 0.f;
    g_spin_t = now;
    if (!g_spin_hold && dt > 0.f && dt < 0.1f)
    {
        g_yaw += 0.28f * dt;
        if (g_yaw > 6.2831853f)
            g_yaw -= 6.2831853f;
    }
    g_spin_hold = false;

    const float* mn = g_gpu.cam.aabb_min;
    const float* mx = g_gpu.cam.aabb_max;
    const float center[3] = {
        (mn[0] + mx[0]) * 0.5f,
        (mn[1] + mx[1]) * 0.5f,
        (mn[2] + mx[2]) * 0.5f,
    };
    const float ext_x = mx[0] - mn[0];
    const float ext_y = mx[1] - mn[1];
    const float ext_z = mx[2] - mn[2];
    float radius = 0.5f * std::sqrt(ext_x * ext_x + ext_y * ext_y + ext_z * ext_z);
    if (radius < 0.5f)
        radius = 0.5f;

    constexpr float fov = 30.f;
    const float aspect = (g_rt_h > 0) ? ((float)g_rt_w / (float)g_rt_h) : 1.f;
    const float asp = aspect > 0.1f ? aspect : 1.f;
    const float tan_y = std::tan(fov * 0.01745329252f * 0.5f);
    const float tan_x = tan_y * asp;
    const float cy = std::cos(g_pitch);
    const float sy = std::sin(g_pitch);
    const float s = std::sin(g_yaw), co = std::cos(g_yaw);
    const float dir[3]{ s * cy, sy, co * cy };
    float xx = dir[2], xy = 0.f, xz = -dir[0];
    float xl = std::sqrt(xx * xx + xz * xz);
    if (xl < 1e-5f)
    {
        xx = 1.f;
        xy = 0.f;
        xz = 0.f;
        xl = 1.f;
    }
    xx /= xl;
    xz /= xl;
    const float yx = dir[1] * xz - dir[2] * xy;
    const float yy = dir[2] * xx - dir[0] * xz;
    const float yz = dir[0] * xy - dir[1] * xx;

    float fit = 0.f;
    for (int ix = 0; ix < 2; ++ix)
    {
        for (int iy = 0; iy < 2; ++iy)
        {
            for (int iz = 0; iz < 2; ++iz)
            {
                const float vx = (ix ? mx[0] : mn[0]) - center[0];
                const float vy = (iy ? mx[1] : mn[1]) - center[1];
                const float vz = (iz ? mx[2] : mn[2]) - center[2];
                const float along = vx * dir[0] + vy * dir[1] + vz * dir[2];
                const float rx = vx * xx + vy * xy + vz * xz;
                const float ry = vx * yx + vy * yy + vz * yz;
                const float need_x = std::fabs(rx) / tan_x + along;
                const float need_y = std::fabs(ry) / tan_y + along;
                if (need_x > fit)
                    fit = need_x;
                if (need_y > fit)
                    fit = need_y;
            }
        }
    }
    if (fit < radius * 0.5f)
        fit = radius * 0.5f;
    const float dist = fit * 1.14f * g_zoom;
    float eye[3] = {
        center[0] + dist * dir[0],
        center[1] + dist * dir[1],
        center[2] + dist * dir[2],
    };
    const float up[3]{ 0.f, 1.f, 0.f };
    float view[16], proj[16], mvp[16];
    LookAt(view, eye, center, up);
    const float zn = 0.05f;
    const float zf = dist + radius * 4.f;
    Perspective(proj, fov, asp, zn, zf > zn + 1.f ? zf : zn + 1.f);
    Mul4(mvp, proj, view);

    ID3D11RenderTargetView* prev_rtv = nullptr;
    ID3D11DepthStencilView* prev_dsv = nullptr;
    ctx->OMGetRenderTargets(1, &prev_rtv, &prev_dsv);
    ID3D11ShaderResourceView* null_srvs[4]{};
    ctx->PSSetShaderResources(0, 4, null_srvs);

    const float clear[4]{ 0.f, 0.f, 0.f, 0.f };
    ctx->OMSetRenderTargets(1, &g_rtv, g_dsv);
    ctx->ClearRenderTargetView(g_rtv, clear);
    ctx->ClearDepthStencilView(g_dsv, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.f, 0);
    D3D11_VIEWPORT vp{};
    vp.Width = (float)g_rt_w;
    vp.Height = (float)g_rt_h;
    vp.MinDepth = 0.f;
    vp.MaxDepth = 1.f;
    ctx->RSSetViewports(1, &vp);
    const float blend[4]{ 0.f, 0.f, 0.f, 0.f };
    ctx->OMSetBlendState(g_bs, blend, 0xffffffff);
    ctx->IASetInputLayout(g_il);
    ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    UINT stride = sizeof(Vtx), off = 0;
    ctx->IASetVertexBuffers(0, 1, &g_gpu.vb, &stride, &off);
    ctx->IASetIndexBuffer(g_gpu.ib, DXGI_FORMAT_R32_UINT, 0);
    ctx->VSSetShader(g_vs, nullptr, 0);
    ctx->PSSetShader(g_ps, nullptr, 0);
    ctx->VSSetConstantBuffers(0, 1, &g_cb);
    ctx->PSSetConstantBuffers(0, 1, &g_cb);
    ctx->PSSetSamplers(0, 1, &g_samp);
    ctx->RSSetState(g_rs);
    ctx->OMSetDepthStencilState(g_dss, 0);

    D3D11_MAPPED_SUBRESOURCE map{};
    if (SUCCEEDED(ctx->Map(g_cb, 0, D3D11_MAP_WRITE_DISCARD, 0, &map)) && map.pData)
    {
        std::memset(map.pData, 0, 256);
        std::memcpy(map.pData, mvp, 64);
        float* light = (float*)((char*)map.pData + 64);
        light[0] = -0.45f;
        light[1] = -0.85f;
        light[2] = -0.30f;
        float* cam = (float*)((char*)map.pData + 80);
        cam[0] = eye[0];
        cam[1] = eye[1];
        cam[2] = eye[2];
        ctx->Unmap(g_cb, 0);
        for (const auto& b : g_gpu.batches)
        {
            if (b.count == 0)
                continue;
            ID3D11ShaderResourceView* tex = nullptr;
            if (b.tex >= 0 && b.tex < (int)g_gpu.texs.size())
                tex = g_gpu.texs[b.tex];
            if (!tex)
                tex = g_gpu.texs[0];
            ctx->PSSetShaderResources(0, 1, &tex);
            ctx->DrawIndexed(b.count, b.start, 0);
        }
    }

    ctx->PSSetShaderResources(0, 4, null_srvs);
    ctx->OMSetRenderTargets(1, &prev_rtv, prev_dsv);
    if (prev_rtv)
        prev_rtv->Release();
    if (prev_dsv)
        prev_dsv->Release();
}

ID3D11ShaderResourceView* Srv()
{
    return (g_gpu.vb && g_gpu.ib && !g_gpu.texs.empty() && g_gpu.texs[0] && g_srv) ? g_srv : nullptr;
}

bool Ready()
{
    return Srv() != nullptr;
}

bool Loading()
{
    return g_loading.load();
}

bool Failed()
{
    return g_fail.load();
}

}
