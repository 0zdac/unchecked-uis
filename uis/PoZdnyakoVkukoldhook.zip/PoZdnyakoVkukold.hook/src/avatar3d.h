#pragma once

#include <cstdint>
#include <d3d11.h>

namespace Avatar3D {

constexpr std::int64_t kUserId = 7210104935;

void Start(ID3D11Device* dev, ID3D11DeviceContext* ctx);
void Stop();
void Tick();
void SetViewSize(int w, int h);
void Orbit(float dx, float dy);
void Zoom(float wheel);
void Render();
ID3D11ShaderResourceView* Srv();
bool Ready();
bool Loading();
bool Failed();

}
