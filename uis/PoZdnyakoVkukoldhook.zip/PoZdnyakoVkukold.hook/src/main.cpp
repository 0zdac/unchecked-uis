#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_freetype.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "widgets.h"
#include "island_font.h"
#include "avatar3d.h"
#include "nowplay.h"
#include "ytview.h"

#define FONT_SIZE 13.0f
static const ImVec2 kChildPad(10.0f, 10.0f);
#include <commdlg.h>
#include <d3d11.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>

#pragma comment(lib, "comdlg32.lib")

#define PROJECT_NAME "PoZdnyakoVkukold.hook"

ImFont* g_fontTitle = nullptr;
ImFont* g_fontVerdana = nullptr;
ImFont* g_fontIcons = nullptr;

static int g_menu_key = VK_DELETE;
static int g_menu_mode = 0;
static bool g_menu_open = true;
static bool g_menu_opening = true;
static float g_menu_anim = 1.0f;
static bool g_plist_open = true;
static bool g_plist_opening = true;
static float g_plist_anim = 1.0f;
static bool g_esp_open = true;
static bool g_esp_opening = true;
static float g_esp_anim = 1.0f;
static bool g_lua_open = true;
static bool g_lua_opening = true;
static float g_lua_anim = 1.0f;
static char g_lua_buf[65536];
static char g_lua_out[65536];
static wchar_t g_lua_path[MAX_PATH];
static HWND g_hwnd = nullptr;
static bool g_lua_seeded = false;
static int g_lua_tab = 0;
static bool g_player_open = true;
static bool g_player_opening = true;
static float g_player_anim = 1.0f;
static bool g_lyrics_open = false;
static bool g_vis_on = true;
static bool g_video_open = false;
static bool g_video_resize = false;
static bool g_video_full = false;
static bool g_video_full_restore = false;
static ImVec2 g_video_full_pos;
static ImVec2 g_video_full_sz;
static char g_video_key[520];
static double g_video_sync_t;

enum { WIN_GUI = 0, WIN_PLIST, WIN_ESP, WIN_LUA, WIN_PLAYER, WIN_COUNT };
static const char* kWinName[WIN_COUNT] = { "gui", "plist", "esp", "lua", "player" };
static bool g_glue[WIN_COUNT][WIN_COUNT];
static int g_dock_drag = -1;
static ImVec2 g_dock_mouse0;
static ImVec2 g_dock_start[WIN_COUNT];
static const float kDockGap = 6.0f;
static const float kDockStick = 22.0f;
static const float kDockUnstick = 26.0f;

static void DockDetach(int id);

static bool MenuKeyDown(int vk)
{
    if (vk <= 0)
        return false;
    ImGuiIO& io = ImGui::GetIO();
    if (vk == VK_LBUTTON)
        return io.MouseDown[0];
    if (vk == VK_RBUTTON)
        return io.MouseDown[1];
    if (vk == VK_MBUTTON)
        return io.MouseDown[2];
    if (vk == VK_XBUTTON1)
        return io.MouseDown[3];
    if (vk == VK_XBUTTON2)
        return io.MouseDown[4];
    return (GetAsyncKeyState(vk) & 0x8000) != 0;
}

static void SetMenuOpen(bool open)
{
    if (open == g_menu_open)
        return;
    g_menu_open = open;
    g_menu_opening = open;
    g_menu_anim = 0.0f;
    if (!open)
        DockDetach(WIN_GUI);
}

static void SetPlistOpen(bool open)
{
    if (open == g_plist_open)
        return;
    g_plist_open = open;
    g_plist_opening = open;
    g_plist_anim = 0.0f;
    if (!open)
        DockDetach(WIN_PLIST);
}

static void SetEspOpen(bool open)
{
    if (open == g_esp_open)
        return;
    g_esp_open = open;
    g_esp_opening = open;
    g_esp_anim = 0.0f;
    if (!open)
        DockDetach(WIN_ESP);
}

static void SetLuaOpen(bool open)
{
    if (open == g_lua_open)
        return;
    g_lua_open = open;
    g_lua_opening = open;
    g_lua_anim = 0.0f;
    if (!open)
        DockDetach(WIN_LUA);
}

static void SetPlayerOpen(bool open)
{
    if (open == g_player_open)
        return;
    g_player_open = open;
    g_player_opening = open;
    g_player_anim = 0.0f;
    if (!open)
        DockDetach(WIN_PLAYER);
}

static float EspAlpha()
{
    const float dur = 0.22f;
    if (g_esp_anim < dur)
        g_esp_anim = ImMin(g_esp_anim + ImGui::GetIO().DeltaTime, dur);
    float t = ImClamp(g_esp_anim / dur, 0.0f, 1.0f);
    float a = g_esp_opening ? (1.0f - powf(1.0f - t, 3.0f)) : (1.0f - t * t * t);
    return ImClamp(a, 0.0f, 1.0f);
}

static float LuaAlpha()
{
    const float dur = 0.22f;
    if (g_lua_anim < dur)
        g_lua_anim = ImMin(g_lua_anim + ImGui::GetIO().DeltaTime, dur);
    float t = ImClamp(g_lua_anim / dur, 0.0f, 1.0f);
    float a = g_lua_opening ? (1.0f - powf(1.0f - t, 3.0f)) : (1.0f - t * t * t);
    return ImClamp(a, 0.0f, 1.0f);
}

static float PlistAlpha()
{
    const float dur = 0.22f;
    if (g_plist_anim < dur)
        g_plist_anim = ImMin(g_plist_anim + ImGui::GetIO().DeltaTime, dur);
    float t = ImClamp(g_plist_anim / dur, 0.0f, 1.0f);
    float a = g_plist_opening ? (1.0f - powf(1.0f - t, 3.0f)) : (1.0f - t * t * t);
    return ImClamp(a, 0.0f, 1.0f);
}

static float PlayerAlpha()
{
    const float dur = 0.22f;
    if (g_player_anim < dur)
        g_player_anim = ImMin(g_player_anim + ImGui::GetIO().DeltaTime, dur);
    float t = ImClamp(g_player_anim / dur, 0.0f, 1.0f);
    float a = g_player_opening ? (1.0f - powf(1.0f - t, 3.0f)) : (1.0f - t * t * t);
    return ImClamp(a, 0.0f, 1.0f);
}

static float MenuAlpha()
{
    static bool was_down = false;
    bool down = MenuKeyDown(g_menu_key);
    if (!Ui::KeybindCapturing() && !ImGui::GetIO().WantTextInput && g_menu_key > 0)
    {
        bool want = g_menu_open;
        if (g_menu_mode == 2)
            want = true;
        else if (g_menu_mode == 1)
            want = down;
        else if (down && !was_down)
            want = !g_menu_open;
        SetMenuOpen(want);
    }
    was_down = down;

    const float dur = 0.22f;
    if (g_menu_anim < dur)
        g_menu_anim = ImMin(g_menu_anim + ImGui::GetIO().DeltaTime, dur);
    float t = ImClamp(g_menu_anim / dur, 0.0f, 1.0f);
    float a = g_menu_opening ? (1.0f - powf(1.0f - t, 3.0f)) : (1.0f - t * t * t);
    return ImClamp(a, 0.0f, 1.0f);
}

static ID3D11Device* g_pd3dDevice = nullptr;
static ID3D11DeviceContext* g_pd3dDeviceContext = nullptr;
static IDXGISwapChain* g_pSwapChain = nullptr;
static bool g_SwapChainOccluded = false;
static UINT g_ResizeWidth = 0;
static UINT g_ResizeHeight = 0;
static ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;

bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

static ImColor FadeCol(int r, int g, int b, int a = 255)
{
    return ImColor(r, g, b, (int)(a * ImGui::GetStyle().Alpha));
}

static ImVec2 Snap(ImVec2 v)
{
    return ImVec2(IM_TRUNC(v.x), IM_TRUNC(v.y));
}

static void PxFill(ImDrawList* draw, float x0, float y0, float x1, float y1, ImU32 col)
{
    draw->AddRectFilled(ImVec2(IM_TRUNC(x0), IM_TRUNC(y0)), ImVec2(IM_TRUNC(x1), IM_TRUNC(y1)), col);
}

static void TextOutlined(ImDrawList* draw, ImVec2 pos, ImColor col, const char* text)
{
    pos.x = IM_TRUNC(pos.x);
    pos.y = IM_TRUNC(pos.y);
    ImColor out(0, 0, 0, (int)(255 * col.Value.w));
    draw->AddText(ImVec2(pos.x - 1, pos.y), out, text);
    draw->AddText(ImVec2(pos.x + 1, pos.y), out, text);
    draw->AddText(ImVec2(pos.x, pos.y - 1), out, text);
    draw->AddText(ImVec2(pos.x, pos.y + 1), out, text);
    draw->AddText(pos, col, text);
}

static void DrawTitle(ImDrawList* draw, ImVec2 pos, ImColor col)
{
    const char* base = "allahu ";
    const char* extra = "akbar";
    const int extra_max = 5;
    float t = (float)ImGui::GetTime();
    float ct = fmodf(t, 8.0f);
    int extra_n = 0;
    if (ct >= 3.0f && ct < 3.0f + extra_max * 0.12f)
        extra_n = (int)((ct - 3.0f) / 0.12f) + 1;
    else if (ct >= 3.0f + extra_max * 0.12f && ct < 6.2f)
        extra_n = extra_max;
    else if (ct >= 6.2f && ct < 6.2f + extra_max * 0.1f)
        extra_n = extra_max - (int)((ct - 6.2f) / 0.1f);
    extra_n = ImClamp(extra_n, 0, extra_max);

    char buf[24];
    int base_n = (int)strlen(base);
    memcpy(buf, base, base_n);
    memcpy(buf + base_n, extra, extra_n);
    buf[base_n + extra_n] = 0;

    float x = pos.x;
    for (int i = 0; buf[i]; i++)
    {
        char ch[2] = { buf[i], 0 };
        float bump = sinf(t * 5.5f - (float)i * 0.75f);
        float yoff = bump > 0.0f ? -bump * 3.0f : 0.0f;
        TextOutlined(draw, ImVec2(IM_TRUNC(x), IM_TRUNC(pos.y + yoff)), i >= base_n ? Tc(g_theme->text_dim) : col, ch);
        x += ImGui::CalcTextSize(ch).x;
    }
}

static ImColor HeaderCol(float t)
{
    return FadeCol(
        (int)ImLerp((float)g_theme->header0.r, (float)g_theme->header1.r, t),
        (int)ImLerp((float)g_theme->header0.g, (float)g_theme->header1.g, t),
        (int)ImLerp((float)g_theme->header0.b, (float)g_theme->header1.b, t));
}

static void DrawHeaderLine(ImDrawList* draw, ImVec2 a, ImVec2 b, float gap_x0 = 0.0f, float gap_x1 = 0.0f)
{
    float x0 = IM_TRUNC(a.x);
    float y0 = IM_TRUNC(a.y);
    float x1 = IM_TRUNC(b.x);
    float y1 = IM_TRUNC(b.y);
    float w = x1 - x0;
    if (w <= 0.0f)
        return;
    gap_x0 = IM_TRUNC(gap_x0);
    gap_x1 = IM_TRUNC(gap_x1);

    auto seg = [&](float xa, float xb)
    {
        if (xb <= xa)
            return;
        ImColor c0 = HeaderCol((xa - x0) / w);
        ImColor c1 = HeaderCol((xb - x0) / w);
        draw->AddRectFilledMultiColor(ImVec2(xa, y0), ImVec2(xb, y1), c0, c1, c1, c0);
    };

    if (gap_x1 > gap_x0)
    {
        seg(x0, gap_x0);
        seg(gap_x1, x1);
    }
    else
        seg(x0, x1);
}

static void DrawIsland()
{
    const int count = 6;
    const float cell = 32.0f;
    const float gap = 4.0f;
    const float pad = 6.0f;
    const float w = 2.0f + pad + cell * (float)count + gap * (float)(count - 1) + pad + 2.0f;
    const float h = 3.0f + pad + cell + pad + 2.0f;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImVec2 pos(IM_TRUNC((ds.x - w) * 0.5f), 12.0f);

    ImGui::SetNextWindowPos(pos);
    ImGui::SetNextWindowSize(ImVec2(w, h));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::Begin("island", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoNav);
    ImGui::PopStyleVar();

    ImDrawList* draw = ImGui::GetWindowDrawList();

    ImVec2 p = Snap(ImGui::GetWindowPos());
    if (p.x != ImGui::GetWindowPos().x || p.y != ImGui::GetWindowPos().y)
        ImGui::SetWindowPos(p);
    float x0 = p.x;
    float y0 = p.y;
    float x1 = x0 + w;
    float y1 = y0 + h;

    static int active = 0;
    PxFill(draw, x0, y0, x1, y1, Tc(g_theme->child));

    float sx = x0 + 2.0f + pad;
    float sy = y0 + 3.0f + pad;
    for (int i = 0; i < count; i++)
    {
        float cx = sx + (cell + gap) * (float)i;
        ImGui::SetCursorScreenPos(ImVec2(cx, sy));
        ImGui::PushID(i);
        ImGui::InvisibleButton("c", ImVec2(cell, cell));
        if (ImGui::IsItemClicked())
        {
            if (i == 0)
            {
                SetMenuOpen(!g_menu_open);
                active = 0;
            }
            else if (i == 1)
            {
                SetPlistOpen(!g_plist_open);
                active = 1;
            }
            else if (i == 2)
            {
                SetPlayerOpen(!g_player_open);
                active = 2;
            }
            else if (i == 3)
            {
                SetLuaOpen(!g_lua_open);
                active = 3;
            }
            else if (i == 5)
            {
                SetEspOpen(!g_esp_open);
                active = 5;
            }
            else
                active = i;
        }
        bool on = (i == 0) ? g_menu_open : (i == 1) ? g_plist_open : (i == 2) ? g_player_open : (i == 3) ? g_lua_open : (i == 5) ? g_esp_open : active == i;
        bool hov = ImGui::IsItemHovered();
        Rgb fill = g_theme->frame;
        if (on)
            fill = Lift(g_theme->frame, 10);
        else if (hov)
            fill = Lift(g_theme->frame, 6);
        PxFill(draw, cx, sy, cx + cell, sy + cell, Tc(fill));
        PxFill(draw, cx, sy, cx + cell, sy + 1, FadeCol(0, 0, 0));
        PxFill(draw, cx, sy + cell - 1, cx + cell, sy + cell, FadeCol(0, 0, 0));
        PxFill(draw, cx, sy, cx + 1, sy + cell, FadeCol(0, 0, 0));
        PxFill(draw, cx + cell - 1, sy, cx + cell, sy + cell, FadeCol(0, 0, 0));
        PxFill(draw, cx + 1, sy + 1, cx + cell - 1, sy + 2, Tc(g_theme->border));
        PxFill(draw, cx + 1, sy + cell - 2, cx + cell - 1, sy + cell - 1, Tc(g_theme->border));
        PxFill(draw, cx + 1, sy + 1, cx + 2, sy + cell - 1, Tc(g_theme->border));
        PxFill(draw, cx + cell - 2, sy + 1, cx + cell - 1, sy + cell - 1, Tc(g_theme->border));
        if (g_fontIcons)
        {
            static const unsigned icons[] = { 0xf015, 0xf0c0, 0xf07b, 0xf121, 0xf53f, 0xf06e };
            char buf[5];
            ImTextCharToUtf8(buf, icons[i]);
            ImGui::PushFont(g_fontIcons, 16.0f);
            ImVec2 ts = ImGui::CalcTextSize(buf);
            ImVec2 tp(IM_TRUNC(cx + (cell - ts.x) * 0.5f), IM_TRUNC(sy + (cell - ts.y) * 0.5f));
            Rgb ic = on ? g_theme->accent : (hov ? g_theme->text : g_theme->text_dim);
            draw->AddText(tp, Tc(ic), buf);
            ImGui::PopFont();
        }
        ImGui::PopID();
    }

    PxFill(draw, x0, y1 - 1, x1, y1, FadeCol(0, 0, 0));
    PxFill(draw, x0, y0, x0 + 1, y1, FadeCol(0, 0, 0));
    PxFill(draw, x1 - 1, y0, x1, y1, FadeCol(0, 0, 0));
    PxFill(draw, x0 + 1, y1 - 2, x1 - 1, y1 - 1, Tc(g_theme->border));
    PxFill(draw, x0 + 1, y0 + 1, x0 + 2, y1 - 1, Tc(g_theme->border));
    PxFill(draw, x1 - 2, y0 + 1, x1 - 1, y1 - 1, Tc(g_theme->border));
    PxFill(draw, x0, y0, x1, y0 + 1, FadeCol(0, 0, 0));
    DrawHeaderLine(draw, ImVec2(x0 + 1, y0 + 1), ImVec2(x1 - 1, y0 + 3));
    ImGui::End();
}

static void DrawBorder(ImDrawList* draw, ImVec2 a, ImVec2 b, float gap_x0 = 0.0f, float gap_x1 = 0.0f)
{
    float x0 = IM_TRUNC(a.x);
    float y0 = IM_TRUNC(a.y);
    float x1 = IM_TRUNC(b.x);
    float y1 = IM_TRUNC(b.y);
    gap_x0 = IM_TRUNC(gap_x0);
    gap_x1 = IM_TRUNC(gap_x1);
    PxFill(draw, x0, y1 - 1, x1, y1, FadeCol(0, 0, 0));
    PxFill(draw, x0, y0, x0 + 1, y1, FadeCol(0, 0, 0));
    PxFill(draw, x1 - 1, y0, x1, y1, FadeCol(0, 0, 0));
    PxFill(draw, x0 + 1, y1 - 2, x1 - 1, y1 - 1, Tc(g_theme->border));
    PxFill(draw, x0 + 1, y0 + 1, x0 + 2, y1 - 1, Tc(g_theme->border));
    PxFill(draw, x1 - 2, y0 + 1, x1 - 1, y1 - 1, Tc(g_theme->border));
    if (gap_x1 > gap_x0)
        DrawHeaderLine(draw, ImVec2(x0 + 2, y0 + 1), ImVec2(x1 - 2, y0 + 3), gap_x0, gap_x1);
    else
    {
        PxFill(draw, x0, y0, x1, y0 + 1, FadeCol(0, 0, 0));
        PxFill(draw, x0 + 1, y0 + 1, x1 - 1, y0 + 2, Tc(g_theme->border));
    }
}

static bool BeginSection(const char* label, const ImVec2& size_arg);
static void EndSection();
static int DrawTabBar(ImDrawList* draw, ImVec2 pos, ImVec2 size, const char** names, int count, int active, float* out_right = nullptr);

static float ItemRight()
{
    return IM_TRUNC(ImGui::GetCursorStartPos().x + ImGui::CalcItemWidth());
}

static bool DockLive(int id)
{
    if (id == WIN_GUI)
        return g_menu_open;
    if (id == WIN_PLIST)
        return g_plist_open;
    if (id == WIN_ESP)
        return g_esp_open;
    if (id == WIN_LUA)
        return g_lua_open;
    return g_player_open;
}

static void DockDetach(int id)
{
    for (int j = 0; j < WIN_COUNT; j++)
    {
        g_glue[id][j] = false;
        g_glue[j][id] = false;
    }
}

static void DockFlood(int id, bool mark[WIN_COUNT])
{
    mark[id] = true;
    for (int j = 0; j < WIN_COUNT; j++)
    {
        if (g_glue[id][j] && DockLive(j) && !mark[j])
            DockFlood(j, mark);
    }
}

static void DockAddPos(int id, ImVec2 d)
{
    ImGuiWindow* w = ImGui::FindWindowByName(kWinName[id]);
    if (!w)
        return;
    ImGui::SetWindowPos(kWinName[id], ImVec2(IM_TRUNC(w->Pos.x + d.x), IM_TRUNC(w->Pos.y + d.y)));
}

static void DockTrySnap(int id, float mag)
{
    ImGuiWindow* wa = ImGui::FindWindowByName(kWinName[id]);
    if (!wa)
        return;
    float ax = IM_TRUNC(wa->Pos.x);
    float ay = IM_TRUNC(wa->Pos.y);
    float aw = IM_TRUNC(wa->Size.x);
    float ah = IM_TRUNC(wa->Size.y);
    bool grp[WIN_COUNT] = {};
    DockFlood(id, grp);
    float best = mag;
    float dx = 0.0f;
    float dy = 0.0f;
    int hit = -1;
    for (int j = 0; j < WIN_COUNT; j++)
    {
        if (grp[j] || !DockLive(j))
            continue;
        ImGuiWindow* wb = ImGui::FindWindowByName(kWinName[j]);
        if (!wb)
            continue;
        float bx = IM_TRUNC(wb->Pos.x);
        float by = IM_TRUNC(wb->Pos.y);
        float bw = IM_TRUNC(wb->Size.x);
        float bh = IM_TRUNC(wb->Size.y);
        bool vov = ay < by + bh && ay + ah > by;
        bool hov = ax < bx + bw && ax + aw > bx;
        auto take = [&](float ndx, float ndy, float err)
        {
            if (ImFabs(err) >= mag || ImFabs(err) >= ImFabs(best))
                return;
            best = err;
            hit = j;
            dx = ndx;
            dy = ndy;
        };
        if (vov && ax + aw <= bx + mag)
        {
            float extra = 0.0f;
            if (ImFabs(by - ay) < mag)
                extra = by - ay;
            else if (ImFabs((by + bh) - (ay + ah)) < mag)
                extra = (by + bh - ah) - ay;
            take((bx - kDockGap - aw) - ax, extra, (bx - kDockGap - aw) - ax);
        }
        if (vov && bx + bw <= ax + mag)
        {
            float extra = 0.0f;
            if (ImFabs(by - ay) < mag)
                extra = by - ay;
            else if (ImFabs((by + bh) - (ay + ah)) < mag)
                extra = (by + bh - ah) - ay;
            take((bx + bw + kDockGap) - ax, extra, (bx + bw + kDockGap) - ax);
        }
        if (hov && ay + ah <= by + mag)
        {
            float extra = 0.0f;
            if (ImFabs(bx - ax) < mag)
                extra = bx - ax;
            else if (ImFabs((bx + bw) - (ax + aw)) < mag)
                extra = (bx + bw - aw) - ax;
            take(extra, (by - kDockGap - ah) - ay, (by - kDockGap - ah) - ay);
        }
        if (hov && by + bh <= ay + mag)
        {
            float extra = 0.0f;
            if (ImFabs(bx - ax) < mag)
                extra = bx - ax;
            else if (ImFabs((bx + bw) - (ax + aw)) < mag)
                extra = (bx + bw - aw) - ax;
            take(extra, (by + bh + kDockGap) - ay, (by + bh + kDockGap) - ay);
        }
    }
    if (hit < 0)
        return;
    dx = IM_TRUNC(dx);
    dy = IM_TRUNC(dy);
    if (dx != 0.0f || dy != 0.0f)
    {
        for (int j = 0; j < WIN_COUNT; j++)
        {
            if (grp[j])
                DockAddPos(j, ImVec2(dx, dy));
        }
    }
    g_glue[id][hit] = true;
    g_glue[hit][id] = true;
}

static void DockDrag(int id)
{
    ImGuiIO& io = ImGui::GetIO();
    if (g_dock_drag != id)
    {
        g_dock_drag = id;
        g_dock_mouse0 = io.MousePos;
        for (int j = 0; j < WIN_COUNT; j++)
        {
            ImGuiWindow* w = ImGui::FindWindowByName(kWinName[j]);
            g_dock_start[j] = w ? ImVec2(IM_TRUNC(w->Pos.x), IM_TRUNC(w->Pos.y)) : ImVec2(0.0f, 0.0f);
        }
    }
    ImVec2 total(IM_TRUNC(io.MousePos.x - g_dock_mouse0.x), IM_TRUNC(io.MousePos.y - g_dock_mouse0.y));
    ImGuiWindow* wa = ImGui::FindWindowByName(kWinName[id]);
    float aw = wa ? IM_TRUNC(wa->Size.x) : 0.0f;
    float ah = wa ? IM_TRUNC(wa->Size.y) : 0.0f;
    ImVec2 a0 = g_dock_start[id];
    if (io.KeyAlt)
    {
        for (int j = 0; j < WIN_COUNT; j++)
        {
            if (j == id || !g_glue[id][j] || !DockLive(j))
                continue;
            ImGuiWindow* wb = ImGui::FindWindowByName(kWinName[j]);
            if (!wb)
                continue;
            float bw = IM_TRUNC(wb->Size.x);
            float bh = IM_TRUNC(wb->Size.y);
            ImVec2 b0 = g_dock_start[j];
            bool away = false;
            if (ImFabs((a0.x + aw + kDockGap) - b0.x) <= 2.0f && total.x <= -kDockUnstick)
                away = true;
            if (ImFabs((b0.x + bw + kDockGap) - a0.x) <= 2.0f && total.x >= kDockUnstick)
                away = true;
            if (ImFabs((a0.y + ah + kDockGap) - b0.y) <= 2.0f && total.y <= -kDockUnstick)
                away = true;
            if (ImFabs((b0.y + bh + kDockGap) - a0.y) <= 2.0f && total.y >= kDockUnstick)
                away = true;
            if (away)
            {
                g_glue[id][j] = false;
                g_glue[j][id] = false;
            }
        }
    }
    bool grp[WIN_COUNT] = {};
    DockFlood(id, grp);
    for (int j = 0; j < WIN_COUNT; j++)
    {
        if (!grp[j])
            continue;
        ImGui::SetWindowPos(kWinName[j], ImVec2(g_dock_start[j].x + total.x, g_dock_start[j].y + total.y));
    }
}

static void OverlayClearForeignActive()
{
    ImGuiContext& g = *GImGui;
    if (!ImGui::IsMouseClicked(0))
        return;
    if (!ImGui::IsWindowHovered(ImGuiHoveredFlags_RootAndChildWindows))
        return;
    ImGuiWindow* root = ImGui::GetCurrentWindow()->RootWindow;
    if (g.ActiveId && g.ActiveIdWindow && g.ActiveIdWindow->RootWindow != root)
        ImGui::ClearActiveID();
}

static void OverlayMove(int id)
{
    if (ImGui::IsItemActive() && ImGui::IsMouseDragging(ImGuiMouseButton_Left))
        DockDrag(id);
}

static ImVec2 OverlaySnapPos()
{
    ImVec2 p = Snap(ImGui::GetWindowPos());
    if (p.x != ImGui::GetWindowPos().x || p.y != ImGui::GetWindowPos().y)
        ImGui::SetWindowPos(p);
    return p;
}

static ID3D11ShaderResourceView* g_art_srv;
static unsigned g_art_seen = 0xFFFFFFFFu;

static void SyncArtTex()
{
    unsigned gen = 0;
    int w = 0, h = 0;
    NowPlay_ArtInfo(&gen, &w, &h);
    if (gen == g_art_seen)
        return;
    if (w <= 0 || h <= 0 || !g_pd3dDevice)
        return;
    unsigned char* px = (unsigned char*)malloc((size_t)w * h * 4);
    if (!px)
        return;
    NowPlay_ArtCopy(px);
    D3D11_TEXTURE2D_DESC d{};
    d.Width = (UINT)w;
    d.Height = (UINT)h;
    d.MipLevels = 1;
    d.ArraySize = 1;
    d.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    d.SampleDesc.Count = 1;
    d.Usage = D3D11_USAGE_IMMUTABLE;
    d.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA sd{};
    sd.pSysMem = px;
    sd.SysMemPitch = (UINT)w * 4;
    ID3D11Texture2D* tex = nullptr;
    ID3D11ShaderResourceView* srv = nullptr;
    if (SUCCEEDED(g_pd3dDevice->CreateTexture2D(&d, &sd, &tex)))
    {
        g_pd3dDevice->CreateShaderResourceView(tex, nullptr, &srv);
        tex->Release();
    }
    free(px);
    if (!srv)
        return;
    if (g_art_srv)
        g_art_srv->Release();
    g_art_srv = srv;
    g_art_seen = gen;
}

static ID3D11Texture2D* g_vid_tex;
static ID3D11ShaderResourceView* g_vid_srv;
static int g_vid_w;
static int g_vid_h;
static unsigned g_vid_seen = 0xFFFFFFFFu;

static void DropVideoTex()
{
    if (g_vid_srv)
    {
        g_vid_srv->Release();
        g_vid_srv = nullptr;
    }
    if (g_vid_tex)
    {
        g_vid_tex->Release();
        g_vid_tex = nullptr;
    }
    g_vid_w = g_vid_h = 0;
}

static void SyncVideoTex()
{
    unsigned gen;
    int w, h;
    Yt_FrameInfo(&gen, &w, &h);
    if (gen == g_vid_seen)
        return;
    g_vid_seen = gen;
    if (w <= 0 || h <= 0)
    {
        DropVideoTex();
        return;
    }
    if (w != g_vid_w || h != g_vid_h || !g_vid_tex)
    {
        DropVideoTex();
        D3D11_TEXTURE2D_DESC d{};
        d.Width = (UINT)w;
        d.Height = (UINT)h;
        d.MipLevels = 1;
        d.ArraySize = 1;
        d.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
        d.SampleDesc.Count = 1;
        d.Usage = D3D11_USAGE_DYNAMIC;
        d.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        d.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
        if (FAILED(g_pd3dDevice->CreateTexture2D(&d, nullptr, &g_vid_tex)))
            return;
        g_pd3dDevice->CreateShaderResourceView(g_vid_tex, nullptr, &g_vid_srv);
        g_vid_w = w;
        g_vid_h = h;
    }
    D3D11_MAPPED_SUBRESOURCE m;
    if (FAILED(g_pd3dDeviceContext->Map(g_vid_tex, 0, D3D11_MAP_WRITE_DISCARD, 0, &m)))
        return;
    Yt_FrameCopy((unsigned char*)m.pData, (int)m.RowPitch);
    g_pd3dDeviceContext->Unmap(g_vid_tex, 0);
}

static void DrawFrameBox(ImDrawList* draw, float x, float y, float w, float h, ImColor fill)
{
    PxFill(draw, x, y, x + w, y + h, fill);
    PxFill(draw, x, y, x + w, y + 1, FadeCol(0, 0, 0));
    PxFill(draw, x, y + h - 1, x + w, y + h, FadeCol(0, 0, 0));
    PxFill(draw, x, y, x + 1, y + h, FadeCol(0, 0, 0));
    PxFill(draw, x + w - 1, y, x + w, y + h, FadeCol(0, 0, 0));
    PxFill(draw, x + 1, y + 1, x + w - 1, y + 2, Tc(g_theme->border));
    PxFill(draw, x + 1, y + h - 2, x + w - 1, y + h - 1, Tc(g_theme->border));
    PxFill(draw, x + 1, y + 1, x + 2, y + h - 1, Tc(g_theme->border));
    PxFill(draw, x + w - 2, y + 1, x + w - 1, y + h - 1, Tc(g_theme->border));
}

static void DrawAvBox(ImDrawList* draw, float x, float y, float s, bool on, ID3D11ShaderResourceView* srv = nullptr)
{
    x = IM_TRUNC(x);
    y = IM_TRUNC(y);
    s = IM_TRUNC(s);
    PxFill(draw, x, y, x + s, y + s, Tc(on ? Lift(g_theme->frame, 10) : g_theme->frame));
    PxFill(draw, x, y, x + s, y + 1, FadeCol(0, 0, 0));
    PxFill(draw, x, y + s - 1, x + s, y + s, FadeCol(0, 0, 0));
    PxFill(draw, x, y, x + 1, y + s, FadeCol(0, 0, 0));
    PxFill(draw, x + s - 1, y, x + s, y + s, FadeCol(0, 0, 0));
    PxFill(draw, x + 1, y + 1, x + s - 1, y + 2, Tc(g_theme->border));
    PxFill(draw, x + 1, y + s - 2, x + s - 1, y + s - 1, Tc(g_theme->border));
    PxFill(draw, x + 1, y + 1, x + 2, y + s - 1, Tc(g_theme->border));
    PxFill(draw, x + s - 2, y + 1, x + s - 1, y + s - 1, Tc(g_theme->border));
    if (srv)
        draw->AddImage(ImTextureRef((ImTextureID)(intptr_t)srv), ImVec2(x + 2, y + 2), ImVec2(x + s - 2, y + s - 2));
}

static void DrawVolCtrl(ImDrawList* draw, float mt_x, float vl_x, float vol_w, float cy, float ch, float bh)
{
    bool muted = NowPlay_Muted();
    float vol = NowPlay_Vol();
    float gy = cy + 3.0f;
    ImGui::SetCursorScreenPos(ImVec2(mt_x, cy));
    ImGui::InvisibleButton("mute", ImVec2(12.0f, ch));
    if (ImGui::IsItemClicked())
        NowPlay_ToggleMute();
    ImColor mcol = (muted || ImGui::IsItemHovered()) ? Tc(g_theme->accent) : Tc(g_theme->text_dim);
    PxFill(draw, mt_x + 1, gy + 3, mt_x + 4, gy + 7, mcol);
    draw->AddTriangleFilled(ImVec2(mt_x + 9, gy + 1), ImVec2(mt_x + 4, gy + 5), ImVec2(mt_x + 9, gy + 9), mcol);
    if (muted)
        PxFill(draw, mt_x, gy + 9, mt_x + 10, gy + 10, mcol);
    float vl_y = cy + IM_TRUNC((ch - bh) * 0.5f);
    ImGui::SetCursorScreenPos(ImVec2(vl_x, vl_y - 3.0f));
    ImGui::InvisibleButton("vol", ImVec2(vol_w, bh + 6.0f));
    if (ImGui::IsItemActive())
        NowPlay_SetVol(ImClamp((ImGui::GetIO().MousePos.x - vl_x) / vol_w, 0.0f, 1.0f));
    float vl_f = IM_TRUNC(vol_w * (muted ? 0.0f : ImClamp(vol, 0.0f, 1.0f)));
    draw->AddRectFilledMultiColor(ImVec2(vl_x, vl_y), ImVec2(vl_x + vol_w, vl_y + bh), Tc(g_theme->frame), Tc(g_theme->frame), Tc(g_theme->win), Tc(g_theme->win));
    if (vl_f > 0.0f)
        draw->AddRectFilledMultiColor(ImVec2(vl_x, vl_y), ImVec2(vl_x + vl_f, vl_y + bh), Tc(g_theme->accent), Tc(g_theme->accent), Tc(g_theme->accent_lo), Tc(g_theme->accent_lo));
    draw->AddRect(ImVec2(vl_x, vl_y), ImVec2(vl_x + vol_w, vl_y + bh), FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(vl_x + 1, vl_y + 1), ImVec2(vl_x + vol_w - 1, vl_y + bh - 1), Tc(g_theme->border));
}

static void DrawMediaPlayer()
{
    float alpha = PlayerAlpha();
    if (alpha <= 0.0f)
        return;
    Yt_Tick();
    NowTrack np = NowPlay_Get();
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    if (g_video_full && !g_video_open)
    {
        g_video_full = false;
        g_video_full_restore = false;
    }
    if (g_video_full && ImGui::IsKeyPressed(ImGuiKey_Escape))
    {
        g_video_full = false;
        g_video_full_restore = true;
    }
    ImGui::SetNextWindowPos(ImVec2(IM_TRUNC(ds.x - 340.0f), IM_TRUNC(ds.y - 228.0f)), ImGuiCond_FirstUseEver);
    if (g_video_full)
    {
        ImGui::SetNextWindowPos(ImVec2(0.0f, 0.0f), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ds, ImGuiCond_Always);
    }
    else if (g_video_full_restore)
    {
        ImGui::SetNextWindowPos(g_video_full_pos);
        ImGui::SetNextWindowSize(g_video_full_sz);
        g_video_full_restore = false;
    }
    else if (g_video_open)
    {
        if (g_video_resize)
        {
            ImGui::SetNextWindowSize(ImVec2(480.0f, 330.0f));
            g_video_resize = false;
        }
        ImGui::SetNextWindowSizeConstraints(ImVec2(320.0f, 220.0f), ImVec2(FLT_MAX, FLT_MAX));
    }
    else
        ImGui::SetNextWindowSize(ImVec2(320.0f, g_vis_on ? 208.0f : 116.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove;
    if (!g_video_open || g_video_full)
        flags |= ImGuiWindowFlags_NoResize;
    if (!g_player_open)
        flags |= ImGuiWindowFlags_NoMouseInputs | ImGuiWindowFlags_NoNav;
    ImGui::Begin("player", nullptr, flags);
    ImGui::PopStyleVar();
    OverlayClearForeignActive();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 p = OverlaySnapPos();
    ImVec2 sz = Snap(ImGui::GetWindowSize());
    if (sz.x != ImGui::GetWindowSize().x || sz.y != ImGui::GetWindowSize().y)
        ImGui::SetWindowSize(sz);
    const float w = sz.x;
    const float h = sz.y;
    float x0 = p.x;
    float y0 = p.y;
    float x1 = x0 + w;
    float y1 = y0 + h;
    PxFill(draw, x0, y0, x1, y1, Tc(g_theme->child));
    DrawBorder(draw, ImVec2(x0, y0), ImVec2(x1, y1));
    DrawHeaderLine(draw, ImVec2(x0 + 1, y0 + 1), ImVec2(x1 - 1, y0 + 3));
    ImGui::SetCursorScreenPos(ImVec2(x0, y0));
    ImGui::InvisibleButton("drag", ImVec2(w, 10.0f));
    OverlayMove(WIN_PLAYER);

    float dt = ImGui::GetIO().DeltaTime;
    float tcur = NowPlay_Pos();
    bool have_dur = np.valid && np.dur > 1.0;
    float tlen = have_dur ? (float)np.dur : 0.0f;
    bool playing = np.valid && np.playing;
    float row_y, cy;
    if (g_video_open)
    {
        char key[520];
        snprintf(key, sizeof(key), "%s|%s", np.title, np.artist);
        if (np.valid && (np.title[0] || np.artist[0]) && strcmp(key, g_video_key) != 0
            && (strcmp(np.source, "spotify") == 0 || strcmp(np.source, "soundcloud") == 0))
        {
            strncpy_s(g_video_key, key, _TRUNCATE);
            Yt_Open(np.title, np.artist);
            g_video_sync_t = 0.0;
        }
        SyncVideoTex();
        float vx = x0 + 6.0f;
        float vy = y0 + 8.0f;
        float vw = w - 12.0f;
        float vh = h - 8.0f - 52.0f;
        DrawFrameBox(draw, vx, vy, vw, vh, FadeCol(0, 0, 0));
        ImGui::SetCursorScreenPos(ImVec2(vx, vy));
        ImGui::InvisibleButton("vidhit", ImVec2(vw, vh));
        if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0))
        {
            if (g_video_full)
            {
                g_video_full = false;
                g_video_full_restore = true;
            }
            else
            {
                g_video_full_pos = ImVec2(x0, y0);
                g_video_full_sz = ImVec2(w, h);
                DockDetach(WIN_PLAYER);
                g_video_full = true;
            }
        }
        if (g_vid_srv)
        {
            float iw = vw - 4.0f;
            float ih = vh - 4.0f;
            float ar = (float)g_vid_w / (float)g_vid_h;
            float dw = iw;
            float dh = IM_TRUNC(iw / ar);
            if (dh > ih)
            {
                dh = ih;
                dw = IM_TRUNC(ih * ar);
            }
            float dx = IM_TRUNC(vx + 2.0f + (iw - dw) * 0.5f);
            float dy = IM_TRUNC(vy + 2.0f + (ih - dh) * 0.5f);
            draw->AddImage(ImTextureRef((ImTextureID)(intptr_t)g_vid_srv), ImVec2(dx, dy), ImVec2(dx + dw, dy + dh));
        }
        else
        {
            const char* msg = Yt_Busy() ? "searching" : Yt_HasVideo() ? "loading" : "no video";
            ImVec2 ms = ImGui::CalcTextSize(msg);
            TextOutlined(draw, ImVec2(IM_TRUNC(vx + (vw - ms.x) * 0.5f), IM_TRUNC(vy + (vh - ms.y) * 0.5f)), Tc(g_theme->text_dim), msg);
        }
        row_y = y1 - 44.0f;
        cy = y1 - 26.0f;
        g_lyrics_open = false;
    }
    else
    {
        row_y = y0 + 64.0f;
        cy = y0 + 86.0f;
        const char* title = (np.valid && np.title[0]) ? np.title : "nothing playing";
        const char* artist = (np.valid && np.artist[0]) ? np.artist : (np.valid ? np.source : "");
        float art = 48.0f;
        float ax = x0 + 8.0f;
        float ay = y0 + 10.0f;
        SyncArtTex();
        DrawAvBox(draw, ax, ay, art, playing, g_art_srv);
        float tx = ax + art + 8.0f;
        draw->PushClipRect(ImVec2(tx, ay), ImVec2(x1 - 8.0f, ay + 48.0f), true);
        ImGui::PushFont(g_fontTitle, FONT_SIZE);
        TextOutlined(draw, ImVec2(tx, ay + 2.0f), Tc(g_theme->text), title);
        ImGui::PopFont();
        TextOutlined(draw, ImVec2(tx, ay + 18.0f), Tc(g_theme->text_dim), artist);
        if (np.valid && np.source[0])
            TextOutlined(draw, ImVec2(tx, ay + 32.0f), Tc(g_theme->accent), np.source);
        draw->PopClipRect();
    }
    float ratio = have_dur ? ImClamp(tcur / tlen, 0.0f, 1.0f) : 0.0f;
    bool show_lyr = !g_video_open && np.valid && strcmp(np.source, "spotify") == 0 && NowPlay_LyricCount() > 0;
    if (!show_lyr)
        g_lyrics_open = false;

    float bx = x0 + 8.0f;
    float bw = w - 16.0f;
    char t0[8], t1[8];
    int c0 = (int)tcur;
    int c1 = have_dur ? (int)tlen : 0;
    snprintf(t0, sizeof(t0), "%d:%02d", c0 / 60, c0 % 60);
    snprintf(t1, sizeof(t1), "%d:%02d", c1 / 60, c1 % 60);
    ImVec2 z0 = ImGui::CalcTextSize(t0);
    ImVec2 z1 = ImGui::CalcTextSize(t1);
    float bh = 6.0f;
    float bar_x = bx + z0.x + 6.0f;
    float bar_w = bw - z0.x - z1.x - 12.0f;
    float bar_y = row_y + IM_TRUNC((z0.y - bh) * 0.5f);
    ImGui::SetCursorScreenPos(ImVec2(bar_x, bar_y - 3.0f));
    ImGui::InvisibleButton("seek", ImVec2(bar_w, bh + 6.0f));
    bool user_seek = ImGui::IsItemActive() && have_dur;
    if (user_seek)
    {
        double t = ImClamp((ImGui::GetIO().MousePos.x - bar_x) / bar_w, 0.0f, 1.0f) * (double)tlen;
        NowPlay_Seek(t);
        if (g_video_open)
            Yt_Seek(t);
    }
    ImGuiWindow* pw = ImGui::GetCurrentWindow();
    float* anim_seek = pw->StateStorage.GetFloatRef(pw->GetID("seekv"), ratio);
    if (fabsf(*anim_seek - ratio) > 0.08f)
        *anim_seek = ratio;
    else
        *anim_seek = ImLerp(*anim_seek, ratio, 18.0f * dt);
    float fill = *anim_seek <= 0.0f ? 0.0f : IM_TRUNC(bar_w * *anim_seek + 0.5f);
    if (fill > bar_w)
        fill = bar_w;
    draw->AddRectFilledMultiColor(ImVec2(bar_x, bar_y), ImVec2(bar_x + bar_w, bar_y + bh), Tc(g_theme->frame), Tc(g_theme->frame), Tc(g_theme->win), Tc(g_theme->win));
    if (fill > 0.0f)
        draw->AddRectFilledMultiColor(ImVec2(bar_x, bar_y), ImVec2(bar_x + fill, bar_y + bh), Tc(g_theme->accent), Tc(g_theme->accent), Tc(g_theme->accent_lo), Tc(g_theme->accent_lo));
    draw->AddRect(ImVec2(bar_x, bar_y), ImVec2(bar_x + bar_w, bar_y + bh), FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(bar_x + 1, bar_y + 1), ImVec2(bar_x + bar_w - 1, bar_y + bh - 1), Tc(g_theme->border));
    TextOutlined(draw, ImVec2(bx, row_y), Tc(g_theme->text_dim), t0);
    TextOutlined(draw, ImVec2(bx + bw - z1.x, row_y), Tc(g_theme->text_dim), t1);

    float cw = 18.0f;
    float ch = 16.0f;
    float cg = 10.0f;
    float row = cw * 3.0f + cg * 2.0f;
    float cx0 = IM_TRUNC(x0 + (w - row) * 0.5f);
    ImGui::SetCursorScreenPos(ImVec2(cx0, cy));
    ImGui::InvisibleButton("prev", ImVec2(cw, ch));
    if (ImGui::IsItemClicked() && np.valid)
        NowPlay_Prev();
    bool hprev = ImGui::IsItemHovered();
    ImGui::SameLine(0.0f, cg);
    ImGui::InvisibleButton("play", ImVec2(cw, ch));
    if (ImGui::IsItemClicked() && np.valid)
        NowPlay_PlayPause();
    bool hplay = ImGui::IsItemHovered();
    ImGui::SameLine(0.0f, cg);
    ImGui::InvisibleButton("next", ImVec2(cw, ch));
    if (ImGui::IsItemClicked() && np.valid)
        NowPlay_Next();
    bool hnext = ImGui::IsItemHovered();
    if (g_video_open)
    {
        ImGui::SetCursorScreenPos(ImVec2(x0 + 8.0f, cy));
        ImGui::InvisibleButton("video", ImVec2(36.0f, ch));
        if (ImGui::IsItemClicked())
        {
            g_video_open = false;
            g_video_full = false;
            g_video_full_restore = false;
            g_video_key[0] = 0;
            Yt_Close();
        }
        TextOutlined(draw, ImVec2(x0 + 8.0f, cy + 1.0f), Tc(g_theme->accent), "video");
        ImGui::SetCursorScreenPos(ImVec2(x0 + 48.0f, cy));
        ImGui::InvisibleButton("full", ImVec2(28.0f, ch));
        if (ImGui::IsItemClicked())
        {
            if (g_video_full)
            {
                g_video_full = false;
                g_video_full_restore = true;
            }
            else
            {
                g_video_full_pos = ImVec2(x0, y0);
                g_video_full_sz = ImVec2(w, h);
                DockDetach(WIN_PLAYER);
                g_video_full = true;
            }
        }
        bool hfull = ImGui::IsItemHovered();
        TextOutlined(draw, ImVec2(x0 + 48.0f, cy + 1.0f), (g_video_full || hfull) ? Tc(g_theme->accent) : Tc(g_theme->text_dim), "full");
    }
    else
    {
        ImGui::SetCursorScreenPos(ImVec2(x0 + 8.0f, cy));
        ImGui::InvisibleButton("vis", ImVec2(22.0f, ch));
        if (ImGui::IsItemClicked())
            g_vis_on = !g_vis_on;
        bool hvis = ImGui::IsItemHovered();
        TextOutlined(draw, ImVec2(x0 + 8.0f, cy + 1.0f), (g_vis_on || hvis) ? Tc(g_theme->accent) : Tc(g_theme->text_dim), "vis");
        if (show_lyr)
        {
            ImGui::SetCursorScreenPos(ImVec2(x0 + 34.0f, cy));
            ImGui::InvisibleButton("lyrics", ImVec2(44.0f, ch));
            if (ImGui::IsItemClicked())
                g_lyrics_open = !g_lyrics_open;
            bool hlyr = ImGui::IsItemHovered();
            TextOutlined(draw, ImVec2(x0 + 34.0f, cy + 1.0f), (g_lyrics_open || hlyr) ? Tc(g_theme->accent) : Tc(g_theme->text_dim), "lyrics");
        }
        float vid_x = x1 - 8.0f - 36.0f;
        ImGui::SetCursorScreenPos(ImVec2(vid_x, cy));
        ImGui::InvisibleButton("video", ImVec2(36.0f, ch));
        if (ImGui::IsItemClicked() && np.valid && (np.title[0] || np.artist[0]))
        {
            g_video_open = true;
            g_video_resize = true;
            snprintf(g_video_key, sizeof(g_video_key), "%s|%s", np.title, np.artist);
            Yt_Open(np.title, np.artist);
            Yt_SetMuted(true);
            Yt_SetPlay(playing);
            if (have_dur)
                Yt_Seek(tcur);
            g_video_sync_t = 0.0;
        }
        bool hvid = ImGui::IsItemHovered();
        TextOutlined(draw, ImVec2(vid_x + 2.0f, cy + 1.0f), hvid ? Tc(g_theme->accent) : Tc(g_theme->text_dim), "video");
    }
    float vol_w = 48.0f;
    float vl_x = (g_video_open ? x1 - 8.0f : x1 - 8.0f - 36.0f - 6.0f) - vol_w;
    float mt_x = vl_x - 14.0f;
    DrawVolCtrl(draw, mt_x, vl_x, vol_w, cy, ch, bh);
    if (g_video_open && !user_seek)
    {
        Yt_SetMuted(true);
        Yt_SetPlay(playing && Yt_HasVideo());
        YtState yt = Yt_State();
        if (yt.dur > 1.0)
        {
            double drift = (double)tcur - yt.pos;
            double now = ImGui::GetTime();
            if (fabs(drift) > 0.35 && (fabs(drift) > 1.2 || now - g_video_sync_t > 0.35))
            {
                Yt_Seek(tcur);
                g_video_sync_t = now;
            }
        }
    }

    auto icon = [&](bool hov) { return hov ? Tc(g_theme->accent) : Tc(g_theme->text); };
    float px = cx0 + 4.0f;
    float py = cy + 3.0f;
    PxFill(draw, px, py, px + 2, py + 10, icon(hprev));
    draw->AddTriangleFilled(ImVec2(px + 12, py), ImVec2(px + 2, py + 5), ImVec2(px + 12, py + 10), icon(hprev));
    float mx = cx0 + cw + cg + 5.0f;
    if (playing)
    {
        PxFill(draw, mx, py, mx + 3, py + 10, icon(hplay));
        PxFill(draw, mx + 6, py, mx + 9, py + 10, icon(hplay));
    }
    else
        draw->AddTriangleFilled(ImVec2(mx, py), ImVec2(mx, py + 10), ImVec2(mx + 9, py + 5), icon(hplay));
    float nx = cx0 + (cw + cg) * 2.0f + 2.0f;
    draw->AddTriangleFilled(ImVec2(nx, py), ImVec2(nx + 10, py + 5), ImVec2(nx, py + 10), icon(hnext));
    PxFill(draw, nx + 10, py, nx + 12, py + 10, icon(hnext));

    if (g_vis_on && !g_video_open)
    {
        float vx = x0 + 8.0f;
        float vy = y0 + 112.0f;
        float vw = w - 16.0f;
        float vh = 88.0f;
        DrawFrameBox(draw, vx, vy, vw, vh, Tc(g_theme->win));
        DrawHeaderLine(draw, ImVec2(vx + 2, vy + 2), ImVec2(vx + vw - 2, vy + 4));

        float inner_x = vx + 4.0f;
        float inner_y = vy + 8.0f;
        int iw = (int)(vw - 8.0f);
        float inner_h = vh - 12.0f;
        const int gap = 2;
        int barw = 4;
        int n = 0;
        for (int b = 4; b <= 6; b++)
        {
            if ((iw + gap) % (b + gap) == 0)
            {
                int cand = (iw + gap) / (b + gap);
                if (cand >= 16 && cand <= 48)
                {
                    barw = b;
                    n = cand;
                    break;
                }
            }
        }
        if (!n)
        {
            barw = 4;
            n = (iw + gap) / (barw + gap);
            if (n > 48)
                n = 48;
            if (n < 16)
                n = 16;
        }
        int used = n * barw + (n - 1) * gap;
        float x = inner_x + IM_TRUNC((float)(iw - used) * 0.5f);
        float spec[48];
        NowPlay_Vis(spec, n);
        static float bars[48];
        for (int i = 0; i < n; i++)
        {
            float want = spec[i];
            if (want > bars[i])
                bars[i] = want;
            else
                bars[i] = ImLerp(bars[i], want, ImSaturate(12.0f * dt));
            float bh2 = IM_TRUNC(inner_h * bars[i]);
            if (playing && bh2 < 2.0f)
                bh2 = 2.0f;
            if (bh2 >= 1.0f)
            {
                float y = inner_y + inner_h - bh2;
                draw->AddRectFilledMultiColor(ImVec2(x, y), ImVec2(x + (float)barw, inner_y + inner_h), Tc(g_theme->accent), Tc(g_theme->accent), Tc(g_theme->accent_lo), Tc(g_theme->accent_lo));
            }
            x += (float)(barw + gap);
        }
    }

    ImGui::End();
    ImGui::PopStyleVar();
}

static void DrawLyrics()
{
    if (!g_lyrics_open)
        return;
    float alpha = PlayerAlpha();
    if (alpha <= 0.0f)
        return;
    const float w = 280.0f;
    const float h = 180.0f;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(IM_TRUNC(ds.x - w - 20.0f), IM_TRUNC(ds.y - h - 240.0f)), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w, h));
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove;
    ImGui::Begin("lyrics", nullptr, flags);
    ImGui::PopStyleVar();
    OverlayClearForeignActive();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 p = OverlaySnapPos();
    float x0 = p.x;
    float y0 = p.y;
    float x1 = x0 + w;
    float y1 = y0 + h;
    PxFill(draw, x0, y0, x1, y1, Tc(g_theme->child));
    DrawBorder(draw, ImVec2(x0, y0), ImVec2(x1, y1));
    DrawHeaderLine(draw, ImVec2(x0 + 1, y0 + 1), ImVec2(x1 - 1, y0 + 3));
    ImGui::SetCursorScreenPos(ImVec2(x0, y0));
    ImGui::InvisibleButton("drag", ImVec2(w, 22.0f));
    if (ImGui::IsItemActive() && ImGui::IsMouseDragging(ImGuiMouseButton_Left))
    {
        ImVec2 np = ImGui::GetWindowPos();
        np.x = IM_TRUNC(np.x + ImGui::GetIO().MouseDelta.x);
        np.y = IM_TRUNC(np.y + ImGui::GetIO().MouseDelta.y);
        ImGui::SetWindowPos(np);
    }
    ImGui::PushFont(g_fontTitle, FONT_SIZE);
    TextOutlined(draw, ImVec2(x0 + 8.0f, y0 + 6.0f), Tc(g_theme->text), "lyrics");
    ImGui::PopFont();
    int n = NowPlay_LyricCount();
    bool synced = NowPlay_LyricSynced();
    int cur = synced ? NowPlay_LyricAt(NowPlay_Pos()) : 0;
    if (n <= 0)
        TextOutlined(draw, ImVec2(x0 + 8.0f, y0 + 32.0f), Tc(g_theme->text_dim), "no lyrics");
    else
    {
        int from = synced ? cur - 2 : 0;
        if (from < 0)
            from = 0;
        float y = y0 + 28.0f;
        draw->PushClipRect(ImVec2(x0 + 6.0f, y0 + 26.0f), ImVec2(x1 - 6.0f, y1 - 6.0f), true);
        for (int i = from; i < n && y < y1 - 8.0f; i++)
        {
            char line[160];
            float ts;
            NowPlay_Lyric(i, &ts, line, 160);
            bool on = synced && i == cur;
            if (on)
                ImGui::PushFont(g_fontTitle, FONT_SIZE);
            TextOutlined(draw, ImVec2(x0 + 8.0f, y), on ? Tc(g_theme->accent) : Tc(g_theme->text_dim), line[0] ? line : " ");
            if (on)
                ImGui::PopFont();
            y += 18.0f;
        }
        draw->PopClipRect();
    }
    ImGui::End();
    ImGui::PopStyleVar();
}

static void DrawEspPreview()
{
    float alpha = EspAlpha();
    if (alpha <= 0.0f)
        return;
    const float w = 300.0f;
    const float h = 400.0f;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(IM_TRUNC(ds.x - w - 20.0f), 80.0f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w, h));
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove;
    if (!g_esp_open)
        flags |= ImGuiWindowFlags_NoMouseInputs | ImGuiWindowFlags_NoNav;
    ImGui::Begin("esp", nullptr, flags);
    ImGui::PopStyleVar();
    OverlayClearForeignActive();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 p = OverlaySnapPos();
    float x0 = p.x;
    float y0 = p.y;
    float x1 = x0 + w;
    float y1 = y0 + h;
    PxFill(draw, x0, y0, x1, y1, Tc(g_theme->child));
    DrawBorder(draw, ImVec2(x0, y0), ImVec2(x1, y1));
    DrawHeaderLine(draw, ImVec2(x0 + 1, y0 + 1), ImVec2(x1 - 1, y0 + 3));
    ImGui::SetCursorScreenPos(ImVec2(x0, y0));
    ImGui::InvisibleButton("drag", ImVec2(w, 20.0f));
    OverlayMove(WIN_ESP);
    ImGui::SetCursorPos(ImVec2(8.0f, 22.0f));
    BeginSection("esp", ImVec2(w - 16.0f, h - 30.0f));
    ImVec2 avail = ImGui::GetContentRegionAvail();
    float vw = IM_TRUNC(avail.x);
    float vh = IM_TRUNC(avail.y);
    if (vw < 64.0f)
        vw = 64.0f;
    if (vh < 64.0f)
        vh = 64.0f;
    Avatar3D::SetViewSize((int)vw, (int)vh);
    ImVec2 img_min = ImGui::GetCursorScreenPos();
    ImVec2 img_max = ImVec2(img_min.x + vw, img_min.y + vh);
    ImGui::InvisibleButton("##avatar3d", ImVec2(vw, vh));
    if (ImGui::IsItemActive() && ImGui::IsMouseDragging(ImGuiMouseButton_Left))
        Avatar3D::Orbit(ImGui::GetIO().MouseDelta.x, ImGui::GetIO().MouseDelta.y);
    if (ImGui::IsItemHovered() && ImGui::GetIO().MouseWheel != 0.0f)
        Avatar3D::Zoom(ImGui::GetIO().MouseWheel);
    Avatar3D::Render();
    ImDrawList* body = ImGui::GetWindowDrawList();
    if (ID3D11ShaderResourceView* srv = Avatar3D::Srv())
        body->AddImage(ImTextureRef((ImTextureID)(intptr_t)srv), img_min, img_max);
    else
    {
        const char* msg = Avatar3D::Failed() ? "failed" : "loading";
        ImGui::PushFont(g_fontVerdana, FONT_SIZE);
        ImVec2 ts = ImGui::CalcTextSize(msg);
        TextOutlined(body, ImVec2(IM_TRUNC(img_min.x + (vw - ts.x) * 0.5f), IM_TRUNC(img_min.y + (vh - ts.y) * 0.5f)), Tc(g_theme->text_dim), msg);
        ImGui::PopFont();
    }
    EndSection();
    ImGui::End();
    ImGui::PopStyleVar();
}

static void LuaOpenFile()
{
    wchar_t path[MAX_PATH]{};
    if (g_lua_path[0])
        wcsncpy_s(path, g_lua_path, _TRUNCATE);
    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g_hwnd;
    ofn.lpstrFilter = L"Lua (*.lua)\0*.lua\0All (*.*)\0*.*\0";
    ofn.lpstrFile = path;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    ofn.lpstrDefExt = L"lua";
    if (!GetOpenFileNameW(&ofn))
        return;
    HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE)
        return;
    LARGE_INTEGER sz{};
    if (!GetFileSizeEx(f, &sz) || sz.QuadPart < 0)
    {
        CloseHandle(f);
        return;
    }
    DWORD n = (DWORD)sz.QuadPart;
    if (n >= sizeof(g_lua_buf))
        n = (DWORD)sizeof(g_lua_buf) - 1;
    DWORD got = 0;
    if (!ReadFile(f, g_lua_buf, n, &got, nullptr))
        got = 0;
    CloseHandle(f);
    g_lua_buf[got] = 0;
    wcsncpy_s(g_lua_path, path, _TRUNCATE);
}

static void LuaSaveFile()
{
    wchar_t path[MAX_PATH]{};
    if (g_lua_path[0])
        wcsncpy_s(path, g_lua_path, _TRUNCATE);
    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g_hwnd;
    ofn.lpstrFilter = L"Lua (*.lua)\0*.lua\0All (*.*)\0*.*\0";
    ofn.lpstrFile = path;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    ofn.lpstrDefExt = L"lua";
    if (!GetSaveFileNameW(&ofn))
        return;
    HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE)
        return;
    DWORD n = (DWORD)strlen(g_lua_buf);
    DWORD put = 0;
    WriteFile(f, g_lua_buf, n, &put, nullptr);
    CloseHandle(f);
    wcsncpy_s(g_lua_path, path, _TRUNCATE);
}

static void LuaSeedDemo()
{
    if (g_lua_seeded)
        return;
    g_lua_seeded = true;
    const char* src =
        "local говно = {\n"
        "    говно = true,\n"
        "    говно_count = 12,\n"
        "    говно_list = { \"говно\", \"говно\", \"говно\" },\n"
        "}\n"
        "\n"
        "local function говно_print(говно)\n"
        "    print(\"говно:\", говно)\n"
        "end\n"
        "\n"
        "local function говно_loop(говно)\n"
        "    for i = 1, говно.говно_count do\n"
        "        if говно.говно then\n"
        "            local говно_i = (i % #говно.говно_list) + 1\n"
        "            говно_print(говно.говно_list[говно_i])\n"
        "        else\n"
        "            говно.говно = not говно.говно\n"
        "        end\n"
        "    end\n"
        "    return говно\n"
        "end\n"
        "\n"
        "local function говно_map(говно, fn)\n"
        "    local говно_out = {}\n"
        "    for k, v in pairs(говно) do\n"
        "        говно_out[k] = fn(v, k, говно)\n"
        "    end\n"
        "    return говно_out\n"
        "end\n"
        "\n"
        "говно_loop(говно)\n"
        "\n"
        "local говно_ready = говно_map(говно.говно_list, function(говно)\n"
        "    return говно .. \" говно\"\n"
        "end)\n"
        "\n"
        "for _, говно in ipairs(говно_ready) do\n"
        "    говно_print(говно)\n"
        "end\n";
    strncpy_s(g_lua_buf, src, _TRUNCATE);
}

static int LuaLineCount()
{
    int n = 1;
    for (const char* s = g_lua_buf; *s; s++)
        if (*s == '\n')
            n++;
    return n;
}

static void DrawLuaExecutor()
{
    float alpha = LuaAlpha();
    if (alpha <= 0.0f)
        return;
    const float w = 440.0f;
    const float h = 360.0f;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(IM_TRUNC((ds.x - w) * 0.5f), 80.0f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w, h));
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove;
    if (!g_lua_open)
        flags |= ImGuiWindowFlags_NoMouseInputs | ImGuiWindowFlags_NoNav;
    ImGui::Begin("lua", nullptr, flags);
    ImGui::PopStyleVar();
    OverlayClearForeignActive();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 p = OverlaySnapPos();
    float x0 = p.x;
    float y0 = p.y;
    float x1 = x0 + w;
    float y1 = y0 + h;
    PxFill(draw, x0, y0, x1, y1, Tc(g_theme->child));
    DrawBorder(draw, ImVec2(x0, y0), ImVec2(x1, y1));
    DrawHeaderLine(draw, ImVec2(x0 + 1, y0 + 1), ImVec2(x1 - 1, y0 + 3));
    ImGui::SetCursorScreenPos(ImVec2(x0, y0));
    ImGui::InvisibleButton("drag", ImVec2(w, 8.0f));
    OverlayMove(WIN_LUA);
    ImVec2 child_pos(x0 + 8.0f, y0 + 8.0f);
    ImVec2 child_size(w - 16.0f, h - 16.0f);
    const char* lua_tabs[] = { "lua", "output" };
    float tabs_r = x0 + 8.0f;
    g_lua_tab = DrawTabBar(draw, child_pos, child_size, lua_tabs, 2, g_lua_tab, &tabs_r);
    ImGui::SetCursorScreenPos(ImVec2(tabs_r, y0 + 8.0f));
    ImGui::InvisibleButton("drag2", ImVec2(ImMax(1.0f, x1 - tabs_r), 26.0f));
    OverlayMove(WIN_LUA);
    float tab_h = 26.0f;
    ImVec2 content_pos(child_pos.x + 6.0f, child_pos.y + tab_h + 6.0f);
    ImVec2 content_size(child_size.x - 12.0f, child_size.y - tab_h - 6.0f);
    ImGui::SetCursorPos(Snap(ImVec2(content_pos.x - x0, content_pos.y - y0)));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6.0f, 10.0f));
    ImGui::BeginChild("LuaTabContent", content_size, ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground);
    ImGui::PopStyleVar();
    ImGui::PushItemWidth(IM_TRUNC(ImMax(1.0f, ImGui::GetContentRegionAvail().x)));
    LuaSeedDemo();
    ImGui::PushFont(g_fontVerdana, FONT_SIZE);
    ImVec2 avail = ImGui::GetContentRegionAvail();
    float btn_h = 24.0f;
    float gap = 8.0f;
    float edit_h = IM_TRUNC(ImMax(80.0f, avail.y - btn_h - gap));
    float edit_w = IM_TRUNC(avail.x);
    int lines = LuaLineCount();
    int digits = 1;
    for (int n = lines; n >= 10; n /= 10)
        digits++;
    float num_w = ImGui::CalcTextSize("0").x;
    float gutter_w = (g_lua_tab == 0) ? IM_TRUNC(10.0f + num_w * (float)digits + 8.0f) : 0.0f;
    ImVec2 ep = ImGui::GetCursorScreenPos();
    ep.x = IM_TRUNC(ep.x);
    ep.y = IM_TRUNC(ep.y);
    ImVec2 e1(ep.x + edit_w, ep.y + edit_h);
    ImDrawList* ed = ImGui::GetWindowDrawList();
    ed->AddRectFilledMultiColor(ep, e1, Tc(g_theme->frame), Tc(g_theme->frame), Tc(g_theme->frame_bot), Tc(g_theme->frame_bot));
    ed->AddRect(ep, e1, FadeCol(0, 0, 0));
    ed->AddRect(ImVec2(ep.x + 1, ep.y + 1), ImVec2(e1.x - 1, e1.y - 1), Tc(g_theme->border));
    if (g_lua_tab == 0)
    {
        PxFill(ed, ep.x + 1, ep.y + 1, ep.x + gutter_w, e1.y - 1, Tc(Lift(g_theme->frame, -6)));
        PxFill(ed, ep.x + gutter_w, ep.y + 2, ep.x + gutter_w + 1, e1.y - 2, Tc(g_theme->border));
        ImGui::SetCursorScreenPos(ImVec2(ep.x + gutter_w + 6.0f, ep.y + 4.0f));
    }
    else
        ImGui::SetCursorScreenPos(ImVec2(ep.x + 6.0f, ep.y + 4.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_ScrollbarBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 0));
    if (g_lua_tab == 0)
        ImGui::InputTextMultiline("##lua_src", g_lua_buf, (int)sizeof(g_lua_buf), ImVec2(edit_w - gutter_w - 12.0f, edit_h - 8.0f), ImGuiInputTextFlags_AllowTabInput);
    else
        ImGui::InputTextMultiline("##lua_out", g_lua_out, (int)sizeof(g_lua_out), ImVec2(edit_w - 12.0f, edit_h - 8.0f), ImGuiInputTextFlags_ReadOnly | ImGuiInputTextFlags_AllowTabInput);
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(3);
    if (g_lua_tab == 0)
    {
        ImGuiWindow* host = ImGui::GetCurrentWindow();
        ImGuiWindow* inner = nullptr;
        for (ImGuiWindow* ch : host->DC.ChildWindows)
        {
            if (strstr(ch->Name, "##lua_src"))
                inner = ch;
        }
        float line_h = ImGui::GetTextLineHeight();
        float scroll_y = inner ? inner->Scroll.y : 0.0f;
        float text_y = (inner ? inner->InnerRect.Min.y : (ep.y + 4.0f)) - scroll_y;
        ed->PushClipRect(ImVec2(ep.x + 2, ep.y + 2), ImVec2(ep.x + gutter_w - 1, e1.y - 2), true);
        for (int i = 0; i < lines; i++)
        {
            float y = IM_TRUNC(text_y + (float)i * line_h);
            if (y + line_h < ep.y || y > e1.y)
                continue;
            char num[16];
            snprintf(num, sizeof(num), "%d", i + 1);
            ImVec2 nts = ImGui::CalcTextSize(num);
            TextOutlined(ed, ImVec2(IM_TRUNC(ep.x + gutter_w - 6.0f - nts.x), y), Tc(g_theme->text_dim), num);
        }
        ed->PopClipRect();
    }
    ImGui::SetCursorScreenPos(ImVec2(ep.x, e1.y + gap));
    ImGui::PushItemWidth(edit_w);
    if (g_lua_tab == 0)
    {
        const char* btns[] = { "execute", "open", "save", "clear" };
        int hit = Ui::ButtonRow(btns, 4);
        if (hit == 0)
        {
            if (g_lua_out[0])
                strcat_s(g_lua_out, "\n> executed");
            else
                strcpy_s(g_lua_out, "> executed");
        }
        else if (hit == 1)
            LuaOpenFile();
        else if (hit == 2)
            LuaSaveFile();
        else if (hit == 3)
            g_lua_buf[0] = 0;
    }
    else
    {
        const char* btns[] = { "clear" };
        if (Ui::ButtonRow(btns, 1) == 0)
            g_lua_out[0] = 0;
    }
    ImGui::PopItemWidth();
    ImGui::PopFont();
    ImGui::PopItemWidth();
    ImGui::EndChild();
    ImGui::End();
    ImGui::PopStyleVar();
}

static void DrawPlayerList()
{
    float alpha = PlistAlpha();
    if (alpha <= 0.0f)
        return;
    const float w = 400.0f;
    const float h = 348.0f;
    ImGui::SetNextWindowPos(ImVec2(20.0f, 80.0f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w, h));
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove;
    if (!g_plist_open)
        flags |= ImGuiWindowFlags_NoMouseInputs | ImGuiWindowFlags_NoNav;
    ImGui::Begin("plist", nullptr, flags);
    ImGui::PopStyleVar();
    OverlayClearForeignActive();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 p = OverlaySnapPos();
    float x0 = p.x;
    float y0 = p.y;
    float x1 = x0 + w;
    float y1 = y0 + h;
    PxFill(draw, x0, y0, x1, y1, Tc(g_theme->child));
    DrawBorder(draw, ImVec2(x0, y0), ImVec2(x1, y1));
    DrawHeaderLine(draw, ImVec2(x0 + 1, y0 + 1), ImVec2(x1 - 1, y0 + 3));
    ImGui::SetCursorScreenPos(ImVec2(x0, y0));
    ImGui::InvisibleButton("drag", ImVec2(w, 20.0f));
    OverlayMove(WIN_PLIST);
    ImGui::SetCursorPos(ImVec2(8.0f, 22.0f));
    BeginSection("players", ImVec2(w - 16.0f, h - 30.0f));

    struct P
    {
        const char* nick;
        const char* user;
        const char* display;
        const char* kind;
        float dist;
        float hp;
    };
    const int count = 24;
    static const char* kinds[] = { "local", "enemy", "team" };
    static char nicks[24][16];
    static char users[24][16];
    static char displays[24][20];
    static P list[24];
    static bool list_init = false;
    if (!list_init)
    {
        for (int i = 0; i < count; i++)
        {
            snprintf(nicks[i], sizeof(nicks[i]), "test %d", i + 1);
            snprintf(users[i], sizeof(users[i]), "user%d", i + 1);
            snprintf(displays[i], sizeof(displays[i]), "Test %d", i + 1);
            list[i].nick = nicks[i];
            list[i].user = users[i];
            list[i].display = displays[i];
            list[i].kind = kinds[i % 3];
            list[i].dist = (float)i * 3.7f;
            list[i].hp = 100.0f - (float)(i % 10) * 9.0f;
        }
        list_init = true;
    }
    static int sel = 0;
    static bool friend_on[24];

    float aw = IM_TRUNC(ImGui::GetContentRegionAvail().x);
    float ah = IM_TRUNC(ImGui::GetContentRegionAvail().y);
    float big = 88.0f;
    float bh = 22.0f;
    float bot_h = 8.0f + big + 6.0f + bh;
    float list_h = IM_TRUNC(ah - bot_h - 6.0f);
    float row_h = 22.0f;

    ImGui::BeginChild("plist_rows", ImVec2(aw, list_h), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float rw = IM_TRUNC(ImGui::GetContentRegionAvail().x);
    for (int i = 0; i < count; i++)
    {
        ImVec2 rp = ImGui::GetCursorScreenPos();
        float rx = IM_TRUNC(rp.x);
        float ry = IM_TRUNC(rp.y);
        ImGui::PushID(i);
        if (ImGui::InvisibleButton("row", ImVec2(rw, row_h), ImGuiButtonFlags_PressedOnClick))
            sel = i;
        bool on = sel == i;
        bool hov = ImGui::IsItemHovered();
        if (on)
            ImGui::PushFont(g_fontTitle, FONT_SIZE);
        ImVec2 ts = ImGui::CalcTextSize(list[i].nick);
        TextOutlined(dl, ImVec2(rx + 4.0f, IM_TRUNC(ry + (row_h - ts.y) * 0.5f)), on ? Tc(g_theme->accent) : (hov ? Tc(g_theme->text) : Tc(g_theme->text_dim)), list[i].nick);
        if (on)
            ImGui::PopFont();
        ImGui::PopID();
    }
    ImGui::EndChild();

    ImDrawList* card = ImGui::GetWindowDrawList();
    ImVec2 origin = ImGui::GetCursorScreenPos();
    float lx = IM_TRUNC(origin.x);
    float by = IM_TRUNC(origin.y);
    PxFill(card, lx, by, lx + aw, by + 1, FadeCol(0, 0, 0));
    PxFill(card, lx, by + 1, lx + aw, by + 2, Tc(g_theme->border));
    by += 6.0f;
    const P& cur = list[sel];
    DrawAvBox(card, lx, by, big, true);
    float tx = lx + big + 8.0f;
    float tw = aw - big - 8.0f;
    ImGui::PushFont(g_fontTitle, FONT_SIZE);
    TextOutlined(card, ImVec2(tx, by + 2.0f), Tc(g_theme->text), cur.user);
    ImGui::PopFont();
    TextOutlined(card, ImVec2(tx, by + 18.0f), Tc(g_theme->text_dim), cur.display);
    char meta[64];
    snprintf(meta, sizeof(meta), "%.1fm   %s", cur.dist, cur.kind);
    TextOutlined(card, ImVec2(tx, by + 34.0f), Tc(g_theme->text_dim), meta);

    float bar_h = 12.0f;
    float bar_y = by + big - bar_h;
    char hp_txt[16];
    snprintf(hp_txt, sizeof(hp_txt), "%.0f/100", cur.hp);
    ImGui::PushFont(g_fontTitle, FONT_SIZE);
    ImVec2 hp_sz = ImGui::CalcTextSize(hp_txt);
    TextOutlined(card, ImVec2(IM_TRUNC(tx + tw - hp_sz.x), IM_TRUNC(bar_y - hp_sz.y - 2.0f)), Tc(g_theme->text), hp_txt);
    ImGui::PopFont();
    ImVec2 b0(tx, bar_y);
    ImVec2 b1(tx + tw, bar_y + bar_h);
    card->AddRectFilledMultiColor(b0, b1, Tc(g_theme->frame), Tc(g_theme->frame), Tc(g_theme->win), Tc(g_theme->win));
    ImGuiWindow* body = ImGui::GetCurrentWindow();
    float* anim_hp = body->StateStorage.GetFloatRef(body->GetID("hp"), cur.hp / 100.0f);
    *anim_hp = ImLerp(*anim_hp, cur.hp / 100.0f, 15.0f * ImGui::GetIO().DeltaTime);
    float fill = *anim_hp <= 0.0f ? 0.0f : IM_TRUNC(tw * *anim_hp + 0.5f);
    if (fill > tw)
        fill = tw;
    if (fill > 0.0f)
        card->AddRectFilledMultiColor(b0, ImVec2(tx + fill, bar_y + bar_h), Tc(g_theme->accent), Tc(g_theme->accent), Tc(g_theme->accent_lo), Tc(g_theme->accent_lo));
    card->AddRect(b0, b1, FadeCol(0, 0, 0));
    card->AddRect(ImVec2(tx + 1, bar_y + 1), ImVec2(tx + tw - 1, bar_y + bar_h - 1), Tc(g_theme->border));

    ImGui::SetCursorScreenPos(ImVec2(lx, by + big + 6.0f));
    ImGui::PushItemWidth(aw);
    const char* btns[] = { friend_on[sel] ? "unfriend" : "friend", "spectate", "teleport", "target" };
    int hit = Ui::ButtonRow(btns, 4);
    ImGui::PopItemWidth();
    if (hit == 0)
        friend_on[sel] = !friend_on[sel];

    EndSection();
    ImGui::End();
    ImGui::PopStyleVar();
}

static void PaintTabBackground(ImDrawList* draw, ImVec2 pos, ImVec2 size, float tab_h, float left, float right)
{
    float x0 = IM_TRUNC(pos.x);
    float y0 = IM_TRUNC(pos.y);
    float x1 = IM_TRUNC(pos.x + size.x);
    float y1 = IM_TRUNC(pos.y + size.y);
    float line_y = IM_TRUNC(pos.y + tab_h);
    left = IM_TRUNC(left);
    right = IM_TRUNC(right);

    PxFill(draw, x0, y1 - 1, x1, y1, FadeCol(0, 0, 0));
    PxFill(draw, x0, line_y, x0 + 1, y1, FadeCol(0, 0, 0));
    PxFill(draw, x1 - 1, line_y, x1, y1, FadeCol(0, 0, 0));
    PxFill(draw, x0 + 1, y1 - 2, x1 - 1, y1 - 1, Tc(g_theme->border));
    PxFill(draw, x0 + 1, line_y, x0 + 2, y1 - 1, Tc(g_theme->border));
    PxFill(draw, x1 - 2, line_y, x1 - 1, y1 - 1, Tc(g_theme->border));

    if (left > x0 + 1)
    {
        PxFill(draw, x0 + 1, line_y, left, line_y + 1, FadeCol(0, 0, 0));
        PxFill(draw, x0 + 2, line_y + 1, left, line_y + 2, Tc(g_theme->border));
    }
    PxFill(draw, left - 1, y0 + 1, left, line_y + 1, FadeCol(0, 0, 0));
    PxFill(draw, left, y0 + 1, left + 1, line_y + 2, Tc(g_theme->border));
    PxFill(draw, right, line_y, x1 - 1, line_y + 1, FadeCol(0, 0, 0));
    PxFill(draw, right, line_y + 1, x1 - 2, line_y + 2, Tc(g_theme->border));
    PxFill(draw, right, y0 + 1, right + 1, line_y + 2, Tc(g_theme->border));
    PxFill(draw, right + 1, y0 + 1, right + 2, line_y + 1, FadeCol(0, 0, 0));

    DrawHeaderLine(draw, ImVec2(left + 1, y0 + 1), ImVec2(right, y0 + 3));
}

static int DrawTabBar(ImDrawList* draw, ImVec2 pos, ImVec2 size, const char** names, int count, int active, float* out_right)
{
    float tab_h = 26.f;
    float pad = 13.f;
    pos = Snap(pos);
    size = Snap(size);
    float x0 = pos.x;

    float xs[8];
    float ws[8];
    ImGui::PushFont(g_fontTitle, FONT_SIZE);
    float x = x0 + 1.f;
    for (int i = 0; i < count; i++)
    {
        xs[i] = x;
        ws[i] = IM_TRUNC(ImGui::CalcTextSize(names[i]).x + pad * 2.f);
        x += ws[i];
    }
    ImGui::PopFont();
    if (out_right)
        *out_right = x;

    PxFill(draw, pos.x, pos.y + tab_h, pos.x + size.x, pos.y + size.y, Tc(g_theme->child));
    PxFill(draw, xs[active], pos.y + 1.f, xs[active] + ws[active], pos.y + tab_h, Tc(g_theme->child));
    PaintTabBackground(draw, pos, size, tab_h, xs[active], xs[active] + ws[active]);

    ImVec2 win = Snap(ImGui::GetWindowPos());

    for (int i = 0; i < count; i++)
    {
        ImGui::SetCursorPos(Snap(ImVec2(xs[i] - win.x, pos.y - win.y)));
        if (ImGui::InvisibleButton(names[i], ImVec2(ws[i], tab_h)))
            active = i;

        ImGui::PushFont(active == i ? g_fontTitle : g_fontVerdana, FONT_SIZE);
        ImVec2 ts = ImGui::CalcTextSize(names[i]);
        ImVec2 tp = Snap(ImVec2(xs[i] + (ws[i] - ts.x) * 0.5f, pos.y + (tab_h - ts.y) * 0.5f));
        TextOutlined(draw, tp, active == i ? Tc(g_theme->text) : Tc(g_theme->text_dim), names[i]);
        ImGui::PopFont();
    }

    return active;
}

static bool BeginSection(const char* label, const ImVec2& size_arg)
{
    ImGuiWindow* parent_window = ImGui::GetCurrentWindow();
    ImGuiContext& g = *GImGui;
    const ImGuiStyle& st = g.Style;

    ImGui::BeginChild(label, size_arg, ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollWithMouse);

    ImGuiWindow* window = ImGui::GetCurrentWindow();
    ImVec2 pos = Snap(window->Pos);
    ImVec2 size = Snap(window->Size);
    ImU32 bg_col = ImGui::GetColorU32(ImGuiCol_ChildBg);
    window->DrawList->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), bg_col);

    ImGui::PushFont(g_fontTitle, FONT_SIZE);
    ImVec2 ts = ImGui::CalcTextSize(label);
    ImVec2 label_pos(IM_TRUNC(pos.x + 14.0f), IM_TRUNC(pos.y + 1.0f - ts.y * 0.5f));
    DrawBorder(window->DrawList, pos, ImVec2(pos.x + size.x, pos.y + size.y), label_pos.x - 3.0f, label_pos.x + ts.x + 3.0f);
    ImColor text_col = ImGui::GetStyleColorVec4(ImGuiCol_Text);
    TextOutlined(window->DrawList, label_pos, text_col, label);
    TextOutlined(parent_window->DrawList, label_pos, text_col, label);
    ImGui::PopFont();

    float inset = IM_TRUNC(st.ChildBorderSize * 2.0f);
    ImGui::SetCursorPos(ImVec2(inset, inset));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, kChildPad);
    char body_id[64];
    snprintf(body_id, sizeof(body_id), "%s::body", label);
    float body_w = ImMax(1.0f, IM_TRUNC(size.x - inset * 2.0f));
    float body_h = ImMax(1.0f, IM_TRUNC(size.y - inset * 2.0f));
    ImGui::BeginChild(body_id, ImVec2(body_w, body_h), ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar);
    ImGui::PopStyleVar();

    ImGuiWindow* body = ImGui::GetCurrentWindow();
    body->DrawList->PushClipRect(ImVec2(IM_TRUNC(body->Pos.x), IM_TRUNC(body->Pos.y + ts.y * 0.5f)), ImVec2(IM_TRUNC(body->Pos.x + body->Size.x), IM_TRUNC(body->Pos.y + body->Size.y)), true);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, st.ItemInnerSpacing);
    ImGui::PushItemWidth(IM_TRUNC(ImMax(1.0f, ImGui::GetContentRegionAvail().x)));
    return true;
}

static void EndSection()
{
    ImGui::PopItemWidth();
    ImGui::PopStyleVar();
    ImGui::GetCurrentWindow()->DrawList->PopClipRect();
    ImGui::EndChild();
    ImGui::EndChild();
}

static void DrawTabChildren(int tab)
{
    ImGuiStyle& st = ImGui::GetStyle();
    ImVec2 avail = ImGui::GetContentRegionAvail();
    float gap = IM_TRUNC(st.ItemSpacing.x);
    float gap_y = IM_TRUNC(st.ItemSpacing.y);
    float inner_w = IM_TRUNC(avail.x);
    float inner_h = IM_TRUNC(avail.y);
    float w = ImMax(1.0f, IM_TRUNC((inner_w - gap) * 0.5f));
    float w2 = ImMax(1.0f, inner_w - gap - w);

    ImGui::PushID(tab);
    ImGui::PushFont(g_fontVerdana, FONT_SIZE);

    if (tab == 0)
    {
        static bool enabled = false;
        static bool extra = false;
        static bool third = true;
        static float color_a[4] = { 221.f / 255.f, 168.f / 255.f, 93.f / 255.f, 1.f };
        static float color_b[4] = { 221.f / 255.f, 168.f / 255.f, 93.f / 255.f, 1.f };
        static float color_c[4] = { 196.f / 255.f, 144.f / 255.f, 72.f / 255.f, 1.f };
        static float amount = 50.f;
        static float range0 = 20.f;
        static float range1 = 80.f;
        static float speed = 12.5f;
        static int mode = 0;
        static int type = 1;
        static int third_key = 0;
        static int third_mode = 0;
        static bool hitscan = true;
        static bool hitboxes[] = { true, true, false, false, false };
        static bool override_on = false;
        static int method = 0;
        static int target = 1;
        const char* modes[] = { "Disabled", "Low", "Medium", "High" };
        const char* types[] = { "A", "B", "C", "D" };
        const char* hitbox_items[] = { "Head", "Chest", "Stomach", "Arms", "Legs" };
        const char* methods[] = { "Automatic", "Manual", "Custom" };
        const char* targets[] = { "Nearest", "Crosshair", "Last" };

        BeginSection("child 1", ImVec2(w, 0.0f));
        Ui::Checkbox("Enabled", &enabled);
        ImGui::SameLine(ItemRight() - 26.0f);
        Ui::ColorPicker("##enabled_col", color_a);
        Ui::Checkbox("Extra", &extra);
        ImGui::SameLine(ItemRight() - 56.0f);
        Ui::ColorPicker("##extra_col_a", color_b);
        ImGui::SameLine(ItemRight() - 26.0f);
        Ui::ColorPicker("##extra_col_b", color_c);
        Ui::Checkbox("Third", &third);
        ImGui::SameLine();
        Ui::Keybind("##Third", &third_key, &third_mode);
        Ui::Checkbox("Hitscan", &hitscan);
        Ui::MultiCombo("Hitboxes", hitboxes, hitbox_items, 5);
        Ui::Checkbox("Override", &override_on);
        if (override_on)
        {
            Ui::Combo("Method", &method, methods, 3);
            Ui::Combo("Target", &target, targets, 3);
        }
        Ui::SliderFloat("Amount", &amount, 0.f, 100.f);
        Ui::SliderRange("Range", &range0, &range1, 0.f, 100.f);
        EndSection();
        ImGui::SameLine(0.0f, gap);
        BeginSection("child 2", ImVec2(w2, 0.0f));
        Ui::Combo("Mode", &mode, modes, 4);
        Ui::Combo("Type", &type, types, 4);
        Ui::SliderFloat("Speed", &speed, 0.f, 50.f, "%.1f");
        Ui::Keybind("Menu Bind", &g_menu_key, &g_menu_mode);
        const char* one[] = { "Button" };
        const char* two[] = { "Button", "Button" };
        const char* three[] = { "Button", "Button", "Button" };
        Ui::ButtonRow(one, 1);
        Ui::ButtonRow(two, 2);
        Ui::ButtonRow(three, 3);
        EndSection();
    }
    else if (tab == 1)
    {
        float h = IM_TRUNC((inner_h - gap_y) * 0.5f);
        BeginSection("child 1", ImVec2(w, 0.0f));
        static char cfg_names[32][64];
        static int cfg_count = 1;
        static int cfg = 0;
        static char cfg_name[64] = "";
        static bool cfg_init = false;
        if (!cfg_init)
        {
            memcpy(cfg_names[0], "a", 2);
            memcpy(cfg_name, "a", 2);
            cfg_init = true;
        }
        const char* cfg_ptrs[32];
        for (int i = 0; i < cfg_count; i++)
            cfg_ptrs[i] = cfg_names[i];
        float list_h = IM_TRUNC(ImMax(60.0f, (ImGui::GetContentRegionAvail().y - 108.0f) * 0.7f));
        if (Ui::ListBox("Configs", &cfg, cfg_ptrs, cfg_count, list_h) && cfg >= 0 && cfg < cfg_count)
            memcpy(cfg_name, cfg_names[cfg], 64);
        Ui::InputText("Config Name", cfg_name, sizeof(cfg_name));
        const char* cfg_a[] = { "Save", "Delete" };
        const char* cfg_b[] = { "Refresh", "Load" };
        int row0 = Ui::ButtonRow(cfg_a, 2);
        int row1 = Ui::ButtonRow(cfg_b, 2);
        if (row0 == 0 && cfg_name[0] && cfg_count < 32)
        {
            int found = -1;
            for (int i = 0; i < cfg_count; i++)
            {
                if (strcmp(cfg_names[i], cfg_name) == 0)
                {
                    found = i;
                    break;
                }
            }
            if (found >= 0)
                cfg = found;
            else
            {
                memcpy(cfg_names[cfg_count], cfg_name, 64);
                cfg = cfg_count++;
            }
        }
        if (row0 == 1 && cfg >= 0 && cfg < cfg_count)
        {
            for (int i = cfg; i < cfg_count - 1; i++)
                memcpy(cfg_names[i], cfg_names[i + 1], 64);
            cfg_count--;
            if (cfg >= cfg_count)
                cfg = cfg_count - 1;
            if (cfg >= 0)
                memcpy(cfg_name, cfg_names[cfg], 64);
            else
                cfg_name[0] = 0;
        }
        if (row1 == 1 && cfg >= 0 && cfg < cfg_count)
            memcpy(cfg_name, cfg_names[cfg], 64);
        EndSection();
        ImGui::SameLine(0.0f, gap);
        ImGui::BeginGroup();
        BeginSection("child 2", ImVec2(w2, h));
        if (Ui::Combo("Theme", &g_theme_idx, ThemeNames(), kThemeCount))
            ApplyTheme(g_theme_idx);
        EndSection();
        BeginSection("child 3", ImVec2(w2, 0.0f));
        EndSection();
        ImGui::EndGroup();
    }
    else if (tab == 2)
    {
        float h = IM_TRUNC((inner_h - gap_y) * 0.5f);
        float h2 = ImMax(1.0f, inner_h - gap_y - h);
        ImGui::BeginGroup();
        BeginSection("child 1", ImVec2(w, h));
        EndSection();
        BeginSection("child 2", ImVec2(w, h2));
        EndSection();
        ImGui::EndGroup();
        ImGui::SameLine(0.0f, gap);
        ImGui::BeginGroup();
        BeginSection("child 3", ImVec2(w2, h));
        EndSection();
        BeginSection("child 4", ImVec2(w2, h2));
        EndSection();
        ImGui::EndGroup();
    }
    else
    {
        float h_left = IM_TRUNC((inner_h - gap_y) * 0.5f);
        float h_left2 = ImMax(1.0f, inner_h - gap_y - h_left);
        float h_right = IM_TRUNC((inner_h - gap_y * 2.0f) / 3.0f);
        float h_right3 = ImMax(1.0f, inner_h - gap_y * 2.0f - h_right * 2.0f);
        ImGui::BeginGroup();
        BeginSection("child 1", ImVec2(w, h_left));
        EndSection();
        BeginSection("child 2", ImVec2(w, h_left2));
        EndSection();
        ImGui::EndGroup();
        ImGui::SameLine(0.0f, gap);
        ImGui::BeginGroup();
        BeginSection("child 3", ImVec2(w2, h_right));
        EndSection();
        BeginSection("child 4", ImVec2(w2, h_right));
        EndSection();
        BeginSection("child 5", ImVec2(w2, h_right3));
        EndSection();
        ImGui::EndGroup();
    }

    ImGui::PopFont();
    ImGui::PopID();
}

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int)
{
    ImGui_ImplWin32_EnableDpiAwareness();
    float main_scale = ImGui_ImplWin32_GetDpiScaleForMonitor(::MonitorFromPoint(POINT{ 0, 0 }, MONITOR_DEFAULTTOPRIMARY));

    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(nullptr), nullptr, nullptr, nullptr, nullptr, L"gui", nullptr };
    ::RegisterClassExW(&wc);
    HWND hwnd = ::CreateWindowW(wc.lpszClassName, L"PoZdnyakoVkukold.hook", WS_OVERLAPPEDWINDOW, 100, 100, (int)(1280 * main_scale), (int)(800 * main_scale), nullptr, nullptr, wc.hInstance, nullptr);
    g_hwnd = hwnd;

    if (!CreateDeviceD3D(hwnd))
    {
        CleanupDeviceD3D();
        ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return 1;
    }

    ::ShowWindow(hwnd, SW_SHOWMAXIMIZED);
    ::UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.ConfigWindowsResizeFromEdges = true;
    io.IniFilename = nullptr;

    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.AntiAliasedLines = false;
    style.AntiAliasedLinesUseTex = false;
    style.AntiAliasedFill = false;
    style.WindowRounding = 0.0f;
    style.ChildRounding = 0.0f;
    style.FrameRounding = 0.0f;
    style.GrabRounding = 0.0f;
    style.PopupRounding = 0.0f;
    style.ScrollbarRounding = 0.0f;
    style.ScrollbarSize = 0.0f;
    style.TabRounding = 0.0f;
    style.ChildBorderSize = 1.0f;
    style.ItemInnerSpacing = ImVec2(10.0f, 6.0f);
    style.ItemSpacing = ImVec2(8.0f, 8.0f);
    style.WindowPadding = ImVec2(8.0f, 8.0f);
    ApplyTheme(g_theme_idx);
    style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0, 0, 0, 0);
    style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0, 0, 0, 0);
    style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(0, 0, 0, 0);
    style.Colors[ImGuiCol_SeparatorHovered] = ImVec4(0, 0, 0, 0);
    style.Colors[ImGuiCol_SeparatorActive] = ImVec4(0, 0, 0, 0);
    style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0, 0, 0, 0);
    style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0, 0, 0, 0);
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0, 0, 0, 0);
    style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0, 0, 0, 0);
    style.FontSizeBase = FONT_SIZE;
    ImFontConfig font_cfg;
    font_cfg.OversampleH = 1;
    font_cfg.OversampleV = 1;
    font_cfg.PixelSnapH = true;
    font_cfg.FontLoaderFlags = ImGuiFreeTypeLoaderFlags_Monochrome | ImGuiFreeTypeLoaderFlags_MonoHinting;
    g_fontVerdana = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\verdana.ttf", FONT_SIZE, &font_cfg);
    ImFontConfig font_cfg_title = font_cfg;
    g_fontTitle = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\tahomabd.ttf", FONT_SIZE, &font_cfg_title);
    ImFontConfig font_cfg_icon;
    font_cfg_icon.FontDataOwnedByAtlas = false;
    font_cfg_icon.OversampleH = 2;
    font_cfg_icon.OversampleV = 2;
    font_cfg_icon.PixelSnapH = false;
    font_cfg_icon.FontLoaderFlags = 0;
    static const ImWchar icon_ranges[] = { 0xf015, 0xf015, 0xf06e, 0xf06e, 0xf07b, 0xf07b, 0xf0c0, 0xf0c0, 0xf121, 0xf121, 0xf53f, 0xf53f, 0 };
    g_fontIcons = io.Fonts->AddFontFromMemoryTTF((void*)k_island_font, (int)sizeof(k_island_font), 16.0f, &font_cfg_icon, icon_ranges);

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);
    Avatar3D::Start(g_pd3dDevice, g_pd3dDeviceContext);
    NowPlay_Start();
    Yt_Init(hwnd);

    ImVec4 clear_color = Tv(g_theme->win);

    bool done = false;
    while (!done)
    {
        MSG msg;
        while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE))
        {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;

        if (g_SwapChainOccluded && g_pSwapChain->Present(0, DXGI_PRESENT_TEST) == DXGI_STATUS_OCCLUDED)
        {
            ::Sleep(10);
            continue;
        }
        g_SwapChainOccluded = false;

        if (g_ResizeWidth != 0 && g_ResizeHeight != 0)
        {
            CleanupRenderTarget();
            g_pSwapChain->ResizeBuffers(0, g_ResizeWidth, g_ResizeHeight, DXGI_FORMAT_UNKNOWN, 0);
            g_ResizeWidth = g_ResizeHeight = 0;
            CreateRenderTarget();
        }

        Avatar3D::Tick();
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        if (!ImGui::IsMouseDown(0))
        {
            if (g_dock_drag >= 0 && ImGui::GetIO().KeyAlt)
                DockTrySnap(g_dock_drag, kDockStick);
            g_dock_drag = -1;
        }

        float menu_alpha = MenuAlpha();
        if (menu_alpha > 0.0f)
        {
        ImGui::SetNextWindowPos(ImVec2(20.0f, 20.0f), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(544.0f, 620.0f), ImGuiCond_Once);
        ImGui::SetNextWindowSizeConstraints(ImVec2(544.0f, 620.0f), ImVec2(FLT_MAX, FLT_MAX));
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, menu_alpha);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        ImGuiWindowFlags menu_flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBringToFrontOnFocus;
        if (!g_menu_open)
            menu_flags |= ImGuiWindowFlags_NoMouseInputs | ImGuiWindowFlags_NoNav;
        ImGui::Begin("gui", nullptr, menu_flags);
        ImGui::PopStyleVar();
        if (GImGui->MovingWindow == ImGui::GetCurrentWindow() && ImGui::IsMouseDragging(ImGuiMouseButton_Left))
            DockDrag(WIN_GUI);

        ImVec2 p = Snap(ImGui::GetWindowPos());
        ImVec2 s = Snap(ImGui::GetWindowSize());
        if (((int)s.x & 1) != 0)
            s.x += 1.0f;
        if (((int)s.y & 1) != 0)
            s.y += 1.0f;
        if (p.x != ImGui::GetWindowPos().x || p.y != ImGui::GetWindowPos().y)
            ImGui::SetWindowPos(p);
        if (s.x != ImGui::GetWindowSize().x || s.y != ImGui::GetWindowSize().y)
            ImGui::SetWindowSize(s);
        ImDrawList* draw = ImGui::GetWindowDrawList();
        if (ImGui::GetPlatformIO().DrawCallback_SetSamplerNearest)
            draw->AddCallback(ImGui::GetPlatformIO().DrawCallback_SetSamplerNearest, nullptr);

        DrawHeaderLine(draw, ImVec2(p.x + 1.0f, p.y + 1.0f), ImVec2(p.x + s.x - 1.0f, p.y + 3.0f));

        ImGui::PushFont(g_fontTitle, FONT_SIZE);
        DrawTitle(draw, ImVec2(p.x + 8.0f, p.y + 8.0f), style.Colors[ImGuiCol_Header]);
        ImGui::PopFont();

        ImVec2 child_pos(p.x + 8.0f, p.y + 26.0f);
        ImVec2 child_size(s.x - 16.0f, s.y - 34.0f);

        static int active_tab = 0;
        const char* tabs[] = { "test 1", "test 2", "test 3", "test 4" };
        active_tab = DrawTabBar(draw, child_pos, child_size, tabs, 4, active_tab);

        float tab_h = 26.0f;
        ImVec2 content_pos(child_pos.x + 6.0f, child_pos.y + tab_h + 6.0f);
        ImVec2 content_size(child_size.x - 12.0f, child_size.y - tab_h - 6.0f);
        ImGui::SetCursorPos(Snap(ImVec2(content_pos.x - p.x, content_pos.y - p.y)));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6.0f, 10.0f));
        ImGui::BeginChild("TabContent", content_size, ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground);
        ImGui::PopStyleVar();
        DrawTabChildren(active_tab);
        ImGui::EndChild();
        ImGui::End();
        ImGui::PopStyleVar();
        }

        DrawPlayerList();
        DrawEspPreview();
        DrawLuaExecutor();
        DrawMediaPlayer();
        DrawLyrics();
        DrawIsland();

        ImGui::Render();
        const float clear[4] = { clear_color.x, clear_color.y, clear_color.z, clear_color.w };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        HRESULT hr = g_pSwapChain->Present(1, 0);
        g_SwapChainOccluded = (hr == DXGI_STATUS_OCCLUDED);
    }

    NowPlay_Stop();
    Yt_Shutdown();
    DropVideoTex();
    if (g_art_srv)
    {
        g_art_srv->Release();
        g_art_srv = nullptr;
    }
    Avatar3D::Stop();
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
    return 0;
}

bool CreateDeviceD3D(HWND hWnd)
{
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
    HRESULT res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res == DXGI_ERROR_UNSUPPORTED)
        res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D()
{
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
}

void CreateRenderTarget()
{
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget()
{
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = nullptr; }
}

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg)
    {
    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED)
            return 0;
        g_ResizeWidth = (UINT)LOWORD(lParam);
        g_ResizeHeight = (UINT)HIWORD(lParam);
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU)
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}
