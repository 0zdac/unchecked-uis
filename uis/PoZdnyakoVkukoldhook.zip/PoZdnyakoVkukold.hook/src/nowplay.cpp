#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include "nowplay.h"
#include <windows.h>
#include <winhttp.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <audioclientactivationparams.h>
#include <audiopolicy.h>
#include <mmreg.h>
#include <objidl.h>
#include <tlhelp32.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
#include <string>
#include <vector>
#include <wincodec.h>
#include <winrt/base.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.Control.h>
#include <winrt/Windows.Storage.Streams.h>

#pragma comment(lib, "windowsapp.lib")
#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "mmdevapi.lib")
#pragma comment(lib, "windowscodecs.lib")

using namespace winrt;
using namespace winrt::Windows::Media::Control;

static CRITICAL_SECTION g_cs;
static HANDLE g_stop;
static HANDLE g_th;
static HANDLE g_vis_th;
static NowTrack g_tr;
static DWORD g_stamp;
static volatile long g_cmd;
static double g_seek = -1.0;

struct Line
{
    float t;
    char s[160];
};

static Line g_lines[256];
static int g_nlines;
static bool g_synced;
static char g_lkey[320];
static char g_fetch_key[320];
static char g_art_key[320];
static char g_art_have[320];
static DWORD g_art_try;
static unsigned char* g_art;
static int g_art_w;
static int g_art_h;
static unsigned g_art_gen;
static float g_np_vol = 1.0f;
static bool g_np_mute;
static DWORD g_np_vol_t;

enum { CMD_NONE = 0, CMD_TOGGLE = 1, CMD_NEXT = 2, CMD_PREV = 3 };

static void Lower(char* s)
{
    for (; *s; s++)
        if (*s >= 'A' && *s <= 'Z')
            *s = (char)(*s - 'A' + 'a');
}

static bool Has(const char* a, const char* b)
{
    return a && b && strstr(a, b) != nullptr;
}

static void Utf8(winrt::hstring const& h, char* o, int cap)
{
    std::string u = winrt::to_string(h);
    strncpy_s(o, cap, u.c_str(), _TRUNCATE);
}

static char g_own_exe[80];

static bool OwnSession(const char* app)
{
    char a[256];
    strncpy_s(a, app ? app : "", _TRUNCATE);
    Lower(a);
    if (Has(a, "webview2") || Has(a, "msedgewebview"))
        return true;
    if (!g_own_exe[0])
    {
        char path[MAX_PATH];
        if (GetModuleFileNameA(nullptr, path, MAX_PATH))
        {
            char* sl = strrchr(path, '\\');
            strncpy_s(g_own_exe, sl ? sl + 1 : path, _TRUNCATE);
            Lower(g_own_exe);
        }
    }
    return g_own_exe[0] && Has(a, g_own_exe);
}

static int Score(const char* app, const char* title, const char* artist, bool playing)
{
    char a[256];
    strncpy_s(a, app, _TRUNCATE);
    Lower(a);
    char t[256];
    strncpy_s(t, title, _TRUNCATE);
    Lower(t);
    char r[256];
    strncpy_s(r, artist, _TRUNCATE);
    Lower(r);
    int s = 0;
    if (Has(a, "soundcloud"))
        s = 300;
    else if (Has(a, "spotify"))
        s = 200;
    else if (Has(a, "youtube") || Has(t, "youtube") || Has(r, "youtube"))
        s = 100;
    else if (Has(a, "chrome") || Has(a, "msedge") || Has(a, "firefox") || Has(a, "brave") || Has(a, "opera"))
        s = 80;
    else
        s = 10;
    if (playing)
        s += 50;
    return s;
}

static void SourceName(const char* app, const char* title, const char* artist, char* o, int cap)
{
    char a[256];
    strncpy_s(a, app ? app : "", _TRUNCATE);
    Lower(a);
    char t[256];
    strncpy_s(t, title ? title : "", _TRUNCATE);
    Lower(t);
    char r[256];
    strncpy_s(r, artist ? artist : "", _TRUNCATE);
    Lower(r);
    if (Has(a, "soundcloud"))
        strncpy_s(o, cap, "soundcloud", _TRUNCATE);
    else if (Has(a, "spotify"))
        strncpy_s(o, cap, "spotify", _TRUNCATE);
    else if (Has(a, "youtube") || Has(t, "youtube") || Has(r, "youtube"))
        strncpy_s(o, cap, "youtube", _TRUNCATE);
    else
        strncpy_s(o, cap, "media", _TRUNCATE);
}

static bool ExeIs(const wchar_t* path, const char* name)
{
    const wchar_t* sl = wcsrchr(path, L'\\');
    const wchar_t* f = sl ? sl + 1 : path;
    char a[80];
    WideCharToMultiByte(CP_UTF8, 0, f, -1, a, 80, nullptr, nullptr);
    Lower(a);
    return strcmp(a, name) == 0;
}

static int CollectNames(const char* aumid, const char* source, const char** names, char* extra, int extra_cap)
{
    int n = 0;
    extra[0] = 0;
    char a[256];
    strncpy_s(a, aumid ? aumid : "", _TRUNCATE);
    Lower(a);
    const char* e = strstr(a, ".exe");
    if (e)
    {
        const char* s = e;
        while (s > a && s[-1] != '\\' && s[-1] != '/' && s[-1] != '!')
            s--;
        int len = (int)(e - s) + 4;
        if (len > 0 && len < extra_cap)
        {
            memcpy(extra, s, len);
            extra[len] = 0;
            names[n++] = extra;
        }
    }
    if (strcmp(source, "spotify") == 0)
        names[n++] = "spotify.exe";
    if (strcmp(source, "soundcloud") == 0)
        names[n++] = "soundcloud.exe";
    if (strcmp(source, "youtube") == 0)
        names[n++] = "youtube.exe";
    if (Has(a, "chrome") || strcmp(source, "soundcloud") == 0 || strcmp(source, "youtube") == 0 || strcmp(source, "media") == 0)
    {
        if (Has(a, "msedge") || Has(a, "edge"))
            names[n++] = "msedge.exe";
        else if (Has(a, "brave"))
            names[n++] = "brave.exe";
        else if (Has(a, "firefox"))
            names[n++] = "firefox.exe";
        else if (Has(a, "opera"))
            names[n++] = "opera.exe";
        else if (Has(a, "chrome"))
            names[n++] = "chrome.exe";
        else if (strcmp(source, "soundcloud") == 0 || strcmp(source, "youtube") == 0)
        {
            names[n++] = "chrome.exe";
            names[n++] = "msedge.exe";
            names[n++] = "brave.exe";
            names[n++] = "firefox.exe";
        }
    }
    return n;
}

static DWORD FindPidSessions(const char** names, int n)
{
    IMMDeviceEnumerator* en = nullptr;
    if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator), (void**)&en)))
        return 0;
    IMMDevice* dev = nullptr;
    HRESULT hr = en->GetDefaultAudioEndpoint(eRender, eMultimedia, &dev);
    en->Release();
    if (FAILED(hr))
        return 0;
    IAudioSessionManager2* mgr = nullptr;
    hr = dev->Activate(__uuidof(IAudioSessionManager2), CLSCTX_ALL, nullptr, (void**)&mgr);
    dev->Release();
    if (FAILED(hr))
        return 0;
    IAudioSessionEnumerator* se = nullptr;
    hr = mgr->GetSessionEnumerator(&se);
    mgr->Release();
    if (FAILED(hr))
        return 0;
    int count = 0;
    se->GetCount(&count);
    DWORD best = 0;
    for (int i = 0; i < count; i++)
    {
        IAudioSessionControl* c = nullptr;
        if (FAILED(se->GetSession(i, &c)))
            continue;
        IAudioSessionControl2* c2 = nullptr;
        if (FAILED(c->QueryInterface(__uuidof(IAudioSessionControl2), (void**)&c2)))
        {
            c->Release();
            continue;
        }
        DWORD pid = 0;
        c2->GetProcessId(&pid);
        AudioSessionState st = AudioSessionStateExpired;
        c->GetState(&st);
        bool sys = c2->IsSystemSoundsSession() == S_OK;
        c2->Release();
        c->Release();
        if (!pid || sys)
            continue;
        HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        if (!h)
            continue;
        wchar_t path[MAX_PATH];
        DWORD plen = MAX_PATH;
        BOOL ok = QueryFullProcessImageNameW(h, 0, path, &plen);
        CloseHandle(h);
        if (!ok)
            continue;
        for (int k = 0; k < n; k++)
        {
            if (!ExeIs(path, names[k]))
                continue;
            if (st == AudioSessionStateActive)
            {
                se->Release();
                return pid;
            }
            if (!best)
                best = pid;
        }
    }
    se->Release();
    return best;
}

static DWORD FindPidSnap(const char** names, int n)
{
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE)
        return 0;
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    DWORD pid = 0;
    if (Process32FirstW(snap, &pe))
    {
        do
        {
            char exe[260];
            WideCharToMultiByte(CP_UTF8, 0, pe.szExeFile, -1, exe, 260, nullptr, nullptr);
            Lower(exe);
            for (int i = 0; i < n; i++)
            {
                if (strcmp(exe, names[i]) == 0)
                {
                    pid = pe.th32ProcessID;
                    break;
                }
            }
            if (pid)
                break;
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

static DWORD FindAudioPid(const char* aumid, const char* source)
{
    const char* names[10];
    char extra[80];
    int n = CollectNames(aumid, source, names, extra, 80);
    if (n <= 0)
        return 0;
    DWORD pid = FindPidSessions(names, n);
    if (!pid)
        pid = FindPidSnap(names, n);
    return pid;
}

static bool JsonStr(const char* json, const char* key, char* out, int cap)
{
    char pat[80];
    snprintf(pat, sizeof(pat), "\"%s\":\"", key);
    const char* p = strstr(json, pat);
    if (!p)
        return false;
    p += strlen(pat);
    int n = 0;
    while (*p && n + 1 < cap)
    {
        if (*p == '\\' && p[1])
        {
            p++;
            if (*p == 'n')
                out[n++] = '\n';
            else if (*p == 'r')
                out[n++] = '\r';
            else if (*p == 't')
                out[n++] = '\t';
            else
                out[n++] = *p;
            p++;
            continue;
        }
        if (*p == '"')
            break;
        out[n++] = *p++;
    }
    out[n] = 0;
    return n > 0;
}

static void ParseLrc(const char* src)
{
    g_nlines = 0;
    g_synced = false;
    if (!src || !src[0])
        return;
    const char* p = src;
    while (*p && g_nlines < 256)
    {
        while (*p == '\n' || *p == '\r')
            p++;
        if (!*p)
            break;
        float ts = -1.0f;
        if (*p == '[')
        {
            int m = 0, s = 0, cs = 0;
            if (sscanf_s(p, "[%d:%d.%d", &m, &s, &cs) >= 2)
            {
                ts = (float)m * 60.0f + (float)s + (float)cs / 100.0f;
                const char* q = strchr(p, ']');
                if (q)
                    p = q + 1;
            }
        }
        const char* e = p;
        while (*e && *e != '\n' && *e != '\r')
            e++;
        int n = (int)(e - p);
        if (n > 159)
            n = 159;
        if (n > 0 || ts >= 0.0f)
        {
            Line& L = g_lines[g_nlines++];
            L.t = ts;
            memcpy(L.s, p, n);
            L.s[n] = 0;
            if (ts >= 0.0f)
                g_synced = true;
        }
        p = e;
    }
}

static void UrlEnc(wchar_t* d, int cap, const char* s)
{
    int n = 0;
    for (; *s && n + 4 < cap; s++)
    {
        unsigned char c = (unsigned char)*s;
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~')
            d[n++] = (wchar_t)c;
        else
        {
            wchar_t tmp[8];
            swprintf_s(tmp, L"%%%02X", c);
            d[n++] = tmp[0];
            d[n++] = tmp[1];
            d[n++] = tmp[2];
        }
    }
    d[n] = 0;
}

static void FetchLyrics(const char* artist, const char* title)
{
    wchar_t ea[512], et[512], path[1400];
    UrlEnc(ea, 512, artist);
    UrlEnc(et, 512, title);
    swprintf_s(path, L"/api/get?artist=%s&track=%s", ea, et);
    HINTERNET ses = WinHttpOpen(L"hriskido", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses)
        return;
    HINTERNET con = WinHttpConnect(ses, L"lrclib.net", INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!con)
    {
        WinHttpCloseHandle(ses);
        return;
    }
    HINTERNET req = WinHttpOpenRequest(con, L"GET", path, nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
    if (!req)
    {
        WinHttpCloseHandle(con);
        WinHttpCloseHandle(ses);
        return;
    }
    BOOL ok = WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
    if (ok)
        ok = WinHttpReceiveResponse(req, nullptr);
    char* body = ok ? (char*)malloc(262144) : nullptr;
    int used = 0;
    if (body)
    {
        for (;;)
        {
            DWORD got = 0;
            if (!WinHttpReadData(req, body + used, 262144 - 1 - used, &got) || got == 0)
                break;
            used += (int)got;
            if (used >= 262144 - 1)
                break;
        }
        body[used] = 0;
    }
    WinHttpCloseHandle(req);
    WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    if (!body)
        return;
    char buf[131072];
    buf[0] = 0;
    if (!JsonStr(body, "syncedLyrics", buf, sizeof(buf)))
        JsonStr(body, "plainLyrics", buf, sizeof(buf));
    EnterCriticalSection(&g_cs);
    ParseLrc(buf);
    LeaveCriticalSection(&g_cs);
    free(body);
}

static void ArtClear()
{
    EnterCriticalSection(&g_cs);
    free(g_art);
    g_art = nullptr;
    g_art_w = 0;
    g_art_h = 0;
    g_art_gen++;
    LeaveCriticalSection(&g_cs);
}

static bool DecodeArt(BYTE* data, UINT size)
{
    IWICImagingFactory* fac = nullptr;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&fac))))
        return false;
    IWICStream* st = nullptr;
    IWICBitmapDecoder* dec = nullptr;
    IWICBitmapFrameDecode* fr = nullptr;
    IWICFormatConverter* cv = nullptr;
    IWICBitmapScaler* sc = nullptr;
    unsigned char* px = nullptr;
    UINT dw = 0, dh = 0, w = 0, h = 0;
    bool ok = false;
    if (FAILED(fac->CreateStream(&st)))
        goto done;
    if (FAILED(st->InitializeFromMemory(data, size)))
        goto done;
    if (FAILED(fac->CreateDecoderFromStream(st, nullptr, WICDecodeMetadataCacheOnLoad, &dec)))
        goto done;
    if (FAILED(dec->GetFrame(0, &fr)))
        goto done;
    if (FAILED(fac->CreateFormatConverter(&cv)))
        goto done;
    if (FAILED(cv->Initialize(fr, GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom)))
        goto done;
    cv->GetSize(&w, &h);
    if (!w || !h)
        goto done;
    dw = 96;
    dh = 96;
    if (w >= h)
        dh = 96 * h / w;
    else
        dw = 96 * w / h;
    if (!dw)
        dw = 1;
    if (!dh)
        dh = 1;
    if (FAILED(fac->CreateBitmapScaler(&sc)))
        goto done;
    if (FAILED(sc->Initialize(cv, dw, dh, WICBitmapInterpolationModeFant)))
        goto done;
    px = (unsigned char*)malloc((size_t)dw * dh * 4);
    if (!px)
        goto done;
    if (FAILED(sc->CopyPixels(nullptr, dw * 4, dw * dh * 4, px)))
    {
        free(px);
        px = nullptr;
        goto done;
    }
    ok = true;
done:
    if (sc)
        sc->Release();
    if (cv)
        cv->Release();
    if (fr)
        fr->Release();
    if (dec)
        dec->Release();
    if (st)
        st->Release();
    fac->Release();
    if (!ok)
        return false;
    EnterCriticalSection(&g_cs);
    free(g_art);
    g_art = px;
    g_art_w = (int)dw;
    g_art_h = (int)dh;
    g_art_gen++;
    LeaveCriticalSection(&g_cs);
    return true;
}

static bool FetchArt(GlobalSystemMediaTransportControlsSession const& s)
{
    try
    {
        auto props = s.TryGetMediaPropertiesAsync().get();
        auto thumb = props.Thumbnail();
        if (!thumb)
            return false;
        auto stream = thumb.OpenReadAsync().get();
        if (!stream)
            return false;
        std::vector<uint8_t> bytes;
        uint64_t sz = stream.Size();
        if (sz >= 32 && sz <= 8ull * 1024 * 1024)
        {
            winrt::Windows::Storage::Streams::DataReader rd(stream);
            rd.LoadAsync((uint32_t)sz).get();
            bytes.resize((size_t)sz);
            rd.ReadBytes(bytes);
        }
        else
        {
            winrt::Windows::Storage::Streams::DataReader rd(stream);
            rd.LoadAsync(2u * 1024u * 1024u).get();
            uint32_t n = rd.UnconsumedBufferLength();
            if (n < 32)
                return false;
            bytes.resize(n);
            rd.ReadBytes(bytes);
        }
        if (bytes.size() < 32)
            return false;
        return DecodeArt(bytes.data(), (UINT)bytes.size());
    }
    catch (...)
    {
        return false;
    }
}

static void Poll()
{
    try
    {
        auto mgr = GlobalSystemMediaTransportControlsSessionManager::RequestAsync().get();
        auto list = mgr.GetSessions();
        GlobalSystemMediaTransportControlsSession best{ nullptr };
        int best_s = -1;
        char bt[256] = {}, ba[256] = {}, bapp[256] = {};
        bool bplay = false;
        for (auto const& s : list)
        {
            char app[256] = {};
            Utf8(s.SourceAppUserModelId(), app, 256);
            if (OwnSession(app))
                continue;
            char title[256] = {}, artist[256] = {};
            try
            {
                auto props = s.TryGetMediaPropertiesAsync().get();
                Utf8(props.Title(), title, 256);
                Utf8(props.Artist(), artist, 256);
            }
            catch (...)
            {
            }
            bool playing = false;
            try
            {
                playing = s.GetPlaybackInfo().PlaybackStatus() == GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing;
            }
            catch (...)
            {
            }
            int sc = Score(app, title, artist, playing);
            if (sc > best_s && (title[0] || artist[0]))
            {
                best_s = sc;
                best = s;
                memcpy(bt, title, sizeof(bt));
                memcpy(ba, artist, sizeof(ba));
                memcpy(bapp, app, sizeof(bapp));
                bplay = playing;
            }
        }
        long cmd = InterlockedExchange(&g_cmd, CMD_NONE);
        if (best && cmd == CMD_TOGGLE)
        {
            if (bplay)
                best.TryPauseAsync();
            else
                best.TryPlayAsync();
        }
        else if (best && cmd == CMD_NEXT)
            best.TrySkipNextAsync();
        else if (best && cmd == CMD_PREV)
            best.TrySkipPreviousAsync();
        double seek;
        double live = 0.0;
        bool same = false;
        double hold_dur = 0.0;
        EnterCriticalSection(&g_cs);
        seek = g_seek;
        g_seek = -1.0;
        live = g_tr.pos;
        if (g_tr.playing)
            live += (double)(GetTickCount() - g_stamp) * 0.001;
        same = best && strcmp(g_tr.title, bt) == 0 && strcmp(g_tr.artist, ba) == 0;
        hold_dur = g_tr.dur;
        LeaveCriticalSection(&g_cs);
        if (best && seek >= 0.0)
            best.TryChangePlaybackPositionAsync((int64_t)(seek * 10000000.0));
        double pos = 0.0, dur = 0.0, age = 0.0;
        if (best)
        {
            try
            {
                auto tl = best.GetTimelineProperties();
                pos = std::chrono::duration<double>(tl.Position()).count();
                dur = std::chrono::duration<double>(tl.EndTime()).count();
                if (dur < 1.0)
                {
                    double mx = std::chrono::duration<double>(tl.MaxSeekTime()).count();
                    if (mx > 1.0)
                        dur = mx;
                }
                if (dur < 0.0)
                    dur = 0.0;
                FILETIME ft;
                GetSystemTimeAsFileTime(&ft);
                ULARGE_INTEGER now;
                now.LowPart = ft.dwLowDateTime;
                now.HighPart = ft.dwHighDateTime;
                int64_t last = tl.LastUpdatedTime().time_since_epoch().count();
                age = (double)((__int64)now.QuadPart - last) / 10000000.0;
                if (age < 0.0 || age > 86400.0)
                    age = 0.0;
            }
            catch (...)
            {
            }
        }
        double gsm = pos;
        if (bplay && age > 0.0)
            gsm += age;
        if (seek >= 0.0)
            live = seek;
        else if (!best)
            live = 0.0;
        else if (!same)
            live = bplay ? gsm : pos;
        else if (!bplay)
            live = pos > 0.2 ? pos : live;
        else if (!(pos < 0.5 && live > 1.0 && gsm + 2.0 < live))
            live = gsm;
        if (dur < 1.0 && same && hold_dur > 1.0)
            dur = hold_dur;
        NowTrack tr{};
        tr.valid = best != nullptr;
        tr.playing = bplay;
        tr.pos = live;
        tr.dur = dur;
        memcpy(tr.title, bt, sizeof(tr.title));
        memcpy(tr.artist, ba, sizeof(tr.artist));
        memcpy(tr.app, bapp, sizeof(tr.app));
        SourceName(bapp, bt, ba, tr.source, 32);
        EnterCriticalSection(&g_cs);
        g_tr = tr;
        g_stamp = GetTickCount();
        LeaveCriticalSection(&g_cs);
        if (tr.valid && strcmp(tr.source, "spotify") == 0 && (tr.title[0] || tr.artist[0]))
        {
            char key[320];
            snprintf(key, sizeof(key), "%s|%s", tr.artist, tr.title);
            if (strcmp(key, g_fetch_key) != 0)
            {
                strncpy_s(g_fetch_key, key, _TRUNCATE);
                EnterCriticalSection(&g_cs);
                g_nlines = 0;
                g_synced = false;
                LeaveCriticalSection(&g_cs);
                FetchLyrics(tr.artist, tr.title);
            }
        }
        else if (g_fetch_key[0])
        {
            g_fetch_key[0] = 0;
            EnterCriticalSection(&g_cs);
            g_nlines = 0;
            g_synced = false;
            LeaveCriticalSection(&g_cs);
        }
        if (tr.valid && (tr.title[0] || tr.artist[0]) && best)
        {
            char key[320];
            snprintf(key, sizeof(key), "%s|%s|%s", tr.artist, tr.title, tr.source);
            DWORD now = GetTickCount();
            if (strcmp(key, g_art_key) != 0)
            {
                strncpy_s(g_art_key, key, _TRUNCATE);
                g_art_try = 0;
            }
            if (strcmp(key, g_art_have) != 0 && now - g_art_try > 700)
            {
                g_art_try = now;
                if (FetchArt(best))
                    strncpy_s(g_art_have, key, _TRUNCATE);
            }
        }
    }
    catch (...)
    {
        EnterCriticalSection(&g_cs);
        g_tr.valid = false;
        g_tr.playing = false;
        LeaveCriticalSection(&g_cs);
    }
}

static DWORD WINAPI Thread(void*)
{
    winrt::init_apartment(winrt::apartment_type::multi_threaded);
    while (WaitForSingleObject(g_stop, 400) == WAIT_TIMEOUT)
        Poll();
    return 0;
}

enum { FFT_N = 512, VIS_N = 48 };

static IAudioClient* g_ac;
static IAudioCaptureClient* g_cc;
static WAVEFORMATEX* g_wf;
static int g_ch;
static int g_bits;
static int g_ieee;
static float g_ring[FFT_N];
static int g_ring_n;
static float g_bands[VIS_N];
static float g_vis_peak = 0.02f;

static void Fft(float* re, float* im, int n)
{
    int j = 0;
    for (int i = 1; i < n; i++)
    {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1)
            j ^= bit;
        j ^= bit;
        if (i < j)
        {
            float tr = re[i];
            re[i] = re[j];
            re[j] = tr;
            float ti = im[i];
            im[i] = im[j];
            im[j] = ti;
        }
    }
    for (int len = 2; len <= n; len <<= 1)
    {
        float ang = -6.28318530718f / (float)len;
        float wlr = cosf(ang);
        float wli = sinf(ang);
        int half = len >> 1;
        for (int i = 0; i < n; i += len)
        {
            float wr = 1.0f;
            float wi = 0.0f;
            for (int k = 0; k < half; k++)
            {
                int i0 = i + k;
                int i1 = i0 + half;
                float vr = re[i1] * wr - im[i1] * wi;
                float vi = re[i1] * wi + im[i1] * wr;
                re[i1] = re[i0] - vr;
                im[i1] = im[i0] - vi;
                re[i0] += vr;
                im[i0] += vi;
                float nr = wr * wlr - wi * wli;
                wi = wr * wli + wi * wlr;
                wr = nr;
            }
        }
    }
}

static void VisFlush()
{
    float re[FFT_N];
    float im[FFT_N];
    for (int i = 0; i < FFT_N; i++)
    {
        float w = 0.5f - 0.5f * cosf(6.28318530718f * (float)i / (float)FFT_N);
        re[i] = g_ring[i] * w;
        im[i] = 0.0f;
    }
    Fft(re, im, FFT_N);
    float mag[FFT_N / 2];
    mag[0] = 0.0f;
    for (int i = 1; i < FFT_N / 2; i++)
        mag[i] = sqrtf(re[i] * re[i] + im[i] * im[i]) * (1.0f / (float)FFT_N);
    float raw[VIS_N];
    int lo = 1;
    float mx = 1.0e-8f;
    for (int b = 0; b < VIS_N; b++)
    {
        int hi = (int)powf((float)(FFT_N / 2 - 1), (float)(b + 1) / (float)VIS_N);
        if (hi <= lo)
            hi = lo + 1;
        if (hi > FFT_N / 2)
            hi = FFT_N / 2;
        float e = 0.0f;
        for (int k = lo; k < hi; k++)
            e += mag[k];
        e /= (float)(hi - lo);
        raw[b] = e;
        if (e > mx)
            mx = e;
        lo = hi;
    }
    if (mx > g_vis_peak)
        g_vis_peak = mx;
    else
        g_vis_peak = g_vis_peak * 0.985f + mx * 0.015f;
    if (g_vis_peak < 1.0e-6f)
        g_vis_peak = 1.0e-6f;
    for (int b = 0; b < VIS_N; b++)
    {
        float v = raw[b] / g_vis_peak;
        if (v < 0.0f)
            v = 0.0f;
        if (v > 1.0f)
            v = 1.0f;
        v = sqrtf(v);
        if (v > g_bands[b])
            g_bands[b] = v;
        else
            g_bands[b] *= 0.72f;
    }
    memmove(g_ring, g_ring + FFT_N / 2, (FFT_N / 2) * sizeof(float));
    g_ring_n = FFT_N / 2;
}

static void VisPush(float s)
{
    g_ring[g_ring_n++] = s;
    if (g_ring_n >= FFT_N)
        VisFlush();
}

static void VisEat(BYTE* data, UINT32 frames, DWORD flags)
{
    if (!g_ch || flags & AUDCLNT_BUFFERFLAGS_SILENT)
    {
        for (UINT32 i = 0; i < frames; i++)
            VisPush(0.0f);
        return;
    }
    if (g_ieee)
    {
        float* f = (float*)data;
        for (UINT32 i = 0; i < frames; i++)
        {
            float s = 0.0f;
            for (int c = 0; c < g_ch; c++)
                s += f[i * g_ch + c];
            VisPush(s / (float)g_ch);
        }
        return;
    }
    if (g_bits == 16)
    {
        short* p = (short*)data;
        for (UINT32 i = 0; i < frames; i++)
        {
            float s = 0.0f;
            for (int c = 0; c < g_ch; c++)
                s += (float)p[i * g_ch + c] * (1.0f / 32768.0f);
            VisPush(s / (float)g_ch);
        }
        return;
    }
    if (g_bits == 32)
    {
        int* p = (int*)data;
        for (UINT32 i = 0; i < frames; i++)
        {
            float s = 0.0f;
            for (int c = 0; c < g_ch; c++)
                s += (float)p[i * g_ch + c] * (1.0f / 2147483648.0f);
            VisPush(s / (float)g_ch);
        }
    }
}

static DWORD g_vis_pid;

static void VisClose()
{
    if (g_cc)
    {
        g_cc->Release();
        g_cc = nullptr;
    }
    if (g_ac)
    {
        g_ac->Stop();
        g_ac->Release();
        g_ac = nullptr;
    }
    if (g_wf)
    {
        CoTaskMemFree(g_wf);
        g_wf = nullptr;
    }
    g_ch = 0;
    g_vis_pid = 0;
}

struct Act : IActivateAudioInterfaceCompletionHandler, IAgileObject
{
    LONG ref = 1;
    HANDLE ev;
    IAudioClient* client = nullptr;
    HRESULT hr = E_FAIL;

    Act()
    {
        ev = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    }

    ~Act()
    {
        if (client)
            client->Release();
        if (ev)
            CloseHandle(ev);
    }

    ULONG STDMETHODCALLTYPE AddRef()
    {
        return (ULONG)InterlockedIncrement(&ref);
    }

    ULONG STDMETHODCALLTYPE Release()
    {
        return (ULONG)InterlockedDecrement(&ref);
    }

    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** pp)
    {
        if (!pp)
            return E_POINTER;
        if (riid == IID_IUnknown || riid == __uuidof(IActivateAudioInterfaceCompletionHandler))
        {
            *pp = static_cast<IActivateAudioInterfaceCompletionHandler*>(this);
            AddRef();
            return S_OK;
        }
        if (riid == __uuidof(IAgileObject))
        {
            *pp = static_cast<IAgileObject*>(this);
            AddRef();
            return S_OK;
        }
        *pp = nullptr;
        return E_NOINTERFACE;
    }

    HRESULT STDMETHODCALLTYPE ActivateCompleted(IActivateAudioInterfaceAsyncOperation* op)
    {
        IUnknown* unk = nullptr;
        HRESULT hrAct = E_FAIL;
        hr = op->GetActivateResult(&hrAct, &unk);
        if (SUCCEEDED(hr) && SUCCEEDED(hrAct) && unk)
        {
            hr = unk->QueryInterface(__uuidof(IAudioClient), (void**)&client);
            unk->Release();
        }
        else if (FAILED(hrAct))
            hr = hrAct;
        SetEvent(ev);
        return S_OK;
    }
};

static bool VisBind(DWORD flags)
{
    HRESULT hr = g_ac->GetMixFormat(&g_wf);
    if (FAILED(hr))
        return false;
    hr = g_ac->Initialize(AUDCLNT_SHAREMODE_SHARED, flags, 2000000, 0, g_wf, nullptr);
    if (FAILED(hr))
        return false;
    hr = g_ac->GetService(__uuidof(IAudioCaptureClient), (void**)&g_cc);
    if (FAILED(hr))
        return false;
    g_ch = g_wf->nChannels;
    g_bits = g_wf->wBitsPerSample;
    g_ieee = 0;
    if (g_wf->wFormatTag == WAVE_FORMAT_IEEE_FLOAT)
        g_ieee = 1;
    else if (g_wf->wFormatTag == WAVE_FORMAT_EXTENSIBLE && g_wf->cbSize >= 22)
    {
        WAVEFORMATEXTENSIBLE* e = (WAVEFORMATEXTENSIBLE*)g_wf;
        if (e->SubFormat.Data1 == 3)
            g_ieee = 1;
    }
    if (g_ch <= 0)
        return false;
    hr = g_ac->Start();
    return SUCCEEDED(hr);
}

static bool VisOpenProcess(DWORD pid)
{
    if (!pid)
        return false;
    AUDIOCLIENT_ACTIVATION_PARAMS ap{};
    ap.ActivationType = AUDIOCLIENT_ACTIVATION_TYPE_PROCESS_LOOPBACK;
    ap.ProcessLoopbackParams.TargetProcessId = pid;
    ap.ProcessLoopbackParams.ProcessLoopbackMode = PROCESS_LOOPBACK_MODE_INCLUDE_TARGET_PROCESS_TREE;
    PROPVARIANT pv;
    PropVariantInit(&pv);
    pv.vt = VT_BLOB;
    pv.blob.cbSize = sizeof(ap);
    pv.blob.pBlobData = (BYTE*)&ap;
    Act act;
    IActivateAudioInterfaceAsyncOperation* op = nullptr;
    HRESULT hr = ActivateAudioInterfaceAsync(VIRTUAL_AUDIO_DEVICE_PROCESS_LOOPBACK, __uuidof(IAudioClient), &pv, &act, &op);
    if (FAILED(hr))
        return false;
    WaitForSingleObject(act.ev, 4000);
    if (op)
        op->Release();
    if (FAILED(act.hr) || !act.client)
        return false;
    g_ac = act.client;
    act.client = nullptr;
    if (!VisBind(0))
    {
        VisClose();
        return false;
    }
    g_vis_pid = pid;
    return true;
}

static bool VisOpenDevice()
{
    IMMDeviceEnumerator* en = nullptr;
    if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator), (void**)&en)))
        return false;
    IMMDevice* dev = nullptr;
    HRESULT hr = en->GetDefaultAudioEndpoint(eRender, eConsole, &dev);
    en->Release();
    if (FAILED(hr))
        return false;
    hr = dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, (void**)&g_ac);
    dev->Release();
    if (FAILED(hr))
        return false;
    if (!VisBind(AUDCLNT_STREAMFLAGS_LOOPBACK))
    {
        VisClose();
        return false;
    }
    g_vis_pid = 1;
    return true;
}

static void VisDecay()
{
    for (int i = 0; i < VIS_N; i++)
        g_bands[i] *= 0.82f;
}

static DWORD WINAPI VisThread(void*)
{
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    DWORD find_t = 0;
    char last_key[320] = {};
    DWORD pid = 0;
    for (;;)
    {
        if (WaitForSingleObject(g_stop, 0) == WAIT_OBJECT_0)
            break;
        char app[256];
        char src[32];
        bool play;
        EnterCriticalSection(&g_cs);
        play = g_tr.playing && g_tr.valid;
        memcpy(app, g_tr.app, sizeof(app));
        memcpy(src, g_tr.source, sizeof(src));
        LeaveCriticalSection(&g_cs);
        if (!play)
        {
            if (g_cc)
                VisClose();
            VisDecay();
            if (WaitForSingleObject(g_stop, 20) != WAIT_TIMEOUT)
                break;
            continue;
        }
        DWORD now = GetTickCount();
        char key[320];
        snprintf(key, sizeof(key), "%s|%s", app, src);
        if (strcmp(key, last_key) != 0 || now - find_t > 800)
        {
            DWORD npid = FindAudioPid(app, src);
            strncpy_s(last_key, key, _TRUNCATE);
            find_t = now;
            if (npid != pid)
            {
                VisClose();
                pid = npid;
            }
        }
        if (!g_cc)
        {
            bool ok = pid && VisOpenProcess(pid);
            if (!ok)
                ok = VisOpenDevice();
            if (!ok)
            {
                VisDecay();
                if (WaitForSingleObject(g_stop, 400) != WAIT_TIMEOUT)
                    break;
                continue;
            }
        }
        UINT32 pkt = 0;
        HRESULT hr = g_cc->GetNextPacketSize(&pkt);
        if (FAILED(hr))
        {
            VisClose();
            pid = 0;
            continue;
        }
        while (pkt)
        {
            BYTE* data = nullptr;
            UINT32 frames = 0;
            DWORD flags = 0;
            hr = g_cc->GetBuffer(&data, &frames, &flags, nullptr, nullptr);
            if (FAILED(hr))
                break;
            VisEat(data, frames, flags);
            g_cc->ReleaseBuffer(frames);
            hr = g_cc->GetNextPacketSize(&pkt);
            if (FAILED(hr))
                break;
        }
        float e = 0.0f;
        for (int i = 0; i < VIS_N; i++)
            e += g_bands[i];
        static DWORD silent_t = 0;
        if (e < 0.2f && g_vis_pid != 1)
        {
            if (!silent_t)
                silent_t = GetTickCount();
            else if (GetTickCount() - silent_t > 800)
            {
                VisClose();
                VisOpenDevice();
                silent_t = 0;
            }
        }
        else
            silent_t = 0;
        if (WaitForSingleObject(g_stop, 4) != WAIT_TIMEOUT)
            break;
    }
    VisClose();
    CoUninitialize();
    return 0;
}

void NowPlay_Start()
{
    memset(&g_tr, 0, sizeof(g_tr));
    memset(g_bands, 0, sizeof(g_bands));
    g_ring_n = 0;
    InitializeCriticalSection(&g_cs);
    g_stop = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    g_th = CreateThread(nullptr, 0, Thread, nullptr, 0, nullptr);
    g_vis_th = CreateThread(nullptr, 0, VisThread, nullptr, 0, nullptr);
}

void NowPlay_Stop()
{
    if (g_stop)
        SetEvent(g_stop);
    if (g_th)
    {
        WaitForSingleObject(g_th, 3000);
        CloseHandle(g_th);
        g_th = nullptr;
    }
    if (g_vis_th)
    {
        WaitForSingleObject(g_vis_th, 3000);
        CloseHandle(g_vis_th);
        g_vis_th = nullptr;
    }
    if (g_stop)
    {
        CloseHandle(g_stop);
        g_stop = nullptr;
    }
    DeleteCriticalSection(&g_cs);
}

NowTrack NowPlay_Get()
{
    EnterCriticalSection(&g_cs);
    NowTrack t = g_tr;
    LeaveCriticalSection(&g_cs);
    return t;
}

float NowPlay_Pos()
{
    EnterCriticalSection(&g_cs);
    double p = g_tr.pos;
    bool play = g_tr.playing;
    DWORD st = g_stamp;
    double dur = g_tr.dur;
    LeaveCriticalSection(&g_cs);
    if (play)
        p += (double)(GetTickCount() - st) * 0.001;
    if (dur > 0.0 && p > dur)
        p = dur;
    return (float)p;
}

void NowPlay_PlayPause()
{
    InterlockedExchange(&g_cmd, CMD_TOGGLE);
}

void NowPlay_Next()
{
    InterlockedExchange(&g_cmd, CMD_NEXT);
}

void NowPlay_Prev()
{
    InterlockedExchange(&g_cmd, CMD_PREV);
}

void NowPlay_Seek(double sec)
{
    EnterCriticalSection(&g_cs);
    g_seek = sec;
    g_tr.pos = sec;
    g_stamp = GetTickCount();
    LeaveCriticalSection(&g_cs);
}

static ISimpleAudioVolume* VolOpen()
{
    char app[256];
    char src[32];
    bool valid;
    EnterCriticalSection(&g_cs);
    valid = g_tr.valid;
    memcpy(app, g_tr.app, sizeof(app));
    memcpy(src, g_tr.source, sizeof(src));
    LeaveCriticalSection(&g_cs);
    if (!valid)
        return nullptr;
    DWORD pid = FindAudioPid(app, src);
    if (!pid)
        return nullptr;
    IMMDeviceEnumerator* en = nullptr;
    if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator), (void**)&en)))
        return nullptr;
    IMMDevice* dev = nullptr;
    HRESULT hr = en->GetDefaultAudioEndpoint(eRender, eMultimedia, &dev);
    en->Release();
    if (FAILED(hr))
        return nullptr;
    IAudioSessionManager2* mgr = nullptr;
    hr = dev->Activate(__uuidof(IAudioSessionManager2), CLSCTX_ALL, nullptr, (void**)&mgr);
    dev->Release();
    if (FAILED(hr))
        return nullptr;
    IAudioSessionEnumerator* se = nullptr;
    hr = mgr->GetSessionEnumerator(&se);
    mgr->Release();
    if (FAILED(hr))
        return nullptr;
    int count = 0;
    se->GetCount(&count);
    ISimpleAudioVolume* best = nullptr;
    for (int i = 0; i < count; i++)
    {
        IAudioSessionControl* c = nullptr;
        if (FAILED(se->GetSession(i, &c)))
            continue;
        IAudioSessionControl2* c2 = nullptr;
        if (FAILED(c->QueryInterface(__uuidof(IAudioSessionControl2), (void**)&c2)))
        {
            c->Release();
            continue;
        }
        DWORD sp = 0;
        c2->GetProcessId(&sp);
        AudioSessionState st = AudioSessionStateExpired;
        c->GetState(&st);
        c2->Release();
        if (sp != pid)
        {
            c->Release();
            continue;
        }
        ISimpleAudioVolume* vol = nullptr;
        if (FAILED(c->QueryInterface(__uuidof(ISimpleAudioVolume), (void**)&vol)))
        {
            c->Release();
            continue;
        }
        c->Release();
        if (st == AudioSessionStateActive)
        {
            if (best)
                best->Release();
            se->Release();
            return vol;
        }
        if (!best)
            best = vol;
        else
            vol->Release();
    }
    se->Release();
    return best;
}

static void VolPull()
{
    DWORD now = GetTickCount();
    if (now - g_np_vol_t < 200)
        return;
    g_np_vol_t = now;
    ISimpleAudioVolume* vol = VolOpen();
    if (!vol)
        return;
    float v = g_np_vol;
    BOOL m = g_np_mute ? TRUE : FALSE;
    vol->GetMasterVolume(&v);
    vol->GetMute(&m);
    vol->Release();
    g_np_vol = v;
    g_np_mute = m != 0;
}

float NowPlay_Vol()
{
    VolPull();
    return g_np_vol;
}

bool NowPlay_Muted()
{
    VolPull();
    return g_np_mute;
}

void NowPlay_SetVol(float v)
{
    if (v < 0.0f)
        v = 0.0f;
    if (v > 1.0f)
        v = 1.0f;
    g_np_vol = v;
    g_np_mute = false;
    g_np_vol_t = GetTickCount();
    ISimpleAudioVolume* vol = VolOpen();
    if (!vol)
        return;
    vol->SetMasterVolume(v, nullptr);
    vol->SetMute(FALSE, nullptr);
    vol->Release();
}

void NowPlay_ToggleMute()
{
    g_np_mute = !g_np_mute;
    g_np_vol_t = GetTickCount();
    ISimpleAudioVolume* vol = VolOpen();
    if (!vol)
        return;
    vol->SetMute(g_np_mute ? TRUE : FALSE, nullptr);
    vol->Release();
}

int NowPlay_LyricCount()
{
    EnterCriticalSection(&g_cs);
    int n = g_nlines;
    LeaveCriticalSection(&g_cs);
    return n;
}

bool NowPlay_LyricSynced()
{
    EnterCriticalSection(&g_cs);
    bool s = g_synced;
    LeaveCriticalSection(&g_cs);
    return s;
}

void NowPlay_Lyric(int i, float* t, char* out, int cap)
{
    EnterCriticalSection(&g_cs);
    if (i < 0 || i >= g_nlines)
    {
        LeaveCriticalSection(&g_cs);
        if (t)
            *t = -1.0f;
        if (out && cap)
            out[0] = 0;
        return;
    }
    if (t)
        *t = g_lines[i].t;
    if (out && cap)
        strncpy_s(out, cap, g_lines[i].s, _TRUNCATE);
    LeaveCriticalSection(&g_cs);
}

int NowPlay_LyricAt(float sec)
{
    EnterCriticalSection(&g_cs);
    int hit = 0;
    for (int i = 0; i < g_nlines; i++)
    {
        if (g_lines[i].t >= 0.0f && g_lines[i].t <= sec)
            hit = i;
    }
    LeaveCriticalSection(&g_cs);
    return hit;
}

void NowPlay_Vis(float* out, int n)
{
    if (!out || n <= 0)
        return;
    for (int i = 0; i < n; i++)
    {
        float t = (float)i * (float)(VIS_N - 1) / (float)(n > 1 ? n - 1 : 1);
        int a = (int)t;
        int b = a + 1;
        if (a < 0)
            a = 0;
        if (a >= VIS_N)
            a = VIS_N - 1;
        if (b >= VIS_N)
            b = VIS_N - 1;
        float f = t - (float)a;
        out[i] = g_bands[a] * (1.0f - f) + g_bands[b] * f;
    }
}

void NowPlay_ArtInfo(unsigned* gen, int* w, int* h)
{
    EnterCriticalSection(&g_cs);
    if (gen)
        *gen = g_art_gen;
    if (w)
        *w = g_art_w;
    if (h)
        *h = g_art_h;
    LeaveCriticalSection(&g_cs);
}

void NowPlay_ArtCopy(unsigned char* dst)
{
    if (!dst)
        return;
    EnterCriticalSection(&g_cs);
    if (g_art && g_art_w > 0 && g_art_h > 0)
        memcpy(dst, g_art, (size_t)g_art_w * g_art_h * 4);
    LeaveCriticalSection(&g_cs);
}
