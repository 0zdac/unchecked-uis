#pragma once

struct NowTrack
{
    char title[256];
    char artist[256];
    char source[32];
    char app[256];
    bool valid;
    bool playing;
    double pos;
    double dur;
};

void NowPlay_Start();
void NowPlay_Stop();
NowTrack NowPlay_Get();
float NowPlay_Pos();
void NowPlay_PlayPause();
void NowPlay_Next();
void NowPlay_Prev();
void NowPlay_Seek(double sec);
float NowPlay_Vol();
bool NowPlay_Muted();
void NowPlay_SetVol(float v);
void NowPlay_ToggleMute();

int NowPlay_LyricCount();
bool NowPlay_LyricSynced();
void NowPlay_Lyric(int i, float* t, char* out, int cap);
int NowPlay_LyricAt(float sec);
void NowPlay_Vis(float* out, int n);
void NowPlay_ArtInfo(unsigned* gen, int* w, int* h);
void NowPlay_ArtCopy(unsigned char* dst);
