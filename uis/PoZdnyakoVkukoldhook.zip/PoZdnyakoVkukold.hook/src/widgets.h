#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include "imgui.h"
#include "imgui_internal.h"
#include "theme.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern ImFont* g_fontTitle;
extern ImFont* g_fontVerdana;

namespace Ui {

inline ImColor FadeCol(int r, int g, int b, int a = 255)
{
    return ImColor(r, g, b, (int)(a * ImGui::GetStyle().Alpha));
}

inline float Px(float v)
{
    return IM_TRUNC(v);
}

inline ImVec2 Px(ImVec2 p)
{
    return ImVec2(IM_TRUNC(p.x), IM_TRUNC(p.y));
}

inline float ItemW()
{
    return Px(ImMax(1.0f, ImGui::CalcItemWidth()));
}

inline float EvenDiff(float outer, float inner)
{
    outer = Px(outer);
    if (((int)(outer - Px(inner)) & 1) != 0)
        outer += 1.0f;
    return outer;
}

inline float GlyphX0(ImWchar c)
{
    const ImFontGlyph* g = ImGui::GetFontBaked()->FindGlyph(c);
    return g ? g->X0 : 0.0f;
}

inline float GlyphX1(ImWchar c)
{
    const ImFontGlyph* g = ImGui::GetFontBaked()->FindGlyph(c);
    return g ? g->X1 : ImGui::GetFontBaked()->GetCharAdvance(c);
}

inline float InkX(float x, const char* s)
{
    return Px(x - GlyphX0((ImWchar)(unsigned char)*s));
}

inline void DrawOutlinedText(ImDrawList* draw, ImVec2 p, ImColor c, const char* t, const char* t_end = nullptr)
{
    p.x = IM_TRUNC(p.x);
    p.y = IM_TRUNC(p.y);
    ImColor out(0, 0, 0, (int)(255 * c.Value.w));
    draw->AddText(ImVec2(p.x - 1, p.y), out, t, t_end);
    draw->AddText(ImVec2(p.x + 1, p.y), out, t, t_end);
    draw->AddText(ImVec2(p.x, p.y - 1), out, t, t_end);
    draw->AddText(ImVec2(p.x, p.y + 1), out, t, t_end);
    draw->AddText(ImVec2(p.x - 1, p.y - 1), out, t, t_end);
    draw->AddText(ImVec2(p.x + 1, p.y - 1), out, t, t_end);
    draw->AddText(ImVec2(p.x - 1, p.y + 1), out, t, t_end);
    draw->AddText(ImVec2(p.x + 1, p.y + 1), out, t, t_end);
    draw->AddText(p, c, t, t_end);
}

inline ImGuiID g_keybind_capture = 0;

inline bool KeybindCapturing()
{
    return g_keybind_capture != 0;
}

inline int HexNibble(char c)
{
    if (c >= '0' && c <= '9')
        return c - '0';
    if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;
    if (c >= 'A' && c <= 'F')
        return c - 'A' + 10;
    return -1;
}

inline bool ParseHexColor(const char* s, float col[4])
{
    while (*s == '#' || *s == ' ')
        s++;
    char buf[8];
    int n = 0;
    for (; n < 8 && HexNibble(s[n]) >= 0; n++)
        buf[n] = s[n];
    if (n == 3)
    {
        col[0] = (float)(HexNibble(buf[0]) * 17) / 255.0f;
        col[1] = (float)(HexNibble(buf[1]) * 17) / 255.0f;
        col[2] = (float)(HexNibble(buf[2]) * 17) / 255.0f;
        return true;
    }
    if (n == 6 || n == 8)
    {
        col[0] = (float)(HexNibble(buf[0]) * 16 + HexNibble(buf[1])) / 255.0f;
        col[1] = (float)(HexNibble(buf[2]) * 16 + HexNibble(buf[3])) / 255.0f;
        col[2] = (float)(HexNibble(buf[4]) * 16 + HexNibble(buf[5])) / 255.0f;
        if (n == 8)
            col[3] = (float)(HexNibble(buf[6]) * 16 + HexNibble(buf[7])) / 255.0f;
        return true;
    }
    return false;
}

inline bool StrIStr(const char* hay, const char* needle)
{
    if (!needle[0])
        return true;
    for (; *hay; hay++)
    {
        const char* h = hay;
        const char* n = needle;
        while (*h && *n)
        {
            char a = *h;
            char b = *n;
            if (a >= 'A' && a <= 'Z')
                a = (char)(a - 'A' + 'a');
            if (b >= 'A' && b <= 'Z')
                b = (char)(b - 'A' + 'a');
            if (a != b)
                break;
            h++;
            n++;
        }
        if (!*n)
            return true;
    }
    return false;
}

inline bool InputBox(const char* str_id, char* buf, int buf_size, const ImVec2& size, const char* hint = nullptr)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(str_id);
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;
    ImVec2 sz(Px(size.x), Px(size.y));
    ImRect bb(pos, ImVec2(pos.x + sz.x, pos.y + sz.y));
    ImGui::ItemSize(bb);
    ImVec2 after = window->DC.CursorPos;
    if (!ImGui::ItemAdd(bb, id))
        return false;

    float* anim = window->StateStorage.GetFloatRef(id, 0.0f);
    ImColor bg_top = LerpRgb(g_theme->frame, Lift(g_theme->frame, 8), *anim);
    ImColor bg_bot = LerpRgb(g_theme->frame_bot, Lift(g_theme->frame_bot, 7), *anim);
    window->DrawList->AddRectFilledMultiColor(bb.Min, bb.Max, bg_top, bg_top, bg_bot, bg_bot);
    window->DrawList->AddRect(bb.Min, bb.Max, FadeCol(0, 0, 0));
    window->DrawList->AddRect(ImVec2(bb.Min.x + 1, bb.Min.y + 1), ImVec2(bb.Max.x - 1, bb.Max.y - 1), Tc(g_theme->border));

    ImGui::SetCursorScreenPos(ImVec2(bb.Min.x + 5.0f, bb.Min.y + 2.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 0));
    ImGui::PushID(id);
    bool changed = ImGui::InputTextEx("##in", hint, buf, buf_size, ImVec2(sz.x - 10.0f, sz.y - 4.0f), 0);
    *anim = ImLerp(*anim, (ImGui::IsItemHovered() || ImGui::IsItemActive()) ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);
    ImGui::PopID();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);
    window->DC.CursorPos = after;
    return changed;
}

inline bool Checkbox(const char* label, bool* v)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);

    const float square_sz = 16.0f;
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;
    const ImRect total_bb(pos, ImVec2(pos.x + square_sz + 3.0f + Px(label_size.x), pos.y + ImMax(square_sz, Px(label_size.y))));

    ImGui::ItemSize(total_bb, style.FramePadding.y);
    if (!ImGui::ItemAdd(total_bb, id))
        return false;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(total_bb, id, &hovered, &held);
    if (pressed)
    {
        *v = !(*v);
        ImGui::MarkItemEdited(id);
    }

    ImDrawList* draw = window->DrawList;
    float* anim_hover = window->StateStorage.GetFloatRef(id, 0.0f);
    *anim_hover = ImLerp(*anim_hover, (hovered || *v) ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);
    float* anim_check = window->StateStorage.GetFloatRef(id + 1, 0.0f);
    *anim_check = ImLerp(*anim_check, *v ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);

    ImColor top_col = LerpRgb(g_theme->frame, g_theme->accent, *anim_check);
    ImColor bot_col = LerpRgb(g_theme->frame_bot, g_theme->accent_lo, *anim_check);

    ImVec2 cb_pos = pos;
    draw->AddRectFilledMultiColor(ImVec2(cb_pos.x + 2, cb_pos.y + 2), ImVec2(cb_pos.x + 14, cb_pos.y + 14), top_col, top_col, bot_col, bot_col);
    draw->AddRect(cb_pos, ImVec2(cb_pos.x + 16, cb_pos.y + 16), FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(cb_pos.x + 1, cb_pos.y + 1), ImVec2(cb_pos.x + 15, cb_pos.y + 15), Tc(g_theme->border));

    ImColor text_col = LerpRgb(Lift(g_theme->text_dim, -40), g_theme->text, *anim_hover);
    DrawOutlinedText(draw, ImVec2(cb_pos.x + 19, cb_pos.y + 1), text_col, label);
    return pressed;
}

inline bool SliderFloat(const char* label, float* v, float v_min, float v_max, const char* format = "%.1f")
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
    ImVec2 minus_sz = ImGui::CalcTextSize("-");
    ImVec2 plus_sz = ImGui::CalcTextSize("+");

    float spacing = 3.0f;
    float track_h = 12.0f;
    float gap = 6.0f;
    float row_h = EvenDiff(ImMax(track_h, ImMax(minus_sz.y, plus_sz.y)), track_h);
    ImGui::PushFont(g_fontTitle, 13.0f);
    ImVec2 val_probe = ImGui::CalcTextSize("00.0");
    ImGui::PopFont();
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;
    float full_w = ItemW();
    float minus_x0 = GlyphX0('-');
    float minus_x1 = GlyphX1('-');
    float plus_x0 = GlyphX0('+');
    float plus_x1 = GlyphX1('+');
    float minus_draw = Px(pos.x - minus_x0);
    float plus_draw = Px(pos.x + full_w - plus_x1);
    float minus_r = Px(minus_draw + minus_x1);
    float plus_l = Px(plus_draw + plus_x0);
    float track_x0 = minus_r + gap;
    float track_x1 = plus_l - gap;
    float track_w = ImMax(1.0f, track_x1 - track_x0);
    ImRect bb(pos, ImVec2(pos.x + ImMax(Px(label_size.x), full_w), pos.y + Px(label_size.y) + spacing + row_h + Px(val_probe.y * 0.5f)));

    ImGui::ItemSize(bb, style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id))
        return false;

    float row_y = pos.y + Px(label_size.y) + spacing;
    float track_y = row_y + Px((row_h - track_h) * 0.5f);
    ImRect minus_bb(ImVec2(pos.x, row_y), ImVec2(track_x0, row_y + row_h));
    ImRect track_bb(ImVec2(track_x0, track_y), ImVec2(track_x0 + track_w, track_y + track_h));
    ImRect plus_bb(ImVec2(track_bb.Max.x, row_y), ImVec2(pos.x + full_w, row_y + row_h));

    bool hovered, held;
    ImGui::ButtonBehavior(track_bb, id, &hovered, &held);
    ImGui::PushID(id);
    bool minus_hov, minus_held;
    bool minus_pressed = ImGui::ButtonBehavior(minus_bb, window->GetID("##s-"), &minus_hov, &minus_held);
    bool plus_hov, plus_held;
    bool plus_pressed = ImGui::ButtonBehavior(plus_bb, window->GetID("##s+"), &plus_hov, &plus_held);
    ImGui::PopID();
    bool value_changed = false;

    float step = (v_max - v_min) >= 10.0f ? 1.0f : 0.1f;
    if (held)
    {
        float new_v = v_min + (g.IO.MousePos.x - track_bb.Min.x) / track_w * (v_max - v_min);
        new_v = ImClamp(new_v, v_min, v_max);
        if (*v != new_v)
        {
            *v = new_v;
            value_changed = true;
        }
    }
    if (minus_pressed)
    {
        *v = ImClamp(*v - step, v_min, v_max);
        value_changed = true;
    }
    if (plus_pressed)
    {
        *v = ImClamp(*v + step, v_min, v_max);
        value_changed = true;
    }

    ImDrawList* draw = window->DrawList;
    float fill_ratio = (*v - v_min) / (v_max - v_min);
    float* anim_hover = window->StateStorage.GetFloatRef(id, 0.0f);
    *anim_hover = ImLerp(*anim_hover, (hovered || held || minus_hov || plus_hov) ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);
    float* anim_value = window->StateStorage.GetFloatRef(id + 1, fill_ratio);
    *anim_value = ImLerp(*anim_value, fill_ratio, 15.0f * g.IO.DeltaTime);

    ImColor text_col = LerpRgb(Lift(g_theme->text_dim, -40), g_theme->text, *anim_hover);

    DrawOutlinedText(draw, ImVec2(pos.x, pos.y), text_col, label);
    DrawOutlinedText(draw, Px(ImVec2(minus_draw, minus_bb.Min.y + (row_h - minus_sz.y) * 0.5f)), minus_hov ? Tc(g_theme->accent) : text_col, "-");
    DrawOutlinedText(draw, Px(ImVec2(plus_draw, plus_bb.Min.y + (row_h - plus_sz.y) * 0.5f)), plus_hov ? Tc(g_theme->accent) : text_col, "+");

    draw->AddRectFilledMultiColor(track_bb.Min, track_bb.Max, Tc(g_theme->frame), Tc(g_theme->frame), Tc(g_theme->win), Tc(g_theme->win));
    float fill_width = *anim_value <= 0.0f ? 0.0f : Px(track_w * (*anim_value) + 0.5f);
    if (fill_width > track_w)
        fill_width = track_w;
    if (fill_width > 0.0f)
        draw->AddRectFilledMultiColor(track_bb.Min, ImVec2(track_bb.Min.x + fill_width, track_bb.Max.y), Tc(g_theme->accent), Tc(g_theme->accent), Tc(g_theme->accent_lo), Tc(g_theme->accent_lo));
    draw->AddRect(track_bb.Min, track_bb.Max, FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(track_bb.Min.x + 1, track_bb.Min.y + 1), ImVec2(track_bb.Max.x - 1, track_bb.Max.y - 1), Tc(g_theme->border));

    char val_buf[32];
    snprintf(val_buf, sizeof(val_buf), format, *v);
    ImGui::PushFont(g_fontTitle, 13.0f);
    ImVec2 val_size = ImGui::CalcTextSize(val_buf);
    float mark_x = track_bb.Min.x + fill_width;
    float val_x = Px(ImClamp(mark_x - val_size.x * 0.5f, track_bb.Min.x + 2.0f, track_bb.Max.x - val_size.x - 2.0f));
    float val_y = Px(track_bb.Max.y - val_size.y * 0.5f);
    DrawOutlinedText(draw, ImVec2(val_x, val_y), Tc(g_theme->text), val_buf);
    ImGui::PopFont();
    return value_changed;
}

inline bool SliderRange(const char* label, float* v0, float* v1, float v_min, float v_max, const char* format = "%.0f")
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
    ImVec2 minus_sz = ImGui::CalcTextSize("-");
    ImVec2 plus_sz = ImGui::CalcTextSize("+");

    float spacing = 3.0f;
    float track_h = 12.0f;
    float gap = 6.0f;
    float row_h = EvenDiff(ImMax(track_h, ImMax(minus_sz.y, plus_sz.y)), track_h);
    ImGui::PushFont(g_fontTitle, 13.0f);
    ImVec2 val_probe = ImGui::CalcTextSize("00 - 00");
    ImGui::PopFont();
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;
    float full_w = ItemW();
    float minus_x0 = GlyphX0('-');
    float minus_x1 = GlyphX1('-');
    float plus_x0 = GlyphX0('+');
    float plus_x1 = GlyphX1('+');
    float minus_draw = Px(pos.x - minus_x0);
    float plus_draw = Px(pos.x + full_w - plus_x1);
    float minus_r = Px(minus_draw + minus_x1);
    float plus_l = Px(plus_draw + plus_x0);
    float track_x0 = minus_r + gap;
    float track_x1 = plus_l - gap;
    float track_w = ImMax(1.0f, track_x1 - track_x0);
    ImRect bb(pos, ImVec2(pos.x + ImMax(Px(label_size.x), full_w), pos.y + Px(label_size.y) + spacing + row_h + Px(val_probe.y * 0.5f)));

    ImGui::ItemSize(bb, style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id))
        return false;

    float row_y = pos.y + Px(label_size.y) + spacing;
    float track_y = row_y + Px((row_h - track_h) * 0.5f);
    ImRect minus_bb(ImVec2(pos.x, row_y), ImVec2(track_x0, row_y + row_h));
    ImRect track_bb(ImVec2(track_x0, track_y), ImVec2(track_x0 + track_w, track_y + track_h));
    ImRect plus_bb(ImVec2(track_bb.Max.x, row_y), ImVec2(pos.x + full_w, row_y + row_h));

    bool hovered, held;
    ImGui::ButtonBehavior(track_bb, id, &hovered, &held);
    ImGui::PushID(id);
    bool minus_hov, minus_held;
    bool minus_pressed = ImGui::ButtonBehavior(minus_bb, window->GetID("##s-"), &minus_hov, &minus_held);
    bool plus_hov, plus_held;
    bool plus_pressed = ImGui::ButtonBehavior(plus_bb, window->GetID("##s+"), &plus_hov, &plus_held);
    ImGui::PopID();
    bool value_changed = false;
    float step = (v_max - v_min) >= 10.0f ? 1.0f : 0.1f;
    int* grab = window->StateStorage.GetIntRef(id + 2, -1);

    if (held)
    {
        float new_v = v_min + (g.IO.MousePos.x - track_bb.Min.x) / track_w * (v_max - v_min);
        new_v = ImClamp(new_v, v_min, v_max);
        if (*grab < 0)
            *grab = (ImFabs(new_v - *v0) <= ImFabs(new_v - *v1)) ? 0 : 1;
        if (*grab == 0)
        {
            new_v = ImMin(new_v, *v1);
            if (*v0 != new_v)
            {
                *v0 = new_v;
                value_changed = true;
            }
        }
        else
        {
            new_v = ImMax(new_v, *v0);
            if (*v1 != new_v)
            {
                *v1 = new_v;
                value_changed = true;
            }
        }
    }
    else
        *grab = -1;

    if (minus_pressed)
    {
        *v0 = ImClamp(*v0 - step, v_min, *v1);
        value_changed = true;
    }
    if (plus_pressed)
    {
        *v1 = ImClamp(*v1 + step, *v0, v_max);
        value_changed = true;
    }

    ImDrawList* draw = window->DrawList;
    float r0 = (*v0 - v_min) / (v_max - v_min);
    float r1 = (*v1 - v_min) / (v_max - v_min);
    float* anim_hover = window->StateStorage.GetFloatRef(id, 0.0f);
    *anim_hover = ImLerp(*anim_hover, (hovered || held || minus_hov || plus_hov) ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);
    float* anim0 = window->StateStorage.GetFloatRef(id + 1, r0);
    float* anim1 = window->StateStorage.GetFloatRef(id + 3, r1);
    *anim0 = ImLerp(*anim0, r0, 15.0f * g.IO.DeltaTime);
    *anim1 = ImLerp(*anim1, r1, 15.0f * g.IO.DeltaTime);

    ImColor text_col = LerpRgb(Lift(g_theme->text_dim, -40), g_theme->text, *anim_hover);
    DrawOutlinedText(draw, ImVec2(pos.x, pos.y), text_col, label);
    DrawOutlinedText(draw, Px(ImVec2(minus_draw, minus_bb.Min.y + (row_h - minus_sz.y) * 0.5f)), minus_hov ? Tc(g_theme->accent) : text_col, "-");
    DrawOutlinedText(draw, Px(ImVec2(plus_draw, plus_bb.Min.y + (row_h - plus_sz.y) * 0.5f)), plus_hov ? Tc(g_theme->accent) : text_col, "+");

    draw->AddRectFilledMultiColor(track_bb.Min, track_bb.Max, Tc(g_theme->frame), Tc(g_theme->frame), Tc(g_theme->win), Tc(g_theme->win));
    float x0 = Px(track_bb.Min.x + track_w * (*anim0) + 0.5f);
    float x1 = Px(track_bb.Min.x + track_w * (*anim1) + 0.5f);
    if (x1 > x0)
        draw->AddRectFilledMultiColor(ImVec2(x0, track_bb.Min.y), ImVec2(x1, track_bb.Max.y), Tc(g_theme->accent), Tc(g_theme->accent), Tc(g_theme->accent_lo), Tc(g_theme->accent_lo));
    draw->AddRect(track_bb.Min, track_bb.Max, FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(track_bb.Min.x + 1, track_bb.Min.y + 1), ImVec2(track_bb.Max.x - 1, track_bb.Max.y - 1), Tc(g_theme->border));

    char a[16], b[16], val_buf[40];
    snprintf(a, sizeof(a), format, *v0);
    snprintf(b, sizeof(b), format, *v1);
    snprintf(val_buf, sizeof(val_buf), "%s - %s", a, b);
    ImGui::PushFont(g_fontTitle, 13.0f);
    ImVec2 val_size = ImGui::CalcTextSize(val_buf);
    float mid = (x0 + x1) * 0.5f;
    float val_x = Px(ImClamp(mid - val_size.x * 0.5f, track_bb.Min.x + 2.0f, track_bb.Max.x - val_size.x - 2.0f));
    float val_y = Px(track_bb.Max.y - val_size.y * 0.5f);
    DrawOutlinedText(draw, ImVec2(val_x, val_y), Tc(g_theme->text), val_buf);
    ImGui::PopFont();
    return value_changed;
}

inline bool Combo(const char* label, int* current_item, const char* const items[], int items_count, const ImVec2& size_arg = ImVec2(0, 0))
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
    float spacing = 4.0f;
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;

    ImVec2 size = size_arg;
    if (size.x <= 0.0f)
        size.x = ItemW();
    else
        size.x = Px(size.x);
    if (size.y <= 0.0f)
        size.y = 19.0f;

    ImRect bb(pos, ImVec2(pos.x + ImMax(Px(label_size.x), size.x), pos.y + Px(label_size.y) + spacing + size.y));
    ImGui::ItemSize(bb, style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id))
        return false;

    ImRect combo_bb(ImVec2(pos.x, pos.y + Px(label_size.y) + spacing), ImVec2(pos.x + size.x, pos.y + Px(label_size.y) + spacing + size.y));

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(combo_bb, id, &hovered, &held);

    float* anim_hover = window->StateStorage.GetFloatRef(id, 0.0f);
    *anim_hover = ImLerp(*anim_hover, hovered || ImGui::IsPopupOpen(label) ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);

    ImDrawList* draw = window->DrawList;
    ImColor bg_top = LerpRgb(g_theme->frame, Lift(g_theme->frame, 8), *anim_hover);
    ImColor bg_bot = LerpRgb(g_theme->frame_bot, Lift(g_theme->frame_bot, 7), *anim_hover);

    draw->AddRectFilledMultiColor(combo_bb.Min, combo_bb.Max, bg_top, bg_top, bg_bot, bg_bot);
    draw->AddRect(combo_bb.Min, combo_bb.Max, FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(combo_bb.Min.x + 1, combo_bb.Min.y + 1), ImVec2(combo_bb.Max.x - 1, combo_bb.Max.y - 1), Tc(g_theme->border));

    ImColor text_col = LerpRgb(Lift(g_theme->text_dim, -40), g_theme->text, *anim_hover);
    DrawOutlinedText(draw, ImVec2(InkX(pos.x + 1.0f, label), pos.y), text_col, label);

    const char* preview_text = (*current_item >= 0 && *current_item < items_count) ? items[*current_item] : "-";
    ImVec2 preview_size = ImGui::CalcTextSize(preview_text);
    DrawOutlinedText(draw, Px(ImVec2(combo_bb.Min.x + 6.0f, combo_bb.Min.y + (size.y - preview_size.y) * 0.5f)), Tc(g_theme->text), preview_text);

    ImRect icon_bb(ImVec2(combo_bb.Max.x - 19.0f, combo_bb.Min.y), combo_bb.Max);
    draw->AddLine(ImVec2(icon_bb.Min.x, icon_bb.Min.y), ImVec2(icon_bb.Min.x, icon_bb.Max.y), FadeCol(0, 0, 0));
    draw->AddLine(ImVec2(icon_bb.Min.x + 1, icon_bb.Min.y + 1), ImVec2(icon_bb.Min.x + 1, icon_bb.Max.y - 1), Tc(g_theme->border));

    ImVec2 icon_center(
        (float)(int)(icon_bb.Min.x + (icon_bb.Max.x - icon_bb.Min.x) * 0.5f),
        (float)(int)(icon_bb.Min.y + (icon_bb.Max.y - icon_bb.Min.y) * 0.5f));
    bool is_popup_open = ImGui::IsPopupOpen(label);
    draw->AddRectFilled(ImVec2(icon_center.x - 4, icon_center.y - 1), ImVec2(icon_center.x + 5, icon_center.y + 2), FadeCol(0, 0, 0));
    if (!is_popup_open)
        draw->AddRectFilled(ImVec2(icon_center.x - 1, icon_center.y - 4), ImVec2(icon_center.x + 2, icon_center.y + 5), FadeCol(0, 0, 0));
    draw->AddRectFilled(ImVec2(icon_center.x - 3, icon_center.y), ImVec2(icon_center.x + 4, icon_center.y + 1), Tc(g_theme->text_dim));
    if (!is_popup_open)
        draw->AddRectFilled(ImVec2(icon_center.x, icon_center.y - 3), ImVec2(icon_center.x + 1, icon_center.y + 4), Tc(g_theme->text_dim));

    bool value_changed = false;
    if (pressed && !is_popup_open)
        ImGui::OpenPopup(label);

    float item_height = 18.0f;
    float search_h = 19.0f;
    bool has_search = items_count > 10;
    int vis = ImMin(items_count, 10);
    float list_h = vis * item_height + 4.0f;
    float popup_h = list_h + (has_search ? search_h + 4.0f : 0.0f);
    ImGui::SetNextWindowPos(ImVec2(combo_bb.Min.x, combo_bb.Max.y + 2.0f));
    ImGui::SetNextWindowSize(ImVec2(size.x, popup_h));
    ImGui::PushStyleColor(ImGuiCol_PopupBg, Tc(g_theme->win).Value);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 0.0f);

    if (ImGui::BeginPopup(label))
    {
        ImDrawList* popup_draw = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetWindowPos();
        ImVec2 s = ImGui::GetWindowSize();
        popup_draw->AddRectFilledMultiColor(p, ImVec2(p.x + s.x, p.y + s.y), Tc(g_theme->frame), Tc(g_theme->frame), Tc(g_theme->win), Tc(g_theme->win));
        popup_draw->AddRect(p, ImVec2(p.x + s.x, p.y + s.y), FadeCol(0, 0, 0));
        popup_draw->AddRect(ImVec2(p.x + 1, p.y + 1), ImVec2(p.x + s.x - 1, p.y + s.y - 1), Tc(g_theme->border));

        static ImGuiID search_id = 0;
        static char search[64] = "";
        if (ImGui::IsWindowAppearing())
        {
            search_id = id;
            search[0] = 0;
        }
        if (search_id != id)
            search[0] = 0;

        float list_y = 2.0f;
        if (has_search)
        {
            ImGui::SetCursorScreenPos(ImVec2(p.x + 3.0f, p.y + 3.0f));
            if (ImGui::IsWindowAppearing())
                ImGui::SetKeyboardFocusHere();
            InputBox("csearch", search, sizeof(search), ImVec2(s.x - 6.0f, search_h), "Search");
            list_y = 5.0f + search_h;
        }

        ImGui::SetCursorScreenPos(ImVec2(p.x + 2.0f, p.y + list_y));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
        ImGui::BeginChild("combo_items", ImVec2(s.x - 4.0f, s.y - list_y - 2.0f), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar);
        if (ImGui::IsWindowAppearing() && *current_item > 0 && !search[0])
            ImGui::SetScrollY(*current_item * item_height);

        ImDrawList* ld = ImGui::GetWindowDrawList();
        for (int i = 0; i < items_count; i++)
        {
            if (has_search && !StrIStr(items[i], search))
                continue;
            ImGui::PushID(i);
            ImVec2 ip = ImGui::GetCursorScreenPos();
            float row_w = ImGui::GetContentRegionAvail().x;
            ImGui::InvisibleButton(items[i], ImVec2(row_w, item_height));
            if (ImGui::IsItemClicked())
            {
                *current_item = i;
                value_changed = true;
                ImGui::CloseCurrentPopup();
            }

            bool is_selected = (*current_item == i);
            ImColor item_col = is_selected ? Tc(g_theme->accent) : Tc(g_theme->text_dim);
            if (ImGui::IsItemHovered() && !is_selected)
                item_col = Tc(g_theme->text);
            if (is_selected)
                ImGui::PushFont(g_fontTitle, 13.0f);
            ImVec2 ts = ImGui::CalcTextSize(items[i]);
            DrawOutlinedText(ld, Px(ImVec2(ip.x + (row_w - ts.x) * 0.5f, ip.y + (item_height - ts.y) * 0.5f)), item_col, items[i]);
            if (is_selected)
                ImGui::PopFont();
            ImGui::PopID();
        }
        ImGui::EndChild();
        ImGui::PopStyleVar();
        ImGui::EndPopup();
    }

    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor();
    return value_changed;
}

inline bool MultiCombo(const char* label, bool* values, const char* const items[], int items_count, const ImVec2& size_arg = ImVec2(0, 0))
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
    float spacing = 4.0f;
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;

    ImVec2 size = size_arg;
    if (size.x <= 0.0f)
        size.x = ItemW();
    else
        size.x = Px(size.x);
    if (size.y <= 0.0f)
        size.y = 19.0f;

    ImRect bb(pos, ImVec2(pos.x + ImMax(Px(label_size.x), size.x), pos.y + Px(label_size.y) + spacing + size.y));
    ImGui::ItemSize(bb, style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id))
        return false;

    ImRect combo_bb(ImVec2(pos.x, pos.y + Px(label_size.y) + spacing), ImVec2(pos.x + size.x, pos.y + Px(label_size.y) + spacing + size.y));

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(combo_bb, id, &hovered, &held);
    bool is_popup_open = ImGui::IsPopupOpen(label);

    float* anim_hover = window->StateStorage.GetFloatRef(id, 0.0f);
    *anim_hover = ImLerp(*anim_hover, hovered || is_popup_open ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);

    ImDrawList* draw = window->DrawList;
    ImColor bg_top = LerpRgb(g_theme->frame, Lift(g_theme->frame, 8), *anim_hover);
    ImColor bg_bot = LerpRgb(g_theme->frame_bot, Lift(g_theme->frame_bot, 7), *anim_hover);

    draw->AddRectFilledMultiColor(combo_bb.Min, combo_bb.Max, bg_top, bg_top, bg_bot, bg_bot);
    draw->AddRect(combo_bb.Min, combo_bb.Max, FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(combo_bb.Min.x + 1, combo_bb.Min.y + 1), ImVec2(combo_bb.Max.x - 1, combo_bb.Max.y - 1), Tc(g_theme->border));

    ImColor text_col = LerpRgb(Lift(g_theme->text_dim, -40), g_theme->text, *anim_hover);
    DrawOutlinedText(draw, ImVec2(InkX(pos.x + 1.0f, label), pos.y), text_col, label);

    char preview[128];
    preview[0] = 0;
    for (int i = 0; i < items_count; i++)
    {
        if (!values[i])
            continue;
        size_t used = strlen(preview);
        if (used)
        {
            if (used + 2 >= sizeof(preview) - 1)
                break;
            memcpy(preview + used, ", ", 3);
            used += 2;
        }
        size_t add = strlen(items[i]);
        if (used + add >= sizeof(preview) - 1)
            break;
        memcpy(preview + used, items[i], add + 1);
    }
    if (!preview[0])
        memcpy(preview, "-", 2);

    float preview_max = size.x - 28.0f;
    size_t plen = strlen(preview);
    while (plen > 0 && ImGui::CalcTextSize(preview).x > preview_max)
    {
        preview[--plen] = 0;
        if (plen >= 3)
        {
            preview[plen - 3] = '.';
            preview[plen - 2] = '.';
            preview[plen - 1] = '.';
            preview[plen] = 0;
        }
    }

    ImVec2 preview_size = ImGui::CalcTextSize(preview);
    DrawOutlinedText(draw, Px(ImVec2(combo_bb.Min.x + 6.0f, combo_bb.Min.y + (size.y - preview_size.y) * 0.5f)), Tc(g_theme->text), preview);

    ImRect icon_bb(ImVec2(combo_bb.Max.x - 19.0f, combo_bb.Min.y), combo_bb.Max);
    draw->AddLine(ImVec2(icon_bb.Min.x, icon_bb.Min.y), ImVec2(icon_bb.Min.x, icon_bb.Max.y), FadeCol(0, 0, 0));
    draw->AddLine(ImVec2(icon_bb.Min.x + 1, icon_bb.Min.y + 1), ImVec2(icon_bb.Min.x + 1, icon_bb.Max.y - 1), Tc(g_theme->border));

    ImVec2 icon_center(
        (float)(int)(icon_bb.Min.x + (icon_bb.Max.x - icon_bb.Min.x) * 0.5f),
        (float)(int)(icon_bb.Min.y + (icon_bb.Max.y - icon_bb.Min.y) * 0.5f));
    draw->AddRectFilled(ImVec2(icon_center.x - 4, icon_center.y - 1), ImVec2(icon_center.x + 5, icon_center.y + 2), FadeCol(0, 0, 0));
    if (!is_popup_open)
        draw->AddRectFilled(ImVec2(icon_center.x - 1, icon_center.y - 4), ImVec2(icon_center.x + 2, icon_center.y + 5), FadeCol(0, 0, 0));
    draw->AddRectFilled(ImVec2(icon_center.x - 3, icon_center.y), ImVec2(icon_center.x + 4, icon_center.y + 1), Tc(g_theme->text_dim));
    if (!is_popup_open)
        draw->AddRectFilled(ImVec2(icon_center.x, icon_center.y - 3), ImVec2(icon_center.x + 1, icon_center.y + 4), Tc(g_theme->text_dim));

    bool value_changed = false;
    if (pressed && !is_popup_open)
        ImGui::OpenPopup(label);

    float item_height = 18.0f;
    int vis = ImMin(items_count, 10);
    float list_h = vis * item_height + 4.0f;
    ImGui::SetNextWindowPos(ImVec2(combo_bb.Min.x, combo_bb.Max.y + 2.0f));
    ImGui::SetNextWindowSize(ImVec2(size.x, list_h));
    ImGui::PushStyleColor(ImGuiCol_PopupBg, Tc(g_theme->win).Value);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 0.0f);

    if (ImGui::BeginPopup(label))
    {
        ImDrawList* popup_draw = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetWindowPos();
        ImVec2 s = ImGui::GetWindowSize();
        popup_draw->AddRectFilledMultiColor(p, ImVec2(p.x + s.x, p.y + s.y), Tc(g_theme->frame), Tc(g_theme->frame), Tc(g_theme->win), Tc(g_theme->win));
        popup_draw->AddRect(p, ImVec2(p.x + s.x, p.y + s.y), FadeCol(0, 0, 0));
        popup_draw->AddRect(ImVec2(p.x + 1, p.y + 1), ImVec2(p.x + s.x - 1, p.y + s.y - 1), Tc(g_theme->border));

        ImGui::SetCursorScreenPos(ImVec2(p.x + 2.0f, p.y + 2.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
        ImGui::BeginChild("mcombo_items", ImVec2(s.x - 4.0f, s.y - 4.0f), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar);

        ImDrawList* ld = ImGui::GetWindowDrawList();
        for (int i = 0; i < items_count; i++)
        {
            ImGui::PushID(i);
            ImVec2 ip = ImGui::GetCursorScreenPos();
            float row_w = ImGui::GetContentRegionAvail().x;
            ImGui::InvisibleButton(items[i], ImVec2(row_w, item_height));
            if (ImGui::IsItemClicked())
            {
                values[i] = !values[i];
                value_changed = true;
            }

            bool is_selected = values[i];
            ImColor item_col = is_selected ? Tc(g_theme->accent) : Tc(g_theme->text_dim);
            if (ImGui::IsItemHovered() && !is_selected)
                item_col = Tc(g_theme->text);
            if (is_selected)
                ImGui::PushFont(g_fontTitle, 13.0f);
            ImVec2 ts = ImGui::CalcTextSize(items[i]);
            DrawOutlinedText(ld, Px(ImVec2(ip.x + (row_w - ts.x) * 0.5f, ip.y + (item_height - ts.y) * 0.5f)), item_col, items[i]);
            if (is_selected)
                ImGui::PopFont();
            ImGui::PopID();
        }
        ImGui::EndChild();
        ImGui::PopStyleVar();
        ImGui::EndPopup();
    }

    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor();
    return value_changed;
}

inline bool Button(const char* label, const ImVec2& size_arg = ImVec2(0, 0))
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;
    ImVec2 size = size_arg;
    if (size.x <= 0.0f)
        size.x = ItemW();
    else
        size.x = Px(size.x);
    if (size.y <= 0.0f)
        size.y = 24.0f;
    ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));
    ImGui::ItemSize(bb, style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id))
        return false;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);
    float* anim_hover = window->StateStorage.GetFloatRef(id, 0.0f);
    float* anim_active = window->StateStorage.GetFloatRef(id + 1, 0.0f);
    *anim_hover = ImLerp(*anim_hover, (hovered && !held) ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);
    *anim_active = ImLerp(*anim_active, held ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);

    ImColor bg_top = LerpCol(LerpRgb(g_theme->frame, Lift(g_theme->frame, 8), *anim_hover), Tc(Lift(g_theme->frame_bot, -6)), *anim_active);
    ImColor bg_bot = LerpCol(LerpRgb(g_theme->frame_bot, Lift(g_theme->frame_bot, 7), *anim_hover), Tc(Lift(g_theme->frame_bot, -10)), *anim_active);
    window->DrawList->AddRectFilledMultiColor(bb.Min, bb.Max, bg_top, bg_top, bg_bot, bg_bot);
    window->DrawList->AddRect(bb.Min, bb.Max, FadeCol(0, 0, 0));
    window->DrawList->AddRect(ImVec2(bb.Min.x + 1, bb.Min.y + 1), ImVec2(bb.Max.x - 1, bb.Max.y - 1), Tc(g_theme->border));

    const char* text_end = ImGui::FindRenderedTextEnd(label);
    ImVec2 ts = ImGui::CalcTextSize(label, text_end);
    ImVec2 tp = Px(ImVec2(bb.Min.x + (size.x - ts.x) * 0.5f, bb.Min.y + (size.y - ts.y) * 0.5f));
    ImColor text_col = LerpCol(LerpRgb(g_theme->text_dim, g_theme->text, *anim_hover), Tc(Lift(g_theme->text_dim, -25)), *anim_active);
    DrawOutlinedText(window->DrawList, tp, text_col, label, text_end);
    return pressed;
}

inline int ButtonRow(const char* const* labels, int count)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    ImGui::PushID((int)window->DC.CursorPos.y);
    float gap = 2.0f;
    float avail = ItemW();
    float cell = IM_TRUNC((avail - gap * (float)(count - 1)) / (float)count);
    int pressed = -1;
    for (int i = 0; i < count; i++)
    {
        if (i)
            ImGui::SameLine(0, gap);
        float w = (i == count - 1) ? (avail - (cell + gap) * (float)(count - 1)) : cell;
        ImGui::PushID(i);
        if (Button(labels[i], ImVec2(ImMax(1.0f, w), 0)))
            pressed = i;
        ImGui::PopID();
    }
    ImGui::PopID();
    return pressed;
}

inline bool ColorPicker(const char* label, float col[4])
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(label);
    int* rainbow = window->StateStorage.GetIntRef(id + 0xC02, 0);
    float* rb_speed = window->StateStorage.GetFloatRef(id + 0xC03, 1.0f);
    int* fade = window->StateStorage.GetIntRef(id + 0xC04, 0);
    float* fade_speed = window->StateStorage.GetFloatRef(id + 0xC05, 1.0f);
    int* fade_dir = window->StateStorage.GetIntRef(id + 0xC06, 1);
    int* shade_rand = window->StateStorage.GetIntRef(id + 0xC07, 0);
    float* sr_speed = window->StateStorage.GetFloatRef(id + 0xC08, 1.0f);
    float* sr_ts = window->StateStorage.GetFloatRef(id + 0xC0A, -1.0f);
    float* sr_tv = window->StateStorage.GetFloatRef(id + 0xC0B, -1.0f);
    if (*rainbow)
    {
        float H, S, V;
        ImGui::ColorConvertRGBtoHSV(col[0], col[1], col[2], H, S, V);
        H += g.IO.DeltaTime * (*rb_speed) * 0.15f;
        if (H > 1.0f)
            H -= 1.0f;
        ImGui::ColorConvertHSVtoRGB(H, S, V, col[0], col[1], col[2]);
    }
    if (*shade_rand)
    {
        float H, S, V;
        ImGui::ColorConvertRGBtoHSV(col[0], col[1], col[2], H, S, V);
        if (*sr_ts < 0.0f)
        {
            *sr_ts = S;
            *sr_tv = V;
        }
        float dx = *sr_ts - S;
        float dy = *sr_tv - V;
        if (dx * dx + dy * dy < 0.0004f)
        {
            unsigned seed = (unsigned)(ImGui::GetTime() * 100000.0f) ^ id;
            seed = seed * 1664525u + 1013904223u;
            *sr_ts = (float)(seed & 0xFFFF) / 65535.0f;
            seed = seed * 1664525u + 1013904223u;
            *sr_tv = (float)(seed & 0xFFFF) / 65535.0f;
        }
        float k = ImSaturate(g.IO.DeltaTime * (*sr_speed) * 2.0f);
        S = ImLerp(S, *sr_ts, k);
        V = ImLerp(V, *sr_tv, k);
        ImGui::ColorConvertHSVtoRGB(H, S, V, col[0], col[1], col[2]);
    }
    if (*fade)
    {
        if (*fade_dir == 0)
            *fade_dir = 1;
        float step = g.IO.DeltaTime * (*fade_speed) * 0.15f;
        col[3] += *fade_dir > 0 ? step : -step;
        if (col[3] >= 1.0f)
        {
            col[3] = 1.0f;
            *fade_dir = -1;
        }
        else if (col[3] <= 0.0f)
        {
            col[3] = 0.0f;
            *fade_dir = 1;
        }
    }
    const float box_w = 26.0f;
    const float box_h = 16.0f;
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;
    const ImRect rect(pos, ImVec2(pos.x + box_w, pos.y + box_h));

    ImGui::ItemSize(rect, g.Style.FramePadding.y);
    if (!ImGui::ItemAdd(rect, id))
        return false;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(rect, id, &hovered, &held);
    if (pressed)
        ImGui::OpenPopup(label);

    ImDrawList* draw = window->DrawList;
    ImColor base_col(col[0], col[1], col[2], col[3]);
    ImColor bot_col = ImColor(col[0] * 0.7f, col[1] * 0.7f, col[2] * 0.7f, col[3]);
    float inner_w = box_w - 4.0f;
    float inner_h = box_h - 4.0f;
    for (float y = 0.0f; y < inner_h; y += 4.0f)
    {
        for (float x = 0.0f; x < inner_w; x += 4.0f)
        {
            ImU32 c = (((int)x / 4) + ((int)y / 4)) % 2 == 0 ? IM_COL32(100, 100, 100, 255) : IM_COL32(50, 50, 50, 255);
            draw->AddRectFilled(ImVec2(pos.x + 2 + x, pos.y + 2 + y), ImVec2(pos.x + 2 + ImMin(x + 4.0f, inner_w), pos.y + 2 + ImMin(y + 4.0f, inner_h)), c);
        }
    }
    draw->AddRectFilledMultiColor(ImVec2(pos.x + 2, pos.y + 2), ImVec2(pos.x + box_w - 2, pos.y + box_h - 2), base_col, base_col, bot_col, bot_col);
    draw->AddRect(pos, ImVec2(pos.x + box_w, pos.y + box_h), FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(pos.x + 1, pos.y + 1), ImVec2(pos.x + box_w - 1, pos.y + box_h - 1), Tc(g_theme->border));

    bool value_changed = false;
    ImGui::PushStyleColor(ImGuiCol_PopupBg, Tc(g_theme->child).Value);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8, 8));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 1.0f);
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.0f, 0.0f, 0.0f, 1.0f));

    if (ImGui::BeginPopup(label))
    {
        ImDrawList* popup_draw = ImGui::GetWindowDrawList();
        int* page = window->StateStorage.GetIntRef(id + 0xC01, 0);
        float sv_picker_size = 150.0f;
        float hue_picker_width = 15.0f;
        float alpha_picker_height = 15.0f;
        float spacing = 8.0f;
        float picker_w = sv_picker_size + spacing + hue_picker_width;
        float tab_h = 24.0f;
        float pad = 6.0f;
        float field_h = 19.0f;
        float fields_h = field_h + 4.0f + field_h;
        float content_h = sv_picker_size + spacing + alpha_picker_height + spacing + fields_h;
        if (*page == 1)
            content_h = 230.0f;
        float chrome_w = picker_w + pad * 2.0f;
        float chrome_h = tab_h + 5.0f + content_h + pad;
        ImVec2 tab_pos = ImGui::GetCursorScreenPos();
        ImVec2 chrome_max(tab_pos.x + chrome_w, tab_pos.y + chrome_h);
        popup_draw->AddRectFilled(tab_pos, chrome_max, Tc(g_theme->child));
        float tab_w = IM_TRUNC(chrome_w * 0.5f);
        float line_y = IM_TRUNC(tab_pos.y + tab_h);
        float active_min = IM_TRUNC(tab_pos.x) + (*page) * tab_w;
        float active_max = IM_TRUNC(tab_pos.x) + (*page + 1) * tab_w;
        if (*page > 0)
        {
            popup_draw->AddRectFilled(ImVec2(IM_TRUNC(tab_pos.x + 2.0f), IM_TRUNC(tab_pos.y + 2.0f)), ImVec2(active_min, line_y), Tc(g_theme->win));
            popup_draw->AddRectFilled(ImVec2(IM_TRUNC(tab_pos.x + 2.0f), line_y), ImVec2(active_min, line_y + 1), FadeCol(0, 0, 0));
            popup_draw->AddRectFilled(ImVec2(IM_TRUNC(tab_pos.x + 2.0f), line_y + 1), ImVec2(active_min + 1, line_y + 2), Tc(g_theme->border));
            popup_draw->AddRectFilled(ImVec2(active_min - 1, tab_pos.y + 2), ImVec2(active_min, line_y), FadeCol(0, 0, 0));
            popup_draw->AddRectFilled(ImVec2(active_min, tab_pos.y + 2), ImVec2(active_min + 1, line_y + 1), Tc(g_theme->border));
        }
        if (*page < 1)
        {
            popup_draw->AddRectFilled(ImVec2(active_max, IM_TRUNC(tab_pos.y + 2.0f)), ImVec2(chrome_max.x, line_y), Tc(g_theme->win));
            popup_draw->AddRectFilled(ImVec2(active_max + 1, line_y), ImVec2(chrome_max.x, line_y + 1), FadeCol(0, 0, 0));
            popup_draw->AddRectFilled(ImVec2(active_max, line_y + 1), ImVec2(chrome_max.x, line_y + 2), Tc(g_theme->border));
            popup_draw->AddRectFilled(ImVec2(active_max, tab_pos.y + 2), ImVec2(active_max + 1, line_y + 1), Tc(g_theme->border));
            popup_draw->AddRectFilled(ImVec2(active_max + 1, tab_pos.y + 2), ImVec2(active_max + 2, line_y), FadeCol(0, 0, 0));
        }
        float x0 = IM_TRUNC(tab_pos.x);
        float y0 = IM_TRUNC(tab_pos.y);
        float x1 = IM_TRUNC(chrome_max.x);
        float y1 = IM_TRUNC(chrome_max.y);
        popup_draw->AddRectFilled(ImVec2(x0, y1 - 1), ImVec2(x1, y1), FadeCol(0, 0, 0));
        popup_draw->AddRectFilled(ImVec2(x0, y0), ImVec2(x0 + 1, y1), FadeCol(0, 0, 0));
        popup_draw->AddRectFilled(ImVec2(x1 - 1, y0), ImVec2(x1, y1), FadeCol(0, 0, 0));
        popup_draw->AddRectFilled(ImVec2(x0 + 1, y1 - 2), ImVec2(x1 - 1, y1 - 1), Tc(g_theme->border));
        popup_draw->AddRectFilled(ImVec2(x0 + 1, y0 + 1), ImVec2(x0 + 2, y1 - 1), Tc(g_theme->border));
        popup_draw->AddRectFilled(ImVec2(x1 - 2, y0 + 1), ImVec2(x1 - 1, y1 - 1), Tc(g_theme->border));
        popup_draw->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y0 + 1), FadeCol(0, 0, 0));
        popup_draw->AddRectFilled(ImVec2(x0 + 1, y0 + 1), ImVec2(x1 - 1, y0 + 2), Tc(g_theme->border));

        const char* tab_names[] = { "Color", "Settings" };
        for (int i = 0; i < 2; i++)
        {
            ImVec2 t0(tab_pos.x + i * tab_w, tab_pos.y);
            ImGui::SetCursorScreenPos(t0);
            if (ImGui::InvisibleButton(tab_names[i], ImVec2(tab_w, tab_h)))
                *page = i;
            bool on = (*page == i);
            ImGui::PushFont(on ? g_fontTitle : g_fontVerdana, 13.0f);
            ImVec2 ns = ImGui::CalcTextSize(tab_names[i]);
            DrawOutlinedText(popup_draw, ImVec2(IM_TRUNC(t0.x + (tab_w - ns.x) * 0.5f), IM_TRUNC(t0.y + (tab_h - ns.y) * 0.5f)), on ? Tc(g_theme->accent) : Tc(g_theme->text_dim), tab_names[i]);
            ImGui::PopFont();
        }

        ImGui::SetCursorScreenPos(ImVec2(tab_pos.x, tab_pos.y + tab_h));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, *page == 1 ? ImVec2(10.0f, 10.0f) : ImVec2(pad, pad));
        ImGui::BeginChild("##cp_body", ImVec2(chrome_w, chrome_h - tab_h), ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar);
        ImGui::PopStyleVar();

        if (*page == 1)
        {
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, g.Style.ItemInnerSpacing);
            ImGui::PushItemWidth(ImMax(1.0f, ImGui::GetContentRegionAvail().x));
            ImGui::PushID(id);
            bool rb = *rainbow != 0;
            Checkbox("Rainbow", &rb);
            *rainbow = rb ? 1 : 0;
            SliderFloat("Rainbow Speed", rb_speed, 0.f, 10.f, "%.1f");
            bool tr = *fade != 0;
            Checkbox("Transparency", &tr);
            *fade = tr ? 1 : 0;
            SliderFloat("Transparency Speed", fade_speed, 0.f, 10.f, "%.1f");
            bool sr = *shade_rand != 0;
            Checkbox("Shade Random", &sr);
            *shade_rand = sr ? 1 : 0;
            SliderFloat("Shade Random Speed", sr_speed, 0.f, 10.f, "%.1f");
            ImGui::PopID();
            ImGui::PopItemWidth();
            ImGui::PopStyleVar();
        }
        else
        {
        ImVec2 p = ImGui::GetCursorScreenPos();

        float H, S, V;
        ImGui::ColorConvertRGBtoHSV(col[0], col[1], col[2], H, S, V);
        float A = col[3];
        ImRect sv_bb(p, ImVec2(p.x + sv_picker_size, p.y + sv_picker_size));
        ImGui::InvisibleButton("##sv", ImVec2(sv_picker_size, sv_picker_size));
        if (ImGui::IsItemActive())
        {
            S = ImSaturate((ImGui::GetIO().MousePos.x - sv_bb.Min.x) / (sv_picker_size - 1));
            V = 1.0f - ImSaturate((ImGui::GetIO().MousePos.y - sv_bb.Min.y) / (sv_picker_size - 1));
            value_changed = true;
            *rainbow = 0;
            *shade_rand = 0;
            *sr_ts = -1.0f;
        }

        float r, gb, b;
        ImGui::ColorConvertHSVtoRGB(H, 1.0f, 1.0f, r, gb, b);
        ImColor hue_color = ImColor(r, gb, b, 1.0f);
        popup_draw->AddRectFilledMultiColor(sv_bb.Min, sv_bb.Max, FadeCol(255, 255, 255), hue_color, hue_color, FadeCol(255, 255, 255));
        popup_draw->AddRectFilledMultiColor(sv_bb.Min, sv_bb.Max, FadeCol(0, 0, 0, 0), FadeCol(0, 0, 0, 0), FadeCol(0, 0, 0, 255), FadeCol(0, 0, 0, 255));
        popup_draw->AddRect(sv_bb.Min, sv_bb.Max, FadeCol(0, 0, 0));
        popup_draw->AddRect(ImVec2(sv_bb.Min.x + 1, sv_bb.Min.y + 1), ImVec2(sv_bb.Max.x - 1, sv_bb.Max.y - 1), Tc(g_theme->border));

        ImVec2 cursor_pos = ImVec2(sv_bb.Min.x + S * sv_picker_size, sv_bb.Min.y + (1.0f - V) * sv_picker_size);
        popup_draw->AddCircle(cursor_pos, 4.0f, FadeCol(0, 0, 0), 0, 2.0f);
        popup_draw->AddCircle(cursor_pos, 3.0f, FadeCol(255, 255, 255), 0, 1.0f);

        ImGui::SameLine(0, spacing);
        ImVec2 hue_p = ImGui::GetCursorScreenPos();
        ImRect hue_bb(hue_p, ImVec2(hue_p.x + hue_picker_width, hue_p.y + sv_picker_size));
        ImGui::InvisibleButton("##hue", ImVec2(hue_picker_width, sv_picker_size));
        if (ImGui::IsItemActive())
        {
            H = ImSaturate((ImGui::GetIO().MousePos.y - hue_bb.Min.y) / (sv_picker_size - 1));
            value_changed = true;
            *rainbow = 0;
        }

        const ImU32 hue_colors[7] = {
            IM_COL32(255, 0, 0, 255),
            IM_COL32(255, 255, 0, 255),
            IM_COL32(0, 255, 0, 255),
            IM_COL32(0, 255, 255, 255),
            IM_COL32(0, 0, 255, 255),
            IM_COL32(255, 0, 255, 255),
            IM_COL32(255, 0, 0, 255)
        };
        for (int i = 0; i < 6; ++i)
        {
            float y0 = hue_bb.Min.y + (i * sv_picker_size / 6.0f);
            float y1 = hue_bb.Min.y + ((i + 1) * sv_picker_size / 6.0f);
            popup_draw->AddRectFilledMultiColor(ImVec2(hue_bb.Min.x, y0), ImVec2(hue_bb.Max.x, y1), hue_colors[i], hue_colors[i], hue_colors[i + 1], hue_colors[i + 1]);
        }
        popup_draw->AddRect(hue_bb.Min, hue_bb.Max, FadeCol(0, 0, 0));
        popup_draw->AddRect(ImVec2(hue_bb.Min.x + 1, hue_bb.Min.y + 1), ImVec2(hue_bb.Max.x - 1, hue_bb.Max.y - 1), Tc(g_theme->border));

        float hue_cursor_y = hue_bb.Min.y + H * sv_picker_size;
        popup_draw->AddRect(ImVec2(hue_bb.Min.x - 1, hue_cursor_y - 2), ImVec2(hue_bb.Max.x + 1, hue_cursor_y + 2), FadeCol(0, 0, 0));
        popup_draw->AddRect(ImVec2(hue_bb.Min.x, hue_cursor_y - 1), ImVec2(hue_bb.Max.x, hue_cursor_y + 1), FadeCol(255, 255, 255));

        ImVec2 alpha_p = ImVec2(p.x, p.y + sv_picker_size + spacing);
        ImGui::SetCursorScreenPos(alpha_p);
        ImRect alpha_bb(alpha_p, ImVec2(alpha_p.x + sv_picker_size + spacing + hue_picker_width, alpha_p.y + alpha_picker_height));
        ImGui::InvisibleButton("##alpha", ImVec2(sv_picker_size + spacing + hue_picker_width, alpha_picker_height));
        if (ImGui::IsItemActive())
        {
            A = ImSaturate((ImGui::GetIO().MousePos.x - alpha_bb.Min.x) / (alpha_bb.Max.x - alpha_bb.Min.x - 1));
            value_changed = true;
            *fade = 0;
        }

        popup_draw->AddRectFilled(alpha_bb.Min, alpha_bb.Max, Tc(g_theme->win));
        popup_draw->AddRectFilledMultiColor(alpha_bb.Min, alpha_bb.Max, ImColor(col[0], col[1], col[2], 0.0f), ImColor(col[0], col[1], col[2], 1.0f), ImColor(col[0], col[1], col[2], 1.0f), ImColor(col[0], col[1], col[2], 0.0f));
        popup_draw->AddRect(alpha_bb.Min, alpha_bb.Max, FadeCol(0, 0, 0));
        popup_draw->AddRect(ImVec2(alpha_bb.Min.x + 1, alpha_bb.Min.y + 1), ImVec2(alpha_bb.Max.x - 1, alpha_bb.Max.y - 1), Tc(g_theme->border));

        float alpha_cursor_x = alpha_bb.Min.x + A * (alpha_bb.Max.x - alpha_bb.Min.x);
        popup_draw->AddRect(ImVec2(alpha_cursor_x - 2, alpha_bb.Min.y - 1), ImVec2(alpha_cursor_x + 2, alpha_bb.Max.y + 1), FadeCol(0, 0, 0));
        popup_draw->AddRect(ImVec2(alpha_cursor_x - 1, alpha_bb.Min.y), ImVec2(alpha_cursor_x + 1, alpha_bb.Max.y), FadeCol(255, 255, 255));

        if (value_changed)
        {
            ImGui::ColorConvertHSVtoRGB(H, S, V, col[0], col[1], col[2]);
            col[3] = A;
        }

        static char rgb[3][8];
        static char hex[16];
        static bool rgb_edit[3];
        static bool hex_edit;
        for (int i = 0; i < 3; i++)
        {
            if (!rgb_edit[i])
                snprintf(rgb[i], sizeof(rgb[i]), "%d", (int)(col[i] * 255.0f + 0.5f));
        }
        if (!hex_edit)
            snprintf(hex, sizeof(hex), "#%02X%02X%02X", (int)(col[0] * 255.0f + 0.5f), (int)(col[1] * 255.0f + 0.5f), (int)(col[2] * 255.0f + 0.5f));

        float gap = 4.0f;
        float cell = IM_TRUNC((picker_w - gap * 2.0f) / 3.0f);
        float last_w = picker_w - (cell + gap) * 2.0f;
        const char* rgb_ids[] = { "cr", "cg", "cb" };
        const char* rgb_hint[] = { "R", "G", "B" };
        float row_y = alpha_bb.Max.y + spacing;
        ImGui::PushID(id);
        for (int i = 0; i < 3; i++)
        {
            ImGui::SetCursorScreenPos(ImVec2(p.x + (cell + gap) * (float)i, row_y));
            if (InputBox(rgb_ids[i], rgb[i], sizeof(rgb[i]), ImVec2(i == 2 ? last_w : cell, field_h), rgb_hint[i]))
            {
                int v = atoi(rgb[i]);
                if (v < 0)
                    v = 0;
                if (v > 255)
                    v = 255;
                col[i] = (float)v / 255.0f;
                value_changed = true;
                *rainbow = 0;
                *shade_rand = 0;
            }
            rgb_edit[i] = ImGui::IsItemActive();
        }
        ImGui::SetCursorScreenPos(ImVec2(p.x, row_y + field_h + 4.0f));
        if (InputBox("hex", hex, sizeof(hex), ImVec2(picker_w, field_h), "Hex"))
        {
            if (ParseHexColor(hex, col))
            {
                value_changed = true;
                *rainbow = 0;
                *shade_rand = 0;
            }
        }
        hex_edit = ImGui::IsItemActive();
        ImGui::PopID();
        }
        ImGui::EndChild();
        ImGui::EndPopup();
    }
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);
    return value_changed;
}

inline const char* KeyName(int key)
{
    if (key >= '0' && key <= '9')
    {
        static const char* d[] = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
        return d[key - '0'];
    }
    if (key >= 'A' && key <= 'Z')
    {
        static const char* a[] = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        return a[key - 'A'];
    }
    if (key >= VK_F1 && key <= VK_F24)
    {
        static const char* f[] = { "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "f20", "f21", "f22", "f23", "f24" };
        return f[key - VK_F1];
    }
    if (key >= VK_NUMPAD0 && key <= VK_NUMPAD9)
    {
        static const char* n[] = { "num0", "num1", "num2", "num3", "num4", "num5", "num6", "num7", "num8", "num9" };
        return n[key - VK_NUMPAD0];
    }
    switch (key)
    {
    case VK_LBUTTON: return "lmb";
    case VK_RBUTTON: return "rmb";
    case VK_MBUTTON: return "mmb";
    case VK_XBUTTON1: return "x1";
    case VK_XBUTTON2: return "x2";
    case VK_BACK: return "back";
    case VK_TAB: return "tab";
    case VK_RETURN: return "enter";
    case VK_SHIFT: return "shift";
    case VK_CONTROL: return "ctrl";
    case VK_MENU: return "alt";
    case VK_PAUSE: return "pause";
    case VK_CAPITAL: return "caps";
    case VK_ESCAPE: return "esc";
    case VK_SPACE: return "space";
    case VK_PRIOR: return "pgup";
    case VK_NEXT: return "pgdn";
    case VK_END: return "end";
    case VK_HOME: return "home";
    case VK_LEFT: return "left";
    case VK_UP: return "up";
    case VK_RIGHT: return "right";
    case VK_DOWN: return "down";
    case VK_INSERT: return "ins";
    case VK_DELETE: return "del";
    case VK_LWIN: return "lwin";
    case VK_RWIN: return "rwin";
    case VK_MULTIPLY: return "num*";
    case VK_ADD: return "num+";
    case VK_SUBTRACT: return "num-";
    case VK_DECIMAL: return "num.";
    case VK_DIVIDE: return "num/";
    case VK_NUMLOCK: return "numlock";
    case VK_SCROLL: return "scroll";
    case VK_LSHIFT: return "lshift";
    case VK_RSHIFT: return "rshift";
    case VK_LCONTROL: return "lctrl";
    case VK_RCONTROL: return "rctrl";
    case VK_LMENU: return "lalt";
    case VK_RMENU: return "ralt";
    default: return "-";
    }
}

inline bool Keybind(const char* label, int* key, int* mode)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(label);
    bool has_label = label && label[0] && !(label[0] == '#' && label[1] == '#');
    const char* list_name = has_label ? label : (label && label[0] == '#' && label[1] == '#' ? label + 2 : "Bind");
    static bool s_wait_up = false;
    bool is_active = (g_keybind_capture == id);

    if (is_active)
    {
        ImGuiIO& io = ImGui::GetIO();
        bool set = false;
        if (!s_wait_up)
        {
            bool any = false;
            for (int i = 0; i < IM_ARRAYSIZE(io.MouseDown); i++)
                if (io.MouseDown[i])
                    any = true;
            for (int vk = VK_BACK; vk <= VK_RMENU; vk++)
                if (GetAsyncKeyState(vk) & 0x8000)
                    any = true;
            if (!any)
                s_wait_up = true;
        }
        else
        {
            for (int i = 0; i < IM_ARRAYSIZE(io.MouseClicked); i++)
            {
                if (io.MouseClicked[i])
                {
                    static const int mouse_vk[] = { VK_LBUTTON, VK_RBUTTON, VK_MBUTTON, VK_XBUTTON1, VK_XBUTTON2 };
                    if (i < 5)
                        *key = mouse_vk[i];
                    set = true;
                    break;
                }
            }
            if (!set)
            {
                for (int vk = VK_BACK; vk <= VK_RMENU; vk++)
                {
                    if (vk == VK_ESCAPE)
                        continue;
                    if (GetAsyncKeyState(vk) & 1)
                    {
                        *key = vk;
                        set = true;
                        break;
                    }
                }
            }
            if (!set && (GetAsyncKeyState(VK_ESCAPE) & 0x8000))
            {
                *key = 0;
                set = true;
            }
            if (set)
            {
                g_keybind_capture = 0;
                s_wait_up = false;
            }
        }
    }

    char display[32];
    if (is_active)
        snprintf(display, sizeof(display), "<...>");
    else
        snprintf(display, sizeof(display), "<%s>", KeyName(*key));

    ImVec2 label_size = has_label ? ImGui::CalcTextSize(label, NULL, true) : ImVec2(0, 0);
    ImVec2 bind_size = ImGui::CalcTextSize(display, NULL, true);
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;
    float row_w = ItemW();
    float row_h = ImMax(label_size.y, bind_size.y);
    ImVec2 bind_pos(IM_TRUNC(pos.x + row_w - bind_size.x - 1.0f), IM_TRUNC(pos.y));
    ImRect total_bb = has_label ? ImRect(pos, ImVec2(pos.x + row_w, pos.y + row_h)) : ImRect(bind_pos, ImVec2(bind_pos.x + bind_size.x, bind_pos.y + bind_size.y));
    ImGui::ItemSize(total_bb, g.Style.FramePadding.y);
    if (!ImGui::ItemAdd(total_bb, id))
        return false;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(total_bb, id, &hovered, &held);
    if (pressed && !is_active)
    {
        g_keybind_capture = id;
        s_wait_up = false;
    }

    ImDrawList* draw = window->DrawList;
    if (has_label)
        DrawOutlinedText(draw, ImVec2(pos.x, pos.y), Tc(g_theme->text), label);
    DrawOutlinedText(draw, bind_pos, (hovered || is_active) ? Tc(g_theme->text) : Tc(g_theme->text_dim), display);

    char popup_id[64];
    snprintf(popup_id, sizeof(popup_id), "%s##kb", label);
    ImGui::OpenPopupOnItemClick(popup_id, ImGuiPopupFlags_MouseButtonRight);

    static const char* mode_names[] = { "Toggle", "Hold", "Always" };
    int cur_mode = ImClamp(*mode, 0, 2);
    char prefix[80];
    snprintf(prefix, sizeof(prefix), "[%s]  %s  /  ", KeyName(*key), list_name);
    const char* mode_txt = mode_names[cur_mode];

    ImVec2 prefix_sz = ImGui::CalcTextSize(prefix);
    ImGui::PushFont(g_fontTitle, 13.0f);
    ImVec2 mode_sz = ImGui::CalcTextSize(mode_txt);
    ImGui::PopFont();
    float body_w = prefix_sz.x + mode_sz.x + 16.0f;
    float body_h = ImMax(prefix_sz.y, mode_sz.y) + 14.0f;

    ImGui::SetNextWindowPos(ImVec2(bind_pos.x, total_bb.Max.y + 4.0f), ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ImVec2(body_w, body_h));
    ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 0.0f);
    if (ImGui::BeginPopup(popup_id))
    {
        ImDrawList* pd = ImGui::GetWindowDrawList();
        ImVec2 bp = ImGui::GetWindowPos();
        pd->AddRectFilled(bp, ImVec2(bp.x + body_w, bp.y + body_h), Tc(g_theme->win));
        pd->AddRect(bp, ImVec2(bp.x + body_w, bp.y + body_h), FadeCol(0, 0, 0));
        pd->AddRect(ImVec2(bp.x + 1, bp.y + 1), ImVec2(bp.x + body_w - 1, bp.y + body_h - 1), Tc(g_theme->border));

        ImVec2 text_pos(bp.x + 8.0f, bp.y + 7.0f);
        ImVec2 mode_pos(text_pos.x + prefix_sz.x, text_pos.y);
        ImGui::SetCursorScreenPos(mode_pos);
        ImGui::InvisibleButton("##kbmode", mode_sz);
        if (ImGui::IsItemClicked())
            *mode = (*mode + 1) % 3;
        DrawOutlinedText(pd, text_pos, Tc(g_theme->text_dim), prefix);
        ImGui::PushFont(g_fontTitle, 13.0f);
        DrawOutlinedText(pd, mode_pos, ImGui::IsItemHovered() ? Tc(g_theme->accent_hi) : Tc(g_theme->accent), mode_txt);
        ImGui::PopFont();
        ImGui::EndPopup();
    }
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor();
    return false;
}

inline bool ListBox(const char* label, int* current_item, const char* const items[], int items_count, float height = 140.0f)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(label);
    ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
    float spacing = 4.0f;
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;
    float w = ItemW();
    ImRect bb(pos, ImVec2(pos.x + ImMax(Px(label_size.x), w), pos.y + Px(label_size.y) + spacing + Px(height)));
    ImGui::ItemSize(bb, g.Style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id))
        return false;

    ImRect box(ImVec2(pos.x, pos.y + Px(label_size.y) + spacing), ImVec2(pos.x + w, pos.y + Px(label_size.y) + spacing + Px(height)));
    ImDrawList* draw = window->DrawList;
    draw->AddRectFilled(box.Min, box.Max, Tc(g_theme->win));
    draw->AddRect(box.Min, box.Max, FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(box.Min.x + 1, box.Min.y + 1), ImVec2(box.Max.x - 1, box.Max.y - 1), Tc(g_theme->border));
    DrawOutlinedText(draw, ImVec2(pos.x, pos.y), Tc(g_theme->text), label);

    bool changed = false;
    ImGui::SetCursorScreenPos(ImVec2(box.Min.x + 4.0f, box.Min.y + 4.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
    ImGui::PushID(id);
    ImGui::BeginChild("list", ImVec2(w - 8.0f, height - 8.0f), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar);
    float item_h = 16.0f;
    for (int i = 0; i < items_count; i++)
    {
        ImGui::PushID(i);
        ImVec2 ip = ImGui::GetCursorScreenPos();
        ImGui::InvisibleButton(items[i], ImVec2(ImGui::GetContentRegionAvail().x, item_h));
        if (ImGui::IsItemClicked())
        {
            *current_item = i;
            changed = true;
        }
        ImColor col = (*current_item == i) ? Tc(g_theme->accent) : Tc(g_theme->text_dim);
        if (ImGui::IsItemHovered() && *current_item != i)
            col = Tc(g_theme->text);
        ImVec2 ts = ImGui::CalcTextSize(items[i]);
        DrawOutlinedText(ImGui::GetWindowDrawList(), Px(ImVec2(ip.x + 2.0f, ip.y + (item_h - ts.y) * 0.5f)), col, items[i]);
        ImGui::PopID();
    }
    ImGui::EndChild();
    ImGui::PopID();
    ImGui::PopStyleVar(2);
    ImGui::SetCursorScreenPos(ImVec2(pos.x, bb.Max.y));
    return changed;
}

inline bool InputText(const char* label, char* buf, int buf_size, float width = 0.0f)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiID id = window->GetID(label);
    ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
    float spacing = 4.0f;
    float h = 20.0f;
    ImVec2 pos = Px(window->DC.CursorPos);
    window->DC.CursorPos = pos;
    float w = width > 0.0f ? Px(width) : ItemW();
    ImRect bb(pos, ImVec2(pos.x + ImMax(Px(label_size.x), w), pos.y + Px(label_size.y) + spacing + h));
    ImGui::ItemSize(bb, g.Style.FramePadding.y);
    ImVec2 after = window->DC.CursorPos;

    ImRect box(ImVec2(pos.x, pos.y + Px(label_size.y) + spacing), ImVec2(pos.x + w, pos.y + Px(label_size.y) + spacing + h));
    float* anim = window->StateStorage.GetFloatRef(id, 0.0f);

    ImColor bg_top = LerpRgb(g_theme->frame, Lift(g_theme->frame, 8), *anim);
    ImColor bg_bot = LerpRgb(g_theme->frame_bot, Lift(g_theme->frame_bot, 7), *anim);

    ImDrawList* draw = window->DrawList;
    draw->AddRectFilledMultiColor(box.Min, box.Max, bg_top, bg_top, bg_bot, bg_bot);
    draw->AddRect(box.Min, box.Max, FadeCol(0, 0, 0));
    draw->AddRect(ImVec2(box.Min.x + 1, box.Min.y + 1), ImVec2(box.Max.x - 1, box.Max.y - 1), Tc(g_theme->border));

    ImColor text_col = LerpRgb(Lift(g_theme->text_dim, -40), g_theme->text, *anim);
    DrawOutlinedText(draw, ImVec2(pos.x, pos.y), text_col, label);

    ImGui::SetCursorScreenPos(ImVec2(box.Min.x + 6.0f, box.Min.y + 2.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 0));
    ImGui::PushID(id);
    bool changed = ImGui::InputTextEx("##in", NULL, buf, buf_size, ImVec2(w - 12.0f, h - 4.0f), 0);
    *anim = ImLerp(*anim, (ImGui::IsItemHovered() || ImGui::IsItemActive()) ? 1.0f : 0.0f, 15.0f * g.IO.DeltaTime);
    ImGui::PopID();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);
    window->DC.CursorPos = after;
    return changed;
}

}
