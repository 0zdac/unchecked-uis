#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include "ytview.h"
#include <windows.h>
#include <winhttp.h>
#include <wincrypt.h>
#include <wincodec.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <wrl.h>
#include <WebView2.h>
#include <WebView2EnvironmentOptions.h>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "version.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "windowscodecs.lib")

using Microsoft::WRL::Callback;
using Microsoft::WRL::ComPtr;

enum { HOST_W = 854, HOST_H = 480 };

static HWND g_host;
static ComPtr<ICoreWebView2Controller> g_ctrl;
static ComPtr<ICoreWebView2> g_web;
static ComPtr<IWICImagingFactory> g_wic;
static volatile long g_busy;
static volatile long g_has;
static char g_nav_id[16];
static volatile long g_nav;
static char g_qtitle[256];
static char g_qartist[256];
static HANDLE g_th;
static EventRegistrationToken g_msg_tok;
static EventRegistrationToken g_nav_tok;
static bool g_paused = true;
static bool g_want_play = true;
static DWORD g_kick;
static bool g_muted = true;
static double g_pos;
static double g_dur;
static float g_vol = 1.0f;
static float g_want_vol = 1.0f;
static unsigned char* g_frame;
static int g_fw;
static int g_fh;
static unsigned g_fgen;
static BYTE* g_b64;
static DWORD g_b64_cap;

static bool IsIdChar(char c)
{
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '_';
}

static bool PickId(const char* html, char* out, int cap)
{
    const char* p = html;
    while ((p = strstr(p, "\"videoId\":\"")) != nullptr)
    {
        p += 11;
        int n = 0;
        char id[16];
        while (n < 11 && IsIdChar(p[n]))
        {
            id[n] = p[n];
            n++;
        }
        if (n == 11 && p[11] == '"')
        {
            id[11] = 0;
            strncpy_s(out, cap, id, _TRUNCATE);
            return true;
        }
        p += n ? n : 1;
    }
    return false;
}

static void UrlEnc(wchar_t* d, int cap, const char* s)
{
    int n = 0;
    for (; *s && n + 4 < cap; s++)
    {
        unsigned char c = (unsigned char)*s;
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~')
            d[n++] = (wchar_t)c;
        else if (c == ' ')
            d[n++] = L'+';
        else
        {
            wchar_t tmp[8];
            swprintf_s(tmp, L"%%%02X", c);
            d[n++] = tmp[0];
            d[n++] = tmp[1];
            d[n++] = tmp[2];
        }
    }
    d[n] = 0;
}

static char* HttpGet(const wchar_t* host, const wchar_t* path)
{
    HINTERNET ses = WinHttpOpen(L"Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/122.0.0.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses)
        return nullptr;
    HINTERNET con = WinHttpConnect(ses, host, INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!con)
    {
        WinHttpCloseHandle(ses);
        return nullptr;
    }
    HINTERNET req = WinHttpOpenRequest(con, L"GET", path, nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
    if (!req)
    {
        WinHttpCloseHandle(con);
        WinHttpCloseHandle(ses);
        return nullptr;
    }
    const wchar_t* hdr = L"Accept-Language: en-US,en;q=0.9\r\n";
    BOOL ok = WinHttpSendRequest(req, hdr, (DWORD)wcslen(hdr), WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
    if (ok)
        ok = WinHttpReceiveResponse(req, nullptr);
    char* body = ok ? (char*)malloc(1 << 20) : nullptr;
    int used = 0;
    if (body)
    {
        for (;;)
        {
            DWORD got = 0;
            if (!WinHttpReadData(req, body + used, (1 << 20) - 1 - used, &got) || got == 0)
                break;
            used += (int)got;
            if (used >= (1 << 20) - 1)
                break;
        }
        body[used] = 0;
    }
    WinHttpCloseHandle(req);
    WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    return body;
}

static bool FindId(const char* title, const char* artist, char* out, int cap)
{
    out[0] = 0;
    char q[512];
    snprintf(q, sizeof(q), "%s %s", title, artist);
    wchar_t eq[800];
    UrlEnc(eq, 800, q);
    wchar_t path[900];
    swprintf_s(path, L"/results?search_query=%s", eq);
    char* body = HttpGet(L"www.youtube.com", path);
    bool ok = body && PickId(body, out, cap);
    free(body);
    if (ok)
        return true;
    swprintf_s(path, L"/api/v1/search?q=%s&type=video", eq);
    body = HttpGet(L"inv.nadeko.net", path);
    ok = body && PickId(body, out, cap);
    free(body);
    return ok;
}

static const wchar_t* kInject = LR"js(
(function(){
if(window.__hk)return;
window.__hk=1;
if(window.__go===undefined)window.__go=1;
if(window.__mute===undefined)window.__mute=1;
try{
  Object.defineProperty(document,'hidden',{configurable:true,get:function(){return false}});
  Object.defineProperty(document,'visibilityState',{configurable:true,get:function(){return 'visible'}});
  Object.defineProperty(document,'webkitHidden',{configurable:true,get:function(){return false}});
}catch(e){}
function stop(e){e.stopImmediatePropagation();}
document.addEventListener('visibilitychange',stop,true);
document.addEventListener('webkitvisibilitychange',stop,true);
window.addEventListener('pagehide',stop,true);
window.addEventListener('blur',stop,true);
var c=document.createElement('canvas'),x=c.getContext('2d'),tok=0,pending=false,last=0,hooked=null;
function vid(){return document.querySelector('video.html5-main-video')||document.querySelector('video');}
function go(v){
  if(!v)return;
  v.muted=!!window.__mute;
  if(!window.__go)return;
  if(v.ended)return;
  v.autoplay=true;
  if(v.paused){var p=v.play();if(p)p.catch(function(){});}
}
function bind(v){
  if(!v||v===hooked)return;
  hooked=v;
  v.autoplay=true;
  v.muted=!!window.__mute;
  v.addEventListener('pause',function(){if(window.__go)setTimeout(function(){go(v)},30);});
}
function tick(t){
  if(t!==tok)return;
  var v=vid();
  bind(v);
  go(v);
  if(v&&v.videoWidth&&window.chrome&&window.chrome.webview){
    var w=Math.min(v.videoWidth,854),h=Math.round(v.videoHeight*w/v.videoWidth);
    if(c.width!=w||c.height!=h){c.width=w;c.height=h;}
    try{x.drawImage(v,0,0,w,h);window.chrome.webview.postMessage('f '+c.toDataURL('image/jpeg',0.72));}catch(e){}
    last=performance.now();
  }
  if(v){pending=true;if(v.requestVideoFrameCallback)v.requestVideoFrameCallback(function(){tick(t)});}
  else pending=false;
}
setInterval(function(){
  if(!pending||performance.now()-last>800){tok++;tick(tok);}
  var v=vid();
  bind(v);
  go(v);
  if(!v||!window.chrome||!window.chrome.webview)return;
  window.chrome.webview.postMessage('s '+(v.paused?1:0)+' '+v.currentTime+' '+(isFinite(v.duration)?v.duration:0)+' '+v.volume+' '+(v.muted?1:0));
},250);
})()
)js";

static void Frame(const wchar_t* b64)
{
    DWORD n = 0;
    if (!CryptStringToBinaryW(b64, 0, CRYPT_STRING_BASE64, nullptr, &n, nullptr, nullptr) || !n)
        return;
    if (n > g_b64_cap)
    {
        free(g_b64);
        g_b64 = (BYTE*)malloc(n);
        g_b64_cap = g_b64 ? n : 0;
        if (!g_b64)
            return;
    }
    if (!CryptStringToBinaryW(b64, 0, CRYPT_STRING_BASE64, g_b64, &n, nullptr, nullptr))
        return;
    if (!g_wic && FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&g_wic))))
        return;
    ComPtr<IWICStream> st;
    ComPtr<IWICBitmapDecoder> dec;
    ComPtr<IWICBitmapFrameDecode> fr;
    ComPtr<IWICFormatConverter> cv;
    if (FAILED(g_wic->CreateStream(&st)) || FAILED(st->InitializeFromMemory(g_b64, n)))
        return;
    if (FAILED(g_wic->CreateDecoderFromStream(st.Get(), nullptr, WICDecodeMetadataCacheOnDemand, &dec)) || FAILED(dec->GetFrame(0, &fr)))
        return;
    if (FAILED(g_wic->CreateFormatConverter(&cv)) || FAILED(cv->Initialize(fr.Get(), GUID_WICPixelFormat32bppBGRA, WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom)))
        return;
    UINT w = 0, h = 0;
    cv->GetSize(&w, &h);
    if (!w || !h || w > 2048 || h > 2048)
        return;
    if ((int)w != g_fw || (int)h != g_fh || !g_frame)
    {
        free(g_frame);
        g_frame = (unsigned char*)malloc((size_t)w * h * 4);
        if (!g_frame)
        {
            g_fw = g_fh = 0;
            return;
        }
        g_fw = (int)w;
        g_fh = (int)h;
    }
    if (SUCCEEDED(cv->CopyPixels(nullptr, w * 4, w * h * 4, g_frame)))
        g_fgen++;
}

static void KickPlay()
{
    if (!g_want_play || !g_web)
        return;
    g_web->ExecuteScript(
        L"(function(){window.__go=1;var v=document.querySelector('video.html5-main-video')||document.querySelector('video');if(!v||v.ended)return;v.autoplay=true;if(v.paused){var p=v.play();if(p)p.catch(function(){})}})()",
        nullptr);
}

static void NavId(const char* id)
{
    if (!g_web || !id[0])
        return;
    g_want_play = true;
    g_paused = true;
    wchar_t url[256];
    swprintf_s(url, L"https://www.youtube.com/watch?v=%S&autoplay=1", id);
    g_web->Navigate(url);
    InterlockedExchange(&g_has, 1);
}

static void HookState()
{
    g_web->AddScriptToExecuteOnDocumentCreated(kInject,
        Callback<ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler>(
            [](HRESULT, LPCWSTR) -> HRESULT
            {
                if (g_nav_id[0])
                    NavId(g_nav_id);
                return S_OK;
            }).Get());
    g_web->add_WebMessageReceived(
        Callback<ICoreWebView2WebMessageReceivedEventHandler>(
            [](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* args) -> HRESULT
            {
                LPWSTR msg = nullptr;
                if (FAILED(args->TryGetWebMessageAsString(&msg)) || !msg)
                    return S_OK;
                if (msg[0] == L'f')
                {
                    const wchar_t* c = wcschr(msg, L',');
                    if (c)
                        Frame(c + 1);
                }
                else
                {
                    int paused = 1, muted = 0;
                    double pos = 0.0, dur = 0.0;
                    float vol = 1.0f;
                    if (swscanf_s(msg, L"s %d %lf %lf %f %d", &paused, &pos, &dur, &vol, &muted) == 5)
                    {
                        g_paused = g_want_play ? paused != 0 : true;
                        g_pos = pos;
                        g_dur = dur;
                        g_vol = vol;
                        g_muted = muted != 0;
                    }
                }
                CoTaskMemFree(msg);
                return S_OK;
            }).Get(),
        &g_msg_tok);
    g_web->add_NavigationCompleted(
        Callback<ICoreWebView2NavigationCompletedEventHandler>(
            [](ICoreWebView2*, ICoreWebView2NavigationCompletedEventArgs*) -> HRESULT
            {
                g_web->ExecuteScript(kInject, nullptr);
                Yt_SetVolume(g_want_vol);
                KickPlay();
                return S_OK;
            }).Get(),
        &g_nav_tok);
}

static DWORD WINAPI FindTh(void*)
{
    char id[16] = {};
    FindId(g_qtitle, g_qartist, id, 16);
    if (id[0])
    {
        strncpy_s(g_nav_id, id, _TRUNCATE);
        InterlockedExchange(&g_nav, 1);
    }
    InterlockedExchange(&g_busy, 0);
    return 0;
}

static void MakeEnv()
{
    wchar_t ud[MAX_PATH];
    GetTempPathW(MAX_PATH, ud);
    wcscat_s(ud, L"hriskido-wv2");
    CreateDirectoryW(ud, nullptr);
    auto opts = Microsoft::WRL::Make<CoreWebView2EnvironmentOptions>();
    opts->put_AdditionalBrowserArguments(
        L"--autoplay-policy=no-user-gesture-required "
        L"--disable-background-timer-throttling "
        L"--disable-backgrounding-occluded-windows "
        L"--disable-renderer-backgrounding "
        L"--disable-features=CalculateNativeWinOcclusion");
    CreateCoreWebView2EnvironmentWithOptions(nullptr, ud, opts.Get(),
        Callback<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler>(
            [](HRESULT hr, ICoreWebView2Environment* env) -> HRESULT
            {
                if (FAILED(hr) || !env)
                    return S_OK;
                env->CreateCoreWebView2Controller(g_host,
                    Callback<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler>(
                        [](HRESULT hr2, ICoreWebView2Controller* ctrl) -> HRESULT
                        {
                            if (FAILED(hr2) || !ctrl)
                                return S_OK;
                            g_ctrl = ctrl;
                            ctrl->get_CoreWebView2(&g_web);
                            if (!g_web)
                                return S_OK;
                            RECT r{ 0, 0, HOST_W, HOST_H };
                            ctrl->put_Bounds(r);
                            ctrl->put_IsVisible(TRUE);
                            ctrl->put_ZoomFactor(1.0);
                            ComPtr<ICoreWebView2Settings> set;
                            if (SUCCEEDED(g_web->get_Settings(&set)) && set)
                            {
                                set->put_IsStatusBarEnabled(FALSE);
                                set->put_AreDefaultContextMenusEnabled(FALSE);
                            }
                            HookState();
                            return S_OK;
                        }).Get());
                return S_OK;
            }).Get());
}

void Yt_Init(HWND parent)
{
    g_host = CreateWindowExW(0, L"Static", L"", WS_CHILD | WS_VISIBLE, -HOST_W - 100, 0, HOST_W, HOST_H, parent, nullptr, GetModuleHandleW(nullptr), nullptr);
    MakeEnv();
}

void Yt_Shutdown()
{
    if (g_th)
    {
        WaitForSingleObject(g_th, 2000);
        CloseHandle(g_th);
        g_th = nullptr;
    }
    g_web.Reset();
    g_ctrl.Reset();
    g_wic.Reset();
    if (g_host)
    {
        DestroyWindow(g_host);
        g_host = nullptr;
    }
    free(g_frame);
    g_frame = nullptr;
    free(g_b64);
    g_b64 = nullptr;
}

void Yt_Open(const char* title, const char* artist)
{
    strncpy_s(g_qtitle, title, _TRUNCATE);
    strncpy_s(g_qartist, artist, _TRUNCATE);
    g_nav_id[0] = 0;
    g_want_play = true;
    g_paused = true;
    InterlockedExchange(&g_has, 0);
    InterlockedExchange(&g_nav, 0);
    InterlockedExchange(&g_busy, 1);
    if (g_th)
    {
        WaitForSingleObject(g_th, 2000);
        CloseHandle(g_th);
        g_th = nullptr;
    }
    g_th = CreateThread(nullptr, 0, FindTh, nullptr, 0, nullptr);
}

void Yt_Close()
{
    InterlockedExchange(&g_has, 0);
    g_nav_id[0] = 0;
    g_want_play = false;
    if (g_web)
        g_web->Navigate(L"about:blank");
    g_paused = true;
    g_pos = 0.0;
    g_dur = 0.0;
    free(g_frame);
    g_frame = nullptr;
    g_fw = g_fh = 0;
    g_fgen++;
}

void Yt_Tick()
{
    if (InterlockedExchange(&g_nav, 0) && g_nav_id[0])
        NavId(g_nav_id);
    DWORD now = GetTickCount();
    if (g_want_play && g_paused && InterlockedCompareExchange(&g_has, 0, 0) && now - g_kick > 400)
    {
        g_kick = now;
        KickPlay();
    }
}

bool Yt_Busy()
{
    return InterlockedCompareExchange(&g_busy, 0, 0) != 0;
}

bool Yt_HasVideo()
{
    return InterlockedCompareExchange(&g_has, 0, 0) != 0;
}

static void Js(const wchar_t* code)
{
    if (g_web)
        g_web->ExecuteScript(code, nullptr);
}

YtState Yt_State()
{
    YtState s;
    s.playing = !g_paused;
    s.muted = g_muted;
    s.pos = g_pos;
    s.dur = g_dur;
    s.vol = g_vol;
    return s;
}

void Yt_TogglePlay()
{
    Yt_SetPlay(!g_want_play);
}

void Yt_SetPlay(bool on)
{
    if (on == g_want_play)
        return;
    g_want_play = on;
    g_paused = !on;
    if (on)
        KickPlay();
    else
        Js(L"(function(){window.__go=0;var v=document.querySelector('video');if(v)v.pause()})()");
}

void Yt_Seek(double sec)
{
    wchar_t js[200];
    swprintf_s(js, L"(function(){var v=document.querySelector('video');if(v)v.currentTime=%.3f;})()", sec);
    Js(js);
    g_pos = sec;
}

void Yt_SetVolume(float v)
{
    if (v < 0.0f)
        v = 0.0f;
    if (v > 1.0f)
        v = 1.0f;
    g_want_vol = v;
    g_vol = v;
    wchar_t js[220];
    swprintf_s(js, L"(function(){var e=document.querySelector('video');if(e)e.volume=%.3f;})()", v);
    Js(js);
}

void Yt_SetMuted(bool on)
{
    g_muted = on;
    Js(on
        ? L"(function(){window.__mute=1;var v=document.querySelector('video');if(v)v.muted=true})()"
        : L"(function(){window.__mute=0;var v=document.querySelector('video');if(v)v.muted=false})()");
}

void Yt_ToggleMute()
{
    Yt_SetMuted(!g_muted);
}

void Yt_FrameInfo(unsigned* gen, int* w, int* h)
{
    *gen = g_fgen;
    *w = g_fw;
    *h = g_fh;
}

void Yt_FrameCopy(unsigned char* dst, int pitch)
{
    if (!g_frame)
        return;
    for (int y = 0; y < g_fh; y++)
        memcpy(dst + (size_t)y * pitch, g_frame + (size_t)y * g_fw * 4, (size_t)g_fw * 4);
}
