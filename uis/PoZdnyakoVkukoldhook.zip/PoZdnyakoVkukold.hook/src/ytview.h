#pragma once
#include <windows.h>

struct YtState
{
    bool playing;
    bool muted;
    double pos;
    double dur;
    float vol;
};

void Yt_Init(HWND parent);
void Yt_Shutdown();
void Yt_Open(const char* title, const char* artist);
void Yt_Close();
void Yt_Tick();
bool Yt_Busy();
bool Yt_HasVideo();
YtState Yt_State();
void Yt_TogglePlay();
void Yt_SetPlay(bool on);
void Yt_Seek(double sec);
void Yt_SetVolume(float v);
void Yt_SetMuted(bool on);
void Yt_ToggleMute();
void Yt_FrameInfo(unsigned* gen, int* w, int* h);
void Yt_FrameCopy(unsigned char* dst, int pitch);
