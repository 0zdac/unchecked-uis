#pragma once

#include <cstddef>

namespace ui::assets
{
    extern const unsigned char picture_detail_bytes[];
    extern const std::size_t picture_detail_bytes_size;
    extern const unsigned char picture_detail_2_bytes[];
    extern const std::size_t picture_detail_2_bytes_size;
    extern const unsigned char picture_detail_3_bytes[];
    extern const std::size_t picture_detail_3_bytes_size;
    extern const unsigned char picture_detail_4_bytes[];
    extern const std::size_t picture_detail_4_bytes_size;
    extern const unsigned char picture_detail_5_bytes[];
    extern const std::size_t picture_detail_5_bytes_size;
}
