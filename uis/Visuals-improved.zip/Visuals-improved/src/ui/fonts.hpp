#pragma once

#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif

#include <imgui.h>

namespace ui
{
    struct text_glyph
    {
        unsigned int codepoint;
        float x;
        float baseline;
    };

    bool load_fonts( );
    void reset_fonts( );
    bool fonts_ready( );

    void draw_glyph_run( ImDrawList* draw, int slot, ImVec2 origin, ImU32 color, const text_glyph* glyphs, int count );

    template < int count >
    void draw_glyph_run( ImDrawList* draw, int slot, ImVec2 origin, ImU32 color, const text_glyph ( &glyphs )[count] )
    {
        draw_glyph_run( draw, slot, origin, color, glyphs, count );
    }

    struct glyph_text
    {
        const text_glyph* glyphs;
        int count;

        template < int length >
        constexpr glyph_text( const text_glyph ( &table )[length] ) : glyphs( table ), count( length ) { }
    };

    inline void draw_glyph_run( ImDrawList* draw, int slot, ImVec2 origin, ImU32 color, glyph_text text )
    {
        draw_glyph_run( draw, slot, origin, color, text.glyphs, text.count );
    }

    void draw_text_box( ImDrawList* draw, int slot, ImVec2 min, ImVec2 max, int horizontal, int vertical, ImU32 color, const char* text );
    void draw_text_line( ImDrawList* draw, int slot, ImVec2 anchor, int align, ImU32 color, const char* text );
    void draw_icon_glyph( ImDrawList* draw, ImVec2 position, ImU32 color, const char* glyph );

    ImFont* slot_font( int slot );
    float slot_font_size( int slot );
    float slot_font_ascent( int slot );

    namespace text_fonts
    {
        inline constexpr int inter_500_10_5 = 0;
        inline constexpr int roboto_400_13 = 1;
        inline constexpr int roboto_400_14 = 2;
        inline constexpr int open_sans_400_12_5 = 3;
        inline constexpr int open_sans_400_13 = 4;
        inline constexpr int open_sans_400_13_5 = 5;
        inline constexpr int open_sans_500_12_5 = 6;
        inline constexpr int work_sans_400_13_5 = 7;
        inline constexpr int work_sans_400_14 = 8;
        inline constexpr int dm_sans_9pt_400_14 = 9;
    }

    namespace icons
    {
        extern const char triangle_down_glyph[];
    }
}
