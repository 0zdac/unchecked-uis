#pragma once

#include <imgui.h>

namespace ui::theme
{
    inline constexpr float frame_width = 762.f;
    inline constexpr float frame_height = 762.f;

    inline constexpr ImU32 background = IM_COL32( 17, 17, 17, 255 );
    inline constexpr ImU32 surface = IM_COL32( 127, 79, 124, 255 );
    inline constexpr ImU32 surface_2 = IM_COL32( 69, 48, 68, 255 );
    inline constexpr ImU32 surface_3 = IM_COL32( 24, 24, 24, 255 );
    inline constexpr ImU32 border = IM_COL32( 0, 0, 0, 255 );
    inline constexpr ImU32 text = IM_COL32( 201, 201, 201, 255 );
    inline constexpr ImU32 text_muted = IM_COL32( 198, 198, 198, 255 );
    inline constexpr ImU32 text_subtle = IM_COL32( 172, 172, 172, 255 );
    inline constexpr ImU32 text_faint = IM_COL32( 158, 119, 155, 255 );
    inline constexpr ImU32 text_5 = IM_COL32( 99, 99, 99, 255 );
    inline constexpr ImU32 icon = IM_COL32( 220, 220, 220, 255 );
    inline constexpr ImU32 accent = IM_COL32( 230, 143, 224, 255 );
    inline constexpr ImU32 gray_dark = IM_COL32( 50, 50, 50, 255 );
    inline constexpr ImU32 fill_pink = IM_COL32( 255, 158, 248, 255 );
    inline constexpr ImU32 fill_pink_2 = IM_COL32( 255, 163, 248, 255 );
}
