#include "lazyui/lazyui.hpp"

#include "ui.hpp"
#include "assets.hpp"
#include "text.hpp"
#include "theme.hpp"
#include "lazyui/runtime.hpp"

#include <array>
#include <cstddef>
#include <iterator>

namespace ui
{
    namespace controls
    {
        using namespace lazyui;

        switch_state lebron_made_this_widget{ true, 1.f, 0.f };
        switch_state vex{ false, 0.f, 0.f };
        const char* const lebron_teammates_options[] = { "Depth" };
        combo_state lebron_teammates{ };
        color_state lebron_made_this_widget_picker{ ImVec4{ 1.f, 0.6196f, 0.9725f, 1.f } };
        selection_state< 4 > nav_main{ 1, 0.f, 40.2909f };
        const ImVec4 nav_main_slots[4] = {
            ImVec4{ 83.19f, 48.23f, 47.8744f, 17.7036f },
            ImVec4{ 269.39f, 48.23f, 40.2909f, 17.7036f },
            ImVec4{ 459.14f, 48.23f, 26.8902f, 17.7036f },
            ImVec4{ 631.06f, 48.23f, 48.2041f, 17.7036f }
        };
        field_state lebron_height_field{ };
    }

    namespace
    {
        using namespace lazyui;
        using namespace controls;

        constexpr ImGuiWindowFlags window_flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoBackground;

        struct embedded_image
        {
            const unsigned char* data;
            std::size_t size;
        };

        const embedded_image image_sources[] = {
            { assets::picture_detail_bytes, assets::picture_detail_bytes_size },
            { assets::picture_detail_2_bytes, assets::picture_detail_2_bytes_size },
            { assets::picture_detail_3_bytes, assets::picture_detail_3_bytes_size },
            { assets::picture_detail_4_bytes, assets::picture_detail_4_bytes_size },
            { assets::picture_detail_5_bytes, assets::picture_detail_5_bytes_size }
        };

        std::array< c_image, std::size( image_sources ) > images;

        c_blureffect framework_blur_effect;

        void load_images( )
        {
            for ( std::size_t index = 0; index < images.size( ); ++index )
                if ( !images[index].ready( ) )
                    ( void )images[index].load( lazyui::app.device, image_sources[index].data, image_sources[index].size );
        }

        bool ensure_framework_blur( )
        {
            if ( framework_blur_effect.ready( ) && framework_blur_effect.matches_display( ImGui::GetIO( ).DisplaySize ) )
                return true;
            return framework_blur_effect.setup( lazyui::app.device, lazyui::app.device_context, lazyui::app.swap_chain );
        }

        const motion_settings design_motion = {
            {
                { 0.389f, curve_spring },
                { 0.23f, curve_smooth },
                { 0.154f, curve_smooth },
                { 0.346f, curve_spring },
                { 0.444f, curve_spring },
                { 0.518f, curve_spring },
                { 0.444f, curve_spring }
            },
            transition_scale, 14.f, 18.f, intro_scale, 0.52f
        };

        const char shader_source_0[] = R"lazyui_hlsl(
        cbuffer lazyui_shader_parameters : register( b0 )
        {
            float2 uResolution; float uTime; float uSpeed;
            float3 uColor1; float uScale;
            float3 uColor2; float uIntensity;
            float3 uColor3; float uAmount;
            float2 uMouse; float uDetail; float uAlpha;
        };
        #define vec2 float2
        #define vec3 float3
        #define vec4 float4
        #define mix lerp
        #define fract frac
        float mod( float x, float y ) { return x - y * floor( x / y ); }
        float2 mod( float2 x, float2 y ) { return x - y * floor( x / y ); }
        float2 mod( float2 x, float y ) { return x - y * floor( x / y ); }
        float3 mod( float3 x, float3 y ) { return x - y * floor( x / y ); }
        float3 mod( float3 x, float y ) { return x - y * floor( x / y ); }

        vec2 splat2( float v ) { return vec2( v, v ); }
        vec3 splat3( float v ) { return vec3( v, v, v ); }
        vec4 splat4( float v ) { return vec4( v, v, v, v ); }
        vec2 rot2( vec2 p, float a ) { float c = cos( a ); float s = sin( a ); return vec2( c * p.x - s * p.y, s * p.x + c * p.y ); }
        float hash21( vec2 p ) { p = fract( p * vec2( 123.34, 456.21 ) ); p += dot( p, p + 45.32 ); return fract( p.x * p.y ); }
        vec2 hash22( vec2 p ) { float n = hash21( p ); return vec2( n, hash21( p + n ) ); }
        float noise2( vec2 p ) {
          vec2 i = floor( p );
          vec2 f = fract( p );
          vec2 u = f * f * ( 3.0 - 2.0 * f );
          float a = hash21( i );
          float b = hash21( i + vec2( 1.0, 0.0 ) );
          float c = hash21( i + vec2( 0.0, 1.0 ) );
          float d = hash21( i + vec2( 1.0, 1.0 ) );
          return mix( mix( a, b, u.x ), mix( c, d, u.x ), u.y );
        }
        float fbm( vec2 p ) {
          float value = 0.0;
          float amplitude = 0.5;
          for ( int i = 0; i < 5; i++ ) {
            value += amplitude * noise2( p );
            p = rot2( p, 0.5 ) * 2.03 + vec2( 17.0, 9.0 );
            amplitude *= 0.5;
          }
          return value;
        }
        vec3 palette3( float t ) {
          t = fract( t );
          vec3 a = mix( uColor1, uColor2, smoothstep( 0.0, 0.5, t ) );
          return mix( a, uColor3, smoothstep( 0.5, 1.0, t ) );
        }
        float luma( vec3 c ) { return dot( c, vec3( 0.299, 0.587, 0.114 ) ); }
        vec4 lightOver( vec3 c ) {
          c = max( c, splat3( 0.0 ) );
          float a = clamp( max( max( c.r, c.g ), c.b ), 0.0, 1.0 );
          return vec4( c / max( a, 0.0001 ), a );
        }
        float grain( vec2 fragCoord ) { return hash21( floor( fragCoord ) + fract( uTime * 7.13 ) * 91.7 ) - 0.5; }

        vec4 shade( vec2 fragCoord ) {
          vec2 uv = fragCoord / uResolution;
          float t = uTime * 0.25;
          vec3 light = splat3( 0.0 );
          for ( int i = 0; i < 14; i++ ) {
            float fi = float( i );
            if ( fi >= uAmount )
              break;
            float seed = hash21( vec2( fi, 3.7 ) );
            float x = ( fi + 0.5 ) / uAmount + 0.08 * sin( t * ( 0.6 + seed ) + seed * 6.28 ) + ( uv.y - 0.5 ) * 0.18 * ( seed - 0.5 );
            float width = ( 0.012 + 0.03 * seed ) * uDetail;
            float beam = exp( -pow( ( uv.x - x ) / width, 2.0 ) );
            float flicker = 0.6 + 0.4 * sin( t * 3.0 * ( 0.5 + seed ) + fi );
            light += mix( uColor2, uColor1, seed ) * beam * flicker;
          }
          light *= smoothstep( 0.0, 0.9, uv.y ) * 0.9 * uIntensity;
          return lightOver( light );
        }
        struct PS_INPUT
        {
            float4 pos : SV_POSITION;
            float4 col : COLOR0;
            float2 uv : TEXCOORD0;
        };
        float4 main( PS_INPUT input ) : SV_Target
        {
            float4 color = shade( float2( input.uv.x * uResolution.x, ( 1.0 - input.uv.y ) * uResolution.y ) );
            return float4( saturate( color.rgb ), saturate( color.a ) * uAlpha * input.col.a );
        }
        )lazyui_hlsl";

        std::array< shader_background, 1 > shader_backgrounds{ {
            shader_background{ shader_source_0, { { 0.f, 0.f }, 0.f, 3.f, { 1.f, 0.6196f, 0.9725f }, 1.f, { 0.498f, 0.3098f, 0.4863f }, 1.f, { 0.6039f, 0.8431f, 1.f }, 11.f, { -1.f, -1.f }, 1.f, 1.f }, false }
        } };

        void update_controls( ImVec2 origin )
        {
            begin_pointer_frame( );
            update_selection( nav_main, nav_main_slots, origin, false, 269.39f, 40.2909f );

            if ( nav_main.selected == 1 )
            {
                update_color( lebron_made_this_widget_picker, origin + ImVec2{ 333.f, 110.f }, origin + ImVec2{ 359.f, 126.f } );
                update_switch( lebron_made_this_widget, origin + ImVec2{ 23.f, 108.1514f }, origin + ImVec2{ 198.5029f, 132.1514f } );
                update_switch( vex, origin + ImVec2{ 386.f, 107.7914f }, origin + ImVec2{ 433.1259f, 131.7914f } );
                update_combo( lebron_teammates, origin + ImVec2{ 27.f, 216.f }, origin + ImVec2{ 367.f, 240.f }, static_cast< int >( IM_ARRAYSIZE( lebron_teammates_options ) ) );
            }
        }

        void draw_window_outline( ImDrawList* draw, ImVec2 origin )
        {
            add_rounded_rect_stroke( draw, origin + ImVec2{ 1.5f, 1.5f }, origin + ImVec2{ 760.5f, 760.5f }, corner_radii{ }, theme::fill_pink, 1.f );
        }

        void draw_top_header( ImDrawList* draw, ImVec2 origin )
        {
            add_rounded_rect_filled( draw, origin + ImVec2{ 15.f, 8.f }, origin + ImVec2{ 747.f, 40.f }, corner_radii{ }, theme::background );
            draw_image( draw, 0, origin + ImVec2{ 644.f, 20.f }, origin + ImVec2{ 667.f, 31.f } );
            add_rounded_rect_filled( draw, origin + ImVec2{ 16.f, 9.f }, origin + ImVec2{ 746.f, 10.f }, corner_radii{ }, theme::surface );
            add_rounded_rect_filled( draw, origin + ImVec2{ 198.f, 9.f }, origin + ImVec2{ 199.f, 39.f }, corner_radii{ }, theme::border );
            add_rounded_rect_filled( draw, origin + ImVec2{ 563.f, 9.f }, origin + ImVec2{ 564.f, 39.f }, corner_radii{ }, theme::border );
            draw_glyph_run( draw, text_fonts::inter_500_10_5, origin + ImVec2{ 96.17f, 17.89f }, theme::text_subtle, text::text_2 );
            draw_glyph_run( draw, text_fonts::roboto_400_14, origin + ImVec2{ 347.81f, 15.07f }, theme::text, text::text_04_03_2001 );
            add_rounded_rect_stroke( draw, origin + ImVec2{ 15.5f, 8.5f }, origin + ImVec2{ 746.5f, 39.5f }, corner_radii{ }, theme::border, 1.f );
        }

        void draw_picture_detail( ImDrawList* draw, ImVec2 origin )
        {
            draw_image( draw, 1, origin + ImVec2{ 14.f, 7.f }, origin + ImVec2{ 748.f, 14.f } );
        }

        void draw_top_bar( ImDrawList* draw, ImVec2 origin )
        {
            add_rounded_rect_filled( draw, origin + ImVec2{ 15.f, 43.f }, origin + ImVec2{ 747.f, 74.f }, corner_radii{ 6.f }, theme::background );
            add_rounded_rect_filled( draw, origin + ImVec2{ 198.f, 45.f }, origin + ImVec2{ 199.f, 74.f }, corner_radii{ }, theme::border );
            add_rounded_rect_filled( draw, origin + ImVec2{ 381.f, 45.f }, origin + ImVec2{ 382.f, 74.f }, corner_radii{ }, theme::border );
            add_rounded_rect_filled( draw, origin + ImVec2{ 564.f, 45.f }, origin + ImVec2{ 565.f, 74.f }, corner_radii{ }, theme::border );
            add_rounded_rect_filled( draw, origin + ImVec2{ 83.19f, 48.23f }, origin + ImVec2{ 131.0644f, 65.9336f }, corner_radii{ }, fade( theme::accent, ImMax( nav_main.amount[0], nav_main.hover[0] * 0.4f ) ) );
            draw_glyph_run( draw, text_fonts::open_sans_400_12_5, origin + ImVec2{ 83.19f, 48.57f }, selection_tint( nav_main, 0, theme::text_5, theme::accent, theme::text_faint ), text::combat );
            draw_glyph_run( draw, text_fonts::open_sans_400_13, origin + ImVec2{ 269.39f, 48.23f }, mix_color( theme::text_5, theme::accent, nav_main.amount[1] ), text::visuals );
            add_rounded_rect_filled( draw, origin + ImVec2{ 459.14f, 48.23f }, origin + ImVec2{ 486.0302f, 65.9336f }, corner_radii{ }, fade( theme::accent, ImMax( nav_main.amount[2], nav_main.hover[2] * 0.4f ) ) );
            draw_glyph_run( draw, text_fonts::open_sans_400_13_5, origin + ImVec2{ 459.14f, 47.57f }, selection_tint( nav_main, 2, theme::text_5, theme::accent, theme::text_faint ), text::misc );
            add_rounded_rect_filled( draw, origin + ImVec2{ 631.06f, 48.23f }, origin + ImVec2{ 679.2641f, 65.9336f }, corner_radii{ }, fade( theme::accent, ImMax( nav_main.amount[3], nav_main.hover[3] * 0.4f ) ) );
            draw_glyph_run( draw, text_fonts::open_sans_400_13, origin + ImVec2{ 631.06f, 48.12f }, selection_tint( nav_main, 3, theme::text_5, theme::accent, theme::text_faint ), text::settings );
            add_rounded_rect_stroke( draw, origin + ImVec2{ 15.5f, 43.5f }, origin + ImVec2{ 746.5f, 73.5f }, corner_radii{ 5.5f }, theme::border, 1.f );
        }

        void draw_picture_detail_2( ImDrawList* draw, ImVec2 origin )
        {
            draw_image( draw, 2, origin + ImVec2{ 13.f, 37.f }, origin + ImVec2{ 749.f, 44.f } );
        }

        void draw_example_settings_panel( ImDrawList* draw, ImVec2 origin )
        {
            const float page_alpha = page_fade( nav_main.amount[1], nav_main.selected == 1 );
            const int scale_start_0 = draw->VtxBuffer.Size;
            add_rounded_rect_filled( draw, origin + ImVec2{ 15.f, 81.f }, origin + ImVec2{ 370.f, 745.f }, corner_radii{ }, fade( theme::background, page_alpha ) );
            add_rounded_rect_filled( draw, origin + ImVec2{ 16.f, 81.f }, origin + ImVec2{ 369.f, 82.f }, corner_radii{ }, fade( theme::surface, page_alpha ) );
            draw_glyph_run( draw, text_fonts::open_sans_400_13, origin + ImVec2{ 20.59f, 89.22f }, fade( theme::text_5, page_alpha ), text::example1 );
            add_rounded_rect_filled( draw, origin + ImVec2{ 27.f, 112.f }, origin + ImVec2{ 41.f, 126.f }, corner_radii{ }, fade( mix_color( mix_color( theme::background, theme::fill_pink, lebron_made_this_widget.anim ), theme::surface_2, lebron_made_this_widget.hover * ( 1.f - lebron_made_this_widget.anim ) ), page_alpha ) );
            add_rounded_rect_stroke( draw, origin + ImVec2{ 27.5f, 112.5f }, origin + ImVec2{ 40.5f, 125.5f }, corner_radii{ }, fade( mix_color( theme::border, IM_COL32( 255, 158, 248, 0 ), lebron_made_this_widget.anim ), page_alpha ), 1.f );
            {
                const int first_vertex = draw->VtxBuffer.Size;
                ImGui::RenderCheckMark( draw, origin + ImVec2{ 29.8f, 114.8f }, fade( IM_COL32_WHITE, lebron_made_this_widget.anim ), 8.4f );
                fade_vertices( draw, first_vertex, page_alpha );
            }
            draw_glyph_run( draw, text_fonts::open_sans_500_12_5, origin + ImVec2{ 46.68f, 111.64f }, fade( mix_color( theme::text_5, theme::text_muted, ImMax( lebron_made_this_widget.anim, lebron_made_this_widget.hover * 0.35f ) ), page_alpha ), text::lebron_made_this_widget );
            add_rounded_rect_filled( draw, origin + ImVec2{ 333.f, 110.f }, origin + ImVec2{ 359.f, 126.f }, corner_radii{ }, fade( color_value( lebron_made_this_widget_picker ), page_alpha ) );
            draw_glyph_run( draw, text_fonts::roboto_400_13, origin + ImVec2{ 25.6f, 140.97f }, fade( theme::text_muted, page_alpha ), text::lebron_height );
            add_rounded_rect_filled( draw, origin + ImVec2{ 27.f, 161.f }, origin + ImVec2{ 367.f, 181.f }, corner_radii{ }, fade( theme::surface_3, page_alpha ) );
            add_rounded_rect_filled( draw, origin + ImVec2{ 28.f, 162.f }, origin + ImVec2{ 138.f, 180.f }, corner_radii{ }, fade( mix_color( theme::fill_pink, theme::fill_pink_2, ImMax( lebron_height_field.focus, lebron_height_field.hover * 0.5f ) ), page_alpha ) );
            {
                const int first_vertex = draw->VtxBuffer.Size;
                edit_field( lebron_height_field, "", text_fonts::roboto_400_13, origin + ImVec2{ 34.f, 175.68f }, 98.f, origin + ImVec2{ 28.f, 162.f }, origin + ImVec2{ 138.f, 180.f }, theme::text_muted, false );
                fade_vertices( draw, first_vertex, page_alpha );
            }
            add_rounded_rect_stroke( draw, origin + ImVec2{ 27.5f, 161.5f }, origin + ImVec2{ 366.5f, 180.5f }, corner_radii{ }, fade( theme::border, page_alpha ), 1.f );
            draw_glyph_run( draw, text_fonts::work_sans_400_13_5, origin + ImVec2{ 25.6f, 195.58f }, fade( theme::text_muted, page_alpha ), text::lebron_teammates );
            add_rounded_rect_filled( draw, origin + ImVec2{ 27.f, 216.f }, origin + ImVec2{ 367.f, 240.f }, corner_radii{ }, fade( theme::background, page_alpha ) );
            if ( lebron_teammates.selected == 0 ) draw_glyph_run( draw, text_fonts::work_sans_400_14, origin + ImVec2{ 31.65f, 220.05f }, fade( theme::text_muted, page_alpha ), text::depth );
            {
                const int first_vertex = draw->VtxBuffer.Size;
                if ( lebron_teammates.selected != 0 ) draw_text_line( draw, text_fonts::work_sans_400_14, origin + ImVec2{ 31.65f, 233.07f }, 0, theme::text_muted, lebron_teammates_options[lebron_teammates.selected] );
                fade_vertices( draw, first_vertex, page_alpha );
            }
            {
                const int first_vertex = draw->VtxBuffer.Size;
                draw_icon_glyph( draw, origin + ImVec2{ 350.f, 221.12f }, fade( theme::icon, page_alpha ), icons::triangle_down_glyph );
                rotate_vertices( draw, first_vertex, origin + ImVec2{ 357.f, 228.12f }, lebron_teammates.anim * IM_PI );
            }
            add_rounded_rect_stroke( draw, origin + ImVec2{ 27.5f, 216.5f }, origin + ImVec2{ 366.5f, 239.5f }, corner_radii{ }, fade( theme::border, page_alpha ), 1.f );
            add_rounded_rect_stroke( draw, origin + ImVec2{ 15.5f, 81.5f }, origin + ImVec2{ 369.5f, 744.5f }, corner_radii{ }, fade( theme::border, page_alpha ), 1.f );
            scale_vertices( draw, scale_start_0, origin + ImVec2{ 192.5f, 413.f }, page_scale( nav_main.amount[1], nav_main.selected == 1 ) );
        }

        void draw_picture_detail_3( ImDrawList* draw, ImVec2 origin )
        {
            const int scale_start_1 = draw->VtxBuffer.Size;
            draw_image( draw, 3, origin + ImVec2{ 14.f, 79.f }, origin + ImVec2{ 371.f, 86.f }, fade( IM_COL32_WHITE, page_fade( nav_main.amount[1], nav_main.selected == 1 ) ) );
            scale_vertices( draw, scale_start_1, origin + ImVec2{ 192.5f, 82.5f }, page_scale( nav_main.amount[1], nav_main.selected == 1 ) );
        }

        void draw_james_settings_panel( ImDrawList* draw, ImVec2 origin )
        {
            const float page_alpha = page_fade( nav_main.amount[1], nav_main.selected == 1 );
            const int scale_start_2 = draw->VtxBuffer.Size;
            add_rounded_rect_filled( draw, origin + ImVec2{ 378.f, 81.f }, origin + ImVec2{ 747.f, 745.f }, corner_radii{ }, fade( theme::background, page_alpha ) );
            add_rounded_rect_filled( draw, origin + ImVec2{ 379.f, 81.f }, origin + ImVec2{ 746.f, 82.f }, corner_radii{ }, fade( theme::surface, page_alpha ) );
            draw_glyph_run( draw, text_fonts::dm_sans_9pt_400_14, origin + ImVec2{ 383.78f, 89.34f }, fade( theme::text_5, page_alpha ), text::lebron_james );
            add_rounded_rect_filled( draw, origin + ImVec2{ 390.f, 111.f }, origin + ImVec2{ 406.f, 127.f }, corner_radii{ }, fade( mix_color( mix_color( theme::background, theme::fill_pink, vex.anim ), theme::surface_2, vex.hover * ( 1.f - vex.anim ) ), page_alpha ) );
            add_rounded_rect_stroke( draw, origin + ImVec2{ 390.5f, 111.5f }, origin + ImVec2{ 405.5f, 126.5f }, corner_radii{ }, fade( mix_color( theme::border, theme::fill_pink, vex.anim ), page_alpha ), 1.f );
            {
                const int first_vertex = draw->VtxBuffer.Size;
                ImGui::RenderCheckMark( draw, origin + ImVec2{ 393.2f, 114.2f }, fade( IM_COL32_WHITE, vex.anim ), 9.6f );
                fade_vertices( draw, first_vertex, page_alpha );
            }
            draw_glyph_run( draw, text_fonts::open_sans_400_12_5, origin + ImVec2{ 410.04f, 111.56f }, fade( mix_color( theme::text_5, theme::text_muted, ImMax( vex.anim, vex.hover * 0.35f ) ), page_alpha ), text::vex );
            add_rounded_rect_stroke( draw, origin + ImVec2{ 378.5f, 81.5f }, origin + ImVec2{ 746.5f, 744.5f }, corner_radii{ }, fade( theme::border, page_alpha ), 1.f );
            scale_vertices( draw, scale_start_2, origin + ImVec2{ 562.5f, 413.f }, page_scale( nav_main.amount[1], nav_main.selected == 1 ) );
        }

        void draw_picture_detail_4( ImDrawList* draw, ImVec2 origin )
        {
            const int scale_start_3 = draw->VtxBuffer.Size;
            draw_image( draw, 4, origin + ImVec2{ 377.f, 80.f }, origin + ImVec2{ 748.f, 85.f }, fade( IM_COL32_WHITE, page_fade( nav_main.amount[1], nav_main.selected == 1 ) ) );
            scale_vertices( draw, scale_start_3, origin + ImVec2{ 562.5f, 82.5f }, page_scale( nav_main.amount[1], nav_main.selected == 1 ) );
        }

        void draw_frame( ImDrawList* draw, ImVec2 origin )
        {
            add_rounded_rect_filled( draw, origin, origin + ImVec2{ 762.f, 762.f }, corner_radii{ }, theme::background );
            draw_shader( draw, shader_backgrounds[0], origin, origin + ImVec2{ 762.f, 762.f }, corner_radii{ } );
            draw->PushClipRect( origin, origin + ImVec2{ 762.f, 762.f }, true );
                draw_window_outline( draw, origin );
                draw_top_header( draw, origin );
                draw_picture_detail( draw, origin );
                draw_top_bar( draw, origin );
                draw_picture_detail_2( draw, origin );
                if ( nav_main.amount[1] > 0.001f )
                {
                    draw_example_settings_panel( draw, origin );
                    draw_picture_detail_3( draw, origin );
                    draw_james_settings_panel( draw, origin );
                    draw_picture_detail_4( draw, origin );
                }
            draw->PopClipRect( );
        }

        void draw_overlays( ImVec2 origin )
        {
            if ( nav_main.selected == 1 )
            {
                draw_combo_popup( ImGui::GetForegroundDrawList( ), lebron_teammates, origin + ImVec2{ 27.f, 216.f }, origin + ImVec2{ 367.f, 240.f }, lebron_teammates_options, text_fonts::work_sans_400_14, 4.65f, 17.07f, 0.f, theme::background, theme::border, theme::text_muted, theme::text_muted );
                draw_color_popup( ImGui::GetForegroundDrawList( ), lebron_made_this_widget_picker, origin + ImVec2{ 333.f, 110.f }, origin + ImVec2{ 359.f, 126.f }, theme::background, theme::gray_dark );
            }
        }
    }

    ImVec2 frame_size( )
    {
        return ImVec2{ theme::frame_width, theme::frame_height };
    }

    void render( )
    {
        motion = design_motion;
        load_images( );
        set_graphics( lazyui::app.device, lazyui::app.swap_chain );

        const ImVec2 display = ImGui::GetIO( ).DisplaySize;
        const ImVec2 size = frame_size( );
        const ImVec2 centered = ImFloor( ( display - size ) * 0.5f );
        const ImVec2 position = ImFloor( ImClamp( centered + window_drag.offset, ImMin( centered, ImVec2{ 0.f, 0.f } ), ImMax( ImMax( display - size, ImVec2{ 0.f, 0.f } ), centered ) ) );
        window_drag.offset = position - centered;
        ImGui::SetNextWindowPos( position );
        ImGui::SetNextWindowSize( size );
        ImGui::PushStyleVar( ImGuiStyleVar_WindowPadding, ImVec2{ 0.f, 0.f } );
        ImGui::PushStyleVar( ImGuiStyleVar_WindowBorderSize, 0.f );
        ImGui::PushStyleVar( ImGuiStyleVar_WindowRounding, 0.f );
        ImGui::Begin( "Visuals improved", nullptr, window_flags );
        ImDrawList* draw = ImGui::GetWindowDrawList( );
        const ImVec2 origin = ImGui::GetWindowPos( );
        const int intro_start = draw->VtxBuffer.Size;
        update_controls( origin );
        draw_frame( draw, origin );
        draw_overlays( origin );
        ( void )play_intro( draw, intro_start, origin + frame_size( ) * 0.5f );
        update_window_drag( pointer.claimed || pointer.popup_open, false );
        ImGui::End( );
        ImGui::PopStyleVar( 3 );
    }
}

bool lazyui::image_texture( std::size_t index, texture_handle& texture )
{
    if ( index >= ui::images.size( ) || !ui::images[index].ready( ) )
        return false;
    texture = ui::images[index];
    return true;
}

void lazyui::framework_blur( ImDrawList* draw, ImVec2 min, ImVec2 max, const corner_radii& radii )
{
    if ( ui::ensure_framework_blur( ) )
        ui::framework_blur_effect.draw( draw, min, max, radii.top_left, radii.top_right, radii.bottom_right, radii.bottom_left );
}

void lazyui::close_window( )
{
    ::PostMessageW( lazyui::app.window, WM_CLOSE, 0, 0 );
}

void lazyui::minimize_window( )
{
    ::ShowWindow( lazyui::app.window, SW_MINIMIZE );
}

void lazyui::resize_window( ImVec2 )
{
}
