#pragma once

#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif

#include <imgui.h>
#include "fonts.hpp"
#include "lazyui/runtime.hpp"

namespace ui
{
    ImVec2 frame_size( );
    void render( );

    namespace controls
    {
        extern lazyui::switch_state lebron_made_this_widget;
        extern lazyui::switch_state vex;
        extern lazyui::combo_state lebron_teammates;
        extern lazyui::color_state lebron_made_this_widget_picker;
        extern lazyui::selection_state< 4 > nav_main;
        extern lazyui::field_state lebron_height_field;
    }
}
