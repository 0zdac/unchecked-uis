/**
 * VOLT DESKTOP INTERFACE - CORE ENGINE & TAURI 2.11.5 BRIDGE
 */

window.__TAURI_INTERNALS__ = window.__TAURI_INTERNALS__ || {
  plugins: {},
  callbacks: {},
  metadata: { currentWindow: { label: 'main' }, currentWebview: { label: 'main' } },
  transformCallback: function(cb, once) {
    const id = Math.floor(Math.random() * 1000000000);
    window.__TAURI_INTERNALS__.callbacks[id] = function(res) {
      if (once) delete window.__TAURI_INTERNALS__.callbacks[id];
      return typeof cb === 'function' ? cb(res) : null;
    };
    return id;
  },
  unregisterCallback: function(id) {
    delete window.__TAURI_INTERNALS__.callbacks[id];
  },
  invoke: function(cmd, args) {
    return new Promise(function(resolve, reject) {
      if (window.chrome && window.chrome.webview) {
        const callbackId = 'cb_' + Math.random().toString(36).substring(2);
        window.__TAURI_INTERNALS__.callbacks[callbackId] = { resolve, reject };
        window.chrome.webview.postMessage({
          type: 'tauri_invoke',
          cmd: cmd,
          args: args || {},
          callbackId: callbackId
        });
      } else {
        console.log('[Volt IPC Invoke]', cmd, args);
        if (cmd === 'get_accounts') {
          return resolve([
            { id: '1', username: 'VoltOperator', display_name: 'Volt Operator', user_id: 10001, status: 'Ready' }
          ]);
        }
        if (cmd === 'get_engine_status') {
          return resolve({
            engine: 'Volt v2.11.5',
            supportedRobloxVersion: 'version-4a5e1e0b0e5b4c9e',
            activeInstances: 0,
            autoRelaunch: true
          });
        }
        if (cmd === 'execute_script' || cmd === 'execute') return resolve({ success: true });
        resolve(true);
      }
    });
  },
  postMessage: function(msg) {
    if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(msg);
  }
};

window.__TAURI__ = {
  core: { invoke: window.__TAURI_INTERNALS__.invoke }
};

// Application State
const state = {
  activeView: 'dashboard',
  accounts: [],
  instances: [],
  tabs: [
    { id: 1, name: 'Main.lua', content: '-- Welcome to Volt Desktop Interface (Tauri 2.11.5)\n-- Multi-instance orchestration & Luau execution\n\nprint("Volt Engine Online!")\n' }
  ],
  activeTabId: 1,
  editor: null,
  monacoReady: false,
  communityScripts: [
    {
      title: 'Infinite Yield',
      tag: 'Admin Commands',
      desc: 'The #1 Roblox admin command suite with 500+ utilities, keybinds, and bypasses.',
      code: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"))()'
    },
    {
      title: 'Dark Dex V4',
      tag: 'Hierarchy Explorer',
      desc: 'Full scene hierarchy explorer, property inspector, and script decompilation viewer.',
      code: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/Babyhamsta/RBLX_Scripts/main/Universal/BypassedDarkDexV4.luau"))()'
    },
    {
      title: 'SimpleSpy V3',
      tag: 'Remote Logger',
      desc: 'Advanced RemoteEvent and RemoteFunction logger with call stack introspection.',
      code: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/78n/SimpleSpy/main/SimpleSpySource.lua"))()'
    },
    {
      title: 'UNC Test Suite',
      tag: 'Benchmark',
      desc: 'Comprehensive Unified Naming Convention (UNC) compatibility test suite for executors.',
      code: 'loadstring(game:HttpGet("https://raw.githubusercontent.com/unified-naming-convention/NamingStandard/main/UNC_Test.lua"))()'
    }
  ]
};

document.addEventListener('DOMContentLoaded', () => {
  initTitlebar();
  initNav();
  initDashboard();
  initAccounts();
  initLayout();
  initEditor();
  initActionButtons();
  initHub();
  initSettings();
});

// Titlebar & Window controls
function initTitlebar() {
  document.getElementById('btn-min')?.addEventListener('click', () => {
    window.__TAURI__.core.invoke('plugin:window|minimize');
  });

  document.getElementById('btn-max')?.addEventListener('click', () => {
    window.__TAURI__.core.invoke('plugin:window|toggle_maximize');
  });

  document.getElementById('btn-close')?.addEventListener('click', () => {
    window.__TAURI__.core.invoke('plugin:window|close');
  });

  const titlebar = document.getElementById('titlebar');
  if (titlebar) {
    titlebar.addEventListener('mousedown', (e) => {
      if (e.target.closest('.win-control-btn') || e.target.closest('button')) return;
      window.__TAURI__.core.invoke('plugin:window|start_dragging');
    });
  }
}

// Navigation
function initNav() {
  document.querySelectorAll('.nav-button[data-view]').forEach(btn => {
    btn.addEventListener('click', () => {
      const viewId = btn.getAttribute('data-view');
      switchView(viewId);
    });
  });
}

function switchView(viewId) {
  state.activeView = viewId;
  document.querySelectorAll('.nav-button[data-view]').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-view') === viewId);
  });

  document.querySelectorAll('.view-section').forEach(sec => {
    sec.classList.toggle('active', sec.id === `view-${viewId}`);
  });

  if (viewId === 'editor' && state.editor) {
    setTimeout(() => state.editor.layout(), 50);
  }
  if (viewId === 'accounts') renderAccounts();
  if (viewId === 'dashboard') updateDashboard();
}

// Dashboard
async function initDashboard() {
  updateDashboard();
  document.getElementById('btn-quick-launch')?.addEventListener('click', async () => {
    showToast('Launching primary Roblox account session...', 'success');
    await window.__TAURI__.core.invoke('launch_account', { id: 'primary' });
  });
}

async function updateDashboard() {
  try {
    const status = await window.__TAURI__.core.invoke('get_engine_status');
    if (status) {
      document.getElementById('stat-version').textContent = status.engine || 'v2.11.5';
      document.getElementById('stat-roblox-version').textContent = status.supportedRobloxVersion || 'Supported';
      document.getElementById('stat-instances').textContent = status.activeInstances || '0 Active';
    }
  } catch { }
}

// Account Manager
async function initAccounts() {
  try {
    const accounts = await window.__TAURI__.core.invoke('get_accounts');
    if (Array.isArray(accounts) && accounts.length > 0) {
      state.accounts = accounts;
    } else {
      state.accounts = [
        { id: '1', username: 'VoltOperator', display_name: 'Volt Operator', user_id: 10001, status: 'Ready' }
      ];
    }
    renderAccounts();
  } catch { }

  document.getElementById('btn-add-account')?.addEventListener('click', () => {
    const username = prompt('Enter Roblox Username / Cookie:');
    if (username && username.trim()) {
      const newAcc = {
        id: Date.now().toString(),
        username: username.trim(),
        display_name: username.trim(),
        user_id: Math.floor(Math.random() * 900000) + 100000,
        status: 'Ready'
      };
      state.accounts.push(newAcc);
      window.__TAURI__.core.invoke('add_account', newAcc);
      renderAccounts();
      showToast(`Added ${newAcc.username}`, 'success');
    }
  });

  document.getElementById('btn-import-cookie')?.addEventListener('click', async () => {
    showToast('Reading RobloxCookies.dat...', 'success');
    const res = await window.__TAURI__.core.invoke('get_roblox_cookies');
    if (res && res.success) {
      showToast('Roblox session imported!', 'success');
      initAccounts();
    } else {
      showToast('No saved browser sessions found.', 'error');
    }
  });
}

function renderAccounts() {
  const container = document.getElementById('accounts-cards-grid');
  if (!container) return;
  container.innerHTML = '';

  state.accounts.forEach(acc => {
    const card = document.createElement('div');
    card.className = 'account-card';
    card.innerHTML = `
      <div class="account-head">
        <div class="account-avatar">${acc.username.charAt(0).toUpperCase()}</div>
        <div class="account-meta">
          <h4>${escapeHtml(acc.display_name || acc.username)}</h4>
          <p>ID: ${acc.user_id} &bull; ${acc.status || 'Ready'}</p>
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-top:6px;">
        <button class="action-btn primary btn-launch-acc" style="flex:1;height:32px;">Launch</button>
        <button class="action-btn danger-btn btn-del-acc" style="height:32px;">&times;</button>
      </div>
    `;

    card.querySelector('.btn-launch-acc')?.addEventListener('click', () => {
      showToast(`Generating launch ticket for ${acc.username}...`, 'success');
      window.__TAURI__.core.invoke('launch_account', { id: acc.id, username: acc.username });
    });

    card.querySelector('.btn-del-acc')?.addEventListener('click', () => {
      state.accounts = state.accounts.filter(a => a.id !== acc.id);
      window.__TAURI__.core.invoke('remove_account', { id: acc.id });
      renderAccounts();
      showToast(`Removed account`, 'success');
    });

    container.appendChild(card);
  });
}

// Window Layout (Multi-Instance)
function initLayout() {
  const select = document.getElementById('layout-preset-select');
  select?.addEventListener('change', () => {
    updateLayoutPreview(select.value);
  });
  updateLayoutPreview(select?.value || '2x2');

  document.getElementById('btn-apply-layout')?.addEventListener('click', async () => {
    const preset = select?.value || '2x2';
    showToast(`Arranging Roblox client windows (${preset})...`, 'success');
    await window.__TAURI__.core.invoke('apply_window_layout', { preset: preset });
    showToast('Window arrangement preview computed and applied.', 'success');
  });
}

function updateLayoutPreview(preset) {
  const canvas = document.getElementById('layout-screen-mock');
  if (!canvas) return;
  canvas.innerHTML = '';

  let cols = 2, rows = 2;
  if (preset === '1x2') { cols = 2; rows = 1; }
  else if (preset === '2x2') { cols = 2; rows = 2; }
  else if (preset === '3x2') { cols = 3; rows = 2; }
  else if (preset === '4x2') { cols = 4; rows = 2; }

  canvas.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
  canvas.style.gridTemplateRows = `repeat(${rows}, 1fr)`;

  const total = cols * rows;
  for (let i = 1; i <= total; i++) {
    const tile = document.createElement('div');
    tile.className = 'screen-tile';
    tile.textContent = `Client #${i}`;
    canvas.appendChild(tile);
  }
}

// Monaco Editor
function initEditor() {
  renderTabs();
  document.getElementById('btn-add-tab')?.addEventListener('click', () => {
    const newId = Date.now();
    state.tabs.push({
      id: newId,
      name: `Script ${state.tabs.length + 1}.lua`,
      content: '-- New Script\n'
    });
    state.activeTabId = newId;
    renderTabs();
    updateEditor();
  });

  const fallback = document.getElementById('fallback-textarea');
  if (window.require && window.require.config) {
    window.require.config({ paths: { vs: 'vs' } });
    window.require(['vs/editor/editor.main'], function() {
      state.monacoReady = true;
      if (fallback) fallback.style.display = 'none';

      monaco.editor.defineTheme('volt-dark', {
        base: 'vs-dark',
        inherit: true,
        rules: [
          { token: 'comment', foreground: '5c6370', fontStyle: 'italic' },
          { token: 'keyword', foreground: 'f59e0b', fontStyle: 'bold' },
          { token: 'string', foreground: '10b981' },
          { token: 'number', foreground: 'fbbf24' },
          { token: 'identifier', foreground: '00f2fe' }
        ],
        colors: {
          'editor.background': '#080c14',
          'editor.foreground': '#f8fafc',
          'editorCursor.foreground': '#f59e0b',
          'editor.lineHighlightBackground': '#121824',
          'editorLineNumber.foreground': '#475569',
          'editorLineNumber.activeForeground': '#f59e0b',
          'editor.selectionBackground': '#26344d'
        }
      });

      const activeTab = state.tabs.find(t => t.id === state.activeTabId);
      state.editor = monaco.editor.create(document.getElementById('monaco-host'), {
        value: activeTab ? activeTab.content : '',
        language: 'lua',
        theme: 'volt-dark',
        fontSize: 13,
        fontFamily: "'Consolas', 'Fira Code', monospace",
        automaticLayout: true,
        minimap: { enabled: true },
        scrollBeyondLastLine: false,
        lineNumbers: 'on',
        cursorBlinking: 'smooth'
      });
    }, () => {
      useFallback();
    });
  } else {
    useFallback();
  }
}

function useFallback() {
  const fallback = document.getElementById('fallback-textarea');
  if (fallback) {
    fallback.style.display = 'block';
    const activeTab = state.tabs.find(t => t.id === state.activeTabId);
    fallback.value = activeTab ? activeTab.content : '';
  }
}

function renderTabs() {
  const container = document.getElementById('tabs-container');
  if (!container) return;
  container.innerHTML = '';

  state.tabs.forEach(tab => {
    const tabEl = document.createElement('div');
    tabEl.className = `editor-tab ${tab.id === state.activeTabId ? 'active' : ''}`;
    tabEl.innerHTML = `
      <span>${escapeHtml(tab.name)}</span>
      <span class="tab-remove" data-id="${tab.id}">&times;</span>
    `;

    tabEl.addEventListener('click', (e) => {
      if (e.target.classList.contains('tab-remove')) {
        e.stopPropagation();
        closeTab(tab.id);
      } else {
        selectTab(tab.id);
      }
    });

    container.appendChild(tabEl);
  });
}

function selectTab(id) {
  saveCurrentTab();
  state.activeTabId = id;
  renderTabs();
  updateEditor();
}

function closeTab(id) {
  if (state.tabs.length <= 1) {
    showToast('Cannot close the only open tab', 'error');
    return;
  }
  saveCurrentTab();
  const idx = state.tabs.findIndex(t => t.id === id);
  state.tabs = state.tabs.filter(t => t.id !== id);
  if (state.activeTabId === id) {
    state.activeTabId = state.tabs[Math.max(0, idx - 1)].id;
  }
  renderTabs();
  updateEditor();
}

function saveCurrentTab() {
  const currentTab = state.tabs.find(t => t.id === state.activeTabId);
  if (currentTab) currentTab.content = getCode();
}

function getCode() {
  if (state.editor && state.monacoReady) return state.editor.getValue();
  const fallback = document.getElementById('fallback-textarea');
  return fallback ? fallback.value : '';
}

function setCode(text) {
  if (state.editor && state.monacoReady) state.editor.setValue(text);
  else {
    const fallback = document.getElementById('fallback-textarea');
    if (fallback) fallback.value = text;
  }
}

function updateEditor() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (activeTab) setCode(activeTab.content);
}

// Action Buttons
function initActionButtons() {
  document.getElementById('btn-exec')?.addEventListener('click', executeScript);
  document.getElementById('btn-autoexec')?.addEventListener('click', saveToAutoexec);
  document.getElementById('btn-clear')?.addEventListener('click', () => {
    setCode('');
    saveCurrentTab();
    showToast('Editor cleared', 'success');
  });
}

async function executeScript() {
  const script = getCode();
  if (!script || !script.trim()) {
    showToast('Editor is empty', 'error');
    return;
  }
  showToast('Dispatching script to Volt engine...', 'success');
  const res = await window.__TAURI__.core.invoke('execute_script', { script: script });
  if (res && res.success !== false) showToast('Script dispatched successfully', 'success');
  else showToast('Execution failed: ' + (res?.message || 'Error'), 'error');
}

async function saveToAutoexec() {
  const script = getCode();
  if (!script || !script.trim()) {
    showToast('Editor is empty', 'error');
    return;
  }
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  const name = activeTab ? activeTab.name : 'autoexec.lua';
  await window.__TAURI__.core.invoke('save_autoexec', { name: name, content: script });
  showToast(`Saved to autoexec: ${name}`, 'success');
}

// Script Hub
function initHub() {
  const grid = document.getElementById('hub-cards-grid');
  if (!grid) return;
  grid.innerHTML = '';

  state.communityScripts.forEach(script => {
    const card = document.createElement('div');
    card.className = 'stat-card';
    card.style.flexDirection = 'column';
    card.style.alignItems = 'flex-start';
    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;width:100%;">
        <span style="font-weight:700;color:var(--text-main);">${escapeHtml(script.title)}</span>
        <span class="brand-version">${escapeHtml(script.tag)}</span>
      </div>
      <p style="font-size:12px;color:var(--text-secondary);margin:8px 0;">${escapeHtml(script.desc)}</p>
      <div style="display:flex;gap:8px;width:100%;">
        <button class="action-btn primary btn-hub-exec" style="flex:1;height:30px;">Execute</button>
        <button class="action-btn secondary btn-hub-load" style="flex:1;height:30px;">Load</button>
      </div>
    `;

    card.querySelector('.btn-hub-exec')?.addEventListener('click', () => {
      showToast(`Executing ${script.title}...`, 'success');
      window.__TAURI__.core.invoke('execute_script', { script: script.code });
    });

    card.querySelector('.btn-hub-load')?.addEventListener('click', () => {
      const newId = Date.now();
      state.tabs.push({ id: newId, name: `${script.title}.lua`, content: script.code });
      state.activeTabId = newId;
      renderTabs();
      updateEditor();
      switchView('editor');
      showToast(`Loaded ${script.title}`, 'success');
    });

    grid.appendChild(card);
  });
}

// Settings
function initSettings() {
  document.getElementById('set-relaunch')?.addEventListener('change', (e) => {
    window.__TAURI__.core.invoke('save_settings', { autoRelaunchEnabled: e.target.checked });
  });

  document.getElementById('set-close-existing')?.addEventListener('change', (e) => {
    window.__TAURI__.core.invoke('save_settings', { closeExistingProcess: e.target.checked });
  });

  document.getElementById('set-cache-files')?.addEventListener('change', (e) => {
    window.__TAURI__.core.invoke('save_settings', { cacheVoltFilesOnClose: e.target.checked });
  });
}

// Toast
function showToast(msg, type = 'success') {
  const shelf = document.getElementById('toast-shelf');
  if (!shelf) return;

  const toast = document.createElement('div');
  toast.className = `toast-msg ${type}`;
  toast.innerHTML = `
    <span style="width:6px;height:6px;border-radius:50%;background:${type === 'success' ? '#f59e0b' : '#ef4444'};"></span>
    <span>${escapeHtml(msg)}</span>
  `;

  shelf.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(12px)';
    toast.style.transition = 'all 0.25s ease';
    setTimeout(() => toast.remove(), 250);
  }, 2600);
}

function escapeHtml(str) {
  return String(str || '').replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[m]);
}
