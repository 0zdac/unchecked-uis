using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace VoltApp
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainWindow());
        }
    }

    public class EmbeddedHttpServer : IDisposable
    {
        private readonly HttpListener _listener;
        private readonly string _rootDir;
        private readonly int _port;
        private CancellationTokenSource? _cts;
        private Task? _listenTask;

        private static readonly Dictionary<string, string> MimeTypes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { ".html", "text/html; charset=utf-8" },
            { ".htm", "text/html; charset=utf-8" },
            { ".js", "application/javascript; charset=utf-8" },
            { ".mjs", "application/javascript; charset=utf-8" },
            { ".css", "text/css; charset=utf-8" },
            { ".json", "application/json; charset=utf-8" },
            { ".svg", "image/svg+xml" },
            { ".png", "image/png" },
            { ".jpg", "image/jpeg" },
            { ".jpeg", "image/jpeg" },
            { ".ico", "image/x-icon" },
            { ".woff", "font/woff" },
            { ".woff2", "font/woff2" },
            { ".ttf", "font/ttf" },
            { ".wasm", "application/wasm" },
            { ".txt", "text/plain; charset=utf-8" }
        };

        public EmbeddedHttpServer(string rootDir, int port = 1430)
        {
            _rootDir = Path.GetFullPath(rootDir);
            _port = port;
            _listener = new HttpListener();
            try
            {
                _listener.Prefixes.Add($"http://localhost:{port}/");
                _listener.Prefixes.Add($"http://127.0.0.1:{port}/");
            }
            catch { }
        }

        public void Start()
        {
            try
            {
                _listener.Start();
                _cts = new CancellationTokenSource();
                _listenTask = Task.Run(() => ListenLoop(_cts.Token));
            }
            catch (Exception ex)
            {
                MainWindow.LogDebug($"[EmbeddedHttpServer] Start error: {ex.Message}");
            }
        }

        private async Task ListenLoop(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested && _listener.IsListening)
            {
                try
                {
                    var ctx = await _listener.GetContextAsync();
                    _ = Task.Run(() => HandleRequest(ctx));
                }
                catch (Exception)
                {
                    if (ct.IsCancellationRequested) break;
                }
            }
        }

        private void HandleRequest(HttpListenerContext ctx)
        {
            try
            {
                var req = ctx.Request;
                var res = ctx.Response;

                res.AddHeader("Access-Control-Allow-Origin", "*");
                res.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                res.AddHeader("Access-Control-Allow-Headers", "*");

                if (req.HttpMethod == "OPTIONS")
                {
                    res.StatusCode = 204;
                    res.Close();
                    return;
                }

                string urlPath = req.Url?.AbsolutePath ?? "";
                if (urlPath == "/" || string.IsNullOrEmpty(urlPath))
                    urlPath = "/index.html";

                string relPath = urlPath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
                string filePath = Path.Combine(_rootDir, relPath);

                if (!File.Exists(filePath))
                {
                    if (string.IsNullOrEmpty(Path.GetExtension(relPath)))
                    {
                        filePath = Path.Combine(_rootDir, "index.html");
                    }
                }

                if (File.Exists(filePath))
                {
                    byte[] bytes = File.ReadAllBytes(filePath);
                    string ext = Path.GetExtension(filePath);
                    if (MimeTypes.TryGetValue(ext, out string? mime) && mime != null)
                        res.ContentType = mime;
                    else
                        res.ContentType = "application/octet-stream";

                    res.ContentLength64 = bytes.Length;
                    res.StatusCode = 200;
                    res.OutputStream.Write(bytes, 0, bytes.Length);
                }
                else
                {
                    res.StatusCode = 404;
                }
                res.Close();
            }
            catch (Exception ex)
            {
                MainWindow.LogDebug($"[EmbeddedHttpServer] Request error: {ex.Message}");
            }
        }

        public void Dispose()
        {
            _cts?.Cancel();
            try { _listener?.Stop(); } catch { }
            try { _listener?.Close(); } catch { }
        }
    }

    public class MainWindow : Form
    {
        private WebView2? _webView;
        private EmbeddedHttpServer? _server;

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;

        private const int WM_NCHITTEST = 0x84;
        private const int HTCLIENT = 1;
        private const int HTLEFT = 10;
        private const int HTRIGHT = 11;
        private const int HTTOP = 12;
        private const int HTTOPLEFT = 13;
        private const int HTTOPRIGHT = 14;
        private const int HTBOTTOM = 15;
        private const int HTBOTTOMLEFT = 16;
        private const int HTBOTTOMRIGHT = 17;

        private const int RESIZE_HANDLE_SIZE = 8;
        private const uint SWP_NOZORDER = 0x0004;
        private const uint SWP_SHOWWINDOW = 0x0040;

        private const int WM_SYSCOMMAND = 0x0112;
        private const int SC_MOVE = 0xF010;

        public MainWindow()
        {
            Text = "constraintt.ez";
            Width = 1100;
            Height = 700;
            MinimumSize = new Size(800, 500);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(7, 9, 14);
            ForeColor = Color.White;
            FormBorderStyle = FormBorderStyle.None;
            DoubleBuffered = true;
            SetStyle(ControlStyles.ResizeRedraw, true);

            LoadAppIcon();
            ApplyDwmAttributes();
            InitUI();
        }

        private void LoadAppIcon()
        {
            try
            {
                string icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
                if (File.Exists(icoPath))
                {
                    Icon = new Icon(icoPath);
                }
                else
                {
                    Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                }
            }
            catch { }
        }

        private void ApplyDwmAttributes()
        {
            try
            {
                int darkMode = 1;
                DwmSetWindowAttribute(Handle, 20, ref darkMode, sizeof(int));

                int cornerPreference = 2; // DWMWCP_ROUND
                DwmSetWindowAttribute(Handle, 33, ref cornerPreference, sizeof(int));
            }
            catch { }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (WindowState == FormWindowState.Normal)
            {
                try
                {
                    Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 16, 16));
                }
                catch { }
            }
            else
            {
                Region = null;
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_NCHITTEST && WindowState == FormWindowState.Normal)
            {
                base.WndProc(ref m);
                if ((int)m.Result == HTCLIENT)
                {
                    Point cursor = PointToClient(Cursor.Position);

                    bool left = cursor.X <= RESIZE_HANDLE_SIZE;
                    bool right = cursor.X >= ClientSize.Width - RESIZE_HANDLE_SIZE;
                    bool top = cursor.Y <= RESIZE_HANDLE_SIZE;
                    bool bottom = cursor.Y >= ClientSize.Height - RESIZE_HANDLE_SIZE;

                    if (top && left) m.Result = (IntPtr)HTTOPLEFT;
                    else if (top && right) m.Result = (IntPtr)HTTOPRIGHT;
                    else if (bottom && left) m.Result = (IntPtr)HTBOTTOMLEFT;
                    else if (bottom && right) m.Result = (IntPtr)HTBOTTOMRIGHT;
                    else if (left) m.Result = (IntPtr)HTLEFT;
                    else if (right) m.Result = (IntPtr)HTRIGHT;
                    else if (top) m.Result = (IntPtr)HTTOP;
                    else if (bottom) m.Result = (IntPtr)HTBOTTOM;
                }
                return;
            }
            base.WndProc(ref m);
        }

        public static void LogDebug(string msg)
        {
            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "volt_debug.log");
                File.AppendAllText(logPath, $"[{DateTime.Now:HH:mm:ss.fff}] {msg}\n");
            }
            catch { }
        }

        private async void InitUI()
        {
            try
            {
                string uiPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ui");
                if (!Directory.Exists(uiPath))
                {
                    string altUi = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\ui"));
                    if (Directory.Exists(altUi)) uiPath = altUi;
                }

                _server = new EmbeddedHttpServer(uiPath, 1430);
                _server.Start();

                _webView = new WebView2
                {
                    Dock = DockStyle.Fill,
                    BackColor = Color.FromArgb(7, 9, 14),
                    DefaultBackgroundColor = Color.FromArgb(7, 9, 14)
                };
                Controls.Add(_webView);

                string userData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VoltWebView2");
                var env = await CoreWebView2Environment.CreateAsync(null, userData);
                await _webView.EnsureCoreWebView2Async(env);

                _webView.DefaultBackgroundColor = Color.FromArgb(7, 9, 14);

                _webView.CoreWebView2.Settings.IsWebMessageEnabled = true;
                _webView.CoreWebView2.Settings.AreDevToolsEnabled = true;
                _webView.CoreWebView2.Settings.IsScriptEnabled = true;
                _webView.CoreWebView2.Settings.IsStatusBarEnabled = false;

                _webView.CoreWebView2.WebMessageReceived += OnWebMessageReceived;

                _webView.CoreWebView2.Navigate("http://localhost:1430/");
            }
            catch (Exception ex)
            {
                LogDebug("InitUI Error: " + ex.Message);
                MessageBox.Show("WebView2 Init Error: " + ex.Message, "Volt Interface", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnWebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                string? raw = null;
                try { raw = e.TryGetWebMessageAsString(); } catch { }
                if (string.IsNullOrEmpty(raw))
                {
                    try { raw = e.WebMessageAsJson; } catch { }
                }
                if (string.IsNullOrEmpty(raw)) return;

                var obj = JObject.Parse(raw);
                string? msgType = obj["type"]?.ToString();

                if (msgType == "console_log")
                {
                    LogDebug($"[Console {obj["level"]}] {obj["msg"]}");
                    return;
                }

                if (msgType == "tauri_invoke")
                {
                    string cmd = obj["cmd"]?.ToString() ?? "";
                    var args = obj["args"] as JObject ?? new JObject();
                    string callbackId = obj["callbackId"]?.ToString() ?? "";

                    object result = HandleTauriCommand(cmd, args);
                    ResolveCallback(callbackId, result);
                }
            }
            catch (Exception ex)
            {
                LogDebug($"WebMessage Error: {ex.Message}");
            }
        }

        private object? HandleTauriCommand(string cmd, JObject args)
        {
            try
            {
                switch (cmd)
                {
                    case "plugin:window|start_dragging":
                    case "start_dragging":
                        BeginDrag();
                        return true;

                    case "plugin:window|minimize":
                    case "minimize":
                        Invoke((Action)(() => WindowState = FormWindowState.Minimized));
                        return true;

                    case "plugin:window|maximize":
                    case "maximize":
                    case "plugin:window|toggle_maximize":
                    case "toggle_maximize":
                        Invoke((Action)(() =>
                        {
                            WindowState = (WindowState == FormWindowState.Maximized) ? FormWindowState.Normal : FormWindowState.Maximized;
                        }));
                        return true;

                    case "plugin:window|close":
                    case "close":
                        Invoke((Action)(() => Close()));
                        return true;

                    case "plugin:window|is_maximized":
                        return WindowState == FormWindowState.Maximized;

                    case "plugin:window|set_always_on_top":
                        bool top = args["enabled"]?.Value<bool>() ?? true;
                        Invoke((Action)(() => TopMost = top));
                        return true;

                    case "get_engine_status":
                        var procs = Process.GetProcessesByName("RobloxPlayerBeta");
                        return new
                        {
                            engine = "constraintt.ez",
                            supportedRobloxVersion = "version-4a5e1e0b0e5b4c9e",
                            activeInstances = $"{procs.Length} Active",
                            autoRelaunch = true
                        };

                    case "get_accounts":
                        return LoadAccounts();

                    case "add_account":
                        SaveAccount(args);
                        return true;

                    case "remove_account":
                        RemoveAccount(args["id"]?.ToString());
                        return true;

                    case "launch_account":
                        return LaunchRobloxAccount(args["username"]?.ToString());

                    case "get_roblox_cookies":
                        return TryExtractRobloxCookies();

                    case "apply_window_layout":
                        string preset = args["preset"]?.ToString() ?? "2x2";
                        return TileRobloxWindows(preset);

                    case "execute_script":
                    case "execute":
                        string script = args["script"]?.ToString() ?? "";
                        return ExecuteScriptCode(script);

                    case "save_autoexec":
                        string name = args["name"]?.ToString() ?? "script.lua";
                        string content = args["content"]?.ToString() ?? "";
                        return SaveAutoexecScript(name, content);

                    case "load_settings":
                        return "{}";

                    case "save_settings":
                        return true;

                    case "check_update_with_domains":
                    case "check_update":
                    case "plugin:updater|check":
                    case "plugin:updater|download_and_install":
                        return null;

                    case "plugin:app|version":
                    case "get_app_version":
                        return "2.11.5";

                    case "plugin:window|get_all_windows":
                    case "plugin:webview|get_all_webviews":
                        return new string[] { "main" };

                    case "plugin:window|inner_size":
                    case "plugin:window|outer_size":
                        return new { width = Width, height = Height };

                    case "plugin:window|inner_position":
                    case "plugin:window|outer_position":
                        return new { x = Location.X, y = Location.Y };

                    case "plugin:window|scale_factor":
                        return 1.0;

                    case "plugin:window|theme":
                        return "dark";

                    case "plugin:window|title":
                        return "constraintt.ez";

                    case "plugin:window|primary_monitor":
                        return new
                        {
                            name = "\\\\.\\DISPLAY1",
                            size = new { width = Screen.PrimaryScreen.Bounds.Width, height = Screen.PrimaryScreen.Bounds.Height },
                            position = new { x = 0, y = 0 },
                            scaleFactor = 1.0
                        };

                    case "account_manager_get_state":
                        return new
                        {
                            accounts = new object[0],
                            groups = new object[0],
                            privateServers = new object[0],
                            settings = new
                            {
                                autoLaunchOnStartup = false,
                                defaultPlaceId = "",
                                privateServerMode = "none",
                                selectedPrivateServerIds = new string[0],
                                windowArrangement = new
                                {
                                    enabled = false,
                                    autoLayout = true,
                                    windowWidth = 800,
                                    windowHeight = 600,
                                    windowsPerRow = 2,
                                    customResolution = "800x600"
                                }
                            },
                            resourceTotals = new
                            {
                                activeProcessCount = 0,
                                cpuPercent = 0.0,
                                memoryBytes = 0
                            }
                        };

                    case "account_manager_save_settings":
                    case "account_manager_save_groups":
                    case "account_manager_save_private_servers":
                    case "account_manager_arrange_windows":
                        return true;

                    case "account_manager_preview_window_arrangement":
                        return new { windowsPerRow = 2, windowWidth = 800, windowHeight = 600 };

                    case "account_manager_validate_place_id":
                        return new { valid = true, placeId = args["placeId"]?.ToString() ?? "" };

                    case "account_manager_check_cookies":
                        return new { valid = true };

                    case "account_manager_import_cookies":
                        return new { success = true, imported = 0 };

                    case "get_latest_sourcemap":
                        return null;

                    case "set_sourcemap_instance":
                        return true;

                    case "restore_window_layout_state":
                    case "delete_layout_temp_file":
                    case "write_layout_temp_file":
                    case "ensure_ignore_folder":
                        return true;

                    case "read_layout_temp_file":
                        return "";

                    case "get_window_layout_state":
                        return new { preset = "2x2", relaunchDelayMs = 3000, autoRelaunchEnabled = false };

                    case "get_client_settings_file_state":
                        return new { exists = false, path = "", settings = new object() };

                    case "list_system_fonts":
                        return new string[] { "Cascadia Code", "Consolas", "Courier New" };

                    case "get_autoexec_directory_cmd":
                        return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "autoexec");

                    case "get_scripts_directory_cmd":
                        return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");

                    case "get_workspace_directory_cmd":
                        return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "workspace");

                    case "directory_exists":
                        string dirPath = args["path"]?.ToString() ?? "";
                        return !string.IsNullOrEmpty(dirPath) && Directory.Exists(dirPath);

                    case "file_exists":
                        string fPath = args["path"]?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(fPath) && fPath.Contains("__volt_untitled__"))
                            return true;
                        return !string.IsNullOrEmpty(fPath) && File.Exists(fPath);

                    case "read_file":
                        string rPath = args["path"]?.ToString() ?? "";
                        if (File.Exists(rPath))
                            return File.ReadAllText(rPath);
                        if (!string.IsNullOrEmpty(rPath) && rPath.Contains("__volt_untitled__"))
                        {
                            try
                            {
                                string? parent = Path.GetDirectoryName(rPath);
                                if (!string.IsNullOrEmpty(parent)) Directory.CreateDirectory(parent);
                                File.WriteAllText(rPath, "");
                            }
                            catch { }
                            return "";
                        }
                        return "";

                    case "write_file":
                        string wPath = args["path"]?.ToString() ?? "";
                        string fContent = args["content"]?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(wPath))
                        {
                            string? parent = Path.GetDirectoryName(wPath);
                            if (!string.IsNullOrEmpty(parent)) Directory.CreateDirectory(parent);
                            File.WriteAllText(wPath, fContent);
                        }
                        return true;

                    case "create_directory":
                        string cdPath = args["path"]?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(cdPath)) Directory.CreateDirectory(cdPath);
                        return true;

                    case "delete_file":
                        string dfPath = args["path"]?.ToString() ?? "";
                        if (File.Exists(dfPath)) File.Delete(dfPath);
                        return true;

                    case "delete_directory":
                        string ddirPath = args["path"]?.ToString() ?? "";
                        if (Directory.Exists(ddirPath)) Directory.Delete(ddirPath, true);
                        return true;

                    case "list_directory_entries":
                    case "list_files_in_directory":
                        string listDir = args["path"]?.ToString() ?? "";
                        if (Directory.Exists(listDir))
                        {
                            var entries = new List<object>();
                            foreach (var d in Directory.GetDirectories(listDir))
                                entries.Add(new { name = Path.GetFileName(d), path = d, isDirectory = true, isFile = false });
                            foreach (var f in Directory.GetFiles(listDir))
                                entries.Add(new { name = Path.GetFileName(f), path = f, isDirectory = false, isFile = true });
                            return entries;
                        }
                        return new object[0];

                    case "open_file_dialog":
                        string? selectedOpen = null;
                        Invoke((Action)(() =>
                        {
                            using (var ofd = new OpenFileDialog())
                            {
                                ofd.Title = "Open Script";
                                ofd.Filter = "Lua Files (*.lua;*.luau)|*.lua;*.luau|All Files (*.*)|*.*";
                                ofd.InitialDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");
                                if (ofd.ShowDialog() == DialogResult.OK)
                                    selectedOpen = ofd.FileName;
                            }
                        }));
                        return selectedOpen;

                    case "save_file_dialog":
                        string? selectedSave = null;
                        Invoke((Action)(() =>
                        {
                            using (var sfd = new SaveFileDialog())
                            {
                                sfd.Title = "Save Script";
                                sfd.Filter = "Lua Files (*.luau)|*.luau|Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";
                                sfd.InitialDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");
                                if (sfd.ShowDialog() == DialogResult.OK)
                                    selectedSave = sfd.FileName;
                            }
                        }));
                        return selectedSave;

                    case "open_folder_in_explorer":
                        string fExpPath = args["path"]?.ToString() ?? "";
                        try
                        {
                            if (Directory.Exists(fExpPath))
                                Process.Start("explorer.exe", fExpPath);
                            else if (File.Exists(fExpPath))
                                Process.Start("explorer.exe", $"/select,\"{fExpPath}\"");
                            else
                                Process.Start("explorer.exe", AppDomain.CurrentDomain.BaseDirectory);
                        }
                        catch { }
                        return true;

                    case "save_file_to_scripts":
                        string sName = args["name"]?.ToString() ?? "script.luau";
                        string sCode = args["content"]?.ToString() ?? "";
                        string scriptsFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");
                        Directory.CreateDirectory(scriptsFolder);
                        string sDest = Path.Combine(scriptsFolder, sName);
                        File.WriteAllText(sDest, sCode);
                        return new { success = true, path = sDest };

                    case "rename_file":
                        string oldF = args["oldPath"]?.ToString() ?? "";
                        string newF = args["newPath"]?.ToString() ?? "";
                        if (File.Exists(oldF) && !string.IsNullOrEmpty(newF))
                        {
                            string? pDir = Path.GetDirectoryName(newF);
                            if (!string.IsNullOrEmpty(pDir)) Directory.CreateDirectory(pDir);
                            File.Move(oldF, newF);
                        }
                        return true;

                    case "rename_directory":
                        string oldD = args["oldPath"]?.ToString() ?? "";
                        string newD = args["newPath"]?.ToString() ?? "";
                        if (Directory.Exists(oldD) && !string.IsNullOrEmpty(newD))
                            Directory.Move(oldD, newD);
                        return true;

                    case "read_file_base64":
                        string bPath = args["path"]?.ToString() ?? "";
                        if (File.Exists(bPath))
                            return Convert.ToBase64String(File.ReadAllBytes(bPath));
                        return "";

                    case "open_theme_file_dialog":
                    case "open_theme_media_file_dialog":
                    case "save_theme_file_dialog":
                        return null;

                    case "plugin:window|set_size":
                        int nw = args["width"]?.Value<int>() ?? Width;
                        int nh = args["height"]?.Value<int>() ?? Height;
                        Invoke((Action)(() => Size = new Size(nw, nh)));
                        return true;

                    case "plugin:window|set_position":
                        int nx = args["x"]?.Value<int>() ?? Location.X;
                        int ny = args["y"]?.Value<int>() ?? Location.Y;
                        Invoke((Action)(() => Location = new Point(nx, ny)));
                        return true;

                    case "plugin:window|set_content_protected":
                        return true;

                    case "plugin:window|is_fullscreen":
                        return WindowState == FormWindowState.Maximized;

                    case "plugin:window|is_focused":
                        return Focused;

                    case "plugin:window|is_resizable":
                    case "plugin:window|is_maximizable":
                    case "plugin:window|is_minimizable":
                    case "plugin:window|is_closable":
                        return true;

                    case "plugin:window|is_always_on_top":
                        return TopMost;

                    case "plugin:window|is_visible":
                        return Visible;

                    case "plugin:window|unmaximize":
                    case "plugin:window|unminimize":
                        Invoke((Action)(() => WindowState = FormWindowState.Normal));
                        return true;

                    case "plugin:window|show":
                        Invoke((Action)(() => Show()));
                        return true;

                    case "plugin:window|hide":
                        Invoke((Action)(() => Hide()));
                        return true;

                    case "get_connections":
                        return new object[0];

                    case "plugin:event|listen":
                        return 1;

                    case "plugin:event|unlisten":
                    case "plugin:event|emit":
                    case "plugin:resources|close":
                        return true;

                    case "plugin:app|name":
                        return "constraintt.ez";

                    default:
                        if (cmd.Contains("get_all") || cmd.StartsWith("list_"))
                            return new object[0];
                        if (cmd.Contains("size"))
                            return new { width = Width, height = Height };
                        if (cmd.Contains("position"))
                            return new { x = Location.X, y = Location.Y };
                        return true;
                }
            }
            catch (Exception ex)
            {
                LogDebug($"HandleTauriCommand error on {cmd}: {ex.Message}");
                return true;
            }
        }

        private object LoadAccounts()
        {
            try
            {
                string accFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "accounts.json");
                if (File.Exists(accFile))
                {
                    return JArray.Parse(File.ReadAllText(accFile));
                }
            }
            catch { }
            return new JArray
            {
                JObject.FromObject(new { id = "1", username = "VoltOperator", display_name = "Volt Operator", user_id = 10001, status = "Ready" })
            };
        }

        private void SaveAccount(JObject acc)
        {
            try
            {
                string accFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "accounts.json");
                var list = LoadAccounts() as JArray ?? new JArray();
                list.Add(acc);
                File.WriteAllText(accFile, list.ToString());
            }
            catch { }
        }

        private void RemoveAccount(string? id)
        {
            try
            {
                if (string.IsNullOrEmpty(id)) return;
                string accFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "accounts.json");
                var list = LoadAccounts() as JArray ?? new JArray();
                var filtered = new JArray();
                foreach (var item in list)
                {
                    if (item["id"]?.ToString() != id) filtered.Add(item);
                }
                File.WriteAllText(accFile, filtered.ToString());
            }
            catch { }
        }

        private object LaunchRobloxAccount(string? username)
        {
            try
            {
                return new { success = true, ticket = Guid.NewGuid().ToString() };
            }
            catch (Exception ex)
            {
                return new { success = false, message = ex.Message };
            }
        }

        private object TryExtractRobloxCookies()
        {
            try
            {
                string localData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string cookiePath = Path.Combine(localData, "Roblox", "LocalStorage", "RobloxCookies.dat");
                if (File.Exists(cookiePath))
                {
                    return new { success = true, found = true, path = cookiePath };
                }
            }
            catch { }
            return new { success = false, found = false };
        }

        private object TileRobloxWindows(string preset)
        {
            try
            {
                var procs = Process.GetProcessesByName("RobloxPlayerBeta");
                if (procs.Length == 0) return new { success = false, message = "No active tracked Roblox windows to arrange." };

                var bounds = Screen.PrimaryScreen.WorkingArea;
                int cols = 2, rows = 2;
                if (preset == "1x2") { cols = 2; rows = 1; }
                else if (preset == "2x2") { cols = 2; rows = 2; }
                else if (preset == "3x2") { cols = 3; rows = 2; }
                else if (preset == "4x2") { cols = 4; rows = 2; }

                int tileW = bounds.Width / cols;
                int tileH = bounds.Height / rows;

                for (int i = 0; i < procs.Length && i < (cols * rows); i++)
                {
                    IntPtr hwnd = procs[i].MainWindowHandle;
                    if (hwnd != IntPtr.Zero)
                    {
                        int c = i % cols;
                        int r = i / cols;
                        int x = bounds.X + (c * tileW);
                        int y = bounds.Y + (r * tileH);
                        SetWindowPos(hwnd, IntPtr.Zero, x, y, tileW, tileH, SWP_NOZORDER | SWP_SHOWWINDOW);
                    }
                }
                return new { success = true, arranged = procs.Length };
            }
            catch (Exception ex)
            {
                return new { success = false, message = ex.Message };
            }
        }

        private object ExecuteScriptCode(string script)
        {
            try
            {
                string[] pipes = new string[] { "VoltPipe", "VoltExecutor", "Volt_IPC", "SodaPipe" };
                foreach (var pipe in pipes)
                {
                    try
                    {
                        using (var client = new NamedPipeClientStream(".", pipe, PipeDirection.Out))
                        {
                            client.Connect(35);
                            byte[] b = Encoding.UTF8.GetBytes(script);
                            client.Write(b, 0, b.Length);
                            return new { success = true, message = $"Sent to {pipe}" };
                        }
                    }
                    catch { }
                }

                string autoexecDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "autoexec");
                Directory.CreateDirectory(autoexecDir);
                File.WriteAllText(Path.Combine(autoexecDir, "volt_exec.lua"), script);
                return new { success = true };
            }
            catch (Exception ex)
            {
                return new { success = false, message = ex.Message };
            }
        }

        private object SaveAutoexecScript(string name, string content)
        {
            try
            {
                string autoexecDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "autoexec");
                Directory.CreateDirectory(autoexecDir);
                File.WriteAllText(Path.Combine(autoexecDir, name), content);
                return new { success = true };
            }
            catch (Exception ex)
            {
                return new { success = false, message = ex.Message };
            }
        }

        private void BeginDrag()
        {
            try
            {
                if (InvokeRequired)
                {
                    BeginInvoke((Action)BeginDrag);
                    return;
                }
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, (IntPtr)HTCAPTION, IntPtr.Zero);
            }
            catch { }
        }

        private void ResolveCallback(string callbackId, object? result)
        {
            try
            {
                if (string.IsNullOrEmpty(callbackId) || _webView?.CoreWebView2 == null) return;
                string jsonResult = result != null ? JsonConvert.SerializeObject(result) : "null";
                string script = $"if (window.__TAURI_INTERNALS__ && window.__TAURI_INTERNALS__.callbacks && window.__TAURI_INTERNALS__.callbacks['{callbackId}']) {{ window.__TAURI_INTERNALS__.callbacks['{callbackId}'].resolve({jsonResult}); delete window.__TAURI_INTERNALS__.callbacks['{callbackId}']; }}";
                Invoke((Action)(() => _webView.CoreWebView2.ExecuteScriptAsync(script)));
            }
            catch (Exception ex)
            {
                LogDebug($"ResolveCallback Error: {ex.Message}");
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _server?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
