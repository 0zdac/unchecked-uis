@echo off
start "" "%~dp0Build_Output\Volt.exe"
