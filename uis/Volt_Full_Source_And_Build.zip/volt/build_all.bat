@echo off
echo ===================================================
echo   Compiling Volt Desktop Interface (Tauri 2.0)
echo ===================================================
cargo build --release
if %ERRORLEVEL% NEQ 0 (
    echo [!] Cargo build failed, attempting .NET 4.8 fallback...
    dotnet build -c Release
)
echo Done!
pause
