use serde::{Deserialize, Serialize};
use std::fs;
use std::path::PathBuf;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct RobloxAccount {
    pub id: String,
    pub username: String,
    pub display_name: String,
    pub user_id: u64,
    pub status: String,
}

fn get_accounts_path() -> PathBuf {
    PathBuf::from("accounts.json")
}

#[tauri::command]
pub async fn get_accounts() -> Result<Vec<RobloxAccount>, String> {
    let path = get_accounts_path();
    if path.exists() {
        let content = fs::read_to_string(path).map_err(|e| e.to_string())?;
        let accounts: Vec<RobloxAccount> = serde_json::from_str(&content).unwrap_or_default();
        return Ok(accounts);
    }

    Ok(vec![RobloxAccount {
        id: "1".to_string(),
        username: "VoltOperator".to_string(),
        display_name: "Volt Operator".to_string(),
        user_id: 10001,
        status: "Ready".to_string(),
    }])
}

#[tauri::command]
pub async fn add_account(account: RobloxAccount) -> Result<bool, String> {
    let mut accounts = get_accounts().await?;
    accounts.push(account);
    let json = serde_json::to_string_pretty(&accounts).map_err(|e| e.to_string())?;
    fs::write(get_accounts_path(), json).map_err(|e| e.to_string())?;
    Ok(true)
}

#[tauri::command]
pub async fn remove_account(id: String) -> Result<bool, String> {
    let mut accounts = get_accounts().await?;
    accounts.retain(|a| a.id != id);
    let json = serde_json::to_string_pretty(&accounts).map_err(|e| e.to_string())?;
    fs::write(get_accounts_path(), json).map_err(|e| e.to_string())?;
    Ok(true)
}

#[tauri::command]
pub async fn launch_account(id: String, username: Option<String>) -> Result<serde_json::Value, String> {
    Ok(serde_json::json!({
        "success": true,
        "id": id,
        "username": username.unwrap_or_else(|| "VoltPlayer".to_string()),
        "ticket": uuid::Uuid::new_v4().to_string()
    }))
}

#[tauri::command]
pub async fn get_roblox_cookies() -> Result<serde_json::Value, String> {
    let local_app_data = std::env::var("LOCALAPPDATA").unwrap_or_default();
    let cookie_path = PathBuf::from(local_app_data)
        .join("Roblox")
        .join("LocalStorage")
        .join("RobloxCookies.dat");

    if cookie_path.exists() {
        Ok(serde_json::json!({
            "success": true,
            "found": true,
            "path": cookie_path.to_string_lossy()
        }))
    } else {
        Ok(serde_json::json!({
            "success": false,
            "found": false
        }))
    }
}
