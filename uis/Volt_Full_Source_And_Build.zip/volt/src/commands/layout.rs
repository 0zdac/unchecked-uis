use serde::Serialize;
use windows_sys::Win32::UI::WindowsAndMessaging::{FindWindowA, SetWindowPos, SWP_NOZORDER, SWP_SHOWWINDOW, GetSystemMetrics, SM_CXSCREEN, SM_CYSCREEN};

#[derive(Debug, Serialize)]
pub struct LayoutResult {
    pub success: bool,
    pub message: String,
    pub arranged: usize,
}

#[tauri::command]
pub async fn apply_window_layout(preset: String) -> Result<LayoutResult, String> {
    unsafe {
        let screen_w = GetSystemMetrics(SM_CXSCREEN);
        let screen_h = GetSystemMetrics(SM_CYSCREEN);

        let (cols, rows) = match preset.as_str() {
            "1x2" => (2, 1),
            "3x2" => (3, 2),
            "4x2" => (4, 2),
            _ => (2, 2),
        };

        let tile_w = screen_w / cols;
        let tile_h = screen_h / rows;

        let title = b"Roblox\0";
        let hwnd = FindWindowA(std::ptr::null(), title.as_ptr());
        
        let mut count = 0;
        if hwnd != 0 {
            SetWindowPos(hwnd, 0, 0, 0, tile_w, tile_h, SWP_NOZORDER | SWP_SHOWWINDOW);
            count = 1;
        }

        Ok(LayoutResult {
            success: true,
            message: "Window arrangement preview computed.".to_string(),
            arranged: count,
        })
    }
}
