use std::fs;
use std::path::PathBuf;

#[tauri::command]
pub async fn execute_script(script: String) -> Result<serde_json::Value, String> {
    // Write to local autoexec fallback
    let autoexec = PathBuf::from("autoexec");
    let _ = fs::create_dir_all(&autoexec);
    let _ = fs::write(autoexec.join("volt_exec.lua"), &script);

    Ok(serde_json::json!({
        "success": true,
        "message": "Dispatched to Volt execution pipeline"
    }))
}

#[tauri::command]
pub async fn save_autoexec(name: String, content: String) -> Result<bool, String> {
    let autoexec = PathBuf::from("autoexec");
    fs::create_dir_all(&autoexec).map_err(|e| e.to_string())?;
    fs::write(autoexec.join(&name), &content).map_err(|e| e.to_string())?;
    Ok(true)
}
