use std::fs;
use std::path::PathBuf;

#[tauri::command]
pub async fn load_settings() -> Result<String, String> {
    let p = PathBuf::from("volt_settings.json");
    if p.exists() {
        fs::read_to_string(p).map_err(|e| e.to_string())
    } else {
        Ok("{}".to_string())
    }
}

#[tauri::command]
pub async fn save_settings(settings: serde_json::Value) -> Result<bool, String> {
    let p = PathBuf::from("volt_settings.json");
    let json = serde_json::to_string_pretty(&settings).map_err(|e| e.to_string())?;
    fs::write(p, json).map_err(|e| e.to_string())?;
    Ok(true)
}

#[tauri::command]
pub async fn get_engine_status() -> Result<serde_json::Value, String> {
    Ok(serde_json::json!({
        "engine": "Volt v2.11.5",
        "supportedRobloxVersion": "version-4a5e1e0b0e5b4c9e",
        "activeInstances": "0 Active",
        "autoRelaunch": true
    }))
}
