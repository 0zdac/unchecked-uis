#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod commands;

use tauri::Manager;

#[tokio::main]
async fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _argv, _cwd| {
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.show();
                let _ = window.set_focus();
            }
        }))
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_os::init())
        .plugin(tauri_plugin_process::init())
        .invoke_handler(tauri::generate_handler![
            commands::account_manager::get_accounts,
            commands::account_manager::add_account,
            commands::account_manager::remove_account,
            commands::account_manager::launch_account,
            commands::account_manager::get_roblox_cookies,
            commands::layout::apply_window_layout,
            commands::script::execute_script,
            commands::script::save_autoexec,
            commands::settings::load_settings,
            commands::settings::save_settings,
            commands::settings::get_engine_status,
        ])
        .run(tauri::generate_context!())
        .expect("error while running Volt desktop application");
}
