#include <windows.h>
#include <dwmapi.h>
#include <d3d11.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>

#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"
#include "imgui/backends/imgui_impl_win32.h"
#include "imgui/backends/imgui_impl_dx11.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dwmapi.lib")

// ===================== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ =====================
static ID3D11Device* g_pd3dDevice = nullptr;
static ID3D11DeviceContext* g_pd3dDeviceContext = nullptr;
static IDXGISwapChain* g_pSwapChain = nullptr;
static ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;
static HWND g_hWnd = nullptr;

bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// ===================== СОСТОЯНИЕ МЕНЮ =====================
bool   g_MenuOpen = true;
ImVec2 g_MenuPos = ImVec2(0, 0);
ImVec2 g_MenuSize = ImVec2(920, 600);
bool   g_PosInit = false;
bool   g_WantTopMost = false;

// ===================== ЦВЕТА =====================
#define COL_BG         ImVec4(0.06f, 0.06f, 0.06f, 1.00f)
#define COL_PANEL      ImVec4(0.09f, 0.09f, 0.09f, 1.00f)
#define COL_ACCENT     ImVec4(0.96f, 0.44f, 0.64f, 1.00f)
#define COL_TEXT       ImVec4(0.90f, 0.90f, 0.90f, 1.00f)
#define COL_TEXT_MUTED ImVec4(0.50f, 0.50f, 0.50f, 1.00f)
#define COL_BORDER     ImVec4(0.12f, 0.12f, 0.12f, 1.00f)

// ===================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ =====================
inline ImU32 Color(const ImVec4& v) { return ImGui::ColorConvertFloat4ToU32(v); }

inline ImVec4 Mix(const ImVec4& a, const ImVec4& b, float t) {
    t = std::clamp(t, 0.0f, 1.0f);
    return ImVec4(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t);
}

inline float AnimateFloat(ImGuiID id, float target, float speed = 10.0f) {
    ImGuiStorage* st = ImGui::GetStateStorage();
    float cur = st->GetFloat(id, target);
    float step = std::clamp(ImGui::GetIO().DeltaTime * speed, 0.0f, 1.0f);
    float next = cur + (target - cur) * step;
    st->SetFloat(id, next);
    return next;
}

// ===================== УПРАВЛЕНИЕ ОКНОМ =====================
void SetOverlayTopMost(bool enabled) {
    if (!g_hWnd) return;
    g_WantTopMost = enabled;
    SetWindowPos(g_hWnd, enabled ? HWND_TOPMOST : HWND_NOTOPMOST,
        0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

void UpdateClickThrough() {
    if (!g_hWnd) return;

    LONG_PTR ex = GetWindowLongPtr(g_hWnd, GWL_EXSTYLE);

    if (!g_MenuOpen) {
        if ((ex & WS_EX_TRANSPARENT) == 0)
            SetWindowLongPtr(g_hWnd, GWL_EXSTYLE, ex | WS_EX_TRANSPARENT);
        SetWindowRgn(g_hWnd, nullptr, TRUE);
        SetOverlayTopMost(false);
        ShowWindow(g_hWnd, SW_HIDE);
        return;
    }

    if (ex & WS_EX_TRANSPARENT)
        SetWindowLongPtr(g_hWnd, GWL_EXSTYLE, ex & ~WS_EX_TRANSPARENT);

    int x1 = (int)g_MenuPos.x;
    int y1 = (int)g_MenuPos.y;
    int x2 = (int)(g_MenuPos.x + g_MenuSize.x);
    int y2 = (int)(g_MenuPos.y + g_MenuSize.y);
    HRGN rgn = CreateRectRgn(x1, y1, x2, y2);
    SetWindowRgn(g_hWnd, rgn, TRUE);
}

// Исправленная логика: topmost ТОЛЬКО когда наше окно активно
void UpdateFocusBehaviour() {
    if (!g_hWnd || !g_MenuOpen) return;

    HWND fg = GetForegroundWindow();
    DWORD pidFg = 0, pidSelf = GetCurrentProcessId();
    if (fg) GetWindowThreadProcessId(fg, &pidFg);

    bool isSelf = (pidFg == pidSelf);

    if (isSelf) {
        ShowWindow(g_hWnd, SW_SHOW);
        SetOverlayTopMost(true);
    }
    else {
        ShowWindow(g_hWnd, SW_SHOW);
        SetOverlayTopMost(false);
        SetWindowPos(g_hWnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    }
}

// ===================== ИКОНКИ ДЛЯ ВКЛАДОК =====================
enum class IconType {
    None,
    Aim,        // Перекрестие
    Trigger,    // Молния
    Player,     // Человечек
    World,      // Глобус
    Inventory,  // Рюкзак
    Exploit,    // Взрыв
    Misc,       // Точки
    Radar,      // Радар
    Config,     // Шестеренка
    Gear        // Шестеренка (для прочих)
};

void DrawIcon(ImDrawList* draw, IconType icon, ImVec2 pos, float size, ImU32 color) {
    const float half = size * 0.5f;
    const ImVec2 c(pos.x + half, pos.y + half);

    switch (icon) {
    case IconType::Aim: {
        draw->AddLine(ImVec2(pos.x + half, pos.y), ImVec2(pos.x + half, pos.y + size), color, 1.5f);
        draw->AddLine(ImVec2(pos.x, pos.y + half), ImVec2(pos.x + size, pos.y + half), color, 1.5f);
        draw->AddCircle(c, size * 0.3f, color, 16, 1.5f);
        draw->AddCircleFilled(c, size * 0.05f, color);
        break;
    }
    case IconType::Trigger: {
        ImVec2 pts[4] = {
            { pos.x + size * 0.6f, pos.y },
            { pos.x + size * 0.2f, pos.y + size * 0.6f },
            { pos.x + size * 0.45f, pos.y + size * 0.6f },
            { pos.x + size * 0.4f, pos.y + size }
        };
        draw->AddPolyline(pts, 4, color, ImDrawFlags_Closed, 1.8f);
        break;
    }
    case IconType::Player: {
        float headR = size * 0.12f;
        draw->AddCircleFilled(ImVec2(c.x, pos.y + headR + size * 0.1f), headR, color, 12);
        draw->AddLine(ImVec2(c.x, pos.y + headR + size * 0.2f), ImVec2(c.x, pos.y + size * 0.7f), color, 1.8f);
        draw->AddLine(ImVec2(c.x, pos.y + size * 0.4f), ImVec2(c.x - size * 0.2f, pos.y + size * 0.55f), color, 1.5f);
        draw->AddLine(ImVec2(c.x, pos.y + size * 0.4f), ImVec2(c.x + size * 0.2f, pos.y + size * 0.55f), color, 1.5f);
        draw->AddLine(ImVec2(c.x, pos.y + size * 0.7f), ImVec2(c.x - size * 0.2f, pos.y + size - size * 0.05f), color, 1.5f);
        draw->AddLine(ImVec2(c.x, pos.y + size * 0.7f), ImVec2(c.x + size * 0.2f, pos.y + size - size * 0.05f), color, 1.5f);
        break;
    }
    case IconType::World: {
        draw->AddCircle(c, size * 0.45f, color, 24, 1.5f);
        draw->AddLine(ImVec2(pos.x + size * 0.1f, c.y - size * 0.25f), ImVec2(pos.x + size * 0.9f, c.y - size * 0.25f), color, 1.0f);
        draw->AddLine(ImVec2(pos.x + size * 0.1f, c.y + size * 0.25f), ImVec2(pos.x + size * 0.9f, c.y + size * 0.25f), color, 1.0f);
        draw->AddLine(ImVec2(pos.x, c.y), ImVec2(pos.x + size, c.y), color, 1.0f);
        break;
    }
    case IconType::Inventory: {
        float w = size * 0.5f, h = size * 0.7f;
        draw->AddRect(ImVec2(c.x - w / 2, c.y - h / 2), ImVec2(c.x + w / 2, c.y + h / 2), color, size * 0.1f, ImDrawFlags_None, 1.5f);
        draw->AddLine(ImVec2(c.x - w * 0.2f, c.y - h / 2), ImVec2(c.x - w * 0.2f, c.y - h / 2 - size * 0.1f), color, 1.5f);
        draw->AddLine(ImVec2(c.x + w * 0.2f, c.y - h / 2), ImVec2(c.x + w * 0.2f, c.y - h / 2 - size * 0.1f), color, 1.5f);
        break;
    }
    case IconType::Exploit: {
        draw->AddCircleFilled(c, size * 0.3f, color, 16);
        draw->AddCircleFilled(ImVec2(pos.x + size * 0.7f, pos.y + size * 0.2f), size * 0.08f, color, 8);
        draw->AddLine(ImVec2(pos.x + size * 0.7f, pos.y + size * 0.2f), ImVec2(pos.x + size * 0.8f, pos.y + size * 0.45f), color, 1.5f);
        break;
    }
    case IconType::Misc: {
        draw->AddCircleFilled(ImVec2(pos.x + size * 0.2f, c.y), size * 0.12f, color, 8);
        draw->AddCircleFilled(c, size * 0.12f, color, 8);
        draw->AddCircleFilled(ImVec2(pos.x + size * 0.8f, c.y), size * 0.12f, color, 8);
        break;
    }
    case IconType::Radar: {
        draw->AddCircle(c, size * 0.4f, color, 24, 1.5f);
        draw->AddLine(ImVec2(pos.x, c.y), ImVec2(pos.x + size, c.y), color, 1.0f);
        draw->AddLine(ImVec2(c.x, pos.y), ImVec2(c.x, pos.y + size), color, 1.0f);
        draw->AddCircleFilled(ImVec2(c.x + size * 0.15f, c.y - size * 0.1f), size * 0.08f, color, 8);
        break;
    }
    case IconType::Config:
    case IconType::Gear: {
        float outer = size * 0.4f;
        draw->AddCircle(c, outer, color, 16, 2.0f);
        draw->AddCircle(c, outer * 0.6f, color, 16, 1.0f);
        draw->AddCircleFilled(c, outer * 0.2f, color, 8);
        const int teeth = 6;
        for (int i = 0; i < teeth; i++) {
            float ang = i * (2.f * 3.1415926f / teeth);
            ImVec2 p1(c.x + cosf(ang) * outer, c.y + sinf(ang) * outer);
            ImVec2 p2(c.x + cosf(ang) * (outer + size * 0.12f), c.y + sinf(ang) * (outer + size * 0.12f));
            draw->AddLine(p1, p2, color, 1.5f);
        }
        break;
    }
    default:
        draw->AddCircle(c, half, color, 12, 1.5f);
        break;
    }
}

// ===================== КАСТОМНЫЙ ПЕРЕКЛЮЧАТЕЛЬ =====================
bool AnimatedToggle(const char* label, bool* value) {
    ImGui::PushID(label);
    ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = 36.0f, h = 20.0f, r = h * 0.5f;

    ImGui::InvisibleButton(label, ImVec2(w, h));
    if (ImGui::IsItemClicked()) *value = !*value;

    float anim = AnimateFloat(ImGui::GetID("tog"), *value ? 1.0f : 0.0f, 12.0f);
    ImDrawList* dl = ImGui::GetWindowDrawList();

    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h),
        Color(Mix(ImVec4(0.20f, 0.20f, 0.20f, 1.0f), COL_ACCENT, anim)), r);
    dl->AddCircleFilled(ImVec2(p.x + r + anim * (w - r * 2.0f), p.y + r),
        r - 2.0f, IM_COL32(255, 255, 255, 255));

    ImGui::PopID();
    return *value;
}

// ===================== ОТРИСОВКА ИНТЕРФЕЙСА =====================
void RenderUI() {
    if (!g_MenuOpen) return;

    ImGuiIO& io = ImGui::GetIO();

    if (!g_PosInit) {
        g_MenuPos = ImVec2((io.DisplaySize.x - g_MenuSize.x) * 0.5f,
            (io.DisplaySize.y - g_MenuSize.y) * 0.5f);
        g_PosInit = true;
    }

    ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
    ImGui::SetNextWindowSize(io.DisplaySize, ImGuiCond_Always);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::Begin("##overlay_host", nullptr,
        ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoDecoration |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNav);

    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 menuMax(g_MenuPos.x + g_MenuSize.x, g_MenuPos.y + g_MenuSize.y);
    const float topBarH = 60.0f;

    static bool dragging = false;
    static ImVec2 dragOff;

    ImRect headerHit(g_MenuPos, ImVec2(menuMax.x - 50.0f, g_MenuPos.y + topBarH));
    ImRect searchBlock(ImVec2(g_MenuPos.x + 55, g_MenuPos.y + 10), ImVec2(g_MenuPos.x + 270, g_MenuPos.y + 50));

    if (ImGui::IsMouseClicked(0)) {
        ImVec2 mp = io.MousePos;
        if (headerHit.Contains(mp) && !searchBlock.Contains(mp)) {
            dragging = true;
            dragOff = ImVec2(mp.x - g_MenuPos.x, mp.y - g_MenuPos.y);
        }
    }
    if (dragging) {
        if (ImGui::IsMouseDown(0)) {
            g_MenuPos = ImVec2(io.MousePos.x - dragOff.x, io.MousePos.y - dragOff.y);
            g_MenuPos.x = std::clamp(g_MenuPos.x, -g_MenuSize.x + 80.0f, io.DisplaySize.x - 80.0f);
            g_MenuPos.y = std::clamp(g_MenuPos.y, 0.0f, io.DisplaySize.y - 40.0f);
            menuMax = ImVec2(g_MenuPos.x + g_MenuSize.x, g_MenuPos.y + g_MenuSize.y);
        }
        else { dragging = false; }
    }

    draw->AddRectFilled(g_MenuPos, menuMax, Color(COL_BG), 12.0f);
    draw->AddRect(g_MenuPos, menuMax, Color(COL_BORDER), 12.0f, 0, 1.0f);
    draw->AddLine(ImVec2(g_MenuPos.x, g_MenuPos.y + topBarH), ImVec2(menuMax.x, g_MenuPos.y + topBarH), Color(COL_BORDER));

    // Верхняя панель
    draw->AddText(io.Fonts->Fonts[0], 16.0f, ImVec2(g_MenuPos.x + 20, g_MenuPos.y + 22), Color(COL_ACCENT), "|||");

    ImGui::SetCursorScreenPos(ImVec2(g_MenuPos.x + 60, g_MenuPos.y + 15));
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.09f, 0.09f, 0.09f, 1.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 6.0f);
    ImGui::PushItemWidth(200);
    static char search[64] = {};
    ImGui::InputTextWithHint("##search", "Search functions...", search, sizeof(search));
    ImGui::PopItemWidth();
    ImGui::PopStyleVar();
    ImGui::PopStyleColor();

    const char* title = "* aimstar";
    ImVec2 ts = ImGui::CalcTextSize(title);
    draw->AddText(io.Fonts->Fonts[0], 18.0f, ImVec2(g_MenuPos.x + (g_MenuSize.x - ts.x) * 0.5f, g_MenuPos.y + 20), Color(COL_TEXT), title);

    // Кнопка закрытия - теперь завершает приложение
    ImGui::SetCursorScreenPos(ImVec2(menuMax.x - 35, g_MenuPos.y + 18));
    if (ImGui::InvisibleButton("##close", ImVec2(22, 22))) {
        io.MouseDrawCursor = false;
        PostQuitMessage(0);
        ImGui::End();
        ImGui::PopStyleVar();
        return;
    }
    draw->AddText(io.Fonts->Fonts[0], 16.0f, ImVec2(menuMax.x - 30, g_MenuPos.y + 20), Color(COL_TEXT_MUTED), "X");

    // Боковое меню
    const float sidebarW = 160.0f;
    draw->AddLine(ImVec2(g_MenuPos.x + sidebarW, g_MenuPos.y + topBarH), ImVec2(g_MenuPos.x + sidebarW, menuMax.y), Color(COL_BORDER));

    struct TabGroup {
        const char* name;
        std::vector<const char*> items;
        std::vector<IconType> icons;
    };
    static TabGroup groups[] = {
        { "Combat", { "Aim-Assist", "Trigger-Bot" }, { IconType::Aim, IconType::Trigger } },
        { "Visual", { "Players", "World", "Inventory", "Exploit", "Miscellaneous" },
                     { IconType::Player, IconType::World, IconType::Inventory, IconType::Exploit, IconType::Misc } },
        { "Cloud",  { "Radar", "Config" }, { IconType::Radar, IconType::Config } }
    };
    static int activeGroup = 1, activeTab = 0;

    float cy = g_MenuPos.y + topBarH + 15.0f;
    for (int g = 0; g < 3; ++g) {
        draw->AddText(io.Fonts->Fonts[0], 14.0f, ImVec2(g_MenuPos.x + 15, cy), Color(COL_TEXT_MUTED), groups[g].name);
        cy += 25.0f;

        for (int i = 0; i < (int)groups[g].items.size(); ++i) {
            bool sel = (activeGroup == g && activeTab == i);
            float anim = AnimateFloat(ImGui::GetID(groups[g].items[i]), sel ? 1.0f : 0.0f, 10.0f);

            ImVec2 ip(g_MenuPos.x + 10, cy);
            if (anim > 0.01f)
                draw->AddRectFilled(ip, ImVec2(ip.x + 140, ip.y + 30), Color(Mix(COL_BG, COL_PANEL, anim)), 6.0f);

            ImGui::SetCursorScreenPos(ip);
            if (ImGui::InvisibleButton(groups[g].items[i], ImVec2(140, 30))) { activeGroup = g; activeTab = i; }

            DrawIcon(draw, groups[g].icons[i], ImVec2(ip.x + 8, ip.y + 7), 16.0f, Color(sel ? COL_ACCENT : COL_TEXT_MUTED));
            draw->AddText(io.Fonts->Fonts[0], 15.0f, ImVec2(ip.x + 28, ip.y + 6), Color(Mix(COL_TEXT_MUTED, COL_TEXT, anim)), groups[g].items[i]);
            cy += 35.0f;
        }
        cy += 10.0f;
    }

    draw->AddRectFilled(ImVec2(g_MenuPos.x + 10, menuMax.y - 60), ImVec2(g_MenuPos.x + sidebarW - 10, menuMax.y - 10), Color(COL_PANEL), 8.0f);
    draw->AddText(io.Fonts->Fonts[0], 14.0f, ImVec2(g_MenuPos.x + 20, menuMax.y - 50), Color(COL_TEXT), "@fuckingboy");
    draw->AddText(io.Fonts->Fonts[0], 13.0f, ImVec2(g_MenuPos.x + 20, menuMax.y - 32), Color(COL_ACCENT), "10 days left");

    // Настройки (центр)
    float panelX = g_MenuPos.x + sidebarW + 20.0f;
    float panelY = g_MenuPos.y + topBarH + 20.0f;
    draw->AddText(io.Fonts->Fonts[0], 14.0f, ImVec2(panelX, panelY), Color(COL_TEXT_MUTED), "PLAYER ESP");

    ImGui::SetCursorScreenPos(ImVec2(panelX, panelY + 25.0f));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, COL_PANEL);
    ImGui::PushStyleColor(ImGuiCol_Border, COL_BORDER);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 8.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12, 10));
    ImGui::BeginChild("##settings", ImVec2(340, g_MenuSize.y - topBarH - 65), true, ImGuiWindowFlags_NoScrollbar);

    struct Setting { const char* name; bool state; bool hasCol; ImVec4 col; bool gear; };
    static Setting settings[] = {
        { "Target bar",            false, false, ImVec4(),     true  },
        { "Hit damage indicator",  true,  false, ImVec4(),     false },
        { "Kill sound",            false, false, ImVec4(),     true  },
        { "Hit marker",            true,  true,  COL_ACCENT,   true  },
        { "Skeleton",              false, true,  ImVec4(1,1,1,1), true },
        { "Player material",       true,  true,  COL_ACCENT,   true  },
        { "Arms",                  true,  true,  COL_ACCENT,   true  },
        { "Viewmodel",             true,  false, ImVec4(),     true  },
        { "Custom crosshair",      true,  true,  COL_ACCENT,   false },
        { "Hitbox",                false, true,  ImVec4(1,1,1,1), true },
        { "Bullet tracer",         false, true,  COL_ACCENT,   true  },
    };

    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
    for (int i = 0; i < IM_ARRAYSIZE(settings); ++i) {
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);
        ImGui::TextUnformatted(settings[i].name);

        ImGui::SameLine(210);
        if (settings[i].gear) ImGui::TextColored(COL_TEXT_MUTED, "*");
        else ImGui::Dummy(ImVec2(10, 1));

        ImGui::SameLine(235);
        if (settings[i].hasCol) {
            ImGui::ColorEdit4(("##c" + std::to_string(i)).c_str(), (float*)&settings[i].col,
                ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_NoTooltip);
        }
        else { ImGui::Dummy(ImVec2(24, 1)); }

        ImGui::SameLine(280);
        AnimatedToggle(("##t" + std::to_string(i)).c_str(), &settings[i].state);

        if (i + 1 < IM_ARRAYSIZE(settings)) {
            ImVec2 cp = ImGui::GetCursorScreenPos();
            ImGui::GetWindowDrawList()->AddLine(ImVec2(cp.x, cp.y + 4), ImVec2(cp.x + 310, cp.y + 4), Color(COL_BORDER));
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 8.0f);
        }
    }
    ImGui::PopStyleVar();
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);

    // Превью (справа)
    float previewX = panelX + 360.0f;
    draw->AddText(io.Fonts->Fonts[0], 14.0f, ImVec2(previewX, panelY), Color(COL_TEXT_MUTED), "PREVIEW");

    ImVec2 pMin(previewX, panelY + 25.0f);
    ImVec2 pMax(previewX + 340, menuMax.y - 20.0f);
    draw->AddRectFilled(pMin, pMax, Color(COL_PANEL), 8.0f);
    draw->AddRect(pMin, pMax, Color(COL_BORDER), 8.0f, 0, 1.0f);

    float boxW = 160.0f, boxH = 320.0f;
    ImVec2 bMin(pMin.x + 90, pMin.y + 60);
    ImVec2 bMax(bMin.x + boxW, bMin.y + boxH);
    float len = 15.0f, th = 2.0f;
    ImU32 cPink = Color(COL_ACCENT), cWhite = IM_COL32(255, 255, 255, 255);

    auto corner = [&](ImVec2 a, ImVec2 b1, ImVec2 b2, ImU32 c) { draw->AddLine(a, b1, c, th); draw->AddLine(a, b2, c, th); };
    corner(bMin, ImVec2(bMin.x + len, bMin.y), ImVec2(bMin.x, bMin.y + len), cPink);
    corner(ImVec2(bMax.x, bMin.y), ImVec2(bMax.x - len, bMin.y), ImVec2(bMax.x, bMin.y + len), cPink);
    corner(ImVec2(bMin.x, bMax.y), ImVec2(bMin.x + len, bMax.y), ImVec2(bMin.x, bMax.y - len), cWhite);
    corner(bMax, ImVec2(bMax.x - len, bMax.y), ImVec2(bMax.x, bMax.y - len), cPink);

    draw->AddRectFilled(ImVec2(bMin.x - 8, bMin.y), ImVec2(bMin.x - 5, bMax.y), IM_COL32(50, 50, 50, 255));
    draw->AddRectFilled(ImVec2(bMin.x - 8, bMin.y + 120), ImVec2(bMin.x - 5, bMax.y), cPink);
    draw->AddRectFilled(ImVec2(bMin.x + boxW * 0.5f - 35, bMin.y - 30), ImVec2(bMin.x + boxW * 0.5f - 15, bMin.y - 10), cPink, 4.0f);

    draw->AddText(io.Fonts->Fonts[0], 14.0f, ImVec2(bMin.x + boxW * 0.5f - 10, bMin.y - 25), cWhite, "PREVIEW");
    draw->AddText(io.Fonts->Fonts[0], 13.0f, ImVec2(bMax.x + 8, bMin.y + 10), cWhite, "35m");
    draw->AddText(io.Fonts->Fonts[0], 13.0f, ImVec2(bMax.x + 8, bMin.y + 25), Color(COL_TEXT_MUTED), "DEVICE");
    draw->AddText(io.Fonts->Fonts[0], 13.0f, ImVec2(bMax.x + 8, bMin.y + 40), cPink, "28 ms");

    ImGui::End();
    ImGui::PopStyleVar();
}

// ===================== ТОЧКА ВХОДА MAIN И DIRECTX =====================
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(HINSTANCE hInstance, HINSTANCE, LPWSTR, int) {
    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0, 0, GetModuleHandle(nullptr),
                       nullptr, nullptr, nullptr, nullptr, L"AimstarOverlay", nullptr };
    RegisterClassExW(&wc);

    g_hWnd = CreateWindowExW(
        WS_EX_LAYERED | WS_EX_APPWINDOW,
        wc.lpszClassName,
        L"Aimstar Overlay",
        WS_POPUP,
        0, 0,
        GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
        nullptr, nullptr, wc.hInstance, nullptr
    );

    SetLayeredWindowAttributes(g_hWnd, 0, 255, LWA_ALPHA);
    MARGINS m = { -1 };
    DwmExtendFrameIntoClientArea(g_hWnd, &m);

    if (!CreateDeviceD3D(g_hWnd)) {
        CleanupDeviceD3D();
        UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return 1;
    }

    ShowWindow(g_hWnd, SW_SHOWDEFAULT);
    UpdateWindow(g_hWnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.MouseDrawCursor = true;

    ImFontConfig cfg;
    cfg.OversampleH = 3;
    cfg.OversampleV = 3;
    io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\arial.ttf", 16.0f, &cfg, io.Fonts->GetGlyphRangesCyrillic());

    ImGui_ImplWin32_Init(g_hWnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    UpdateClickThrough();

    bool done = false;
    while (!done) {
        MSG msg;
        while (PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;

        if (GetAsyncKeyState(VK_INSERT) & 1) {
            g_MenuOpen = !g_MenuOpen;
            io.MouseDrawCursor = g_MenuOpen;
            UpdateClickThrough();
        }

        if (g_MenuOpen) {
            UpdateClickThrough();
            UpdateFocusBehaviour();
        }

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        RenderUI();

        ImGui::Render();
        const float clear[4] = { 0, 0, 0, 0 };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_pSwapChain->Present(1, 0);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupDeviceD3D();
    DestroyWindow(g_hWnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);
    return 0;
}

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg) {
    case WM_SIZE:
        if (g_pd3dDevice && wParam != SIZE_MINIMIZED) {
            CleanupRenderTarget();
            g_pSwapChain->ResizeBuffers(0, LOWORD(lParam), HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
            CreateRenderTarget();
        }
        return 0;

    case WM_CLOSE:
        DestroyWindow(hWnd);
        return 0;

    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU)
            return 0;
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

// ===================== DIRECTX БОЙЛЕРПЛЕЙТ =====================
bool CreateDeviceD3D(HWND hWnd) {
    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate = { 60, 1 };
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL fl;
    const D3D_FEATURE_LEVEL fls[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };

    if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, fls, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &fl, &g_pd3dDeviceContext)))
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D() {
    CleanupRenderTarget();
    if (g_pSwapChain) {
        g_pSwapChain->Release();
        g_pSwapChain = nullptr;
    }
    if (g_pd3dDeviceContext) {
        g_pd3dDeviceContext->Release();
        g_pd3dDeviceContext = nullptr;
    }
    if (g_pd3dDevice) {
        g_pd3dDevice->Release();
        g_pd3dDevice = nullptr;
    }
}

void CreateRenderTarget() {
    ID3D11Texture2D* bb = nullptr;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&bb));
    if (bb) {
        g_pd3dDevice->CreateRenderTargetView(bb, nullptr, &g_mainRenderTargetView);
        bb->Release();
    }
}

void CleanupRenderTarget() {
    if (g_mainRenderTargetView) {
        g_mainRenderTargetView->Release();
        g_mainRenderTargetView = nullptr;
    }
}