
// this file is generated — do not edit it


/// <reference types="@sveltejs/kit" />

/**
 * Environment variables [loaded by Vite](https://vitejs.dev/guide/env-and-mode.html#env-files) from `.env` files and `process.env`. Like [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), this module cannot be imported into client-side code. This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured).
 * 
 * _Unlike_ [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), the values exported from this module are statically injected into your bundle at build time, enabling optimisations like dead code elimination.
 * 
 * ```ts
 * import { API_KEY } from '$env/static/private';
 * ```
 * 
 * Note that all environment variables referenced in your code should be declared (for example in an `.env` file), even if they don't have a value until the app is deployed:
 * 
 * ```
 * MY_FEATURE_FLAG=""
 * ```
 * 
 * You can override `.env` values from the command line like so:
 * 
 * ```bash
 * MY_FEATURE_FLAG="enabled" npm run dev
 * ```
 */
declare module '$env/static/private' {
	export const PYCHARM_VM_OPTIONS: string;
	export const WEBIDE_VM_OPTIONS: string;
	export const TERM_PROGRAM: string;
	export const NODE: string;
	export const INIT_CWD: string;
	export const JETBRAINSCLIENT_VM_OPTIONS: string;
	export const SHELL: string;
	export const TERM: string;
	export const TMPDIR: string;
	export const npm_config_global_prefix: string;
	export const TERM_PROGRAM_VERSION: string;
	export const TAURI_CLI_VERBOSITY: string;
	export const COLOR: string;
	export const TAURI_ENV_DEBUG: string;
	export const TERM_SESSION_ID: string;
	export const npm_config_noproxy: string;
	export const npm_config_local_prefix: string;
	export const USER: string;
	export const TAURI_ENV_TARGET_TRIPLE: string;
	export const npm_config_globalconfig: string;
	export const PHPSTORM_VM_OPTIONS: string;
	export const SSH_AUTH_SOCK: string;
	export const __CF_USER_TEXT_ENCODING: string;
	export const GOLAND_VM_OPTIONS: string;
	export const npm_execpath: string;
	export const APPCODE_VM_OPTIONS: string;
	export const TAURI_ENV_PLATFORM: string;
	export const DEVECOSTUDIO_VM_OPTIONS: string;
	export const PATH: string;
	export const RUSTROVER_VM_OPTIONS: string;
	export const LaunchInstanceID: string;
	export const _: string;
	export const npm_package_json: string;
	export const TAURI_ENV_FAMILY: string;
	export const TAURI_ENV_PLATFORM_VERSION: string;
	export const __CFBundleIdentifier: string;
	export const npm_config_init_module: string;
	export const npm_config_userconfig: string;
	export const PWD: string;
	export const npm_command: string;
	export const EDITOR: string;
	export const npm_lifecycle_event: string;
	export const CLION_VM_OPTIONS: string;
	export const IDEA_VM_OPTIONS: string;
	export const LANG: string;
	export const npm_package_name: string;
	export const XPC_FLAGS: string;
	export const npm_config_npm_version: string;
	export const TAURI_ENV_ARCH: string;
	export const WEBSTORM_VM_OPTIONS: string;
	export const DATASPELL_VM_OPTIONS: string;
	export const npm_config_node_gyp: string;
	export const XPC_SERVICE_NAME: string;
	export const npm_package_version: string;
	export const HOME: string;
	export const SHLVL: string;
	export const STUDIO_VM_OPTIONS: string;
	export const LOGNAME: string;
	export const MACOSX_DEPLOYMENT_TARGET: string;
	export const npm_config_cache: string;
	export const npm_lifecycle_script: string;
	export const GATEWAY_VM_OPTIONS: string;
	export const DATAGRIP_VM_OPTIONS: string;
	export const npm_config_user_agent: string;
	export const JETBRAINS_CLIENT_VM_OPTIONS: string;
	export const OSLogRateLimit: string;
	export const RIDER_VM_OPTIONS: string;
	export const RUBYMINE_VM_OPTIONS: string;
	export const SECURITYSESSIONID: string;
	export const COLORTERM: string;
	export const npm_config_prefix: string;
	export const npm_node_execpath: string;
	export const NODE_ENV: string;
}

/**
 * Similar to [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private), except that it only includes environment variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`), and can therefore safely be exposed to client-side code.
 * 
 * Values are replaced statically at build time.
 * 
 * ```ts
 * import { PUBLIC_BASE_URL } from '$env/static/public';
 * ```
 */
declare module '$env/static/public' {
	
}

/**
 * This module provides access to runtime environment variables, as defined by the platform you're running on. For example if you're using [`adapter-node`](https://github.com/sveltejs/kit/tree/main/packages/adapter-node) (or running [`vite preview`](https://svelte.dev/docs/kit/cli)), this is equivalent to `process.env`. This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured).
 * 
 * This module cannot be imported into client-side code.
 * 
 * Dynamic environment variables cannot be used during prerendering.
 * 
 * ```ts
 * import { env } from '$env/dynamic/private';
 * console.log(env.DEPLOYMENT_SPECIFIC_VARIABLE);
 * ```
 * 
 * > In `dev`, `$env/dynamic` always includes environment variables from `.env`. In `prod`, this behavior will depend on your adapter.
 */
declare module '$env/dynamic/private' {
	export const env: {
		PYCHARM_VM_OPTIONS: string;
		WEBIDE_VM_OPTIONS: string;
		TERM_PROGRAM: string;
		NODE: string;
		INIT_CWD: string;
		JETBRAINSCLIENT_VM_OPTIONS: string;
		SHELL: string;
		TERM: string;
		TMPDIR: string;
		npm_config_global_prefix: string;
		TERM_PROGRAM_VERSION: string;
		TAURI_CLI_VERBOSITY: string;
		COLOR: string;
		TAURI_ENV_DEBUG: string;
		TERM_SESSION_ID: string;
		npm_config_noproxy: string;
		npm_config_local_prefix: string;
		USER: string;
		TAURI_ENV_TARGET_TRIPLE: string;
		npm_config_globalconfig: string;
		PHPSTORM_VM_OPTIONS: string;
		SSH_AUTH_SOCK: string;
		__CF_USER_TEXT_ENCODING: string;
		GOLAND_VM_OPTIONS: string;
		npm_execpath: string;
		APPCODE_VM_OPTIONS: string;
		TAURI_ENV_PLATFORM: string;
		DEVECOSTUDIO_VM_OPTIONS: string;
		PATH: string;
		RUSTROVER_VM_OPTIONS: string;
		LaunchInstanceID: string;
		_: string;
		npm_package_json: string;
		TAURI_ENV_FAMILY: string;
		TAURI_ENV_PLATFORM_VERSION: string;
		__CFBundleIdentifier: string;
		npm_config_init_module: string;
		npm_config_userconfig: string;
		PWD: string;
		npm_command: string;
		EDITOR: string;
		npm_lifecycle_event: string;
		CLION_VM_OPTIONS: string;
		IDEA_VM_OPTIONS: string;
		LANG: string;
		npm_package_name: string;
		XPC_FLAGS: string;
		npm_config_npm_version: string;
		TAURI_ENV_ARCH: string;
		WEBSTORM_VM_OPTIONS: string;
		DATASPELL_VM_OPTIONS: string;
		npm_config_node_gyp: string;
		XPC_SERVICE_NAME: string;
		npm_package_version: string;
		HOME: string;
		SHLVL: string;
		STUDIO_VM_OPTIONS: string;
		LOGNAME: string;
		MACOSX_DEPLOYMENT_TARGET: string;
		npm_config_cache: string;
		npm_lifecycle_script: string;
		GATEWAY_VM_OPTIONS: string;
		DATAGRIP_VM_OPTIONS: string;
		npm_config_user_agent: string;
		JETBRAINS_CLIENT_VM_OPTIONS: string;
		OSLogRateLimit: string;
		RIDER_VM_OPTIONS: string;
		RUBYMINE_VM_OPTIONS: string;
		SECURITYSESSIONID: string;
		COLORTERM: string;
		npm_config_prefix: string;
		npm_node_execpath: string;
		NODE_ENV: string;
		[key: `PUBLIC_${string}`]: undefined;
		[key: `${string}`]: string | undefined;
	}
}

/**
 * Similar to [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), but only includes variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`), and can therefore safely be exposed to client-side code.
 * 
 * Note that public dynamic environment variables must all be sent from the server to the client, causing larger network requests — when possible, use `$env/static/public` instead.
 * 
 * Dynamic environment variables cannot be used during prerendering.
 * 
 * ```ts
 * import { env } from '$env/dynamic/public';
 * console.log(env.PUBLIC_DEPLOYMENT_SPECIFIC_VARIABLE);
 * ```
 */
declare module '$env/dynamic/public' {
	export const env: {
		[key: `PUBLIC_${string}`]: string | undefined;
	}
}
