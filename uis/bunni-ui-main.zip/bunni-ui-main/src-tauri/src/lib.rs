use serde::Deserialize;
use tauri::{AppHandle, Manager, State, Emitter};
use std::collections::HashMap;
use std::process::{Command, Child};
use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH, Duration};
use tokio::net::{TcpListener, TcpStream};
use tokio_tungstenite::{accept_async, tungstenite::Message};
use serde_json::{json, Value};
use uuid::Uuid;
use tokio::sync::{mpsc, RwLock};
use futures_util::{SinkExt, StreamExt};
use std::sync::atomic::{AtomicU64, Ordering};
use std::fs;
use std::path::PathBuf;

type ClientId = String;
type ClientSender = mpsc::UnboundedSender<Message>;
type ClientMap = Arc<RwLock<HashMap<ClientId, ClientSender>>>;

struct WebSocketState {
    clients: ClientMap,
    app_handle: Option<AppHandle>,
}

static PING_COUNTER: AtomicU64 = AtomicU64::new(0);

fn get_path() -> Result<PathBuf, String> {
    
    let home_dir = std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .map_err(|_| {
            println!("DEBUG: Could not find home directory");
            "Could not find home directory"
        })?;


    let cache_dir = PathBuf::from(home_dir).join("Library/Caches/BunniMac");
    
    // Create directory if it doesn't exist
    if let Err(e) = fs::create_dir_all(&cache_dir) {
        return Err(format!("Failed to create cache directory: {}", e));
    }
    
    let file_path = cache_dir.join("dont_touch_this.lua");
    
    Ok(file_path)
}

async fn handle_connection(stream: TcpStream, clients: ClientMap, app_handle: Option<AppHandle>) {
    let websocket = match accept_async(stream).await {
        Ok(ws) => ws,
        Err(_) => return,
    };

    let client_id = generate_client_id();
    let (tx, mut rx) = mpsc::unbounded_channel();
    
    {
        let mut clients_lock = clients.write().await;
        clients_lock.insert(client_id.clone(), tx);
    }

    let (mut ws_sender, mut ws_receiver) = websocket.split();
    let clients_for_handler = clients.clone();
    let client_id_for_handler = client_id.clone();
    let app_handle_for_handler = app_handle.clone();

    let sender_task = tokio::spawn(async move {
        while let Some(message) = rx.recv().await {
            if ws_sender.send(message).await.is_err() {
                break;
            }
        }
    });

    let receiver_task = tokio::spawn(async move {
        while let Some(message) = ws_receiver.next().await {
            match message {
                Ok(Message::Text(text)) => {
                    //println!("ud btw");
                    if let Some(ref handle) = app_handle_for_handler {
                                       if let Ok(parsed) = serde_json::from_str::<Value>(&text) {
                            let log_type = parsed["log_type"].as_str().unwrap_or("info");
                            let message_content = parsed["message"].as_str().unwrap_or(&text);
                            let formatted = format!("{}_{}", log_type, message_content);
                            let _ = handle.emit("ws_message", formatted);
                        } else {
                            println!("{}", &text);
                            let _ = handle.emit("ws_message", &text);
                        }
                    }
                    
                    //if handle_message(&text, &client_id_for_handler, &clients_for_handler).await.is_err() {
                     //   break;
                    //}
                }
                Ok(Message::Close(_)) => break,
                Ok(Message::Ping(data)) => {
                    let clients_lock = clients_for_handler.read().await;
                    if let Some(sender) = clients_lock.get(&client_id_for_handler) {
                        let _ = sender.send(Message::Pong(data));
                    }
                }
                Err(_) => break,
                _ => {}
            }
        }
    });

    tokio::select! {
        _ = sender_task => {},
        _ = receiver_task => {},
    }

    {
        let mut clients_lock = clients.write().await;
        clients_lock.remove(&client_id);
    }
}

async fn handle_message(
    text: &str,
    sender_id: &str,
    clients: &ClientMap,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let message: Value = serde_json::from_str(text)?;
    
    match message["type"].as_str() {
        Some("ping") => {
            send_to_client(
                sender_id,
                &json!({
                    "type": "pong",
                    "timestamp": get_timestamp()
                }),
                clients,
            ).await;
        }
        Some("direct") => {
            if let Some(target) = message["target_client"].as_str() {
                send_to_client(
                    target,
                    &json!({
                        "type": "direct_message",
                        "from": sender_id,
                        "data": message["data"]
                    }),
                    clients,
                ).await;
            }
        }
        _ => {}
    }
    Ok(())
}

async fn send_to_client(client_id: &str, message: &Value, clients: &ClientMap) {
    let clients_lock = clients.read().await;
    if let Some(sender) = clients_lock.get(client_id) {
        let msg_text = message.to_string();
        let _ = sender.send(Message::Text(msg_text));
    }
}

#[tauri::command]
async fn broadcast_raw(message: &str, state: State<'_, WebSocketState>) -> Result<String, String> {
    let clients = &state.clients;
    let clients_lock = clients.read().await;
        
    if clients_lock.is_empty() {
        return Ok("No clients connected".to_string());
    }
        
    let message_text = Message::Text(message.to_string());
    let mut sent_count = 0;
        
    for sender in clients_lock.values() {
        if sender.send(message_text.clone()).is_ok() {
            sent_count += 1;
        }
    }
        
    Ok(format!("Broadcast queued for {} clients", sent_count))
}

fn generate_client_id() -> String {
    format!("client_{}", Uuid::new_v4().simple().to_string()[..8].to_string())
}

fn get_timestamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_millis() as u64
}

async fn start_ping_interval(clients: ClientMap) {
    let mut interval = tokio::time::interval(Duration::from_secs(30));
    loop {
        interval.tick().await;
        let clients_lock = clients.read().await;
        let ping_data = PING_COUNTER.fetch_add(1, Ordering::Relaxed).to_le_bytes().to_vec();
        
        for sender in clients_lock.values() {
            let _ = sender.send(Message::Ping(ping_data.clone()));
        }
    }
}

#[derive(Deserialize)]
struct OutputTypes {
    error: bool,
    warn: bool,
    info: bool,
    output: bool,
}

#[tauri::command]
fn auth_key(_key: &str) -> bool {
    true
}

#[tauri::command]
fn attach() -> bool {
    use std::process::Command;

    let dylib_path = "/Applications/Roblox.app/Contents/MacOS/libbunnimac.dylib";

    // Try without sudo first
    let result = Command::new("/Applications/Roblox.app/Contents/MacOS/RobloxPlayer")
        .env("DYLD_INSERT_LIBRARIES", dylib_path)
        .spawn();

    match result {
        Ok(_) => {
            println!("Attached successfully");
            true
        }
        Err(_) => {
            // If it fails, try with sudo
            println!("Initial attach failed, requesting sudo privileges...");
            
            // Use osascript to request admin privileges via GUI
            let sudo_result = Command::new("osascript")
                .arg("-e")
                .arg(&format!(
                    "do shell script \"DYLD_INSERT_LIBRARIES={} /Applications/Roblox.app/Contents/MacOS/RobloxPlayer &\" with administrator privileges",
                    dylib_path
                ))
                .output();

            match sudo_result {
                Ok(output) => {
                    if output.status.success() {
                        println!("Attached with administrator privileges");
                        true
                    } else {
                        let error_msg = String::from_utf8_lossy(&output.stderr);
                        println!("Failed to attach with sudo: {}", error_msg);
                        false
                    }
                }
                Err(e) => {
                    println!("Failed to request privileges: {}", e);
                    false
                }
            }
        }
    }
}

#[tauri::command]
fn execute(script: &str) -> Result<String, String> {
    let script_text = script.to_string();

    std::thread::spawn(move || {
        let rt = tokio::runtime::Runtime::new().unwrap();
        rt.block_on(async move {
            use tokio_tungstenite::connect_async;
            use url::Url;
            use tokio_tungstenite::tungstenite::Message;

            let url = Url::parse("ws://127.0.0.1:8765").unwrap();

            match connect_async(url).await {
                Ok((mut ws_stream, _)) => {
                    let _ = ws_stream.send(Message::Text(script_text)).await;
                    let _ = ws_stream.close(None).await;
                }
                Err(e) => {
                    eprintln!("Failed to connect to WebSocket server: {}", e);
                }
            }
        });
    });

    Ok("Script sent to WebSocket server.".to_string())
}

#[tauri::command]
fn set_autoinject(_value: bool) -> Result<(), String> {
    Ok(())
}

#[tauri::command]
fn set_hotkey(_value: &str) -> Result<(), String> {
    Ok(())
}

#[tauri::command]
fn set_topmost(handle: AppHandle, value: bool) -> Result<(), String> {
    let window = handle.get_webview_window("main").ok_or("failed to get window").unwrap();
    window.set_always_on_top(value).map_err(|e| format!("failed topmost setter: {}", e))?;
    Ok(())
}

#[tauri::command]
fn set_redirect(_value: bool) -> Result<(), String> {
    Ok(())
}

#[tauri::command]
fn set_outputtypes(_value: OutputTypes) -> Result<(), String> {
    Ok(())
}

#[tauri::command]
fn on_keybind_set(_keybind: &str) -> Result<(), String> {
    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tokio::runtime::Runtime::new().unwrap().block_on(async {
    tauri::Builder::default()
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![auth_key, attach, execute, set_autoinject, set_topmost, broadcast_raw, set_hotkey, set_redirect, set_outputtypes, on_keybind_set])
        .setup(|app| {
            let app_handle = app.handle().clone();
            let clients: ClientMap = Arc::new(RwLock::new(HashMap::new()));
            
            app.manage(WebSocketState {
                clients: clients.clone(),
                app_handle: Some(app_handle.clone()),
            });
            
            let ping_clients = clients.clone();
            let rt = tokio::runtime::Runtime::new().unwrap();
            
            std::thread::spawn(move || {
                rt.block_on(async {
                    tokio::spawn(async move {
                        start_ping_interval(ping_clients).await;
                    });
                    
                    let addr = "127.0.0.1:5000";
                    let listener = match TcpListener::bind(&addr).await {
                        Ok(l) => l,
                        Err(_) => return,
                    };
                    
                    while let Ok((stream, _)) = listener.accept().await {
                        let clients_clone = clients.clone();
                        let handle_clone = Some(app_handle.clone());
                        tokio::spawn(async move {
                            handle_connection(stream, clients_clone, handle_clone).await;
                        });
                    }
                });
            });
  
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
    });
}