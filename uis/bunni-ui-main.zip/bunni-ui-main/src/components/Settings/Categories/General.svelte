<script lang="ts">
    import { fade } from "svelte/transition";
    import Toggle from "../Toggle.svelte";
    import Keybind from "../Keybind.svelte";
    import { settings, type Settings } from "$lib/settings";

    interface Props {
        onChange: (key: keyof Settings, value: any) => void;
    };

    let {
        onChange
    }: Props = $props();
</script>

<div in:fade={{ duration: 150 }} class="space-y-4">
    <div class="space-y-3">
        <Toggle
            title="Auto Inject"
            description="Automatically inject when Roblox is detected"
            bind:checked={$settings.autoInject}
            onChange={(value) => onChange("autoInject", value)}
        />

        <Toggle
            title="Top Most"
            description="Toggle the top most functionality of the window."
            bind:checked={$settings.topMost}
            onChange={(value) => onChange("topMost", value)}
        />
        
        <Toggle
            title="Enable Minimap"
            description="Show code minimap in the editor"
            bind:checked={$settings.enableMinimap}
            onChange={(value) => onChange("enableMinimap", value)}
        />
        
        <Keybind
            title="Internal UI Hotkey"
            description="Set the hotkey for toggling the internal UI"
            keybind="HOME"
        />
        
        <Toggle
            title="Redirect Roblox Output"
            description="Show Roblox output in the console"
            bind:checked={$settings.redirectRobloxOutput}
            onChange={(value) => onChange("redirectRobloxOutput", value)}
        />
    </div>
</div>