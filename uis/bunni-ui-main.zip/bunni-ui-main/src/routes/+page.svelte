<script lang="ts">
    import { onMount } from "svelte";
    import { registerTabs } from "$lib/stores/register";
    import TabContent from "../components/TabContent.svelte";
    import { setActive } from "$lib/stores/tabs";
    import { VConsole } from "$lib/console";
    import { listen } from '@tauri-apps/api/event'


    onMount(() => {
        listen('ws_message', (event) => {
           const [logType, ...msgParts] = event.payload.split('_');
           const message = msgParts.join('_');
            console.log(logType),
            console.log(message);
           if (logType == "INFO") {
            VConsole.info(message);
           } else if (logType == "WARNING") {
            VConsole.warn(message);
           } else if (logType == "ERROR") {
            VConsole.error(message);
           }
        });

        registerTabs();
        setActive("editor");
    
        VConsole.clear();
        VConsole.warn("Beta release, expect bugs.");
    });
</script>

<div class="px-4 py-2 h-full w-full flex flex-col overflow-hidden">
    <TabContent />
</div>