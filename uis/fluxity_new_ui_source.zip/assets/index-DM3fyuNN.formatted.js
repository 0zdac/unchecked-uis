import {
  l as Ln,
  _ as Ka,
  e as Xa,
  m as Za
} from "./monaco-DWoI3J41.js";
(function() {
  const e = document.createElement("link").relList;
  if (e && e.supports && e.supports("modulepreload")) return;
  for (const i of document.querySelectorAll('link[rel="modulepreload"]')) r(i);
  new MutationObserver(i => {
    for (const a of i)
      if (a.type === "childList")
        for (const s of a.addedNodes) s.tagName === "LINK" && s.rel === "modulepreload" && r(s)
  }).observe(document, {
    childList: !0,
    subtree: !0
  });

  function n(i) {
    const a = {};
    return i.integrity && (a.integrity = i.integrity), i.referrerPolicy && (a.referrerPolicy = i.referrerPolicy), i.crossOrigin === "use-credentials" ? a.credentials = "include" : i.crossOrigin === "anonymous" ? a.credentials = "omit" : a.credentials = "same-origin", a
  }

  function r(i) {
    if (i.ep) return;
    i.ep = !0;
    const a = n(i);
    fetch(i.href, a)
  }
})();
const Pi = !1;
var Br = Array.isArray,
  Ja = Array.prototype.indexOf,
  qn = Array.prototype.includes,
  nr = Array.from,
  Qa = Object.defineProperty,
  At = Object.getOwnPropertyDescriptor,
  Oi = Object.getOwnPropertyDescriptors,
  es = Object.prototype,
  ts = Array.prototype,
  jr = Object.getPrototypeOf,
  si = Object.isExtensible;

function Xt(t) {
  return typeof t == "function"
}
const Zt = () => {};

function ns(t) {
  return t()
}

function yr(t) {
  for (var e = 0; e < t.length; e++) t[e]()
}

function Ri() {
  var t, e, n = new Promise((r, i) => {
    t = r, e = i
  });
  return {
    promise: n,
    resolve: t,
    reject: e
  }
}

function Di(t, e) {
  if (Array.isArray(t)) return t;
  if (!(Symbol.iterator in t)) return Array.from(t);
  const n = [];
  for (const r of t)
    if (n.push(r), n.length === e) break;
  return n
}
const Ee = 2,
  en = 4,
  Cn = 8,
  Vr = 1 << 24,
  Xe = 16,
  Je = 32,
  mt = 64,
  mr = 128,
  Ze = 512,
  ke = 1024,
  ye = 2048,
  st = 4096,
  De = 8192,
  Ge = 16384,
  qt = 32768,
  kr = 1 << 25,
  Pt = 65536,
  Yn = 1 << 17,
  rs = 1 << 18,
  cn = 1 << 19,
  Li = 1 << 20,
  ft = 1 << 25,
  Ht = 65536,
  Kn = 1 << 21,
  Qt = 1 << 22,
  Mt = 1 << 23,
  dt = Symbol("$state"),
  Ii = Symbol("legacy props"),
  is = Symbol(""),
  Wi = Symbol("attributes"),
  xr = Symbol("class"),
  Er = Symbol("style"),
  Sr = Symbol("text"),
  Vn = Symbol("form reset"),
  Tn = new class extends Error {
    name = "StaleReactionError";
    message = "The reaction that called `getAbortSignal()` was re-run or destroyed"
  },
  rr = !!globalThis.document?.contentType && globalThis.document.contentType.includes("xml");

function as(t) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component")
}

function ss() {
  throw new Error("https://svelte.dev/e/async_derived_orphan")
}

function ls(t, e, n) {
  throw new Error("https://svelte.dev/e/each_key_duplicate")
}

function os(t) {
  throw new Error("https://svelte.dev/e/effect_in_teardown")
}

function cs() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived")
}

function us(t) {
  throw new Error("https://svelte.dev/e/effect_orphan")
}

function fs() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded")
}

function ds(t) {
  throw new Error("https://svelte.dev/e/props_invalid_value")
}

function vs() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed")
}

function hs() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed")
}

function ps() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation")
}

function _s() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror")
}
const gs = 1,
  bs = 2,
  Fi = 4,
  ws = 8,
  ys = 16,
  ms = 1,
  ks = 2,
  Bi = 4,
  xs = 8,
  Es = 16,
  Ss = 1,
  zs = 2,
  $s = 4,
  Ns = 1,
  Cs = 2,
  we = Symbol("uninitialized"),
  ji = "http://www.w3.org/1999/xhtml",
  Ts = "http://www.w3.org/2000/svg",
  As = "@attach";

function Ms() {
  console.warn("https://svelte.dev/e/derived_inert")
}

function Ps() {
  console.warn("https://svelte.dev/e/select_multiple_invalid_value")
}

function Os() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop")
}

function Vi(t) {
  return t === this.v
}

function Rs(t, e) {
  return t != t ? e == e : t !== e || t !== null && typeof t == "object" || typeof t == "function"
}

function Ui(t) {
  return !Rs(t, this.v)
}
let un = !1,
  Ds = !1;

function Ls() {
  un = !0
}
let oe = null;

function tn(t) {
  oe = t
}

function ot(t, e = !1, n) {
  oe = {
    p: oe,
    i: !1,
    c: null,
    e: null,
    s: t,
    x: null,
    r: B,
    l: un && !e ? {
      s: null,
      u: null,
      $: []
    } : null
  }
}

function ct(t) {
  var e = oe,
    n = e.e;
  if (n !== null) {
    e.e = null;
    for (var r of n) ua(r)
  }
  return t !== void 0 && (e.x = t), e.i = !0, oe = e.p, t ?? {}
}

function fn() {
  return !un || oe !== null && oe.l === null
}
let Ft = [];

function Hi() {
  var t = Ft;
  Ft = [], yr(t)
}

function rt(t) {
  if (Ft.length === 0 && !yn) {
    var e = Ft;
    queueMicrotask(() => {
      e === Ft && Hi()
    })
  }
  Ft.push(t)
}

function Is() {
  for (; Ft.length > 0;) Hi()
}

function Gi(t) {
  var e = B;
  if (e === null) return q.f |= Mt, t;
  if ((e.f & qt) === 0 && (e.f & en) === 0) throw t;
  Tt(t, e)
}

function Tt(t, e) {
  if (!(e !== null && (e.f & Ge) !== 0)) {
    for (; e !== null;) {
      if ((e.f & mr) !== 0) {
        if ((e.f & qt) === 0) throw t;
        try {
          e.b.error(t);
          return
        } catch (n) {
          t = n
        }
      }
      e = e.parent
    }
    throw t
  }
}
const Ws = -7169;

function he(t, e) {
  t.f = t.f & Ws | e
}

function Ur(t) {
  (t.f & Ze) !== 0 || t.deps === null ? he(t, ke) : he(t, st)
}

function qi(t) {
  if (t !== null)
    for (const e of t)(e.f & Ee) === 0 || (e.f & Ht) === 0 || (e.f ^= Ht, qi(e.deps))
}

function Yi(t, e, n) {
  (t.f & ye) !== 0 ? e.add(t) : (t.f & st) !== 0 && n.add(t), qi(t.deps), he(t, ke)
}
let In = !1;

function Fs(t) {
  var e = In;
  try {
    return In = !1, [t(), In]
  } finally {
    In = e
  }
}

function Bs(t, e) {
  if (e) {
    const n = document.body;
    t.autofocus = !0, rt(() => {
      document.activeElement === n && t.focus()
    })
  }
}
let li = !1;

function js() {
  li || (li = !0, document.addEventListener("reset", t => {
    Promise.resolve().then(() => {
      if (!t.defaultPrevented)
        for (const e of t.target.elements) e[Vn]?.()
    })
  }, {
    capture: !0
  }))
}

function Dt(t) {
  var e = q,
    n = B;
  Qe(null), et(null);
  try {
    return t()
  } finally {
    Qe(e), et(n)
  }
}

function Vs(t, e, n, r = n) {
  t.addEventListener(e, () => Dt(n));
  const i = t[Vn];
  i ? t[Vn] = () => {
    i(), r(!0)
  } : t[Vn] = () => r(!0), js()
}

function Us(t) {
  let e = 0,
    n = Rt(0),
    r;
  return () => {
    Kr() && (o(n), Xr(() => (e === 0 && (r = Lt(() => t(() => mn(n)))), e += 1, () => {
      rt(() => {
        e -= 1, e === 0 && (r?.(), r = void 0, mn(n))
      })
    })))
  }
}
var Hs = Pt | cn;

function Gs(t, e, n, r) {
  new qs(t, e, n, r)
}
class qs {
  parent;
  is_pending = !1;
  transform_error;
  #t;
  #s = null;
  #e;
  #o;
  #r;
  #a = null;
  #n = null;
  #l = null;
  #i = null;
  #p = 0;
  #c = 0;
  #u = !1;
  #d = new Set;
  #_ = new Set;
  #f = null;
  #b = Us(() => (this.#f = Rt(this.#p), () => {
    this.#f = null
  }));
  constructor(e, n, r, i) {
    this.#t = e, this.#e = n, this.#o = a => {
      var s = B;
      s.b = this, s.f |= mr, r(a)
    }, this.parent = B.b, this.transform_error = i ?? this.parent?.transform_error ?? (a => a), this.#r = Mn(() => {
      this.#v()
    }, Hs)
  }
  #g() {
    try {
      this.#a = Fe(() => this.#o(this.#t))
    } catch (e) {
      this.error(e)
    }
  }
  #m(e) {
    const n = this.#e.failed,
      {
        reset: r,
        invoke_onerror: i
      } = this.#w(e);
    rt(i), n && (this.#l = Fe(() => {
      n(this.#t, () => e, () => r)
    }))
  }
  #w(e) {
    var n = !1,
      r = !1;
    const i = () => {
      if (n) {
        Os();
        return
      }
      n = !0, r && _s(), this.#l !== null && jt(this.#l, () => {
        this.#l = null
      }), this.#h(() => {
        this.#v()
      })
    };
    return {
      reset: i,
      invoke_onerror: () => {
        try {
          r = !0, this.#e.onerror?.(e, i), r = !1
        } catch (s) {
          Tt(s, this.#r && this.#r.parent)
        }
      }
    }
  }
  #k() {
    const e = this.#e.pending;
    e && (this.is_pending = !0, this.#n = Fe(() => e(this.#t)), rt(() => {
      var n = this.#i = document.createDocumentFragment(),
        r = yt();
      n.append(r), this.#a = this.#h(() => Fe(() => this.#o(r))), this.#c === 0 && (this.#t.before(n), this.#i = null, jt(this.#n, () => {
        this.#n = null
      }), this.#y(H))
    }))
  }
  #v() {
    try {
      if (this.is_pending = this.has_pending_snippet(), this.#c = 0, this.#p = 0, this.#a = Fe(() => {
          this.#o(this.#t)
        }), this.#c > 0) {
        var e = this.#i = document.createDocumentFragment();
        Jr(this.#a, e);
        const n = this.#e.pending;
        this.#n = Fe(() => n(this.#t))
      } else this.#y(H)
    } catch (n) {
      this.error(n)
    }
  }
  #y(e) {
    this.is_pending = !1, e.transfer_effects(this.#d, this.#_)
  }
  defer_effect(e) {
    Yi(e, this.#d, this.#_)
  }
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered())
  }
  has_pending_snippet() {
    return !!this.#e.pending
  }
  #h(e) {
    var n = B,
      r = q,
      i = oe;
    et(this.#r), Qe(this.#r), tn(this.#r.ctx);
    try {
      return Ot.ensure(), e()
    } catch (a) {
      return Gi(a), null
    } finally {
      et(n), Qe(r), tn(i)
    }
  }
  #x(e, n) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#x(e, n);
      return
    }
    this.#c += e, this.#c === 0 && (this.#y(n), this.#n && jt(this.#n, () => {
      this.#n = null
    }), this.#i && (this.#t.before(this.#i), this.#i = null))
  }
  update_pending_count(e, n) {
    this.#x(e, n), this.#p += e, !(!this.#f || this.#u) && (this.#u = !0, rt(() => {
      this.#u = !1, this.#f && rn(this.#f, this.#p)
    }))
  }
  get_effect_pending() {
    return this.#b(), o(this.#f)
  }
  error(e) {
    if (!this.#e.onerror && !this.#e.failed) throw e;
    H?.is_fork ? (this.#a && H.skip_effect(this.#a), this.#n && H.skip_effect(this.#n), this.#l && H.skip_effect(this.#l), H.oncommit(() => {
      this.#E(e)
    })) : this.#E(e)
  }
  #E(e) {
    this.#a && (ze(this.#a), this.#a = null), this.#n && (ze(this.#n), this.#n = null), this.#l && (ze(this.#l), this.#l = null);
    let n = this.#e.failed;
    const r = i => {
      const {
        reset: a,
        invoke_onerror: s
      } = this.#w(i);
      s(), n && (this.#l = this.#h(() => {
        try {
          return Fe(() => {
            var l = B;
            l.b = this, l.f |= mr, n(this.#t, () => i, () => a)
          })
        } catch (l) {
          return Tt(l, this.#r.parent), null
        }
      }))
    };
    rt(() => {
      var i;
      try {
        i = this.transform_error(e)
      } catch (a) {
        Tt(a, this.#r && this.#r.parent);
        return
      }
      i !== null && typeof i == "object" && typeof i.then == "function" ? i.then(r, a => Tt(a, this.#r && this.#r.parent)) : r(i)
    })
  }
}

function Ki(t, e, n, r) {
  const i = fn() ? nn : Hr;
  var a = t.filter(p => !p.settled),
    s = e.map(i);
  if (n.length === 0 && a.length === 0) {
    r(s);
    return
  }
  var l = B,
    c = Ys(),
    u = a.length === 1 ? a[0].promise : a.length > 1 ? Promise.all(a.map(p => p.promise)) : null;

  function d(p) {
    if ((l.f & Ge) === 0) {
      c();
      try {
        r([...s, ...p])
      } catch (_) {
        Tt(_, l)
      }
      Xn()
    }
  }
  var f = Xi();
  if (n.length === 0) {
    u.then(() => d([])).finally(f);
    return
  }

  function v() {
    Promise.all(n.map(p => Ks(p))).then(d).catch(p => Tt(p, l)).finally(f)
  }
  u ? u.then(() => {
    c(), v(), Xn()
  }) : v()
}

function Ys() {
  var t = B,
    e = q,
    n = oe,
    r = H;
  return function(a = !0) {
    et(t), Qe(e), tn(n), a && (t.f & Ge) === 0 && (r?.activate(), r?.apply())
  }
}

function Xn(t = !0) {
  et(null), Qe(null), tn(null), t && H?.deactivate()
}

function Xi() {
  var t = B,
    e = t.b,
    n = H,
    r = !!e?.is_rendered();
  return e?.update_pending_count(1, n), n.increment(r, t), () => {
    e?.update_pending_count(-1, n), n.decrement(r, t)
  }
}

function nn(t) {
  var e = Ee | ye;
  return B !== null && (B.f |= cn), {
    ctx: oe,
    deps: null,
    effects: null,
    equals: Vi,
    f: e,
    fn: t,
    reactions: null,
    rv: 0,
    v: we,
    wv: 0,
    parent: B,
    ac: null
  }
}
const gn = Symbol("obsolete");

function Ks(t, e, n) {
  let r = B;
  r === null && ss();
  var i = void 0,
    a = Rt(we),
    s = !q,
    l = new Set;
  return cl(() => {
    var c = B,
      u = Ri();
    i = u.promise;
    try {
      Promise.resolve(t()).then(u.resolve, p => {
        p !== Tn && u.reject(p)
      }).finally(Xn)
    } catch (p) {
      u.reject(p), Xn()
    }
    var d = H;
    if (s) {
      if ((c.f & qt) !== 0) var f = Xi();
      if (r.b?.is_rendered()) d.async_deriveds.get(c)?.reject(gn);
      else
        for (const p of l.values()) p.reject(gn);
      l.add(u), d.async_deriveds.set(c, u)
    }
    const v = (p, _ = void 0) => {
      f?.(), l.delete(u), _ !== gn && (d.activate(), _ ? (a.f |= Mt, rn(a, _)) : ((a.f & Mt) !== 0 && (a.f ^= Mt), rn(a, p)), d.deactivate())
    };
    u.promise.then(v, p => v(null, p || "unknown"))
  }), ir(() => {
    for (const c of l) c.reject(gn)
  }), new Promise(c => {
    function u(d) {
      function f() {
        d === i ? c(a) : u(i)
      }
      d.then(f, f)
    }
    u(i)
  })
}

function Sn(t) {
  const e = nn(t);
  return _a(e), e
}

function Hr(t) {
  const e = nn(t);
  return e.equals = Ui, e
}

function Xs(t) {
  var e = t.effects;
  if (e !== null) {
    t.effects = null;
    for (var n = 0; n < e.length; n += 1) ze(e[n])
  }
}

function Gr(t) {
  var e, n = B,
    r = t.parent;
  if (!kt && r !== null && t.v !== we && (r.f & (Ge | De)) !== 0) return Ms(), t.v;
  et(r);
  try {
    t.f &= ~Ht, Xs(t), e = ya(t)
  } finally {
    et(n)
  }
  return e
}

function Zi(t) {
  var e = Gr(t);
  if (!t.equals(e) && (t.wv = ba(), (!H?.is_fork || t.deps === null) && (H !== null ? (H.capture(t, e, !0), zr?.capture(t, e, !0)) : t.v = e, t.deps === null))) {
    he(t, ke);
    return
  }
  kt || (it !== null ? (Kr() || H?.is_fork) && it.set(t, e) : Ur(t))
}

function Zs(t) {
  if (t.effects !== null)
    for (const e of t.effects)(e.teardown || e.ac) && (e.teardown?.(), e.ac !== null && Dt(() => {
      e.ac.abort(Tn), e.ac = null
    }), e.fn !== null && (e.teardown = Zt), zn(e, 0), Zr(e))
}

function Ji(t) {
  if (t.effects !== null)
    for (const e of t.effects) e.teardown && e.fn !== null && sn(e)
}
let or = null,
  Yt = null,
  H = null,
  zr = null,
  it = null,
  $r = null,
  yn = !1,
  cr = !1,
  Jt = null,
  Un = null;
var oi = 0;
let Js = 1;
class Ot {
  id = Js++;
  #t = !1;
  linked = !0;
  #s = null;
  #e = null;
  async_deriveds = new Map;
  current = new Map;
  previous = new Map;
  #o = new Set;
  #r = new Set;
  #a = 0;
  #n = new Map;
  #l = null;
  #i = [];
  #p = [];
  #c = new Set;
  #u = new Set;
  #d = new Map;
  #_ = new Set;
  is_fork = !1;
  #f = !1;
  constructor() {
    Yt === null ? or = Yt = this : (Yt.#e = this, this.#s = Yt), Yt = this
  }
  #b() {
    if (this.is_fork) return !0;
    for (const r of this.#n.keys()) {
      for (var e = r, n = !1; e.parent !== null;) {
        if (this.#d.has(e)) {
          n = !0;
          break
        }
        e = e.parent
      }
      if (!n) return !0
    }
    return !1
  }
  skip_effect(e) {
    this.#d.has(e) || this.#d.set(e, {
      d: [],
      m: []
    }), this.#_.delete(e)
  }
  unskip_effect(e, n = r => this.schedule(r)) {
    var r = this.#d.get(e);
    if (r) {
      this.#d.delete(e);
      for (var i of r.d) he(i, ye), n(i);
      for (i of r.m) he(i, st), n(i)
    }
    this.#_.add(e)
  }
  #g() {
    this.#t = !0, oi++ > 1e3 && (this.#h(), el());
    for (const c of this.#c) this.#u.delete(c), he(c, ye), this.schedule(c);
    for (const c of this.#u) he(c, st), this.schedule(c);
    const e = this.#i;
    this.#i = [], this.apply();
    var n = Jt = [],
      r = [],
      i = Un = [];
    for (const c of e) try {
      this.#m(c, n, r)
    } catch (u) {
      throw ta(c), this.#b() || this.discard(), u
    }
    if (H = null, i.length > 0) {
      var a = Ot.ensure();
      for (const c of i) a.schedule(c)
    }
    if (Jt = null, Un = null, this.#b()) {
      this.#v(r), this.#v(n);
      for (const [c, u] of this.#d) ea(c, u);
      i.length > 0 && H.#g();
      return
    }
    const s = this.#w();
    if (s) {
      this.#v(r), this.#v(n), s.#k(this);
      return
    }
    this.#c.clear(), this.#u.clear();
    for (const c of this.#o) c(this);
    this.#o.clear(), zr = this, ci(r), ci(n), zr = null, this.#l?.resolve();
    var l = H;
    if (this.#a === 0 && (this.#i.length === 0 || l !== null) && this.#h(), this.#i.length > 0)
      if (l !== null) {
        const c = l;
        c.#i.push(...this.#i.filter(u => !c.#i.includes(u)))
      } else l = this;
    l !== null && (vt.clear(), l.#g())
  }
  #m(e, n, r) {
    e.f ^= ke;
    for (var i = e.first; i !== null;) {
      var a = i.f,
        s = (a & (Je | mt)) !== 0,
        l = s && (a & ke) !== 0,
        c = l || (a & De) !== 0 || this.#d.has(i);
      if (!c && i.fn !== null) {
        s ? i.f ^= ke : (a & en) !== 0 ? n.push(i) : Pn(i) && ((a & Xe) !== 0 && this.#u.add(i), sn(i));
        var u = i.first;
        if (u !== null) {
          i = u;
          continue
        }
      }
      for (; i !== null;) {
        var d = i.next;
        if (d !== null) {
          i = d;
          break
        }
        i = i.parent
      }
    }
  }
  #w() {
    for (var e = this.#s; e !== null;) {
      if (!e.is_fork) {
        for (const [n, [, r]] of this.current)
          if (e.current.has(n) && !r) return e
      }
      e = e.#s
    }
    return null
  }
  #k(e) {
    for (const [r, i] of e.current) !this.previous.has(r) && e.previous.has(r) && this.previous.set(r, e.previous.get(r)), this.current.set(r, i);
    for (const [r, i] of e.async_deriveds) {
      const a = this.async_deriveds.get(r);
      a && i.promise.then(a.resolve).catch(a.reject)
    }
    e.async_deriveds.clear(), this.transfer_effects(e.#c, e.#u);
    const n = r => {
      var i = r.reactions;
      if (i !== null && !((r.f & Ee) !== 0 && (r.f & (ye | st)) === 0))
        for (const l of i) {
          var a = l.f;
          if ((a & Ee) !== 0) n(l);
          else {
            var s = l;
            a & (Qt | Xe) && !this.async_deriveds.has(s) && (this.#u.delete(s), he(s, ye), this.schedule(s))
          }
        }
    };
    for (const r of this.current.keys()) n(r);
    this.oncommit(() => e.discard()), e.#h(), H = this, this.#g()
  }
  #v(e) {
    for (var n = 0; n < e.length; n += 1) Yi(e[n], this.#c, this.#u)
  }
  capture(e, n, r = !1) {
    e.v !== we && !this.previous.has(e) && this.previous.set(e, e.v), (e.f & Mt) === 0 && (this.current.set(e, [n, r]), it?.set(e, n)), this.is_fork || (e.v = n)
  }
  activate() {
    H = this
  }
  deactivate() {
    H = null, it = null
  }
  flush() {
    try {
      cr = !0, H = this, this.#g()
    } finally {
      oi = 0, $r = null, Jt = null, Un = null, cr = !1, H = null, it = null, vt.clear()
    }
  }
  discard() {
    for (const e of this.#r) e(this);
    this.#r.clear();
    for (const e of this.async_deriveds.values()) e.reject(gn);
    this.#h(), this.#l?.resolve()
  }
  register_created_effect(e) {
    this.#p.push(e)
  }
  #y() {
    for (let f = or; f !== null; f = f.#e) {
      var e = f.id < this.id,
        n = [];
      for (const [v, [p, _]] of this.current) {
        if (f.current.has(v)) {
          var r = f.current.get(v)[0];
          if (e && p !== r) f.current.set(v, [p, _]);
          else continue
        }
        n.push(v)
      }
      if (e)
        for (const [v, p] of this.async_deriveds) {
          const _ = f.async_deriveds.get(v);
          _ && p.promise.then(_.resolve).catch(_.reject)
        }
      var i = [...f.current.keys()].filter(v => !f.current.get(v)[1]);
      if (!(!f.#t || i.length === 0)) {
        var a = i.filter(v => !this.current.has(v));
        if (a.length === 0) e && f.discard();
        else if (n.length > 0) {
          if (e)
            for (const v of this.#_) f.unskip_effect(v, p => {
              (p.f & (Xe | Qt)) !== 0 ? f.schedule(p) : f.#v([p])
            });
          f.activate();
          var s = new Set,
            l = new Map;
          for (var c of n) Qi(c, a, s, l);
          l = new Map;
          var u = [...f.current].filter(([v, p]) => {
            const _ = this.current.get(v);
            return _ ? _[0] !== p[0] || _[1] !== p[1] : !0
          }).map(([v]) => v);
          if (u.length > 0)
            for (const v of this.#p)(v.f & (Ge | De | Yn)) === 0 && qr(v, u, l) && ((v.f & (Qt | Xe)) !== 0 ? (he(v, ye), f.schedule(v)) : f.#c.add(v));
          if (f.#i.length > 0 && !f.#f) {
            f.apply();
            for (var d of f.#i) f.#m(d, [], []);
            f.#i = []
          }
          f.deactivate()
        }
      }
    }
  }
  increment(e, n) {
    if (this.#a += 1, e) {
      let r = this.#n.get(n) ?? 0;
      this.#n.set(n, r + 1)
    }
  }
  decrement(e, n) {
    if (this.#a -= 1, e) {
      let r = this.#n.get(n) ?? 0;
      r === 1 ? this.#n.delete(n) : this.#n.set(n, r - 1)
    }
    this.#f || (this.#f = !0, rt(() => {
      this.#f = !1, this.linked && this.flush()
    }))
  }
  transfer_effects(e, n) {
    for (const r of e) this.#c.add(r);
    for (const r of n) this.#u.add(r);
    e.clear(), n.clear()
  }
  oncommit(e) {
    this.#o.add(e)
  }
  ondiscard(e) {
    this.#r.add(e)
  }
  settled() {
    return (this.#l ??= Ri()).promise
  }
  static ensure() {
    if (H === null) {
      const e = H = new Ot;
      !cr && !yn && rt(() => {
        e.#t || e.flush()
      })
    }
    return H
  }
  apply() {
    {
      it = null;
      return
    }
  }
  schedule(e) {
    if ($r = e, e.b?.is_pending && (e.f & (en | Cn | Vr)) !== 0 && (e.f & qt) === 0) {
      e.b.defer_effect(e);
      return
    }
    for (var n = e; n.parent !== null;) {
      n = n.parent;
      var r = n.f;
      if (Jt !== null && n === B && (q === null || (q.f & Ee) === 0)) return;
      if ((r & (mt | Je)) !== 0) {
        if ((r & ke) === 0) return;
        n.f ^= ke
      }
    }
    this.#i.push(n)
  }
  #h() {
    if (this.linked) {
      var e = this.#s,
        n = this.#e;
      e === null ? or = n : e.#e = n, n === null ? Yt = e : n.#s = e, this.linked = !1
    }
  }
}

function Qs(t) {
  var e = yn;
  yn = !0;
  try {
    for (var n;;) {
      if (Is(), H === null) return n;
      H.flush()
    }
  } finally {
    yn = e
  }
}

function el() {
  try {
    fs()
  } catch (t) {
    Tt(t, $r)
  }
}
let bt = null;

function ci(t) {
  var e = t.length;
  if (e !== 0) {
    for (var n = 0; n < e;) {
      var r = t[n++];
      if ((r.f & (Ge | De)) === 0 && Pn(r) && (bt = new Set, sn(r), r.deps === null && r.first === null && r.nodes === null && r.teardown === null && r.ac === null && va(r), bt?.size > 0)) {
        vt.clear();
        for (const i of bt) {
          if ((i.f & (Ge | De)) !== 0) continue;
          const a = [i];
          let s = i.parent;
          for (; s !== null;) bt.has(s) && (bt.delete(s), a.push(s)), s = s.parent;
          for (let l = a.length - 1; l >= 0; l--) {
            const c = a[l];
            (c.f & (Ge | De)) === 0 && sn(c)
          }
        }
        bt.clear()
      }
    }
    bt = null
  }
}

function Qi(t, e, n, r) {
  if (!n.has(t) && (n.add(t), t.reactions !== null))
    for (const i of t.reactions) {
      const a = i.f;
      (a & Ee) !== 0 ? Qi(i, e, n, r) : (a & (Qt | Xe)) !== 0 && (a & ye) === 0 && qr(i, e, r) && (he(i, ye), Yr(i))
    }
}

function qr(t, e, n) {
  const r = n.get(t);
  if (r !== void 0) return r;
  if (t.deps !== null)
    for (const i of t.deps) {
      if (qn.call(e, i)) return !0;
      if ((i.f & Ee) !== 0 && qr(i, e, n)) return n.set(i, !0), !0
    }
  return n.set(t, !1), !1
}

function Yr(t) {
  H.schedule(t)
}

function ea(t, e) {
  if (!((t.f & Je) !== 0 && (t.f & ke) !== 0)) {
    (t.f & ye) !== 0 ? e.d.push(t) : (t.f & st) !== 0 && e.m.push(t), he(t, ke);
    for (var n = t.first; n !== null;) ea(n, e), n = n.next
  }
}

function ta(t) {
  he(t, ke);
  for (var e = t.first; e !== null;) ta(e), e = e.next
}
let Zn = new Set;
const vt = new Map;
let na = !1;

function Rt(t, e) {
  var n = {
    f: 0,
    v: t,
    reactions: null,
    equals: Vi,
    rv: 0,
    wv: 0
  };
  return n
}

function L(t, e) {
  const n = Rt(t);
  return _a(n), n
}

function tl(t, e = !1, n = !0) {
  const r = Rt(t);
  return e || (r.equals = Ui), un && n && oe !== null && oe.l !== null && (oe.l.s ??= []).push(r), r
}

function y(t, e, n = !1) {
  q !== null && (!at || (q.f & Yn) !== 0) && fn() && (q.f & (Ee | Xe | Qt | Yn)) !== 0 && (ht === null || !ht.has(t)) && ps();
  let r = n ? xe(e) : e;
  return rn(t, r, Un)
}

function rn(t, e, n = null) {
  if (!t.equals(e)) {
    kt ? vt.set(t, e) : vt.has(t) || vt.set(t, t.v);
    var r = Ot.ensure();
    if (r.capture(t, e), (t.f & Ee) !== 0) {
      const i = t;
      (t.f & ye) !== 0 && Gr(i), it === null && Ur(i)
    }
    t.wv = ba(), ra(t, ye, n), fn() && B !== null && (B.f & ke) !== 0 && (B.f & (Je | mt)) === 0 && (Ke === null ? dl([t]) : Ke.push(t)), !r.is_fork && Zn.size > 0 && !na && nl()
  }
  return e
}

function nl() {
  na = !1;
  for (const t of Zn) {
    (t.f & ke) !== 0 && he(t, st);
    let e;
    try {
      e = Pn(t)
    } catch {
      e = !0
    }
    e && sn(t)
  }
  Zn.clear()
}

function ui(t, e = 1) {
  var n = o(t),
    r = e === 1 ? n++ : n--;
  return y(t, n), r
}

function mn(t) {
  y(t, t.v + 1)
}

function ra(t, e, n) {
  var r = t.reactions;
  if (r !== null)
    for (var i = fn(), a = r.length, s = 0; s < a; s++) {
      var l = r[s],
        c = l.f;
      if (!(!i && l === B)) {
        var u = (c & ye) === 0;
        if (u && he(l, e), (c & Yn) !== 0) Zn.add(l);
        else if ((c & Ee) !== 0) {
          var d = l;
          it?.delete(d), (c & Ht) === 0 && (c & Ze && (B === null || (B.f & Kn) === 0) && (l.f |= Ht), ra(d, st, n))
        } else if (u) {
          var f = l;
          (c & Xe) !== 0 && bt !== null && bt.add(f), n !== null ? n.push(f) : Yr(f)
        }
      }
    }
}

function xe(t) {
  if (typeof t != "object" || t === null || dt in t) return t;
  const e = jr(t);
  if (e !== es && e !== ts) return t;
  var n = new Map,
    r = Br(t),
    i = L(0),
    a = Vt,
    s = l => {
      if (Vt === a) return l();
      var c = q,
        u = Vt;
      Qe(null), vi(a);
      var d = l();
      return Qe(c), vi(u), d
    };
  return r && n.set("length", L(t.length)), new Proxy(t, {
    defineProperty(l, c, u) {
      (!("value" in u) || u.configurable === !1 || u.enumerable === !1 || u.writable === !1) && vs();
      var d = n.get(c);
      return d === void 0 ? s(() => {
        var f = L(u.value);
        return n.set(c, f), f
      }) : y(d, u.value, !0), !0
    },
    deleteProperty(l, c) {
      var u = n.get(c);
      if (u === void 0) {
        if (c in l) {
          const d = s(() => L(we));
          n.set(c, d), mn(i)
        }
      } else y(u, we), mn(i);
      return !0
    },
    get(l, c, u) {
      if (c === dt) return t;
      var d = n.get(c),
        f = c in l;
      if (d === void 0 && (!f || At(l, c)?.writable) && (d = s(() => {
          var p = xe(f ? l[c] : we),
            _ = L(p);
          return _
        }), n.set(c, d)), d !== void 0) {
        var v = o(d);
        return v === we ? void 0 : v
      }
      return Reflect.get(l, c, u)
    },
    getOwnPropertyDescriptor(l, c) {
      var u = Reflect.getOwnPropertyDescriptor(l, c);
      if (u && "value" in u) {
        var d = n.get(c);
        d && (u.value = o(d))
      } else if (u === void 0) {
        var f = n.get(c),
          v = f?.v;
        if (f !== void 0 && v !== we) return {
          enumerable: !0,
          configurable: !0,
          value: v,
          writable: !0
        }
      }
      return u
    },
    has(l, c) {
      if (c === dt) return !0;
      var u = n.get(c),
        d = u !== void 0 && u.v !== we || Reflect.has(l, c);
      if (u !== void 0 || B !== null && (!d || At(l, c)?.writable)) {
        u === void 0 && (u = s(() => {
          var v = d ? xe(l[c]) : we,
            p = L(v);
          return p
        }), n.set(c, u));
        var f = o(u);
        if (f === we) return !1
      }
      return d
    },
    set(l, c, u, d) {
      var f = n.get(c),
        v = c in l;
      if (r && c === "length")
        for (var p = u; p < f.v; p += 1) {
          var _ = n.get(p + "");
          _ !== void 0 ? y(_, we) : p in l && (_ = s(() => L(we)), n.set(p + "", _))
        }
      if (f === void 0)(!v || At(l, c)?.writable) && (f = s(() => L(void 0)), y(f, xe(u)), n.set(c, f));
      else {
        v = f.v !== we;
        var m = s(() => xe(u));
        y(f, m)
      }
      var g = Reflect.getOwnPropertyDescriptor(l, c);
      if (g?.set && g.set.call(d, u), !v) {
        if (r && typeof c == "string") {
          var k = n.get("length"),
            E = Number(c);
          Number.isInteger(E) && E >= k.v && y(k, E + 1)
        }
        mn(i)
      }
      return !0
    },
    ownKeys(l) {
      o(i);
      var c = Reflect.ownKeys(l).filter(f => {
        var v = n.get(f);
        return v === void 0 || v.v !== we
      });
      for (var [u, d] of n) d.v !== we && !(u in l) && c.push(u);
      return c
    },
    setPrototypeOf() {
      hs()
    }
  })
}

function fi(t) {
  try {
    if (t !== null && typeof t == "object" && dt in t) return t[dt]
  } catch {}
  return t
}

function rl(t, e) {
  return Object.is(fi(t), fi(e))
}
var Nr, ia, aa, sa;

function il() {
  if (Nr === void 0) {
    Nr = window, ia = /Firefox/.test(navigator.userAgent);
    var t = Element.prototype,
      e = Node.prototype,
      n = Text.prototype;
    aa = At(e, "firstChild").get, sa = At(e, "nextSibling").get, si(t) && (t[xr] = void 0, t[Wi] = null, t[Er] = void 0, t.__e = void 0), si(n) && (n[Sr] = void 0)
  }
}

function yt(t = "") {
  return document.createTextNode(t)
}

function an(t) {
  return aa.call(t)
}

function An(t) {
  return sa.call(t)
}

function h(t, e) {
  return an(t)
}

function Y(t, e = !1) {
  {
    var n = an(t);
    return n instanceof Comment && n.data === "" ? An(n) : n
  }
}

function w(t, e = 1, n = !1) {
  let r = t;
  for (; e--;) r = An(r);
  return r
}

function al(t) {
  t.textContent = ""
}

function la() {
  return !1
}

function oa(t, e, n) {
  return e == null || e === ji ? n ? document.createElement(t, {
    is: n
  }) : document.createElement(t) : n ? document.createElementNS(e, t, {
    is: n
  }) : document.createElementNS(e, t)
}

function ca(t) {
  B === null && (q === null && us(), cs()), kt && os()
}

function sl(t, e) {
  var n = e.last;
  n === null ? e.last = e.first = t : (n.next = t, t.prev = n, e.last = t)
}

function ut(t, e) {
  var n = B;
  n !== null && (n.f & De) !== 0 && (t |= De);
  var r = {
    ctx: oe,
    deps: null,
    nodes: null,
    f: t | ye | Ze,
    first: null,
    fn: e,
    last: null,
    next: null,
    parent: n,
    b: n && n.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  H?.register_created_effect(r);
  var i = r;
  if ((t & en) !== 0) Jt !== null ? Jt.push(r) : Ot.ensure().schedule(r);
  else if (e !== null) {
    try {
      sn(r)
    } catch (s) {
      throw ze(r), s
    }
    i.deps === null && i.teardown === null && i.nodes === null && i.first === i.last && (i.f & cn) === 0 && (i = i.first, (t & Xe) !== 0 && (t & Pt) !== 0 && i !== null && (i.f |= Pt))
  }
  if (i !== null && (i.parent = n, n !== null && sl(i, n), q !== null && (q.f & Ee) !== 0 && (t & mt) === 0)) {
    var a = q;
    (a.effects ??= []).push(i)
  }
  return r
}

function Kr() {
  return q !== null && !at
}

function ir(t) {
  const e = ut(Cn, null);
  return he(e, ke), e.teardown = t, e
}

function Cr(t) {
  ca();
  var e = B.f,
    n = !q && (e & Je) !== 0 && oe !== null && !oe.i;
  if (n) {
    var r = oe;
    (r.e ??= []).push(t)
  } else return ua(t)
}

function ua(t) {
  return ut(en | Li, t)
}

function ll(t) {
  return ca(), ut(Cn | Li, t)
}

function ol(t) {
  Ot.ensure();
  const e = ut(mt | cn, t);
  return (n = {}) => new Promise(r => {
    n.outro ? jt(e, () => {
      ze(e), r(void 0)
    }) : (ze(e), r(void 0))
  })
}

function ar(t) {
  return ut(en, t)
}

function cl(t) {
  return ut(Qt | cn, t)
}

function Xr(t, e = 0) {
  return ut(Cn | e, t)
}

function ne(t, e = [], n = [], r = []) {
  Ki(r, e, n, i => {
    ut(Cn, () => {
      t(...i.map(o))
    })
  })
}

function Mn(t, e = 0) {
  var n = ut(Xe | e, t);
  return n
}

function fa(t, e = 0) {
  var n = ut(Vr | e, t);
  return n
}

function Fe(t) {
  return ut(Je | cn, t)
}

function da(t) {
  var e = t.teardown;
  if (e !== null) {
    const n = kt,
      r = q;
    di(!0), Qe(null);
    try {
      e.call(null)
    } finally {
      di(n), Qe(r)
    }
  }
}

function Zr(t, e = !1) {
  var n = t.first;
  for (t.first = t.last = null; n !== null;) {
    const i = n.ac;
    i !== null && Dt(() => {
      i.abort(Tn)
    });
    var r = n.next;
    (n.f & mt) !== 0 ? n.parent = null : ze(n, e), n = r
  }
}

function ul(t) {
  for (var e = t.first; e !== null;) {
    var n = e.next;
    (e.f & Je) === 0 && ze(e), e = n
  }
}

function ze(t, e = !0) {
  var n = !1;
  (e || (t.f & rs) !== 0) && t.nodes !== null && t.nodes.end !== null && (fl(t.nodes.start, t.nodes.end), n = !0), t.f |= kr, Zr(t, e && !n), zn(t, 0);
  var r = t.nodes && t.nodes.t;
  if (r !== null)
    for (const a of r) a.stop();
  da(t), t.f ^= kr, t.f |= Ge;
  var i = t.parent;
  i !== null && i.first !== null && va(t), t.next = t.prev = t.teardown = t.ctx = t.deps = t.fn = t.nodes = t.ac = t.b = null
}

function fl(t, e) {
  for (; t !== null;) {
    var n = t === e ? null : An(t);
    t.remove(), t = n
  }
}

function va(t) {
  var e = t.parent,
    n = t.prev,
    r = t.next;
  n !== null && (n.next = r), r !== null && (r.prev = n), e !== null && (e.first === t && (e.first = r), e.last === t && (e.last = n))
}

function jt(t, e, n = !0) {
  var r = [];
  ha(t, r, !0);
  var i = () => {
      n && ze(t), e && e()
    },
    a = r.length;
  if (a > 0) {
    var s = () => --a || i();
    for (var l of r) l.out(s)
  } else i()
}

function ha(t, e, n) {
  if ((t.f & De) === 0) {
    t.f ^= De;
    var r = t.nodes && t.nodes.t;
    if (r !== null)
      for (const l of r)(l.is_global || n) && e.push(l);
    for (var i = t.first; i !== null;) {
      var a = i.next;
      if ((i.f & mt) === 0) {
        var s = (i.f & Pt) !== 0 || (i.f & Je) !== 0 && (t.f & Xe) !== 0;
        ha(i, e, s ? n : !1)
      }
      i = a
    }
  }
}

function Jn(t) {
  pa(t, !0)
}

function pa(t, e) {
  if ((t.f & De) !== 0) {
    t.f ^= De, (t.f & ke) === 0 && (he(t, ye), Ot.ensure().schedule(t));
    for (var n = t.first; n !== null;) {
      var r = n.next,
        i = (n.f & Pt) !== 0 || (n.f & Je) !== 0;
      pa(n, i ? e : !1), n = r
    }
    var a = t.nodes && t.nodes.t;
    if (a !== null)
      for (const s of a)(s.is_global || e) && s.in()
  }
}

function Jr(t, e) {
  if (t.nodes)
    for (var n = t.nodes.start, r = t.nodes.end; n !== null;) {
      var i = n === r ? null : An(n);
      e.append(n), n = i
    }
}
let Hn = !1,
  kt = !1;

function di(t) {
  kt = t
}
let q = null,
  at = !1;

function Qe(t) {
  q = t
}
let B = null;

function et(t) {
  B = t
}
let ht = null;

function _a(t) {
  q !== null && (ht ??= new Set).add(t)
}
let We = null,
  Ue = 0,
  Ke = null;

function dl(t) {
  Ke = t
}
let ga = 1,
  Bt = 0,
  Vt = Bt;

function vi(t) {
  Vt = t
}

function ba() {
  return ++ga
}

function Pn(t) {
  var e = t.f;
  if ((e & ye) !== 0) return !0;
  if (e & Ee && (t.f &= ~Ht), (e & st) !== 0) {
    for (var n = t.deps, r = n.length, i = 0; i < r; i++) {
      var a = n[i];
      if (Pn(a) && Zi(a), a.wv > t.wv) return !0
    }(e & Ze) !== 0 && it === null && he(t, ke)
  }
  return !1
}

function wa(t, e, n = !0) {
  var r = t.reactions;
  if (r !== null && !(ht !== null && ht.has(t)))
    for (var i = 0; i < r.length; i++) {
      var a = r[i];
      (a.f & Ee) !== 0 ? wa(a, e, !1) : e === a && (n ? he(a, ye) : (a.f & ke) !== 0 && he(a, st), Yr(a))
    }
}

function ya(t) {
  var e = We,
    n = Ue,
    r = Ke,
    i = q,
    a = ht,
    s = oe,
    l = at,
    c = Vt,
    u = t.f;
  We = null, Ue = 0, Ke = null, q = (u & (Je | mt)) === 0 ? t : null, ht = null, tn(t.ctx), at = !1, Vt = ++Bt, t.ac !== null && (Dt(() => {
    t.ac.abort(Tn)
  }), t.ac = null);
  try {
    t.f |= Kn;
    var d = t.fn,
      f = d();
    t.f |= qt;
    var v = t.deps,
      p = H?.is_fork;
    if (We !== null) {
      var _;
      if (p || zn(t, Ue), v !== null && Ue > 0)
        for (v.length = Ue + We.length, _ = 0; _ < We.length; _++) v[Ue + _] = We[_];
      else t.deps = v = We;
      if (Kr() && (t.f & Ze) !== 0)
        for (_ = Ue; _ < v.length; _++)(v[_].reactions ??= []).push(t)
    } else !p && v !== null && Ue < v.length && (zn(t, Ue), v.length = Ue);
    if (fn() && Ke !== null && !at && v !== null && (t.f & (Ee | st | ye)) === 0)
      for (_ = 0; _ < Ke.length; _++) wa(Ke[_], t);
    if (i !== null && i !== t) {
      if (Bt++, i.deps !== null)
        for (let m = 0; m < n; m += 1) i.deps[m].rv = Bt;
      if (e !== null)
        for (const m of e) m.rv = Bt;
      Ke !== null && (r === null ? r = Ke : r.push(...Ke))
    }
    return (t.f & Mt) !== 0 && (t.f ^= Mt), f
  } catch (m) {
    return Gi(m)
  } finally {
    t.f ^= Kn, We = e, Ue = n, Ke = r, q = i, ht = a, tn(s), at = l, Vt = c
  }
}

function vl(t, e) {
  let n = e.reactions;
  if (n !== null) {
    var r = Ja.call(n, t);
    if (r !== -1) {
      var i = n.length - 1;
      i === 0 ? n = e.reactions = null : (n[r] = n[i], n.pop())
    }
  }
  if (n === null && (e.f & Ee) !== 0 && (We === null || !qn.call(We, e))) {
    var a = e;
    (a.f & Ze) !== 0 && (a.f ^= Ze, a.f &= ~Ht), a.v !== we && Ur(a), a.ac !== null && Dt(() => {
      a.ac.abort(Tn), a.ac = null, he(a, ye)
    }), Zs(a), zn(a, 0)
  }
}

function zn(t, e) {
  var n = t.deps;
  if (n !== null)
    for (var r = e; r < n.length; r++) vl(t, n[r])
}

function sn(t) {
  var e = t.f;
  if ((e & Ge) === 0) {
    he(t, ke);
    var n = B,
      r = Hn;
    B = t, Hn = (e & (Je | mt)) === 0;
    try {
      (e & (Xe | Vr)) !== 0 ? ul(t) : Zr(t), da(t);
      var i = ya(t);
      t.teardown = typeof i == "function" ? i : null, t.wv = ga;
      var a;
      Pi && Ds && (t.f & ye) !== 0 && t.deps
    } finally {
      Hn = r, B = n
    }
  }
}
async function Nt() {
  await Promise.resolve(), Qs()
}

function o(t) {
  var e = t.f,
    n = (e & Ee) !== 0;
  if (q !== null && !at) {
    var r = B !== null && (B.f & Ge) !== 0;
    if (!r && (ht === null || !ht.has(t))) {
      var i = q.deps;
      if ((q.f & Kn) !== 0) t.rv < Bt && (t.rv = Bt, We === null && i !== null && i[Ue] === t ? Ue++ : We === null ? We = [t] : We.push(t));
      else {
        q.deps ??= [], qn.call(q.deps, t) || q.deps.push(t);
        var a = t.reactions;
        a === null ? t.reactions = [q] : qn.call(a, q) || a.push(q)
      }
    }
  }
  if (kt && vt.has(t)) return vt.get(t);
  if (n) {
    var s = t;
    if (kt) {
      var l = s.v;
      return ((s.f & ke) === 0 && s.reactions !== null || ka(s)) && (l = Gr(s)), vt.set(s, l), l
    }
    var c = (s.f & Ze) === 0 && !at && q !== null && (Hn || (q.f & Ze) !== 0),
      u = (s.f & qt) === 0;
    Pn(s) && (c && (s.f |= Ze), Zi(s)), c && !u && (Ji(s), ma(s))
  }
  if (it?.has(t)) return it.get(t);
  if ((t.f & Mt) !== 0) throw t.v;
  return t.v
}

function ma(t) {
  if (t.f |= Ze, t.deps !== null)
    for (const e of t.deps)(e.reactions ??= []).push(t), (e.f & Ee) !== 0 && (e.f & Ze) === 0 && (Ji(e), ma(e))
}

function ka(t) {
  if (t.v === we) return !0;
  if (t.deps === null) return !1;
  for (const e of t.deps)
    if (vt.has(e) || (e.f & Ee) !== 0 && ka(e)) return !0;
  return !1
}

function Lt(t) {
  var e = at;
  try {
    return at = !0, t()
  } finally {
    at = e
  }
}

function Tr(t) {
  if (!(typeof t != "object" || !t || t instanceof EventTarget)) {
    if (dt in t) Ar(t);
    else if (!Array.isArray(t))
      for (let e in t) {
        const n = t[e];
        typeof n == "object" && n && dt in n && Ar(n)
      }
  }
}

function Ar(t, e = new Set) {
  if (typeof t == "object" && t !== null && !(t instanceof EventTarget) && !e.has(t)) {
    e.add(t), t instanceof Date && t.getTime();
    for (let r in t) try {
      Ar(t[r], e)
    } catch {}
    const n = jr(t);
    if (n !== Object.prototype && n !== Array.prototype && n !== Map.prototype && n !== Set.prototype && n !== Date.prototype) {
      const r = Oi(n);
      for (let i in r) {
        const a = r[i].get;
        if (a) try {
          a.call(t)
        } catch {}
      }
    }
  }
}

function hl(t) {
  return t.endsWith("capture") && t !== "gotpointercapture" && t !== "lostpointercapture"
}
const pl = ["beforeinput", "click", "change", "dblclick", "contextmenu", "focusin", "focusout", "input", "keydown", "keyup", "mousedown", "mousemove", "mouseout", "mouseover", "mouseup", "pointerdown", "pointermove", "pointerout", "pointerover", "pointerup", "touchend", "touchmove", "touchstart"];

function _l(t) {
  return pl.includes(t)
}
const gl = {
  formnovalidate: "formNoValidate",
  ismap: "isMap",
  nomodule: "noModule",
  playsinline: "playsInline",
  readonly: "readOnly",
  defaultvalue: "defaultValue",
  defaultchecked: "defaultChecked",
  srcobject: "srcObject",
  novalidate: "noValidate",
  allowfullscreen: "allowFullscreen",
  disablepictureinpicture: "disablePictureInPicture",
  disableremoteplayback: "disableRemotePlayback"
};

function bl(t) {
  return t = t.toLowerCase(), gl[t] ?? t
}
const wl = ["touchstart", "touchmove"];

function yl(t) {
  return wl.includes(t)
}
const bn = Symbol("events"),
  xa = new Set,
  Mr = new Set;

function Ea(t, e, n, r = {}) {
  function i(a) {
    if (r.capture || Or.call(e, a), !a.cancelBubble) return Dt(() => n?.call(this, a))
  }
  return t.startsWith("pointer") || t.startsWith("touch") || t === "wheel" ? rt(() => {
    e.addEventListener(t, i, r)
  }) : e.addEventListener(t, i, r), i
}

function Pr(t, e, n, r, i) {
  var a = {
      capture: r,
      passive: i
    },
    s = Ea(t, e, n, a);
  (e === document.body || e === window || e === document || e instanceof HTMLMediaElement) && ir(() => {
    e.removeEventListener(t, s, a)
  })
}

function C(t, e, n) {
  (e[bn] ??= {})[t] = n
}

function It(t) {
  for (var e = 0; e < t.length; e++) xa.add(t[e]);
  for (var n of Mr) n(t)
}
let ur = null,
  fr = !1;

function Or(t) {
  var e = this,
    n = e.ownerDocument,
    r = t.type,
    i = t.composedPath?.() || [],
    a = i[0] || t.target;
  ur = t, fr || (fr = !0, setTimeout(() => {
    fr = !1, ur = null
  }));
  var s = 0,
    l = ur === t && t[bn];
  if (l) {
    var c = i.indexOf(l);
    if (c !== -1 && (e === document || e === window)) {
      t[bn] = e;
      return
    }
    var u = i.indexOf(e);
    if (u === -1) return;
    c <= u && (s = c)
  }
  if (a = i[s] || t.target, a !== e) {
    Qa(t, "currentTarget", {
      configurable: !0,
      get() {
        return a || n
      }
    });
    var d = q,
      f = B;
    Qe(null), et(null);
    try {
      for (var v, p = []; a !== null && a !== e;) {
        try {
          var _ = a[bn]?.[r];
          _ != null && (!a.disabled || t.target === a) && _.call(a, t)
        } catch (m) {
          v ? p.push(m) : v = m
        }
        if (t.cancelBubble) break;
        s++, a = s < i.length ? i[s] : null
      }
      if (v) {
        for (let m of p) queueMicrotask(() => {
          throw m
        });
        throw v
      }
    } finally {
      t[bn] = e, delete t.currentTarget, Qe(d), et(f)
    }
  }
}
const ml = globalThis?.window?.trustedTypes && globalThis.window.trustedTypes.createPolicy("svelte-trusted-html", {
  createHTML: t => t
});

function kl(t) {
  return ml?.createHTML(t) ?? t
}

function Sa(t) {
  var e = oa("template");
  return e.innerHTML = kl(t.replaceAll("<!>", "<!---->")), e.content
}

function $n(t, e) {
  var n = B;
  n.nodes === null && (n.nodes = {
    start: t,
    end: e,
    a: null,
    t: null
  })
}

function M(t, e) {
  var n = (e & Ns) !== 0,
    r = (e & Cs) !== 0,
    i, a = !t.startsWith("<!>");
  return () => {
    i === void 0 && (i = Sa(a ? t : "<!>" + t), n || (i = an(i)));
    var s = r || ia ? document.importNode(i, !0) : i.cloneNode(!0);
    if (n) {
      var l = an(s),
        c = s.lastChild;
      $n(l, c)
    } else $n(s, s);
    return s
  }
}

function xl(t, e, n = "svg") {
  var r = !t.startsWith("<!>"),
    i = `<${n}>${r?t:"<!>"+t}</${n}>`,
    a;
  return () => {
    if (!a) {
      var s = Sa(i),
        l = an(s);
      a = an(l)
    }
    var c = a.cloneNode(!0);
    return $n(c, c), c
  }
}

function El(t, e) {
  return xl(t, e, "svg")
}

function ee() {
  var t = document.createDocumentFragment(),
    e = document.createComment(""),
    n = yt();
  return t.append(e, n), $n(e, n), t
}

function x(t, e) {
  t !== null && t.before(e)
}
let Qn = !0;

function Wn(t) {
  Qn = t
}

function ae(t, e) {
  var n = e == null ? "" : typeof e == "object" ? `${e}` : e;
  n !== (t[Sr] ??= t.nodeValue) && (t[Sr] = n, t.nodeValue = `${n}`)
}

function Sl(t, e) {
  return zl(t, e)
}
const Fn = new Map;

function zl(t, {
  target: e,
  anchor: n,
  props: r = {},
  events: i,
  context: a,
  intro: s = !0,
  transformError: l
}) {
  il();
  var c = void 0,
    u = ol(() => {
      var d = n ?? e.appendChild(yt());
      Gs(d, {
        pending: () => {}
      }, p => {
        ot({});
        var _ = oe;
        a && (_.c = a), i && (r.$$events = i), Qn = s, c = t(p, r) || {}, Qn = !0, ct()
      }, l);
      var f = new Set,
        v = p => {
          for (var _ = 0; _ < p.length; _++) {
            var m = p[_];
            if (!f.has(m)) {
              f.add(m);
              var g = yl(m);
              for (const A of [e, document]) {
                var k = Fn.get(A);
                k === void 0 && (k = new Map, Fn.set(A, k));
                var E = k.get(m);
                E === void 0 ? (A.addEventListener(m, Or, {
                  passive: g
                }), k.set(m, 1)) : k.set(m, E + 1)
              }
            }
          }
        };
      return v(nr(xa)), Mr.add(v), () => {
        for (var p of f)
          for (const g of [e, document]) {
            var _ = Fn.get(g),
              m = _.get(p);
            --m == 0 ? (g.removeEventListener(p, Or), _.delete(p), _.size === 0 && Fn.delete(g)) : _.set(p, m)
          }
        Mr.delete(v), d !== n && d.parentNode?.removeChild(d)
      }
    });
  return $l.set(c, u), c
}
let $l = new WeakMap;
class Qr {
  anchor;
  #t = new Map;
  #s = new Map;
  #e = new Map;
  #o = new Set;
  #r = !0;
  constructor(e, n = !0) {
    this.anchor = e, this.#r = n
  }
  #a = e => {
    if (this.#t.has(e)) {
      var n = this.#t.get(e),
        r = this.#s.get(n);
      if (r) Jn(r), this.#o.delete(n);
      else {
        var i = this.#e.get(n);
        i && (Jn(i.effect), this.#s.set(n, i.effect), this.#e.delete(n), i.fragment.lastChild.remove(), this.anchor.before(i.fragment), r = i.effect)
      }
      for (const [a, s] of this.#t) {
        if (this.#t.delete(a), a === e) break;
        const l = this.#e.get(s);
        l && (ze(l.effect), this.#e.delete(s))
      }
      for (const [a, s] of this.#s) {
        if (a === n || this.#o.has(a)) continue;
        const l = () => {
          if (Array.from(this.#t.values()).includes(a)) {
            var u = document.createDocumentFragment();
            Jr(s, u), u.append(yt()), this.#e.set(a, {
              effect: s,
              fragment: u
            })
          } else ze(s);
          this.#o.delete(a), this.#s.delete(a)
        };
        this.#r || !r ? (this.#o.add(a), jt(s, l, !1)) : l()
      }
    }
  };
  #n = e => {
    this.#t.delete(e);
    const n = Array.from(this.#t.values());
    for (const [r, i] of this.#e) n.includes(r) || (ze(i.effect), this.#e.delete(r))
  };
  ensure(e, n) {
    var r = H,
      i = la();
    if (n && !this.#s.has(e) && !this.#e.has(e))
      if (i) {
        var a = document.createDocumentFragment(),
          s = yt();
        a.append(s), this.#e.set(e, {
          effect: Fe(() => n(s)),
          fragment: a
        })
      } else this.#s.set(e, Fe(() => n(this.anchor)));
    if (this.#t.set(r, e), i) {
      for (const [l, c] of this.#s) l === e ? r.unskip_effect(c) : r.skip_effect(c);
      for (const [l, c] of this.#e) l === e ? r.unskip_effect(c.effect) : r.skip_effect(c.effect);
      r.oncommit(this.#a), r.ondiscard(this.#n)
    } else this.#a(r)
  }
}

function pe(t, e, n = !1) {
  var r = new Qr(t),
    i = n ? Pt : 0;

  function a(s, l) {
    r.ensure(s, l)
  }
  Mn(() => {
    var s = !1;
    e((l, c = 0) => {
      s = !0, a(c, l)
    }), s || a(-1, null)
  }, i)
}
const Nl = Symbol("NaN");

function Cl(t, e, n) {
  var r = new Qr(t),
    i = !fn();
  Mn(() => {
    var a = e();
    a !== a && (a = Nl), i && a !== null && typeof a == "object" && (a = {}), r.ensure(a, n)
  })
}

function ln(t, e) {
  return e
}

function Tl(t, e, n) {
  for (var r = [], i = e.length, a, s = e.length, l = 0; l < i; l++) {
    let f = e[l];
    jt(f, () => {
      if (a) {
        if (a.pending.delete(f), a.done.add(f), a.pending.size === 0) {
          var v = t.outrogroups;
          Rr(t, nr(a.done)), v.delete(a), v.size === 0 && (t.outrogroups = null)
        }
      } else s -= 1
    }, !1)
  }
  if (s === 0) {
    var c = r.length === 0 && n !== null && t.pending.size === 0;
    if (c) {
      var u = n,
        d = u.parentNode;
      al(d), d.append(u), t.items.clear()
    }
    Rr(t, e, !c)
  } else a = {
    pending: new Set(e),
    done: new Set
  }, (t.outrogroups ??= new Set).add(a)
}

function Rr(t, e, n = !0) {
  var r;
  if (t.pending.size > 0) {
    r = new Set;
    for (const s of t.pending.values())
      for (const l of s) r.add(t.items.get(l).e)
  }
  for (var i = 0; i < e.length; i++) {
    var a = e[i];
    if (r?.has(a)) {
      a.f |= ft;
      const s = document.createDocumentFragment();
      Jr(a, s)
    } else ze(e[i], n)
  }
}
var hi;

function lt(t, e, n, r, i, a = null) {
  var s = t,
    l = new Map,
    c = (e & Fi) !== 0;
  if (c) {
    var u = t;
    s = u.appendChild(yt())
  }
  var d = null,
    f = Hr(() => {
      var A = n();
      return Br(A) ? A : A == null ? [] : nr(A)
    }),
    v, p = new Map,
    _ = !0;

  function m(A) {
    (E.effect.f & Ge) === 0 && (E.pending.delete(A), E.fallback = d, Al(E, v, s, e, r), d !== null && (v.length === 0 ? (d.f & ft) === 0 ? Jn(d) : (d.f ^= ft, wn(d, null, s)) : jt(d, () => {
      d = null
    })))
  }

  function g(A) {
    E.pending.delete(A)
  }
  var k = Mn(() => {
      v = o(f);
      for (var A = v.length, S = new Set, T = H, P = la(), j = 0; j < A; j += 1) {
        var I = v[j],
          te = r(I, j),
          U = _ ? null : l.get(te);
        U ? (U.v && rn(U.v, I), U.i && rn(U.i, j), P && T.unskip_effect(U.e)) : (U = Ml(l, _ ? s : hi ??= yt(), I, te, j, i, e, n), _ || (U.e.f |= ft), l.set(te, U)), S.add(te)
      }
      if (A === 0 && a && !d && (_ ? d = Fe(() => a(s)) : (d = Fe(() => a(hi ??= yt())), d.f |= ft)), A > S.size && ls(), !_)
        if (p.set(T, S), P) {
          for (const [Te, $e] of l) S.has(Te) || T.skip_effect($e.e);
          T.oncommit(m), T.ondiscard(g)
        } else m(T);
      o(f)
    }),
    E = {
      effect: k,
      items: l,
      pending: p,
      outrogroups: null,
      fallback: d
    };
  _ = !1
}

function hn(t) {
  for (; t !== null && (t.f & Je) === 0;) t = t.next;
  return t
}

function Al(t, e, n, r, i) {
  var a = (r & ws) !== 0,
    s = e.length,
    l = t.items,
    c = hn(t.effect.first),
    u, d = null,
    f, v = [],
    p = [],
    _, m, g, k;
  if (a)
    for (k = 0; k < s; k += 1) _ = e[k], m = i(_, k), g = l.get(m).e, (g.f & ft) === 0 && (g.nodes?.a?.measure(), (f ??= new Set).add(g));
  for (k = 0; k < s; k += 1) {
    if (_ = e[k], m = i(_, k), g = l.get(m).e, t.outrogroups !== null)
      for (const U of t.outrogroups) U.pending.delete(g), U.done.delete(g);
    if ((g.f & De) !== 0 && (Jn(g), a && (g.nodes?.a?.unfix(), (f ??= new Set).delete(g))), (g.f & ft) !== 0)
      if (g.f ^= ft, g === c) wn(g, null, n);
      else {
        var E = d ? d.next : c;
        g === t.effect.last && (t.effect.last = g.prev), g.prev && (g.prev.next = g.next), g.next && (g.next.prev = g.prev), $t(t, d, g), $t(t, g, E), wn(g, E, n), d = g, v = [], p = [], c = hn(d.next);
        continue
      } if (g !== c) {
      if (u !== void 0 && u.has(g)) {
        if (v.length < p.length) {
          var A = p[0],
            S;
          d = A.prev;
          var T = v[0],
            P = v[v.length - 1];
          for (S = 0; S < v.length; S += 1) wn(v[S], A, n);
          for (S = 0; S < p.length; S += 1) u.delete(p[S]);
          $t(t, T.prev, P.next), $t(t, d, T), $t(t, P, A), c = A, d = P, k -= 1, v = [], p = []
        } else u.delete(g), wn(g, c, n), $t(t, g.prev, g.next), $t(t, g, d === null ? t.effect.first : d.next), $t(t, d, g), d = g;
        continue
      }
      for (v = [], p = []; c !== null && c !== g;)(u ??= new Set).add(c), p.push(c), c = hn(c.next);
      if (c === null) continue
    }(g.f & ft) === 0 && v.push(g), d = g, c = hn(g.next)
  }
  if (t.outrogroups !== null) {
    for (const U of t.outrogroups) U.pending.size === 0 && (Rr(t, nr(U.done)), t.outrogroups?.delete(U));
    t.outrogroups.size === 0 && (t.outrogroups = null)
  }
  if (c !== null || u !== void 0) {
    var j = [];
    if (u !== void 0)
      for (g of u)(g.f & De) === 0 && j.push(g);
    for (; c !== null;)(c.f & De) === 0 && c !== t.fallback && j.push(c), c = hn(c.next);
    var I = j.length;
    if (I > 0) {
      var te = (r & Fi) !== 0 && s === 0 ? n : null;
      if (a) {
        for (k = 0; k < I; k += 1) j[k].nodes?.a?.measure();
        for (k = 0; k < I; k += 1) j[k].nodes?.a?.fix()
      }
      Tl(t, j, te)
    }
  }
  a && rt(() => {
    if (f !== void 0)
      for (g of f) g.nodes?.a?.apply()
  })
}

function Ml(t, e, n, r, i, a, s, l) {
  var c = (s & gs) !== 0 ? (s & ys) === 0 ? tl(n, !1, !1) : Rt(n) : null,
    u = (s & bs) !== 0 ? Rt(i) : null;
  return {
    v: c,
    i: u,
    e: Fe(() => (a(e, c ?? n, u ?? i, l), () => {
      t.delete(r)
    }))
  }
}

function wn(t, e, n) {
  if (t.nodes)
    for (var r = t.nodes.start, i = t.nodes.end, a = e && (e.f & ft) === 0 ? e.nodes.start : n; r !== null;) {
      var s = An(r);
      if (a.before(r), r === i) return;
      r = s
    }
}

function $t(t, e, n) {
  e === null ? t.effect.first = n : e.next = n, n === null ? t.effect.last = e : n.prev = e
}

function le(t, e, n, r, i) {
  var a = e.$$slots?.[n],
    s = !1;
  a === !0 && (a = e.children, s = !0), a === void 0 || a(t, s ? () => r : r)
}
const Pl = () => performance.now(),
  wt = {
    tick: t => requestAnimationFrame(t),
    now: () => Pl(),
    tasks: new Set
  };

function za() {
  const t = wt.now();
  wt.tasks.forEach(e => {
    e.c(t) || (wt.tasks.delete(e), e.f())
  }), wt.tasks.size !== 0 && wt.tick(za)
}

function Ol(t) {
  let e;
  return wt.tasks.size === 0 && wt.tick(za), {
    promise: new Promise(n => {
      wt.tasks.add(e = {
        c: t,
        f: n
      })
    }),
    abort() {
      wt.tasks.delete(e)
    }
  }
}

function Bn(t, e) {
  Dt(() => {
    t.dispatchEvent(new CustomEvent(e))
  })
}

function Rl(t) {
  if (t === "float") return "cssFloat";
  if (t === "offset") return "cssOffset";
  if (t.startsWith("--")) return t;
  const e = t.split("-");
  return e.length === 1 ? e[0] : e[0] + e.slice(1).map(n => n[0].toUpperCase() + n.slice(1)).join("")
}

function pi(t) {
  const e = {},
    n = t.split(";");
  for (const r of n) {
    const [i, a] = r.split(":");
    if (!i || a === void 0) break;
    const s = Rl(i.trim());
    e[s] = a.trim()
  }
  return e
}
const Dl = t => t;

function on(t, e, n, r) {
  var i = (t & Ss) !== 0,
    a = (t & zs) !== 0,
    s = i && a,
    l = (t & $s) !== 0,
    c = s ? "both" : i ? "in" : "out",
    u, d = e.inert,
    f = e.style.overflow,
    v, p;

  function _() {
    return Dt(() => u ??= n()(e, r?.() ?? {}, {
      direction: c
    }))
  }
  var m = {
      is_global: l,
      in() {
        if (e.inert = d, !i) {
          p?.abort(), p?.reset?.();
          return
        }
        a || v?.abort(), v = Dr(e, _(), p, 1, () => {
          Bn(e, "introstart")
        }, () => {
          Bn(e, "introend"), v?.abort(), v = u = void 0, e.style.overflow = f
        })
      },
      out(A) {
        if (!a) {
          A?.(), u = void 0;
          return
        }
        e.inert = !0, p = Dr(e, _(), v, 0, () => {
          Bn(e, "outrostart")
        }, () => {
          Bn(e, "outroend"), A?.()
        })
      },
      stop: () => {
        v?.abort(), p?.abort()
      }
    },
    g = B;
  if ((g.nodes.t ??= []).push(m), i && Qn) {
    var k = l;
    if (!k) {
      for (var E = g.parent; E && (E.f & Pt) !== 0;)
        for (;
          (E = E.parent) && (E.f & Xe) === 0;);
      k = !E || (E.f & qt) !== 0
    }
    k && ar(() => {
      Lt(() => m.in())
    })
  }
}

function Dr(t, e, n, r, i, a) {
  var s = r === 1;
  if (Xt(e)) {
    var l, c = !1;
    return rt(() => {
      if (!c) {
        var k = e({
          direction: s ? "in" : "out"
        });
        l = Dr(t, k, n, r, i, a)
      }
    }), {
      abort: () => {
        c = !0, l?.abort()
      },
      deactivate: () => l.deactivate(),
      reset: () => l.reset(),
      t: () => l.t()
    }
  }
  if (n?.deactivate(), !e?.duration && !e?.delay) return i(), a(), {
    abort: Zt,
    deactivate: Zt,
    reset: Zt,
    t: () => r
  };
  const {
    delay: u = 0,
    css: d,
    tick: f,
    easing: v = Dl
  } = e;
  var p = [];
  if (s && n === void 0 && (f && f(0, 1), d)) {
    var _ = pi(d(0, 1));
    p.push(_, _)
  }
  var m = () => 1 - r,
    g = t.animate(p, {
      duration: u,
      fill: "forwards"
    });
  return g.onfinish = () => {
    g.cancel(), i();
    var k = n?.t() ?? 1 - r;
    n?.abort();
    var E = r - k,
      A = e.duration * Math.abs(E),
      S = [];
    if (A > 0) {
      var T = !1;
      if (d)
        for (var P = Math.ceil(A / 16.666666666666668), j = 0; j <= P; j += 1) {
          var I = k + E * v(j / P),
            te = pi(d(I, 1 - I));
          S.push(te), T ||= te.overflow === "hidden"
        }
      T && (t.style.overflow = "hidden"), m = () => {
        var U = g.currentTime;
        return k + E * v(U / A)
      }, f && Ol(() => {
        if (g.playState !== "running") return !1;
        var U = m();
        return f(U, 1 - U), !0
      })
    }
    g = t.animate(S, {
      duration: A,
      fill: "forwards"
    }), g.onfinish = () => {
      m = () => r, f?.(r, 1 - r), a()
    }
  }, {
    abort: () => {
      g && (g.cancel(), g.effect = null, g.onfinish = Zt)
    },
    deactivate: () => {
      a = Zt
    },
    reset: () => {
      r === 0 && f?.(1, 0)
    },
    t: () => m()
  }
}

function Ll(t, e, n, r, i, a) {
  var s = null,
    l = t,
    c = new Qr(l, !1);
  Mn(() => {
    const u = e() || null;
    var d = Ts;
    if (u === null) {
      c.ensure(null, null), Wn(!0);
      return
    }
    return c.ensure(u, f => {
      if (u) {
        if (s = oa(u, d), $n(s, s), r) {
          var v = null,
            p = s.appendChild(yt());
          r(s, p), v?.remove()
        }
        B.nodes.end = s, f.before(s)
      }
    }), Wn(!0), () => {
      u && Wn(!1)
    }
  }, Pt), ir(() => {
    Wn(!0)
  })
}

function Il(t, e) {
  var n = void 0,
    r;
  fa(() => {
    n !== (n = e()) && (r && (ze(r), r = null), n && (r = Fe(() => {
      ar(() => n(t))
    })))
  })
}

function $a(t) {
  var e, n, r = "";
  if (typeof t == "string" || typeof t == "number") r += t;
  else if (typeof t == "object")
    if (Array.isArray(t)) {
      var i = t.length;
      for (e = 0; e < i; e++) t[e] && (n = $a(t[e])) && (r && (r += " "), r += n)
    } else
      for (n in t) t[n] && (r && (r += " "), r += n);
  return r
}

function Wl() {
  for (var t, e, n = 0, r = "", i = arguments.length; n < i; n++)(t = arguments[n]) && (e = $a(t)) && (r && (r += " "), r += e);
  return r
}

function Fl(t) {
  return typeof t == "object" ? Wl(t) : t ?? ""
}
const _i = [...` 	
\r\f \v\uFEFF`];

function Bl(t, e, n) {
  var r = t == null ? "" : "" + t;
  if (e && (r = r ? r + " " + e : e), n) {
    for (var i of Object.keys(n))
      if (n[i]) r = r ? r + " " + i : i;
      else if (r.length)
      for (var a = i.length, s = 0;
        (s = r.indexOf(i, s)) >= 0;) {
        var l = s + a;
        (s === 0 || _i.includes(r[s - 1])) && (l === r.length || _i.includes(r[l])) ? r = (s === 0 ? "" : r.substring(0, s)) + r.substring(l + 1): s = l
      }
  }
  return r === "" ? null : r
}

function gi(t, e = !1) {
  var n = e ? " !important;" : ";",
    r = "";
  for (var i of Object.keys(t)) {
    var a = t[i];
    a != null && a !== "" && (r += " " + i + ": " + a + n)
  }
  return r
}

function dr(t) {
  return t[0] !== "-" || t[1] !== "-" ? t.toLowerCase() : t
}

function jl(t, e) {
  if (e) {
    var n = "",
      r, i;
    if (Array.isArray(e) ? (r = e[0], i = e[1]) : r = e, t) {
      t = String(t).replaceAll(/\/\*.*?\*\//g, "").trim();
      var a = !1,
        s = 0,
        l = !1,
        c = [];
      r && c.push(...Object.keys(r).map(dr)), i && c.push(...Object.keys(i).map(dr));
      var u = 0,
        d = -1;
      const m = t.length;
      for (var f = 0; f < m; f++) {
        var v = t[f];
        if (l ? v === "/" && t[f - 1] === "*" && (l = !1) : a ? a === v && (a = !1) : v === "/" && t[f + 1] === "*" ? l = !0 : v === '"' || v === "'" ? a = v : v === "(" ? s++ : v === ")" && s--, !l && a === !1 && s === 0) {
          if (v === ":" && d === -1) d = f;
          else if (v === ";" || f === m - 1) {
            if (d !== -1) {
              var p = dr(t.substring(u, d).trim());
              if (!c.includes(p)) {
                v !== ";" && f++;
                var _ = t.substring(u, f).trim();
                n += " " + _ + ";"
              }
            }
            u = f + 1, d = -1
          }
        }
      }
    }
    return r && (n += gi(r)), i && (n += gi(i, !0)), n = n.trim(), n === "" ? null : n
  }
  return t == null ? null : String(t)
}

function Se(t, e, n, r, i, a) {
  var s = t[xr];
  if (s !== n || s === void 0) {
    var l = Bl(n, r, a);
    l == null ? t.removeAttribute("class") : e ? t.className = l : t.setAttribute("class", l), t[xr] = n
  } else if (a && i !== a)
    for (var c in a) {
      var u = !!a[c];
      (i == null || u !== !!i[c]) && t.classList.toggle(c, u)
    }
  return a
}

function vr(t, e = {}, n, r) {
  for (var i in n) {
    var a = n[i];
    e[i] !== a && (n[i] == null ? t.style.removeProperty(i) : t.style.setProperty(i, a, r))
  }
}

function On(t, e, n, r) {
  var i = t[Er];
  if (i !== e) {
    var a = jl(e, r);
    a == null ? t.removeAttribute("style") : t.style.cssText = a, t[Er] = e
  } else r && (Array.isArray(r) ? (vr(t, n?.[0], r[0]), vr(t, n?.[1], r[1], "important")) : vr(t, n, r));
  return r
}

function Lr(t, e, n = !1) {
  if (t.multiple) {
    if (e == null) return;
    if (!Br(e)) return Ps();
    for (var r of t.options) r.selected = e.includes(bi(r));
    return
  }
  for (r of t.options) {
    var i = bi(r);
    if (rl(i, e)) {
      r.selected = !0;
      return
    }
  }(!n || e !== void 0) && (t.selectedIndex = -1)
}

function Vl(t) {
  var e = new MutationObserver(() => {
    "__value" in t && Lr(t, t.__value)
  });
  e.observe(t, {
    childList: !0,
    subtree: !0,
    attributes: !0,
    attributeFilter: ["value"]
  }), ir(() => {
    e.disconnect()
  })
}

function bi(t) {
  return "__value" in t ? t.__value : t.value
}
const pn = Symbol("class"),
  _n = Symbol("style"),
  Na = Symbol("is custom element"),
  Ca = Symbol("is html"),
  Ul = rr ? "input" : "INPUT",
  Hl = rr ? "option" : "OPTION",
  Gl = rr ? "select" : "SELECT",
  ql = rr ? "progress" : "PROGRESS";

function Yl(t, e) {
  var n = ei(t);
  n.value === (n.value = e ?? void 0) || t.value === e && (e !== 0 || t.nodeName !== ql) || (t.value = e ?? "")
}

function Kl(t, e) {
  e ? t.hasAttribute("selected") || t.setAttribute("selected", "") : t.removeAttribute("selected")
}

function Ut(t, e, n, r) {
  var i = ei(t);
  i[e] !== (i[e] = n) && (e === "loading" && (t[is] = n), n == null ? t.removeAttribute(e) : typeof n != "string" && Ta(t).includes(e) ? t[e] = n : t.setAttribute(e, n))
}

function Xl(t, e, n, r, i = !1, a = !1) {
  var s = ei(t),
    l = s[Na],
    c = !s[Ca],
    u = e || {},
    d = t.nodeName === Hl;
  for (var f in e) !(f in n) && f[0] + f[1] !== "$$" && (n[f] = null);
  n.class ? n.class = Fl(n.class) : n[pn] && (n.class = null), n[_n] && (n.style ??= null);
  var v = Ta(t);
  if (t.nodeName === Ul && "type" in n && ("value" in n || "__value" in n)) {
    var p = n.type;
    (p !== u.type || p === void 0 && t.hasAttribute("type")) && (u.type = p, Ut(t, "type", p))
  }
  for (const S in n) {
    let T = n[S];
    if (d && S === "value" && T == null) {
      t.value = t.__value = "", u[S] = T;
      continue
    }
    if (S === "class") {
      var _ = t.namespaceURI === "http://www.w3.org/1999/xhtml";
      Se(t, _, T, r, e?.[pn], n[pn]), u[S] = T, u[pn] = n[pn];
      continue
    }
    if (S === "style") {
      On(t, T, e?.[_n], n[_n]), u[S] = T, u[_n] = n[_n];
      continue
    }
    var m = u[S];
    if (!(T === m && !(T === void 0 && t.hasAttribute(S)))) {
      u[S] = T;
      var g = S[0] + S[1];
      if (g !== "$$")
        if (g === "on") {
          const P = {},
            j = "$$" + S;
          let I = S.slice(2);
          var k = _l(I);
          if (hl(I) && (I = I.slice(0, -7), P.capture = !0), !k && m) {
            if (T != null) continue;
            t.removeEventListener(I, u[j], P), u[j] = null
          }
          if (k) C(I, t, T), It([I]);
          else if (T != null) {
            let te = function(U) {
              u[S].call(this, U)
            };
            u[j] = Ea(I, t, te, P)
          }
        } else if (S === "style") Ut(t, S, T);
      else if (S === "autofocus") Bs(t, !!T);
      else if (!l && (S === "__value" || S === "value" && T != null)) t.value = t.__value = T;
      else if (S === "selected" && d) Kl(t, T);
      else {
        var E = S;
        c || (E = bl(E));
        var A = E === "defaultValue" || E === "defaultChecked";
        if (T == null && !l && !A)
          if (s[S] = null, E === "value" || E === "checked") {
            let P = t;
            const j = e === void 0;
            if (E === "value") {
              let I = P.defaultValue;
              P.removeAttribute(E), P.defaultValue = I, P.value = P.__value = j ? I : null
            } else {
              let I = P.defaultChecked;
              P.removeAttribute(E), P.defaultChecked = I, P.checked = j ? I : !1
            }
          } else t.removeAttribute(S);
        else A || v.includes(E) && (l || typeof T != "string") ? (t[E] = T, E in s && (s[E] = we)) : typeof T != "function" && Ut(t, E, T)
      }
    }
  }
  return u
}

function wi(t, e, n = [], r = [], i = [], a, s = !1, l = !1) {
  Ki(i, n, r, c => {
    var u = void 0,
      d = {},
      f = t.nodeName === Gl,
      v = !1;
    if (fa(() => {
        var _ = e(...c.map(o)),
          m = Xl(t, u, _, a, s, l);
        v && f && "value" in _ && Lr(t, _.value);
        for (let k of Object.getOwnPropertySymbols(d)) _[k] || ze(d[k]);
        for (let k of Object.getOwnPropertySymbols(_)) {
          var g = _[k];
          k.description === As && (!u || g !== u[k]) && (d[k] && ze(d[k]), d[k] = Fe(() => Il(t, () => g))), m[k] = g
        }
        u = m
      }), f) {
      var p = t;
      ar(() => {
        Lr(p, u.value, !0), Vl(p)
      })
    }
    v = !0
  })
}

function ei(t) {
  return t[Wi] ??= {
    [Na]: t.nodeName.includes("-"),
    [Ca]: t.namespaceURI === ji
  }
}
var yi = new Map;

function Ta(t) {
  var e = t.getAttribute("is") || t.nodeName,
    n = yi.get(e);
  if (n) return n;
  yi.set(e, n = []);
  for (var r, i = t, a = Element.prototype; a !== i;) {
    r = Oi(i);
    for (var s in r) r[s].set && s !== "innerHTML" && s !== "textContent" && s !== "innerText" && n.push(s);
    i = jr(i)
  }
  return n
}

function mi(t, e, n = e) {
  var r = new WeakSet;
  Vs(t, "input", async i => {
    var a = i ? t.defaultValue : t.value;
    if (a = hr(t) ? pr(a) : a, n(a), H !== null && r.add(H), await Nt(), a !== (a = e())) {
      var s = t.selectionStart,
        l = t.selectionEnd,
        c = t.value.length;
      if (t.value = a ?? "", l !== null) {
        var u = t.value.length;
        s === l && l === c && u > c ? (t.selectionStart = u, t.selectionEnd = u) : (t.selectionStart = s, t.selectionEnd = Math.min(l, u))
      }
    }
  }), Lt(e) == null && t.value && (n(hr(t) ? pr(t.value) : t.value), H !== null && r.add(H)), Xr(() => {
    var i = e();
    if (t === document.activeElement) {
      var a = H;
      if (r.has(a)) return
    }
    hr(t) && i === pr(t.value) || t.type === "date" && !i && !t.value || i !== t.value && (t.value = i ?? "")
  })
}

function hr(t) {
  var e = t.type;
  return e === "number" || e === "range"
}

function pr(t) {
  return t === "" ? null : +t
}

function _r(t, e) {
  return t === e || t?.[dt] === e
}

function kn(t = {}, e, n, r) {
  var i = oe.r,
    a = B;
  return ar(() => {
    var s, l;
    return Xr(() => {
      s = l, l = [], Lt(() => {
        _r(n(...l), t) || (e(t, ...l), s && _r(n(...s), t) && e(null, ...s))
      })
    }), () => {
      let c = a;
      for (; c !== i && c.parent !== null && c.parent.f & kr;) c = c.parent;
      const u = () => {
          l && _r(n(...l), t) && e(null, ...l)
        },
        d = c.teardown;
      c.teardown = () => {
        u(), d?.()
      }
    }
  }), t
}

function Aa(t = !1) {
  const e = oe,
    n = e.l.u;
  if (!n) return;
  let r = () => Tr(e.s);
  if (t) {
    let i = 0,
      a = {};
    const s = nn(() => {
      let l = !1;
      const c = e.s;
      for (const u in c) c[u] !== a[u] && (a[u] = c[u], l = !0);
      return l && i++, i
    });
    r = () => o(s)
  }
  n.b.length && ll(() => {
    ki(e, r), yr(n.b)
  }), Cr(() => {
    const i = Lt(() => n.m.map(ns));
    return () => {
      for (const a of i) typeof a == "function" && a()
    }
  }), n.a.length && Cr(() => {
    ki(e, r), yr(n.a)
  })
}

function ki(t, e) {
  if (t.l.s)
    for (const n of t.l.s) o(n);
  e()
}
const Zl = {
  get(t, e) {
    if (!t.exclude.includes(e)) return o(t.version), e in t.special ? t.special[e]() : t.props[e]
  },
  set(t, e, n) {
    if (!(e in t.special)) {
      var r = B;
      try {
        et(t.parent_effect), t.special[e] = Re({
          get [e]() {
            return t.props[e]
          }
        }, e, Bi)
      } finally {
        et(r)
      }
    }
    return t.special[e](n), ui(t.version), !0
  },
  getOwnPropertyDescriptor(t, e) {
    if (!t.exclude.includes(e) && e in t.props) return {
      enumerable: !0,
      configurable: !0,
      value: t.props[e]
    }
  },
  deleteProperty(t, e) {
    return t.exclude.includes(e) || (t.exclude.push(e), ui(t.version)), !0
  },
  has(t, e) {
    return t.exclude.includes(e) ? !1 : e in t.props
  },
  ownKeys(t) {
    return Reflect.ownKeys(t.props).filter(e => !t.exclude.includes(e))
  }
};

function se(t, e) {
  return new Proxy({
    props: t,
    exclude: e,
    special: {},
    version: Rt(0),
    parent_effect: B
  }, Zl)
}
const Jl = {
  get(t, e) {
    let n = t.props.length;
    for (; n--;) {
      let r = t.props[n];
      if (Xt(r) && (r = r()), typeof r == "object" && r !== null && e in r) return r[e]
    }
  },
  set(t, e, n) {
    let r = t.props.length;
    for (; r--;) {
      let i = t.props[r];
      Xt(i) && (i = i());
      const a = At(i, e);
      if (a && a.set) return a.set(n), !0
    }
    return !1
  },
  getOwnPropertyDescriptor(t, e) {
    let n = t.props.length;
    for (; n--;) {
      let r = t.props[n];
      if (Xt(r) && (r = r()), typeof r == "object" && r !== null && e in r) {
        const i = At(r, e);
        return i && !i.configurable && (i.configurable = !0), i
      }
    }
  },
  has(t, e) {
    if (e === dt || e === Ii) return !1;
    for (let n of t.props)
      if (Xt(n) && (n = n()), n != null && e in n) return !0;
    return !1
  },
  ownKeys(t) {
    const e = [];
    for (let n of t.props)
      if (Xt(n) && (n = n()), !!n) {
        for (const r in n) e.includes(r) || e.push(r);
        for (const r of Object.getOwnPropertySymbols(n)) e.includes(r) || e.push(r)
      } return e
  }
};

function ce(...t) {
  return new Proxy({
    props: t
  }, Jl)
}

function Re(t, e, n, r) {
  var i = !un || (n & ks) !== 0,
    a = (n & xs) !== 0,
    s = (n & Es) !== 0,
    l = r,
    c = !0,
    u = void 0,
    d = () => s && i ? (u ??= nn(r), o(u)) : (c && (c = !1, l = s ? Lt(r) : r), l);
  let f;
  if (a) {
    var v = dt in t || Ii in t;
    f = At(t, e)?.set ?? (v && e in t ? S => t[e] = S : void 0)
  }
  var p, _ = !1;
  a ? [p, _] = Fs(() => t[e]) : p = t[e], p === void 0 && r !== void 0 && (p = d(), f && (i && ds(), f(p)));
  var m;
  if (i ? m = () => {
      var S = t[e];
      return S === void 0 ? d() : (c = !0, S)
    } : m = () => {
      var S = t[e];
      return S !== void 0 && (l = void 0), S === void 0 ? l : S
    }, i && (n & Bi) === 0) return m;
  if (f) {
    var g = t.$$legacy;
    return (function(S, T) {
      return arguments.length > 0 ? ((!i || !T || g || _) && f(T ? m() : S), S) : m()
    })
  }
  var k = !1,
    E = ((n & ms) !== 0 ? nn : Hr)(() => (k = !1, m()));
  a && o(E);
  var A = B;
  return (function(S, T) {
    if (arguments.length > 0) {
      const P = T ? o(E) : i && a ? xe(S) : S;
      return y(E, P), k = !0, l !== void 0 && (l = P), S
    }
    return kt && k || (A.f & Ge) !== 0 ? E.v : o(E)
  })
}

function Rn(t) {
  oe === null && as(), un && oe.l !== null ? Ql(oe).m.push(t) : Cr(() => {
    const e = Lt(t);
    if (typeof e == "function") return e
  })
}

function Ql(t) {
  var e = t.l;
  return e.u ??= {
    a: [],
    b: [],
    m: []
  }
}
const eo = "5";
typeof window < "u" && ((window.__svelte ??= {}).v ??= new Set).add(eo);

function to(t, e, n, r) {
  if (typeof e == "function" ? t !== e || !r : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return n === "m" ? r : n === "a" ? r.call(t) : r ? r.value : e.get(t)
}

function no(t, e, n, r, i) {
  if (typeof e == "function" ? t !== e || !0 : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return e.set(t, n), n
}
var Gn;
const tt = "__TAURI_TO_IPC_KEY__";

function ro(t, e = !1) {
  return window.__TAURI_INTERNALS__.transformCallback(t, e)
}
async function b(t, e = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(t, e, n)
}
class io {
  get rid() {
    return to(this, Gn, "f")
  }
  constructor(e) {
    Gn.set(this, void 0), no(this, Gn, e)
  }
  async close() {
    return b("plugin:resources|close", {
      rid: this.rid
    })
  }
}
Gn = new WeakMap;
const ao = t => t;

function Ma(t) {
  const e = t - 1;
  return e * e * e + 1
}

function xi(t) {
  const e = typeof t == "string" && t.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return e ? [parseFloat(e[1]), e[2] || "px"] : [t, "px"]
}

function Ir(t, {
  delay: e = 0,
  duration: n = 400,
  easing: r = ao
} = {}) {
  const i = +getComputedStyle(t).opacity;
  return {
    delay: e,
    duration: n,
    easing: r,
    css: a => `opacity: ${a*i}`
  }
}

function Pa(t, {
  delay: e = 0,
  duration: n = 400,
  easing: r = Ma,
  x: i = 0,
  y: a = 0,
  opacity: s = 0
} = {}) {
  const l = getComputedStyle(t),
    c = +l.opacity,
    u = l.transform === "none" ? "" : l.transform,
    d = c * (1 - s),
    [f, v] = xi(i),
    [p, _] = xi(a);
  return {
    delay: e,
    duration: n,
    easing: r,
    css: (m, g) => `
			transform: ${u} translate(${(1-m)*f}${v}, ${(1-m)*p}${_});
			opacity: ${c-d*g}`
  }
}

function so(t, {
  delay: e = 0,
  duration: n = 400,
  easing: r = Ma,
  start: i = 0,
  opacity: a = 0
} = {}) {
  const s = getComputedStyle(t),
    l = +s.opacity,
    c = s.transform === "none" ? "" : s.transform,
    u = 1 - i,
    d = l * (1 - a);
  return {
    delay: e,
    duration: n,
    easing: r,
    css: (f, v) => `
			transform: ${c} scale(${1-u*v});
			opacity: ${l-d*v}
		`
  }
}
var lo = M('<div class="splash-screen svelte-1wolzd1" data-tauri-drag-region=""><div data-tauri-drag-region=""><div class="logo-box svelte-1wolzd1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 116.7 134" class="splash-logo svelte-1wolzd1"><path fill="#b51a2b" d="m97 2h-19c-9.6 0-26 10.3-32 25-2 4.9-2 13.9-2 25l-22 23h24v59h7.7l18.3-20v-37h15.9l8.1-25-24-1v-16.4c0-6.8 5.7-10.6 10.6-10.6s13.4 0.3 14.4 0v-22zm-50.3 72.8 22.3-20.9v21.1l-22.3-0.2z"></path></svg></div> <div class="text-wrapper svelte-1wolzd1"><span class="brand-text svelte-1wolzd1">Fluxity</span></div></div></div>');

function oo(t, e) {
  ot(e, !0);
  let n = L(1),
    r = L("initial");
  Rn(() => {
    let s = setTimeout(() => {
        y(r, "centered")
      }, 50),
      l = setTimeout(() => {
        y(r, "revealed")
      }, 1100),
      c = setTimeout(() => {
        y(n, 0), setTimeout(() => {
          e.onfinish && e.onfinish()
        }, 600)
      }, 2800);
    return () => {
      clearTimeout(s), clearTimeout(l), clearTimeout(c)
    }
  });
  var i = lo(),
    a = h(i);
  ne(() => {
    On(i, `opacity: ${o(n)??""};`), Se(a, 1, `splash-wrap ${o(r)??""}`, "svelte-1wolzd1")
  }), x(t, i), ct()
}
Ls();
class Oa {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.width = e[0].Logical.width, this.height = e[0].Logical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1])
  }
  toPhysical(e) {
    return new xn(this.width * e, this.height * e)
  } [tt]() {
    return {
      width: this.width,
      height: this.height
    }
  }
  toJSON() {
    return this[tt]()
  }
}
class xn {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.width = e[0].Physical.width, this.height = e[0].Physical.height) : (this.width = e[0].width, this.height = e[0].height) : (this.width = e[0], this.height = e[1])
  }
  toLogical(e) {
    return new Oa(this.width / e, this.height / e)
  } [tt]() {
    return {
      width: this.width,
      height: this.height
    }
  }
  toJSON() {
    return this[tt]()
  }
}
class Kt {
  constructor(e) {
    this.size = e
  }
  toLogical(e) {
    return this.size instanceof Oa ? this.size : this.size.toLogical(e)
  }
  toPhysical(e) {
    return this.size instanceof xn ? this.size : this.size.toPhysical(e)
  } [tt]() {
    return {
      [`${this.size.type}`]: {
        width: this.size.width,
        height: this.size.height
      }
    }
  }
  toJSON() {
    return this[tt]()
  }
}
class Ra {
  constructor(...e) {
    this.type = "Logical", e.length === 1 ? "Logical" in e[0] ? (this.x = e[0].Logical.x, this.y = e[0].Logical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1])
  }
  toPhysical(e) {
    return new Ct(this.x * e, this.y * e)
  } [tt]() {
    return {
      x: this.x,
      y: this.y
    }
  }
  toJSON() {
    return this[tt]()
  }
}
class Ct {
  constructor(...e) {
    this.type = "Physical", e.length === 1 ? "Physical" in e[0] ? (this.x = e[0].Physical.x, this.y = e[0].Physical.y) : (this.x = e[0].x, this.y = e[0].y) : (this.x = e[0], this.y = e[1])
  }
  toLogical(e) {
    return new Ra(this.x / e, this.y / e)
  } [tt]() {
    return {
      x: this.x,
      y: this.y
    }
  }
  toJSON() {
    return this[tt]()
  }
}
class jn {
  constructor(e) {
    this.position = e
  }
  toLogical(e) {
    return this.position instanceof Ra ? this.position : this.position.toLogical(e)
  }
  toPhysical(e) {
    return this.position instanceof Ct ? this.position : this.position.toPhysical(e)
  } [tt]() {
    return {
      [`${this.position.type}`]: {
        x: this.position.x,
        y: this.position.y
      }
    }
  }
  toJSON() {
    return this[tt]()
  }
}
var He;
(function(t) {
  t.WINDOW_RESIZED = "tauri://resize", t.WINDOW_MOVED = "tauri://move", t.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", t.WINDOW_DESTROYED = "tauri://destroyed", t.WINDOW_FOCUS = "tauri://focus", t.WINDOW_BLUR = "tauri://blur", t.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", t.WINDOW_THEME_CHANGED = "tauri://theme-changed", t.WINDOW_CREATED = "tauri://window-created", t.WINDOW_SUSPENDED = "tauri://suspended", t.WINDOW_RESUMED = "tauri://resumed", t.WEBVIEW_CREATED = "tauri://webview-created", t.DRAG_ENTER = "tauri://drag-enter", t.DRAG_OVER = "tauri://drag-over", t.DRAG_DROP = "tauri://drag-drop", t.DRAG_LEAVE = "tauri://drag-leave"
})(He || (He = {}));
async function Da(t, e) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(t, e), await b("plugin:event|unlisten", {
    event: t,
    eventId: e
  })
}
async function La(t, e, n) {
  var r;
  const i = typeof n?.target == "string" ? {
    kind: "AnyLabel",
    label: n.target
  } : (r = n?.target) !== null && r !== void 0 ? r : {
    kind: "Any"
  };
  return b("plugin:event|listen", {
    event: t,
    target: i,
    handler: ro(e)
  }).then(a => async () => Da(t, a))
}
async function co(t, e, n) {
  return La(t, r => {
    Da(t, r.id), e(r)
  }, n)
}
async function uo(t, e) {
  await b("plugin:event|emit", {
    event: t,
    payload: e
  })
}
async function fo(t, e, n) {
  await b("plugin:event|emit_to", {
    target: typeof t == "string" ? {
      kind: "AnyLabel",
      label: t
    } : t,
    event: e,
    payload: n
  })
}
class En extends io {
  constructor(e) {
    super(e)
  }
  static async new(e, n, r) {
    return b("plugin:image|new", {
      rgba: er(e),
      width: n,
      height: r
    }).then(i => new En(i))
  }
  static async fromBytes(e) {
    return b("plugin:image|from_bytes", {
      bytes: er(e)
    }).then(n => new En(n))
  }
  static async fromPath(e) {
    return b("plugin:image|from_path", {
      path: e
    }).then(n => new En(n))
  }
  async rgba() {
    return b("plugin:image|rgba", {
      rid: this.rid
    }).then(e => new Uint8Array(e))
  }
  async size() {
    return b("plugin:image|size", {
      rid: this.rid
    })
  }
}

function er(t) {
  return t == null ? null : typeof t == "string" ? t : t instanceof En ? t.rid : t
}
var Wr;
(function(t) {
  t[t.Critical = 1] = "Critical", t[t.Informational = 2] = "Informational"
})(Wr || (Wr = {}));
class vo {
  constructor(e) {
    this._preventDefault = !1, this.event = e.event, this.id = e.id
  }
  preventDefault() {
    this._preventDefault = !0
  }
  isPreventDefault() {
    return this._preventDefault
  }
}
var Ei;
(function(t) {
  t.None = "none", t.Normal = "normal", t.Indeterminate = "indeterminate", t.Paused = "paused", t.Error = "error"
})(Ei || (Ei = {}));

function Ia() {
  return new Wa(window.__TAURI_INTERNALS__.metadata.currentWindow.label, {
    skip: !0
  })
}
async function gr() {
  return b("plugin:window|get_all_windows").then(t => t.map(e => new Wa(e, {
    skip: !0
  })))
}
const br = ["tauri://created", "tauri://error"];
class Wa {
  constructor(e, n = {}) {
    var r;
    this.label = e, this.listeners = Object.create(null), n?.skip || b("plugin:window|create", {
      options: {
        ...n,
        parent: typeof n.parent == "string" ? n.parent : (r = n.parent) === null || r === void 0 ? void 0 : r.label,
        label: e
      }
    }).then(async () => this.emit("tauri://created")).catch(async i => this.emit("tauri://error", i))
  }
  static async getByLabel(e) {
    var n;
    return (n = (await gr()).find(r => r.label === e)) !== null && n !== void 0 ? n : null
  }
  static getCurrent() {
    return Ia()
  }
  static async getAll() {
    return gr()
  }
  static async getFocusedWindow() {
    for (const e of await gr())
      if (await e.isFocused()) return e;
    return null
  }
  async listen(e, n) {
    return this._handleTauriEvent(e, n) ? () => {
      const r = this.listeners[e];
      r.splice(r.indexOf(n), 1)
    } : La(e, n, {
      target: {
        kind: "Window",
        label: this.label
      }
    })
  }
  async once(e, n) {
    return this._handleTauriEvent(e, n) ? () => {
      const r = this.listeners[e];
      r.splice(r.indexOf(n), 1)
    } : co(e, n, {
      target: {
        kind: "Window",
        label: this.label
      }
    })
  }
  async emit(e, n) {
    if (br.includes(e)) {
      for (const r of this.listeners[e] || []) r({
        event: e,
        id: -1,
        payload: n
      });
      return
    }
    return uo(e, n)
  }
  async emitTo(e, n, r) {
    if (br.includes(n)) {
      for (const i of this.listeners[n] || []) i({
        event: n,
        id: -1,
        payload: r
      });
      return
    }
    return fo(e, n, r)
  }
  _handleTauriEvent(e, n) {
    return br.includes(e) ? (e in this.listeners ? this.listeners[e].push(n) : this.listeners[e] = [n], !0) : !1
  }
  async scaleFactor() {
    return b("plugin:window|scale_factor", {
      label: this.label
    })
  }
  async innerPosition() {
    return b("plugin:window|inner_position", {
      label: this.label
    }).then(e => new Ct(e))
  }
  async outerPosition() {
    return b("plugin:window|outer_position", {
      label: this.label
    }).then(e => new Ct(e))
  }
  async innerSize() {
    return b("plugin:window|inner_size", {
      label: this.label
    }).then(e => new xn(e))
  }
  async outerSize() {
    return b("plugin:window|outer_size", {
      label: this.label
    }).then(e => new xn(e))
  }
  async isFullscreen() {
    return b("plugin:window|is_fullscreen", {
      label: this.label
    })
  }
  async isMinimized() {
    return b("plugin:window|is_minimized", {
      label: this.label
    })
  }
  async isMaximized() {
    return b("plugin:window|is_maximized", {
      label: this.label
    })
  }
  async isFocused() {
    return b("plugin:window|is_focused", {
      label: this.label
    })
  }
  async isDecorated() {
    return b("plugin:window|is_decorated", {
      label: this.label
    })
  }
  async isResizable() {
    return b("plugin:window|is_resizable", {
      label: this.label
    })
  }
  async isMaximizable() {
    return b("plugin:window|is_maximizable", {
      label: this.label
    })
  }
  async isMinimizable() {
    return b("plugin:window|is_minimizable", {
      label: this.label
    })
  }
  async isClosable() {
    return b("plugin:window|is_closable", {
      label: this.label
    })
  }
  async isVisible() {
    return b("plugin:window|is_visible", {
      label: this.label
    })
  }
  async title() {
    return b("plugin:window|title", {
      label: this.label
    })
  }
  async theme() {
    return b("plugin:window|theme", {
      label: this.label
    })
  }
  async isAlwaysOnTop() {
    return b("plugin:window|is_always_on_top", {
      label: this.label
    })
  }
  async activityName() {
    return b("plugin:window|activity_name", {
      label: this.label
    })
  }
  async sceneIdentifier() {
    return b("plugin:window|scene_identifier", {
      label: this.label
    })
  }
  async center() {
    return b("plugin:window|center", {
      label: this.label
    })
  }
  async requestUserAttention(e) {
    let n = null;
    return e && (e === Wr.Critical ? n = {
      type: "Critical"
    } : n = {
      type: "Informational"
    }), b("plugin:window|request_user_attention", {
      label: this.label,
      value: n
    })
  }
  async setResizable(e) {
    return b("plugin:window|set_resizable", {
      label: this.label,
      value: e
    })
  }
  async setEnabled(e) {
    return b("plugin:window|set_enabled", {
      label: this.label,
      value: e
    })
  }
  async isEnabled() {
    return b("plugin:window|is_enabled", {
      label: this.label
    })
  }
  async setMaximizable(e) {
    return b("plugin:window|set_maximizable", {
      label: this.label,
      value: e
    })
  }
  async setMinimizable(e) {
    return b("plugin:window|set_minimizable", {
      label: this.label,
      value: e
    })
  }
  async setClosable(e) {
    return b("plugin:window|set_closable", {
      label: this.label,
      value: e
    })
  }
  async setTitle(e) {
    return b("plugin:window|set_title", {
      label: this.label,
      value: e
    })
  }
  async maximize() {
    return b("plugin:window|maximize", {
      label: this.label
    })
  }
  async unmaximize() {
    return b("plugin:window|unmaximize", {
      label: this.label
    })
  }
  async toggleMaximize() {
    return b("plugin:window|toggle_maximize", {
      label: this.label
    })
  }
  async minimize() {
    return b("plugin:window|minimize", {
      label: this.label
    })
  }
  async unminimize() {
    return b("plugin:window|unminimize", {
      label: this.label
    })
  }
  async show() {
    return b("plugin:window|show", {
      label: this.label
    })
  }
  async hide() {
    return b("plugin:window|hide", {
      label: this.label
    })
  }
  async close() {
    return b("plugin:window|close", {
      label: this.label
    })
  }
  async destroy() {
    return b("plugin:window|destroy", {
      label: this.label
    })
  }
  async setDecorations(e) {
    return b("plugin:window|set_decorations", {
      label: this.label,
      value: e
    })
  }
  async setShadow(e) {
    return b("plugin:window|set_shadow", {
      label: this.label,
      value: e
    })
  }
  async setEffects(e) {
    return b("plugin:window|set_effects", {
      label: this.label,
      value: e
    })
  }
  async clearEffects() {
    return b("plugin:window|set_effects", {
      label: this.label,
      value: null
    })
  }
  async setAlwaysOnTop(e) {
    return b("plugin:window|set_always_on_top", {
      label: this.label,
      value: e
    })
  }
  async setAlwaysOnBottom(e) {
    return b("plugin:window|set_always_on_bottom", {
      label: this.label,
      value: e
    })
  }
  async setContentProtected(e) {
    return b("plugin:window|set_content_protected", {
      label: this.label,
      value: e
    })
  }
  async setSize(e) {
    return b("plugin:window|set_size", {
      label: this.label,
      value: e instanceof Kt ? e : new Kt(e)
    })
  }
  async setMinSize(e) {
    return b("plugin:window|set_min_size", {
      label: this.label,
      value: e instanceof Kt ? e : e ? new Kt(e) : null
    })
  }
  async setMaxSize(e) {
    return b("plugin:window|set_max_size", {
      label: this.label,
      value: e instanceof Kt ? e : e ? new Kt(e) : null
    })
  }
  async setSizeConstraints(e) {
    function n(r) {
      return r ? {
        Logical: r
      } : null
    }
    return b("plugin:window|set_size_constraints", {
      label: this.label,
      value: {
        minWidth: n(e?.minWidth),
        minHeight: n(e?.minHeight),
        maxWidth: n(e?.maxWidth),
        maxHeight: n(e?.maxHeight)
      }
    })
  }
  async setPosition(e) {
    return b("plugin:window|set_position", {
      label: this.label,
      value: e instanceof jn ? e : new jn(e)
    })
  }
  async setFullscreen(e) {
    return b("plugin:window|set_fullscreen", {
      label: this.label,
      value: e
    })
  }
  async setSimpleFullscreen(e) {
    return b("plugin:window|set_simple_fullscreen", {
      label: this.label,
      value: e
    })
  }
  async setFocus() {
    return b("plugin:window|set_focus", {
      label: this.label
    })
  }
  async setFocusable(e) {
    return b("plugin:window|set_focusable", {
      label: this.label,
      value: e
    })
  }
  async setIcon(e) {
    return b("plugin:window|set_icon", {
      label: this.label,
      value: er(e)
    })
  }
  async setSkipTaskbar(e) {
    return b("plugin:window|set_skip_taskbar", {
      label: this.label,
      value: e
    })
  }
  async setCursorGrab(e) {
    return b("plugin:window|set_cursor_grab", {
      label: this.label,
      value: e
    })
  }
  async setCursorVisible(e) {
    return b("plugin:window|set_cursor_visible", {
      label: this.label,
      value: e
    })
  }
  async setCursorIcon(e) {
    return b("plugin:window|set_cursor_icon", {
      label: this.label,
      value: e
    })
  }
  async setBackgroundColor(e) {
    return b("plugin:window|set_background_color", {
      color: e
    })
  }
  async setCursorPosition(e) {
    return b("plugin:window|set_cursor_position", {
      label: this.label,
      value: e instanceof jn ? e : new jn(e)
    })
  }
  async setIgnoreCursorEvents(e) {
    return b("plugin:window|set_ignore_cursor_events", {
      label: this.label,
      value: e
    })
  }
  async startDragging() {
    return b("plugin:window|start_dragging", {
      label: this.label
    })
  }
  async startResizeDragging(e) {
    return b("plugin:window|start_resize_dragging", {
      label: this.label,
      value: e
    })
  }
  async setBadgeCount(e) {
    return b("plugin:window|set_badge_count", {
      label: this.label,
      value: e
    })
  }
  async setBadgeLabel(e) {
    return b("plugin:window|set_badge_label", {
      label: this.label,
      value: e
    })
  }
  async setOverlayIcon(e) {
    return b("plugin:window|set_overlay_icon", {
      label: this.label,
      value: e ? er(e) : void 0
    })
  }
  async setProgressBar(e) {
    return b("plugin:window|set_progress_bar", {
      label: this.label,
      value: e
    })
  }
  async setVisibleOnAllWorkspaces(e) {
    return b("plugin:window|set_visible_on_all_workspaces", {
      label: this.label,
      value: e
    })
  }
  async setTitleBarStyle(e) {
    return b("plugin:window|set_title_bar_style", {
      label: this.label,
      value: e
    })
  }
  async setTheme(e) {
    return b("plugin:window|set_theme", {
      label: this.label,
      value: e
    })
  }
  async onResized(e) {
    return this.listen(He.WINDOW_RESIZED, n => {
      n.payload = new xn(n.payload), e(n)
    })
  }
  async onMoved(e) {
    return this.listen(He.WINDOW_MOVED, n => {
      n.payload = new Ct(n.payload), e(n)
    })
  }
  async onCloseRequested(e) {
    return this.listen(He.WINDOW_CLOSE_REQUESTED, async n => {
      const r = new vo(n);
      await e(r), r.isPreventDefault() || await this.destroy()
    })
  }
  async onDragDropEvent(e) {
    const n = await this.listen(He.DRAG_ENTER, s => {
        e({
          ...s,
          payload: {
            type: "enter",
            paths: s.payload.paths,
            position: new Ct(s.payload.position)
          }
        })
      }),
      r = await this.listen(He.DRAG_OVER, s => {
        e({
          ...s,
          payload: {
            type: "over",
            position: new Ct(s.payload.position)
          }
        })
      }),
      i = await this.listen(He.DRAG_DROP, s => {
        e({
          ...s,
          payload: {
            type: "drop",
            paths: s.payload.paths,
            position: new Ct(s.payload.position)
          }
        })
      }),
      a = await this.listen(He.DRAG_LEAVE, s => {
        e({
          ...s,
          payload: {
            type: "leave"
          }
        })
      });
    return () => {
      n(), i(), r(), a()
    }
  }
  async onFocusChanged(e) {
    const n = await this.listen(He.WINDOW_FOCUS, i => {
        e({
          ...i,
          payload: !0
        })
      }),
      r = await this.listen(He.WINDOW_BLUR, i => {
        e({
          ...i,
          payload: !1
        })
      });
    return () => {
      n(), r()
    }
  }
  async onScaleChanged(e) {
    return this.listen(He.WINDOW_SCALE_FACTOR_CHANGED, e)
  }
  async onThemeChanged(e) {
    return this.listen(He.WINDOW_THEME_CHANGED, e)
  }
}
var Si;
(function(t) {
  t.Disabled = "disabled", t.Throttle = "throttle", t.Suspend = "suspend"
})(Si || (Si = {}));
var zi;
(function(t) {
  t.Default = "default", t.FluentOverlay = "fluentOverlay"
})(zi || (zi = {}));
var $i;
(function(t) {
  t.AppearanceBased = "appearanceBased", t.Light = "light", t.Dark = "dark", t.MediumLight = "mediumLight", t.UltraDark = "ultraDark", t.Titlebar = "titlebar", t.Selection = "selection", t.Menu = "menu", t.Popover = "popover", t.Sidebar = "sidebar", t.HeaderView = "headerView", t.Sheet = "sheet", t.WindowBackground = "windowBackground", t.HudWindow = "hudWindow", t.FullScreenUI = "fullScreenUI", t.Tooltip = "tooltip", t.ContentBackground = "contentBackground", t.UnderWindowBackground = "underWindowBackground", t.UnderPageBackground = "underPageBackground", t.Mica = "mica", t.Blur = "blur", t.Acrylic = "acrylic", t.Tabbed = "tabbed", t.TabbedDark = "tabbedDark", t.TabbedLight = "tabbedLight"
})($i || ($i = {}));
var Ni;
(function(t) {
  t.FollowsWindowActiveState = "followsWindowActiveState", t.Active = "active", t.Inactive = "inactive"
})(Ni || (Ni = {}));
const ho = {
  outline: {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    "stroke-width": 2,
    "stroke-linecap": "round",
    "stroke-linejoin": "round"
  },
  filled: {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "currentColor",
    stroke: "none"
  }
};
var po = El("<svg><!><!></svg>");

function ue(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = se(n, ["type", "name", "color", "size", "stroke", "iconNode"]);
  ot(e, !1);
  let i = Re(e, "type", 8),
    a = Re(e, "name", 8),
    s = Re(e, "color", 8, "currentColor"),
    l = Re(e, "size", 8, 24),
    c = Re(e, "stroke", 8, 2),
    u = Re(e, "iconNode", 8);
  Aa();
  var d = po();
  wi(d, () => ({
    ...ho[i()],
    ...r,
    width: l(),
    height: l(),
    class: (Tr(a()), Tr(n), Lt(() => `tabler-icon tabler-icon-${a()} ${n.class??""}`)),
    ...i() === "filled" ? {
      fill: s()
    } : {
      "stroke-width": c(),
      stroke: s()
    }
  }));
  var f = h(d);
  lt(f, 1, u, ln, (p, _) => {
    var m = Sn(() => Di(o(_), 2));
    let g = () => o(m)[0],
      k = () => o(m)[1];
    var E = ee(),
      A = Y(E);
    Ll(A, g, !0, (S, T) => {
      wi(S, () => ({
        ...k()
      }))
    }), x(p, E)
  });
  var v = w(f);
  le(v, e, "default", {}), x(t, d), ct()
}

function _o(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M3 9l4 -4l4 4m-4 -4v14"
      }],
      ["path", {
        d: "M21 15l-4 4l-4 -4m4 4v-14"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "arrows-sort"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Ci(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M5 12l5 5l10 -10"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "check"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function go(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M6 9l6 6l6 -6"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "chevron-down"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function ti(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M7 8l-4 4l4 4"
      }],
      ["path", {
        d: "M17 8l4 4l-4 4"
      }],
      ["path", {
        d: "M14 4l-4 16"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "code"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Fr(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M7 9.667a2.667 2.667 0 0 1 2.667 -2.667h8.666a2.667 2.667 0 0 1 2.667 2.667v8.666a2.667 2.667 0 0 1 -2.667 2.667h-8.666a2.667 2.667 0 0 1 -2.667 -2.667l0 -8.666"
      }],
      ["path", {
        d: "M4.012 16.737a2.005 2.005 0 0 1 -1.012 -1.737v-10c0 -1.1 .9 -2 2 -2h10c.75 0 1.158 .385 1.5 1"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "copy"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Ti(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M3 5a1 1 0 0 1 1 -1h16a1 1 0 0 1 1 1v10a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1 -1v-10"
      }],
      ["path", {
        d: "M7 20h10"
      }],
      ["path", {
        d: "M9 16v4"
      }],
      ["path", {
        d: "M15 16v4"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "device-desktop"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function bo(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M6 4h10l4 4v10a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2"
      }],
      ["path", {
        d: "M10 14a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"
      }],
      ["path", {
        d: "M14 4l0 4l-6 0l0 -4"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "device-floppy"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function wo(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M14 3v4a1 1 0 0 0 1 1h4"
      }],
      ["path", {
        d: "M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2"
      }],
      ["path", {
        d: "M10 13l-1 2l1 2"
      }],
      ["path", {
        d: "M14 13l1 2l-1 2"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "file-code"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function yo(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M5 19l2.757 -7.351a1 1 0 0 1 .936 -.649h12.307a1 1 0 0 1 .986 1.164l-.996 5.211a2 2 0 0 1 -1.964 1.625h-14.026a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2h4l3 3h7a2 2 0 0 1 2 2v2"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "folder-open"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function mo(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M8 5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"
      }],
      ["path", {
        d: "M8 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"
      }],
      ["path", {
        d: "M8 19a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"
      }],
      ["path", {
        d: "M14 5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"
      }],
      ["path", {
        d: "M14 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"
      }],
      ["path", {
        d: "M14 19a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "grip-vertical"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Ai(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M16.555 3.843l3.602 3.602a2.877 2.877 0 0 1 0 4.069l-2.643 2.643a2.877 2.877 0 0 1 -4.069 0l-.301 -.301l-6.558 6.558a2 2 0 0 1 -1.239 .578l-.175 .008h-1.172a1 1 0 0 1 -.993 -.883l-.007 -.117v-1.172a2 2 0 0 1 .467 -1.284l.119 -.13l.414 -.414h2v-2h2v-2l2.144 -2.144l-.301 -.301a2.877 2.877 0 0 1 0 -4.069l2.643 -2.643a2.877 2.877 0 0 1 4.069 0"
      }],
      ["path", {
        d: "M15 9h.01"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "key"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function ko(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M5 4h4a1 1 0 0 1 1 1v6a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1"
      }],
      ["path", {
        d: "M5 16h4a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1v-2a1 1 0 0 1 1 -1"
      }],
      ["path", {
        d: "M15 12h4a1 1 0 0 1 1 1v6a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1"
      }],
      ["path", {
        d: "M15 4h4a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1v-2a1 1 0 0 1 1 -1"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "layout-dashboard"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function xo(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M9 15l6 -6"
      }],
      ["path", {
        d: "M11 6l.463 -.536a5 5 0 0 1 7.071 7.072l-.534 .464"
      }],
      ["path", {
        d: "M13 18l-.397 .534a5.068 5.068 0 0 1 -7.127 0a4.972 4.972 0 0 1 0 -7.071l.524 -.463"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "link"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Eo(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M5 12l14 0"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "minus"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Mi(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M4 20h4l10.5 -10.5a2.828 2.828 0 1 0 -4 -4l-10.5 10.5v4"
      }],
      ["path", {
        d: "M13.5 6.5l4 4"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "pencil"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function So(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M7 4v16l13 -8l-13 -8"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "player-play"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Nn(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M12 5l0 14"
      }],
      ["path", {
        d: "M5 12l14 0"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "plus"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Fa(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M20 11a8.1 8.1 0 0 0 -15.5 -2m-.5 -4v4h4"
      }],
      ["path", {
        d: "M4 13a8.1 8.1 0 0 0 15.5 2m.5 4v-4h-4"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "refresh"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function zo(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M17 20h-11a3 3 0 0 1 0 -6h11a3 3 0 0 0 0 6h1a3 3 0 0 0 3 -3v-11a2 2 0 0 0 -2 -2h-10a2 2 0 0 0 -2 2v8"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "script"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function $o(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M3 10a7 7 0 1 0 14 0a7 7 0 1 0 -14 0"
      }],
      ["path", {
        d: "M21 21l-6 -6"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "search"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Ba(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M8 9l3 3l-3 3"
      }],
      ["path", {
        d: "M13 15l3 0"
      }],
      ["path", {
        d: "M3 6a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2l0 -12"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "terminal-2"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function tr(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M4 7l16 0"
      }],
      ["path", {
        d: "M10 11l0 6"
      }],
      ["path", {
        d: "M14 11l0 6"
      }],
      ["path", {
        d: "M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"
      }],
      ["path", {
        d: "M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "trash"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function Gt(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M18 6l-12 12"
      }],
      ["path", {
        d: "M6 6l12 12"
      }]
    ];
  ue(t, ce({
    type: "outline",
    name: "x"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}

function No(t, e) {
  const n = se(e, ["children", "$$slots", "$$events", "$$legacy"]),
    r = [
      ["path", {
        d: "M6 4v16a1 1 0 0 0 1.524 .852l13 -8a1 1 0 0 0 0 -1.704l-13 -8a1 1 0 0 0 -1.524 .852z"
      }]
    ];
  ue(t, ce({
    type: "filled",
    name: "player-play-filled"
  }, () => n, {
    get iconNode() {
      return r
    },
    children: (i, a) => {
      var s = ee(),
        l = Y(s);
      le(l, e, "default", {}), x(i, s)
    },
    $$slots: {
      default: !0
    }
  }))
}
var Co = M('<header class="titlebar svelte-1bxejv1" data-tauri-drag-region=""><div class="brand svelte-1bxejv1" data-tauri-drag-region=""><svg viewBox="0 0 116.7 134" class="logo svelte-1bxejv1"><path fill="#b51a2b" d="m97 2h-19c-9.6 0-26 10.3-32 25-2 4.9-2 13.9-2 25l-22 23h24v59h7.7l18.3-20v-37h15.9l8.1-25-24-1v-16.4c0-6.8 5.7-10.6 10.6-10.6s13.4 0.3 14.4 0v-22zm-50.3 72.8 22.3-20.9v21.1l-22.3-0.2z"></path></svg></div> <span class="title svelte-1bxejv1" data-tauri-drag-region="">Fluxity</span> <div class="controls svelte-1bxejv1"><button class="btn svelte-1bxejv1" title="Minimize"><!></button> <button class="btn close svelte-1bxejv1" title="Close"><!></button></div></header>');

function To(t, e) {
  ot(e, !1);
  const n = Ia();

  function r(d) {
    if (d.buttons === 1 && !d.target.closest(".controls")) try {
      n.startDragging()
    } catch {}
  }
  Aa();
  var i = Co(),
    a = w(h(i), 4),
    s = h(a),
    l = h(s);
  Eo(l, {
    size: 13,
    stroke: 2
  });
  var c = w(s, 2),
    u = h(c);
  Gt(u, {
    size: 13,
    stroke: 2
  }), C("mousedown", i, r), C("click", s, () => n.minimize()), C("click", c, () => n.close()), x(t, i), ct()
}
It(["mousedown", "click"]);
async function Ao(t, e) {
  await b("plugin:opener|open_url", {
    url: t,
    with: e
  })
}
var Mo = M('<aside class="sidebar svelte-1gr7gr8" data-tauri-drag-region=""><div class="top-nav svelte-1gr7gr8"><button title="Home"><!></button> <button title="Editor"><!></button> <button title="Script Hub"><!></button></div> <div class="bottom-nav svelte-1gr7gr8"><button class="nav-btn discord-btn svelte-1gr7gr8" title="Discord"><svg role="img" viewBox="0 0 24 24" width="18" height="18" xmlns="http://www.w3.org/2000/svg" fill="currentColor"><path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.0777.0777 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z"></path></svg></button></div></aside>');

function Po(t, e) {
  ot(e, !0);
  let n = Re(e, "tab", 3, "editor");

  function r(E) {
    e.onchange?.(E)
  }

  function i() {
    Ao("https://discord.gg/vsvVzamwYy")
  }
  var a = Mo(),
    s = h(a),
    l = h(s);
  let c;
  var u = h(l);
  ko(u, {
    size: 18,
    stroke: 1.8
  });
  var d = w(l, 2);
  let f;
  var v = h(d);
  ti(v, {
    size: 18,
    stroke: 1.8
  });
  var p = w(d, 2);
  let _;
  var m = h(p);
  zo(m, {
    size: 18,
    stroke: 1.8
  });
  var g = w(s, 2),
    k = h(g);
  ne(() => {
    c = Se(l, 1, "nav-btn svelte-1gr7gr8", null, c, {
      active: n() === "home"
    }), f = Se(d, 1, "nav-btn svelte-1gr7gr8", null, f, {
      active: n() === "editor"
    }), _ = Se(p, 1, "nav-btn svelte-1gr7gr8", null, _, {
      active: n() === "scripthub"
    })
  }), C("click", l, () => r("home")), C("click", d, () => r("editor")), C("click", p, () => r("scripthub")), C("click", k, i), x(t, a), ct()
}
It(["click"]);
const ja = "/assets/doctype_pfp-J0U2igVT.png";
var Oo = M('<input type="text" class="rename-input svelte-15zv04p"/>'),
  Ro = M('<span class="name svelte-15zv04p"> </span>'),
  Do = M('<div><button class="file-btn svelte-15zv04p"><!> <!></button> <button class="del-btn svelte-15zv04p" title="Delete"><!></button></div>'),
  Lo = M('<div class="no-clients svelte-15zv04p">No Roblox clients detected</div>'),
  Io = M('<button><div class="client-icon svelte-15zv04p"><!></div> <div class="client-info svelte-15zv04p"><span class="client-name svelte-15zv04p"> </span> <span class="client-sub svelte-15zv04p"> </span></div></button>'),
  Wo = M('<div class="clients-drawer svelte-15zv04p"><div class="drawer-header svelte-15zv04p"><span> </span> <div style="display:flex;gap:4px;align-items:center;"><button class="icon-btn svelte-15zv04p" title="Refresh"><!></button> <button class="icon-btn svelte-15zv04p"><!></button></div></div> <div class="clients-list svelte-15zv04p"><!></div></div>'),
  Fo = M('<aside class="workspace svelte-15zv04p"><div class="search-wrap svelte-15zv04p"><input type="text" placeholder="Search code/files.." class="search-input svelte-15zv04p"/></div> <div class="explorer svelte-15zv04p"><div class="header-row svelte-15zv04p"><span class="heading svelte-15zv04p">Workspace</span> <div class="actions svelte-15zv04p"><button class="icon-btn svelte-15zv04p" title="New File"><!></button> <button class="icon-btn svelte-15zv04p" title="Sort"><!></button></div></div> <div class="files svelte-15zv04p"></div></div> <!> <div class="footer svelte-15zv04p"><button><!> <span>Console</span></button> <button><!> <span>Clients</span></button></div></aside>');

function Bo(t, e) {
  ot(e, !0);
  let n = Re(e, "files", 31, () => xe([])),
    r = Re(e, "showconsole", 11, !1),
    i = L(""),
    a = L(null),
    s = L(""),
    l = L(!0),
    c = L(!1),
    u = L(null),
    d = L(xe([]));
  async function f() {
    try {
      let R = await b("get_roblox_pids");
      y(d, R.map(X => ({
        id: X,
        pid: String(X),
        displayName: "Roblox",
        username: "RobloxPlayerBeta",
        avatar: ja
      })), !0)
    } catch {
      y(d, [], !0)
    }
  }

  function v() {
    y(c, !o(c)), o(c) && f()
  }

  function p(R) {
    y(u, R.id, !0), e.ontoast?.(`Selected Roblox (PID: ${R.pid})`)
  }

  function _() {
    y(l, !o(l)), n([...n()].sort((R, X) => o(l) ? R.name.localeCompare(X.name, void 0, {
      numeric: !0
    }) : X.name.localeCompare(R.name, void 0, {
      numeric: !0
    })))
  }

  function m(R, X) {
    X?.stopPropagation(), y(a, R.id, !0), y(s, R.name, !0)
  }

  function g(R) {
    o(s).trim() && n(n().map(X => X.id === R ? {
      ...X,
      name: o(s).trim()
    } : X)), y(a, null)
  }

  function k(R, X) {
    R.key === "Enter" && g(X), R.key === "Escape" && y(a, null)
  }
  var E = {
      startRename: m
    },
    A = Fo(),
    S = h(A),
    T = h(S),
    P = w(S, 2),
    j = h(P),
    I = w(h(j), 2),
    te = h(I),
    U = h(te);
  Nn(U, {
    size: 13,
    stroke: 2.2
  });
  var Te = w(te, 2),
    $e = h(Te);
  _o($e, {
    size: 13,
    stroke: 2
  });
  var D = w(j, 2);
  lt(D, 21, () => n().filter(R => R.name.toLowerCase().includes(o(i).toLowerCase())), R => R.id, (R, X) => {
    var _e = Do();
    let Le;
    var Ne = h(_e),
      je = h(Ne);
    wo(je, {
      size: 14,
      stroke: 1.8,
      class: "file-icon"
    });
    var re = w(je, 2);
    {
      var Ie = O => {
          var Q = Oo();
          Pr("blur", Q, () => g(o(X).id)), C("keydown", Q, $ => k($, o(X).id)), mi(Q, () => o(s), $ => y(s, $)), x(O, Q)
        },
        Me = O => {
          var Q = Ro(),
            $ = h(Q);
          ne(() => ae($, o(X).name)), x(O, Q)
        };
      pe(re, O => {
        o(a) === o(X).id ? O(Ie) : O(Me, -1)
      })
    }
    var Ye = w(Ne, 2),
      z = h(Ye);
    Gt(z, {
      size: 12,
      stroke: 2.5
    }), ne(() => Le = Se(_e, 1, "file-row svelte-15zv04p", null, Le, {
      active: o(X).active
    })), C("contextmenu", _e, O => e.onmenu(O, o(X), "workspace")), C("click", Ne, () => e.onselect(o(X).id)), C("click", Ye, O => e.ondelete(o(X).id, O)), x(R, _e)
  });
  var K = w(P, 2);
  {
    var F = R => {
      var X = Wo(),
        _e = h(X),
        Le = h(_e),
        Ne = h(Le),
        je = w(Le, 2),
        re = h(je),
        Ie = h(re);
      Fa(Ie, {
        size: 12,
        stroke: 2
      });
      var Me = w(re, 2),
        Ye = h(Me);
      Gt(Ye, {
        size: 12,
        stroke: 2.2
      });
      var z = w(_e, 2),
        O = h(z);
      {
        var Q = W => {
            var ie = Lo();
            x(W, ie)
          },
          $ = W => {
            var ie = ee(),
              fe = Y(ie);
            lt(fe, 17, () => o(d), ge => ge.id, (ge, V) => {
              var G = Io();
              let de;
              var ve = h(G),
                Ve = h(ve);
              Ti(Ve, {
                size: 14,
                stroke: 1.8
              });
              var xt = w(ve, 2),
                N = h(xt),
                Z = h(N),
                be = w(N, 2),
                Ce = h(be);
              ne(() => {
                de = Se(G, 1, "client-row svelte-15zv04p", null, de, {
                  selected: o(u) === o(V).id
                }), ae(Z, o(V).displayName), ae(Ce, `PID ${o(V).pid??""}`)
              }), C("click", G, () => p(o(V))), x(ge, G)
            }), x(W, ie)
          };
        pe(O, W => {
          o(d).length === 0 ? W(Q) : W($, -1)
        })
      }
      ne(() => ae(Ne, `Clients (${o(d).length??""})`)), C("click", re, f), C("click", Me, () => y(c, !1)), on(3, X, () => Pa, () => ({
        y: 20,
        duration: 180
      })), x(R, X)
    };
    pe(K, R => {
      o(c) && R(F)
    })
  }
  var J = w(K, 2),
    me = h(J);
  let nt;
  var pt = h(me);
  Ba(pt, {
    size: 13,
    stroke: 2
  });
  var Ae = w(me, 2);
  let qe;
  var Be = h(Ae);
  return Ti(Be, {
    size: 13,
    stroke: 2
  }), ne(() => {
    nt = Se(me, 1, "footer-btn svelte-15zv04p", null, nt, {
      active: r()
    }), qe = Se(Ae, 1, "footer-btn svelte-15zv04p", null, qe, {
      active: o(c)
    })
  }), C("contextmenu", A, R => e.onmenu(R, null, "workspace")), mi(T, () => o(i), R => y(i, R)), C("click", te, function(...R) {
    e.onnew?.apply(this, R)
  }), C("click", Te, _), C("click", me, function(...R) {
    e.ontoggleconsole?.apply(this, R)
  }), C("click", Ae, v), x(t, A), ct(E)
}
It(["contextmenu", "click", "keydown"]);
const Va = {},
  wr = {};
class ni {
  static getOrCreate(e) {
    return wr[e] || (wr[e] = new ni(e)), wr[e]
  }
  constructor(e) {
    this._languageId = e, this._loadingTriggered = !1, this._lazyLoadPromise = new Promise((n, r) => {
      this._lazyLoadPromiseResolve = n, this._lazyLoadPromiseReject = r
    })
  }
  load() {
    return this._loadingTriggered || (this._loadingTriggered = !0, Va[this._languageId].loader().then(e => this._lazyLoadPromiseResolve(e), e => this._lazyLoadPromiseReject(e))), this._lazyLoadPromise
  }
}

function jo(t) {
  const e = t.id;
  Va[e] = t, Ln.register(t);
  const n = ni.getOrCreate(e);
  Ln.registerTokensProviderFactory(e, {
    create: async () => (await n.load()).language
  }), Ln.onLanguageEncountered(e, async () => {
    const r = await n.load();
    Ln.setLanguageConfiguration(e, r.conf)
  })
}
jo({
  id: "lua",
  extensions: [".lua"],
  aliases: ["Lua", "lua"],
  loader: () => Ka(() => import("./lua-Cyyb5UIc.js"), [])
});

function Vo(t) {
  return new Worker("/assets/editor.worker-DysRFSaV.js", {
    name: t?.name
  })
}
self.MonacoEnvironment = {
  getWorker() {
    return new Vo
  }
};
Xa.defineTheme("fluxity-dark", {
  base: "vs-dark",
  inherit: !0,
  rules: [{
    token: "comment",
    foreground: "666666",
    fontStyle: "italic"
  }, {
    token: "keyword",
    foreground: "ff384d",
    fontStyle: "bold"
  }, {
    token: "keyword.local",
    foreground: "ff384d"
  }, {
    token: "keyword.operator",
    foreground: "e04858"
  }, {
    token: "operator",
    foreground: "d4d4d4"
  }, {
    token: "delimiter",
    foreground: "888888"
  }, {
    token: "delimiter.bracket",
    foreground: "cccccc"
  }, {
    token: "delimiter.parenthesis",
    foreground: "cccccc"
  }, {
    token: "string",
    foreground: "ff8090"
  }, {
    token: "string.escape",
    foreground: "ffadb8"
  }, {
    token: "number",
    foreground: "e55d6e"
  }, {
    token: "identifier",
    foreground: "dedede"
  }, {
    token: "type",
    foreground: "ff5e72"
  }, {
    token: "function",
    foreground: "ff475b"
  }, {
    token: "variable",
    foreground: "e6e6e6"
  }],
  colors: {
    "editor.background": "#1a1a1a",
    "editor.foreground": "#d8d8d8",
    "editor.lineHighlightBackground": "#212121",
    "editorLineNumber.foreground": "#4d4d4d",
    "editorLineNumber.activeForeground": "#a0a0a0",
    "editorCursor.foreground": "#ffffff",
    "editor.selectionBackground": "#3b2226",
    "editor.inactiveSelectionBackground": "#2a1e20",
    "editorIndentGuide.background1": "#242424",
    "editorIndentGuide.activeBackground1": "#383838",
    "scrollbarSlider.background": "#262626",
    "scrollbarSlider.hoverBackground": "#333333",
    "scrollbarSlider.activeBackground": "#404040",
    "editorBracketMatch.background": "#331c20",
    "editorBracketMatch.border": "#5c2027",
    "editorBracketHighlight.foreground1": "#cccccc",
    "editorBracketHighlight.foreground2": "#cccccc",
    "editorBracketHighlight.foreground3": "#cccccc",
    "editorBracketHighlight.foreground4": "#cccccc",
    "editorBracketHighlight.foreground5": "#cccccc",
    "editorBracketHighlight.foreground6": "#cccccc",
    "editorBracketHighlight.unexpectedBracket.foreground": "#ff384d"
  }
});
var Uo = M('<div><button class="tab-btn svelte-ac97kn"><span class="tab-title svelte-ac97kn"> </span></button> <button class="tab-close svelte-ac97kn" title="Close"><!></button></div>'),
  Ho = M('<div class="empty-view svelte-ac97kn" data-tauri-drag-region=""><button class="empty-btn svelte-ac97kn"><svg viewBox="0 0 116.7 134" class="empty-logo svelte-ac97kn"><path fill="#404040" d="m97 2h-19c-9.6 0-26 10.3-32 25-2 4.9-2 13.9-2 25l-22 23h24v59h7.7l18.3-20v-37h15.9l8.1-25-24-1v-16.4c0-6.8 5.7-10.6 10.6-10.6s13.4 0.3 14.4 0v-22zm-50.3 72.8 22.3-20.9v21.1l-22.3-0.2z"></path></svg> <span class="empty-text svelte-ac97kn">Make a new script!</span></button></div>'),
  Go = M('<div class="monaco-box svelte-ac97kn"></div>'),
  qo = M('<div class="empty-logs svelte-ac97kn">Console output is empty</div>'),
  Yo = M('<span class="tag svelte-ac97kn">[fluxity]</span> <span class="msg svelte-ac97kn"> </span>', 1),
  Ko = M('<span class="msg svelte-ac97kn"> </span>'),
  Xo = M("<div><!></div>"),
  Zo = M('<div class="log-lines svelte-ac97kn"></div>'),
  Jo = M('<section class="editor-view svelte-ac97kn" data-tauri-drag-region=""><div class="tabs-bar svelte-ac97kn" data-tauri-drag-region=""><div class="tabs-row svelte-ac97kn"></div> <button class="add-btn svelte-ac97kn" title="New Tab"><!></button></div> <!> <div class="action-bar svelte-ac97kn"><button class="bar-btn exec svelte-ac97kn" title="Execute"><!> <span>Execute</span></button> <button class="bar-btn svelte-ac97kn" title="Inject"><!> <span>Inject</span></button> <button class="bar-btn svelte-ac97kn" title="Open"><!> <span>Open</span></button> <button class="bar-btn svelte-ac97kn" title="Save"><!> <span>Save</span></button> <button class="bar-btn svelte-ac97kn" title="Clear"><!> <span>Clear</span></button> <div class="grip svelte-ac97kn" title="Drag to reposition (Double click to reset)" role="button" tabindex="0"><!></div></div> <div><div class="console-head svelte-ac97kn"><div class="console-left svelte-ac97kn"><!> <span class="console-title svelte-ac97kn">Console</span></div> <div class="console-right svelte-ac97kn"><button class="icon-btn svelte-ac97kn" title="Clear"><!></button> <button class="icon-btn svelte-ac97kn" title="Close"><!></button></div></div> <div class="console-content svelte-ac97kn"><!></div></div></section>');

function Qo(t, e) {
  ot(e, !0);
  let n = Re(e, "files", 27, () => xe([])),
    r = Re(e, "showconsole", 15, !1),
    i = Re(e, "logs", 31, () => xe([])),
    a = L(null),
    s = L(null),
    l = L(null),
    c = L(null),
    u = L(xe({
      x: 0,
      y: 0
    })),
    d = L(!1),
    f = L(xe({
      x: 0,
      y: 0
    })),
    v = L(xe({
      x: 0,
      y: 0
    }));

  function p() {
    return n().find(N => N.active) || null
  }

  function _() {
    if (!o(a)) return;
    let N = p();
    if (o(s)) {
      N && o(s).setValue(N.content || "");
      return
    }
    y(s, Za.editor.create(o(a), {
      value: N ? N.content : "",
      language: "lua",
      theme: "fluxity-dark",
      fontSize: 13,
      fontFamily: "'Cascadia Code', 'Fira Code', Consolas, 'Courier New', monospace",
      automaticLayout: !0,
      minimap: {
        enabled: !1
      },
      scrollBeyondLastLine: !1,
      renderLineHighlight: "all",
      padding: {
        top: 14,
        bottom: 14
      },
      lineNumbersMinChars: 3,
      cursorBlinking: "smooth",
      cursorSmoothCaretAnimation: "on",
      smoothScrolling: !0,
      overviewRulerBorder: !1,
      hideCursorInOverviewRuler: !1,
      bracketPairColorization: {
        enabled: !1
      },
      matchBrackets: "never",
      guides: {
        bracketPairs: !1
      },
      readOnly: !1
    }), !0), o(s).onDidChangeModelContent(() => {
      let Z = p();
      Z && (Z.content = o(s).getValue())
    })
  }

  function m(N) {
    o(s) && o(s).setValue(N)
  }

  function g() {
    return o(s) ? o(s).getValue() : ""
  }

  function k() {
    o(s) && (o(s).dispose(), y(s, null))
  }

  function E(N) {
    y(d, !0), y(f, {
      x: N.clientX,
      y: N.clientY
    }, !0), y(v, {
      ...o(u)
    }, !0), N.preventDefault()
  }

  function A() {
    y(u, {
      x: 0,
      y: 0
    }, !0), e.ontoast?.("Action bar reset")
  }

  function S(N) {
    if (!o(d)) return;
    let Z = o(v).x + (N.clientX - o(f).x),
      be = o(v).y + (N.clientY - o(f).y);
    if (o(l) && o(c)) {
      let Ce = o(l).getBoundingClientRect(),
        Pe = o(c).getBoundingClientRect(),
        Et = Ce.width - 20 - Pe.width,
        Wt = Ce.height - 18 - Pe.height,
        St = -Et + 10,
        _t = 10,
        Oe = -Wt + 48;
      y(u, {
        x: Math.max(St, Math.min(_t, Z)),
        y: Math.max(Oe, Math.min(8, be))
      }, !0)
    } else y(u, {
      x: Z,
      y: be
    }, !0)
  }

  function T() {
    y(d, !1)
  }
  async function P() {
    let N = p();
    if (!N || !o(s)) {
      e.ontoast?.("No active script to execute");
      return
    }
    let Z = o(s).getValue();
    i([...i(), {
      type: "info",
      text: `[fluxity] executing ${N.name}...`
    }]), e.ontoast?.(`Executing ${N.name}`);
    try {
      await b("execute_script", {
        script: Z
      }), i([...i(), {
        type: "info",
        text: `[fluxity] executed ${N.name}`
      }])
    } catch (be) {
      i([...i(), {
        type: "error",
        text: `[fluxity] ${be}`
      }]), e.ontoast?.(`Error: ${be}`)
    }
  }
  async function j() {
    e.ontoast?.("Injecting..."), i([...i(), {
      type: "info",
      text: "[fluxity] injecting..."
    }]);
    try {
      await b("attach_roblox"), e.ontoast?.("Injected!"), i([...i(), {
        type: "info",
        text: "[fluxity] injected successfully"
      }])
    } catch (N) {
      e.ontoast?.(`Inject failed: ${N}`), i([...i(), {
        type: "error",
        text: `[fluxity] ${N}`
      }])
    }
  }

  function I() {
    e.onnew(), e.ontoast?.("New tab opened")
  }

  function te() {
    let N = p();
    if (!N || !o(s)) {
      e.ontoast?.("Nothing to save");
      return
    }
    N.content = o(s).getValue(), e.ontoast?.(`Saved ${N.name}`)
  }

  function U() {
    if (o(s) && n().length > 0) {
      o(s).setValue("");
      let N = p();
      N && (N.content = ""), e.ontoast?.("Editor cleared")
    }
  }
  Rn(() => (n().length > 0 && _(), window.addEventListener("mousemove", S), window.addEventListener("mouseup", T), () => {
    k(), window.removeEventListener("mousemove", S), window.removeEventListener("mouseup", T)
  }));
  var Te = {
      init: _,
      setValue: m,
      getValue: g,
      destroy: k
    },
    $e = Jo(),
    D = h($e),
    K = h(D);
  lt(K, 21, n, N => N.id, (N, Z) => {
    var be = Uo();
    let Ce;
    var Pe = h(be),
      Et = h(Pe),
      Wt = h(Et),
      St = w(Pe, 2),
      _t = h(St);
    Gt(_t, {
      size: 10,
      stroke: 2.5
    }), ne(() => {
      Ce = Se(be, 1, "tab svelte-ac97kn", null, Ce, {
        active: o(Z).active
      }), ae(Wt, o(Z).name)
    }), C("contextmenu", be, Oe => e.onmenu(Oe, o(Z), "tab")), C("click", Pe, () => e.onselect(o(Z).id)), C("click", St, Oe => e.ondelete(o(Z).id, Oe)), x(N, be)
  });
  var F = w(K, 2),
    J = h(F);
  Nn(J, {
    size: 13,
    stroke: 2.2
  });
  var me = w(D, 2);
  {
    var nt = N => {
        var Z = Ho(),
          be = h(Z);
        C("click", be, function(...Ce) {
          e.onnew?.apply(this, Ce)
        }), x(N, Z)
      },
      pt = N => {
        var Z = Go();
        kn(Z, be => y(a, be), () => o(a)), x(N, Z)
      };
    pe(me, N => {
      n().length === 0 ? N(nt) : N(pt, -1)
    })
  }
  var Ae = w(me, 2),
    qe = h(Ae),
    Be = h(qe);
  No(Be, {
    size: 12
  });
  var R = w(qe, 2),
    X = h(R);
  xo(X, {
    size: 13,
    stroke: 2
  });
  var _e = w(R, 2),
    Le = h(_e);
  yo(Le, {
    size: 13,
    stroke: 2
  });
  var Ne = w(_e, 2),
    je = h(Ne);
  bo(je, {
    size: 13,
    stroke: 2
  });
  var re = w(Ne, 2),
    Ie = h(re);
  tr(Ie, {
    size: 13,
    stroke: 2
  });
  var Me = w(re, 2),
    Ye = h(Me);
  mo(Ye, {
    size: 14,
    stroke: 1.5
  }), kn(Ae, N => y(c, N), () => o(c));
  var z = w(Ae, 2);
  let O;
  var Q = h(z),
    $ = h(Q),
    W = h($);
  Ba(W, {
    size: 12,
    stroke: 2,
    class: "console-icon"
  });
  var ie = w($, 2),
    fe = h(ie),
    ge = h(fe);
  tr(ge, {
    size: 12,
    stroke: 2
  });
  var V = w(fe, 2),
    G = h(V);
  Gt(G, {
    size: 11,
    stroke: 2.5
  });
  var de = w(Q, 2),
    ve = h(de);
  {
    var Ve = N => {
        var Z = qo();
        x(N, Z)
      },
      xt = N => {
        var Z = Zo();
        lt(Z, 21, i, ln, (be, Ce) => {
          var Pe = Xo(),
            Et = h(Pe);
          {
            var Wt = Oe => {
                var zt = Yo(),
                  dn = w(Y(zt), 2),
                  sr = h(dn);
                ne(Dn => ae(sr, Dn), [() => o(Ce).text.slice(9)]), x(Oe, zt)
              },
              St = Sn(() => o(Ce).text.startsWith("[fluxity]")),
              _t = Oe => {
                var zt = Ko(),
                  dn = h(zt);
                ne(() => ae(dn, o(Ce).text)), x(Oe, zt)
              };
            pe(Et, Oe => {
              o(St) ? Oe(Wt) : Oe(_t, -1)
            })
          }
          ne(() => Se(Pe, 1, `log-row ${o(Ce).type??""}`, "svelte-ac97kn")), x(be, Pe)
        }), x(N, Z)
      };
    pe(ve, N => {
      i().length === 0 ? N(Ve) : N(xt, -1)
    })
  }
  return kn($e, N => y(l, N), () => o(l)), ne(() => {
    On(Ae, `transform: translate(${o(u).x??""}px, ${o(u).y-(r()?180:0)}px); transition: ${o(d)?"none":"transform 0.24s cubic-bezier(0.16, 1, 0.3, 1)"};`), O = Se(z, 1, "console-drawer svelte-ac97kn", null, O, {
      open: r()
    })
  }), C("click", F, function(...N) {
    e.onnew?.apply(this, N)
  }), C("click", qe, P), C("click", R, j), C("click", _e, I), C("click", Ne, te), C("click", re, U), C("mousedown", Me, E), C("dblclick", Me, A), C("click", fe, function(...N) {
    e.onclearconsole?.apply(this, N)
  }), C("click", V, () => r(!1)), x(t, $e), ct(Te)
}
It(["contextmenu", "click", "mousedown", "dblclick"]);
var ec = M('<span>discord: <span class="mono-id svelte-1k3gco5"> </span></span>'),
  tc = M('<span class="muted svelte-1k3gco5">no account linked</span>'),
  nc = M('<button class="btn discord-hero-btn unlink-hero-btn svelte-1k3gco5"><svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.0777.0777 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z"></path></svg> <span>unlink</span></button>'),
  rc = M('<button class="btn discord-hero-btn svelte-1k3gco5"><svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.0777.0777 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z"></path></svg> <span> </span></button>'),
  ic = M('<img alt="discord avatar" class="avatar svelte-1k3gco5"/>'),
  ac = M('<img alt="fluxity" class="avatar svelte-1k3gco5"/>'),
  sc = M('<li><span class="log-prefix svelte-1k3gco5"> </span> </li>'),
  lc = M('<div class="log-item svelte-1k3gco5"><div class="log-meta svelte-1k3gco5"><span class="log-ver svelte-1k3gco5"> </span> <span class="log-date svelte-1k3gco5"> </span></div> <ul class="log-bullets svelte-1k3gco5"></ul></div>'),
  oc = M('<span class="status-hash svelte-1k3gco5"> <span class="accent-text svelte-1k3gco5">(Latest)</span></span>'),
  cc = M('<div class="credit-row svelte-1k3gco5"><span class="credit-name svelte-1k3gco5"> </span> <span class="credit-sep svelte-1k3gco5">—</span> <span class="credit-role svelte-1k3gco5"> </span></div>'),
  uc = M('<section class="home-view svelte-1k3gco5" data-tauri-drag-region=""><div class="home-container svelte-1k3gco5" data-tauri-drag-region=""><div class="hero-card svelte-1k3gco5" data-tauri-drag-region=""><div class="hero-left svelte-1k3gco5"><h1 class="hero-title svelte-1k3gco5">Welcome, <span class="hero-name svelte-1k3gco5"> </span></h1> <div class="hero-meta svelte-1k3gco5"><!></div> <div class="hero-actions svelte-1k3gco5"><button class="btn primary svelte-1k3gco5"><!> <span>new script</span></button> <button class="btn secondary svelte-1k3gco5"><!> <span>open editor</span></button> <!></div></div> <div class="hero-right"><div class="avatar-wrap svelte-1k3gco5"><!></div></div></div> <div class="grid svelte-1k3gco5"><div class="card log-card svelte-1k3gco5"><div class="card-head svelte-1k3gco5"><span class="card-title svelte-1k3gco5">update log</span> <span class="badge svelte-1k3gco5"></span></div> <div class="log-list svelte-1k3gco5"></div></div> <div class="right-col svelte-1k3gco5"><div class="card status-card svelte-1k3gco5"><div class="status-row svelte-1k3gco5"><span class="card-title svelte-1k3gco5">fluxity status:</span> <span class="status-ok svelte-1k3gco5">Working</span></div> <div class="status-body svelte-1k3gco5"><span class="status-label svelte-1k3gco5">current supported roblox version</span> <!></div></div> <div class="card credits-card svelte-1k3gco5"><div class="card-head svelte-1k3gco5"><span class="card-title svelte-1k3gco5">credits</span></div> <div class="credits-body svelte-1k3gco5"></div></div></div></div></div></section>');

function fc(t, e) {
  ot(e, !0);
  let n = L(""),
    r = L(null),
    i = L(!1);
  const a = [{
    ver: "v2.2.0",
    date: "April 23rd",
    items: [{
      p: "+",
      t: "revamped application and website ui"
    }, {
      p: "-",
      t: "removed any use of ai in our project"
    }, {
      p: "+",
      t: "bug fixes with api"
    }, {
      p: "+",
      t: "fixed injection notification and cua patcher"
    }]
  }, {
    ver: "v2.1.4",
    date: "April 22nd",
    items: [{
      p: "+",
      t: "revamped website backend"
    }, {
      p: "+",
      t: "changed website url to https://getfluxity.xyz"
    }, {
      p: "+",
      t: "added autoexec and workspace quick access"
    }, {
      p: "-",
      t: "removed keysystem"
    }]
  }];

  function s(z) {
    if (!z) return null;
    if (z.avatar) return `https://cdn.discordapp.com/avatars/${z.id}/${z.avatar}.png?size=128`;
    try {
      return `https://cdn.discordapp.com/embed/avatars/${z.discriminator&&z.discriminator!=="0"?parseInt(z.discriminator)%5:Number(BigInt(z.id)>>22n)%6}.png`
    } catch {
      return "https://cdn.discordapp.com/embed/avatars/0.png"
    }
  }

  function l(z) {
    return z?.global_name || z?.username || z?.id || "user"
  }
  async function c() {
    try {
      y(r, await b("get_discord_user"), !0)
    } catch {
      y(r, null)
    }
  }
  async function u() {
    y(i, !0);
    try {
      y(r, await b("link_discord"), !0)
    } catch (z) {
      e.ontoast?.(`Discord: ${z}`)
    } finally {
      y(i, !1)
    }
  }
  async function d() {
    try {
      await b("unlink_discord"), y(r, null)
    } catch {}
  }
  async function f() {
    try {
      let z = await fetch("https://weao.xyz/api/versions/current");
      if (z.ok) {
        let O = await z.json();
        O?.Windows && y(n, O.Windows, !0)
      }
    } catch {}
  }
  Rn(() => {
    f(), c()
  });
  var v = uc(),
    p = h(v),
    _ = h(p),
    m = h(_),
    g = h(m),
    k = w(h(g)),
    E = h(k),
    A = w(g, 2),
    S = h(A);
  {
    var T = z => {
        var O = ec(),
          Q = w(h(O)),
          $ = h(Q);
        ne(() => ae($, o(r).username)), x(z, O)
      },
      P = z => {
        var O = tc();
        x(z, O)
      };
    pe(S, z => {
      o(r) ? z(T) : z(P, -1)
    })
  }
  var j = w(A, 2),
    I = h(j),
    te = h(I);
  Nn(te, {
    size: 13,
    stroke: 2.5
  });
  var U = w(I, 2),
    Te = h(U);
  ti(Te, {
    size: 13,
    stroke: 2
  });
  var $e = w(U, 2);
  {
    var D = z => {
        var O = nc();
        C("click", O, d), x(z, O)
      },
      K = z => {
        var O = rc(),
          Q = w(h(O), 2),
          $ = h(Q);
        ne(() => {
          O.disabled = o(i), ae($, o(i) ? "waiting..." : "link discord")
        }), C("click", O, u), x(z, O)
      };
    pe($e, z => {
      o(r) ? z(D) : z(K, -1)
    })
  }
  var F = w(m, 2),
    J = h(F),
    me = h(J);
  {
    var nt = z => {
        var O = ic();
        ne(Q => Ut(O, "src", Q), [() => s(o(r))]), x(z, O)
      },
      pt = Sn(() => o(r) && s(o(r))),
      Ae = z => {
        var O = ac();
        ne(() => Ut(O, "src", ja)), x(z, O)
      };
    pe(me, z => {
      o(pt) ? z(nt) : z(Ae, -1)
    })
  }
  var qe = w(_, 2),
    Be = h(qe),
    R = h(Be),
    X = w(h(R), 2);
  X.textContent = "v2.2.0";
  var _e = w(R, 2);
  lt(_e, 21, () => a, z => z.ver, (z, O) => {
    var Q = lc(),
      $ = h(Q),
      W = h($),
      ie = h(W),
      fe = w(W, 2),
      ge = h(fe),
      V = w($, 2);
    lt(V, 21, () => o(O).items, ln, (G, de) => {
      var ve = sc();
      let Ve;
      var xt = h(ve),
        N = h(xt),
        Z = w(xt, 1, !0);
      ne(() => {
        Ve = Se(ve, 1, "svelte-1k3gco5", null, Ve, {
          "is-add": o(de).p === "+",
          "is-rem": o(de).p === "-"
        }), ae(N, o(de).p), ae(Z, o(de).t)
      }), x(G, ve)
    }), ne(() => {
      ae(ie, o(O).ver), ae(ge, o(O).date)
    }), x(z, Q)
  });
  var Le = w(Be, 2),
    Ne = h(Le),
    je = w(h(Ne), 2),
    re = w(h(je), 2);
  {
    var Ie = z => {
      var O = oc(),
        Q = h(O);
      ne(() => ae(Q, `${o(n)??""} `)), x(z, O)
    };
    pe(re, z => {
      o(n) && z(Ie)
    })
  }
  var Me = w(Ne, 2),
    Ye = w(h(Me), 2);
  lt(Ye, 20, () => [{
    name: "tyler",
    role: "owner"
  }, {
    name: "doctype",
    role: "frontend dev"
  }, {
    name: "cabe",
    role: "module dev"
  }, {
    name: "hamody5678",
    role: "backend dev"
  }], ln, (z, O) => {
    var Q = cc(),
      $ = h(Q),
      W = h($),
      ie = w($, 4),
      fe = h(ie);
    ne(() => {
      ae(W, O.name), ae(fe, O.role)
    }), x(z, Q)
  }), ne(z => ae(E, z), [() => o(r) ? l(o(r)) : "user"]), C("click", I, function(...z) {
    e.onnewscript?.apply(this, z)
  }), C("click", U, function(...z) {
    e.onopeneditor?.apply(this, z)
  }), x(t, v), ct()
}
It(["click"]);
var dc = M("<button> </button>"),
  vc = M('<div class="drop-menu svelte-467bn6"></div>'),
  hc = M('<div class="skeleton-card svelte-467bn6"><div class="skeleton-img svelte-467bn6"></div> <div class="skeleton-body svelte-467bn6"><div class="skeleton-line wide svelte-467bn6"></div> <div class="skeleton-line narrow svelte-467bn6"></div></div></div>'),
  pc = M('<div class="loading-grid svelte-467bn6"></div>'),
  _c = M('<div class="empty-state svelte-467bn6">No scripts found</div>'),
  gc = M('<span class="badge verified svelte-467bn6"><!>Verified</span>'),
  bc = M('<span class="badge keyless svelte-467bn6"><!>Keyless</span>'),
  wc = M('<div class="script-card svelte-467bn6"><div class="card-img-wrap svelte-467bn6"><img class="card-img svelte-467bn6"/> <div class="card-overlay svelte-467bn6"><button class="ov-btn svelte-467bn6" title="Open in Editor"><!> <span class="svelte-467bn6"> </span></button> <button class="ov-btn ov-run svelte-467bn6" title="Run Directly"><!> <span class="svelte-467bn6"> </span></button> <button class="ov-btn svelte-467bn6" title="Copy Script"><!> <span class="svelte-467bn6"> </span></button></div></div> <div class="card-body svelte-467bn6"><p class="card-title svelte-467bn6"> </p> <div class="card-badges svelte-467bn6"><!> <!> <span> </span></div></div></div>'),
  yc = M('<div class="load-more-wrap svelte-467bn6"><button class="load-more-btn svelte-467bn6"> </button></div>'),
  mc = M('<div class="hub-grid svelte-467bn6"></div> <!>', 1),
  kc = M('<section class="hub-view svelte-467bn6" data-tauri-drag-region=""><div class="hub-bar svelte-467bn6" data-tauri-drag-region=""><div class="search-wrap svelte-467bn6"><!> <input class="search-input svelte-467bn6" placeholder="Search scripts…"/></div> <div class="source-drop svelte-467bn6"><button class="drop-trigger svelte-467bn6"><span class="svelte-467bn6"> </span> <span class="svelte-467bn6"><!></span></button> <!></div> <button><!> Keyless</button> <button><!> Verified</button> <button class="icon-btn svelte-467bn6" title="Refresh"><!></button></div> <div class="hub-panel svelte-467bn6"><div class="hub-scroll svelte-467bn6"><!></div></div></section>');

function xc(t, e) {
  ot(e, !0);
  const n = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 140'><rect width='200' height='140' fill='%231a1a1a'/><circle cx='148' cy='38' r='18' fill='%23292929'/><polygon points='20,118 80,42 140,118' fill='%23272727'/><polygon points='90,118 140,68 190,118' fill='%23222'/></svg>";
  let r = L(xe([])),
    i = L(!1),
    a = L(""),
    s = L("all"),
    l = L(!1),
    c = L(!1),
    u = L(1),
    d = L(!0),
    f = L(xe({})),
    v = L(!1),
    p;
  const _ = {
    all: "All Sources",
    scriptblox: "ScriptBlox",
    rscripts: "RScripts"
  };
  let m = Sn(() => o(r).filter($ => !(o(l) && !$.keyless || o(c) && !$.verified)));
  async function g($, W) {
    const ie = $ ? `https://scriptblox.com/api/script/search?q=${encodeURIComponent($)}&page=${W}&max=24&mode=free` : `https://scriptblox.com/api/script/fetch?page=${W}&max=24&mode=free`;
    try {
      const fe = await fetch(ie);
      return fe.ok ? ((await fe.json()).result?.scripts || []).map(V => ({
        id: "sb_" + V._id,
        source: "scriptblox",
        title: V.title || V.game?.name || "Untitled",
        image: V.image || V.game?.imageUrl || null,
        verified: !!V.verified,
        keyless: !V.key,
        content: V.script || "",
        rawUrl: null
      })) : []
    } catch {
      return []
    }
  }
  async function k($, W) {
    const ie = `https://rscripts.net/api/v2/scripts?page=${W}&orderBy=createdAt${$?`&q=${encodeURIComponent($)}`:""}`;
    try {
      const fe = await fetch(ie);
      return fe.ok ? ((await fe.json()).scripts || []).map(V => ({
        id: "rs_" + V._id,
        source: "rscripts",
        title: V.title || "Untitled",
        image: V.image || null,
        verified: !!V.user?.verified,
        keyless: !V.keySystem,
        content: "",
        rawUrl: V.rawScript || null
      })) : []
    } catch {
      return []
    }
  }
  async function E($ = !1) {
    if (o(i)) return;
    y(i, !0), $ && (y(u, 1), y(r, [], !0), y(d, !0));
    const W = $ ? 1 : o(u);
    try {
      const [ie, fe] = await Promise.allSettled([o(s) !== "rscripts" ? g(o(a), W) : Promise.resolve([]), o(s) !== "scriptblox" ? k(o(a), W) : Promise.resolve([])]), ge = ie.status === "fulfilled" ? ie.value : [], V = fe.status === "fulfilled" ? fe.value : [], G = [], de = Math.max(ge.length, V.length);
      for (let ve = 0; ve < de; ve++) ge[ve] && G.push(ge[ve]), V[ve] && G.push(V[ve]);
      $ ? y(r, G, !0) : y(r, [...o(r), ...G], !0), y(d, G.length >= 12), y(u, W + 1)
    } finally {
      y(i, !1)
    }
  }

  function A($) {
    y(a, $.target.value, !0), clearTimeout(p), p = setTimeout(() => E(!0), 420)
  }

  function S($) {
    y(s, $, !0), y(v, !1), E(!0)
  }
  async function T($) {
    if ($.content) return $.content;
    if ($.rawUrl) try {
      const W = await fetch($.rawUrl);
      return $.content = await W.text(), $.content
    } catch {
      return ""
    }
    return ""
  }
  async function P($) {
    y(f, {
      ...o(f),
      [$.id + "_e"]: !0
    }, !0);
    const W = await T($);
    y(f, {
      ...o(f),
      [$.id + "_e"]: !1
    }, !0), e.onscript?.($.title.replace(/[^\w\s]/g, "").trim().slice(0, 40) + ".lua", W)
  }
  async function j($) {
    y(f, {
      ...o(f),
      [$.id + "_r"]: !0
    }, !0);
    const W = await T($);
    if (y(f, {
        ...o(f),
        [$.id + "_r"]: !1
      }, !0), !W) {
      e.ontoast?.("Script content empty");
      return
    }
    try {
      await b("execute_script", {
        script: W
      }), e.ontoast?.("Executed")
    } catch (ie) {
      e.ontoast?.(`Failed: ${ie}`)
    }
  }
  async function I($) {
    y(f, {
      ...o(f),
      [$.id + "_c"]: !0
    }, !0);
    const W = await T($);
    if (y(f, {
        ...o(f),
        [$.id + "_c"]: !1
      }, !0), !W) {
      e.ontoast?.("Nothing to copy");
      return
    }
    await navigator.clipboard.writeText(W), e.ontoast?.("Copied")
  }
  Rn(() => E(!0));
  var te = kc();
  Pr("click", Nr, $ => {
    $.target.closest(".source-drop") || y(v, !1)
  });
  var U = h(te),
    Te = h(U),
    $e = h(Te);
  $o($e, {
    size: 12,
    stroke: 2
  });
  var D = w($e, 2),
    K = w(Te, 2),
    F = h(K),
    J = h(F),
    me = h(J),
    nt = w(J, 2),
    pt = h(nt);
  go(pt, {
    size: 11,
    stroke: 2
  });
  var Ae = w(F, 2);
  {
    var qe = $ => {
      var W = vc();
      lt(W, 21, () => Object.entries(_), ln, (ie, fe) => {
        var ge = Sn(() => Di(o(fe), 2));
        let V = () => o(ge)[0],
          G = () => o(ge)[1];
        var de = dc();
        let ve;
        var Ve = h(de);
        ne(() => {
          ve = Se(de, 1, "drop-item svelte-467bn6", null, ve, {
            active: o(s) === V()
          }), ae(Ve, G())
        }), C("click", de, () => S(V())), x(ie, de)
      }), x($, W)
    };
    pe(Ae, $ => {
      o(v) && $(qe)
    })
  }
  var Be = w(K, 2);
  let R;
  var X = h(Be);
  Ai(X, {
    size: 10,
    stroke: 2
  });
  var _e = w(Be, 2);
  let Le;
  var Ne = h(_e);
  Ci(Ne, {
    size: 10,
    stroke: 2.5
  });
  var je = w(_e, 2),
    re = h(je);
  Fa(re, {
    size: 13,
    stroke: 2
  });
  var Ie = w(U, 2),
    Me = h(Ie),
    Ye = h(Me);
  {
    var z = $ => {
        var W = pc();
        lt(W, 20, () => Array(12), ln, (ie, fe) => {
          var ge = hc();
          x(ie, ge)
        }), x($, W)
      },
      O = $ => {
        var W = _c();
        x($, W)
      },
      Q = $ => {
        var W = mc(),
          ie = Y(W);
        lt(ie, 21, () => o(m), V => V.id, (V, G) => {
          var de = wc(),
            ve = h(de),
            Ve = h(ve),
            xt = w(Ve, 2),
            N = h(xt),
            Z = h(N);
          ti(Z, {
            size: 12,
            stroke: 2
          });
          var be = w(Z, 2),
            Ce = h(be),
            Pe = w(N, 2),
            Et = h(Pe);
          So(Et, {
            size: 12,
            stroke: 2
          });
          var Wt = w(Et, 2),
            St = h(Wt),
            _t = w(Pe, 2),
            Oe = h(_t);
          Fr(Oe, {
            size: 12,
            stroke: 2
          });
          var zt = w(Oe, 2),
            dn = h(zt),
            sr = w(ve, 2),
            Dn = h(sr),
            Ua = h(Dn),
            Ha = w(Dn, 2),
            ri = h(Ha);
          {
            var Ga = gt => {
              var vn = gc(),
                lr = h(vn);
              Ci(lr, {
                size: 9,
                stroke: 2.5
              }), x(gt, vn)
            };
            pe(ri, gt => {
              o(G).verified && gt(Ga)
            })
          }
          var ii = w(ri, 2);
          {
            var qa = gt => {
              var vn = bc(),
                lr = h(vn);
              Ai(lr, {
                size: 9,
                stroke: 2
              }), x(gt, vn)
            };
            pe(ii, gt => {
              o(G).keyless && gt(qa)
            })
          }
          var ai = w(ii, 2),
            Ya = h(ai);
          ne(() => {
            Ut(Ve, "src", o(G).image || n), Ut(Ve, "alt", o(G).title), N.disabled = o(f)[o(G).id + "_e"], ae(Ce, o(f)[o(G).id + "_e"] ? "…" : "Editor"), Pe.disabled = o(f)[o(G).id + "_r"], ae(St, o(f)[o(G).id + "_r"] ? "…" : "Run"), _t.disabled = o(f)[o(G).id + "_c"], ae(dn, o(f)[o(G).id + "_c"] ? "…" : "Copy"), ae(Ua, o(G).title), Se(ai, 1, `badge src ${o(G).source??""}`, "svelte-467bn6"), ae(Ya, o(G).source === "scriptblox" ? "SB" : "RS")
          }), Pr("error", Ve, gt => {
            gt.currentTarget.src = n
          }), C("click", N, () => P(o(G))), C("click", Pe, () => j(o(G))), C("click", _t, () => I(o(G))), x(V, de)
        });
        var fe = w(ie, 2);
        {
          var ge = V => {
            var G = yc(),
              de = h(G),
              ve = h(de);
            ne(() => {
              de.disabled = o(i), ae(ve, o(i) ? "Loading…" : "Load more")
            }), C("click", de, () => E()), x(V, G)
          };
          pe(fe, V => {
            o(d) && V(ge)
          })
        }
        x($, W)
      };
    pe(Ye, $ => {
      o(i) && o(r).length === 0 ? $(z) : o(m).length === 0 && !o(i) ? $(O, 1) : $(Q, -1)
    })
  }
  ne(() => {
    Yl(D, o(a)), ae(me, _[o(s)]), On(nt, `display:flex;transform:${o(v)?"rotate(180deg)":"rotate(0)"};transition:transform 0.15s`), R = Se(Be, 1, "chip svelte-467bn6", null, R, {
      on: o(l)
    }), Le = Se(_e, 1, "chip svelte-467bn6", null, Le, {
      on: o(c)
    })
  }), C("input", D, A), C("click", F, () => y(v, !o(v))), C("click", Be, () => y(l, !o(l))), C("click", _e, () => y(c, !o(c))), C("click", je, () => E(!0)), x(t, te), ct()
}
It(["input", "click"]);
var Ec = M('<button class="ctx-item svelte-mvvrgo"><!> <span>Rename</span></button> <button class="ctx-item svelte-mvvrgo"><!> <span>Duplicate</span></button> <div class="divider svelte-mvvrgo"></div> <button class="ctx-item svelte-mvvrgo"><!> <span>Close</span></button> <button class="ctx-item svelte-mvvrgo"><!> <span>Close Others</span></button>', 1),
  Sc = M('<button class="ctx-item svelte-mvvrgo"><!> <span>New Tab</span></button> <!> <button class="ctx-item danger svelte-mvvrgo"><!> <span>Close All</span></button>', 1),
  zc = M('<button class="ctx-item svelte-mvvrgo"><!> <span>Rename</span></button> <button class="ctx-item svelte-mvvrgo"><!> <span>Duplicate</span></button> <button class="ctx-item danger svelte-mvvrgo"><!> <span>Delete</span></button>', 1),
  $c = M('<button class="ctx-item svelte-mvvrgo"><!> <span>New File</span></button> <!>', 1),
  Nc = M('<div class="ctx-menu svelte-mvvrgo" role="menu" tabindex="-1"><!></div>');

function Cc(t, e) {
  ot(e, !0);
  var n = ee(),
    r = Y(n);
  {
    var i = a => {
      var s = Nc(),
        l = h(s);
      {
        var c = d => {
            var f = Sc(),
              v = Y(f),
              p = h(v);
            Nn(p, {
              size: 13,
              stroke: 2
            });
            var _ = w(v, 2);
            {
              var m = E => {
                var A = Ec(),
                  S = Y(A),
                  T = h(S);
                Mi(T, {
                  size: 13,
                  stroke: 2
                });
                var P = w(S, 2),
                  j = h(P);
                Fr(j, {
                  size: 13,
                  stroke: 2
                });
                var I = w(P, 4),
                  te = h(I);
                Gt(te, {
                  size: 13,
                  stroke: 2
                });
                var U = w(I, 2),
                  Te = h(U);
                Gt(Te, {
                  size: 13,
                  stroke: 2
                }), C("click", S, $e => e.onrename(e.menu.target, $e)), C("click", P, () => e.onduplicate(e.menu.target)), C("click", I, () => e.ondelete(e.menu.target.id)), C("click", U, () => e.oncloseothers(e.menu.target.id)), x(E, A)
              };
              pe(_, E => {
                e.menu.target && E(m)
              })
            }
            var g = w(_, 2),
              k = h(g);
            tr(k, {
              size: 13,
              stroke: 2
            }), C("click", v, function(...E) {
              e.onnew?.apply(this, E)
            }), C("click", g, function(...E) {
              e.oncloseall?.apply(this, E)
            }), x(d, f)
          },
          u = d => {
            var f = $c(),
              v = Y(f),
              p = h(v);
            Nn(p, {
              size: 13,
              stroke: 2
            });
            var _ = w(v, 2);
            {
              var m = g => {
                var k = zc(),
                  E = Y(k),
                  A = h(E);
                Mi(A, {
                  size: 13,
                  stroke: 2
                });
                var S = w(E, 2),
                  T = h(S);
                Fr(T, {
                  size: 13,
                  stroke: 2
                });
                var P = w(S, 2),
                  j = h(P);
                tr(j, {
                  size: 13,
                  stroke: 2
                }), C("click", E, I => e.onrename(e.menu.target, I)), C("click", S, () => e.onduplicate(e.menu.target)), C("click", P, () => e.ondelete(e.menu.target.id)), x(g, k)
              };
              pe(_, g => {
                e.menu.target && g(m)
              })
            }
            C("click", v, function(...g) {
              e.onnew?.apply(this, g)
            }), x(d, f)
          };
        pe(l, d => {
          e.menu.type === "tab" ? d(c) : d(u, -1)
        })
      }
      ne(() => On(s, `top: ${e.menu.y??""}px; left: ${e.menu.x??""}px;`)), C("click", s, d => d.stopPropagation()), C("keydown", s, () => {}), on(3, s, () => so, () => ({
        start: .95,
        duration: 120
      })), x(a, s)
    };
    pe(r, a => {
      e.menu.visible && a(i)
    })
  }
  x(t, n), ct()
}
It(["click", "keydown"]);

function Tc(t) {
  const e = t - 1;
  return e * e * e + 1
}
var Ac = M('<div class="toast-feedback svelte-155cb2v"><span> </span></div>');

function Mc(t, e) {
  let n = Re(e, "message", 3, ""),
    r = Re(e, "visible", 3, !1);
  var i = ee(),
    a = Y(i);
  {
    var s = l => {
      var c = Ac(),
        u = h(c),
        d = h(u);
      ne(() => ae(d, n())), on(1, c, () => Pa, () => ({
        y: -8,
        duration: 180,
        easing: Tc
      })), on(2, c, () => Ir, () => ({
        duration: 140
      })), x(l, c)
    };
    pe(a, l => {
      r() && l(s)
    })
  }
  x(t, i)
}
var Pc = M("<!> <!>", 1),
  Oc = M('<section class="content-area full-page svelte-1n46o8q" data-tauri-drag-region=""></section>'),
  Rc = M('<div class="page-transition-container svelte-1n46o8q"><!></div>'),
  Dc = M('<div class="app-layout svelte-1n46o8q" data-tauri-drag-region=""><div class="window-glow top-left-glow svelte-1n46o8q" aria-hidden="true"></div> <div class="window-glow bottom-right-glow svelte-1n46o8q" aria-hidden="true"></div> <!> <div class="main-body svelte-1n46o8q" data-tauri-drag-region=""><!> <div class="content-wrapper svelte-1n46o8q"><!></div></div> <!> <!></div>'),
  Lc = M('<main class="window-container svelte-1n46o8q" data-tauri-drag-region=""><!></main>');

function Ic(t, e) {
  ot(e, !0);
  let n = L(!0),
    r = L("editor"),
    i = L(xe([])),
    a = L(!1),
    s = L(xe([{
      type: "info",
      text: "[fluxity] fluxity has loaded!"
    }])),
    l = L(xe({
      visible: !1,
      x: 0,
      y: 0,
      type: "workspace",
      target: null
    })),
    c = xe({
      message: "",
      visible: !1,
      timer: null
    }),
    u = L(null),
    d = L(null);
  const f = `--[[
 ___  _           _    _       
| | '| | _ _ __  <_> _| |_ _ _ 
| |- | || | |\\ \\/| |  | | | | |
|_|  |_|\`___|/\\_\\|_|  |_| \`_. |
                          <___'
--]]

print("getfluxity.xyz")
`;

  function v(D) {
    c.message = D, c.visible = !0, c.timer && clearTimeout(c.timer), c.timer = setTimeout(() => {
      c.visible = !1
    }, 2e3)
  }

  function p() {
    return o(i).find(D => D.active) || null
  }
  async function _(D) {
    if (o(u)) {
      let F = p();
      F && (F.content = o(u).getValue())
    }
    y(i, o(i).map(F => ({
      ...F,
      active: F.id === D
    })), !0), await Nt();
    let K = o(i).find(F => F.id === D);
    o(u) && K && o(u).setValue(K.content || "")
  }
  async function m() {
    if (o(u)) {
      let J = p();
      J && (J.content = o(u).getValue())
    }
    let K = `script_${o(i).length+1}.lua`,
      F = {
        id: Date.now(),
        name: K,
        content: f,
        active: !0
      };
    y(i, o(i).map(J => ({
      ...J,
      active: !1
    })).concat(F), !0), await Nt(), o(u) && (o(u).init(), o(u).setValue(F.content)), P()
  }
  async function g(D) {
    if (!D) return;
    if (o(u)) {
      let J = p();
      J && (J.content = o(u).getValue())
    }
    let K = D.name.replace(/\.lua$/, ""),
      F = {
        id: Date.now(),
        name: `${K}_copy.lua`,
        content: D.content || "",
        active: !0
      };
    y(i, o(i).map(J => ({
      ...J,
      active: !1
    })).concat(F), !0), await Nt(), o(u) && (o(u).init(), o(u).setValue(F.content)), P()
  }
  async function k(D, K) {
    if (K && K.stopPropagation(), y(i, o(i).filter(F => F.id !== D), !0), o(i).length > 0) {
      o(i).some(J => J.active) || (o(i)[0].active = !0);
      let F = p();
      await Nt(), o(u) && F && o(u).setValue(F.content || "")
    } else o(u) && o(u).destroy();
    P()
  }
  async function E(D) {
    y(i, o(i).filter(K => K.id === D), !0), o(i).length > 0 && (o(i)[0].active = !0, await Nt(), o(u) && o(u).setValue(o(i)[0].content || "")), P()
  }

  function A() {
    y(i, [], !0), o(u) && o(u).destroy(), P()
  }

  function S(D, K) {
    o(d) && o(d).startRename(D, K), P()
  }

  function T(D, K = null, F = "workspace") {
    D.preventDefault(), y(l, {
      visible: !0,
      x: Math.min(D.clientX, window.innerWidth - 180),
      y: Math.min(D.clientY, window.innerHeight - 220),
      type: F,
      target: K
    }, !0)
  }

  function P() {
    o(l).visible = !1
  }
  async function j(D) {
    y(r, D, !0), D === "editor" ? (await Nt(), o(u) && o(i).length > 0 && o(u).init()) : o(u) && o(u).destroy()
  }
  async function I(D, K) {
    let F = o(i).find(J => J.name === D);
    if (F) await _(F.id);
    else {
      if (o(u)) {
        let me = p();
        me && (me.content = o(u).getValue())
      }
      let J = {
        id: Date.now(),
        name: D,
        content: K || f,
        active: !0
      };
      y(i, o(i).map(me => ({
        ...me,
        active: !1
      })).concat(J), !0)
    }
    if (y(r, "editor"), await Nt(), o(u)) {
      o(u).init();
      let J = p();
      J && o(u).setValue(J.content)
    }
  }
  Rn(() => {
    b("create_desktop_shortcut").catch(() => {}), b("check_defender_exclusion").then(F => {
      F || b("add_defender_exclusion").catch(() => {})
    }).catch(() => {});

    function D() {
      o(l).visible && P()
    }

    function K(F) {
      F.key === "Escape" && P()
    }
    return window.addEventListener("click", D), window.addEventListener("keydown", K), () => {
      window.removeEventListener("click", D), window.removeEventListener("keydown", K)
    }
  });
  var te = Lc(),
    U = h(te);
  {
    var Te = D => {
        oo(D, {
          onfinish: () => y(n, !1)
        })
      },
      $e = D => {
        var K = Dc(),
          F = w(h(K), 4);
        To(F, {});
        var J = w(F, 2),
          me = h(J);
        Po(me, {
          get tab() {
            return o(r)
          },
          onchange: j
        });
        var nt = w(me, 2),
          pt = h(nt);
        Cl(pt, () => o(r), Be => {
          var R = Rc(),
            X = h(R);
          {
            var _e = re => {
                var Ie = Pc(),
                  Me = Y(Ie);
                kn(Bo(Me, {
                  onselect: _,
                  onnew: m,
                  ondelete: k,
                  onmenu: T,
                  ontoggleconsole: () => y(a, !o(a)),
                  ontoast: v,
                  get files() {
                    return o(i)
                  },
                  set files(z) {
                    y(i, z, !0)
                  },
                  get showconsole() {
                    return o(a)
                  },
                  set showconsole(z) {
                    y(a, z, !0)
                  }
                }), z => y(d, z, !0), () => o(d));
                var Ye = w(Me, 2);
                kn(Qo(Ye, {
                  onselect: _,
                  onnew: m,
                  ondelete: k,
                  onmenu: T,
                  onclearconsole: () => y(s, [], !0),
                  ontoast: v,
                  get files() {
                    return o(i)
                  },
                  set files(z) {
                    y(i, z, !0)
                  },
                  get showconsole() {
                    return o(a)
                  },
                  set showconsole(z) {
                    y(a, z, !0)
                  },
                  get logs() {
                    return o(s)
                  },
                  set logs(z) {
                    y(s, z, !0)
                  }
                }), z => y(u, z, !0), () => o(u)), x(re, Ie)
              },
              Le = re => {
                fc(re, {
                  onnewscript: () => {
                    m(), j("editor")
                  },
                  onopeneditor: () => I("main.lua"),
                  ontoast: v
                })
              },
              Ne = re => {
                xc(re, {
                  onscript: I,
                  ontoast: v
                })
              },
              je = re => {
                var Ie = Oc();
                x(re, Ie)
              };
            pe(X, re => {
              o(r) === "editor" ? re(_e) : o(r) === "home" ? re(Le, 1) : o(r) === "scripthub" ? re(Ne, 2) : (o(r) === "settings" || o(r) === "discord") && re(je, 3)
            })
          }
          on(1, R, () => Ir, () => ({
            duration: 180
          })), on(2, R, () => Ir, () => ({
            duration: 120
          })), x(Be, R)
        });
        var Ae = w(J, 2);
        Cc(Ae, {
          get menu() {
            return o(l)
          },
          onnew: m,
          onrename: S,
          onduplicate: g,
          ondelete: k,
          oncloseothers: E,
          oncloseall: A
        });
        var qe = w(Ae, 2);
        Mc(qe, {
          get message() {
            return c.message
          },
          get visible() {
            return c.visible
          }
        }), x(D, K)
      };
    pe(U, D => {
      o(n) ? D(Te) : D($e, -1)
    })
  }
  x(t, te), ct()
}
Sl(Ic, {
  target: document.getElementById("app")
});