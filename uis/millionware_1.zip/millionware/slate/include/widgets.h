#pragma once

class c_widgets {
public:
	struct widget_window {
		void begin( const std::string_view& name, ImVec2 size, ImGuiWindowFlags flags = 0 );
		void end( );
	}; widget_window window;
	struct widget_child {
		void begin( const ptext& name, ImVec2 size = ImVec2{ 0, 0 } );
		void end( );

		float* smoothscroll( bool scrollbar = false, ImVec2 padding = ImVec2{ 0, 0 } );
	} child;
	struct widget_menu {
		void begin( const std::string_view& str_id );
		void end( );
		bool button( const ptext& label, ImVec2 size, c_buttonstyle style = { } );
	} menu;
	struct widget_popup {
		bool begin( const std::string_view& str_id, float alpha, ImVec2 pos, ImVec2 padding = ImVec2{ 0, 0 } );
		void end( );
	} popup;
	struct widget_nav {
		std::vector< c_tab > tabs;
		int current = 0;
		int next = 0;
		float tab_anim = 1;
		float tab_animdest = 1;
		float subtab_anim = 1;
		float subtab_animdest = 1;

		void drawtabs( );
		void drawsubtabs( );
		void drawpage( );

		bool tab( c_tab tab, bool selected );
		bool subtab( const ptext& label, bool selected );

		void addpage( int tab, std::function< void( ) > code );
	} nav;
	struct widget_colorpicker {
		std::vector< ImColor > history;
		bool huebar( const char* str_id, float* h, float s, float v );
		bool alphabar( float* col );
		bool square( const char* str_id, float h, float* s, float* v );
		bool draw( const std::string_view& str_id, float* col );
		bool colorbutton( const char* str_id, const ImColor& color );
	} colorpicker;

	bool button( const ptext& label, ImVec2 size = ImVec2{ 0, 0 }, c_buttonstyle style = { } );
	
	template < typename T >
	bool slider( const ptext& label, T* v, T min, T max, const char* format, c_sliderstyle style = { } );
	bool sliderint( const ptext& label, int* v, int min, int max, const char* format = "%d" );
	bool sliderfloat( const ptext& label, float* v, float min, float max, const char* format = "%.1f" );
	bool checkbox( const ptext& label, bool* v, c_checkboxstyle style = { } );
	bool optionsbtn( const std::string_view& str_id, std::function< void( ) > options, ImVec2 windowpos = ImVec2{ 0, 0 }, vec2 padding = vec2{ 14, 14 } );
	bool comboex( const ptext& label, const std::string_view& preview, bool should_close = false, c_combostyle style = { } );
	bool combo( const ptext& label, int* v, std::vector< std::string_view > items );
	bool multicombo( const ptext& label, bool* v, std::vector< std::string_view > items );
	bool colorbutton( const std::string& str_id, float* col );
	bool coloredit( const ptext& label, float* col );
	bool binder( const ptext& label, int* key );
	bool selectable( const ptext& label, bool selected, ImVec2 size = ImVec2{ 0, 0 }, c_selectablestyle style = { } );
	void spacing( float px );
	void separator( bool vertical = false, float arg1 = -1, float arg2 = -1 );
	bool textinput( const ptext& label, char* buf, size_t buf_size, c_textinputstyle style = { } );
};

inline auto widgets = std::make_unique< c_widgets >( );