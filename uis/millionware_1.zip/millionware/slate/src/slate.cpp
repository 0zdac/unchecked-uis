#include <slate.h>
#include "../resources/fonts.h"
#include "../resources/images.h"

using namespace ImGui;

void c_slate::initialize_fonts( ) {
    fonts.resize( fonts_size );
    const static ImWchar icons_ranges[] = { 0xE900, 0xF5FD, 0 };
    
    fonts.at( inter_medium ).setup( inter_mediumbinary, sizeof( inter_mediumbinary ),
    { 13, 11 },
    GetIO( ).Fonts->GetGlyphRangesCyrillic( ) );
    
    fonts.at( inter_semibold ).setup( inter_semiboldbinary, sizeof( inter_semiboldbinary ),
    { 13 },
    GetIO( ).Fonts->GetGlyphRangesCyrillic( ) );
}

bool bools[100];
int ints[100];
float floats[100];
bool multicombov[6];
bool multicombov2[6];
float col[100][4];

c_image bg;
c_image logo;
void c_slate::initialize( ID3D11Device* device, ID3D11DeviceContext* ctx, IDXGISwapChain* swapchain ) {
    GImGui->IO.IniFilename = "";
    g_style->dpi_scale = 1;
    g_style->setup( );

    initialize_fonts( );
    
    logo.load( device, logobinary, sizeof( logobinary ) );
    
    bg.load( device, bgbinary, sizeof( bgbinary ) );
    
    widgets->nav.tabs = {
        { "Aimbot", { "Entities", "World", "View" } },
        { "Visuals", {  } },
        { "Misc", {  } },
        { "Skins", {  } },
        { "Settings", {  } },
    };
    
    widgets->nav.addpage( 0, [&] {
        BeginGroup( );
        {
            widgets->child.begin( "General", { 0, 193.f } );
            {
                widgets->checkbox( "Per weapon settings", &bools[0], { .col = { col[0] } } );
                widgets->checkbox( "Enabled", &bools[1], { .key = &ints[43] } );
                widgets->combo( "Flick bot", &ints[0], { "Disabled", "Enabled" } );
                widgets->checkbox( "Console aim assist", &bools[2] );
                widgets->checkbox( "Backtrack", &bools[3] );
            }
            widgets->child.end( );
            widgets->spacing( 10.f );
            widgets->child.begin( "Filters", { 0, 116.f } );
            {
                widgets->checkbox( "Auto wall", &bools[4] );
                widgets->checkbox( "Target teammates", &bools[5] );
                widgets->checkbox( "Smoke check", &bools[6] );
                widgets->checkbox( "Flash check", &bools[7] );
            }
            widgets->child.end( );
            widgets->spacing( 10.f );
            widgets->child.begin( "Standalone RCS", { 0, 116.f } );
            {
                widgets->checkbox( "Enabled##2", &bools[8] );
            }
            widgets->child.end( );
        }
        EndGroup( );
        SameLine( 0, 10.f );
        BeginGroup( );
        {
            widgets->child.begin( "Aim options", { 0, 144.f } );
            {
                widgets->sliderint( "Speed", &ints[1], 0, 100 );
                widgets->sliderfloat( "Speed exponent", &floats[2], 1, 10 );
                widgets->sliderint( "RCS X", &ints[3], 0, 100, "%d%%" );
                widgets->sliderint( "RCS Y", &ints[4], 0, 100, "%d%%" );
                widgets->checkbox( "Adaptive", &bools[9] );
            }
            widgets->child.end( );
            widgets->spacing( 10.f );
            widgets->child.begin( "Prerequisites", { 0, 130.f } );
            {
                widgets->sliderint( "FOV", &ints[5], 0, 180 );
                widgets->sliderint( "Start bullets", &ints[6], 1, 4 );
                widgets->combo( "Hitbox method", &ints[7], { "Head", "Body", "Chest", "Arms", "Legs", "Nearest" } );
                widgets->checkbox( "Target backtrack", &bools[10] );
            }
            widgets->child.end( );
            widgets->spacing( 10.f );
            widgets->child.begin( "Triggerbot", { 0, 151.f } );
            {
                widgets->checkbox( "Enabled##3", &bools[11] );
            }
            widgets->child.end( );
        }
        EndGroup( );
    } );
    
}

void c_slate::draw( ID3D11Device* device, ID3D11DeviceContext* ctx, IDXGISwapChain* swapchain ) {
    m_device = device;
    m_ctx = ctx;
    m_swapchain = swapchain;
    
    g_style->setup( );

    GetBackgroundDrawList( )->AddImage( bg, { 0, -555 }, { 3500, 2333 - 555 } );
    
    SetNextWindowPos( { 555, 555 }, ImGuiCond_Once );
    
    PushStyleVar( ImGuiStyleVar_WindowPadding, vec2{ 10, 10 } );
    widgets->window.begin( "menu", vec2{ 740, 532 }, ImGuiWindowFlags_NoBringToFrontOnFocus );
    {
        GetWindowDrawList( )->AddRectFilled( GetWindowPos( ), GetWindowPos( ) + GetWindowSize( ), g_style->col( pcol_bg ), 0, 0 );
        g_draw->gradient( GetWindowDrawList( ), GetWindowPos( ), GetWindowPos( ) + ImVec2{ GetWindowWidth( ), 31 }, pcolor{ 255, 255, 255, 0.03f }, pcolor{ 255, 255, 255, 0.03f }, pcolor{ 255, 255, 255, 0.00f }, pcolor{ 255, 255, 255, 0.00f }, 0 );

        SetCursorPosY( 31.f );
        PushStyleVar( ImGuiStyleVar_WindowPadding, vec2{ 0, 0 } );
        BeginChild( "main", vec2{ 720, 491 }, 3 );
        {
            PushStyleVar( ImGuiStyleVar_WindowPadding, vec2{ 3, 18 } );
            BeginChild( "sidebar", vec2{ 140, 0 }, 2, 0 );
            {
                SetCursorPosX( 18.f );
                Image( logo, vec2{ 101.f, 45.f } );
                widgets->nav.drawtabs( );
            }
            EndChild( );
            PopStyleVar( );
            SetCursorPos( { GetCurrentWindow( )->DC.CursorPosPrevLine.x + 0.f - GetWindowPos( ).x, GetCurrentWindow( )->DC.CursorPosPrevLine.y + 6.f - GetWindowPos( ).y } );
            BeginChild( "main", vec2{ 574, 479 }, 1 );
            {
                widgets->nav.drawsubtabs( );
                if ( !widgets->nav.tabs[widgets->nav.current].subtabs.empty( ) ) {
                    widgets->spacing( 0.f );
                };
                PushStyleVar( ImGuiStyleVar_Alpha, GImGui->Style.Alpha * widgets->nav.tab_anim * widgets->nav.subtab_anim );
                PushStyleVar( ImGuiStyleVar_WindowPadding, vec2{ 6, 6 } );
                PushStyleVar( ImGuiStyleVar_ItemSpacing, vec2{ 14, 14 } );
                BeginChild( "page", vec2{ 0.f, 0.f }, ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse );
                {
                    SetCursorPosY( 10 );
                    widgets->nav.drawpage( );
                }
                EndChild( );
                PopStyleVar( 3 );
            }
            EndChild( );
        }
        EndChild( );
        PopStyleVar( );
    }
    widgets->window.end( );
    PopStyleVar( );
}