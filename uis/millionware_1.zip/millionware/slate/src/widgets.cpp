#define NOMINMAX
#include <slate.h>
#include <imgui_freetype.h>
#include <thread>
#pragma comment(lib, "winmm.lib")

using namespace ImGui;

vec2::operator ImVec2( ) const {
	return ImVec2{ x, y };
}

extern c_image logo;
void c_font::setup( unsigned char* data, size_t data_size, std::vector< float > sizes, const ImWchar* ranges ) {
	auto config = ImFontConfig( );
	config.FontDataOwnedByAtlas = false;

	for ( auto& sz : sizes ) {
		fonts.push_back( { sz, ImGui::GetIO( ).Fonts->AddFontFromMemoryTTF( data, data_size, sz * g_style->dpi_scale, &config, ranges ) } );
	}
}

bool c_widgets::button( const ptext& label, ImVec2 size, c_buttonstyle style ) 
{
	struct s {
		float hover;
		float held;
	}; auto& obj = anim_obj( label.str.data( ), 0, s{ } );

	auto* window = GetCurrentWindow( );
	bool pressed = InvisibleButton( label.str.data( ), CalcItemSize( size, GImGui->Style.FramePadding.x * 2 + CalcTextSize( label.translate( ).data( ), 0, 1 ).x + ( ( style.iconsize + 8 ) ) * bool( style.icon ), GetFrameHeight( ) ) );
	bool hovered = IsItemHovered( ), held = IsItemActive( );
	ImRect& bb = GImGui->LastItemData.Rect;

	obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
	obj.held = anim( obj.held, 0.f, 1.f, held );

	pcolor iconcolor, labelcolor;
	switch ( style.style ) {
	case button_default:
	{
		iconcolor = g_style->col( pcol_scheme );
		labelcolor = g_style->col( pcol_text );

		window->DrawList->AddRectFilled( bb.Min, bb.Max, col_anim( g_style->col( pcol_bg3 ), g_style->col( pcol_bg4 ), obj.hover ), style.rounding );
	}
	break;
	}

	float spacing = style.iconsize + 8;
    ImVec2 label_pos = bb.GetCenter( ) - CalcTextSize( label.translate( ).data( ), 0, 1 ) / 2;
    if ( style.icon )
    {
        label_pos.x = style.iconpos == align_left ? label_pos.x + ( spacing / 2 ) : label_pos.x - ( spacing / 2 );
        if ( CalcTextSize( label.translate( ).data( ), 0, 1 ).x == 0 ) label_pos.x = bb.GetCenter( ).x + 8 + ( style.iconsize ) / 2;
        float iconpos = style.iconpos == align_left ? label_pos.x - spacing : label_pos.x + CalcTextSize( label.translate( ).data( ), 0, 1 ).x + 8;
        g_draw->text( icons, style.iconsize, { iconpos, bb.GetCenter( ).y - ( style.iconsize ) / 2 }, iconcolor, style.icon );
    }
    
    window->DrawList->AddText( label_pos, labelcolor, label.translate( ).data( ), FindRenderedTextEnd( label.translate( ).data( ) ) );

	return pressed;
}
bool c_widgets::checkbox( const ptext& label, bool* v, c_checkboxstyle style ) 
{
    struct s {
        float anim;
        float hover;
        float enabled;
        ImVec2 optsize;
    }; auto& obj = anim_obj( label.str.data( ), 0, s{ } );
    
    auto* window = GetCurrentWindow( );
    
    float square_sz = 10;
    
    bool pressed = InvisibleButton( label.str.data( ), { CalcItemWidth( ), square_sz } );
    bool hovered = IsItemHovered( ), held = IsItemActive( );
    ImRect total_bb = GImGui->LastItemData.Rect;
    ImRect bb{ { total_bb.Min.x + 0, total_bb.Max.y - 10 }, { total_bb.Min.x + 10, total_bb.Max.y } };
    
    obj.hover = anim( obj.hover, 0.f, 1.f, hovered && !*v );
    obj.enabled = anim( obj.enabled, 0.f, 1.f, *v );
    obj.anim = anim( obj.anim, 0.f, 1.f, hovered || *v );
    
    if ( pressed ) {
        *v = !*v;
    }
    
    auto bgcol = col_anim( col_anim( g_style->col( pcol_bg3 ), g_style->col( pcol_bg4 ), obj.hover ), g_style->col( pcol_scheme ), obj.enabled );
    auto col = col_anim( col_anim( g_style->col( pcol_text2 ), g_style->col( pcol_text3 ), obj.hover ), g_style->col( pcol_text ), obj.enabled );
    
    window->DrawList->AddRectFilled( bb.Min, bb.Max, col_anim( col_anim( g_style->col( pcol_bg2 ), g_style->col( pcol_bg4 ), obj.hover ), g_style->col( pcol_scheme ), obj.enabled ), 0 );
    window->DrawList->AddRect( bb.Min, bb.Max, g_style->col( pcol_border ), 0 );
    g_draw->text( *v ? inter_semibold : inter_medium, 13, total_bb.Min + vec2{ 15, -2 }, col, label.translate( ).data( ), FindRenderedTextEnd( label.translate( ).data( ) ) );
    
    auto pos = window->DC.CursorPos;
    auto posprev = window->DC.CursorPosPrevLine;
    
    window->DC.CursorPos = ImVec2{ total_bb.Max.x - obj.optsize.x, bb.GetCenter( ).y - obj.optsize.y / 2 };
    char temp[128];
    ImFormatString( temp, sizeof( temp ), "%s opt", label.str.data( ) );
    PushStyleVar( ImGuiStyleVar_WindowPadding, vec2{ 1, 1 } );
    BeginChild( temp, { 0, 0 }, ImGuiChildFlags_AlwaysAutoResize | ImGuiChildFlags_AutoResizeY | ImGuiChildFlags_AutoResizeX | ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoBackground );
    {
        if ( style.key ) {
            ImFormatString( temp, sizeof( temp ), "##%s key", label.str.data( ) );
			SetCursorPosY( GetWindowHeight( ) / 2 - 7 );
            widgets->binder( temp, style.key );
            SameLine( 0, 8 );
        }
        if ( style.options ) {
            ImFormatString( temp, sizeof( temp ), "##%s settings", label.str.data( ) );
            SetCursorPosY( GetWindowHeight( ) / 2 - 8 );
            widgets->optionsbtn( temp, style.options );
            SameLine( 0, 8 );
        }
        if ( style.col.size( ) > 0 ) {
            for ( int i = 0; i < style.col.size( ); ++i ) {
                ImFormatString( temp, sizeof( temp ), "##%s col %d", label.str.data( ), i );
                SetCursorPosY( GetWindowHeight( ) / 2 - 5.f );
                widgets->colorbutton( temp, style.col[i] );
                SameLine( 0, 8 );
            }
        }
        
        obj.optsize = GetWindowSize( );
    }
    EndChild( );
    PopStyleVar( );
    
    window->DC.CursorPos = pos;
    window->DC.CursorPosPrevLine = posprev;
    
    return pressed;
}

template < typename T >
bool c_widgets::slider( const ptext& label, T* v, T min, T max, const char* format, c_sliderstyle style ) 
{
    struct s {
        float anim;
        float hover;
        float held;
        float val_anim;
        bool washeld = false;
    }; auto& obj = anim_obj( label.str.data( ), 1120, s{ } );
    
    char max_buf[32];
    ImFormatString( max_buf, sizeof( max_buf ), format, max );
    
    auto* window = GetCurrentWindow( );
    auto id = window->GetID( label.str.data( ) );
    ImRect total_bb{ window->DC.CursorPos, window->DC.CursorPos + ImVec2{ CalcItemWidth(), 21 } };
    ImRect bb{ { total_bb.Min.x + 15, total_bb.Max.y - 6.f }, { total_bb.Max.x - 21.f, total_bb.Max.y } };
    ItemSize( total_bb );
    ItemAdd( total_bb, id );
    
    bool result = false;
    
    auto data = GImGui->LastItemData;
    
    bool hovered, held;
    bool pressed = ButtonBehavior( total_bb, id, &hovered, &held );
    
    obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
    obj.held = anim( obj.held, 0.f, 1.f, held );
    obj.anim = anim( obj.anim, 0.f, 1.f, hovered || held );
    obj.val_anim = ImLerp( obj.val_anim, ( ImClamp( *v, min, max ) - min * 1.f ) / ( max - min ) * bb.GetWidth( ), GetIO( ).DeltaTime * 17 );
    
    if ( held ) {
        *v = ImClamp( T( min + ( GetIO( ).MousePos.x - bb.Min.x ) / bb.GetWidth( ) * ( max - min ) ), min, max );   
        if ( !obj.washeld ) {
            obj.washeld = true;
        }
        } else { 
        if ( obj.washeld ) {
            obj.washeld = false;
            result = true;
        }
    }
    
    window->DrawList->AddRectFilled( bb.Min, bb.Max, col_anim( col_anim( g_style->col( pcol_bg2 ), g_style->col( pcol_bg4 ), obj.hover ), g_style->col( pcol_bg4 ), obj.held ), 0 );
    window->DrawList->AddRect( bb.Min, bb.Max, g_style->col( pcol_border ), 0 );
    
    // Fill
    window->DrawList->AddRectFilled( bb.Min, { bb.Min.x + obj.val_anim, bb.Max.y }, g_style->col( pcol_scheme ), 0, 0 );
    window->DrawList->AddText( total_bb.Min + vec2{ 15, 0 }, g_style->col( pcol_text ), label.translate( ).data( ), FindRenderedTextEnd( label.translate( ).data( ) ) );
    
    
    char buf[32];
    ImFormatString( buf, sizeof( buf ), format, *v );
    
    PushStyleVar( ImGuiStyleVar_FramePadding, { 0.f, 0.f } );
    auto pos = window->DC.CursorPos;
    window->DC.CursorPos = ImVec2{ bb.Max.x - CalcTextSize( buf ).x, total_bb.Min.y };
    char temp[128];
    ImFormatString( temp, sizeof( temp ), "##%s", label );
    BeginChild( temp, { 0, 0 }, ImGuiChildFlags_AlwaysAutoResize | ImGuiChildFlags_AutoResizeX | ImGuiChildFlags_AutoResizeY, ImGuiWindowFlags_NoBackground );
    PushStyleColor( ImGuiCol_FrameBg, GetColorU32( ImGuiCol_FrameBg, 0 ) );
    PushStyleColor( ImGuiCol_Text, g_style->col( pcol_text2 ).vec4( ) );
    if ( InputTextEx( temp, "", buf, sizeof( buf ), CalcTextSize( buf ) + GImGui->Style.FramePadding * 2, ImGuiInputTextFlags_NoHorizontalScroll ) ) {
        DataTypeApplyFromText( buf, std::is_same< T, int >::value ? ImGuiDataType_S32 : ImGuiDataType_Float, v, format );
        *v = ImClamp( *v, min, max );
    }
    PopStyleColor( 2 );
    EndChild( );
    window->DC.CursorPos = pos;
    PopStyleVar( );
    
    GImGui->LastItemData = data;
    
    return result;
}

bool c_widgets::sliderint( const ptext& label, int* v, int min, int max, const char* format ) 
{
	return slider( label, v, min, max, format );
}
bool c_widgets::sliderfloat( const ptext& label, float* v, float min, float max, const char* format ) 
{
	return slider( label, v, min, max, format );
}

bool c_widgets::colorbutton( const std::string& str_id, float* col )
{
    struct s {
        float anim;
        float hover;
        float open_anim;
        bool open;
    }; auto& obj = anim_obj( str_id.c_str( ), 0, s{ } );
    
    auto* window = GetCurrentWindow( );
    bool pressed = InvisibleButton( str_id.c_str( ), vec2{ 20, 10 } );
    bool hovered = IsItemHovered( );
    ImRect bb = GImGui->LastItemData.Rect;
    bool value_changed = false;
    
    if ( pressed ) {
        obj.open = !obj.open;
    }
    
    obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
    obj.open_anim = anim( obj.open_anim, 0.f, 1.f, obj.open );
    obj.anim = anim( obj.anim, 0.f, 1.f, hovered || obj.open );
    
    window->DrawList->AddRectFilled( bb.Min, bb.Max, pcolor{ col[0], col[1], col[2], 1.00f }, 0 );
	window->DrawList->AddRect( bb.Min - ImVec2{ 0, 0.5f }, bb.Max, g_style->col( pcol_border ), 0 );

    g_draw->gradient( window->DrawList, bb.Min, bb.Max, g_style->col( pcol_border, 0.f ), 
    g_style->col( pcol_border, 0.f ), 
    g_style->col( pcol_border, 0.2f ), 
    g_style->col( pcol_border, 0.2f ), 0 );
    
    if ( popup.begin( str_id.c_str( ), obj.open_anim, bb.Min, vec2{ 14, 14 } ) ) {
        if ( ( !IsWindowHovered( ImGuiHoveredFlags_AnyWindow ) || ( GImGui->HoveredWindow && !strstr( GImGui->HoveredWindow->Name, "popup" ) ) || FindWindowDisplayIndex( GImGui->HoveredWindow ) < FindWindowDisplayIndex( GetCurrentWindow( ) ) ) && IsMouseClicked( 0 ) ) {
            obj.open = false;
        }
        
        PushStyleVar( ImGuiStyleVar_ItemSpacing, vec2{ 6, 6 } );
        colorpicker.draw( str_id.c_str( ), col );
        PopStyleVar( );
        
        popup.end( );
    }
    
    return value_changed;
}

bool c_widgets::coloredit( const ptext& label, float* col )
{
	TextEx( label.translate( ).data( ), FindRenderedTextEnd( label.translate( ).data( ) ) );
	SameLine( CalcItemWidth( ) );
	return colorbutton( label.str.data( ), col );
}
bool c_widgets::optionsbtn( const std::string_view& str_id, std::function< void( ) > options, ImVec2 windowpos, vec2 padding )
{
	struct s {
		float anim;
		float hover;
		float open_anim;
		bool open = false;
		bool closed = false;
	}; auto& obj = anim_obj( str_id.data( ), 12210, s{ } );

	auto* window = GetCurrentWindow( );
	bool pressed = InvisibleButton( str_id.data( ), { 16, 16 } );
	bool hovered = IsItemHovered( );
	ImRect bb = GImGui->LastItemData.Rect;

	obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
	obj.open_anim = anim( obj.open_anim, 0.f, 1.f, obj.open );
	obj.anim = anim( obj.anim, 0.f, 1.f, hovered || obj.open );

	if ( pressed && !obj.closed ) {
		obj.open = true;
	}

	if ( !IsMouseDown( 0 ) ) {
		obj.closed = false;
	}

	if ( windowpos.x == 0 && windowpos.y == 0 ) {
		windowpos = ImVec2{ bb.Min.x, bb.Max.y + 8 };
	}

	if ( popup.begin( str_id, obj.open_anim, windowpos, padding ) ) {
		if ( ( !IsWindowHovered( ImGuiHoveredFlags_AnyWindow ) || ( GImGui->HoveredWindow && !strstr( GImGui->HoveredWindow->Name, "popup" ) ) ) && IsMouseClicked( 0 ) ) {
			obj.open = false;
			obj.closed = true;
		}

		PushItemWidth( 180 );
		PushItemFlag( ImGuiItemFlags_NoNav, true );
		options( );
		PopItemFlag( );
		PopItemWidth( );
		popup.end( );
	}

	return pressed;
}

bool c_widgets::comboex( const ptext& label, const std::string_view& preview, bool should_close, c_combostyle style ) 
{
    struct s {
        float anim;
        float hover;
        float held;
        float open_anim;
        bool open;
        float w;
    }; auto& obj = anim_obj( label.str.data( ), 123123443, s{ } );
    
    bool result = false;
    
    obj.w = ImLerp( obj.w, g_draw->textsize( inter_medium, 13, preview.data( ) ).x, GetIO( ).DeltaTime * 17 );
    
    ImVec2 padding{ 4.f, 3.f };
    
    auto* window = GetCurrentWindow( );
    auto id = window->GetID( label.str.data( ) );
    ImRect total_bb{ window->DC.CursorPos, window->DC.CursorPos + ImVec2{ CalcItemWidth( ), 34 } };
    ImRect bb{ { total_bb.Min.x + 15, total_bb.Max.y - 19 }, { total_bb.Max.x - 21, total_bb.Max.y } };
    
    ItemSize( total_bb );
    ItemAdd( total_bb, id );
    
    bool hovered, held;
    bool pressed = ButtonBehavior( bb, id, &hovered, &held );
    
    if ( pressed ) {
        obj.open = !obj.open;
    }
    
    obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
    obj.held = anim( obj.held, 0.f, 1.f, held );
    obj.anim = anim( obj.anim, 0.f, 1.f, obj.open || hovered );
    obj.open_anim = anim( obj.open_anim, 0.f, 1.f, obj.open );
    
    window->DrawList->AddRectFilled( bb.Min, bb.Max, g_style->col( pcol_bg2 ), 0, 0 );
    g_draw->gradient( window->DrawList, bb.Min, bb.Max, col_anim( col_anim( pcolor{ 255, 255, 255, 0.03f }, pcolor{ 255, 255, 255, 0.06f }, obj.hover ), pcolor{ 255, 255, 255, 0.06f }, obj.open_anim ), col_anim( col_anim( pcolor{ 255, 255, 255, 0.03f }, pcolor{ 255, 255, 255, 0.06f }, obj.hover ), pcolor{ 255, 255, 255, 0.06f }, obj.open_anim ), pcolor{ 255, 255, 255, 0.00f }, pcolor{ 255, 255, 255, 0.00f }, 0, 0 );
    window->DrawList->AddRect( bb.Min, bb.Max, g_style->col( pcol_border ), 0, 0 );
    g_draw->text( inter_medium, 13, total_bb.Min + vec2{ 15, 0 }, g_style->col( pcol_text ), label.translate( ).data( ), FindRenderedTextEnd( label.translate( ).data( ) ) );
    window->DrawList->AddText( bb.Min + padding, g_style->col( pcol_text ), preview.data( ) );
    
	RenderArrow( window->DrawList, { bb.Max.x - 20, bb.GetCenter( ).y - 5 }, g_style->col( pcol_text2 ), obj.open ? ImGuiDir_Up : ImGuiDir_Down, 0.8f );
    
    if ( obj.open_anim > 0.05f ) {
        char temp[64];
        ImFormatString( temp, sizeof( temp ), "%s popup", label.str.data( ) );
        PushStyleVar( ImGuiStyleVar_WindowPadding, vec2{ 0, 0 } );
        PushStyleVar( ImGuiStyleVar_WindowRounding, style.rounding );
        PushStyleVar( ImGuiStyleVar_WindowBorderSize, 1 );
        PushStyleVar( ImGuiStyleVar_ItemSpacing, vec2{ 0, 0 } );
        PushStyleVar( ImGuiStyleVar_Alpha, GImGui->Style.Alpha * obj.open_anim );
        PushStyleColor( ImGuiCol_WindowBg, g_style->col( pcol_bg3 ).vec4( ) );
        Begin( temp, 0, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize );
        SetWindowSize( { ImMax( GetCurrentWindow( )->ContentSize.x, bb.GetWidth( ) ), ImMin( GetCurrentWindow( )->ContentSize.y + GImGui->Style.WindowPadding.y * 2 + 2, 200.f ) * obj.open_anim } );
        SetWindowPos( { bb.Min.x, bb.Max.y + 4 } );
        BringWindowToDisplayFront( GetCurrentWindow( ) );
        BringWindowToFocusFront( GetCurrentWindow( ) );
        
        if ( GImGui->HoveredWindow && !strstr( GImGui->HoveredWindow->Name, "popup" ) && IsMouseClicked( 0 ) && !hovered || should_close ) {
            obj.open = false;
        }   
        
        return true;
    }
    
    return false;
}

bool c_widgets::combo( const ptext& label, int* v, std::vector< std::string_view > items ) 
{
	struct s {
		bool should_close;
	}; auto& obj = anim_obj( label.str.data( ), 0, s{ } );
	float maxw = 0;
	for ( int i = 0; i < items.size( ); ++i ) {
		maxw = ImMax( CalcTextSize( items[i].data( ), 0, 1 ).x + 48, maxw );
	}

	if ( comboex( label, items[*v], obj.should_close ) ) {
		if ( obj.should_close ) obj.should_close = false;

		for ( int i = 0; i < items.size( ); ++i ) {
			if ( selectable( items[i], *v == i, { ImMax( maxw, GetWindowWidth( ) - GImGui->Style.WindowPadding.x * 2 ), 22 } ) ) {
				*v = i;
				obj.should_close = true;
			}
		}

		End( );
		PopStyleColor( );
		PopStyleVar( 5 );
	}

	return obj.should_close;
}
bool c_widgets::multicombo( const ptext& label, bool* v, std::vector< std::string_view > items ) 
{
	auto& style = GetStyle( );

    std::string buf;

    buf.clear( );
    for ( size_t i = 0; i < items.size( ); ++i ) {
        if ( v[i] ) {
			buf += ptext{ items[i] }.translate( );
            buf += ", ";
        }
    }

    if ( !buf.empty( ) ) {
        buf.resize( buf.size( ) - 2 );
    }

	float maxw = 0;
	for ( int i = 0; i < items.size( ); ++i ) {
		maxw = ImMax( CalcTextSize( items[i].data( ), 0, 1 ).x + 48, maxw );
	}

    if ( CalcTextSize( buf.c_str( ) ).x > 100 ) {
        for ( int i = 0; i < buf.size( ) - 1; ++i ) {
            if ( CalcTextSize( buf.substr( 0, i + 1 ).c_str( ) ).x > 100 ) {
                buf.resize( i );
                if ( buf[buf.size( ) - 1] == ',' ) {
                    buf.resize( buf.size( ) - 1 );
                }
                buf.append( ".." );
            }
        }
    }

	if ( buf == "" ) { 
		buf = "None";
	}

	bool result = false;
	if ( comboex( label, buf.c_str( ) ) ) {
		for ( int i = 0; i < items.size( ); ++i ) {
			if ( selectable( items[i], v[i], { ImMax( maxw, GetWindowWidth( ) ), 22 } ) ) {
				v[i] = !v[i];
				result = true;
			}
		}

		End( );
		PopStyleColor( );
		PopStyleVar( 5 );
	}

	return result;
}
bool c_widgets::binder( const ptext& label, int* key )
{
	struct s {
		float anim;
		float hover;
		float active_anim;
		float w;
		bool active = false;
	}; auto& obj = anim_obj( label.str.data( ), 0, s{ } );
	std::string_view buf = obj.active ? "..." : keys[*key];
	obj.w = ImLerp( obj.w, g_draw->textsize( inter_medium, 11, buf.data( ) ).x, GetIO( ).DeltaTime * 17 );

	auto* window = GetCurrentWindow( );
	auto id = window->GetID( label.str.data( ) );
	ImRect total_bb{ window->DC.CursorPos, window->DC.CursorPos + ( CalcTextSize( label.str.data( ), 0, 1 ).x > 0 ? ImVec2{ CalcItemWidth( ), 14 } : ImVec2{ 8.f + obj.w, 14 } ) };
	ImRect bb{ total_bb.Max - ImVec2{ ( 8.f + int( obj.w ) ), 14 }, total_bb.Max };
	ItemSize( total_bb );
	ItemAdd( total_bb, id );

	bool hovered, held;
	bool pressed = ButtonBehavior( bb, id, &hovered, &held );
	bool value_changed = false;

	if ( pressed ) {
		obj.active = true;
		*key = 7;
	}

	if ( obj.active ) {
		for ( auto i = 0; i < 5; i++ ) {
			if ( GetIO( ).MouseDown[i] ) {
				switch ( i ) {
				case 0:
					*key = VK_LBUTTON;
					break;
				case 1:
					*key = VK_RBUTTON;
					break;
				case 2:
					*key = VK_MBUTTON;
					break;
				case 3:
					*key = VK_XBUTTON1;
					break;
				case 4:
					*key = VK_XBUTTON2;
				}
				value_changed = true;
				obj.active = false;
			}
		}

		if ( !value_changed ) {
			for ( auto i = VK_BACK; i <= VK_RMENU; i++ ) {
				if ( GetAsyncKeyState( i ) & 0x8000 ) {
					*key = i == VK_ESCAPE ? 0 : i;
					value_changed = true;
					obj.active = false;
				}
			}
		}
	}

	obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
	obj.active_anim = anim( obj.active_anim, 0.f, 1.f, obj.active );
	obj.anim = anim( obj.anim, 0.f, 1.f, hovered || obj.active );

	auto bgcol = col_anim( g_style->col( pcol_bg3 ), g_style->col( pcol_bg4 ), obj.anim );
	window->DrawList->AddRectFilled( bb.Min, bb.Max, bgcol );
	window->DrawList->AddRect( bb.Min, bb.Max, g_style->col( pcol_border ) );
	g_draw->text( inter_medium, 11, bb.Min + vec2{ 4, 1.5f }, g_style->col( pcol_text2 ), buf.data( ) );

	window->DrawList->AddText( { total_bb.Min.x, total_bb.GetCenter( ).y - GImGui->FontSize / 2 }, g_style->col( pcol_text ), label.translate( ).data( ), FindRenderedTextEnd( label.translate( ).data( ) ) );

	return value_changed;
}
bool c_widgets::selectable( const ptext& label, bool selected, ImVec2 size, c_selectablestyle style )
{
	struct s {
		float anim;
		float hover;
		float selected;
	}; auto& obj = anim_obj( label.str.data( ), 0, s{ } );

	style.rounding *= g_style->dpi_scale;
	style.xpad *= g_style->dpi_scale;

	auto* window = GetCurrentWindow( );
	auto id = window->GetID( label.str.data( ) );
	ImRect bb{ window->DC.CursorPos, window->DC.CursorPos + CalcItemSize( size, style.xpad * 2 + int( ( 22 ) * obj.selected ) * style.checkmark + 4 + CalcTextSize( label.translate( ).data( ) ).x, GetFrameHeight( ) ) };
	ItemSize( bb );
	ItemAdd( bb, id );

	bool hovered, held;
	bool pressed = ButtonBehavior( bb, id, &hovered, &held );

	obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
	obj.selected = anim( obj.selected, 0.f, 1.f, selected );
	obj.anim = anim( obj.anim, 0.f, 1.f, hovered || selected );

	auto col = col_anim( col_anim( g_style->col( pcol_text2 ), g_style->col( pcol_text3 ), obj.hover ), g_style->col( pcol_scheme ), obj.selected );

	window->DrawList->AddRectFilled( bb.Min, bb.Max, g_style->col( pcol_bg4, obj.hover ), style.rounding );
	g_draw->text( selected ? inter_semibold : inter_medium, 13, { bb.Min.x + 8, bb.GetCenter( ).y - GImGui->FontSize / 2 }, col, label.translate( ).data( ) );

	return pressed;
}

void c_widgets::spacing( float px )
{
	SetCursorPosY( GetCursorPosY( ) - GImGui->Style.ItemSpacing.y + px );
}

void c_widgets::separator( bool vertical, float arg1, float arg2 )
{
	if ( vertical ) {
		if ( arg1 == -1 ) arg1 = GImGui->FontSize;
		if ( arg2 == -1 ) arg2 = GImGui->FontSize;

		GetWindowDrawList( )->AddRectFilled( GetCurrentWindow( )->DC.CursorPos + ImVec2{ 0, ( arg2 / 2 - arg1 / 2 ) }, GetCurrentWindow( )->DC.CursorPos + ImVec2{ 1, ( arg2 / 2 + arg1 / 2 ) }, g_style->col( pcol_separator ) );
		Dummy( { 1, arg1 } );
	} else {
		if ( arg1 == -1 ) arg1 = 14;
		if ( arg2 == -1 ) arg2 = 0;

		GetWindowDrawList( )->AddRectFilled( GetWindowPos( ) + ImVec2{ arg1, GetCursorPosY( ) }, GetWindowPos( ) + ImVec2{ GetWindowWidth( ) - arg2, GetCursorPosY( ) + 1 }, g_style->col( pcol_separator ) );
		Dummy( { GetWindowWidth( ) - arg1 - arg2, 1 } );
	}	
}

bool c_widgets::textinput( const ptext& label, char* buf, size_t buf_size, c_textinputstyle style )
{
	bool result = false;

	if ( !style.bgcol ) {
		style.bgcol = g_style->col( pcol_bg3 );
	}

	BeginGroup( );
	if ( CalcTextSize( label.str.data( ), 0, 1 ).x > 0 ) {
		Text( label.translate( ).data( ) );
		spacing( 8 );
	}

	PushStyleVar( ImGuiStyleVar_FramePadding, style.padding );
	ImVec2 size{ CalcItemSize( style.size, CalcItemWidth( ), GetFrameHeight( ) ) };
	ImRect bb{ GetCurrentWindow( )->DC.CursorPos, GetCurrentWindow( )->DC.CursorPos + size };
	GetWindowDrawList( )->AddRectFilled( bb.Min, bb.Max, style.bgcol, style.rounding );

	if ( GImGui->Style.FrameBorderSize > 0 ) {
		GetWindowDrawList( )->AddRect( bb.Min, bb.Max, g_style->col( pcol_border ), style.rounding );
	}

	PushStyleColor( ImGuiCol_FrameBg, GetColorU32( ImGuiCol_FrameBg, 0 ) );
	char temp[64];
	ImFormatString( temp, sizeof( temp ), "##%s", label.str.data( ) );

	if ( style.icon ) {
		g_draw->text( icons, 16, bb.Min + style.padding, g_style->col( pcol_text2 ), style.icon );
		SetCursorPosX( GetCursorPosX( ) + 26 );
	}

	PushStyleVar( ImGuiStyleVar_FrameBorderSize, 0 );
	result = InputTextEx( temp, style.hint.data( ), buf, buf_size, size - ImVec2{ ( 26.f ) * bool( style.icon ), 0 }, style.flags );
	PopStyleColor( );
	PopStyleVar( 2 );
	EndGroup( );

	return result;
}

///////////////////////////////////////////////////////////////////////////////


// WINDOW
void c_widgets::widget_window::begin( const std::string_view& name, ImVec2 size, ImGuiWindowFlags flags ) {
	SetNextWindowSize( size );
	Begin( name.data( ), 0, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoResize | flags );
}
void c_widgets::widget_window::end( ) {
	End( );
}

// CHILD

std::string last_name;
void c_widgets::widget_child::begin( const ptext& name, ImVec2 size ) {
    float padding = GImGui->Style.WindowPadding.x;
    PushStyleVar( ImGuiStyleVar_WindowPadding, { 0, 0 } );
    BeginChild( name.str.data( ), CalcItemSize( size, GetWindowWidth( ) / 2 - padding - GImGui->Style.ItemSpacing.x / 2, 0 ), 97, 0 );
    PopStyleVar( );

	last_name = name.str;
    
    PushStyleVar( ImGuiStyleVar_WindowPadding, vec2{ 11, 11 } );
    PushStyleVar( ImGuiStyleVar_ItemSpacing, vec2{ 14, 6 } );
    PushStyleVar( ImGuiStyleVar_ChildRounding, 0 );
    BeginChild( "content", { 0, size.y == 0 ? 0 : size.y - GetCursorPosY( ) }, 98, 152 );
    PopStyleVar( );
    
    PushItemWidth( GetWindowWidth( ) - GImGui->Style.WindowPadding.x * 2 );
    smoothscroll( false );
}

void c_widgets::widget_child::end( ) {
	PopItemWidth( );

	PushClipRect( GetCurrentWindow( )->ParentWindow->ParentWindow->ClipRect.Min, GetCurrentWindow( )->ParentWindow->ParentWindow->ClipRect.Max, false );
	GetWindowDrawList( )->AddText( GetWindowPos( ) + ImVec2{ 14, -10 }, GetColorU32( ImGuiCol_Text ), last_name.c_str( ) );
	PopClipRect( );

	EndChild( );
	PopStyleVar( 2 );
	EndChild( );
}

float* c_widgets::widget_child::smoothscroll( bool scrollbar, ImVec2 padding )
{
	struct s {
		ImVec2 scroll;
		ImVec2 scroll_anim;
		bool scroll_activey = false;
		bool scroll_activex = false;
		float oldscroll;
		float clickpos;

		float xanim;
		float yanim;
	}; auto& obj = anim_obj( GetCurrentWindow( )->Name, 23123, s{ } );

	obj.scroll.y = ImClamp( obj.scroll.y, 0.f, GetCurrentWindow( )->ScrollMax.y );
	obj.scroll.x = ImClamp( obj.scroll.x, 0.f, GetCurrentWindow( )->ScrollMax.x );
	obj.scroll_anim.y = ImClamp( obj.scroll_anim.y, 0.f, GetCurrentWindow( )->ScrollMax.y );
	obj.scroll_anim.x = ImClamp( obj.scroll_anim.x, 0.f, GetCurrentWindow( )->ScrollMax.x );

	if ( scrollbar ) {
		// vertical
		{
			ImRect scrollbarbb{ GetWindowPos( ) + ImVec2{ GetWindowWidth( ) - 5, 4 + padding.y }, GetWindowPos( ) + GetWindowSize( ) - vec2{ 2, 4 + padding.y } };
			float visiblepart = GetWindowHeight( ) / ( GetCurrentWindow( )->ContentSize.y + GImGui->Style.WindowPadding.y * 2 );

			if ( visiblepart < 1.f ) {
				float scrollh = scrollbarbb.GetHeight( ) * visiblepart;
				float invisiblepart = 1.f - visiblepart;
				float scrolloffset = ( obj.scroll.y / GetCurrentWindow( )->ScrollMax.y ) * ( scrollbarbb.GetHeight( ) - scrollh );

				obj.yanim = anim( obj.yanim, 0.f, 1.f, IsMouseHoveringRect( scrollbarbb.Min, scrollbarbb.Max ) || obj.scroll_activey );
				auto col = col_anim( g_style->col( pcol_scheme ), g_style->col( pcol_scheme, 0.8f ), obj.yanim );

				GetWindowDrawList( )->AddRectFilled( scrollbarbb.Min + vec2{ 1, 0 }, scrollbarbb.Max - vec2{ 1, 0 }, g_style->col( pcol_bg3 ), 5 );
				GetWindowDrawList( )->PushClipRect( scrollbarbb.Min, scrollbarbb.Max );
				GetWindowDrawList( )->AddRectFilled( scrollbarbb.Min + ImVec2{ 0, scrolloffset }, { scrollbarbb.Max.x, scrollbarbb.Min.y + scrollh + scrolloffset }, col, 5 );
				GetWindowDrawList( )->PopClipRect( );

				if ( IsMouseClicked( 0 ) && IsMouseHoveringRect( scrollbarbb.Min, scrollbarbb.Max ) && !obj.scroll_activey ) {
					obj.scroll_activey = true;
					obj.oldscroll = obj.scroll.y;
					obj.clickpos = ( GetIO( ).MousePos.y - scrollbarbb.Min.y ) / scrollbarbb.GetHeight( );
				} if ( !IsMouseDown( 0 ) ) obj.scroll_activey = false;

				if ( obj.scroll_activey ) {
					GetCurrentWindow( )->Flags |= ImGuiWindowFlags_NoMove;

					float newscroll = ( GetIO( ).MousePos.y - scrollbarbb.Min.y ) / scrollbarbb.GetHeight( );
					float diff = ( newscroll - obj.clickpos ) / invisiblepart;

					obj.scroll.y = obj.oldscroll + diff * GetCurrentWindow( )->ScrollMax.y;
					obj.scroll.y = ImClamp( obj.scroll.y, 0.f, GetCurrentWindow( )->ScrollMax.y );
				}
			}
		}
		// horizontal
		{
			ImRect scrollbarbb{ GetWindowPos( ) + ImVec2{ 3 + padding.x, GetWindowHeight( ) - 5 }, GetWindowPos( ) + GetWindowSize( ) - vec2{ 3 + padding.x, 2 } };
			float visiblepart = GetWindowWidth( ) / ( GetCurrentWindow( )->ContentSize.x + GImGui->Style.WindowPadding.x * 2 );

			if ( visiblepart < 1.f ) {
				float scrollh = scrollbarbb.GetWidth( ) * visiblepart;
				float invisiblepart = 1.f - visiblepart;
				float scrolloffset = ( obj.scroll.x / GetCurrentWindow( )->ScrollMax.x ) * ( scrollbarbb.GetWidth( ) - scrollh );

				obj.xanim = anim( obj.xanim, 0.f, 1.f, IsMouseHoveringRect( scrollbarbb.Min, scrollbarbb.Max ) || obj.scroll_activex );
				auto col = col_anim( g_style->col( pcol_bg3 ), g_style->col( pcol_text2 ), obj.xanim );

				GetWindowDrawList( )->PushClipRect( scrollbarbb.Min, scrollbarbb.Max );
				GetWindowDrawList( )->AddRectFilled( scrollbarbb.Min + ImVec2{ scrolloffset, 0 }, { scrollbarbb.Min.x + scrollh + scrolloffset, scrollbarbb.Max.y }, col, 5 );
				GetWindowDrawList( )->PopClipRect( );

				if ( IsMouseClicked( 0 ) && IsMouseHoveringRect( scrollbarbb.Min, scrollbarbb.Max ) && !obj.scroll_activex ) {
					obj.scroll_activex = true;
					obj.oldscroll = obj.scroll.x;
					obj.clickpos = ( GetIO( ).MousePos.x - scrollbarbb.Min.x ) / scrollbarbb.GetWidth( );
				} if ( !IsMouseDown( 0 ) ) obj.scroll_activex = false;

				if ( obj.scroll_activex ) {
					GetCurrentWindow( )->Flags |= ImGuiWindowFlags_NoMove;

					float newscroll = ( GetIO( ).MousePos.x - scrollbarbb.Min.x ) / scrollbarbb.GetWidth( );
					float diff = ( newscroll - obj.clickpos ) / invisiblepart;

					obj.scroll.x = obj.oldscroll + diff * GetCurrentWindow( )->ScrollMax.x;
					obj.scroll.x = ImClamp( obj.scroll.x, 0.f, GetCurrentWindow( )->ScrollMax.x );
				}
			}
		}
	}

	GetCurrentWindow( )->Scroll.y = obj.scroll_anim.y < 0.5f ? 0.f : obj.scroll_anim.y > ( GetCurrentWindow( )->ScrollMax.y - 0.5f ) ? GetCurrentWindow( )->ScrollMax.y : ImLerp( GetCurrentWindow( )->Scroll.y, obj.scroll.y, GetIO( ).DeltaTime * 40 );
	GetCurrentWindow( )->Scroll.x = ImLerp( GetCurrentWindow( )->Scroll.x, obj.scroll.x, GetIO( ).DeltaTime * 40 );

	ImGuiWindow* wheeling_window = nullptr;
	if ( GImGui->HoveredWindow ) {
		if ( GImGui->HoveredWindow->Flags & ImGuiWindowFlags_ChildWindow ) {
			for ( ImGuiWindow* window = GImGui->HoveredWindow; window->Flags & ImGuiWindowFlags_ChildWindow; window = window->ParentWindow ) {
				if ( window->ScrollMax[ImGuiAxis_Y] == 0 )
					continue;

				wheeling_window = window;
				break;
			}
		} else {
			wheeling_window = GImGui->HoveredWindow;
		}
	}

	if ( wheeling_window == GetCurrentWindow( ) ) {
		if ( !IsKeyDown( ImGuiKey_LeftCtrl ) )
			obj.scroll.y = ImClamp( obj.scroll.y - GetIO( ).MouseWheel * 80, 0.f, GetCurrentWindow( )->ScrollMax.y );
		else
			obj.scroll.x = obj.scroll.x - GetIO( ).MouseWheel * 80;
	}

	obj.scroll_anim.y = ImLerp( obj.scroll_anim.y, obj.scroll.y, GetIO( ).DeltaTime * 40 );
	obj.scroll_anim.x = ImLerp( obj.scroll_anim.x, obj.scroll.x, GetIO( ).DeltaTime * 40 );

	return &obj.scroll.y;
}

// MENU
void c_widgets::widget_menu::begin( const std::string_view& str_id ) {

}
void c_widgets::widget_menu::end( ) {

}
bool c_widgets::widget_menu::button( const ptext& label, ImVec2 size, c_buttonstyle style ) {
	return false;
}

// POPUP
bool c_widgets::widget_popup::begin( const std::string_view& str_id, float alpha, ImVec2 pos, ImVec2 padding )
{
	char temp[64];
	ImFormatString( temp, sizeof( temp ), "%s popup", str_id.data( ) );

	if ( alpha > 0.05f ) {
		if ( pos != ImVec2{ 0, 0 } )
			SetNextWindowPos( pos );
		PushStyleVar( ImGuiStyleVar_Alpha, GImGui->Style.Alpha * alpha );
		PushStyleVar( ImGuiStyleVar_WindowPadding, padding );
		PushStyleVar( ImGuiStyleVar_WindowBorderSize, 1 );
		PushStyleVar( ImGuiStyleVar_WindowRounding, 4 );
		Begin( temp, 0, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize );

		if ( alpha > 0.95f ) {
			GetCurrentWindow( )->Flags |= ImGuiWindowFlags_NoBringToFrontOnFocus;
		} else {
			GetCurrentWindow( )->Flags &= ~ImGuiWindowFlags_NoBringToFrontOnFocus;
		}

		return true;
	}

	return false;
}
void c_widgets::widget_popup::end( )
{
	End( );
	PopStyleVar( 4 );
}

bool c_widgets::widget_nav::subtab( const ptext& label, bool selected )
{
    struct s {
        float anim;
        float hover;
        float selected;
    }; auto& obj = anim_obj( label.str.data( ), 0, s{ } );
    
    auto* window = GetCurrentWindow( );
    auto id = window->GetID( label.str.data( ) );
    ImRect bb{ window->DC.CursorPos, window->DC.CursorPos + ImVec2{ GetWindowWidth( ) / tabs[current].subtabs.size( ), 22 } };
    ItemSize( bb );
    ItemAdd( bb, id );
    
    bool hovered, held;
    bool pressed = ButtonBehavior( bb, id, &hovered, &held );
    
    obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
    obj.selected = anim( obj.selected, 0.f, 1.f, selected );
    obj.anim = anim( obj.anim, 0.f, 1.f, hovered || selected );
    
    g_draw->gradient( window->DrawList, bb.Min, bb.Max, col_anim( col_anim( pcolor{ 255, 255, 255, 0.03f }, pcolor{ 255, 255, 255, 0.06f }, obj.hover ), pcolor{ 255, 255, 255, 0.03f }, obj.selected ), 
    col_anim( col_anim( pcolor{ 255, 255, 255, 0.03f }, pcolor{ 255, 255, 255, 0.06f }, obj.hover ), pcolor{ 255, 255, 255, 0.03f }, obj.selected ), 
    pcolor{ 255, 255, 255, 0.00f }, 
    pcolor{ 255, 255, 255, 0.00f }, 0 );
    g_draw->text( selected ? inter_semibold : inter_medium, 13, { bb.GetCenter( ).x - CalcTextSize( label.translate( ).data( ), 0, 1 ).x / 2, bb.Min.y + 3.f }, g_style->col( pcol_text ), label.translate( ).data( ) );
    window->DrawList->AddRectFilled( bb.Min + vec2{ 0.f, 20.f }, bb.Max, col_anim( g_style->col( pcol_scheme, 0.f ), g_style->col( pcol_scheme ), obj.selected ), 0, 0 );
    
    return pressed;
}

bool c_widgets::widget_nav::tab( c_tab tab, bool selected )
{
    auto* window = GetCurrentWindow( );
    
    struct s {
        float anim;
        float hover;
        float selected;
    }; auto& obj = anim_obj( tab.label.str.data( ), 0, s{ } );
    
    bool pressed = InvisibleButton( tab.label.str.data( ), { 134.f, 32.f } );
    bool hovered = IsItemHovered( ), held = IsItemActive( );
    ImRect bb = GImGui->LastItemData.Rect;
    
    obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
    obj.selected = anim( obj.selected, 0.f, 1.f, selected );
    obj.anim = anim( obj.anim, 0.f, 1.f, hovered || selected );
    
    window->DrawList->AddRectFilled( bb.Min, bb.Max, col_anim( col_anim( g_style->col( pcol_tab, 0.f ), g_style->col( pcol_tab, 0.5f ), obj.hover ), g_style->col( pcol_tab ), obj.selected ), 0 );
    window->DrawList->AddRect( bb.Min, bb.Max, g_style->col( pcol_border ), 0 );
    window->DrawList->AddRectFilled( bb.Min, bb.Min + vec2{ 3.f, 32.f }, col_anim( g_style->col( pcol_scheme, 0.f ), g_style->col( pcol_scheme ), obj.selected ), 0, 0 );
    g_draw->text( selected ? inter_semibold : inter_medium, 13, bb.Min + vec2{ 10.f, 9.f }, g_style->col( pcol_text ), tab.label.translate( ).data( ) );
    
    return pressed;
}

void c_widgets::widget_nav::drawtabs( )
{
    
    BeginGroup( );
    {
        for ( int i = 0; i < tabs.size( ); ++i ) {
            if ( tab( tabs[i], next == i ) && next != i ) {
                next = i;
                tab_animdest = 0;
            }
            
            widgets->spacing( 3 );
        }
    }
    EndGroup( );
    
    
    tab_anim = ImLerp( tab_anim, tab_animdest, GetIO( ).DeltaTime * 17 );
    subtab_anim = ImLerp( subtab_anim, subtab_animdest, GetIO( ).DeltaTime * 17 );
    
    if ( tab_anim < 0.05f ) {
        tab_animdest = 1.f;
        current = next;
    }
    
    if ( subtab_anim < 0.05f ) {
        subtab_animdest = 1.f;
        tabs[current].current = tabs[current].next;
    }
}
void c_widgets::widget_nav::drawsubtabs( )
{
    if ( tabs[current].subtabs.empty( ) ) {
        return;
    }
    
    PushStyleVar( ImGuiStyleVar_Alpha, GImGui->Style.Alpha * tab_anim );
    BeginChild( "subtabs", vec2{ 0, 22 }, 0, 128 );
    {
        GetWindowDrawList( )->AddRectFilled( GetWindowPos( ) + ImVec2{ 0, GetWindowHeight( ) - 1 }, GetWindowPos( ) + GetWindowSize( ), g_style->col( pcol_border ) );
        
        for ( int i = 0; i < tabs[current].subtabs.size( ); ++i ) {
            if ( subtab( tabs[current].subtabs[i], i == tabs[current].next ) && i != tabs[current].next ) {
                tabs[current].next = i;
                subtab_animdest = 0;
            }
            SameLine( 0, 0 );
        }
    }
    EndChild( );
    
    PopStyleVar( );
}
void c_widgets::widget_nav::drawpage( )
{
	if ( tabs[current].pages.size( ) <= tabs[current].current )
		return;

	tabs[current].pages[tabs[current].current]( );
}
void c_widgets::widget_nav::addpage( int tab, std::function< void( ) > code )
{
	tabs[tab].pages.push_back( code );
}

// COLORPICKER

bool c_widgets::widget_colorpicker::huebar( const char* str_id, float* h, float s, float v )
{
	float h_values[] {
		0.f, 0.1f, 0.2f, 0.3f, 0.4f, 0.5f, 0.6f, 0.7f, 0.8f, 0.9f, 1.f
	};
	int h_size = IM_ARRAYSIZE( h_values );

	ImVec2 size{ 207, int( 5 ) * 1.f };
	ImRect bb{ GetCurrentWindow( )->DC.CursorPos, GetCurrentWindow( )->DC.CursorPos + size };

	for ( int i = 0; i < h_size - 1; ++i ) {
		ImColor col1, col2;

		ColorConvertHSVtoRGB( h_values[i], ImClamp( s, 0.6f, 1.f ), ImClamp( v, 0.6f, 1.f ), col1.Value.x, col1.Value.y, col1.Value.z );
		ColorConvertHSVtoRGB( h_values[i + 1], ImClamp( s, 0.6f, 1.f ), ImClamp( v, 0.6f, 1.f ), col2.Value.x, col2.Value.y, col2.Value.z );
		col1.Value.w = col2.Value.w = GImGui->Style.Alpha;
		
		g_draw->gradient( GetWindowDrawList( ), { bb.Min.x + ( size.x / ( h_size - 1 ) ) * i, bb.Min.y }, { bb.Min.x + ( size.x / ( h_size - 1 ) ) * ( i + 1 ), bb.Max.y }, col1, col2, col2, col1, 4, i == 0 ? ImDrawFlags_RoundCornersLeft : ( i == h_size - 2 ) ? ImDrawFlags_RoundCornersRight : ImDrawFlags_RoundCornersNone );
	}

	GetWindowDrawList( )->AddCircle( { bb.Min.x + size.x * *h, bb.GetCenter( ).y }, 3, ImColor{ 1.f, 1.f, 1.f, GImGui->Style.Alpha } );

	InvisibleButton( "hue", size );
	if ( IsItemActive( ) ) {
		*h = ImSaturate( ( GetIO( ).MousePos.x - bb.Min.x ) / size.x );

		return true;
	}

	return false;
}
bool c_widgets::widget_colorpicker::alphabar( float* col )
{
	ImVec2 size{ 6, 132 };
	ImRect bb{ GetCurrentWindow( )->DC.CursorPos, GetCurrentWindow( )->DC.CursorPos + size };

	float square_sz = 3;

	GetWindowDrawList( )->Flags &= ~ImDrawListFlags_AntiAliasedFill;
	for ( int i = 0; i < size.y / ( square_sz ) - 1; ++i ) {
		GetWindowDrawList( )->AddRectFilled( bb.Min + ImVec2{ 0, square_sz * i }, bb.Min + ImVec2{ bb.GetWidth( ) / 2, square_sz * ( i + 1 ) }, ( i + 1 ) % 2 == 0 ? ImColor{ 222, 222, 222, int( 255 * GImGui->Style.Alpha ) } : ImColor{ 155, 155, 155, int( 255 * GImGui->Style.Alpha ) }, 4, i == 0 ? ImDrawFlags_RoundCornersTopLeft : ( i == size.y / square_sz - 2 ) ? ImDrawFlags_RoundCornersBottomLeft : ImDrawFlags_RoundCornersNone );
		GetWindowDrawList( )->AddRectFilled( bb.Min + ImVec2{ bb.GetWidth( ) / 2, square_sz * i }, bb.Min + ImVec2{ bb.GetWidth( ), square_sz * ( i + 1 ) }, ( i + 1 ) % 2 != 0 ? ImColor{ 222, 222, 222, int( 255 * GImGui->Style.Alpha ) } : ImColor{ 155, 155, 155, int( 255 * GImGui->Style.Alpha ) }, 4, i == 0 ? ImDrawFlags_RoundCornersTopRight : ( i == size.y / square_sz - 2 ) ? ImDrawFlags_RoundCornersBottomRight : ImDrawFlags_RoundCornersNone );
	}

	g_draw->gradient( GetWindowDrawList( ), bb.Min, bb.Max, ImColor{ col[0], col[1], col[2], GImGui->Style.Alpha }, ImColor{ col[0], col[1], col[2], GImGui->Style.Alpha }, ImColor{ col[0], col[1], col[2], 0.f }, ImColor{ col[0], col[1], col[2], 0.f }, 4 );
	GetWindowDrawList( )->Flags |= ImDrawListFlags_AntiAliasedFill;

	GetWindowDrawList( )->AddCircleFilled( { bb.GetCenter( ).x, bb.Min.y + ( 1.f - col[3] ) * size.y }, 3.5f, ImColor{ 1.f, 1.f, 1.f, GImGui->Style.Alpha }, 30 );
	GetWindowDrawList( )->AddCircleFilled( { bb.GetCenter( ).x, bb.Min.y + ( 1.f - col[3] ) * size.y }, 3.5f, ImColor{ col[0], col[1], col[2], col[3] * GImGui->Style.Alpha }, 30 );
	GetWindowDrawList( )->AddCircle( { bb.GetCenter( ).x, bb.Min.y + ( 1.f - col[3] ) * size.y }, 3.5f, ImColor{ 1.f, 1.f, 1.f, GImGui->Style.Alpha }, 30 );

	InvisibleButton( "a", size );
    if ( IsItemActive( ) )
    {
        col[3] = 1.f - ImSaturate( ( GetIO( ).MousePos.y - bb.Min.y ) / size.y );

        return true;
    }

	return false;
}
bool c_widgets::widget_colorpicker::square( const char* str_id, float h, float* s, float* v )
{
	ImVec2 size{ 193, 132 };
	ImRect bb{ GetCurrentWindow( )->DC.CursorPos, GetCurrentWindow( )->DC.CursorPos + size };

	ImColor col_white{ 1.f, 1.f, 1.f, GImGui->Style.Alpha };
	ImColor col_black{ 0.f, 0.f, 0.f, GImGui->Style.Alpha };
	ImColor col_hue;

	ColorConvertHSVtoRGB( h, 1, 1, col_hue.Value.x, col_hue.Value.y, col_hue.Value.z );
	col_hue.Value.w = GImGui->Style.Alpha;

	GetWindowDrawList( )->Flags &= ~ImDrawListFlags_AntiAliasedFill;
	g_draw->gradient( GetWindowDrawList( ), bb.Min, bb.Max, col_white, col_hue, col_hue, col_white, 4, 0 );
    g_draw->gradient( GetWindowDrawList( ), bb.Min, bb.Max, 0, 0, col_black, col_black, 4, 0 );
	GetWindowDrawList( )->Flags |= ImDrawListFlags_AntiAliasedFill;

	GetWindowDrawList( )->AddCircle( bb.Min + size * ImVec2{ *s, 1.f - *v }, 3, col_white, 36 );

	InvisibleButton( "sv", size );
    if ( IsItemActive( ) )
    {
        *s = ImSaturate( ( GetIO( ).MousePos.x - bb.Min.x ) / size.x );
        *v = 1.f - ImSaturate( ( GetIO( ).MousePos.y - bb.Min.y ) / size.y );

        return true;
    }
}
bool c_widgets::widget_colorpicker::draw( const std::string_view& str_id, float* col )
{
	bool value_changed = false;

	struct s {
		float h, s, v;
		bool init;
	}; auto& obj = anim_obj( str_id.data( ), 2323321, s{ } );

	if ( !obj.init ) {
		ColorConvertRGBtoHSV( col[0], col[1], col[2], obj.h, obj.s, obj.v );
		obj.init = true;
	}
	
	BeginGroup( );
	value_changed |= square( str_id.data( ), obj.h, &obj.s, &obj.v );
	SameLine( );
	value_changed |= alphabar( col );
	EndGroup( );
	value_changed |= huebar( str_id.data( ), &obj.h, obj.s, obj.v );

	static char buf[7];
	static char alpha_buf[7];
	ImFormatString( buf, sizeof( buf ), "%02X%02X%02X", int( col[0] * 255 ), int( col[1] * 255 ), int( col[2] * 255 ) );
	ImFormatString( alpha_buf, sizeof( alpha_buf ), "%d%%", int( col[3] * 100 ) );

	PushStyleColor( ImGuiCol_FrameBg, GetColorU32( ImGuiCol_FrameBgHovered ) );
	PushStyleVar( ImGuiStyleVar_FrameBorderSize, 1 );
	PushStyleVar( ImGuiStyleVar_FramePadding, { 6, 3 } );
	PushItemFlag( ImGuiItemFlags_NoNav, true );

	if ( value_changed ) {
		ColorConvertHSVtoRGB( obj.h, obj.s, obj.v, col[0], col[1], col[2] );
	}

	bool hex_changed = widgets->textinput( "##hex_input", buf, sizeof( buf ), { .padding = vec2{ 8, 8 }, .size = vec2{ 117, 0 } } );
	SameLine( 0, 10 );

	bool alpha_changed = widgets->textinput( "##a_input", alpha_buf, sizeof( alpha_buf ), { .padding = vec2{ 8, 8 }, .size = vec2{ 80, 0 } } );

	PopItemFlag( );
	PopStyleVar( 2 );
	PopStyleColor( );

	int i[4];
	sscanf( buf, "%02X%02X%02X", ( unsigned int* )&i[0], ( unsigned int* )&i[1], ( unsigned int* )&i[2] );
	sscanf( alpha_buf, "%d%%", ( unsigned int* )&i[3] );
	if ( hex_changed ) {
		col[0] = i[0] / 255.f;
		col[1] = i[1] / 255.f;
		col[2] = i[2] / 255.f;

		ColorConvertRGBtoHSV( col[0], col[1], col[2], obj.h, obj.s, obj.v );
	}
	
	if ( alpha_changed ) {
		col[3] = i[3] / 100.f;
	}

	return value_changed;
}
bool c_widgets::widget_colorpicker::colorbutton( const char* str_id, const ImColor& color )
{
	struct s {
		float anim = 0;
		float hover = 0;
		float held = 0;
	}; auto& obj = anim_obj( str_id, 0, s{ } );

	auto* window = GetCurrentWindow( );
	auto id = window->GetID( str_id );
	ImRect bb{ window->DC.CursorPos, window->DC.CursorPos + vec2{ 16, 16 } };
	ItemSize( bb );
	ItemAdd( bb, id );

	bool hovered, held;
	bool pressed = ButtonBehavior( bb, id, &hovered, &held );

	obj.hover = anim( obj.hover, 0.f, 1.f, hovered );
	obj.held = anim( obj.held, 0.f, 1.f, held );
	obj.anim = anim( obj.anim, 0.f, 1.f, hovered || held );

	window->DrawList->AddCircleFilled( bb.GetCenter( ), bb.GetSize( ).x / 2, g_style->col( pcol_bg3 ), bb.GetSize( ).x * 5 );

	window->DrawList->PushClipRect( bb.GetCenter( ), bb.Max );
	window->DrawList->AddCircleFilled( bb.GetCenter( ), bb.GetSize( ).x / 2, pcolor{ 255, 255, 255 }, bb.GetSize( ).x * 5 );
	window->DrawList->PopClipRect( );

	window->DrawList->PushClipRect( bb.Min, { bb.GetCenter( ).x, bb.Max.y } );
	window->DrawList->AddCircleFilled( bb.GetCenter( ), bb.GetSize( ).x / 2, ImColor{ color.Value.x, color.Value.y, color.Value.z, GImGui->Style.Alpha }, bb.GetSize( ).x * 5 );
	window->DrawList->PopClipRect( );

	window->DrawList->PushClipRect( { bb.GetCenter( ).x, bb.Min.y }, bb.Max );
	window->DrawList->AddCircleFilled( bb.GetCenter( ), bb.GetSize( ).x / 2, ImColor{ color.Value.x, color.Value.y, color.Value.z, GImGui->Style.Alpha * color.Value.w }, bb.GetSize( ).x * 5 );
	window->DrawList->PopClipRect( );

	window->DrawList->AddCircle( bb.GetCenter( ), bb.GetSize( ).x / 2 - 1, pcolor{ 0, 0, 0, 0.3f }, bb.GetSize( ).x * 5, 2.5f );

	return pressed;
}