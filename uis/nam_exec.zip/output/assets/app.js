    lucide.createIcons();

    const toastContainer = document.getElementById('toastContainer');
    const toastIcons = {
      success: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
      error: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
      info: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>',
      warning: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
    };
    function showToast(message, type) {
      type = type || 'info';
      const el = document.createElement('div');
      el.className = 'toast ' + type;
      el.innerHTML = toastIcons[type] + '<span>' + message + '</span>';
      toastContainer.appendChild(el);
      setTimeout(function() { el.remove(); }, 3000);
    }

    (function() {
      const STORAGE_KEY = 'nam-settings';

      function loadSettings() {
        try { return Object.assign({}, memSettings, JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}); } catch { return Object.assign({}, memSettings); }
      }
      // In-memory fallback so the app never dies when storage is blocked
      // (file:// with denied site data, private mode, etc.). loadSettings
      // already never throws; saveSettings must not either — one uncaught
      // throw here used to kill the entire UI script on startup.
      let memSettings = {};
      function saveSettings(key, value) {
        try {
          const s = loadSettings();
          s[key] = value;
          localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
        } catch (e) {
          memSettings[key] = value;
        }
      }

      const tabs = document.querySelectorAll('.tab-btn');
      const indicator = document.getElementById('tabIndicator');
      const panes = {
        home: document.getElementById('tabHome'),
        code: document.getElementById('tabCode'),
        globe: document.getElementById('tabGlobe'),
        settings: document.getElementById('tabSettings')
      };

      const tabMetrics = {};

      function measureTabs() {
        const parent = document.querySelector('.tab-bar');
        const parentRect = parent.getBoundingClientRect();
        tabs.forEach(function(btn) {
          const rect = btn.getBoundingClientRect();
          tabMetrics[btn.dataset.tab] = { left: rect.left - parentRect.left, width: rect.width };
        });
      }

      function updateIndicator(activeBtn) {
        const m = tabMetrics[activeBtn.dataset.tab] || {};
        indicator.style.left = (m.left || 0) + 'px';
        indicator.style.width = (m.width || 0) + 'px';
      }

      function setActiveTab(tabId) {
        tabs.forEach(btn => {
          btn.classList.toggle('active', btn.dataset.tab === tabId);
        });
        Object.keys(panes).forEach(key => {
          const isActive = key === tabId;
          panes[key].classList.toggle('active', isActive);
          try {
            if (isActive) {
              panes[key].removeAttribute('inert');
              panes[key].style.display = '';
            } else {
              panes[key].setAttribute('inert', '');
            }
          } catch(e) {}
        });
        const activeBtn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
        if (activeBtn) updateIndicator(activeBtn);
        if (document.documentElement.classList.contains('liquid-gl-active')) {
          destroyLiquidGL();
          applyLiquidGLMode();
        }
      }

      document.addEventListener('click', function(e){
        const card = e.target.closest('.info-card, .home-card, .theme-option, .toggle, .color-input');
        if (!card) return;
        const pane = card.closest('.tab-pane');
        if (pane && !pane.classList.contains('active')) {
          e.stopImmediatePropagation();
          e.stopPropagation();
          e.preventDefault();
        }
      }, true);
      document.addEventListener('mousedown', function(e){
        const card = e.target.closest('.info-card, .home-card');
        if (!card) return;
        const pane = card.closest('.tab-pane');
        if (pane && !pane.classList.contains('active')) {
          e.stopImmediatePropagation();
          e.stopPropagation();
          e.preventDefault();
        }
      }, true);

      tabs.forEach(btn => {
        btn.addEventListener('click', function() {
          setActiveTab(this.dataset.tab);
        });
      });

      const initialActive = document.querySelector('.tab-btn.active');
      measureTabs();
      if (initialActive) updateIndicator(initialActive);

      window.addEventListener('resize', function() {
        measureTabs();
        const active = document.querySelector('.tab-btn.active');
        if (active) updateIndicator(active);
      });

      const themeOptions = document.querySelectorAll('.theme-option');
      const app = document.getElementById('app');
      const settings = loadSettings();
      const customEditor = document.getElementById('customThemeEditor');
      const colorInputs = document.querySelectorAll('.color-input');
      const root = document.documentElement;

      function clearCustomVars() {
        ['--bg-dark','--bg','--bg-light','--text','--text-muted','--primary','--secondary','--border','--border-muted','--danger','--success','--warning'].forEach(function(v) {
          root.style.removeProperty(v);
        });
      }

      function applyCustomTheme(colors) {
        Object.keys(colors).forEach(function(v) {
          root.style.setProperty(v, colors[v]);
        });
      }

      function getCustomColors() {
        var c = {};
        colorInputs.forEach(function(inp) {
          c[inp.dataset.var] = inp.value;
        });
        return c;
      }

      function setTheme(theme) {
        clearCustomVars();
        app.classList.remove('theme-blue', 'theme-purple', 'theme-light');
        root.classList.remove('theme-blue', 'theme-purple', 'theme-light');
        if (theme === 'blue') { app.classList.add('theme-blue'); root.classList.add('theme-blue'); }
        else if (theme === 'purple') { app.classList.add('theme-purple'); root.classList.add('theme-purple'); }
        else if (theme === 'light') { app.classList.add('theme-light'); root.classList.add('theme-light'); }
        else if (theme === 'custom') {
          var saved = settings.customTheme || getCustomColors();
          applyCustomTheme(saved);
          colorInputs.forEach(function(inp) {
            if (saved[inp.dataset.var]) inp.value = saved[inp.dataset.var];
          });
        }
        themeOptions.forEach(opt => {
          opt.classList.toggle('active', opt.dataset.theme === theme);
        });
        customEditor.classList.toggle('visible', theme === 'custom');
        saveSettings('theme', theme);
        syncMonacoTheme();
        if (document.documentElement.classList.contains('liquid-gl-active')) {
          destroyLiquidGL();
          applyLiquidGLMode();
        }
      }

      themeOptions.forEach(opt => {
        opt.addEventListener('click', function(e) {
          const pane = this.closest('.tab-pane');
          if (pane && !pane.classList.contains('active')) { e.stopPropagation(); e.preventDefault(); return; }
          setTheme(this.dataset.theme);
          if (this.dataset.theme !== 'custom') {
            showToast('Theme set to ' + this.dataset.theme, 'info');
          } else {
            showToast('Custom theme active', 'info');
          }
        });
      });

      colorInputs.forEach(function(inp) {
        inp.addEventListener('input', function(e) {
          const pp = this.closest('.tab-pane');
          if (pp && !pp.classList.contains('active')) { e.stopPropagation(); e.preventDefault(); return; }
          var colors = getCustomColors();
          applyCustomTheme(colors);
          settings.customTheme = colors;
          saveSettings('customTheme', colors);
          syncMonacoTheme();
        });
      });

      document.getElementById('exportThemeBtn').addEventListener('click', function() {
        var data = { name: 'Nam Custom Theme', version: 1, colors: getCustomColors() };
        var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'nam-theme.json';
        a.click();
        URL.revokeObjectURL(url);
        showToast('Theme exported', 'success');
      });

      document.getElementById('importThemeBtn').addEventListener('click', function() {
        document.getElementById('importThemeFile').click();
      });

      document.getElementById('importThemeFile').addEventListener('change', function(e) {
        var file = e.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function(ev) {
          try {
            var data = JSON.parse(ev.target.result);
            var colors = data.colors || data;
            applyCustomTheme(colors);
            settings.customTheme = colors;
            saveSettings('customTheme', colors);
            setTheme('custom');
            showToast('Theme imported', 'success');
          } catch(err) {
            showToast('Invalid theme file', 'error');
          }
        };
        reader.readAsText(file);
      });

      if (settings.theme) setTheme(settings.theme);
      else setTheme('black');

      const scriptSearch = document.getElementById('scriptSearch');
      const scriptResults = document.getElementById('scriptResults');
      const paginationEl = document.getElementById('pagination');
      const filterBtn = document.getElementById('filterBtn');
      const filterOverlay = document.getElementById('filterOverlay');
      const filterClose = document.getElementById('filterClose');
      const filterReset = document.getElementById('filterReset');
      const filterApply = document.getElementById('filterApply');
      let currentQuery = '';
      let currentPage = 1;
      let totalPages = 1;
      let searchTimeout;
      let activeFilters = {};

      function getFilterParams() {
        var p = {};
        ['mode','verified','patched','key','universal','sortBy','order','owner','placeId','exclude','max'].forEach(function(k) {
          var cb = document.getElementById('f-cb-' + k);
          if (cb) {
            var hidden = cb.querySelector('input[type="hidden"]');
            if (hidden && hidden.value !== '') p[k] = hidden.value;
          } else {
            var el = document.getElementById('f-' + k);
            if (el && el.value !== '' && el.value !== (k === 'max' ? '20' : '')) p[k] = el.value;
          }
        });
        return p;
      }

      function buildFilterString() {
        var p = getFilterParams();
        var parts = [];
        for (var k in p) {
          parts.push(k + '=' + encodeURIComponent(p[k]));
        }
        return parts.join('&');
      }

      function fetchScripts(query, page) {
        var url = query
          ? 'https://scriptblox.com/api/script/search?q=' + encodeURIComponent(query) + '&page=' + page
          : 'https://scriptblox.com/api/script/fetch?page=' + page;
        var filterStr = buildFilterString();
        if (filterStr) url = (query
          ? 'https://scriptblox.com/api/script/search?q=' + encodeURIComponent(query)
          : 'https://scriptblox.com/api/script/fetch?') + filterStr + '&page=' + page;
        scriptResults.innerHTML = '<div class="script-loading">Loading...</div>';
        fetch(url)
          .then(function(r) { return r.json(); })
          .then(function(data) {
            var result = data.result || data;
            var scripts = result.scripts || [];
            totalPages = result.totalPages || 1;
            renderScripts(scripts);
            renderPagination(page, totalPages);
          })
          .catch(function() {
            scriptResults.innerHTML = '<div class="script-empty">Failed to load scripts.</div>';
          });
      }

      function formatDate(str) {
        if (!str) return '';
        var d = new Date(str);
        var now = new Date();
        var diff = now - d;
        var days = Math.floor(diff / 86400000);
        if (days < 1) return 'today';
        if (days < 7) return days + 'd ago';
        if (days < 30) return Math.floor(days / 7) + 'w ago';
        return Math.floor(days / 30) + 'mo ago';
      }

      function renderScripts(scripts) {
        if (!scripts.length) {
          scriptResults.innerHTML = '<div class="script-empty">No scripts found.</div>';
          return;
        }
        var html = '';
        scripts.forEach(function(s) {
          var img = s.image && !s.image.includes('/images/') ? s.image : (s.game && s.game.imageUrl && !s.game.imageUrl.includes('/images/') ? s.game.imageUrl : '');
          var gameName = s.game ? s.game.name : 'Universal';
          var views = s.views || 0;
          var viewsStr = views > 999 ? (views / 1000).toFixed(1) + 'k' : views;
          var createdAt = formatDate(s.createdAt);
          var tags = '';
          if (s.verified) tags += '<span class="tag tag-verified">Verified</span>';
          if (s.isUniversal) tags += '<span class="tag tag-universal">Universal</span>';
          if (s.key) tags += '<span class="tag tag-key">Key</span>';
          if (s.isPatched) tags += '<span class="tag tag-patched">Patched</span>';
          if (s.scriptType === 'paid') tags += '<span class="tag tag-free">Paid</span>';

          html += '<div class="script-card">';
          html += '<div class="script-card-img-wrap">';
          if (img) {
            html += '<img class="script-card-img" src="' + img + '" alt="" loading="lazy" />';
          } else {
            html += '<div class="script-card-img" style="display:flex;align-items:center;justify-content:center;background:var(--bg-dark);color:var(--text-muted);font-size:0.7rem;height:220px;">No Image</div>';
          }
          if (tags) html += '<div class="script-card-tags">' + tags + '</div>';
          html += '<div class="script-card-img-overlay">';
          html += '<span><i data-lucide="eye" style="width:12px;height:12px;"></i> ' + viewsStr + '</span>';
          if (createdAt) html += '<span><i data-lucide="calendar" style="width:12px;height:12px;"></i> ' + createdAt + '</span>';
          html += '</div>';
          html += '</div>';
          html += '<div class="script-card-body">';
          html += '<div class="script-card-title">' + s.title + '</div>';
          html += '<div class="script-card-game">' + gameName + '</div>';
          html += '</div>';
          html += '<div class="script-card-actions">';
          html += '<button class="script-btn" data-idx="' + scripts.indexOf(s) + '" data-action="play"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="white" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z"/></svg></button>';
          html += '<button class="script-btn" data-idx="' + scripts.indexOf(s) + '" data-action="copy"><i data-lucide="copy" style="width:16px;height:16px;"></i></button>';
          html += '</div>';
          html += '</div>';
        });
        scriptResults.innerHTML = html;
        lucide.createIcons();
        function executeHubScript(code) {
          const tauri = window.__TAURI__?.core;
          if (tauri && tauri.invoke) {
            showToast('Executing...', 'info');
            tauri.invoke('execute', { script: code }).then(function(msg){ showToast(msg || 'Executed', 'success'); }).catch(function(e){ showToast('Execute failed: ' + e, 'error'); });
          } else if (typeof window.execute === 'function') {
            try { window.execute(code); showToast('Executed', 'success'); } catch(e){ showToast('Execute failed: ' + e, 'error'); }
          } else {
            showToast('Executor not connected', 'error');
          }
        }

        // Warning + confirmation before executing any Script Hub script
        let pendingHubCode = '';
        const hubConfirmOverlay = document.getElementById('hubConfirmOverlay');
        const hubConfirmScript = document.getElementById('hubConfirmScript');
        const hubConfirmClose = document.getElementById('hubConfirmClose');
        const hubConfirmCancel = document.getElementById('hubConfirmCancel');
        const hubConfirmExecute = document.getElementById('hubConfirmExecute');

        function openHubConfirm(title, code) {
          pendingHubCode = code;
          if (hubConfirmScript) hubConfirmScript.textContent = title || 'Untitled script';
          if (hubConfirmOverlay) hubConfirmOverlay.classList.add('open');
        }
        function closeHubConfirm() {
          pendingHubCode = '';
          if (hubConfirmOverlay) hubConfirmOverlay.classList.remove('open');
        }
        if (hubConfirmClose) hubConfirmClose.addEventListener('click', closeHubConfirm);
        if (hubConfirmCancel) hubConfirmCancel.addEventListener('click', closeHubConfirm);
        if (hubConfirmExecute) hubConfirmExecute.addEventListener('click', function() {
          if (pendingHubCode) executeHubScript(pendingHubCode);
          closeHubConfirm();
        });
        if (hubConfirmOverlay) hubConfirmOverlay.addEventListener('click', function(e) {
          if (e.target === hubConfirmOverlay) closeHubConfirm();
        });
        document.addEventListener('keydown', function(e) {
          if (e.key === 'Escape' && hubConfirmOverlay && hubConfirmOverlay.classList.contains('open')) closeHubConfirm();
        });

        scriptResults.querySelectorAll('.script-btn[data-action="play"]').forEach(function(btn) {
          btn.addEventListener('click', function() {
            var idx = parseInt(btn.dataset.idx);
            var data = scripts[idx];
            var code = data && data.script ? data.script : '';
            if (!code) { showToast('No script code', 'error'); return; }
            openHubConfirm(data.title || '', code);
          });
        });
        scriptResults.querySelectorAll('.script-btn[data-action="copy"]').forEach(function(btn) {
          btn.addEventListener('click', function() {
            var idx = parseInt(btn.dataset.idx);
            var scriptData = scripts[idx];
            if (scriptData && scriptData.script) {
              navigator.clipboard.writeText(scriptData.script).then(function() {
                showToast('Script copied to clipboard', 'success');
              }).catch(function() {
                showToast('Failed to copy', 'error');
              });
            } else {
              showToast('Script code not available', 'error');
            }
          });
        });
      }

      function renderPagination(page, total) {
        if (total <= 1) { paginationEl.innerHTML = ''; return; }
        var html = '<nav role="navigation" aria-label="pagination"><ul>';
        html += '<li><button class="page-btn" data-page="' + (page - 1) + '"' + (page <= 1 ? ' disabled style="opacity:0.4;cursor:default;"' : '') + '><svg class="lucide lucide-chevron-left" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6" /></svg><span>Previous</span></button></li>';
        var start = Math.max(1, page - 2);
        var end = Math.min(total, page + 2);
        if (start > 1) {
          html += '<li><button class="page-btn" data-page="1">1</button></li>';
          if (start > 2) html += '<li><div class="page-ellipsis"><svg class="lucide lucide-ellipsis" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /><circle cx="5" cy="12" r="1" /></svg></div></li>';
        }
        for (var i = start; i <= end; i++) {
          html += '<li><button class="page-btn' + (i === page ? ' active' : '') + '" data-page="' + i + '">' + i + '</button></li>';
        }
        if (end < total) {
          if (end < total - 1) html += '<li><div class="page-ellipsis"><svg class="lucide lucide-ellipsis" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /><circle cx="5" cy="12" r="1" /></svg></div></li>';
          html += '<li><button class="page-btn" data-page="' + total + '">' + total + '</button></li>';
        }
        html += '<li><button class="page-btn" data-page="' + (page + 1) + '"' + (page >= total ? ' disabled style="opacity:0.4;cursor:default;"' : '') + '><span>Next</span><svg class="lucide lucide-chevron-right" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6" /></svg></button></li>';
        html += '</ul></nav>';
        paginationEl.innerHTML = html;
        paginationEl.querySelectorAll('.page-btn:not([disabled])').forEach(function(btn) {
          btn.addEventListener('click', function() {
            var p = parseInt(this.dataset.page);
            if (p && p !== currentPage) {
              currentPage = p;
              fetchScripts(currentQuery, currentPage);
            }
          });
        });
      }

      filterBtn.addEventListener('click', function() {
        filterOverlay.classList.add('open');
      });
      filterClose.addEventListener('click', function() {
        filterOverlay.classList.remove('open');
      });
      filterOverlay.addEventListener('click', function(e) {
        if (e.target === filterOverlay) filterOverlay.classList.remove('open');
      });
      filterReset.addEventListener('click', function() {
        filterOverlay.querySelectorAll('input').forEach(function(el) {
          if (el.id === 'f-max') el.value = '20';
          else if (el.id === 'f-page') el.value = '1';
          else if (!el.closest('.combobox') && el.type !== 'hidden') el.value = '';
        });
        filterOverlay.querySelectorAll('.combobox').forEach(function(cb) {
          var inp = cb.querySelector('input[role="combobox"]');
          var hidden = cb.querySelector('input[type="hidden"]');
          if (inp) inp.value = '';
          if (hidden) hidden.value = '';
        });
      });
      filterApply.addEventListener('click', function() {
        filterOverlay.classList.remove('open');
        activeFilters = getFilterParams();
        filterBtn.classList.toggle('active', Object.keys(activeFilters).length > 0);
        currentPage = 1;
        fetchScripts(currentQuery, currentPage);
      });

      document.querySelectorAll('.combobox').forEach(function(cb) {
        var inp = cb.querySelector('input[role="combobox"]');
        var popover = cb.querySelector('[data-popover]');
        var listbox = popover ? popover.querySelector('[role="listbox"]') : null;
        var hidden = cb.querySelector('input[type="hidden"]');
        inp.addEventListener('click', function(e) {
          e.stopPropagation();
          var open = popover.getAttribute('aria-hidden') === 'false';
          document.querySelectorAll('.combobox [data-popover]').forEach(function(p) { p.setAttribute('aria-hidden', 'true'); });
          if (!open) popover.setAttribute('aria-hidden', 'false');
        });
        if (listbox) {
          listbox.querySelectorAll('[role="option"]').forEach(function(opt) {
            opt.addEventListener('click', function() {
              inp.value = this.textContent;
              if (hidden) hidden.value = this.dataset.value;
              popover.setAttribute('aria-hidden', 'true');
            });
          });
        }
      });
      document.addEventListener('click', function() {
        document.querySelectorAll('.combobox [data-popover]').forEach(function(p) { p.setAttribute('aria-hidden', 'true'); });
      });

      scriptSearch.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(function() {
          currentQuery = scriptSearch.value.trim();
          currentPage = 1;
          fetchScripts(currentQuery, currentPage);
        }, 400);
      });

      document.querySelectorAll('.home-card').forEach(function(card) {
        card.addEventListener('click', function() {
          var title = this.querySelector('h4').textContent;
          if (title === 'Inject') {
            doInject();
          } else if (title === 'Open Editor') {
            setActiveTab('code');
            showToast('Opening editor...', 'info');
          } else if (title === 'Script Hub') {
            setActiveTab('globe');
            if (!scriptsLoaded) { scriptsLoaded = true; fetchScripts('', 1); }
            showToast('Loading Script Hub...', 'info');
          } else if (title === 'New Tab') {
            setActiveTab('code');
            showToast('New tab created', 'success');
          }
        });
      });

      let scriptsLoaded = false;
      document.querySelectorAll('.tab-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
          if (btn.dataset.tab === 'globe' && !scriptsLoaded) {
            scriptsLoaded = true;
            fetchScripts('', 1);
          }
        });
      });

      const sidebarBtns = document.querySelectorAll('.settings-sidebar button');
      const groups = {
        appearance: document.getElementById('section-appearance'),
        loader: document.getElementById('section-loader'),
        window: document.getElementById('section-window'),
        editor: document.getElementById('section-editor'),
        behavior: document.getElementById('section-behavior'),
        mcp: document.getElementById('section-mcp')
      };

      sidebarBtns.forEach(btn => {
        btn.addEventListener('click', function() {
          sidebarBtns.forEach(b => b.classList.remove('active'));
          this.classList.add('active');
          const section = this.dataset.section;
          saveSettings('settingsSection', section);
          Object.keys(groups).forEach(key => {
            groups[key].classList.toggle('active', key === section);
          });
        });
      });

      if (settings.settingsSection && groups[settings.settingsSection]) {
        sidebarBtns.forEach(b => b.classList.remove('active'));
        const target = document.querySelector(`.settings-sidebar button[data-section="${settings.settingsSection}"]`);
        if (target) target.classList.add('active');
        Object.keys(groups).forEach(key => {
          groups[key].classList.toggle('active', key === settings.settingsSection);
        });
      }


      const aotToggle = document.getElementById('alwaysOnTopToggle');
      if (aotToggle) {
        aotToggle.addEventListener('click', async function(e) {
          e.stopImmediatePropagation();
          this.classList.toggle('on');
          const on = this.classList.contains('on');
          const invoke = window.__TAURI__?.core?.invoke;
          if (invoke) {
            try { await invoke('set_topmost', { enabled: on }); showToast(on ? 'Always on top enabled' : 'Always on top disabled', 'info'); } catch(err) { showToast('Failed: ' + err, 'error'); this.classList.toggle('on'); }
          }
        });
        aotToggle.classList.remove('on');
        try { window.__TAURI__?.core?.invoke('set_topmost', { enabled: false }); } catch(e) {}
      }

      const liquidBg = document.getElementById('liquidBg');
      const bgUrlInput = document.getElementById('bgUrlInput');
      const bgBrowseBtn = document.getElementById('bgBrowseBtn');
      const bgFileInput = document.getElementById('bgFileInput');
      const bgPreview = document.getElementById('bgPreview');
      const blurSlider = document.getElementById('blurSlider');
      const blurValue = document.getElementById('blurValue');
      const bgToggle = document.getElementById('bgImageToggle');
      const distortionSlider = document.getElementById('distortionSlider');
      const distortionValue = document.getElementById('distortionValue');
      const distortionMap = document.querySelector('#glass-distortion feDisplacementMap');

      setTimeout(updateBgImage, 0);

      function applyLiquidGlass() {
        const on = document.getElementById('liquidGlassToggle').classList.contains('on');
        app.classList.toggle('liquid-glass-enabled', on);
        document.documentElement.classList.toggle('liquid-glass-enabled', on);
        document.getElementById('distortionCard').style.display = on ? '' : 'none';
      }

      function destroyLiquidGL() {
        const renderer = window.__liquidGLRenderer__;
        if (!renderer) return;
        try { if (renderer._rafId) cancelAnimationFrame(renderer._rafId); } catch(e) {}
        (renderer.lenses || []).forEach(function(lens) {
          try {
            if (lens._sizeObs) { lens._sizeObs.disconnect(); lens._sizeObs = null; }
            if (lens._tiltHandlersBound && lens._unbindTiltHandlers) lens._unbindTiltHandlers();
            if (lens._destroyMirrorCanvas) lens._destroyMirrorCanvas();
            if (lens._shadowEl) { lens._shadowEl.remove(); lens._shadowEl = null; }
            const el = lens.el;
            if (el) {
              el.style.opacity = lens.originalOpacity || '';
              el.style.transition = lens.originalTransition || '';
              el.style.boxShadow = lens.originalShadow || '';
              ['background', 'background-color', 'background-image', 'backdrop-filter',
               '-webkit-backdrop-filter', 'pointer-events', 'transform', 'transform-style'
              ].forEach(function(p) { el.style.removeProperty(p); });
            }
          } catch (err) { console.error('liquidGL teardown', err); }
        });
        renderer.lenses = [];
        try { if (renderer.canvas && renderer.canvas.parentNode) renderer.canvas.parentNode.removeChild(renderer.canvas); } catch(e) {}
        try { delete window.__liquidGLRenderer__; } catch(e) { window.__liquidGLRenderer__ = undefined; }
      }

      function applyLiquidGLMode() {
        const on = document.getElementById('liquidGLToggle').classList.contains('on');
        document.documentElement.classList.toggle('liquid-gl-active', on);
        app.classList.toggle('liquid-gl-active', on);
        if (on) {
          if (!window.liquidGL) {
            showToast('LiquidGL library failed to load', 'error');
            return;
          }
          try {
            const frostVal = (parseFloat(blurSlider.value) || 0) / 4;
            window.liquidGL({
              target: '.tab-pane.active .info-card, .tab-pane.active .home-card',
              snapshot: '.liquid-bg',
              resolution: 1.5,
              refraction: 0,
              aberration: 0.25,
              bevelDepth: 0.1,
              bevelWidth: 0.25,
              frost: frostVal,
              magnify: 1,
              shadow: true,
              specular: true,
              reveal: 'fade',
              tilt: false
            });
          } catch (err) {
            console.error('liquidGL init failed', err);
            showToast('Liquid Glass not supported (WebGL unavailable)', 'error');
            document.getElementById('liquidGLToggle').classList.remove('on');
            saveSettings('liquidGLToggle', false);
            destroyLiquidGL();
            document.documentElement.classList.remove('liquid-gl-active');
            app.classList.remove('liquid-gl-active');
          }
        } else {
          destroyLiquidGL();
        }
      }

      let lgScrollRaf = null;
      document.addEventListener('scroll', function() {
        if (!document.documentElement.classList.contains('liquid-gl-active')) return;
        if (lgScrollRaf) return;
        lgScrollRaf = requestAnimationFrame(function() {
          lgScrollRaf = null;
          const renderer = window.__liquidGLRenderer__;
          if (renderer && renderer.lenses) {
            renderer.lenses.forEach(function(ln) { ln.updateMetrics(); });
          }
        });
      }, true);

      function applyDistortion() {
        const on = document.getElementById('distortionToggle').classList.contains('on');
        document.documentElement.classList.toggle('distorted', on);
      }

      const BG_PROXY_WESERV = 'https://images.weserv.nl/?url=';
      const BG_PROXY_CORS = 'https://corsproxy.io/?';
      const BG_PROXY_ALLO = 'https://api.allorigins.win/raw?url=';
      let _currentBgBlobUrl = null;
      let _currentBgType = 'image';
      const bgBlobCache = {};
      function bgBlobLive(url) {
        if (!url || url.indexOf('blob:') !== 0) return false;
        if (Object.keys(bgBlobCache).some(function(k) { return bgBlobCache[k] === url; })) return true;
        return getBgHistory().some(function(h) { return h.src === url; });
      }
      function forgetBgBlob(url) {
        if (url && !bgBlobLive(url)) { try { URL.revokeObjectURL(url); } catch (e) {} }
      }
      function getBgHistory() {
        try { return JSON.parse(localStorage.getItem('nam-bg-history') || '[]') || []; }
        catch (e) { return []; }
      }
      function setBgHistory(list) {
        try { localStorage.setItem('nam-bg-history', JSON.stringify(list)); return true; }
        catch (e) {
          for (let i = 0; i < 5; i++) {
            list.pop();
            try { localStorage.setItem('nam-bg-history', JSON.stringify(list)); return true; }
            catch (err) {}
          }
          return false;
        }
      }
      function bgCurrentSrc() {
        const v = (bgUrlInput.value || '').trim();
        if (bgUrlInput.dataset.blobUrl && bgUrlInput.dataset.fileName === v) return bgUrlInput.dataset.blobUrl;
        return v;
      }
      function pushBgHistory(entry) {
        const list = getBgHistory().filter(function(x) { return x.src !== entry.src; });
        list.unshift(entry);
        while (list.length > 6) list.pop();
        setBgHistory(list);
        renderBgHistory();
      }
      function renderBgHistory() {
        const box = document.getElementById('bgHistory');
        const clr = document.getElementById('bgClearBtn');
        if (!box) return;
        const list = getBgHistory();
        const cur = bgToggle.classList.contains('on') ? bgCurrentSrc() : '';
        box.innerHTML = '';
        list.forEach(function(h) {
          const d = document.createElement('div');
          d.className = 'bg-thumb' + (h.type === 'video' ? ' is-video' : '') + (h.unavail ? ' unavail' : '') + ((cur && (h.src === cur || (h.fileName && h.fileName === bgUrlInput.value.trim()))) ? ' active' : '');
          d.title = h.fileName || h.src;
          if (h.thumb) d.style.backgroundImage = cssUrl(h.thumb);
          else if (h.type !== 'video') d.style.backgroundImage = cssUrl(h.src);
          d.addEventListener('click', function() { applyBgHistory(h); });
          box.appendChild(d);
        });
        if (clr) clr.style.display = list.length ? '' : 'none';
      }
      function applyBgHistory(h) {
        if (!h || !h.src) return;
        if (h.type === 'video') {
          let src = h.src;
          if (src.indexOf('blob:') === 0) {
            src = bgBlobCache[h.fileName] || '';
            if (!src) {
              showToast('Video file no longer available — pick it again', 'warning');
              return;
            }
          }
          bgUrlInput.value = h.fileName || src;
          bgUrlInput.dataset.fileName = h.fileName || '';
          bgUrlInput.dataset.blobUrl = src;
          if (src.indexOf('blob:') === 0) _currentBgBlobUrl = src;
          _currentBgType = 'video';
          saveSettings('bgUrl', bgUrlInput.value);
          saveSettings('bgType', 'video');
          ensureBgVideo(src);
          showToast('Background applied', 'success');
        } else {
          bgUrlInput.value = h.fileName || h.src;
          bgUrlInput.dataset.fileName = h.fileName || '';
          bgUrlInput.dataset.blobUrl = (h.src.indexOf('data:') === 0 || h.src.indexOf('blob:') === 0) ? h.src : '';
          if (h.src.indexOf('data:') === 0) {
            _currentBgBlobUrl = h.src;
            saveSettings('bgDataUrl', h.src);
          }
          _currentBgType = 'image';
          saveSettings('bgUrl', bgUrlInput.value);
          saveSettings('bgType', 'image');
          updateBgImage();
          showToast('Background applied', 'success');
        }
        if (!bgToggle.classList.contains('on')) { bgToggle.classList.add('on'); saveSettings('bgImageToggle', true); }
        pushBgHistory(h);
      }
      let _bgUpdateId = 0;
      function isDataOrBlobUrl(u) { return /^data:|^blob:/i.test(u); }
      function isVideoFile(file) {
        if (!file) return false;
        if (file.type && file.type.startsWith('video/')) return true;
        const name = file.name || '';
        return /\.(mp4|webm|ogg|mov)$/i.test(name);
      }
      function isVideoUrl(url) {
        if (!url) return false;
        const clean = url.split('?')[0].split('#')[0];
        return /\.(mp4|webm|ogg|mov)$/i.test(clean);
      }
      function cssUrl(url) {
        return 'url("' + url.replace(/"/g, '\\"') + '")';
      }
      function refreshLiquidGlassSnapshot() {
        if (document.documentElement.classList.contains('liquid-gl-active')) {
          destroyLiquidGL();
          applyLiquidGLMode();
        }
      }
      function preloadCORS(url, timeoutMs) {
        timeoutMs = timeoutMs || 3000;
        return new Promise(function(resolve) {
          let done = false;
          function finish(ok) { if (!done) { done = true; resolve(ok); } }
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = function() { finish(true); };
          img.onerror = function() { finish(false); };
          img.src = url;
          if (isDataOrBlobUrl(url)) {
            setTimeout(function(){ if (img.complete && img.naturalWidth) finish(true); }, 50);
          }
          setTimeout(function(){ finish(false); }, timeoutMs);
        });
      }
      async function resolveBestUrl(rawUrl) {
        if (isDataOrBlobUrl(rawUrl)) return rawUrl;
        const rawOk = await preloadCORS(rawUrl, 2800);
        if (rawOk) return rawUrl;
        const weservUrl = BG_PROXY_WESERV + encodeURIComponent(rawUrl);
        const wesOk = await preloadCORS(weservUrl, 3200);
        if (wesOk) return weservUrl;
        const corsUrl = BG_PROXY_CORS + encodeURIComponent(rawUrl);
        const corsOk = await preloadCORS(corsUrl, 3200);
        if (corsOk) return corsUrl;
        const alloUrl = BG_PROXY_ALLO + encodeURIComponent(rawUrl);
        const alloOk = await preloadCORS(alloUrl, 3200);
        if (alloOk) return alloUrl;
        return rawUrl;
      }
      function clearBgVideo() {
        const v = document.getElementById('bgVideo');
        if (v) v.remove();
      }
      function ensureBgVideo(src) {
        clearBgVideo();
        liquidBg.style.backgroundImage = '';
        const vid = document.createElement('video');
        vid.id = 'bgVideo';
        vid.autoplay = true;
        vid.loop = true;
        vid.muted = true;
        vid.playsInline = true;
        vid.preload = 'auto';
        vid.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:center;';
        if (/^https?:/.test(src)) vid.crossOrigin = 'anonymous';
        vid.src = src;
        liquidBg.appendChild(vid);
        liquidBg.classList.add('has-image');
        liquidBg.classList.remove('no-image');
        bgPreview.style.backgroundImage = '';
        bgPreview.classList.remove('visible');
        vid.addEventListener('loadeddata', function() {
          try {
            const c = document.createElement('canvas');
            c.width = 160; c.height = 90;
            const ctx = c.getContext('2d');
            ctx.drawImage(vid, 0, 0, c.width, c.height);
            bgPreview.style.backgroundImage = 'url("' + c.toDataURL() + '")';
            bgPreview.classList.add('visible');
          } catch(e) {}
        });
        if (document.documentElement.classList.contains('liquid-gl-active')) {
          setTimeout(refreshLiquidGlassSnapshot, 300);
          setTimeout(refreshLiquidGlassSnapshot, 900);
        }
        return vid;
      }

      async function updateBgImage() {
        const on = bgToggle.classList.contains('on');
        let rawUrl = bgUrlInput.value.trim();
        if (bgUrlInput.dataset.blobUrl && bgUrlInput.dataset.fileName === rawUrl) {
          rawUrl = bgUrlInput.dataset.blobUrl;
        } else if (_currentBgBlobUrl && rawUrl === (bgUrlInput.dataset.fileName || '')) {
          rawUrl = _currentBgBlobUrl;
        } else if (rawUrl && !/^data:|^blob:|^https?:|^file:/i.test(rawUrl) && !/\//.test(rawUrl)) {
          try {
            const stored = JSON.parse(localStorage.getItem('nam-settings') || '{}');
            if (stored.bgDataUrl && stored.bgFileName === rawUrl) rawUrl = stored.bgDataUrl;
          } catch(e) {}
        }
        const curId = ++_bgUpdateId;
        if (on && rawUrl) {
          const treatAsVideo = isVideoUrl(rawUrl) || (_currentBgType === 'video' && (rawUrl.startsWith('blob:') || rawUrl.startsWith('data:video'))) || (rawUrl.startsWith('blob:') && _currentBgType === 'video');
          const isNetVideo = /^https?:/i.test(rawUrl) && isVideoUrl(rawUrl);
          if (treatAsVideo || isNetVideo) {
            let videoSrc = rawUrl;
            const vid = ensureBgVideo(videoSrc);
            vid.onloadedmetadata = function() {
              if (vid.duration && vid.duration > 30) {
                showToast('Video must be <=30s (got ' + vid.duration.toFixed(1) + 's)', 'error');
                clearBgVideo();
                bgUrlInput.value = '';
                bgUrlInput.dataset.fileName = '';
                bgUrlInput.dataset.blobUrl = '';
                saveSettings('bgUrl', '');
                refreshLiquidGlassSnapshot();
              }
            };
            vid.onerror = function() {
              if (/^https?:/.test(videoSrc) && !videoSrc.includes('images.weserv.nl')) {
                showToast('Failed to load video link', 'error');
              }
            };
            return;
          }
          let safeUrl = rawUrl;
          if (/^https?:\/\//i.test(rawUrl) && !isDataOrBlobUrl(rawUrl)) {
            safeUrl = await resolveBestUrl(rawUrl);
            if (curId !== _bgUpdateId) return;
            if (safeUrl !== rawUrl) {
            }
          }
          clearBgVideo();
          liquidBg.style.backgroundImage = cssUrl(safeUrl);
          liquidBg.classList.add('has-image');
          liquidBg.classList.remove('no-image');
          bgPreview.style.backgroundImage = cssUrl(safeUrl);
          bgPreview.classList.add('visible');
          if (document.documentElement.classList.contains('liquid-gl-active')) {
            refreshLiquidGlassSnapshot();
            if (!isDataOrBlobUrl(safeUrl)) setTimeout(refreshLiquidGlassSnapshot, 650);
          }
        } else if (on) {
          clearBgVideo();
          liquidBg.classList.add('no-image');
          liquidBg.classList.remove('has-image');
          liquidBg.style.backgroundImage = '';
          bgPreview.classList.remove('visible');
          refreshLiquidGlassSnapshot();
        } else {
          clearBgVideo();
          liquidBg.style.backgroundImage = '';
          liquidBg.classList.remove('has-image', 'no-image');
          bgPreview.classList.remove('visible');
          refreshLiquidGlassSnapshot();
        }
      }

      const DEFAULT_FONT_SIZE = 14;
      const DEFAULT_TAB_SIZE = 4;
      const DEFAULT_MINIMAP = true;
      const DEFAULT_WORDWRAP = false;
      function getEditorSettingsPayload() {
        var fsEl = document.getElementById('fontSizeSlider');
        var tsEl = document.getElementById('tabSizeSlider');
        var mmEl = document.getElementById('minimapToggle');
        var wwEl = document.getElementById('wordWrapToggle');
        return {
          fontSize: fsEl ? parseInt(fsEl.value, 10) : (settings.fontSize !== undefined ? settings.fontSize : DEFAULT_FONT_SIZE),
          tabSize: tsEl ? parseInt(tsEl.value, 10) : (settings.tabSize !== undefined ? settings.tabSize : DEFAULT_TAB_SIZE),
          minimap: mmEl ? mmEl.classList.contains('on') : (settings.minimap !== undefined ? settings.minimap : DEFAULT_MINIMAP),
          wordWrap: wwEl ? wwEl.classList.contains('on') : (settings.wordWrap !== undefined ? settings.wordWrap : DEFAULT_WORDWRAP)
        };
      }
      function syncMonacoEditorSettings() {
        try {
          var payload = getEditorSettingsPayload();
          if (typeof monacoCall === 'function') { monacoCall('editorSettings', payload).catch(function(){}); }
        } catch(e) {}
      }

      document.querySelectorAll('.toggle').forEach(toggle => {
        toggle.addEventListener('click', function(e) {
          const p = this.closest('.tab-pane');
          if (p && !p.classList.contains('active')) { e.stopPropagation(); e.preventDefault(); return; }
          if (this.id === 'alwaysOnTopToggle') return;
          this.classList.toggle('on');
          const on = this.classList.contains('on');
          if (this.id && this.id !== 'minimapToggle' && this.id !== 'wordWrapToggle') saveSettings(this.id, on);
          if (this.id === 'liquidGlassToggle') {
            if (on) {
              const lgToggle = document.getElementById('liquidGLToggle');
              if (lgToggle && lgToggle.classList.contains('on')) {
                lgToggle.classList.remove('on');
                saveSettings('liquidGLToggle', false);
                applyLiquidGLMode();
                showToast('Liquid Glass turned off — Glassmorphism enabled', 'info');
              }
            }
            applyLiquidGlass();
            syncMonacoTheme();
            showToast(on ? 'Glassmorphism enabled' : 'Glassmorphism disabled', 'success');
          }
          if (this.id === 'liquidGLToggle') {
            if (on) {
              const glassToggle = document.getElementById('liquidGlassToggle');
              if (glassToggle && glassToggle.classList.contains('on')) {
                glassToggle.classList.remove('on');
                saveSettings('liquidGlassToggle', false);
                applyLiquidGlass();
                syncMonacoTheme();
                showToast('Glassmorphism turned off — Liquid Glass enabled', 'info');
              }
            }
            applyLiquidGLMode();
            showToast(on ? 'Liquid Glass enabled' : 'Liquid Glass disabled', 'success');
          }
          if (this.id === 'distortionToggle') {
            applyDistortion();
            showToast(on ? 'Distortion enabled' : 'Distortion disabled', 'info');
          }
          if (this.id === 'bgImageToggle') {
            updateBgImage();
            renderBgHistory();
            showToast(on ? 'Background image enabled' : 'Background image disabled', 'info');
          }
          if (this.id === 'autoInjectToggle') {
            showToast(on ? 'Auto-Inject on launch enabled' : 'Auto-Inject on launch disabled', 'info');
            if (on) doInject();
          }
          if (this.id === 'minimapToggle') {
            saveSettings('minimap', on);
            settings.minimap = on;
            syncMonacoEditorSettings();
            showToast(on ? 'Minimap enabled' : 'Minimap disabled', 'info');
          }
          if (this.id === 'wordWrapToggle') {
            saveSettings('wordWrap', on);
            settings.wordWrap = on;
            syncMonacoEditorSettings();
            showToast(on ? 'Word wrap enabled' : 'Word wrap disabled', 'info');
          }
        });
      });

      if (settings.liquidGlassToggle) {
        document.getElementById('liquidGlassToggle').classList.add('on');
        applyLiquidGlass();
      }
      if (settings.liquidGLToggle && !settings.liquidGlassToggle) {
        document.getElementById('liquidGLToggle').classList.add('on');
        applyLiquidGLMode();
      }
      if (settings.autoInjectToggle) {
        document.getElementById('autoInjectToggle').classList.add('on');
        setTimeout(doInject, 800);
      }
      refreshInjectStatus();
      if (settings.distortionToggle) {
        document.getElementById('distortionToggle').classList.add('on');
        applyDistortion();
      }
      if (settings.bgImageToggle) {
        document.getElementById('bgImageToggle').classList.add('on');
      }

      bgUrlInput.addEventListener('input', function() {
        if (this.value !== this.dataset.fileName) {
          this.dataset.fileName = '';
          this.dataset.blobUrl = '';
          _currentBgType = /^https?:.*\.(mp4|webm|ogg|mov)(\?|$)/i.test(this.value) ? 'video' : 'image';
          if (_currentBgBlobUrl && _currentBgBlobUrl.startsWith('blob:')) { forgetBgBlob(_currentBgBlobUrl); _currentBgBlobUrl = null; }
        }
        saveSettings('bgUrl', this.value);
        if (/^https?:/i.test(this.value)) { saveSettings('bgDataUrl', ''); saveSettings('bgType', _currentBgType); }
        updateBgImage();
      });
      if (settings.bgUrl) {
        bgUrlInput.value = settings.bgUrl;
        if (settings.bgFileName) bgUrlInput.dataset.fileName = settings.bgFileName;
        if (settings.bgActualSrc) bgUrlInput.dataset.blobUrl = settings.bgActualSrc;
        if (settings.bgType) _currentBgType = settings.bgType;
        if (settings.bgDataUrl && settings.bgType === 'image') {
          bgUrlInput.dataset.blobUrl = settings.bgDataUrl;
          _currentBgBlobUrl = settings.bgDataUrl;
        }
      }

      bgBrowseBtn.addEventListener('click', function() {
        bgFileInput.click();
      });
      bgUrlInput.addEventListener('change', function() {
        const v = (this.value || '').trim();
        if (/^https?:\/\/.+/i.test(v)) {
          pushBgHistory({ src: v, fileName: '', type: isVideoUrl(v) ? 'video' : 'image', thumb: isVideoUrl(v) ? '' : v });
        }
      });

      bgFileInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;
        const fileName = file.name || 'upload';
        const isVideo = isVideoFile(file);
        if (_currentBgBlobUrl) { forgetBgBlob(_currentBgBlobUrl); _currentBgBlobUrl = null; }
        bgUrlInput.value = fileName;
        bgUrlInput.dataset.fileName = fileName;
        bgUrlInput.dataset.blobUrl = '';
        saveSettings('bgFileName', fileName);
        const blobUrl = URL.createObjectURL(file);
        _currentBgBlobUrl = blobUrl;
        bgUrlInput.dataset.blobUrl = blobUrl;
        _currentBgType = isVideo ? 'video' : 'image';
        saveSettings('bgType', _currentBgType);
        if (isVideo) {
          const probe = document.createElement('video');
          probe.preload = 'metadata';
          probe.src = blobUrl;
          probe.onloadedmetadata = function() {
            const dur = probe.duration;
            if (dur && dur > 30) {
              showToast('Video must be <=30s (got ' + dur.toFixed(1) + 's)', 'error');
              URL.revokeObjectURL(blobUrl);
              _currentBgBlobUrl = null;
              bgUrlInput.value = '';
              bgUrlInput.dataset.fileName = '';
              bgUrlInput.dataset.blobUrl = '';
              saveSettings('bgUrl', '');
              clearBgVideo();
              refreshLiquidGlassSnapshot();
              return;
            }
            saveSettings('bgUrl', fileName);
            saveSettings('bgActualSrc', blobUrl);
            bgBlobCache[fileName] = blobUrl;
            pushBgHistory({ src: blobUrl, fileName: fileName, type: 'video', thumb: '' });
            ensureBgVideo(blobUrl);
            showToast('Video background loaded (' + fileName + ')', 'success');
            if (!bgToggle.classList.contains('on')) { bgToggle.classList.add('on'); saveSettings('bgImageToggle', true); }
          };
          probe.onerror = function() { showToast('Failed to load video metadata', 'error'); URL.revokeObjectURL(blobUrl); };
        } else {
          clearBgVideo();
          liquidBg.style.backgroundImage = cssUrl(blobUrl);
          liquidBg.classList.add('has-image');
          liquidBg.classList.remove('no-image');
          bgPreview.style.backgroundImage = cssUrl(blobUrl);
          bgPreview.classList.add('visible');
          saveSettings('bgUrl', fileName);
          saveSettings('bgActualSrc', blobUrl);
          const reader = new FileReader();
          reader.onload = function(ev) {
            saveSettings('bgDataUrl', ev.target.result);
            pushBgHistory({ src: ev.target.result, fileName: fileName, type: 'image', thumb: ev.target.result });
          };
          reader.readAsDataURL(file);
          showToast('Background ' + (file.type === 'image/gif' ? 'GIF' : 'image') + ' loaded (' + fileName + ')', 'success');
          if (!bgToggle.classList.contains('on')) { bgToggle.classList.add('on'); saveSettings('bgImageToggle', true); }
          refreshLiquidGlassSnapshot();
          setTimeout(refreshLiquidGlassSnapshot, 600);
        }
        e.target.value = '';
      });

      function applyBlur(val) {
        blurValue.textContent = val;
        liquidBg.style.setProperty('--bg-blur', val + 'px');
        const renderer = window.__liquidGLRenderer__;
        if (renderer && renderer.lenses) {
          renderer.lenses.forEach(function(ln) { ln.options.frost = val / 4; });
        }
      }
      blurSlider.addEventListener('input', function() {
        saveSettings('blur', this.value);
        applyBlur(this.value);
      });
      if (settings.blur !== undefined) {
        blurSlider.value = settings.blur;
      }
      applyBlur(blurSlider.value);

      function applyDistortionIntensity(val) {
        distortionValue.textContent = val;
        distortionMap.setAttribute('scale', val);
      }
      distortionSlider.addEventListener('input', function() {
        saveSettings('distortionIntensity', this.value);
        applyDistortionIntensity(this.value);
      });
      if (settings.distortionIntensity !== undefined) {
        distortionSlider.value = settings.distortionIntensity;
      }
      applyDistortionIntensity(distortionSlider.value);
      (function initEditorSettings(){
        var fontSlider = document.getElementById('fontSizeSlider');
        var fontVal = document.getElementById('fontSizeValue');
        var tabSlider = document.getElementById('tabSizeSlider');
        var tabVal = document.getElementById('tabSizeValue');
        var miniToggle = document.getElementById('minimapToggle');
        var wrapToggle = document.getElementById('wordWrapToggle');
        var restoreFontBtn = document.getElementById('restoreFontBtn');
        var restoreTabBtn = document.getElementById('restoreTabBtn');

        if (miniToggle) {
          var miniInit = settings.minimap !== undefined ? !!settings.minimap : DEFAULT_MINIMAP;
          miniToggle.classList.toggle('on', miniInit);
        }
        if (wrapToggle) {
          var wrapInit = settings.wordWrap !== undefined ? !!settings.wordWrap : DEFAULT_WORDWRAP;
          wrapToggle.classList.toggle('on', wrapInit);
        }

        function updateFontLabel(v){ if(fontVal) fontVal.textContent = v; }
        function updateTabLabel(v){ if(tabVal) tabVal.textContent = v; }

        if (fontSlider) {
          var initFont = settings.fontSize !== undefined ? settings.fontSize : DEFAULT_FONT_SIZE;
          fontSlider.value = initFont;
          updateFontLabel(initFont);
          fontSlider.addEventListener('input', function(){
            var v = parseInt(this.value,10);
            updateFontLabel(v);
            saveSettings('fontSize', v);
            settings.fontSize = v;
            syncMonacoEditorSettings();
          });
          fontSlider.addEventListener('change', function(){
            showToast('Font size: ' + this.value + 'px', 'info');
          });
        }
        if (tabSlider) {
          var initTab = settings.tabSize !== undefined ? settings.tabSize : DEFAULT_TAB_SIZE;
          tabSlider.value = initTab;
          updateTabLabel(initTab);
          tabSlider.addEventListener('input', function(){
            var v = parseInt(this.value,10);
            updateTabLabel(v);
            saveSettings('tabSize', v);
            settings.tabSize = v;
            syncMonacoEditorSettings();
          });
          tabSlider.addEventListener('change', function(){
            showToast('Tab size: ' + this.value + ' spaces', 'info');
          });
        }
        if (restoreFontBtn) {
          restoreFontBtn.addEventListener('click', function(){
            if (!fontSlider) return;
            var df = DEFAULT_FONT_SIZE;
            fontSlider.value = df;
            updateFontLabel(df);
            saveSettings('fontSize', df);
            settings.fontSize = df;
            syncMonacoEditorSettings();
            showToast('Font size restored to default (' + df + 'px)', 'success');
          });
        }
        if (restoreTabBtn) {
          restoreTabBtn.addEventListener('click', function(){
            if (!tabSlider) return;
            var dt = DEFAULT_TAB_SIZE;
            tabSlider.value = dt;
            updateTabLabel(dt);
            saveSettings('tabSize', dt);
            settings.tabSize = dt;
            syncMonacoEditorSettings();
            showToast('Tab size restored to default (' + dt + ' spaces)', 'success');
          });
        }
      })();

      updateBgImage();
      renderBgHistory();
      const bgClearBtn = document.getElementById('bgClearBtn');
      if (bgClearBtn) bgClearBtn.addEventListener('click', function() {
        setBgHistory([]);
        try { localStorage.removeItem('nam-bg-history'); } catch (e) {}
        renderBgHistory();
        showToast('Background history cleared', 'info');
      });

      // Loader settings
      const dlUrlInput = document.getElementById('dlUrlInput');
      const saveDlBtn = document.getElementById('saveDlBtn');
      const currentVersionEl = document.getElementById('currentVersion');
      const remoteVersionEl = document.getElementById('remoteVersion');
      const checkUpdateBtn = document.getElementById('checkUpdateBtn');

      if (settings.dlUrl) {
        dlUrlInput.value = settings.dlUrl;
      }

      saveDlBtn.addEventListener('click', function() {
        const url = dlUrlInput.value.trim();
        if (!url) {
          showToast('Please enter a download URL', 'error');
          return;
        }
        saveSettings('dlUrl', url);
        showToast('Download URL saved!', 'success');
        checkVersion();
      });

      function checkVersion() {
        currentVersionEl.textContent = 'Checking...';
        remoteVersionEl.textContent = 'Checking...';
        
        let storedVer = null;
        try { storedVer = localStorage.getItem('nam-version'); } catch (e) { storedVer = null; }
        if (storedVer) {
          currentVersionEl.textContent = storedVer;
        } else {
          currentVersionEl.textContent = 'Not installed';
        }

        fetch('https://systa.getnam.xyz/ver.json')
          .then(r => r.json())
          .then(data => {
            if (data.ver) {
              remoteVersionEl.textContent = data.ver;
              if (storedVer && storedVer !== data.ver) {
                showToast('New version available! ' + storedVer + ' → ' + data.ver, 'warning');
              }
            } else {
              remoteVersionEl.textContent = 'Error';
            }
          })
          .catch(() => {
            remoteVersionEl.textContent = 'Failed to fetch';
          });
      }

      checkUpdateBtn.addEventListener('click', function() {
        checkVersion();
        showToast('Checking for updates...', 'info');
      });

      checkVersion();

      const monacoFrame = document.getElementById('monacoFrame');
      const openScriptFile = document.getElementById('openScriptFile');
      let monacoSeq = 0;
      const monacoWait = {};
      let monacoReady = false;

      function monacoSrc() {
        const q = new URLSearchParams();
        const theme = settings.theme || 'black';
        q.set('theme', theme);
        if (settings.liquidGlassToggle) q.set('isglassmorphism', '1');
        if (theme === 'custom') q.set('customtheme', JSON.stringify(settings.customTheme || {}));
        q.set('renderLineHighlight', 'none');
        q.set('fontSize', String(settings.fontSize !== undefined ? settings.fontSize : DEFAULT_FONT_SIZE));
        q.set('tabSize', String(settings.tabSize !== undefined ? settings.tabSize : DEFAULT_TAB_SIZE));
        q.set('minimap', (settings.minimap !== undefined ? !!settings.minimap : DEFAULT_MINIMAP) ? '1' : '0');
        q.set('wordWrap', (settings.wordWrap !== undefined ? !!settings.wordWrap : DEFAULT_WORDWRAP) ? 'on' : 'off');
        return 'monaco.html?' + q.toString();
      }

      function monacoCall(type, payload) {
        const id = ++monacoSeq;
        return new Promise(function(resolve, reject) {
          if (!monacoReady) { reject(new Error('Editor not ready yet')); return; }
          monacoWait[id] = { resolve, reject };
          const m = Object.assign({ type: type, id: id }, payload || {});
          try {
            monacoFrame.contentWindow.postMessage(m, '*');
          } catch (e) {
            delete monacoWait[id];
            reject(e);
          }
          setTimeout(function() {
            if (monacoWait[id]) { delete monacoWait[id]; reject(new Error('Editor timed out')); }
          }, 5000);
        });
      }

      function editorOp(type, payload) {
        return monacoCall(type, payload).catch(function(err) {
          showToast(err.message || 'Editor not ready', 'error');
          throw err;
        });
      }

      function syncMonacoTheme() {
        try {
          if (!monacoFrame || !monacoFrame.src) return;
        } catch (e) { return; }
        const theme = settings.theme || 'black';
        monacoCall('theme', {
          theme: theme,
          isglassmorphism: !!settings.liquidGlassToggle,
          customtheme: theme === 'custom' ? (settings.customTheme || {}) : null
        }).catch(function() {});
      }

      window.addEventListener('message', function(ev) {
        if (ev.origin !== window.location.origin && ev.origin !== 'null') return;
        const d = ev.data || {};
        if (d.type === 'ready') {
          monacoReady = true;
          syncMonacoTheme();
          try { syncMonacoEditorSettings(); } catch(e) {}
        } else if (d.type === 'result' && monacoWait[d.id]) {
          const w = monacoWait[d.id];
          delete monacoWait[d.id];
          if (d.ok) w.resolve(d);
          else w.reject(new Error('Editor operation failed'));
        }
      });

      function refreshInjectStatus() {
        const el = document.getElementById('injectStatus');
        if (!el) return;
        const tauri = window.__TAURI__?.core;
        if (!(tauri && tauri.invoke)) return;
        tauri.invoke('injected_status').then(function(alive) {
          el.textContent = alive ? 'Injected ✓' : 'Attach to Roblox';
          el.style.color = alive ? 'var(--success)' : '';
        }).catch(function() {});
      }

      function mcpProgress(checkpoint, message) {
        const box = document.getElementById('mcpInjectProgress');
        if (box) {
          box.style.display = '';
          box.textContent = checkpoint + ': ' + message;
        }
      }

      // Tauri event: nam-inject-progress { checkpoint, message }
      try {
        if (window.__TAURI__?.event?.listen) {
          window.__TAURI__.event.listen('nam-inject-progress', function(ev) {
            const p = ev.payload || {};
            if (p.checkpoint || p.message) mcpProgress(p.checkpoint || 'progress', p.message || '');
            if (p.checkpoint === 'injected' || p.checkpoint === 'already-injected') refreshInjectStatus();
          });
        }
      } catch (e) {}

      let injecting = false;
      async function doInject() {
        if (injecting) { showToast('Already injecting — waiting for payload...', 'info'); return; }
        const tauri = window.__TAURI__?.core;
        if (tauri && tauri.invoke) {
          try {
            injecting = true;
            showToast('Injecting... (polling 6736/6969)', 'info');
            mcpProgress('start', 'inject requested, polling payload ports...');
            const msg = await tauri.invoke('inject');
            // backend only resolves after the port answers or timeout
            if (msg === 'Already injected' || String(msg).indexOf('Already') === 0) showToast('Already injected — executor ready', 'info');
            else showToast(msg || 'Injected', 'success');
          } catch(e) { showToast('Inject failed: ' + (e || ''), 'error'); mcpProgress('error', String(e || '')); }
          injecting = false;
          refreshInjectStatus();
          try {
            const st = await tauri.invoke('mcp_status').catch(function(){ return null; });
            if (st) renderMcpStatus(st);
          } catch (e) {}
          return;
        }
        if (typeof window.inject === 'function') { window.inject(); showToast('Injecting into Roblox...', 'info'); return; }
        if (typeof window.namInject === 'function') { window.namInject(); showToast('Injecting into Roblox...', 'info'); return; }
        if (typeof window.NamInject === 'function') { window.NamInject(); showToast('Injecting into Roblox...', 'info'); return; }
        showToast('Executor not connected', 'error');
      }

      document.getElementById('btnExecute').addEventListener('click', function() {
        editorOp('get').then(async function(r) {
          const script = r.content || '';
          if (!script.trim()) { showToast('Script is empty', 'warning'); return; }
          const tauri = window.__TAURI__?.core;
          if (tauri && tauri.invoke) {
            try { const msg = await tauri.invoke('execute', { script }); showToast(msg || ('Executed (' + script.length + ' chars)'), 'success'); } catch(e) { showToast('Execute failed: ' + (e || ''), 'error'); }
            return;
          }
          try {
            if (typeof window.execute === 'function') {
              window.execute(script);
              showToast('Executed (' + script.length + ' chars)', 'success');
            } else {
              showToast('Executor not connected', 'error');
            }
          } catch (err) {
            showToast('Execute failed: ' + (err.message || err), 'error');
          }
        }).catch(function() {});
      });

      document.getElementById('btnClear').addEventListener('click', function() {
        editorOp('clear').then(function() { showToast('Editor cleared', 'info'); }).catch(function() {});
      });

      document.getElementById('btnSave').addEventListener('click', function() {
        editorOp('get').then(function(r) {
          const name = String(r.name || 'script').replace(/\.[^.]*$/, '') + '.lua';
          const content = r.content || '';
          if (!content.trim()) { showToast('Script is empty', 'warning'); return; }
          let savedDisk = false;
          try {
            const tauriDisk = window.__TAURI__?.core;
            if (tauriDisk && tauriDisk.invoke) {
              savedDisk = true;
              tauriDisk.invoke('save_script_file', { name: name, content: content }).then(function() {
                renderLibrary();
              }).catch(function() {});
            }
          } catch (e) { savedDisk = false; }
          if (!savedDisk) {
            const blob = new Blob([content], { type: 'text/plain' });
            const a = document.createElement('a');
            const url = URL.createObjectURL(blob);
            a.href = url;
            a.download = name;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(function() { URL.revokeObjectURL(url); }, 2000);
          }
          saveToLibrary(name, content);
          showToast('Saved ' + name, 'success');
        }).catch(function() {});
      });

      // ---- Saved-scripts library (home page) ----
      function getLibrary() {
        try { return JSON.parse(localStorage.getItem('nam-library') || '[]') || []; }
        catch (e) { return []; }
      }
      function setLibrary(list) {
        try { localStorage.setItem('nam-library', JSON.stringify(list)); } catch (e) {}
      }
      function saveToLibrary(name, content) {
        const list = getLibrary();
        const ix = list.findIndex(function(s) { return s.name === name; });
        const entry = { name: name, content: content, updated: Date.now() };
        if (ix >= 0) list[ix] = entry; else list.unshift(entry);
        setLibrary(list);
        renderLibrary();
      }
      function updateSavedCount() {
        const box = document.getElementById('savedList');
        const count = document.getElementById('savedCount');
        const empty = document.getElementById('savedEmpty');
        if (!box) return;
        const n = box.querySelectorAll('.saved-row').length;
        if (count) count.textContent = n + ' total';
        if (empty) empty.style.display = n ? 'none' : '';
      }
      function mergeDiskSaved() {
        const box = document.getElementById('savedList');
        if (!box) return;
        let invoke = null;
        try { invoke = window.__TAURI__?.core?.invoke; } catch (e) { return; }
        if (!invoke) return;
        invoke('list_saved_files').then(function(files) {
          const known = {};
          box.querySelectorAll('.saved-row .saved-name').forEach(function(el) { known[el.textContent] = true; });
          let added = false;
          (files || []).forEach(function(n) {
            if (known[n]) return;
            const row = document.createElement('div');
            row.className = 'saved-row';
            const nm = document.createElement('span');
            nm.className = 'saved-name';
            nm.textContent = n;
            nm.title = n + ' (saved folder)';
            nm.addEventListener('click', function() { loadLibraryScript(n); });
            const del = document.createElement('button');
            del.className = 'saved-del';
            del.textContent = '×';
            del.title = 'Delete';
            del.addEventListener('click', function(e) {
              e.stopPropagation();
              try { invoke('delete_saved_file', { name: n }).catch(function() {}); } catch (err) {}
              row.remove();
              updateSavedCount();
              showToast('Deleted ' + n, 'info');
            });
            row.appendChild(nm);
            row.appendChild(del);
            box.appendChild(row);
            added = true;
          });
          if (added) updateSavedCount();
        }).catch(function() {});
      }
      function renderLibrary() {
        const count = document.getElementById('savedCount');
        const empty = document.getElementById('savedEmpty');
        const box = document.getElementById('savedList');
        if (!box) return;
        const list = getLibrary();
        if (count) count.textContent = list.length + ' total';
        if (empty) empty.style.display = list.length ? 'none' : '';
        box.innerHTML = '';
        list.forEach(function(s) {
          const row = document.createElement('div');
          row.className = 'saved-row';
          const nm = document.createElement('span');
          nm.className = 'saved-name';
          nm.textContent = s.name;
          nm.title = s.name;
          nm.addEventListener('click', function() { loadLibraryScript(s.name); });
          const del = document.createElement('button');
          del.className = 'saved-del';
          del.textContent = '×';
          del.title = 'Delete';
          del.addEventListener('click', function(e) {
            e.stopPropagation();
            setLibrary(getLibrary().filter(function(x) { return x.name !== s.name; }));
            try {
              const tauri = window.__TAURI__?.core;
              if (tauri && tauri.invoke) tauri.invoke('delete_saved_file', { name: s.name }).catch(function() {});
            } catch (err) {}
            renderLibrary();
            showToast('Deleted ' + s.name, 'info');
          });
          row.appendChild(nm);
          row.appendChild(del);
          box.appendChild(row);
        });
        mergeDiskSaved();
      }
      function loadLibraryScript(name) {
        const found = getLibrary().find(function(s) { return s.name === name; });
        function openIt(content) {
          setActiveTab('code');
          editorOp('open', { content: content, name: name })
            .then(function() { showToast('Opened ' + name, 'success'); })
            .catch(function() {});
        }
        if (found) { openIt(found.content || ''); return; }
        try {
          const tauri = window.__TAURI__?.core;
          if (!(tauri && tauri.invoke)) { showToast('Not in library', 'error'); return; }
          tauri.invoke('read_saved_file', { name: name }).then(openIt).catch(function() { showToast('Not in library', 'error'); });
        } catch (e) { showToast('Not in library', 'error'); }
      }
      let winWireTries = 0;
      (function wireWinFallback() {
        try {
          const invoke = window.__TAURI__?.core?.invoke;
          if (!invoke) { if (++winWireTries < 240) setTimeout(wireWinFallback, 500); return; }
          [['.win-btn.minimize', 'minimize_window'], ['.win-btn.maximize', 'toggle_maximize'], ['.win-btn.close', 'close_window']].forEach(function(pair) {
            const b = document.querySelector(pair[0]);
            if (b && !b.dataset.tauriWired) {
              b.dataset.tauriWired = '1';
              b.addEventListener('click', function() { invoke(pair[1]).catch(function() {}); });
            }
          });
        } catch (e) { setTimeout(wireWinFallback, 1000); }
      })();
      renderLibrary();

      document.getElementById('btnOpen').addEventListener('click', function() {
        openScriptFile.click();
      });

      openScriptFile.addEventListener('change', function(e) {
        const f = e.target.files[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = function(ev) {
          editorOp('open', { content: ev.target.result, name: f.name }).then(function() {
            showToast('Opened ' + f.name, 'success');
          }).catch(function() {});
        };
        reader.readAsText(f);
        e.target.value = '';
      });

      document.getElementById('btnInject').addEventListener('click', function() {
        doInject();
      });

      // ---------------- Nam MCP panel ----------------
      let mcpTokenShown = false;
      let mcpCache = null;
      function mcpInvoke(cmd, args, silent) {
        const tauri = window.__TAURI__?.core;
        if (!(tauri && tauri.invoke)) {
          if (!silent) showToast('Executor not connected', 'error');
          return Promise.reject(new Error('no tauri'));
        }
        return tauri.invoke(cmd, args || {});
      }
      const MCP_PERMS = [
        { id: 'inject', en: ['Inject', 'Inject Nam into a running Roblox client.'], vi: ['Tiêm', 'Tiêm Nam vào Roblox client đang chạy.'] },
        { id: 'execute', en: ['Execute', 'Run Luau and return values in the attached client.'], vi: ['Thực thi', 'Chạy Luau và nhận giá trị trả về trong client đã tiêm.'] },
        { id: 'scripts', en: ['Script inspection', 'List scripts, read bytecode and hashes.'], vi: ['Soi script', 'Liệt kê script, đọc bytecode và hash.'] },
        { id: 'instances', en: ['Instances', 'Search the game tree and read instance info.'], vi: ['Instances', 'Tìm cây game và đọc thông tin instance.'] },
        { id: 'memory', en: ['Memory', 'Scan the Luau GC and read environment tables.'], vi: ['Bộ nhớ', 'Quét Luau GC và đọc bảng môi trường.'] },
        { id: 'files', en: ['Files', 'Read and write the Workspace, Scripts and AutoExec folders.'], vi: ['Tệp', 'Đọc/ghi thư mục Workspace, Scripts và AutoExec.'] },
        { id: 'diagnostics', en: ['Diagnostics', 'Read the editor Problems and terminal.'], vi: ['Chẩn đoán', 'Đọc bảng Problems và terminal.'] },
        { id: 'gameknowledge', en: ['Game knowledge', 'Remember findings about a game so later sessions start informed.'], vi: ['Hiểu game', 'Ghi nhớ phát hiện về game để lần sau vào là biết.'] },
        { id: 'uilibraries', en: ['UI libraries', 'Fetch Roblox UI libraries from GitHub so scripts get a real menu instead of a hand built one.'], vi: ['Thư viện UI', 'Lấy thư viện UI Roblox từ GitHub để script có menu xịn thay vì tự chế.'] }
      ];
      let mcpPermState = {};
      MCP_PERMS.forEach(function(p) { mcpPermState[p.id] = true; });
      try {
        const savedPerms = loadSettings().mcpPerms;
        if (savedPerms) Object.keys(savedPerms).forEach(function(k) {
          if (k in mcpPermState) mcpPermState[k] = !!savedPerms[k];
        });
      } catch (e) {}
      let mcpDocsLang = 'en';
      try { mcpDocsLang = loadSettings().mcpDocsLang === 'vi' ? 'vi' : 'en'; } catch (e) {}
      function mcpLang() { return mcpDocsLang; }
      const MCP_PERM_ICONS = {
        inject: 'plug', execute: 'play', scripts: 'file-code', instances: 'boxes',
        memory: 'cpu', files: 'folder',
        diagnostics: 'activity', gameknowledge: 'brain', uilibraries: 'layout-template'
      };
      function updateMcpBadge() {
        const permCount = document.getElementById('mcpPermCount');
        if (!permCount) return;
        const onCount = MCP_PERMS.filter(function(p) { return !!mcpPermState[p.id]; }).length;
        permCount.textContent = onCount + '/' + MCP_PERMS.length;
      }
      function renderMcpPerms() {
        const permList = document.getElementById('mcpPermList');
        if (!permList) return;
        const lang = mcpLang();
        updateMcpBadge();
        const permTitle = document.getElementById('mcpPermTitle');
        if (permTitle) permTitle.textContent = lang === 'vi' ? 'Quyền' : 'Permissions';
        permList.innerHTML = '';
        MCP_PERMS.forEach(function(p) {
          const on = !!mcpPermState[p.id];
          const row = document.createElement('div');
          row.className = 'mcp-perm-row' + (on ? '' : ' off');
          const icon = document.createElement('div');
          icon.className = 'mcp-perm-icon';
          const ic = document.createElement('i');
          ic.setAttribute('data-lucide', MCP_PERM_ICONS[p.id] || 'toggle-right');
          icon.appendChild(ic);
          const txt = document.createElement('div');
          txt.className = 'mcp-perm-text';
          const b = document.createElement('b');
          b.textContent = p[lang][0];
          const s = document.createElement('span');
          s.textContent = p[lang][1];
          txt.appendChild(b); txt.appendChild(s);
          const t = document.createElement('div');
          t.className = 'toggle' + (on ? ' on' : '');
          t.dataset.perm = p.id;
          const knob = document.createElement('div');
          knob.className = 'knob';
          t.appendChild(knob);
          t.addEventListener('click', function(e) {
            e.stopPropagation();
            e.preventDefault();
            const next = !mcpPermState[p.id];
            mcpPermState[p.id] = next;
            saveSettings('mcpPerms', mcpPermState);
            t.classList.toggle('on', next);
            row.classList.toggle('off', !next);
            updateMcpBadge();
            mcpInvoke('mcp_set_permission', { id: p.id, enabled: next }, true)
              .then(function(st) {
                let changed = false;
                if (st && st.permissions) st.permissions.forEach(function(bp) {
                  if ((bp.id in mcpPermState) && mcpPermState[bp.id] !== !!bp.enabled) {
                    mcpPermState[bp.id] = !!bp.enabled;
                    changed = true;
                  }
                });
                if (changed) {
                  try { saveSettings('mcpPerms', mcpPermState); } catch (err) {}
                  renderMcpPerms();
                }
              })
              .catch(function() {});
          });
          row.appendChild(icon); row.appendChild(txt); row.appendChild(t);
          permList.appendChild(row);
        });
        try { lucide.createIcons(); } catch (e) {}
      }
      function renderMcpClients(clients) {
        const box = document.getElementById('mcpClients');
        if (!box) return;
        box.innerHTML = '';
        const visible = clients.filter(function(c) {
          return c.status === 'connected' || c.detected;
        });
        if (!visible.length) {
          const hint = document.createElement('div');
          hint.className = 'mcp-hint';
          hint.textContent = 'No AI coder found on this PC — launch one, then reopen Settings.';
          box.appendChild(hint);
          try { lucide.createIcons(); } catch (e) {}
          return;
        }
        visible.forEach(function(c) {
          const row = document.createElement('div');
          row.className = 'mcp-client-row' + ((!c.detected && c.status !== 'connected') ? ' dim' : '');
          const nm = document.createElement('span');
          nm.className = 'name'; nm.textContent = c.label;
          const sts = document.createElement('span');
          const isConn = c.status === 'connected';
          sts.className = 'st' + (isConn ? ' connected' : '');
          sts.textContent = isConn ? 'Connected' : (c.detected ? 'Not set up' : 'Not detected');
          const sp = document.createElement('span');
          sp.className = 'spacer';
          row.appendChild(nm); row.appendChild(sts); row.appendChild(sp);
          if (isConn) {
            const x = document.createElement('button');
            x.className = 'mcp-disconnect'; x.textContent = '×'; x.title = 'Disconnect';
            x.addEventListener('click', function() {
              mcpInvoke('mcp_disconnect_client', { client: c.id }).then(renderMcpStatus).catch(function(e){ showToast(String(e), 'error'); });
            });
            row.appendChild(x);
          } else {
            const b = document.createElement('button');
            b.className = 'mcp-setup-btn'; b.textContent = 'Set up';
            b.addEventListener('click', function() {
              showToast('Setting up ' + c.label + '...', 'info');
              mcpInvoke('mcp_setup_client', { client: c.id }).then(function(s2){ renderMcpStatus(s2); showToast(c.label + ' connected', 'success'); }).catch(function(e){ showToast('Setup failed: ' + e, 'error'); });
            });
            row.appendChild(b);
          }
          box.appendChild(row);
        });
        try { lucide.createIcons(); } catch (e) {}
      }
      function renderMcpStatus(st) {
        mcpCache = st;
        const badge = document.getElementById('mcpStatusBadge');
        const btn = document.getElementById('mcpStartBtn');
        const ep = document.getElementById('mcpEndpoint');
        if (badge) {
          badge.textContent = st.running ? 'Running' : 'Stopped';
          badge.classList.toggle('running', !!st.running);
          badge.classList.toggle('stopped', !st.running);
        }
        if (btn) {
          btn.querySelector('span').textContent = st.running ? 'Stop' : 'Start';
          btn.classList.toggle('stop', !!st.running);
        }
        if (ep) ep.style.display = st.running ? '' : 'none';
        if (st.running) {
          document.getElementById('mcpUrlText').textContent = st.url || '-';
          document.getElementById('mcpRelayText').textContent = st.relay || '-';
          setMcpToken(st.token || '');
        }
        if (st.permissions) {
          st.permissions.forEach(function(bp) {
            if (bp.id in mcpPermState) mcpPermState[bp.id] = !!bp.enabled;
          });
          try { saveSettings('mcpPerms', mcpPermState); } catch (e) {}
        }
        renderMcpPerms();
        renderMcpClients(st.clients || []);
        try { lucide.createIcons(); } catch (e) {}
      }
      function setMcpToken(tok) {
        const el = document.getElementById('mcpTokenText');
        if (!el) return;
        el.dataset.token = tok;
        el.textContent = mcpTokenShown ? tok : (tok ? '•'.repeat(Math.min(tok.length, 24)) : '-');
      }
      const MCP_DOCS = {
        en: {
          sub: 'Let an AI assistant drive Nam for you',
          stopped: 'Server is off — start it above and your URL + token appear here.',
          p1: 'Nam MCP opens a small local door between Nam and coding assistants. A linked assistant can inject, fire Luau through your game, shuffle local files, and keep notes per game. Live-game reading needs an injected client mid-match; everything else only needs Nam.',
          steps: ['Start the server above.', 'Hit Set up next to your assistant, then restart it.', 'Inject, join a game, and tell it what you want.'],
          connecting: 'Hooking up an assistant',
          connectingBody: 'Set up patches the assistant\'s config to launch Nam in relay mode — no Node, no JSON typing. Restart the assistant after (terminal ones just need a fresh session). Your token never lands in the client config, so the hook survives restarts and updates.',
          other: 'An assistant we don\'t know',
          otherBody: 'Give it the relay command below. The relay speaks plain MCP over stdio — no URL, no token — and re-finds Nam\'s live port (3836, or wherever it landed) on every launch. One setup, then forget it.',
          relayLabel: 'Relay command:',
          httpLabel: 'HTTP instead? While running, Nam also answers at the URL below with a restart-proof token.',
          tokenNote: 'Pass the token as an Authorization: Bearer header.',
          perms: 'Switches',
          permsBody: 'Each row is a master switch. Flip one off and its tools bounce immediately. Execute runs code, so think twice there.',
          tools: 'What it can touch',
          toolsIntro: 'Every call a linked assistant may make. Each one below runs for real on Nam.',
          groups: [
            ['API cheat-sheet', 'search-api', 'Nam\'s Luau globals and libraries. No injection needed.'],
            ['Seats', 'list-clients, set-active-client, inject, get-game-info', 'Who is injected and where.'],
            ['Running code', 'get-data-by-code, eval, execute, execute-file, live-reload', 'Luau through the attached client — eval and get-data-by-code bring prints and return values back.'],
            ['Script shelf', 'list-scripts, get-script-bytecode, get-script-hash', 'Running scripts with names and classes; bytecode comes back base64.'],
            ['Game tree', 'search-instances, get-descendants-tree, get-nil-instances, get-instance-properties, get-property, list-players, list-connections', 'Instances by class, capped tree dumps, properties including hidden ones, players and signal counts.'],
            ['Memory', 'gc-scan, get-env', 'Filter the GC with counts, plus environment key lists.'],
            ['Remote poking', 'fire-remote, set-property, call-method', 'Nudge remotes, properties and methods without writing Luau by hand.'],
            ['File drawer', 'read-file, write-file, list-files', 'Local Workspace, Scripts and AutoExec.'],
            ['Game memory', 'remember-game, game-feedback, recall-game-memory, forget-game-memory', 'Notes per game, recalled next session.'],
            ['Script desk', 'open-script, check-script', 'Drop a script into Scripts/MCP; quick local lint before running.'],
            ['Logs', 'get-app-log, get-diagnostics', 'Nam\'s own log plus open-tab problems (Nam has no Problems feed, so that one is quiet).'],
            ['UI kits', 'fetch-ui-library, list-ui-libraries', 'Rayfield, Orion, WindUI, Fluent, Luna, Maclib and LinoriaLib straight from GitHub.']
          ],
          trouble: 'Hiccups',
          troubleItems: ['Assistant can\'t reach Nam → server is off, or the assistant wasn\'t restarted after Set up.', 'Token rejected → Stop, Start, restart the assistant.', 'Tool bounced instantly → its switch is off.', 'Inject stalls → Roblox isn\'t open, or NamLoader isn\'t where Nam looks (Nam/bin next to Nam.exe).']
        },
        vi: {
          sub: 'Để trợ lý AI lái Nam giùm bạn',
          stopped: 'Server đang tắt — bật lên ở trên, URL + token sẽ hiện ra.',
          p1: 'Nam MCP mở một cánh cửa local giữa Nam và trợ lý viết code. Trợ lý đã nối có thể bấm tiêm, bắn Luau qua game, xoay file local và ghi chú theo game. Đọc game trực tiếp cần client đã tiêm đang trong trận; còn lại chỉ cần mỗi Nam.',
          steps: ['Bật server ở trên.', 'Nhấn Set up cạnh trợ lý rồi khởi động lại nó.', 'Tiêm, vào game, rồi cứ việc sai vặt.'],
          connecting: 'Móc trợ lý vào',
          connectingBody: 'Set up tự vá config để gọi Nam ở chế độ relay — khỏi Node, khỏi gõ JSON. Xong thì khởi động lại trợ lý (mấy con terminal mở session mới là xong). Token không bao giờ nằm trong config client nên mối nối sống qua restart và update.',
          other: 'Trợ lý lạ hoắc',
          otherBody: 'Quăng cho nó lệnh relay bên dưới. Relay nói MCP thuần qua stdio — không URL không token — mỗi lần chạy tự tìm lại cổng sống của Nam (3836 hoặc chỗ nó dạt tới). Setup một lần rồi quên.',
          relayLabel: 'Lệnh relay:',
          httpLabel: 'Thích HTTP hơn? Khi chạy, Nam cũng trả lời ở URL bên dưới với token giữ qua restart.',
          tokenNote: 'Gắn token vào header Authorization: Bearer.',
          perms: 'Công tắc',
          permsBody: 'Mỗi dòng là công tắc tổng. Tắt dòng nào tool của nó dội lại ngay. Thực thi chạy code nên nghĩ kỹ chỗ đó.',
          tools: 'Nó đụng được gì',
          toolsIntro: 'Mọi lệnh trợ lý đã nối được phép gọi. Món nào dưới đây cũng chạy thật trên Nam.',
          groups: [
            ['Bảng tra API', 'search-api', 'Global và thư viện Luau của Nam. Khỏi tiêm.'],
            ['Ghế ngồi', 'list-clients, set-active-client, inject, get-game-info', 'Ai đang tiêm và ở đâu.'],
            ['Chạy code', 'get-data-by-code, eval, execute, execute-file, live-reload', 'Luau qua client đang gắn — eval và get-data-by-code mang cả chữ in lẫn giá trị trả về.'],
            ['Kệ script', 'list-scripts, get-script-bytecode, get-script-hash', 'Script đang chạy kèm tên và class; bytecode về dạng base64.'],
            ['Cây game', 'search-instances, get-descendants-tree, get-nil-instances, get-instance-properties, get-property, list-players, list-connections', 'Instance theo class, dump cây có giới hạn, thuộc tính kể cả ẩn, players và số connection.'],
            ['Bộ nhớ', 'gc-scan, get-env', 'Lọc GC lấy số lượng, và danh sách key môi trường.'],
            ['Chọc remote', 'fire-remote, set-property, call-method', 'Chọc remote, thuộc tính, method mà khỏi viết Luau tay.'],
            ['Ngăn file', 'read-file, write-file, list-files', 'Workspace, Scripts, AutoExec local.'],
            ['Trí nhớ game', 'remember-game, game-feedback, recall-game-memory, forget-game-memory', 'Ghi chú theo game, session sau nhớ.'],
            ['Bàn script', 'open-script, check-script', 'Thả script vào Scripts/MCP; lint local nhanh trước khi chạy.'],
            ['Log', 'get-app-log, get-diagnostics', 'Log của Nam và lỗi tab đang mở (Nam không có feed Problems nên món đó im re).'],
            ['Bộ UI', 'fetch-ui-library, list-ui-libraries', 'Rayfield, Orion, WindUI, Fluent, Luna, Maclib và LinoriaLib thẳng từ GitHub.']
          ],
          trouble: 'Trục trặc',
          troubleItems: ['Trợ lý không tới được Nam → server tắt, hoặc chưa restart sau Set up.', 'Token bị đá → Stop, Start, restart trợ lý.', 'Tool dội ngay → công tắc của nó đang tắt.', 'Tiêm đứng im → Roblox chưa mở, hoặc NamLoader không ở chỗ Nam tìm (Nam/bin cạnh Nam.exe).']
        }
      };
      function escHtml(s) {
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
      }
      function renderMcpDocs() {
        const d = MCP_DOCS[mcpLang()];
        const body = document.getElementById('mcpDocsBody');
        const sub = document.getElementById('mcpDocsSub');
        const langBtn = document.getElementById('mcpDocsLang');
        if (langBtn) langBtn.textContent = mcpLang() === 'en' ? 'VI' : 'EN';
        if (sub) sub.textContent = d.sub;
        if (!body) return;
        const running = mcpCache && mcpCache.running;
        const relay = (mcpCache && mcpCache.relay) || 'nam.exe --mcp-relay';
        const url = (mcpCache && mcpCache.url) || 'http://127.0.0.1:3836/mcp';
        const token = (mcpCache && mcpCache.token) || '';
        let html = '';
        if (!running) html += '<div class="mcpdocs-banner">' + escHtml(d.stopped) + '</div>';
        html += '<p>' + escHtml(d.p1) + '</p>';
        if (d.steps) {
          html += '<ol class="mcpdocs-steps">';
          d.steps.forEach(function(s, i) { html += '<li><b>' + (i + 1) + '.</b> ' + escHtml(s) + '</li>'; });
          html += '</ol>';
        }
        html += '<h4>' + escHtml(d.connecting) + '</h4><p>' + escHtml(d.connectingBody) + '</p>';
        html += '<h4>' + escHtml(d.other) + '</h4><p>' + escHtml(d.otherBody) + '</p>';
        html += '<div class="mcp-field"><label>Relay</label><code>' + escHtml(relay) + '</code><button class="mcp-copy" data-copy="' + escHtml(relay) + '"><i data-lucide="copy"></i></button></div>';
        html += '<div class="mcp-field" style="margin-top:0.4rem;"><label>URL</label><code>' + escHtml(url) + '</code><button class="mcp-copy" data-copy="' + escHtml(url) + '"><i data-lucide="copy"></i></button></div>';
        if (token) html += '<div class="mcp-field" style="margin-top:0.4rem;"><label>Token</label><code>' + escHtml(token) + '</code><button class="mcp-copy" data-copy="' + escHtml(token) + '"><i data-lucide="copy"></i></button></div>';
        html += '<p style="margin-top:0.4rem;">' + escHtml(d.httpLabel) + ' ' + escHtml(d.tokenNote) + '</p>';
        html += '<h4>' + escHtml(d.perms) + '</h4><p>' + escHtml(d.permsBody) + '</p>';
        html += '<h4>' + escHtml(d.tools) + '</h4><p>' + escHtml(d.toolsIntro) + '</p>';
        d.groups.forEach(function(g) {
          html += '<div class="mcpdocs-tool"><b>' + escHtml(g[0]) + '</b><p>' + escHtml(g[2]) + '</p><div class="mcpdocs-chips">';
          g[1].split(',').forEach(function(t) { html += '<span>' + escHtml(t.trim()) + '</span>'; });
          html += '</div></div>';
        });
        if (d.trouble) {
          html += '<h4>' + escHtml(d.trouble) + '</h4><ul class="mcpdocs-trouble">';
          d.troubleItems.forEach(function(s) { html += '<li>' + escHtml(s) + '</li>'; });
          html += '</ul>';
        }
        body.innerHTML = html;
        try { lucide.createIcons(); } catch (e) {}
      }
      function openMcpDocs() {
        try {
          ensureMcpModalWiring();
          renderMcpDocs();
          document.getElementById('mcpDocsOverlay').classList.add('open');
        } catch (err) {
          showToast('Docs failed to open', 'error');
        }
      }
      function closeMcpDocs() {
        document.getElementById('mcpDocsOverlay').classList.remove('open');
      }
      if (mcpStartBtn) mcpStartBtn.addEventListener('click', function() {
        const running = mcpCache && mcpCache.running;
        mcpInvoke(running ? 'mcp_stop' : 'mcp_start').then(function(st){ renderMcpStatus(st); showToast(st.running ? 'Nam MCP running' : 'Nam MCP stopped', st.running ? 'success' : 'info'); }).catch(function(e){ showToast('MCP failed: ' + e, 'error'); });
      });
      const mcpDocsBtn = document.getElementById('mcpDocsBtn');
      if (mcpDocsBtn) {
        mcpDocsBtn.addEventListener('click', openMcpDocs);
        mcpDocsBtn.__namWired = true;
      }
      function onMcpLangSwitch() {
        try {
          mcpDocsLang = (mcpDocsLang === 'en' ? 'vi' : 'en');
          try { saveSettings('mcpDocsLang', mcpDocsLang); } catch (err) {}
          renderMcpPerms();
          renderMcpDocs();
        } catch (err) {
          showToast('Language failed', 'error');
        }
      }
      function ensureMcpModalWiring() {
        const c = document.getElementById('mcpDocsClose');
        if (c && !c.__namWired) {
          c.addEventListener('click', function() { closeMcpDocs(); });
          c.__namWired = true;
        }
        const l = document.getElementById('mcpDocsLang');
        if (l && !l.__namWired) {
          l.addEventListener('click', onMcpLangSwitch);
          l.__namWired = true;
        }
        const o = document.getElementById('mcpDocsOverlay');
        if (o && !o.__namWired) {
          o.addEventListener('click', function(e) {
            if (e.target === o) closeMcpDocs();
          });
          o.__namWired = true;
        }
        const bd = document.getElementById('mcpDocsBody');
        if (bd && !bd.__namWired) {
          bd.addEventListener('click', function(e) {
            const t = e.target && e.target.closest ? e.target.closest('[data-copy]') : null;
            if (t && t.dataset && t.dataset.copy) copyText(t.dataset.copy, 'Copied');
          });
          bd.__namWired = true;
        }
      }
      ensureMcpModalWiring();
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
          const o = document.getElementById('mcpDocsOverlay');
          if (o && o.classList.contains('open')) closeMcpDocs();
        }
      });
      const mcpPermCollapse = document.getElementById('mcpPermCollapse');
      if (mcpPermCollapse) mcpPermCollapse.addEventListener('click', function() {
        const l = document.getElementById('mcpPermList');
        if (!l) return;
        const opening = l.style.display === 'none';
        l.style.display = opening ? '' : 'none';
        mcpPermCollapse.classList.toggle('open', opening);
      });
      const mcpClientCollapse = document.getElementById('mcpClientCollapse');
      if (mcpClientCollapse) mcpClientCollapse.addEventListener('click', function() {
        const l = document.getElementById('mcpClients');
        if (!l) return;
        const opening = l.style.display === 'none';
        l.style.display = opening ? '' : 'none';
        mcpClientCollapse.classList.toggle('open', opening);
      });
      function copyText(t, label) {
        if (!t || t === '-') { showToast('Nothing to copy', 'warning'); return; }
        navigator.clipboard.writeText(t).then(function(){ showToast((label || 'Copied'), 'success'); }).catch(function(){ showToast('Copy failed', 'error'); });
      }
      const mcpUrlCopy = document.getElementById('mcpUrlCopy');
      if (mcpUrlCopy) mcpUrlCopy.addEventListener('click', function(){ copyText(document.getElementById('mcpUrlText').textContent, 'URL copied'); });
      const mcpTokenCopy = document.getElementById('mcpTokenCopy');
      if (mcpTokenCopy) mcpTokenCopy.addEventListener('click', function(){ copyText(document.getElementById('mcpTokenText').dataset.token, 'Token copied'); });
      const mcpTokenToggle = document.getElementById('mcpTokenToggle');
      if (mcpTokenToggle) mcpTokenToggle.addEventListener('click', function(){ mcpTokenShown = !mcpTokenShown; if (mcpCache) setMcpToken(mcpCache.token || ''); });
      const mcpRelayCopy = document.getElementById('mcpRelayCopy');
      if (mcpRelayCopy) mcpRelayCopy.addEventListener('click', function(){ copyText(document.getElementById('mcpRelayText').textContent, 'Relay path copied'); });
      renderMcpPerms();
      mcpInvoke('mcp_status', {}, true).then(renderMcpStatus).catch(function() {});

      monacoFrame.src = monacoSrc();

      if (Object.keys(settings).length > 0) {
        setTimeout(function() { showToast('Settings restored', 'info'); }, 500);
      }
    })();
  
