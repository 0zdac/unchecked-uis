/* Nam guard disabled for debugging - was causing 10s auto-close */
(function(){ 'use strict'; console.log('[guard] disabled'); })();
