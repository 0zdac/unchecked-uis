function wireWindowButtons(invoke) {
  const minBtn = document.querySelector(".win-btn.minimize");
  const maxBtn = document.querySelector(".win-btn.maximize");
  const closeBtn = document.querySelector(".win-btn.close");
  if (minBtn && !minBtn.dataset.tauriWired) {
    minBtn.dataset.tauriWired = "1";
    minBtn.addEventListener("click", () => invoke("minimize_window").catch(e => console.error(e)));
  }
  if (maxBtn && !maxBtn.dataset.tauriWired) {
    maxBtn.dataset.tauriWired = "1";
    maxBtn.addEventListener("click", () => invoke("toggle_maximize").catch(e => console.error(e)));
  }
  if (closeBtn && !closeBtn.dataset.tauriWired) {
    closeBtn.dataset.tauriWired = "1";
    closeBtn.addEventListener("click", () => invoke("close_window").catch(e => console.error(e)));
  }
}
async function setupTauriWindow() {
  // wait for the Tauri bridge; capped so a plain browser preview doesn't
  // spin forever (app.js carries its own retry as backup).
  for (let i = 0; i < 480; i++) {
    const invoke = window.__TAURI__?.core?.invoke;
    if (invoke) {
      wireWindowButtons(invoke);
      wireDragFallback();
      console.log('Tauri window controls ready (invoke)');
      return;
    }
    await new Promise(r => setTimeout(r, 250));
  }
}
function wireDragFallback() {
  // also handle drag via CSS data-tauri-drag-region, but fallback JS drag
  const header = document.querySelector(".header-tabs");
  if (header && !header.dataset.tauriDragWired) {
    header.dataset.tauriDragWired = "1";
    header.addEventListener("mousedown", async (e) => {
      if (e.target.closest(".tab-btn, .win-btn")) return;
      try {
        const mod = await import("@tauri-apps/api/window").catch(() => null);
        const win = mod ? mod.getCurrentWindow() : window.__TAURI__?.window?.getCurrentWindow?.();
        if (win && win.startDragging) await win.startDragging();
      } catch {}
    });
  }
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupTauriWindow);
} else {
  setupTauriWindow();
}


document.addEventListener('contextmenu', e => e.preventDefault(), {capture:true});
window.addEventListener('contextmenu', e => e.preventDefault(), {capture:true});
document.addEventListener('keydown', e => {
  if (e.key === 'F12' || e.keyCode === 123) { e.preventDefault(); e.stopPropagation(); }
  if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.keyCode === 73)) { e.preventDefault(); }
  if (e.ctrlKey && e.key === 'F12') e.preventDefault();
  if ((e.ctrlKey || e.metaKey) && (e.key === 'a' || e.key === 'A' || e.keyCode === 65)) {
    const t = e.target;
    if (!(t && t.closest && t.closest('.monaco-editor, input, textarea, [contenteditable="true"]'))) {
      e.preventDefault();
      e.stopPropagation();
    }
  }
});
document.addEventListener('selectstart', e => {
  const t = e.target;
  if (t && t.closest && t.closest('.monaco-editor, input, textarea, [contenteditable="true"]')) return;
  e.preventDefault();
});