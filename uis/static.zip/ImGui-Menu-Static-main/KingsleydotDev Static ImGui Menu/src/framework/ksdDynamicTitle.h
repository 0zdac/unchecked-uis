// this source is from NewReality a discord server with 1500+ sources: discord.gg/realitynew
#pragma once
#include "imgui.h"

namespace KsdDynamicTitle
{
void Draw(ImDrawList* pDraw, const ImVec2& vWindowPos);
}
