// this source is from NewReality a discord server with 1500+ sources: discord.gg/realitynew
#pragma once

namespace KSD
{
void Render();
}
