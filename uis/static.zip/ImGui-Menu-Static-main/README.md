<!-- this source is from NewReality a discord server with 1500+ sources: discord.gg/realitynew -->
Skeet inspired 

ImGui Version v1.92.7 WIP (Latest)
Font Awesome
Custom menu strip with icons, animated page transitions, dynamic title system, advanced color pickers, custom Textboxes, SliderFloat, SliderInt, Combo boxes, GroupBox, and Buttons, etc etc. 

![Image](https://i.ibb.co/WpPmDNhJ/Static-Framework-4-Cm3p-Hdl-JC-Copy.gif)

[![Views](https://hits.dwyl.com/KingsleydotDev/ImGui-Menu-Static.svg?style=for-the-badge&color=blue)](https://github.com/KingsleydotDev/ImGui-Menu-Static)
