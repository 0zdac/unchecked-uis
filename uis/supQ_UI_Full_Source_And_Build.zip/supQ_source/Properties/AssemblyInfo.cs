using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Resources;

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyAssociatedContentFile("assets/flaticon-license.txt")]
[assembly: AssemblyAssociatedContentFile("hava_nagila.mp3")]
[assembly: AssemblyAssociatedContentFile("webview2loader.dll")]
[assembly: AssemblyCompany("supQ")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("supQ")]
[assembly: AssemblyTitle("supQ")]
[assembly: AssemblyVersion("1.0.0.0")]
