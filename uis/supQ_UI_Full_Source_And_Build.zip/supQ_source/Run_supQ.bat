@echo off
start "" "%~dp0Build_Output\supQ.exe"
