using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace supQ;

public partial class App : Application
{
	protected override void OnStartup(StartupEventArgs e)
	{
		RenderOptions.ProcessRenderMode = RenderMode.Default;
		Timeline.DesiredFrameRateProperty.OverrideMetadata(typeof(Timeline), new FrameworkPropertyMetadata
		{
			DefaultValue = 60
		});
		TextOptions.TextFormattingModeProperty.OverrideMetadata(typeof(Window), new FrameworkPropertyMetadata(TextFormattingMode.Display));
		base.OnStartup(e);
	}
}
