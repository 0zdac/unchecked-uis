using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Win32;

namespace supQ;

public static class AppPaths
{
	public static string Data => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "supQ");

	public static string ModuleRoot
	{
		get
		{
			try
			{
				using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\supQ", writable: false);
				if (registryKey != null)
				{
					string text = registryKey.GetValue("Root") as string;
					if (!string.IsNullOrEmpty(text) && Directory.Exists(text))
					{
						return text;
					}
				}
			}
			catch
			{
			}
			return Data;
		}
	}

	public static string Workspace => Path.Combine(ModuleRoot, "workspace");

	public static string Settings => Path.Combine(Data, "settings.json");

	public static string Themes => Path.Combine(Data, "themes.json");

	public static string Tabs => Path.Combine(Data, "tabs.json");

	public static string Fonts => Path.Combine(Data, "fonts");

	public static string RobloxConsoleLog => Path.Combine(Workspace, "roblox_console.log");

	public static string[] RobloxConsoleLogs => new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		RobloxConsoleLog,
		Path.Combine(Data, "workspace", "roblox_console.log"),
		Path.Combine(AppContext.BaseDirectory, "workspace", "roblox_console.log")
	}.ToArray();

	public static string Scripts => Path.Combine(AppContext.BaseDirectory, "scripts");

	public static string AutoExec => Path.Combine(AppContext.BaseDirectory, "autoexec");

	public static string EnsureDirectory(string path)
	{
		if (!Directory.Exists(path))
		{
			Directory.CreateDirectory(path);
		}
		return path;
	}
}
