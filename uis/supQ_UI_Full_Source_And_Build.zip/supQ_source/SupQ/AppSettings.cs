using System;
using System.IO;
using Newtonsoft.Json;

namespace supQ;

public class AppSettings
{
	public string ThemeName { get; set; } = "Midnight";

	public bool TopMost { get; set; }

	public bool AutoOpenConsole { get; set; } = true;

	public bool SetupFFlags { get; set; }

	public int EditorFontSize { get; set; } = 14;

	public string UiFontKey { get; set; } = "Segoe UI Variable Text";

	public string EditorFontKey { get; set; } = "Cascadia Code";

	[JsonIgnore]
	private static string SettingsPath => AppPaths.Settings;

	public static AppSettings Load()
	{
		try
		{
			string settingsPath = SettingsPath;
			if (File.Exists(settingsPath))
			{
				AppSettings appSettings = JsonConvert.DeserializeObject<AppSettings>(File.ReadAllText(settingsPath));
				if (appSettings != null)
				{
					return appSettings;
				}
			}
		}
		catch (Exception)
		{
		}
		return new AppSettings();
	}

	public void Save()
	{
		try
		{
			string settingsPath = SettingsPath;
			string directoryName = Path.GetDirectoryName(settingsPath);
			if (!string.IsNullOrEmpty(directoryName) && !Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			File.WriteAllText(settingsPath, JsonConvert.SerializeObject(this, Formatting.Indented));
		}
		catch (Exception)
		{
		}
	}
}
