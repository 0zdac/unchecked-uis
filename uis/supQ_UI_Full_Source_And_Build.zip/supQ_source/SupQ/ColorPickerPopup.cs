using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace supQ;

public class ColorPickerPopup : Popup
{
	private const double SvWidth = 220.0;

	private const double SvHeight = 132.0;

	private const double HueHeight = 13.0;

	private readonly Rectangle _hueBase = new Rectangle();

	private readonly Canvas _svThumbLayer = new Canvas
	{
		IsHitTestVisible = false
	};

	private readonly Ellipse _svThumb = new Ellipse();

	private readonly Canvas _hueThumbLayer = new Canvas
	{
		IsHitTestVisible = false
	};

	private readonly Border _hueThumb = new Border();

	private readonly TextBox _hexBox = new TextBox();

	private readonly Border _preview = new Border();

	private double _h;

	private double _s;

	private double _v;

	private bool _syncing;

	public Color SelectedColor { get; private set; }

	public event Action<Color>? ColorChanged;

	public ColorPickerPopup(UIElement placementTarget, Color initial)
	{
		base.PlacementTarget = placementTarget;
		base.Placement = PlacementMode.Bottom;
		base.HorizontalOffset = -4.0;
		base.VerticalOffset = 6.0;
		base.StaysOpen = false;
		base.AllowsTransparency = true;
		base.PopupAnimation = PopupAnimation.Fade;
		base.Child = BuildContent();
		SetColor(initial, updateHexBox: true);
		base.Opened += delegate
		{
			base.Child?.Focus();
		};
	}

	private FrameworkElement BuildContent()
	{
		Grid svGrid = new Grid
		{
			Width = 220.0,
			Height = 132.0,
			Cursor = Cursors.Cross
		};
		_hueBase.Fill = new SolidColorBrush(Colors.Red);
		svGrid.Children.Add(_hueBase);
		svGrid.Children.Add(new Rectangle
		{
			Fill = new LinearGradientBrush(Colors.White, Color.FromArgb(0, byte.MaxValue, byte.MaxValue, byte.MaxValue), new Point(0.0, 0.0), new Point(1.0, 0.0))
		});
		svGrid.Children.Add(new Rectangle
		{
			Fill = new LinearGradientBrush(Color.FromArgb(0, 0, 0, 0), Colors.Black, new Point(0.0, 0.0), new Point(0.0, 1.0))
		});
		Ellipse svThumb = _svThumb;
		double width = (_svThumb.Height = 12.0);
		svThumb.Width = width;
		_svThumb.Stroke = Brushes.White;
		_svThumb.StrokeThickness = 2.0;
		_svThumb.Effect = new DropShadowEffect
		{
			BlurRadius = 4.0,
			ShadowDepth = 0.0,
			Opacity = 0.8,
			Color = Colors.Black
		};
		_svThumbLayer.Children.Add(_svThumb);
		svGrid.Children.Add(_svThumbLayer);
		Border border = new Border
		{
			CornerRadius = new CornerRadius(6.0),
			ClipToBounds = true,
			Child = svGrid,
			BorderThickness = new Thickness(1.0)
		};
		border.SetResourceReference(Border.BorderBrushProperty, "StrokeBrush");
		border.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
		{
			svGrid.CaptureMouse();
			UpdateFromSv(e.GetPosition(svGrid));
		};
		border.MouseMove += delegate(object s, MouseEventArgs e)
		{
			if (e.LeftButton == MouseButtonState.Pressed && svGrid.IsMouseCaptured)
			{
				UpdateFromSv(e.GetPosition(svGrid));
			}
		};
		border.MouseLeftButtonUp += delegate
		{
			svGrid.ReleaseMouseCapture();
		};
		Grid hueGrid = new Grid
		{
			Width = 220.0,
			Height = 13.0,
			Cursor = Cursors.SizeWE
		};
		GradientStopCollection gradientStopCollection = new GradientStopCollection();
		for (int num2 = 0; num2 <= 6; num2++)
		{
			gradientStopCollection.Add(new GradientStop(ThemeManager.FromHsv(num2 * 60, 1.0, 1.0), (double)num2 / 6.0));
		}
		hueGrid.Children.Add(new Rectangle
		{
			Fill = new LinearGradientBrush(gradientStopCollection, new Point(0.0, 0.0), new Point(1.0, 0.0))
		});
		_hueThumb.Width = 5.0;
		_hueThumb.Height = 13.0;
		_hueThumb.CornerRadius = new CornerRadius(2.0);
		_hueThumb.BorderBrush = Brushes.White;
		_hueThumb.BorderThickness = new Thickness(2.0);
		_hueThumbLayer.Children.Add(_hueThumb);
		hueGrid.Children.Add(_hueThumbLayer);
		Border border2 = new Border
		{
			CornerRadius = new CornerRadius(4.0),
			ClipToBounds = true,
			Margin = new Thickness(0.0, 10.0, 0.0, 0.0),
			Child = hueGrid,
			BorderThickness = new Thickness(1.0)
		};
		border2.SetResourceReference(Border.BorderBrushProperty, "StrokeBrush");
		border2.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
		{
			hueGrid.CaptureMouse();
			UpdateFromHue(e.GetPosition(hueGrid));
		};
		border2.MouseMove += delegate(object s, MouseEventArgs e)
		{
			if (e.LeftButton == MouseButtonState.Pressed && hueGrid.IsMouseCaptured)
			{
				UpdateFromHue(e.GetPosition(hueGrid));
			}
		};
		border2.MouseLeftButtonUp += delegate
		{
			hueGrid.ReleaseMouseCapture();
		};
		_preview.Width = 30.0;
		_preview.Height = 26.0;
		_preview.CornerRadius = new CornerRadius(5.0);
		_preview.BorderThickness = new Thickness(1.0);
		_preview.SetResourceReference(Border.BorderBrushProperty, "StrokeBrush");
		_hexBox.Width = 92.0;
		_hexBox.Height = 26.0;
		_hexBox.Margin = new Thickness(8.0, 0.0, 0.0, 0.0);
		_hexBox.FontFamily = new FontFamily("Consolas");
		_hexBox.FontSize = 11.5;
		_hexBox.VerticalContentAlignment = VerticalAlignment.Center;
		_hexBox.Padding = new Thickness(6.0, 0.0, 0.0, 0.0);
		_hexBox.BorderThickness = new Thickness(1.0);
		_hexBox.SetResourceReference(Control.BackgroundProperty, "SurfaceRaisedBrush");
		_hexBox.SetResourceReference(Control.ForegroundProperty, "TextBrightBrush");
		_hexBox.SetResourceReference(Control.BorderBrushProperty, "StrokeBrush");
		_hexBox.SetResourceReference(TextBoxBase.CaretBrushProperty, "AccentBrush");
		_hexBox.TextChanged += delegate
		{
			if (!_syncing && ThemeManager.TryParseHex(_hexBox.Text, out var color))
			{
				SetColor(color, updateHexBox: false);
			}
		};
		Button button = new Button
		{
			Content = "Done",
			Height = 26.0,
			Width = 60.0,
			Margin = new Thickness(8.0, 0.0, 0.0, 0.0),
			FontSize = 11.0,
			Cursor = Cursors.Hand
		};
		button.SetResourceReference(FrameworkElement.StyleProperty, "CardButtonStyle");
		button.Click += delegate
		{
			base.IsOpen = false;
		};
		StackPanel element = new StackPanel
		{
			Orientation = Orientation.Horizontal,
			Margin = new Thickness(0.0, 10.0, 0.0, 0.0),
			Children = 
			{
				(UIElement)_preview,
				(UIElement)_hexBox,
				(UIElement)button
			}
		};
		StackPanel child = new StackPanel
		{
			Children = 
			{
				(UIElement)border,
				(UIElement)border2,
				(UIElement)element
			}
		};
		Border border3 = new Border();
		border3.CornerRadius = new CornerRadius(6.0);
		border3.BorderThickness = new Thickness(1.0);
		border3.Padding = new Thickness(10.0);
		border3.Focusable = true;
		border3.Effect = new DropShadowEffect
		{
			BlurRadius = 14.0,
			ShadowDepth = 4.0,
			Opacity = 0.35,
			Color = Colors.Black
		};
		border3.Child = child;
		border3.SetResourceReference(Border.BackgroundProperty, "PanelBrush");
		border3.SetResourceReference(Border.BorderBrushProperty, "StrokeBrush");
		border3.KeyDown += delegate(object s, KeyEventArgs e)
		{
			if (e.Key == Key.Escape || e.Key == Key.Return)
			{
				base.IsOpen = false;
			}
		};
		return border3;
	}

	private void UpdateFromSv(Point p)
	{
		_s = MathX.Clamp(p.X / 220.0, 0.0, 1.0);
		_v = 1.0 - MathX.Clamp(p.Y / 132.0, 0.0, 1.0);
		Commit(ThemeManager.FromHsv(_h, _s, _v), updateHexBox: true);
	}

	private void UpdateFromHue(Point p)
	{
		_h = MathX.Clamp(p.X / 220.0, 0.0, 1.0) * 360.0;
		Commit(ThemeManager.FromHsv(_h, _s, _v), updateHexBox: true);
	}

	private void SetColor(Color c, bool updateHexBox)
	{
		var (h, num, v) = ThemeManager.ToHsv(c);
		if (num > 0.001)
		{
			_h = h;
		}
		_s = num;
		_v = v;
		Commit(c, updateHexBox);
	}

	private void Commit(Color c, bool updateHexBox)
	{
		SelectedColor = c;
		_hueBase.Fill = new SolidColorBrush(ThemeManager.FromHsv(_h, 1.0, 1.0));
		_preview.Background = new SolidColorBrush(c);
		_svThumb.Fill = new SolidColorBrush(c);
		Canvas.SetLeft(_svThumb, _s * 220.0 - 6.0);
		Canvas.SetTop(_svThumb, (1.0 - _v) * 132.0 - 6.0);
		Canvas.SetLeft(_hueThumb, _h / 360.0 * 220.0 - 2.5);
		if (updateHexBox)
		{
			_syncing = true;
			_hexBox.Text = ThemeManager.ToHex(c);
			_syncing = false;
		}
		ColorChanged?.Invoke(c);
	}
}
