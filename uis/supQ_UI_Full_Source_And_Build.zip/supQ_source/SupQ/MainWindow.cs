using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace supQ;

public partial class MainWindow : Window, IComponentConnector, IStyleConnector
{
	private enum InjectState
	{
		Idle,
		Loading,
		Injected,
		Failed
	}

	public sealed class FontChoice
	{
		public string DisplayName { get; init; } = "";

		public string Key { get; init; } = "";

		public FontFamily Family { get; init; } = new FontFamily("Segoe UI");

		public string CssFamily { get; init; } = "";

		public string? FileName { get; init; }

		public override string ToString()
		{
			return DisplayName;
		}
	}

	internal enum LogLevel
	{
		Info,
		Warn,
		Error,
		Success,
		System
	}

	public class EditorTab : INotifyPropertyChanged
	{
		private string _header = "New Script";

		private string _content = "";

		private bool _isSelected;

		public string Header
		{
			get
			{
				return _header;
			}
			set
			{
				_header = value;
				OnPropertyChanged("Header");
			}
		}

		public string Content
		{
			get
			{
				return _content;
			}
			set
			{
				_content = value;
				OnPropertyChanged("Content");
			}
		}

		public bool IsSelected
		{
			get
			{
				return _isSelected;
			}
			set
			{
				_isSelected = value;
				OnPropertyChanged("IsSelected");
			}
		}

		public event PropertyChangedEventHandler? PropertyChanged;

		protected void OnPropertyChanged(string name)
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		}
	}

	public class LogEntry : INotifyPropertyChanged
	{
		private Brush _color = Brushes.LightGray;

		public string Time { get; set; } = "";

		public string Text { get; set; } = "";

		public string Symbol { get; set; } = "";

		internal LogLevel Level { get; set; }

		public Brush Color
		{
			get
			{
				return _color;
			}
			set
			{
				if (_color != value)
				{
					_color = value;
					PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Color"));
				}
			}
		}

		public event PropertyChangedEventHandler? PropertyChanged;
	}

	private static readonly HttpClient httpClient = CreateHttpClient();

	private double _lastFinderWidth = 220.0;

	private bool _finderCollapsedByUser;

	private double _lastConsoleHeight = 200.0;

	private bool _consoleCollapsed = true;

	private int _editorFontSize = 14;

	private InjectState _injectState;

	private DoubleAnimation? _spinnerAnimation;

	private Process? _injectorProcess;

	private CancellationTokenSource? _injectPollCts;

	private readonly ObservableCollection<LogEntry> _consoleLog = new ObservableCollection<LogEntry>();

	private ICollectionView? _consoleView;

	private string _consoleFilter = "";

	private readonly AppSettings _settings = AppSettings.Load();

	private CancellationTokenSource? _hubLoadCts;

	private List<ScriptHubItem> _hubItems = new List<ScriptHubItem>();

	private readonly List<FontChoice> _uiFontChoices = new List<FontChoice>();

	private readonly List<FontChoice> _editorFontChoices = new List<FontChoice>();

	private const string RobloxMcpDirectory = "C:\\Users\\supquarter\\Documents\\roblox-executor-mcp";

	private const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;

	private const int DWMWCP_ROUND = 2;

	private DispatcherTimer? _injectWatchdog;

	private CancellationTokenSource? _consoleTailCts;

	private static readonly (string Name, string Body)[] BundledStarterScripts = new(string, string)[1] { ("saveinstance.luau", "-- supQ: saveinstance\n-- Saves the current place as <PlaceName>.rbxm in supQ's workspace folder\n-- (%APPDATA%\\supQ\\workspace), the same folder the Finder's Workspace tab\n-- lists. writefile is sandboxed to that folder by the module, so the file\n-- lands there no matter what path the saver is given.\nlocal ok, mod = pcall(function()\n    local src = game:HttpGet(\"https://raw.githubusercontent.com/luau/SynSaveInstance/main/saveinstance.luau\")\n    return assert(loadstring(src, \"=saveinstance\"))()\nend)\nif not ok or type(mod) ~= \"function\" then\n    warn(\"saveinstance bootstrap failed: \" .. tostring(mod))\n    return\nend\ngetgenv().saveinstance = mod\ngetgenv().saveplace    = mod\n\n-- File name: the place's own name, minus anything Windows rejects in a path.\nlocal placeName = \"place_\" .. tostring(game.PlaceId)\nlocal okName, info = pcall(function()\n    return game:GetService(\"MarketplaceService\"):GetProductInfo(game.PlaceId)\nend)\nif okName and type(info) == \"table\" and type(info.Name) == \"string\" and info.Name ~= \"\" then\n    placeName = info.Name\nend\nplaceName = placeName:gsub('[<>:\"/\\\\|%?%*%c]', \"\"):gsub(\"^%s+\", \"\"):gsub(\"%s+$\", \"\")\nif placeName == \"\" then placeName = \"place_\" .. tostring(game.PlaceId) end\n\nlocal fileName = placeName .. \".rbxm\"\n\n-- Suppress the \"don't rejoin\" prompt by silencing messagebox during the dump.\nlocal _mb = getgenv().messagebox\ngetgenv().messagebox = function() return 1 end\nlocal sok, serr = pcall(mod, {\n    FilePath = fileName,  -- an explicit extension is kept as-is by the saver\n    IsModel  = true,      -- model serialization, so .rbxm is the right container\n    mode     = \"full\",    -- \"optimized\" is incompatible with model mode\n})\ngetgenv().messagebox = _mb\n\nif not sok then\n    warn(\"saveinstance failed: \" .. tostring(serr))\n    return\nend\nprint(\"[supQ] saved \" .. fileName .. \" to the workspace folder\")\n") };

	private static readonly Dictionary<string, string[]> BundledScriptHistory = new Dictionary<string, string[]> { ["saveinstance.luau"] = new string[1] { "-- supQ: saveinstance\n-- Dumps the current place to the /workspace folder next to supQ.exe\n-- (same directory as the injector and the module) as <PlaceName>.rbxlx.\nlocal ok, mod = pcall(function()\n    local src = game:HttpGet(\"https://raw.githubusercontent.com/luau/SynSaveInstance/main/saveinstance.luau\")\n    return assert(loadstring(src, \"=saveinstance\"))()\nend)\nif not ok or type(mod) ~= \"function\" then\n    warn(\"saveinstance bootstrap failed: \" .. tostring(mod))\n    return\nend\ngetgenv().saveinstance = mod\ngetgenv().saveplace    = mod\n\n-- Suppress the \"don't rejoin\" prompt by silencing messagebox during the dump.\nlocal _mb = getgenv().messagebox\ngetgenv().messagebox = function() return 1 end\nlocal sok, serr = pcall(mod)\ngetgenv().messagebox = _mb\n\nif not sok then\n    warn(\"saveinstance failed: \" .. tostring(serr))\n    return\nend\nprint(\"[supQ] saveinstance finished. Check the /workspace folder next to supQ.exe\")\n" } };

	private static readonly IEasingFunction _slideEase = new CubicEase
	{
		EasingMode = EasingMode.EaseOut
	};

	private const int SlideDurationMs = 180;

	private EventHandler? _colTick;

	private EventHandler? _rowTick;

	private bool _sessionSaved;

	private static readonly string[] RobloxProcessNames = new string[4] { "RobloxPlayerBeta", "RobloxPlayerBeta_x64", "RobloxPlayer", "Windows10Universal" };

	private bool _launching;

	private bool _elevatedRetryDone;

	private MediaPlayer? _mossadPlayer;

	private bool _isMutedMossadAudio;

	private bool _restoringSettings;

	private Theme _draft = ThemeManager.Builtin[0];

	private Theme? _themeBeforeEdit;

	private string? _editingOriginalName;

	private bool _editorSyncing;

	private readonly Dictionary<string, (Border Swatch, TextBox Hex)> _slotRows = new Dictionary<string, (Border, TextBox)>();

	private ColorPickerPopup? _openPicker;

	private static readonly (string Header, string[] Slots)[] SlotGroups = new(string, string[])[5]
	{
		("ACCENT", new string[5] { "Accent", "AccentBright", "AccentDim", "AccentSubtle", "AccentBorder" }),
		("WINDOW BACKGROUND", new string[3] { "BgTop", "BgMid", "BgBottom" }),
		("SURFACES", new string[5] { "TitleBar", "Rail", "Panel", "Surface", "SurfaceRaised" }),
		("LINES", new string[2] { "Stroke", "StrokeSoft" }),
		("TEXT", new string[3] { "TextBright", "TextMuted", "TextDim" })
	};

	private static readonly Dictionary<string, (string Label, string Hint)> SlotInfo = new Dictionary<string, (string, string)>
	{
		["Accent"] = ("Accent", "Primary accent — Run button, indicators, focus rings."),
		["AccentBright"] = ("Accent bright", "Hover and glow variant of the accent."),
		["AccentDim"] = ("Accent dim", "Pressed and de-emphasised accent."),
		["AccentSubtle"] = ("Accent tint", "Soft accent wash behind badges and selected rows."),
		["AccentBorder"] = ("Accent border", "Accent-tinted outlines on hover."),
		["BgTop"] = ("Gradient top", "Top-left stop of the window background gradient."),
		["BgMid"] = ("Gradient middle", "Middle stop of the window background gradient."),
		["BgBottom"] = ("Gradient bottom", "Bottom-right stop; also the solid window base."),
		["TitleBar"] = ("Title bar", "The 46px caption strip."),
		["Rail"] = ("Nav rail", "Left icon rail and the status strips."),
		["Panel"] = ("Panel", "Finder sidebar and dialog backgrounds."),
		["Surface"] = ("Surface", "Cards, dropdowns and input backgrounds."),
		["SurfaceRaised"] = ("Raised surface", "Buttons, hover fills and the tab strip."),
		["Stroke"] = ("Border", "Card and control outlines."),
		["StrokeSoft"] = ("Soft border", "Hairlines and separators."),
		["TextBright"] = ("Text", "Primary text colour."),
		["TextMuted"] = ("Text muted", "Secondary labels and subtitles."),
		["TextDim"] = ("Text dim", "Placeholders and disabled text.")
	};

	private ObservableCollection<EditorTab> EditorTabs { get; set; } = new ObservableCollection<EditorTab>();

	private EditorTab? SelectedTab { get; set; }

	private static HttpClient CreateHttpClient()
	{
		HttpClient obj = new HttpClient();
		obj.DefaultRequestHeaders.UserAgent.ParseAdd("supQ/1.0 (+https://github.com/YuB-X)");
		obj.DefaultRequestHeaders.Accept.ParseAdd("application/json");
		obj.Timeout = TimeSpan.FromSeconds(15.0);
		return obj;
	}

	public MainWindow()
	{
		InitializeComponent();
		ThemeManager.Apply(ThemeManager.ByName(_settings.ThemeName));
		RestoreTabSession();
		SetupFontSelectors();
		InitializeMonaco();
		SetupConsole();
		SetupThemeSwatches();
		SetupSpinner();
		base.StateChanged += delegate
		{
			RootShell.Margin = ((base.WindowState == WindowState.Maximized) ? new Thickness(7.0) : new Thickness(0.0));
		};
		base.Loaded += MainWindow_Loaded;
		base.Closing += MainWindow_Closing;
		base.SourceInitialized += delegate
		{
			TryEnableRoundedCorners();
		};
	}

	[DllImport("dwmapi.dll")]
	private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);

	private void TryEnableRoundedCorners()
	{
		try
		{
			WindowInteropHelper windowInteropHelper = new WindowInteropHelper(this);
			int val = 2;
			DwmSetWindowAttribute(windowInteropHelper.Handle, 33, ref val, 4);
		}
		catch
		{
		}
	}

	private void MainWindow_Loaded(object sender, RoutedEventArgs e)
	{
		RestoreSettings();
		PlayIntroAnimationAsync();
		SetConsoleCollapsed(collapsed: true);
		UpdateChromeForTheme(ThemeManager.Current);
		EnsureBundledScripts();
		LoadLocalScriptsList();
		LoadHubScriptsAsync();
		StartRobloxConsoleTail();
		AppendConsole("supQ ready. Click Attach to connect to Roblox.", LogLevel.System);
		StartInjectionWatchdog();
	}

	private async Task PlayIntroAnimationAsync()
	{
		if (IntroOverlay != null && ContentRoot != null)
		{
			ContentRoot.Opacity = 0.0;
			IntroOverlay.Opacity = 1.0;
			IntroLockup.Opacity = 0.0;
			IntroLockupTranslate.Y = 8.0;
			IntroProgressScale.ScaleX = 0.0;
			CubicEase ease = new CubicEase
			{
				EasingMode = EasingMode.EaseOut
			};
			IntroLockup.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(220.0))
			{
				EasingFunction = ease
			});
			IntroLockupTranslate.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(8.0, 0.0, TimeSpan.FromMilliseconds(280.0))
			{
				EasingFunction = ease
			});
			IntroProgressScale.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(560.0))
			{
				EasingFunction = ease
			});
			await Task.Delay(640);
			DoubleAnimation animation = new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(240.0))
			{
				EasingFunction = ease
			};
			ContentRoot.BeginAnimation(UIElement.OpacityProperty, animation);
			DoubleAnimation doubleAnimation = new DoubleAnimation(1.0, 0.0, TimeSpan.FromMilliseconds(220.0));
			doubleAnimation.Completed += delegate
			{
				IntroOverlay.Visibility = Visibility.Collapsed;
				IntroOverlay.IsHitTestVisible = false;
			};
			IntroOverlay.BeginAnimation(UIElement.OpacityProperty, doubleAnimation);
		}
	}

	private void StartInjectionWatchdog()
	{
		_injectWatchdog = new DispatcherTimer
		{
			Interval = TimeSpan.FromSeconds(5.0)
		};
		_injectWatchdog.Tick += async delegate
		{
			if (_injectState == InjectState.Injected && !(await IsPortOpenAsync("127.0.0.1", 6969, TimeSpan.FromMilliseconds(400.0))) && _injectState == InjectState.Injected)
			{
				AppendConsole("Port 6969 no longer responds — Roblox closed or executor unloaded.", LogLevel.Warn);
				SetInjectState(InjectState.Idle);
			}
		};
		_injectWatchdog.Start();
	}

	private void StartRobloxConsoleTail()
	{
		_consoleTailCts?.Cancel();
		_consoleTailCts = new CancellationTokenSource();
		CancellationToken token = _consoleTailCts.Token;
		string[] logPaths = AppPaths.RobloxConsoleLogs;
		string[] array = logPaths;
		foreach (string path in array)
		{
			try
			{
				string directoryName = System.IO.Path.GetDirectoryName(path);
				if (!string.IsNullOrEmpty(directoryName) && !Directory.Exists(directoryName))
				{
					Directory.CreateDirectory(directoryName);
				}
			}
			catch
			{
			}
		}
		Task.Run(async delegate
		{
			Dictionary<string, long> cursors = logPaths.ToDictionary((string p) => p, delegate(string fileName)
			{
				try
				{
					return new FileInfo(fileName).Length;
				}
				catch
				{
					return 0L;
				}
			});
			Dictionary<string, string> partials = logPaths.ToDictionary((string p) => p, (string _) => (string)null);
			Dictionary<string, Decoder> decoders = logPaths.ToDictionary((string p) => p, (string _) => new UTF8Encoding(encoderShouldEmitUTF8Identifier: false).GetDecoder());
			while (!token.IsCancellationRequested)
			{
				string[] array2 = logPaths;
				foreach (string text in array2)
				{
					try
					{
						if (File.Exists(text))
						{
							FileInfo fileInfo = new FileInfo(text);
							if (fileInfo.Length < cursors[text])
							{
								cursors[text] = 0L;
								partials[text] = null;
								decoders[text].Reset();
							}
							if (fileInfo.Length > cursors[text])
							{
								using FileStream fileStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
								fileStream.Seek(cursors[text], SeekOrigin.Begin);
								byte[] array3 = new byte[(int)Math.Min(fileInfo.Length - cursors[text], 1048576L)];
								int num2 = fileStream.Read(array3, 0, array3.Length);
								if (num2 > 0)
								{
									cursors[text] += num2;
									Decoder decoder = decoders[text];
									char[] array4 = new char[decoder.GetCharCount(array3, 0, num2, flush: false)];
									int chars = decoder.GetChars(array3, 0, num2, array4, 0, flush: false);
									string text2 = new string(array4, 0, chars);
									if (partials[text] != null)
									{
										text2 = partials[text] + text2;
										partials[text] = null;
									}
									int num3 = 0;
									for (int num4 = 0; num4 < text2.Length; num4++)
									{
										if (text2[num4] == '\n')
										{
											string text3 = text2.Substring(num3, num4 - num3).TrimEnd('\r');
											if (!string.IsNullOrEmpty(text3))
											{
												EmitTailedLine(text3);
											}
											num3 = num4 + 1;
										}
									}
									if (num3 < text2.Length)
									{
										partials[text] = text2.Substring(num3);
									}
								}
							}
						}
					}
					catch
					{
					}
				}
				try
				{
					await Task.Delay(200, token);
				}
				catch (TaskCanceledException)
				{
					break;
				}
			}
		}, token);
	}

	private void EmitTailedLine(string line)
	{
		string text = line;
		LogLevel level = LogLevel.Info;
		string[] array = line.Split(new char[1] { '\t' }, 3);
		if (array.Length == 3)
		{
			text = array[2];
			string text2 = array[0];
			LogLevel logLevel = ((text2 == "W") ? LogLevel.Warn : ((text2 == "E") ? LogLevel.Error : LogLevel.Info));
			level = logLevel;
		}
		base.Dispatcher.Invoke(delegate
		{
			AppendRobloxLine(text, level);
		});
	}

	private void EnsureBundledScripts()
	{
		try
		{
			string scripts = AppPaths.Scripts;
			if (!Directory.Exists(scripts))
			{
				Directory.CreateDirectory(scripts);
			}
			(string, string)[] bundledStarterScripts = BundledStarterScripts;
			for (int i = 0; i < bundledStarterScripts.Length; i++)
			{
				(string, string) tuple = bundledStarterScripts[i];
				string item = tuple.Item1;
				string item2 = tuple.Item2;
				string p = System.IO.Path.Combine(scripts, item);
				string[] value;
				if (!File.Exists(p))
				{
					File.WriteAllText(p, item2);
				}
				else if (BundledScriptHistory.TryGetValue(item, out value) && value.Any((string old) => SameScriptBody(File.ReadAllText(p), old)))
				{
					File.WriteAllText(p, item2);
				}
			}
		}
		catch (Exception)
		{
		}
	}

	private static bool SameScriptBody(string a, string b)
	{
		return a.Replace("\r\n", "\n").TrimEnd() == b.Replace("\r\n", "\n").TrimEnd();
	}

	private void MinimizeWindow_Click(object sender, RoutedEventArgs e)
	{
		base.WindowState = WindowState.Minimized;
	}

	private void MaximizeWindow_Click(object sender, RoutedEventArgs e)
	{
		base.WindowState = ((base.WindowState != WindowState.Maximized) ? WindowState.Maximized : WindowState.Normal);
	}

	private void CloseWindow_Click(object sender, RoutedEventArgs e)
	{
		Close();
	}

	private void TransitionToView(Grid targetView, params Grid[] otherViews)
	{
		if (targetView == null)
		{
			return;
		}
		foreach (Grid grid in otherViews)
		{
			if (grid != null && grid.Visibility == Visibility.Visible)
			{
				grid.Visibility = Visibility.Collapsed;
			}
		}
		targetView.Visibility = Visibility.Visible;
		targetView.Opacity = 0.0;
		TranslateTransform translateTransform = targetView.RenderTransform as TranslateTransform;
		if (translateTransform == null)
		{
			translateTransform = (TranslateTransform)(targetView.RenderTransform = new TranslateTransform(0.0, 0.0));
		}
		translateTransform.Y = 12.0;
		DoubleAnimation animation = new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(220.0))
		{
			EasingFunction = new CubicEase
			{
				EasingMode = EasingMode.EaseOut
			}
		};
		DoubleAnimation animation2 = new DoubleAnimation(12.0, 0.0, TimeSpan.FromMilliseconds(220.0))
		{
			EasingFunction = new CubicEase
			{
				EasingMode = EasingMode.EaseOut
			}
		};
		targetView.BeginAnimation(UIElement.OpacityProperty, animation);
		translateTransform.BeginAnimation(TranslateTransform.YProperty, animation2);
	}

	private void TabButton_Checked(object sender, RoutedEventArgs e)
	{
		if (EditorGrid == null || ScriptHubGrid == null || SettingsGrid == null)
		{
			return;
		}
		if (EditorTabButton.IsChecked == true)
		{
			TransitionToView(EditorGrid, ScriptHubGrid, SettingsGrid);
			LoadLocalScriptsList();
			SetEditorFontSizeAsync(_editorFontSize);
			SetEditorThemeAsync(ThemeManager.Current);
			if (FinderExpandButton != null)
			{
				FinderExpandButton.Visibility = ((!_finderCollapsedByUser) ? Visibility.Collapsed : Visibility.Visible);
			}
		}
		else if (HubTabButton.IsChecked == true)
		{
			TransitionToView(ScriptHubGrid, EditorGrid, SettingsGrid);
			if (FinderExpandButton != null)
			{
				FinderExpandButton.Visibility = Visibility.Collapsed;
			}
			LoadHubScriptsAsync();
		}
		else if (SettingsTabButton.IsChecked == true)
		{
			TransitionToView(SettingsGrid, EditorGrid, ScriptHubGrid);
			if (FinderExpandButton != null)
			{
				FinderExpandButton.Visibility = Visibility.Collapsed;
			}
		}
	}

	private void ShowFinder()
	{
		if (FinderColumn != null)
		{
			if (FinderSplitter != null)
			{
				FinderSplitter.Visibility = Visibility.Visible;
			}
			if (FinderPanel != null)
			{
				FinderPanel.Visibility = Visibility.Visible;
			}
			if (FinderExpandButton != null)
			{
				FinderExpandButton.Visibility = Visibility.Collapsed;
			}
			double to = ((_lastFinderWidth > 80.0) ? _lastFinderWidth : 230.0);
			AnimateColumnWidth(FinderColumn, FinderColumn.Width.Value, to);
		}
	}

	private void HideFinder(bool rememberUserChoice)
	{
		if (FinderColumn == null)
		{
			return;
		}
		if (FinderColumn.Width.Value > 0.0)
		{
			_lastFinderWidth = FinderColumn.Width.Value;
		}
		AnimateColumnWidth(FinderColumn, FinderColumn.Width.Value, 0.0, delegate
		{
			if (FinderSplitter != null)
			{
				FinderSplitter.Visibility = Visibility.Collapsed;
			}
			if (FinderPanel != null)
			{
				FinderPanel.Visibility = Visibility.Collapsed;
			}
		});
		if (rememberUserChoice && FinderExpandButton != null)
		{
			RadioButton editorTabButton = EditorTabButton;
			if (editorTabButton != null && editorTabButton.IsChecked == true)
			{
				FinderExpandButton.Visibility = Visibility.Visible;
			}
		}
	}

	private void AnimateColumnWidth(ColumnDefinition col, double from, double to, Action? onDone = null)
	{
		if (col == null)
		{
			return;
		}
		if (_colTick != null)
		{
			CompositionTarget.Rendering -= _colTick;
			_colTick = null;
		}
		Stopwatch sw = Stopwatch.StartNew();
		_colTick = delegate
		{
			double num = Math.Min(1.0, (double)sw.ElapsedMilliseconds / 180.0);
			double num2 = _slideEase.Ease(num);
			col.Width = new GridLength(from + (to - from) * num2);
			if (num >= 1.0)
			{
				CompositionTarget.Rendering -= _colTick;
				_colTick = null;
				col.Width = new GridLength(to);
				onDone?.Invoke();
			}
		};
		CompositionTarget.Rendering += _colTick;
	}

	private void AnimateRowHeight(RowDefinition row, double from, double to, Action? onDone = null)
	{
		if (row == null)
		{
			return;
		}
		if (_rowTick != null)
		{
			CompositionTarget.Rendering -= _rowTick;
			_rowTick = null;
		}
		Stopwatch sw = Stopwatch.StartNew();
		_rowTick = delegate
		{
			double num = Math.Min(1.0, (double)sw.ElapsedMilliseconds / 180.0);
			double num2 = _slideEase.Ease(num);
			row.Height = new GridLength(from + (to - from) * num2);
			if (num >= 1.0)
			{
				CompositionTarget.Rendering -= _rowTick;
				_rowTick = null;
				row.Height = new GridLength(to);
				onDone?.Invoke();
			}
		};
		CompositionTarget.Rendering += _rowTick;
	}

	private void FinderToggle_Click(object sender, RoutedEventArgs e)
	{
		if (FinderColumn != null)
		{
			if (FinderColumn.Width.Value > 0.0)
			{
				_finderCollapsedByUser = true;
				HideFinder(rememberUserChoice: true);
			}
			else
			{
				_finderCollapsedByUser = false;
				ShowFinder();
			}
		}
	}

	private void SettingsShortcut_Click(object sender, RoutedEventArgs e)
	{
		SettingsTabButton.IsChecked = true;
	}

	private void FinderCategory_Checked(object sender, RoutedEventArgs e)
	{
		if (FinderScriptsContent != null && FinderWorkspaceContent != null && FinderAutoExecContent != null)
		{
			if (FinderScriptsTab.IsChecked == true)
			{
				FinderScriptsContent.Visibility = Visibility.Visible;
				FinderWorkspaceContent.Visibility = Visibility.Collapsed;
				FinderAutoExecContent.Visibility = Visibility.Collapsed;
				LoadLocalScriptsList();
			}
			else if (FinderWorkspaceTab.IsChecked == true)
			{
				FinderScriptsContent.Visibility = Visibility.Collapsed;
				FinderWorkspaceContent.Visibility = Visibility.Visible;
				FinderAutoExecContent.Visibility = Visibility.Collapsed;
				LoadWorkspaceList();
			}
			else if (FinderAutoExecTab.IsChecked == true)
			{
				FinderScriptsContent.Visibility = Visibility.Collapsed;
				FinderWorkspaceContent.Visibility = Visibility.Collapsed;
				FinderAutoExecContent.Visibility = Visibility.Visible;
				LoadAutoExecList();
			}
		}
	}

	private void LoadLocalScriptsList()
	{
		try
		{
			string scripts = AppPaths.Scripts;
			if (!Directory.Exists(scripts))
			{
				Directory.CreateDirectory(scripts);
			}
			LocalScriptsStack.Children.Clear();
			string[] files = Directory.GetFiles(scripts, "*.*", SearchOption.TopDirectoryOnly);
			foreach (string file in files)
			{
				string text = System.IO.Path.GetExtension(file).ToLower();
				if (text != ".lua" && text != ".luau" && text != ".txt")
				{
					continue;
				}
				string fileName = System.IO.Path.GetFileName(file);
				Border border = new Border
				{
					Background = Brushes.Transparent,
					CornerRadius = new CornerRadius(6.0),
					Padding = new Thickness(11.0, 8.0, 11.0, 8.0),
					Margin = new Thickness(0.0, 1.0, 0.0, 2.0),
					Cursor = Cursors.Hand
				};
				SolidColorBrush idleFg = new SolidColorBrush(ThemeManager.Current.TextMuted);
				SolidColorBrush hoverFg = new SolidColorBrush(ThemeManager.Current.TextBright);
				SolidColorBrush hoverBg = new SolidColorBrush(ThemeManager.Current.SurfaceRaised);
				TextBlock textBlock = new TextBlock
				{
					Text = fileName,
					Foreground = idleFg,
					FontSize = 12.5,
					FontWeight = FontWeights.Medium
				};
				border.Child = textBlock;
				border.MouseLeftButtonDown += async delegate
				{
					try
					{
						string fileContent = File.ReadAllText(file);
						if (SelectedTab != null)
						{
							await SetEditorTextAsync(fileContent);
							SelectedTab.Content = fileContent;
							SelectedTab.Header = fileName;
						}
					}
					catch (Exception ex2)
					{
						MessageBox.Show("Failed to read script file: " + ex2.Message, "supQ Error", MessageBoxButton.OK, MessageBoxImage.Hand);
					}
				};
				border.MouseEnter += delegate
				{
					border.Background = hoverBg;
					textBlock.Foreground = hoverFg;
				};
				border.MouseLeave += delegate
				{
					border.Background = Brushes.Transparent;
					textBlock.Foreground = idleFg;
				};
				LocalScriptsStack.Children.Add(border);
			}
		}
		catch (Exception)
		{
		}
	}

	private void LoadWorkspaceList()
	{
		try
		{
			string text = AppPaths.EnsureDirectory(AppPaths.Workspace);
			if (WorkspacePathLabel != null)
			{
				WorkspacePathLabel.Text = ".\\workspace";
				WorkspacePathLabel.ToolTip = text + "\n\nWhere the injected executor reads and writes\n(writefile, saveinstance, …). Click to open it in Explorer.";
			}
			WorkspaceStack.Children.Clear();
			string[] directories = Directory.GetDirectories(text, "*", SearchOption.TopDirectoryOnly);
			string[] files = Directory.GetFiles(text, "*.*", SearchOption.TopDirectoryOnly);
			bool flag = false;
			string[] array = directories;
			foreach (string text2 in array)
			{
				flag = true;
				string fileName = System.IO.Path.GetFileName(text2);
				AddFinderEntry(WorkspaceStack, fileName, null, isFolder: true, text2);
			}
			array = files;
			foreach (string text3 in array)
			{
				flag = true;
				string fileName2 = System.IO.Path.GetFileName(text3);
				string text4 = System.IO.Path.GetExtension(text3).ToLower();
				bool openInEditor = text4 == ".lua" || text4 == ".luau" || text4 == ".txt";
				AddFinderEntry(WorkspaceStack, fileName2, text3, isFolder: false, text3, openInEditor);
			}
			WorkspaceEmptyState.Visibility = (flag ? Visibility.Collapsed : Visibility.Visible);
		}
		catch (Exception)
		{
		}
	}

	private void WorkspacePath_Click(object sender, MouseButtonEventArgs e)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = AppPaths.EnsureDirectory(AppPaths.Workspace),
				UseShellExecute = true
			});
		}
		catch (Exception)
		{
		}
	}

	private void LoadAutoExecList()
	{
		try
		{
			string autoExec = AppPaths.AutoExec;
			if (!Directory.Exists(autoExec))
			{
				Directory.CreateDirectory(autoExec);
			}
			AutoExecStack.Children.Clear();
			string[] files = Directory.GetFiles(autoExec, "*.*", SearchOption.TopDirectoryOnly);
			bool flag = false;
			string[] array = files;
			foreach (string text in array)
			{
				string text2 = System.IO.Path.GetExtension(text).ToLower();
				if (!(text2 != ".lua") || !(text2 != ".luau") || !(text2 != ".txt"))
				{
					flag = true;
					string fileName = System.IO.Path.GetFileName(text);
					AddFinderEntry(AutoExecStack, fileName, text, isFolder: false, text, openInEditor: true);
				}
			}
			AutoExecEmptyState.Visibility = (flag ? Visibility.Collapsed : Visibility.Visible);
		}
		catch (Exception)
		{
		}
	}

	private void AddFinderEntry(StackPanel parent, string label, string? filePath, bool isFolder, string fullPath, bool openInEditor = false)
	{
		Border border = new Border
		{
			Background = Brushes.Transparent,
			CornerRadius = new CornerRadius(6.0),
			Padding = new Thickness(11.0, 8.0, 11.0, 8.0),
			Margin = new Thickness(0.0, 1.0, 0.0, 2.0),
			Cursor = Cursors.Hand
		};
		SolidColorBrush idleFg = new SolidColorBrush(ThemeManager.Current.TextMuted);
		SolidColorBrush hoverFg = new SolidColorBrush(ThemeManager.Current.TextBright);
		SolidColorBrush hoverBg = new SolidColorBrush(ThemeManager.Current.SurfaceRaised);
		TextBlock textBlock = new TextBlock
		{
			Text = label,
			Foreground = idleFg,
			FontSize = 12.5,
			FontWeight = FontWeights.Medium
		};
		border.Child = textBlock;
		if (isFolder)
		{
			border.MouseLeftButtonDown += delegate
			{
				LoadSubdirectory(parent, fullPath);
			};
		}
		else if (openInEditor && filePath != null)
		{
			border.MouseLeftButtonDown += async delegate
			{
				await OpenScriptInTabAsync(filePath);
			};
		}
		border.MouseEnter += delegate
		{
			border.Background = hoverBg;
			textBlock.Foreground = hoverFg;
		};
		border.MouseLeave += delegate
		{
			border.Background = Brushes.Transparent;
			textBlock.Foreground = idleFg;
		};
		parent.Children.Add(border);
	}

	private async Task OpenScriptInTabAsync(string filePath)
	{
		_ = 1;
		try
		{
			string content = File.ReadAllText(filePath);
			string header = System.IO.Path.GetFileName(filePath);
			EditorTab editorTab = EditorTabs.FirstOrDefault((EditorTab t) => t.Header == header);
			if (editorTab != null)
			{
				editorTab.Content = content;
				await SwitchToTab(editorTab);
			}
			else
			{
				EditorTab editorTab2 = new EditorTab
				{
					Header = header,
					Content = content
				};
				EditorTabs.Add(editorTab2);
				await SwitchToTab(editorTab2);
			}
			SaveTabSession();
		}
		catch (Exception ex)
		{
			MessageBox.Show("Failed to read file: " + ex.Message, "supQ Error", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void LoadSubdirectory(StackPanel parent, string dirPath)
	{
		try
		{
			parent.Children.Clear();
			Border backBorder = new Border
			{
				Background = Brushes.Transparent,
				Padding = new Thickness(20.0, 6.0, 10.0, 6.0),
				Cursor = Cursors.Hand
			};
			SolidColorBrush backFg = new SolidColorBrush(ThemeManager.Current.TextMuted);
			SolidColorBrush backHoverFg = new SolidColorBrush(ThemeManager.Current.TextBright);
			SolidColorBrush backHoverBg = new SolidColorBrush(ThemeManager.Current.Surface);
			TextBlock backText = new TextBlock
			{
				Text = "←  Parent folder",
				Foreground = backFg,
				FontSize = 11.5
			};
			backBorder.Child = backText;
			backBorder.MouseLeftButtonDown += delegate
			{
				string directoryName = System.IO.Path.GetDirectoryName(dirPath);
				string workspace = AppPaths.Workspace;
				if (directoryName != null && directoryName.StartsWith(workspace, StringComparison.OrdinalIgnoreCase))
				{
					LoadSubdirectory(parent, directoryName);
				}
				else
				{
					LoadWorkspaceList();
				}
			};
			backBorder.MouseEnter += delegate
			{
				backBorder.Background = backHoverBg;
				backText.Foreground = backHoverFg;
			};
			backBorder.MouseLeave += delegate
			{
				backBorder.Background = Brushes.Transparent;
				backText.Foreground = backFg;
			};
			parent.Children.Add(backBorder);
			string[] directories = Directory.GetDirectories(dirPath);
			foreach (string text in directories)
			{
				AddFinderEntry(parent, System.IO.Path.GetFileName(text), null, isFolder: true, text);
			}
			directories = Directory.GetFiles(dirPath);
			foreach (string text2 in directories)
			{
				string text3 = System.IO.Path.GetExtension(text2).ToLower();
				bool openInEditor = text3 == ".lua" || text3 == ".luau" || text3 == ".txt";
				AddFinderEntry(parent, System.IO.Path.GetFileName(text2), text2, isFolder: false, text2, openInEditor);
			}
		}
		catch (Exception)
		{
		}
	}

	private void FinderSearch_Click(object sender, RoutedEventArgs e)
	{
		if (ScriptHubGrid != null && ScriptHubGrid.Visibility == Visibility.Visible)
		{
			HubSearchBox.Focus();
		}
	}

	private async void TabItem_Click(object sender, MouseButtonEventArgs e)
	{
		if (sender is FrameworkElement { DataContext: EditorTab dataContext })
		{
			await SwitchToTab(dataContext);
		}
	}

	private async Task SwitchToTab(EditorTab targetTab)
	{
		if (SelectedTab != targetTab)
		{
			if (SelectedTab != null)
			{
				await SyncSelectedTabContentAsync();
				SelectedTab.IsSelected = false;
			}
			SelectedTab = targetTab;
			SelectedTab.IsSelected = true;
			await SetEditorTextAsync(SelectedTab.Content);
			AnimateEditorTabContent();
		}
	}

	private void AnimateEditorTabContent()
	{
		if (EditorContentHost != null)
		{
			CubicEase easingFunction = new CubicEase
			{
				EasingMode = EasingMode.EaseOut
			};
			EditorContentHost.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.55, 1.0, TimeSpan.FromMilliseconds(170.0))
			{
				EasingFunction = easingFunction
			});
			TranslateTransform translateTransform = EditorContentHost.RenderTransform as TranslateTransform;
			if (translateTransform == null)
			{
				translateTransform = new TranslateTransform();
				EditorContentHost.RenderTransform = translateTransform;
			}
			translateTransform.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(5.0, 0.0, TimeSpan.FromMilliseconds(180.0))
			{
				EasingFunction = easingFunction
			});
		}
	}

	private async Task SyncSelectedTabContentAsync()
	{
		if (SelectedTab == null)
		{
			return;
		}
		try
		{
			if (CodeEditorWebView?.CoreWebView2 != null)
			{
				string text = JsonConvert.DeserializeObject<string>(await CodeEditorWebView.ExecuteScriptAsync("getCode()"));
				if (text != null)
				{
					SelectedTab.Content = text;
				}
			}
		}
		catch
		{
		}
	}

	private void AddTab_Click(object sender, RoutedEventArgs e)
	{
		int n;
		for (n = 1; EditorTabs.Any((EditorTab t) => t.Header == $"Script #{n}"); n++)
		{
		}
		EditorTab editorTab = new EditorTab
		{
			Header = $"Script #{n}",
			Content = "-- New Tab\n",
			IsSelected = false
		};
		EditorTabs.Add(editorTab);
		SwitchToTab(editorTab).ContinueWith(delegate
		{
			base.Dispatcher.Invoke(SaveTabSession);
		}, TaskScheduler.FromCurrentSynchronizationContext());
	}

	private async void CloseTab_Click(object sender, RoutedEventArgs e)
	{
		if (!(sender is Button { DataContext: var dataContext }) || !(dataContext is EditorTab tab))
		{
			return;
		}
		int index = EditorTabs.IndexOf(tab);
		if (index == -1)
		{
			return;
		}
		if (SelectedTab == tab)
		{
			await SyncSelectedTabContentAsync();
		}
		await AnimateTabOutAsync(tab);
		EditorTabs.Remove(tab);
		if (SelectedTab == tab)
		{
			if (EditorTabs.Count > 0)
			{
				int index2 = Math.Min(index, EditorTabs.Count - 1);
				SelectedTab = null;
				await SwitchToTab(EditorTabs[index2]);
			}
			else
			{
				SelectedTab = null;
				await SetEditorTextAsync("");
			}
		}
		SaveTabSession();
	}

	private Task AnimateTabOutAsync(EditorTab tab)
	{
		if (!(EditorTabsList.ItemContainerGenerator.ContainerFromItem(tab) is FrameworkElement frameworkElement))
		{
			return Task.CompletedTask;
		}
		TaskCompletionSource<bool> done = new TaskCompletionSource<bool>();
		DoubleAnimation doubleAnimation = new DoubleAnimation(0.0, TimeSpan.FromMilliseconds(130.0))
		{
			EasingFunction = new CubicEase
			{
				EasingMode = EasingMode.EaseIn
			}
		};
		doubleAnimation.Completed += delegate
		{
			done.TrySetResult(result: true);
		};
		frameworkElement.BeginAnimation(UIElement.OpacityProperty, doubleAnimation);
		return done.Task;
	}

	private void RestoreTabSession()
	{
		TabSession tabSession = TabSession.Load();
		foreach (TabSession.TabRecord tab in tabSession.Tabs)
		{
			EditorTabs.Add(new EditorTab
			{
				Header = tab.Header,
				Content = tab.Content
			});
		}
		if (EditorTabs.Count == 0)
		{
			EditorTabs.Add(new EditorTab
			{
				Header = "Welcome",
				Content = "-- Welcome to supQ\nprint(\"Hello World!\")\n"
			});
		}
		SelectedTab = EditorTabs[MathX.Clamp(tabSession.SelectedIndex, 0, EditorTabs.Count - 1)];
		SelectedTab.IsSelected = true;
		EditorTabsList.ItemsSource = EditorTabs;
	}

	private void SaveTabSession()
	{
		TabSession tabSession = new TabSession
		{
			SelectedIndex = ((SelectedTab != null) ? Math.Max(0, EditorTabs.IndexOf(SelectedTab)) : 0)
		};
		foreach (EditorTab editorTab in EditorTabs)
		{
			tabSession.Tabs.Add(new TabSession.TabRecord
			{
				Header = editorTab.Header,
				Content = editorTab.Content
			});
		}
		tabSession.Save();
	}

	private async void MainWindow_Closing(object? sender, CancelEventArgs e)
	{
		if (!_sessionSaved)
		{
			e.Cancel = true;
			try
			{
				await SyncSelectedTabContentAsync();
				SaveTabSession();
			}
			catch (Exception)
			{
			}
			_sessionSaved = true;
			Close();
		}
	}

	private async void ToolbarRun_Click(object sender, RoutedEventArgs e)
	{
		await ExecuteScript(await GetEditorTextAsync());
	}

	private async void ToolbarClear_Click(object sender, RoutedEventArgs e)
	{
		await SetEditorTextAsync("");
		if (SelectedTab != null)
		{
			SelectedTab.Content = "";
		}
	}

	private void ToolbarOpen_Click(object sender, RoutedEventArgs e)
	{
		OpenFile();
	}

	private async void ToolbarSave_Click(object sender, RoutedEventArgs e)
	{
		SaveFile(await GetEditorTextAsync());
	}

	private void SetupConsole()
	{
		_consoleView = CollectionViewSource.GetDefaultView(_consoleLog);
		_consoleView.Filter = delegate(object obj)
		{
			if (!(obj is LogEntry logEntry))
			{
				return false;
			}
			return string.IsNullOrWhiteSpace(_consoleFilter) || logEntry.Text.IndexOf(_consoleFilter, StringComparison.OrdinalIgnoreCase) >= 0;
		};
		ConsoleItems.ItemsSource = _consoleView;
	}

	private static Brush Hx(string hex)
	{
		return (Brush)new BrushConverter().ConvertFromString(hex);
	}

	private static Brush BrushFor(LogLevel level)
	{
		bool isLight = ThemeManager.Current.IsLight;
		return level switch
		{
			LogLevel.Warn => isLight ? Hx("#9A6400") : Hx("#F5C048"), 
			LogLevel.Error => isLight ? Hx("#C02626") : Hx("#FA5D5D"), 
			LogLevel.Success => isLight ? Hx("#0E7A55") : Hx("#49D0A4"), 
			LogLevel.System => new SolidColorBrush(ThemeManager.Current.Accent), 
			_ => new SolidColorBrush(ThemeManager.Current.TextMuted), 
		};
	}

	private static string SymbolFor(LogLevel level)
	{
		return level switch
		{
			LogLevel.Warn => "⚠", 
			LogLevel.Error => "✕", 
			LogLevel.Success => "✓", 
			LogLevel.System => "◆", 
			_ => "•", 
		};
	}

	private void AppendConsole(string? text, LogLevel level = LogLevel.Info)
	{
		if (!string.IsNullOrEmpty(text))
		{
			if (base.Dispatcher.CheckAccess())
			{
				Do();
			}
			else
			{
				base.Dispatcher.Invoke(Do);
			}
		}
		void Do()
		{
			_consoleLog.Add(new LogEntry
			{
				Time = DateTime.Now.ToString("HH:mm:ss"),
				Text = text,
				Symbol = SymbolFor(level),
				Level = level,
				Color = BrushFor(level)
			});
			if (ConsoleLineCount != null)
			{
				ConsoleLineCount.Text = $"{_consoleLog.Count} lines";
			}
			if (ConsoleEmptyState != null)
			{
				ConsoleEmptyState.Visibility = ((_consoleLog.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
			}
			if (ConsoleScroll != null)
			{
				ConsoleScroll.Visibility = ((_consoleLog.Count == 0) ? Visibility.Collapsed : Visibility.Visible);
				ConsoleScroll.ScrollToBottom();
			}
		}
	}

	private void AppendRobloxLine(string text, LogLevel level)
	{
		if (!string.IsNullOrEmpty(text))
		{
			if (base.Dispatcher.CheckAccess())
			{
				Do();
			}
			else
			{
				base.Dispatcher.Invoke(Do);
			}
		}
		void Do()
		{
			_consoleLog.Add(new LogEntry
			{
				Time = DateTime.Now.ToString("HH:mm:ss"),
				Text = text,
				Symbol = SymbolFor(level),
				Level = level,
				Color = BrushFor(level)
			});
			if (ConsoleLineCount != null)
			{
				ConsoleLineCount.Text = $"{_consoleLog.Count} lines";
			}
			if (ConsoleEmptyState != null)
			{
				ConsoleEmptyState.Visibility = ((_consoleLog.Count != 0) ? Visibility.Collapsed : Visibility.Visible);
			}
			if (ConsoleScroll != null)
			{
				ConsoleScroll.Visibility = ((_consoleLog.Count == 0) ? Visibility.Collapsed : Visibility.Visible);
				ConsoleScroll.ScrollToBottom();
			}
		}
	}

	private void ClearConsole_Click(object sender, RoutedEventArgs e)
	{
		_consoleLog.Clear();
		if (ConsoleLineCount != null)
		{
			ConsoleLineCount.Text = "0 lines";
		}
		if (ConsoleEmptyState != null)
		{
			ConsoleEmptyState.Visibility = Visibility.Visible;
		}
		if (ConsoleScroll != null)
		{
			ConsoleScroll.Visibility = Visibility.Collapsed;
		}
	}

	private void ConsoleFilter_TextChanged(object sender, TextChangedEventArgs e)
	{
		_consoleFilter = (sender as TextBox)?.Text ?? "";
		_consoleView?.Refresh();
	}

	private void CollapseConsole_Click(object sender, RoutedEventArgs e)
	{
		SetConsoleCollapsed(!_consoleCollapsed);
	}

	private void ToggleConsole_Click(object sender, RoutedEventArgs e)
	{
		SetConsoleCollapsed(!_consoleCollapsed);
	}

	private void SetConsoleCollapsed(bool collapsed)
	{
		_consoleCollapsed = collapsed;
		bool isLoaded = base.IsLoaded;
		if (collapsed)
		{
			if (ConsoleRow.Height.Value > 0.0)
			{
				_lastConsoleHeight = ConsoleRow.Height.Value;
			}
			if (isLoaded)
			{
				AnimateRowHeight(ConsoleRow, ConsoleRow.Height.Value, 0.0, delegate
				{
					ConsoleSplitterRow.Height = new GridLength(0.0);
				});
			}
			else
			{
				ConsoleRow.Height = new GridLength(0.0);
				ConsoleSplitterRow.Height = new GridLength(0.0);
			}
			if (ConsoleChevron != null)
			{
				ConsoleChevron.Data = Geometry.Parse("M 6,15 L 12,9 L 18,15");
			}
		}
		else
		{
			double num = ((_lastConsoleHeight > 60.0) ? _lastConsoleHeight : 200.0);
			ConsoleSplitterRow.Height = GridLength.Auto;
			if (isLoaded)
			{
				AnimateRowHeight(ConsoleRow, ConsoleRow.Height.Value, num);
			}
			else
			{
				ConsoleRow.Height = new GridLength(num);
			}
			if (ConsoleChevron != null)
			{
				ConsoleChevron.Data = Geometry.Parse("M 6,9 L 12,15 L 18,9");
			}
		}
	}

	private void SetupSpinner()
	{
		_spinnerAnimation = new DoubleAnimation(0.0, 360.0, TimeSpan.FromSeconds(0.9))
		{
			RepeatBehavior = RepeatBehavior.Forever
		};
	}

	private void StartSpinner()
	{
		InjectSpinRotate?.BeginAnimation(RotateTransform.AngleProperty, _spinnerAnimation);
	}

	private void StopSpinner()
	{
		InjectSpinRotate?.BeginAnimation(RotateTransform.AngleProperty, null);
	}

	private void SetInjectState(InjectState state)
	{
		_injectState = state;
		InjectIconIdle.Visibility = Visibility.Collapsed;
		InjectIconSpinner.Visibility = Visibility.Collapsed;
		InjectIconCheck.Visibility = Visibility.Collapsed;
		StopSpinner();
		switch (state)
		{
		case InjectState.Idle:
			InjectIconIdle.Visibility = Visibility.Visible;
			InjectButtonLabel.Text = "Attach";
			InjectButton.ToolTip = "Attach / Inject to Roblox";
			InjectButton.IsEnabled = true;
			SetStatus("Not injected", "#FA5D5D");
			break;
		case InjectState.Loading:
			InjectIconSpinner.Visibility = Visibility.Visible;
			InjectButtonLabel.Text = "Attaching…";
			InjectButton.ToolTip = "Injecting…";
			InjectButton.IsEnabled = false;
			StartSpinner();
			SetStatus("Injecting…", "#F5C048");
			break;
		case InjectState.Injected:
		{
			InjectIconCheck.Visibility = Visibility.Visible;
			InjectButtonLabel.Text = "Attached";
			InjectButton.ToolTip = "Injected (Port 6969 Live)";
			InjectButton.IsEnabled = true;
			SetStatus("Injected", "#49D0A4");
			ScaleTransform scaleTransform = new ScaleTransform(0.4, 0.4);
			InjectIconCheck.RenderTransformOrigin = new Point(0.5, 0.5);
			InjectIconCheck.RenderTransform = scaleTransform;
			DoubleAnimation animation = new DoubleAnimation(0.4, 1.0, TimeSpan.FromMilliseconds(260.0))
			{
				EasingFunction = new BackEase
				{
					Amplitude = 0.45,
					EasingMode = EasingMode.EaseOut
				}
			};
			scaleTransform.BeginAnimation(ScaleTransform.ScaleXProperty, animation);
			scaleTransform.BeginAnimation(ScaleTransform.ScaleYProperty, animation);
			break;
		}
		case InjectState.Failed:
			InjectIconIdle.Visibility = Visibility.Visible;
			InjectButtonLabel.Text = "Retry attach";
			InjectButton.ToolTip = "Retry Injection (Failed)";
			InjectButton.IsEnabled = true;
			SetStatus("Injection failed", "#FA5D5D");
			break;
		}
	}

	private void SetStatus(string text, string colorHex)
	{
		if (StatusText != null)
		{
			StatusText.Text = text;
		}
		if (StatusCircle != null)
		{
			Brush brush = (Brush)new BrushConverter().ConvertFromString(colorHex);
			StatusCircle.Fill = brush;
			if (StatusCircle.Effect is DropShadowEffect dropShadowEffect && brush is SolidColorBrush solidColorBrush)
			{
				dropShadowEffect.Color = solidColorBrush.Color;
			}
			DoubleAnimation animation = new DoubleAnimation(0.3, 1.0, TimeSpan.FromMilliseconds(200.0))
			{
				EasingFunction = new CubicEase
				{
					EasingMode = EasingMode.EaseOut
				}
			};
			StatusCircle.BeginAnimation(UIElement.OpacityProperty, animation);
		}
	}

	private static int FindRobloxPid()
	{
		Process[] array = RobloxProcessNames.SelectMany(Process.GetProcessesByName).ToArray();
		try
		{
			Process[] array2 = array;
			foreach (Process process in array2)
			{
				if (process.MainWindowHandle != IntPtr.Zero)
				{
					return process.Id;
				}
			}
			int num = 0;
			array2 = array;
			foreach (Process process2 in array2)
			{
				if (num == 0)
				{
					num = process2.Id;
				}
				try
				{
					foreach (ProcessModule module in process2.Modules)
					{
						if (string.Equals(module.ModuleName, "RobloxPlayerBeta.dll", StringComparison.OrdinalIgnoreCase))
						{
							return process2.Id;
						}
					}
				}
				catch
				{
				}
			}
			return num;
		}
		finally
		{
			Process[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].Dispose();
			}
		}
	}

	private async void Attach_Click(object sender, RoutedEventArgs e)
	{
		if (_injectState == InjectState.Loading || _launching)
		{
			return;
		}
		_launching = true;
		try
		{
			int robloxPid = FindRobloxPid();
			bool flag = robloxPid > 0;
			if (flag)
			{
				flag = await IsPortOpenAsync("127.0.0.1", 6969, TimeSpan.FromMilliseconds(300.0));
			}
			if (flag)
			{
				AppendConsole("Already injected (port 6969 is live) — skipping re-inject.", LogLevel.Success);
				SetInjectState(InjectState.Injected);
				return;
			}
			Process[] processesByName = Process.GetProcessesByName("Injector");
			if (processesByName.Length != 0)
			{
				AppendConsole($"Cleaning up {processesByName.Length} duplicate Injector.exe instance(s) before starting...", LogLevel.Warn);
				Process[] array = processesByName;
				foreach (Process process in array)
				{
					try
					{
						process.Kill();
						process.WaitForExit(1000);
					}
					catch
					{
					}
					process.Dispose();
				}
			}
			string text = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Injector.exe");
			if (!File.Exists(text))
			{
				AppendConsole("Injector.exe was not found in the application directory.", LogLevel.Error);
				MessageBox.Show("Injector.exe was not found in the application directory. Place it in the directory to inject.", "supQ", MessageBoxButton.OK, MessageBoxImage.Hand);
				return;
			}
			if (robloxPid <= 0)
			{
				AppendConsole("No Roblox process matched by name — starting Injector.exe anyway.", LogLevel.Warn);
			}
			if ((AutoOpenConsoleToggle?.IsChecked == true) && _consoleCollapsed)
			{
				SetConsoleCollapsed(collapsed: false);
			}
			SetInjectState(InjectState.Loading);
			_elevatedRetryDone = false;
			AppendConsole((robloxPid > 0) ? $"Launching Injector.exe against Roblox PID {robloxPid}…" : "Launching Injector.exe…", LogLevel.System);
			if (StartInjector(text, robloxPid, elevated: false))
			{
				BeginInjectionPoll();
			}
			else
			{
				SetInjectState(InjectState.Failed);
			}
		}
		catch (Exception ex)
		{
			AppendConsole("Failed to launch Injector.exe: " + ex.Message, LogLevel.Error);
			SetInjectState(InjectState.Failed);
		}
		finally
		{
			_launching = false;
		}
	}

	private static bool IsElevated()
	{
		try
		{
			using WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent();
			return new WindowsPrincipal(ntIdentity).IsInRole(WindowsBuiltInRole.Administrator);
		}
		catch
		{
			return false;
		}
	}

	private bool StartInjector(string injectorPath, int robloxPid, bool elevated)
	{
		ProcessStartInfo processStartInfo = new ProcessStartInfo(injectorPath)
		{
			Arguments = ((robloxPid > 0) ? robloxPid.ToString() : string.Empty),
			WorkingDirectory = (System.IO.Path.GetDirectoryName(injectorPath) ?? AppDomain.CurrentDomain.BaseDirectory),
			UseShellExecute = elevated,
			CreateNoWindow = false
		};
		if (elevated)
		{
			processStartInfo.Verb = "runas";
		}
		try
		{
			_injectorProcess?.Dispose();
			_injectorProcess = new Process
			{
				StartInfo = processStartInfo,
				EnableRaisingEvents = true
			};
			_injectorProcess.Exited += delegate
			{
				base.Dispatcher.Invoke(delegate
				{
					int num = -1;
					try
					{
						num = _injectorProcess?.ExitCode ?? (-1);
					}
					catch
					{
					}
					AppendConsole($"Injector.exe exited (code {num}).", LogLevel.System);
				});
			};
			_injectorProcess.Start();
			return true;
		}
		catch (Win32Exception ex) when (!elevated && (ex.NativeErrorCode == 740 || ex.NativeErrorCode == 5))
		{
			AppendConsole("Injector.exe wants administrator rights — asking for elevation…", LogLevel.Warn);
			return StartInjector(injectorPath, robloxPid, elevated: true);
		}
		catch (Win32Exception ex2) when (ex2.NativeErrorCode == 1223)
		{
			AppendConsole("Elevation was declined — injection cancelled.", LogLevel.Error);
			return false;
		}
		catch (Exception ex3)
		{
			AppendConsole("Failed to launch Injector.exe: " + ex3.Message, LogLevel.Error);
			return false;
		}
	}

	private void OfferElevatedRetry()
	{
		if (_elevatedRetryDone || IsElevated())
		{
			return;
		}
		_elevatedRetryDone = true;
		if (MessageBox.Show("Injection didn't come through.\n\nRetry with administrator rights? Roblox usually needs them before the injector can attach.", "supQ", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
		{
			return;
		}
		string text = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Injector.exe");
		if (File.Exists(text))
		{
			AppendConsole("Retrying Injector.exe as administrator…", LogLevel.System);
			if (StartInjector(text, FindRobloxPid(), elevated: true))
			{
				BeginInjectionPoll();
			}
			else
			{
				SetInjectState(InjectState.Failed);
			}
		}
	}

	private void BeginInjectionPoll()
	{
		SetInjectState(InjectState.Loading);
		_injectPollCts?.Cancel();
		_injectPollCts = new CancellationTokenSource();
		PollForInjectionAsync(_injectPollCts.Token);
	}

	private async Task PollForInjectionAsync(CancellationToken token)
	{
		for (int i = 0; i < 60; i++)
		{
			if (token.IsCancellationRequested)
			{
				break;
			}
			if (await IsPortOpenAsync("127.0.0.1", 6969, TimeSpan.FromMilliseconds(400.0)))
			{
				base.Dispatcher.Invoke(delegate
				{
					AppendConsole("Port 6969 is live — injection confirmed.", LogLevel.Success);
					SetInjectState(InjectState.Injected);
				});
				await ConsoleBridge.SendAsync();
				return;
			}
			try
			{
				await Task.Delay(500, token);
			}
			catch (TaskCanceledException)
			{
				return;
			}
		}
		if (!token.IsCancellationRequested)
		{
			base.Dispatcher.Invoke(delegate
			{
				AppendConsole("Timed out waiting for port 6969.", LogLevel.Warn);
				SetInjectState(InjectState.Failed);
				OfferElevatedRetry();
			});
		}
	}

	private static async Task<bool> IsPortOpenAsync(string host, int port, TimeSpan timeout)
	{
		try
		{
			using TcpClient client = new TcpClient();
			Task connectTask = client.ConnectAsync(host, port);
			Task task = Task.Delay(timeout);
			return await Task.WhenAny(connectTask, task) == connectTask && client.Connected;
		}
		catch
		{
			return false;
		}
	}

	private void SettingToggle_Changed(object sender, RoutedEventArgs e)
	{
		PersistSettings();
	}

	private async Task ExecuteScript(string scriptText)
	{
		if (!string.IsNullOrEmpty(scriptText))
		{
			if (_injectState == InjectState.Injected)
			{
				await ConsoleBridge.SendAsync();
			}
			if (!(await ExploitExecutor.ExecuteScriptAsync(scriptText)))
			{
				AppendConsole("Script delivery failed — is the executor injected?", LogLevel.Error);
				MessageBox.Show("Failed to execute script. Ensure your Roblox executor is injected (6969 port listener is running).", "supQ", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}
	}

	private void OpenFile()
	{
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "Lua Files (*.lua;*.luau)|*.lua;*.luau|Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
			Title = "Open Script"
		};
		if (openFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			string text = File.ReadAllText(openFileDialog.FileName);
			SetEditorTextAsync(text);
			if (SelectedTab != null)
			{
				SelectedTab.Content = text;
				SelectedTab.Header = System.IO.Path.GetFileName(openFileDialog.FileName);
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show("Failed to read file: " + ex.Message, "supQ Error", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void SaveFile(string code)
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "Lua Files (*.lua;*.luau)|*.lua;*.luau|Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
			Title = "Save Script"
		};
		if (saveFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			File.WriteAllText(saveFileDialog.FileName, code);
			if (SelectedTab != null)
			{
				SelectedTab.Header = System.IO.Path.GetFileName(saveFileDialog.FileName);
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show("Failed to save file: " + ex.Message, "supQ Error", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private async void InitializeMonaco()
	{
		_ = 1;
		try
		{
			string text = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "supQ", "WebView2");
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(null, text);
			await CodeEditorWebView.EnsureCoreWebView2Async(environment);
			string folderPath = AppPaths.EnsureDirectory(AppPaths.Fonts);
			CodeEditorWebView.CoreWebView2.SetVirtualHostNameToFolderMapping("supq-fonts", folderPath, CoreWebView2HostResourceAccessKind.Allow);
			CodeEditorWebView.NavigationCompleted += async delegate
			{
				if (SelectedTab != null)
				{
					await SetEditorTextAsync(SelectedTab.Content);
				}
				await SetEditorFontSizeAsync(_editorFontSize);
				if (EditorFontDropdown?.SelectedItem is FontChoice editorFontAsync)
				{
					await SetEditorFontAsync(editorFontAsync);
				}
				await SetEditorThemeAsync(ThemeManager.Current);
				await CodeEditorWebView.ExecuteScriptAsync("if(typeof editor !== 'undefined') editor.layout();");
			};
			CodeEditorWebView.NavigateToString(GetMonacoHtml());
		}
		catch (Exception ex)
		{
			MessageBox.Show("Failed to initialize Monaco Editor: " + ex.Message + "\nEnsure Microsoft Edge WebView2 Runtime is installed.", "supQ Error", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private async Task<string> GetEditorTextAsync()
	{
		try
		{
			return JsonConvert.DeserializeObject<string>(await CodeEditorWebView.ExecuteScriptAsync("getCode()")) ?? string.Empty;
		}
		catch
		{
			return string.Empty;
		}
	}

	private async Task SetEditorTextAsync(string text)
	{
		try
		{
			string text2 = JsonConvert.SerializeObject(text);
			await CodeEditorWebView.ExecuteScriptAsync("setCode(" + text2 + ")");
		}
		catch (Exception)
		{
		}
	}

	private async Task SetEditorFontSizeAsync(int size)
	{
		try
		{
			if (CodeEditorWebView?.CoreWebView2 != null)
			{
				await CodeEditorWebView.ExecuteScriptAsync($"setFontSize({size})");
			}
		}
		catch
		{
		}
	}

	private async Task SetEditorFontAsync(FontChoice choice)
	{
		try
		{
			if (CodeEditorWebView?.CoreWebView2 != null)
			{
				string text = JsonConvert.SerializeObject(choice.CssFamily);
				string text2 = ((choice.FileName == null) ? "null" : JsonConvert.SerializeObject("https://supq-fonts/" + Uri.EscapeDataString(choice.FileName)));
				await CodeEditorWebView.ExecuteScriptAsync("setEditorFont(" + text + ", " + text2 + ")");
			}
		}
		catch (Exception)
		{
		}
	}

	private void SetupFontSelectors()
	{
		if (UIFontDropdown == null || EditorFontDropdown == null)
		{
			return;
		}
		bool restoringSettings = _restoringSettings;
		_restoringSettings = true;
		try
		{
			_uiFontChoices.Clear();
			_editorFontChoices.Clear();
			string[] array = new string[10] { "Segoe UI Variable Text", "Segoe UI", "Aptos", "Inter", "Arial", "Calibri", "Tahoma", "Verdana", "Trebuchet MS", "Georgia" };
			foreach (string name in array)
			{
				_uiFontChoices.Add(SystemFontChoice(name));
			}
			array = new string[8] { "Cascadia Code", "Cascadia Mono", "JetBrains Mono", "Fira Code", "Consolas", "Source Code Pro", "IBM Plex Mono", "Courier New" };
			foreach (string name2 in array)
			{
				_editorFontChoices.Add(SystemFontChoice(name2));
			}
			foreach (string item in from path in Directory.EnumerateFiles(AppPaths.EnsureDirectory(AppPaths.Fonts))
				where string.Equals(System.IO.Path.GetExtension(path), ".ttf", StringComparison.OrdinalIgnoreCase) || string.Equals(System.IO.Path.GetExtension(path), ".otf", StringComparison.OrdinalIgnoreCase)
				select path)
			{
				FontChoice fontChoice = TryCreateCustomFontChoice(item);
				if (fontChoice != null)
				{
					_uiFontChoices.Add(fontChoice);
					_editorFontChoices.Add(fontChoice);
				}
			}
			UIFontDropdown.ItemsSource = null;
			EditorFontDropdown.ItemsSource = null;
			UIFontDropdown.ItemsSource = _uiFontChoices;
			EditorFontDropdown.ItemsSource = _editorFontChoices;
			UIFontDropdown.SelectedItem = _uiFontChoices.FirstOrDefault((FontChoice font) => font.Key == _settings.UiFontKey) ?? _uiFontChoices.First();
			EditorFontDropdown.SelectedItem = _editorFontChoices.FirstOrDefault((FontChoice font) => font.Key == _settings.EditorFontKey) ?? _editorFontChoices.First();
			if (UIFontDropdown.SelectedItem is FontChoice fontChoice2)
			{
				base.FontFamily = fontChoice2.Family;
			}
		}
		finally
		{
			_restoringSettings = restoringSettings;
		}
	}

	private static FontChoice SystemFontChoice(string name)
	{
		return new FontChoice
		{
			DisplayName = name,
			Key = name,
			Family = new FontFamily(name),
			CssFamily = name
		};
	}

	private static FontChoice? TryCreateCustomFontChoice(string filePath)
	{
		try
		{
			string text = new GlyphTypeface(new Uri(filePath, UriKind.Absolute)).FamilyNames.Values.FirstOrDefault();
			if (string.IsNullOrWhiteSpace(text))
			{
				return null;
			}
			string uriString = System.IO.Path.GetDirectoryName(filePath) + System.IO.Path.DirectorySeparatorChar;
			return new FontChoice
			{
				DisplayName = text + " (Custom)",
				Key = "custom:" + System.IO.Path.GetFileName(filePath) + ":" + text,
				Family = new FontFamily(new Uri(uriString, UriKind.Absolute), "./#" + text),
				CssFamily = text,
				FileName = System.IO.Path.GetFileName(filePath)
			};
		}
		catch (Exception)
		{
			return null;
		}
	}

	private void UIFontDropdown_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		if (UIFontDropdown?.SelectedItem is FontChoice fontChoice)
		{
			base.FontFamily = fontChoice.Family;
			if (!_restoringSettings)
			{
				_settings.UiFontKey = fontChoice.Key;
				_settings.Save();
			}
		}
	}

	private void EditorFontDropdown_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		if (EditorFontDropdown?.SelectedItem is FontChoice fontChoice)
		{
			SetEditorFontAsync(fontChoice);
			if (!_restoringSettings)
			{
				_settings.EditorFontKey = fontChoice.Key;
				_settings.Save();
			}
		}
	}

	private void AddCustomFont_Click(object sender, RoutedEventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Title = "Add custom fonts",
			Filter = "Font files (*.ttf;*.otf)|*.ttf;*.otf",
			Multiselect = true
		};
		if (openFileDialog.ShowDialog() != true)
		{
			return;
		}
		int num = 0;
		List<string> list = new List<string>();
		string path = AppPaths.EnsureDirectory(AppPaths.Fonts);
		string[] fileNames = openFileDialog.FileNames;
		foreach (string text in fileNames)
		{
			try
			{
				string destFileName = System.IO.Path.Combine(path, System.IO.Path.GetFileName(text));
				File.Copy(text, destFileName, overwrite: true);
				num++;
			}
			catch (Exception ex)
			{
				list.Add(System.IO.Path.GetFileName(text) + ": " + ex.Message);
			}
		}
		SetupFontSelectors();
		if (num > 0)
		{
			AppendConsole(string.Format("Imported {0} custom font{1}.", num, (num == 1) ? "" : "s"), LogLevel.Success);
		}
		if (list.Count > 0)
		{
			MessageBox.Show(string.Join(Environment.NewLine, list), "Some fonts could not be imported", MessageBoxButton.OK, MessageBoxImage.Exclamation);
		}
	}

	private static string Hex(Color c)
	{
		return $"#{c.R:X2}{c.G:X2}{c.B:X2}";
	}

	private static string Syntax(Theme t, double hueShift, double sat, double val)
	{
		(double H, double S, double V) tuple = ThemeManager.ToHsv(t.Accent);
		var (num, _, _) = tuple;
		if (tuple.S < 0.1)
		{
			return Hex(ThemeManager.Mix(t.TextMuted, t.TextBright, MathX.Clamp((val - 0.5) * 2.0, 0.0, 1.0)));
		}
		if (!t.IsLight)
		{
			return Hex(ThemeManager.FromHsv(num + hueShift, sat, val));
		}
		return Hex(ThemeManager.FromHsv(num + hueShift, Math.Min(sat + 0.15, 1.0), 0.58));
	}

	private async Task SetEditorThemeAsync(Theme t)
	{
		try
		{
			if (CodeEditorWebView?.CoreWebView2 != null)
			{
				bool flag = t.Name == "Mossad";
				Dictionary<string, object> value = new Dictionary<string, object>
				{
					["bg"] = (flag ? "#00000000" : Hex(t.Surface)),
					["fg"] = Hex(t.TextBright),
					["lineBg"] = (flag ? "#00000000" : Hex(t.SurfaceRaised)),
					["sel"] = Hex(t.AccentDim),
					["isLight"] = t.IsLight,
					["lineNum"] = Hex(t.TextDim),
					["lineNumActive"] = Hex(t.AccentBright),
					["cursor"] = Hex(t.AccentBright),
					["keyword"] = Syntax(t, 0.0, 0.78, 0.98),
					["str"] = Syntax(t, 28.0, 0.62, 0.92),
					["number"] = Syntax(t, -26.0, 0.7, 0.96),
					["type"] = Syntax(t, 14.0, 0.45, 1.0),
					["comment"] = Hex(t.TextDim),
					["op"] = Hex(t.TextMuted),
					["ident"] = Hex(t.TextBright)
				};
				await CodeEditorWebView.ExecuteScriptAsync("applyEditorTheme(" + JsonConvert.SerializeObject(value) + ")");
			}
		}
		catch
		{
		}
	}

	private void SetupThemeSwatches()
	{
		if (ThemeDropdown == null)
		{
			return;
		}
		ThemeDropdown.SelectionChanged -= ThemeDropdown_SelectionChanged;
		ThemeDropdown.Items.Clear();
		foreach (Theme theme in ThemeManager.Themes)
		{
			ThemeDropdown.Items.Add(new ThemeChoice
			{
				Name = theme.Name,
				Dot = new SolidColorBrush(theme.Accent),
				IsCustom = theme.IsCustom
			});
		}
		SelectThemeChoice(ThemeManager.Current.Name);
		ThemeDropdown.SelectionChanged += ThemeDropdown_SelectionChanged;
	}

	private void SelectThemeChoice(string name)
	{
		ThemeDropdown.SelectedItem = ThemeDropdown.Items.OfType<ThemeChoice>().FirstOrDefault((ThemeChoice c) => c.Name == name);
	}

	private void ThemeDropdown_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		if (ThemeDropdown.SelectedItem is ThemeChoice themeChoice)
		{
			Theme theme = ThemeManager.ByName(themeChoice.Name);
			if (theme != ThemeManager.Current)
			{
				ApplyTheme(theme);
			}
		}
	}

	private static UIElement BuildWin7Flag()
	{
		Canvas canvas = new Canvas
		{
			Width = 26.0,
			Height = 24.0
		};
		Pane("M 1,4.4 L 11.6,2.2 L 11.6,11.0 L 1,12.4 Z", "#F65314");
		Pane("M 13.4,1.8 L 25,0.0  L 25,10.4 L 13.4,10.9 Z", "#7CBB00");
		Pane("M 1,13.8 L 11.6,12.6 L 11.6,21.4 L 1,19.8 Z", "#00A1F1");
		Pane("M 13.4,12.4 L 25,11.8 L 25,22.6 L 13.4,20.9 Z", "#FFBB00");
		return new Viewbox
		{
			Width = 28.0,
			Height = 28.0,
			Stretch = Stretch.Uniform,
			Child = canvas,
			Effect = new DropShadowEffect
			{
				Color = Colors.White,
				BlurRadius = 10.0,
				ShadowDepth = 0.0,
				Opacity = 0.35
			}
		};
		void Pane(string data, string hex)
		{
			canvas.Children.Add(new System.Windows.Shapes.Path
			{
				Data = Geometry.Parse(data),
				Fill = (Brush)new BrushConverter().ConvertFromString(hex)
			});
		}
	}

	private void ApplyTheme(Theme theme)
	{
		ThemeManager.ApplyAndRemember(theme, _settings);
		UpdateSwatchSelection();
		UpdateChromeForTheme(theme);
		SetEditorThemeAsync(theme);
		RefreshThemedLists();
		AppendConsole("Theme changed to " + theme.Name + ".", LogLevel.System);
	}

	private void PreviewTheme(Theme theme)
	{
		ThemeManager.Apply(theme);
		UpdateChromeForTheme(theme);
		SetEditorThemeAsync(theme);
		foreach (LogEntry item in _consoleLog)
		{
			item.Color = BrushFor(item.Level);
		}
	}

	private void UpdateChromeForTheme(Theme theme)
	{
		bool flag = theme.Glass || theme.Name == "Windows 7 Aero";
		bool flag2 = theme.Name == "Windows XP Luna";
		bool flag3 = theme.Name == "Mossad";
		bool flag4 = theme.Name == "Serversiding.xyz";
		if (SupqBrand != null)
		{
			SupqBrand.Visibility = (flag4 ? Visibility.Collapsed : Visibility.Visible);
		}
		if (ServersidingBrand != null)
		{
			ServersidingBrand.Visibility = ((!flag4) ? Visibility.Collapsed : Visibility.Visible);
		}
		ApplyToolbarStyle(flag4);
		if (GlassOverlay != null)
		{
			GlassOverlay.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		}
		if (XpOverlay != null)
		{
			XpOverlay.Visibility = ((!flag2) ? Visibility.Collapsed : Visibility.Visible);
		}
		if (AeroCaptionButtons != null)
		{
			AeroCaptionButtons.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		}
		if (XpCaptionButtons != null)
		{
			XpCaptionButtons.Visibility = ((!flag2) ? Visibility.Collapsed : Visibility.Visible);
		}
		if (ModernCaptionButtons != null)
		{
			ModernCaptionButtons.Visibility = ((flag || flag2) ? Visibility.Collapsed : Visibility.Visible);
		}
		if (TitleBrandText != null)
		{
			if (flag2)
			{
				TitleBrandText.Foreground = Brushes.White;
				TitleBrandText.FontWeight = FontWeights.Bold;
				TitleBrandText.Effect = null;
			}
			else if (flag)
			{
				TitleBrandText.Foreground = (Brush)new BrushConverter().ConvertFromString("#0B2A45");
				TitleBrandText.FontWeight = FontWeights.SemiBold;
				TitleBrandText.Effect = new DropShadowEffect
				{
					Color = Colors.White,
					BlurRadius = 10.0,
					ShadowDepth = 0.0,
					Opacity = 0.95
				};
			}
			else
			{
				TitleBrandText.SetResourceReference(TextBlock.ForegroundProperty, "TextBrightBrush");
				TitleBrandText.FontWeight = FontWeights.SemiBold;
				TitleBrandText.Effect = null;
			}
		}
		if (MossadWatermark != null)
		{
			MossadWatermark.Visibility = ((!flag3) ? Visibility.Collapsed : Visibility.Visible);
		}
		if (TitleLogo?.Effect is DropShadowEffect dropShadowEffect)
		{
			dropShadowEffect.Opacity = (theme.IsLight ? 0.0 : 0.7);
		}
		UpdateMossadAudio(flag3);
		UpdateLanguageForTheme(theme);
	}

	private void ApplyToolbarStyle(bool pills)
	{
		if (RunButton != null)
		{
			RunButton.Style = (Style)FindResource("FluentAccentButtonStyle");
			RunButton.SetResourceReference(Control.BackgroundProperty, "AccentBrush");
			RunButton.Foreground = Brushes.White;
			RunIcon.Fill = Brushes.White;
			ClearButton.Style = (Style)FindResource("ToolbarButtonStyle");
			ClearButton.ClearValue(Control.BackgroundProperty);
			ClearButton.ClearValue(Control.BorderBrushProperty);
			ClearButton.SetResourceReference(Control.ForegroundProperty, "TextBrightBrush");
			ClearIcon.SetResourceReference(Shape.FillProperty, "TextMutedBrush");
			OpenButton.Style = (Style)FindResource("ToolbarButtonStyle");
			OpenButton.ClearValue(Control.BackgroundProperty);
			OpenButton.ClearValue(Control.BorderBrushProperty);
			OpenButton.SetResourceReference(Control.ForegroundProperty, "TextBrightBrush");
			OpenIcon.SetResourceReference(Shape.FillProperty, "TextMutedBrush");
			SaveButton.Style = (Style)FindResource("ToolbarButtonStyle");
			SaveButton.ClearValue(Control.BackgroundProperty);
			SaveButton.ClearValue(Control.BorderBrushProperty);
			SaveButton.SetResourceReference(Control.ForegroundProperty, "TextBrightBrush");
			SaveIcon.SetResourceReference(Shape.StrokeProperty, "TextMutedBrush");
			InjectButton.Style = (Style)FindResource("FluentStandardButtonStyle");
			InjectButton.SetResourceReference(Control.BackgroundProperty, "SurfaceRaisedBrush");
			InjectButton.SetResourceReference(Control.BorderBrushProperty, "StrokeBrush");
			InjectButton.SetResourceReference(Control.ForegroundProperty, "TextBrightBrush");
			InjectIconIdle.SetResourceReference(Shape.FillProperty, "AccentBrush");
			InjectIconSpinner.SetResourceReference(Shape.StrokeProperty, "AccentBrush");
			InjectIconCheck.Stroke = (Brush)new BrushConverter().ConvertFromString("#107C41");
			ToolbarSeparator.Margin = new Thickness(4.0, 0.0, 8.0, 0.0);
		}
	}

	private void UpdateMossadAudio(bool isMossad)
	{
		if (isMossad)
		{
			try
			{
				string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "hava_nagila.mp3");
				if (!File.Exists(path))
				{
					path = "c:\\Users\\supquarter\\Documents\\idk-base\\supQ\\hava_nagila.mp3";
				}
				if (!File.Exists(path))
				{
					path = "C:\\Users\\supquarter\\Downloads\\hava nagila.mp3";
				}
				if (File.Exists(path))
				{
					if (_mossadPlayer == null)
					{
						_mossadPlayer = new MediaPlayer();
						_mossadPlayer.MediaOpened += delegate
						{
							_mossadPlayer.Volume = 1.0;
							_mossadPlayer.IsMuted = _isMutedMossadAudio;
							_mossadPlayer.Play();
						};
						_mossadPlayer.MediaEnded += delegate
						{
							_mossadPlayer.Position = TimeSpan.Zero;
							_mossadPlayer.Play();
						};
					}
					_mossadPlayer.Open(new Uri(System.IO.Path.GetFullPath(path), UriKind.Absolute));
					_mossadPlayer.Volume = 1.0;
					_mossadPlayer.IsMuted = _isMutedMossadAudio;
					_mossadPlayer.Position = TimeSpan.Zero;
					_mossadPlayer.Play();
				}
				return;
			}
			catch (Exception)
			{
				return;
			}
		}
		if (_mossadPlayer != null)
		{
			_mossadPlayer.Stop();
			_mossadPlayer.Close();
			_mossadPlayer = null;
		}
	}

	private void MossadAudioToggle_Click(object sender, RoutedEventArgs e)
	{
		_isMutedMossadAudio = MossadAudioToggle.IsChecked == true;
		if (_mossadPlayer != null)
		{
			_mossadPlayer.IsMuted = _isMutedMossadAudio;
		}
	}

	private void UpdateLanguageForTheme(Theme theme)
	{
		bool flag = theme.Name == "Mossad";
		if (MossadAudioRow != null)
		{
			MossadAudioRow.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		}
		if (MossadAudioTitle != null)
		{
			MossadAudioTitle.Text = (flag ? "השתק מוזיקת הבה נגילה" : "Mute Theme Music (Hava Nagila)");
		}
		if (MossadAudioSub != null)
		{
			MossadAudioSub.Text = (flag ? "הפעל או השתק את המוזיקה של ערכת הנושא." : "Mute or unmute the Mossad theme soundtrack.");
		}
		if (EditorTabButton != null)
		{
			EditorTabButton.ToolTip = (flag ? "עורך קוד (Execution)" : "Code Editor");
		}
		if (HubTabButton != null)
		{
			HubTabButton.ToolTip = (flag ? "ספרית תסריטים (Scripts)" : "Script Hub");
		}
		if (SettingsTabButton != null)
		{
			SettingsTabButton.ToolTip = (flag ? "הגדרות מערכת (Settings)" : "Settings");
		}
		if (FinderTitleText != null)
		{
			FinderTitleText.Text = (flag ? "חיפוש" : "Explorer");
		}
		if (FinderScriptsText != null)
		{
			FinderScriptsText.Text = (flag ? "תסריטים" : "Scripts");
		}
		if (FinderWorkspaceText != null)
		{
			FinderWorkspaceText.Text = (flag ? "סביבת עבודה" : "Workspace");
		}
		if (FinderAutoExecText != null)
		{
			FinderAutoExecText.Text = (flag ? "הרצה אוטומטית" : "AutoExec");
		}
		if (RunButton != null)
		{
			RunButton.ToolTip = (flag ? "הרצה (Execute / Run F5)" : "Execute / Run (F5)");
		}
		if (ClearButton != null)
		{
			ClearButton.ToolTip = (flag ? "ניקוי (Clear)" : "Clear Editor");
		}
		if (OpenButton != null)
		{
			OpenButton.ToolTip = (flag ? "פתח (Open)" : "Open Script");
		}
		if (SaveButton != null)
		{
			SaveButton.ToolTip = (flag ? "שמור (Save)" : "Save Script");
		}
		if (ConsoleStatusLabel != null)
		{
			ConsoleStatusLabel.Text = (flag ? "קונסול" : "Console");
		}
		if (StatusText != null && (StatusText.Text == "Not injected" || StatusText.Text == "לא מחובר"))
		{
			StatusText.Text = (flag ? "לא מחובר" : "Not injected");
		}
	}

	private void RefreshThemedLists()
	{
		LoadLocalScriptsList();
		foreach (LogEntry item in _consoleLog)
		{
			item.Color = BrushFor(item.Level);
		}
	}

	private void UpdateSwatchSelection()
	{
		if (ThemeDropdown != null && (ThemeDropdown.SelectedItem as ThemeChoice)?.Name != ThemeManager.Current.Name)
		{
			ThemeDropdown.SelectionChanged -= ThemeDropdown_SelectionChanged;
			SelectThemeChoice(ThemeManager.Current.Name);
			ThemeDropdown.SelectionChanged += ThemeDropdown_SelectionChanged;
		}
	}

	private void RestoreSettings()
	{
		_restoringSettings = true;
		try
		{
			if (TopMostToggle != null)
			{
				TopMostToggle.IsChecked = _settings.TopMost;
				base.Topmost = _settings.TopMost;
			}
			if (AutoOpenConsoleToggle != null)
			{
				AutoOpenConsoleToggle.IsChecked = _settings.AutoOpenConsole;
			}
			if (FontSizeSlider != null)
			{
				FontSizeSlider.Value = _settings.EditorFontSize;
			}
			_editorFontSize = _settings.EditorFontSize;
			if (FontSizeLabel != null)
			{
				FontSizeLabel.Text = _editorFontSize.ToString();
			}
			UpdateMcpSetupStatus();
		}
		finally
		{
			_restoringSettings = false;
		}
	}

	private void PersistSettings()
	{
		if (!_restoringSettings)
		{
			_settings.TopMost = TopMostToggle?.IsChecked == true;
			_settings.AutoOpenConsole = AutoOpenConsoleToggle?.IsChecked == true;
			_settings.EditorFontSize = _editorFontSize;
			_settings.Save();
		}
	}

	private static string SelectedComboTag(ComboBox? comboBox, string fallback)
	{
		return (comboBox?.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? fallback;
	}

	private static void SelectComboByTag(ComboBox? comboBox, string? tag)
	{
		if (comboBox == null)
		{
			return;
		}
		foreach (ComboBoxItem item in comboBox.Items.OfType<ComboBoxItem>())
		{
			if (string.Equals(item.Tag?.ToString(), tag, StringComparison.OrdinalIgnoreCase))
			{
				comboBox.SelectedItem = item;
				break;
			}
		}
	}

	private void TopMost_Changed(object sender, RoutedEventArgs e)
	{
		if (TopMostToggle != null)
		{
			base.Topmost = TopMostToggle.IsChecked == true;
			PersistSettings();
		}
	}

	private void FontSize_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
	{
		int num = (_editorFontSize = (int)Math.Round(e.NewValue));
		if (FontSizeLabel != null)
		{
			FontSizeLabel.Text = $"{num} pt";
		}
		SetEditorFontSizeAsync(num);
		PersistSettings();
	}

	private void OpenRDD_Click(object sender, RoutedEventArgs e)
	{
		string text = RobloxVersionBox?.Text?.Trim() ?? "";
		string url = (string.IsNullOrEmpty(text) ? "https://rdd.weao.gg/" : ("https://rdd.weao.gg/?channel=LIVE&binaryType=WindowsPlayer&version=" + Uri.EscapeDataString(text)));
		OpenUrl(url);
	}

	private void OpenRDDLatest_Click(object sender, RoutedEventArgs e)
	{
		OpenUrl("https://rdd.weao.gg/?channel=LIVE&binaryType=WindowsPlayer");
	}

	private void LaunchRoblox_Click(object sender, RoutedEventArgs e)
	{
		try
		{
			Process.Start(new ProcessStartInfo("roblox://")
			{
				UseShellExecute = true
			});
			AppendConsole("Launching Roblox…", LogLevel.System);
		}
		catch (Exception ex)
		{
			AppendConsole("Failed to launch Roblox: " + ex.Message, LogLevel.Error);
			MessageBox.Show("Failed to launch Roblox: " + ex.Message, "supQ", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void OpenMcpDashboard_Click(object sender, RoutedEventArgs e)
	{
		OpenUrl("http://localhost:16384/");
	}

	private void UpdateMcpSetupStatus()
	{
		if (McpSetupStatusText != null)
		{
			string path = System.IO.Path.Combine("C:\\Users\\supquarter\\Documents\\roblox-executor-mcp", "dist", "index.js");
			string path2 = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".codex", "config.toml");
			bool flag = File.Exists(path);
			bool flag2 = File.Exists(path2) && File.ReadAllText(path2).IndexOf("[mcp_servers.roblox-executor-mcp]", StringComparison.Ordinal) >= 0;
			McpSetupStatusText.Text = (flag2 ? "Configured in Codex — restart Codex to load the MCP server." : (flag ? "Server build found and ready to add." : "Server build missing; run npm install and npm run build first."));
		}
	}

	private void AddRobloxMcpToCodex_Click(object sender, RoutedEventArgs e)
	{
		try
		{
			string text = System.IO.Path.Combine("C:\\Users\\supquarter\\Documents\\roblox-executor-mcp", "dist", "index.js");
			if (!File.Exists(text))
			{
				throw new FileNotFoundException("The MCP build was not found. Run npm install and npm run build in the Roblox Executor MCP folder first.", text);
			}
			string text2 = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".codex");
			string path = System.IO.Path.Combine(text2, "config.toml");
			Directory.CreateDirectory(text2);
			string text3 = (File.Exists(path) ? File.ReadAllText(path) : "");
			string text4 = text.Replace('\\', '/');
			string text5 = "[mcp_servers.roblox-executor-mcp]" + Environment.NewLine + "command = \"node\"" + Environment.NewLine + "args = [\"" + text4 + "\"]" + Environment.NewLine;
			Regex regex = new Regex("(?ms)^\\[mcp_servers\\.roblox-executor-mcp\\][^\\r\\n]*\\r?\\n.*?(?=^\\[|\\z)");
			text3 = ((!regex.IsMatch(text3)) ? (text3.TrimEnd() + (string.IsNullOrWhiteSpace(text3) ? "" : (Environment.NewLine + Environment.NewLine)) + text5) : regex.Replace(text3, text5 + Environment.NewLine, 1));
			File.WriteAllText(path, text3);
			UpdateMcpSetupStatus();
			AppendConsole("[MCP] Added roblox-executor-mcp to Codex config.", LogLevel.Success);
			MessageBox.Show("Roblox Executor MCP was added to Codex. Restart Codex to load the server.", "supQ Integrations", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
		catch (Exception ex)
		{
			if (McpSetupStatusText != null)
			{
				McpSetupStatusText.Text = ex.Message;
			}
			AppendConsole("[MCP] Setup failed: " + ex.Message, LogLevel.Error);
			MessageBox.Show(ex.Message, "Could not add Roblox Executor MCP", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void OpenUrl(string url)
	{
		try
		{
			Process.Start(new ProcessStartInfo(url)
			{
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			MessageBox.Show("Failed to open link: " + ex.Message, "supQ", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void Discord_Click(object sender, RoutedEventArgs e)
	{
		OpenUrl("https://discord.gg/SeC9jXhxGb");
	}

	private void YouTube_Click(object sender, RoutedEventArgs e)
	{
		OpenUrl("https://youtube.com/@supquarter");
	}

	private void Flaticon_Click(object sender, RoutedEventArgs e)
	{
		OpenUrl("https://www.flaticon.com/uicons");
	}

	private async void HubFilter_Changed(object sender, RoutedEventArgs e)
	{
		if (!_restoringSettings && base.IsLoaded)
		{
			await LoadHubScriptsAsync();
		}
	}

	private async void HubApplyFilters_Click(object sender, RoutedEventArgs e)
	{
		await LoadHubScriptsAsync();
	}

	private async void HubPlaceIdBox_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.Key == Key.Return)
		{
			await LoadHubScriptsAsync();
		}
	}

	private async void HubSearch_Click(object sender, RoutedEventArgs e)
	{
		await PerformSearch();
	}

	private async void HubSearchBox_KeyDown(object sender, KeyEventArgs e)
	{
		if (e.Key == Key.Return)
		{
			await PerformSearch();
		}
	}

	private async Task PerformSearch()
	{
		await LoadHubScriptsAsync();
	}

	private async Task LoadHubScriptsAsync()
	{
		if (ScriptHubMainList == null)
		{
			return;
		}
		string text = HubPlaceIdBox?.Text?.Trim() ?? "";
		if (text.Length > 0 && !text.All(char.IsDigit))
		{
			ShowHubState("Invalid place ID", "Roblox place IDs contain numbers only.", loading: false);
			return;
		}
		_hubLoadCts?.Cancel();
		_hubLoadCts?.Dispose();
		_hubLoadCts = new CancellationTokenSource();
		CancellationToken token = _hubLoadCts.Token;
		ShowHubState("Loading scripts", "Contacting ScriptBlox…", loading: true);
		SetHubFooterState("Loading", busy: true);
		try
		{
			List<ScriptHubItem> list = await FetchScriptBloxAsync(token);
			token.ThrowIfCancellationRequested();
			_hubItems = list;
			ScriptHubMainList.ItemsSource = _hubItems;
			if (list.Count == 0)
			{
				ShowHubState("No scripts found", "Try a broader search or remove one of the filters.", loading: false);
				SetHubFooterState("No results", busy: false);
				return;
			}
			HideHubState();
			SetHubFooterState($"{list.Count} results", busy: false, online: true);
			string text2 = HubSearchBox?.Text?.Trim() ?? "";
			AppendConsole(string.IsNullOrEmpty(text2) ? string.Format("[ScriptHub] Loaded {0} scripts from {1}.", list.Count, "ScriptBlox") : string.Format("[ScriptHub] Found {0} {1} scripts for '{2}'.", list.Count, "ScriptBlox", text2));
		}
		catch (OperationCanceledException)
		{
		}
		catch (Exception ex2)
		{
			ShowHubState("Could not reach ScriptBlox", ex2.Message, loading: false);
			SetHubFooterState("Offline", busy: false);
			AppendConsole("[ScriptHub] ScriptBlox error: " + ex2.Message, LogLevel.Warn);
		}
	}

	private async Task<List<ScriptHubItem>> FetchScriptBloxAsync(CancellationToken token)
	{
		string text = HubSearchBox?.Text?.Trim() ?? "";
		string text2 = (string.IsNullOrWhiteSpace(text) ? "https://scriptblox.com/api/script/fetch" : "https://scriptblox.com/api/script/search");
		List<string> list = new List<string> { "page=1", "max=20" };
		if (!string.IsNullOrWhiteSpace(text))
		{
			list.Add("q=" + Uri.EscapeDataString(text));
		}
		if (HubFreeOnlyToggle?.IsChecked == true)
		{
			list.Add("mode=free");
		}
		if (HubNoKeyToggle?.IsChecked == true)
		{
			list.Add("key=0");
		}
		if (HubVerifiedToggle?.IsChecked == true)
		{
			list.Add("verified=1");
		}
		if (HubActiveToggle?.IsChecked == true)
		{
			list.Add("patched=0");
		}
		AddPlaceId(list);
		switch (SelectedComboTag(HubSortCombo, "recommended"))
		{
		case "newest":
			list.Add("sortBy=createdAt");
			list.Add("order=desc");
			break;
		case "oldest":
			list.Add("sortBy=createdAt");
			list.Add("order=asc");
			break;
		case "views":
			list.Add("sortBy=views");
			list.Add("order=desc");
			break;
		case "likes":
			list.Add("sortBy=likeCount");
			list.Add("order=desc");
			break;
		}
		using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, text2 + "?" + string.Join("&", list));
		using HttpResponseMessage httpResponse = await httpClient.SendAsync(request, token);
		httpResponse.EnsureSuccessStatusCode();
		return JsonConvert.DeserializeObject<ScriptBloxResponse>(await httpResponse.Content.ReadAsStringAsync())?.result?.scripts?.Select(ScriptHubItem.FromScriptBlox).ToList() ?? new List<ScriptHubItem>();
	}

	private void AddPlaceId(List<string> parameters)
	{
		string text = HubPlaceIdBox?.Text?.Trim() ?? "";
		if (!string.IsNullOrEmpty(text))
		{
			parameters.Add("placeId=" + Uri.EscapeDataString(text));
		}
	}

	private void ShowHubState(string title, string message, bool loading)
	{
		if (HubStatePanel != null)
		{
			HubStatePanel.Visibility = Visibility.Visible;
			HubStateTitle.Text = title;
			HubStateMessage.Text = message;
			HubProgress.Visibility = ((!loading) ? Visibility.Collapsed : Visibility.Visible);
		}
	}

	private void HideHubState()
	{
		if (HubStatePanel != null)
		{
			HubStatePanel.Visibility = Visibility.Collapsed;
		}
	}

	private void SetHubFooterState(string text, bool busy, bool online = false)
	{
		if (HubStatusText != null)
		{
			HubStatusText.Text = text;
		}
		if (HubStatusDot != null)
		{
			HubStatusDot.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(busy ? "#FBBF24" : (online ? "#34D399" : "#FB7185")));
		}
	}

	private async void LoadScript_Click(object sender, RoutedEventArgs e)
	{
		if (!(sender is Button { Tag: var tag } button) || !(tag is ScriptHubItem item))
		{
			return;
		}
		button.IsEnabled = false;
		object origContent = button.Content;
		button.Content = "…";
		try
		{
			string text = await FetchRawScript(item);
			if (!string.IsNullOrEmpty(text))
			{
				string text2 = item.Title;
				if (text2.Length > 22)
				{
					text2 = text2.Substring(0, 20) + "…";
				}
				if (SelectedTab != null && (string.IsNullOrWhiteSpace(SelectedTab.Content) || SelectedTab.Header == "New Script"))
				{
					SelectedTab.Header = text2;
					SelectedTab.Content = text;
					await SetEditorTextAsync(text);
				}
				else
				{
					EditorTab editorTab = new EditorTab
					{
						Header = text2,
						Content = text
					};
					EditorTabs.Add(editorTab);
					await SwitchToTab(editorTab);
				}
				SaveTabSession();
				EditorTabButton.IsChecked = true;
				AppendConsole("[ScriptHub] Loaded '" + item.Title + "' from " + item.Provider + " into editor.", LogLevel.Success);
			}
			else
			{
				MessageBox.Show("Could not retrieve script content from " + item.Provider + ".", "supQ Hub", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}
		finally
		{
			button.IsEnabled = true;
			button.Content = origContent;
		}
	}

	private async void ExecuteScriptDirect_Click(object sender, RoutedEventArgs e)
	{
		if (!(sender is Button { Tag: var tag } button) || !(tag is ScriptHubItem item))
		{
			return;
		}
		button.IsEnabled = false;
		try
		{
			string text = await FetchRawScript(item);
			if (!string.IsNullOrEmpty(text))
			{
				AppendConsole("[ScriptHub] Executing '" + item.Title + "' from " + item.Provider + "…", LogLevel.System);
				await ExecuteScript(text);
			}
			else
			{
				MessageBox.Show("Could not retrieve script content from " + item.Provider + ".", "supQ Hub", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}
		finally
		{
			button.IsEnabled = true;
		}
	}

	private async Task<string> FetchRawScript(ScriptHubItem item)
	{
		try
		{
			string requestUri = "https://scriptblox.com/api/script/raw/" + Uri.EscapeDataString(item.Id);
			return await httpClient.GetStringAsync(requestUri);
		}
		catch
		{
			try
			{
				string requestUri2 = "https://scriptblox.com/api/script/" + Uri.EscapeDataString(item.Id);
				return JsonConvert.DeserializeObject<ScriptBloxDetailResponse>(await httpClient.GetStringAsync(requestUri2))?.script?.script ?? string.Empty;
			}
			catch (Exception ex)
			{
				MessageBox.Show("Failed to retrieve script source: " + ex.Message, "supQ Hub", MessageBoxButton.OK, MessageBoxImage.Hand);
				return string.Empty;
			}
		}
	}

	private string GetMonacoHtml()
	{
		return "<!DOCTYPE html>\n<html>\n<head>\n    <meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\" />\n    <style type=\"text/css\">\n        html, body { width: 100%; height: 100%; margin: 0; padding: 0; overflow: hidden; background: transparent !important; box-sizing: border-box; }\n        #container { width: 100%; height: 100%; position: absolute; top: 0; left: 0; right: 0; bottom: 0; }\n        .monaco-editor, .monaco-editor-background, .monaco-editor .margin { background: transparent !important; }\n    </style>\n    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.39.0/min/vs/loader.min.js\"></script>\n</head>\n<body>\n    <div id=\"container\"></div>\n    <script>\n        require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.39.0/min/vs' } });\n        var editor;\n        require(['vs/editor/editor.main'], function() {\n            monaco.languages.registerCompletionItemProvider('lua', {\n                provideCompletionItems: function(model, position) {\n                    var suggestions = [\n                        { label: 'getgenv', kind: monaco.languages.CompletionItemKind.Function, insertText: 'getgenv()', detail: 'Returns the global environment table.' },\n                        { label: 'getrenv', kind: monaco.languages.CompletionItemKind.Function, insertText: 'getrenv()', detail: 'Returns the Roblox global environment table.' },\n                        { label: 'getreg', kind: monaco.languages.CompletionItemKind.Function, insertText: 'getreg()', detail: 'Returns the Lua registry table.' },\n                        { label: 'getgc', kind: monaco.languages.CompletionItemKind.Function, insertText: 'getgc()', detail: 'Returns all active garbage collection objects.' },\n                        { label: 'hookfunction', kind: monaco.languages.CompletionItemKind.Function, insertText: 'hookfunction(${1:target}, ${2:hook})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Hooks a function and redirects calls.' },\n                        { label: 'hookmetatable', kind: monaco.languages.CompletionItemKind.Function, insertText: 'hookmetatable(${1:object}, ${2:metatable})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Hooks the metatable of a Roblox instance.' },\n                        { label: 'newcclosure', kind: monaco.languages.CompletionItemKind.Function, insertText: 'newcclosure(${1:func})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Creates a custom C-closure wrapper for a Lua function.' },\n                        { label: 'clonefunction', kind: monaco.languages.CompletionItemKind.Function, insertText: 'clonefunction(${1:func})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Creates a copy of a function.' },\n                        { label: 'cloneref', kind: monaco.languages.CompletionItemKind.Function, insertText: 'cloneref(${1:instance})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Clones a reference to a Roblox instance to bypass basic checks.' },\n                        { label: 'loadstring', kind: monaco.languages.CompletionItemKind.Function, insertText: 'loadstring(${1:code})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Compiles and loads a chunk of Lua code.' },\n                        { label: 'identifyexecutor', kind: monaco.languages.CompletionItemKind.Function, insertText: 'identifyexecutor()', detail: 'Returns name and version of the active executor.' },\n                        { label: 'getexecutorname', kind: monaco.languages.CompletionItemKind.Function, insertText: 'getexecutorname()', detail: 'Returns name of the active executor.' },\n                        { label: 'firesignal', kind: monaco.languages.CompletionItemKind.Function, insertText: 'firesignal(${1:signal})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Fires a Roblox signal/event handler.' },\n                        { label: 'fireclickdetector', kind: monaco.languages.CompletionItemKind.Function, insertText: 'fireclickdetector(${1:detector})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Simulates clicking a ClickDetector.' },\n                        { label: 'firetouchinterest', kind: monaco.languages.CompletionItemKind.Function, insertText: 'firetouchinterest(${1:part}, ${2:toucher}, ${3:toggle})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Simulates a touch interaction interest.' },\n                        { label: 'getconnections', kind: monaco.languages.CompletionItemKind.Function, insertText: 'getconnections(${1:signal})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Returns a table of all active connections to a signal.' },\n                        { label: 'getloadedmodules', kind: monaco.languages.CompletionItemKind.Function, insertText: 'getloadedmodules()', detail: 'Returns a list of all loaded ModuleScripts.' },\n                        { label: 'getnilinstances', kind: monaco.languages.CompletionItemKind.Function, insertText: 'getnilinstances()', detail: 'Returns a list of all instances parented to nil.' },\n                        { label: 'getscripts', kind: monaco.languages.CompletionItemKind.Function, insertText: 'getscripts()', detail: 'Returns a list of all active LocalScripts and ModuleScripts.' },\n                        { label: 'setfpscap', kind: monaco.languages.CompletionItemKind.Function, insertText: 'setfpscap(${1:cap})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Configures maximum frame rate ceiling.' },\n                        { label: 'isrbxactive', kind: monaco.languages.CompletionItemKind.Function, insertText: 'isrbxactive()', detail: 'Checks if the Roblox game window is currently focused.' },\n                        { label: 'mouse1click', kind: monaco.languages.CompletionItemKind.Function, insertText: 'mouse1click()', detail: 'Simulates a mouse left-button click.' },\n                        { label: 'mouse2click', kind: monaco.languages.CompletionItemKind.Function, insertText: 'mouse2click()', detail: 'Simulates a mouse right-button click.' },\n                        { label: 'keypress', kind: monaco.languages.CompletionItemKind.Function, insertText: 'keypress(${1:code})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Simulates a key press down event.' },\n                        { label: 'keyrelease', kind: monaco.languages.CompletionItemKind.Function, insertText: 'keyrelease(${1:code})', insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet, detail: 'Simulates a key release up event.' }\n                    ];\n                    return { suggestions: suggestions };\n                }\n            });\n\n            editor = monaco.editor.create(document.getElementById('container'), {\n                value: '-- Welcome to supQ\\n\\nprint(\"Hello World!\")\\n',\n                language: 'lua',\n                theme: 'vs',\n                automaticLayout: true,\n                minimap: { enabled: false },\n                fontSize: 14,\n                fontFamily: 'Cascadia Code, Consolas, Courier New, monospace',\n                lineNumbersMinChars: 3,\n                scrollBeyondLastLine: false,\n                roundedSelection: true,\n                cursorBlinking: 'smooth',\n                cursorSmoothCaretAnimation: 'on'\n            });\n\n            monaco.editor.defineTheme('supQTheme', {\n                base: 'vs',\n                inherit: true,\n                rules: [\n                    { token: 'comment', foreground: '808080', fontStyle: 'italic' },\n                    { token: 'keyword', foreground: 'B0B0B0', fontStyle: 'bold' },\n                    { token: 'string', foreground: '909090' },\n                    { token: 'number', foreground: '989898' }\n                ],\n                colors: {\n                    'editor.background': '#00000000',\n                    'editor.foreground': '#C8C8C8',\n                    'editorLineNumber.foreground': '#707070',\n                    'editorLineNumber.activeForeground': '#A0A0A0',\n                    'editor.lineHighlightBackground': '#00000000',\n                    'editor.selectionBackground': '#33FFFFFF'\n                }\n            });\n            monaco.editor.setTheme('supQTheme');\n        });\n\n        function getCode() { return editor ? editor.getValue() : ''; }\n        function setCode(code) { if (editor) editor.setValue(code); }\n        function setFontSize(n) { if (editor) editor.updateOptions({ fontSize: n }); }\n        function setEditorFont(family, fontUrl) {\n            var previous = document.getElementById('supq-custom-font');\n            if (previous) previous.remove();\n\n            var target = family + ', Consolas, Courier New, monospace';\n            if (fontUrl) {\n                var style = document.createElement('style');\n                style.id = 'supq-custom-font';\n                style.textContent = `@font-face { font-family: 'supQCustomFont'; src: url('${fontUrl}'); font-style: normal; font-weight: 100 900; }`;\n                document.head.appendChild(style);\n                target = `'supQCustomFont', ${target}`;\n            }\n            if (editor) editor.updateOptions({ fontFamily: target });\n        }\n        function applyEditorTheme(o) {\n            if (typeof monaco === 'undefined') return;\n            var raw = function (c) { return String(c || '').replace('#', ''); };\n            var isTrans = (o.bg === '#00000000' || o.bg === 'transparent');\n            monaco.editor.defineTheme('supQTheme', {\n                base: o.isLight ? 'vs' : 'vs-dark', inherit: true,\n                rules: [\n                    { token: '', foreground: raw(o.ident) },\n                    { token: 'comment', foreground: raw(o.comment), fontStyle: 'italic' },\n                    { token: 'keyword', foreground: raw(o.keyword), fontStyle: 'bold' },\n                    { token: 'string', foreground: raw(o.str) },\n                    { token: 'string.escape', foreground: raw(o.number) },\n                    { token: 'number', foreground: raw(o.number) },\n                    { token: 'type', foreground: raw(o.type) },\n                    { token: 'constant', foreground: raw(o.type) },\n                    { token: 'identifier', foreground: raw(o.ident) },\n                    { token: 'delimiter', foreground: raw(o.op) },\n                    { token: 'operator', foreground: raw(o.op) },\n                    { token: 'operators', foreground: raw(o.op) }\n                ],\n                colors: {\n                    'editor.background': isTrans ? '#00000000' : o.bg,\n                    'editor.foreground': o.fg,\n                    'editorLineNumber.foreground': o.lineNum,\n                    'editorLineNumber.activeForeground': o.lineNumActive,\n                    'editor.lineHighlightBackground': isTrans ? '#00000000' : o.lineBg,\n                    'editor.selectionBackground': o.sel,\n                    'editorCursor.foreground': o.cursor\n                }\n            });\n            monaco.editor.setTheme('supQTheme');\n        }\n    </script>\n</body>\n</html>";
	}

	private void EditTheme_Click(object sender, RoutedEventArgs e)
	{
		OpenThemeEditor(ThemeManager.Current, asNew: false);
	}

	private void NewTheme_Click(object sender, RoutedEventArgs e)
	{
		OpenThemeEditor(ThemeManager.Current, asNew: true);
	}

	private void OpenThemeEditor(Theme seed, bool asNew)
	{
		BuildSlotRows();
		_themeBeforeEdit = ThemeManager.Current;
		if (asNew || !seed.IsCustom)
		{
			_editingOriginalName = null;
			string baseName = (asNew ? "Custom Theme" : (seed.Name + " Custom"));
			_draft = seed with
			{
				Name = ThemeManager.UniqueName(baseName),
				IsCustom = true
			};
		}
		else
		{
			_editingOriginalName = seed.Name;
			_draft = seed;
		}
		LoadDraftIntoEditor();
		PreviewTheme(_draft);
		ThemeEditorOverlay.Opacity = 0.0;
		ThemeEditorOverlay.Visibility = Visibility.Visible;
		DoubleAnimation animation = new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(200.0))
		{
			EasingFunction = new CubicEase
			{
				EasingMode = EasingMode.EaseOut
			}
		};
		ThemeEditorOverlay.BeginAnimation(UIElement.OpacityProperty, animation);
		if (ThemeEditorCard != null)
		{
			TransformGroup transformGroup = (ThemeEditorCard.RenderTransform as TransformGroup) ?? new TransformGroup();
			ScaleTransform scaleTransform = transformGroup.Children.OfType<ScaleTransform>().FirstOrDefault() ?? new ScaleTransform(1.0, 1.0);
			TranslateTransform translateTransform = transformGroup.Children.OfType<TranslateTransform>().FirstOrDefault() ?? new TranslateTransform(0.0, 0.0);
			transformGroup.Children.Clear();
			transformGroup.Children.Add(scaleTransform);
			transformGroup.Children.Add(translateTransform);
			ThemeEditorCard.RenderTransform = transformGroup;
			DoubleAnimation animation2 = new DoubleAnimation(0.92, 1.0, TimeSpan.FromMilliseconds(220.0))
			{
				EasingFunction = new CubicEase
				{
					EasingMode = EasingMode.EaseOut
				}
			};
			DoubleAnimation animation3 = new DoubleAnimation(18.0, 0.0, TimeSpan.FromMilliseconds(220.0))
			{
				EasingFunction = new CubicEase
				{
					EasingMode = EasingMode.EaseOut
				}
			};
			scaleTransform.BeginAnimation(ScaleTransform.ScaleXProperty, animation2);
			scaleTransform.BeginAnimation(ScaleTransform.ScaleYProperty, animation2);
			translateTransform.BeginAnimation(TranslateTransform.YProperty, animation3);
		}
		ThemeNameBox.Focus();
		ThemeNameBox.SelectAll();
	}

	private void CloseThemeEditor()
	{
		if (_openPicker != null)
		{
			_openPicker.IsOpen = false;
		}
		DoubleAnimation doubleAnimation = new DoubleAnimation(1.0, 0.0, TimeSpan.FromMilliseconds(150.0))
		{
			EasingFunction = new CubicEase
			{
				EasingMode = EasingMode.EaseOut
			}
		};
		doubleAnimation.Completed += delegate
		{
			ThemeEditorOverlay.Visibility = Visibility.Collapsed;
		};
		ThemeEditorOverlay.BeginAnimation(UIElement.OpacityProperty, doubleAnimation);
	}

	private void ThemeEditorCancel_Click(object sender, RoutedEventArgs e)
	{
		CloseThemeEditor();
		if (_themeBeforeEdit != null)
		{
			PreviewTheme(_themeBeforeEdit);
			RefreshThemedLists();
			_themeBeforeEdit = null;
		}
	}

	private void ThemeEditor_PreviewKeyDown(object sender, KeyEventArgs e)
	{
		if (ThemeEditorOverlay.Visibility == Visibility.Visible && e.Key == Key.Escape)
		{
			ColorPickerPopup? openPicker = _openPicker;
			if (openPicker != null && openPicker.IsOpen)
			{
				_openPicker.IsOpen = false;
			}
			else
			{
				ThemeEditorCancel_Click(sender, e);
			}
			e.Handled = true;
		}
	}

	private void BuildSlotRows()
	{
		if (ThemeEditorGroups.Children.Count > 0)
		{
			return;
		}
		(string, string[])[] slotGroups = SlotGroups;
		for (int i = 0; i < slotGroups.Length; i++)
		{
			(string, string[]) tuple = slotGroups[i];
			string item = tuple.Item1;
			string[] item2 = tuple.Item2;
			TextBlock textBlock = new TextBlock
			{
				Text = item,
				Margin = new Thickness(2.0, 0.0, 0.0, 8.0)
			};
			textBlock.SetResourceReference(FrameworkElement.StyleProperty, "SectionHeaderStyle");
			ThemeEditorGroups.Children.Add(textBlock);
			UniformGrid uniformGrid = new UniformGrid
			{
				Columns = 2,
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
			};
			string[] array = item2;
			foreach (string slot in array)
			{
				uniformGrid.Children.Add(BuildSlotRow(slot));
			}
			ThemeEditorGroups.Children.Add(uniformGrid);
		}
		base.PreviewKeyDown += ThemeEditor_PreviewKeyDown;
	}

	private FrameworkElement BuildSlotRow(string slot)
	{
		(string Label, string Hint) tuple = SlotInfo[slot];
		string item = tuple.Label;
		string item2 = tuple.Hint;
		Border swatch = new Border
		{
			Width = 38.0,
			Height = 24.0,
			CornerRadius = new CornerRadius(5.0),
			BorderThickness = new Thickness(1.0),
			VerticalAlignment = VerticalAlignment.Center,
			Cursor = Cursors.Hand,
			Background = Brushes.Transparent
		};
		swatch.SetResourceReference(Border.BorderBrushProperty, "StrokeBrush");
		swatch.MouseLeftButtonUp += delegate
		{
			OpenPicker(slot, swatch);
		};
		TextBlock textBlock = new TextBlock
		{
			Text = item,
			FontSize = 11.5,
			Width = 104.0,
			Margin = new Thickness(10.0, 0.0, 0.0, 0.0),
			VerticalAlignment = VerticalAlignment.Center,
			TextTrimming = TextTrimming.CharacterEllipsis
		};
		textBlock.SetResourceReference(TextBlock.ForegroundProperty, "TextBrightBrush");
		TextBox hex = new TextBox
		{
			Width = 78.0,
			Height = 24.0,
			FontFamily = new FontFamily("Consolas"),
			FontSize = 11.0,
			MaxLength = 7,
			VerticalContentAlignment = VerticalAlignment.Center,
			Padding = new Thickness(6.0, 0.0, 0.0, 0.0),
			BorderThickness = new Thickness(1.0),
			VerticalAlignment = VerticalAlignment.Center
		};
		hex.SetResourceReference(Control.BackgroundProperty, "SurfaceRaisedBrush");
		hex.SetResourceReference(Control.ForegroundProperty, "TextBrightBrush");
		hex.SetResourceReference(Control.BorderBrushProperty, "StrokeBrush");
		hex.SetResourceReference(TextBoxBase.CaretBrushProperty, "AccentBrush");
		hex.TextChanged += delegate
		{
			if (!_editorSyncing && ThemeManager.TryParseHex(hex.Text, out var color))
			{
				SetSlotColor(slot, color, updateHexBox: false);
			}
		};
		hex.LostFocus += delegate
		{
			UpdateSlotRow(slot, updateHexBox: true);
		};
		_slotRows[slot] = (swatch, hex);
		return new StackPanel
		{
			Orientation = Orientation.Horizontal,
			Margin = new Thickness(0.0, 0.0, 12.0, 9.0),
			ToolTip = item2,
			Children = 
			{
				(UIElement)swatch,
				(UIElement)textBlock,
				(UIElement)hex
			}
		};
	}

	private void SetSlotColor(string slot, Color color, bool updateHexBox)
	{
		_draft = ThemeManager.With(_draft, slot, color);
		UpdateSlotRow(slot, updateHexBox);
		PreviewTheme(_draft);
	}

	private void UpdateSlotRow(string slot, bool updateHexBox)
	{
		if (_slotRows.TryGetValue(slot, out (Border, TextBox) value))
		{
			Color color = ThemeManager.Get(_draft, slot);
			value.Item1.Background = new SolidColorBrush(color);
			if (updateHexBox)
			{
				_editorSyncing = true;
				value.Item2.Text = ThemeManager.ToHex(color);
				_editorSyncing = false;
			}
		}
	}

	private void LoadDraftIntoEditor()
	{
		_editorSyncing = true;
		try
		{
			ThemeNameBox.Text = _draft.Name;
			ThemeLightToggle.IsChecked = _draft.IsLight;
			ThemeGlassToggle.IsChecked = _draft.Glass;
		}
		finally
		{
			_editorSyncing = false;
		}
		string[] slots = ThemeManager.Slots;
		foreach (string slot in slots)
		{
			UpdateSlotRow(slot, updateHexBox: true);
		}
		bool flag = _editingOriginalName != null;
		ThemeDeleteButton.Visibility = ((!flag) ? Visibility.Collapsed : Visibility.Visible);
		ThemeEditorSubtitle.Text = (flag ? ("Editing \"" + _editingOriginalName + "\". Changes preview live; Cancel restores the previous theme.") : "Saving creates a new custom theme. Changes preview live; Cancel restores the previous theme.");
	}

	private void ThemeFlag_Changed(object sender, RoutedEventArgs e)
	{
		if (!_editorSyncing && ThemeLightToggle != null && ThemeGlassToggle != null)
		{
			_draft = _draft with
			{
				IsLight = (ThemeLightToggle.IsChecked == true),
				Glass = (ThemeGlassToggle.IsChecked == true)
			};
			PreviewTheme(_draft);
			RefreshThemedLists();
		}
	}

	private void ThemeAutoAccents_Click(object sender, RoutedEventArgs e)
	{
		_draft = ThemeManager.DeriveAccentRamp(_draft);
		string[] array = new string[4] { "AccentBright", "AccentDim", "AccentSubtle", "AccentBorder" };
		foreach (string slot in array)
		{
			UpdateSlotRow(slot, updateHexBox: true);
		}
		PreviewTheme(_draft);
	}

	private void OpenPicker(string slot, UIElement anchor)
	{
		if (_openPicker != null)
		{
			_openPicker.IsOpen = false;
		}
		ColorPickerPopup picker = new ColorPickerPopup(anchor, ThemeManager.Get(_draft, slot));
		picker.ColorChanged += delegate(Color color)
		{
			SetSlotColor(slot, color, updateHexBox: true);
		};
		picker.Closed += delegate
		{
			ThemePickerHost.Children.Remove(picker);
			if (_openPicker == picker)
			{
				_openPicker = null;
			}
		};
		ThemePickerHost.Children.Add(picker);
		_openPicker = picker;
		picker.IsOpen = true;
	}

	private void ThemeEditorSave_Click(object sender, RoutedEventArgs e)
	{
		string text = (ThemeNameBox.Text ?? "").Trim();
		if (text.Length == 0)
		{
			text = "Custom Theme";
		}
		if (ThemeManager.IsBuiltinName(text))
		{
			text += " Custom";
		}
		text = ThemeManager.UniqueName(text, _editingOriginalName);
		Theme theme = ThemeManager.Upsert(_draft with
		{
			Name = text
		}, _editingOriginalName);
		_themeBeforeEdit = null;
		_editingOriginalName = null;
		CloseThemeEditor();
		SetupThemeSwatches();
		ApplyTheme(theme);
	}

	private void ThemeDelete_Click(object sender, RoutedEventArgs e)
	{
		if (_editingOriginalName != null && MessageBox.Show("Delete the custom theme \"" + _editingOriginalName + "\"?", "supQ", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) == MessageBoxResult.Yes)
		{
			ThemeManager.Delete(_editingOriginalName);
			_editingOriginalName = null;
			_themeBeforeEdit = null;
			CloseThemeEditor();
			SetupThemeSwatches();
			ApplyTheme(ThemeManager.ByName(_settings.ThemeName));
		}
	}

	private void ThemeDuplicate_Click(object sender, RoutedEventArgs e)
	{
		string text = (ThemeNameBox.Text ?? "").Trim();
		if (text.Length == 0)
		{
			text = "Custom Theme";
		}
		_editingOriginalName = null;
		_draft = _draft with
		{
			Name = ThemeManager.UniqueName(text + " copy"),
			IsCustom = true
		};
		LoadDraftIntoEditor();
	}

	private void ThemeImport_Click(object sender, RoutedEventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Title = "Import theme",
			Filter = "supQ theme (*.json)|*.json|All files (*.*)|*.*"
		};
		if (openFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			Theme theme = ThemeManager.Import(openFileDialog.FileName);
			if (theme == null)
			{
				MessageBox.Show("That file doesn't contain a supQ theme.", "supQ", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return;
			}
			_editingOriginalName = null;
			_draft = theme with
			{
				Name = ThemeManager.UniqueName(theme.Name),
				IsCustom = true
			};
			LoadDraftIntoEditor();
			PreviewTheme(_draft);
		}
		catch (Exception ex)
		{
			MessageBox.Show("Failed to import theme: " + ex.Message, "supQ Error", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void ThemeExport_Click(object sender, RoutedEventArgs e)
	{
		string text = (ThemeNameBox.Text ?? "").Trim();
		if (text.Length == 0)
		{
			text = "Custom Theme";
		}
		string text2 = string.Concat(text.Select((char c) => (!System.IO.Path.GetInvalidFileNameChars().Contains(c)) ? c : '_'));
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Title = "Export theme",
			FileName = text2 + ".json",
			DefaultExt = ".json",
			Filter = "supQ theme (*.json)|*.json"
		};
		if (saveFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			ThemeManager.Export(_draft with
			{
				Name = text
			}, saveFileDialog.FileName);
			AppendConsole("Exported theme to " + saveFileDialog.FileName + ".", LogLevel.System);
		}
		catch (Exception ex)
		{
			MessageBox.Show("Failed to export theme: " + ex.Message, "supQ Error", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}
}
