namespace supQ;

public class ScriptBloxDetail
{
	public string _id { get; set; } = "";

	public string title { get; set; } = "";

	public string script { get; set; } = "";

	public string features { get; set; } = "";
}
