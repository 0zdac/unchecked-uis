namespace supQ;

public class ScriptBloxDetailResponse
{
	public ScriptBloxDetail script { get; set; } = new ScriptBloxDetail();
}
