using System;

namespace supQ;

public class ScriptBloxGame
{
	public string _id { get; set; } = "";

	public string name { get; set; } = "";

	public string imageUrl { get; set; } = "";

	public string AbsoluteGameUrl
	{
		get
		{
			if (string.IsNullOrEmpty(imageUrl))
			{
				return "https://scriptblox.com/images/default.png";
			}
			if (imageUrl.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || imageUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
			{
				return imageUrl;
			}
			return "https://scriptblox.com" + (imageUrl.StartsWith("/") ? "" : "/") + imageUrl;
		}
	}
}
