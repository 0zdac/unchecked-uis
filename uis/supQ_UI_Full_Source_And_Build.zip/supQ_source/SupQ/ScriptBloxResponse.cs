namespace supQ;

public class ScriptBloxResponse
{
	public ScriptBloxResult result { get; set; } = new ScriptBloxResult();
}
