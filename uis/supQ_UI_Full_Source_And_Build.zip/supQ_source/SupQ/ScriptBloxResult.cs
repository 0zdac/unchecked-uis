using System.Collections.Generic;

namespace supQ;

public class ScriptBloxResult
{
	public int totalPages { get; set; }

	public List<ScriptBloxScript> scripts { get; set; } = new List<ScriptBloxScript>();
}
