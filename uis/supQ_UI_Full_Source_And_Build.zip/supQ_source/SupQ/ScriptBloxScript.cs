using System;

namespace supQ;

public class ScriptBloxScript
{
	public string _id { get; set; } = "";

	public string title { get; set; } = "";

	public ScriptBloxGame game { get; set; } = new ScriptBloxGame();

	public string slug { get; set; } = "";

	public bool verified { get; set; }

	public bool key { get; set; }

	public int views { get; set; }

	public string scriptType { get; set; } = "";

	public bool isPatched { get; set; }

	public bool isUniversal { get; set; }

	public string createdAt { get; set; } = "";

	public string image { get; set; } = "";

	public string AbsoluteImageUrl
	{
		get
		{
			if (string.IsNullOrEmpty(image) || image == "/images/default.png")
			{
				if (game != null && !string.IsNullOrEmpty(game.imageUrl))
				{
					return game.AbsoluteGameUrl;
				}
				return "https://scriptblox.com/images/default.png";
			}
			if (image.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || image.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
			{
				return image;
			}
			return "https://scriptblox.com" + (image.StartsWith("/") ? "" : "/") + image;
		}
	}
}
