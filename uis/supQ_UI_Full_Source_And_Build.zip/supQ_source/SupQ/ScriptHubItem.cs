using System;

namespace supQ;

public class ScriptHubItem
{
	public string Id { get; set; } = "";

	public string Provider { get; set; } = "ScriptBlox";

	public string Title { get; set; } = "Untitled script";

	public string GameName { get; set; } = "Universal";

	public string ImageUrl { get; set; } = "https://scriptblox.com/images/default.png";

	public bool IsVerified { get; set; }

	public bool HasKey { get; set; }

	public bool IsPatched { get; set; }

	public bool IsUniversal { get; set; }

	public bool IsPaid { get; set; }

	public int Views { get; set; }

	public int Likes { get; set; }

	public string Metrics
	{
		get
		{
			if (Likes <= 0)
			{
				return $"{Views:N0} views";
			}
			return $"{Views:N0} views  •  {Likes:N0} likes";
		}
	}

	public string SourceLabel => "SB";

	public static ScriptHubItem FromScriptBlox(ScriptBloxScript script)
	{
		return new ScriptHubItem
		{
			Id = (script._id ?? ""),
			Provider = "ScriptBlox",
			Title = (string.IsNullOrWhiteSpace(script.title) ? "Untitled script" : script.title),
			GameName = (string.IsNullOrWhiteSpace(script.game?.name) ? "Universal" : script.game.name),
			ImageUrl = script.AbsoluteImageUrl,
			IsVerified = script.verified,
			HasKey = script.key,
			IsPatched = script.isPatched,
			IsUniversal = script.isUniversal,
			IsPaid = string.Equals(script.scriptType, "paid", StringComparison.OrdinalIgnoreCase),
			Views = script.views
		};
	}
}
