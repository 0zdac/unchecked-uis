using System;
using System.IO;
using System.Reflection;
using System.Text;

namespace SupQ;

public static class StringVault
{
	private const string ResourceName = "supq.strings.v1";

	private static readonly object Sync = new object();

	private static string[]? _cache;

	private static bool _loaded;

	public static string G(int index)
	{
		if (!_loaded)
		{
			lock (Sync)
			{
				if (!_loaded)
				{
					Load();
				}
			}
		}
		return _cache[index];
	}

	private static void Load()
	{
		try
		{
			using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("supq.strings.v1");
			if (stream == null)
			{
				_cache = Array.Empty<string>();
				_loaded = true;
				return;
			}
			using BinaryReader binaryReader = new BinaryReader(stream);
			byte[] array = binaryReader.ReadBytes(16);
			int num = binaryReader.ReadInt32();
			string[] array2 = new string[num];
			byte[] array3 = new byte[65536];
			for (int i = 0; i < num; i++)
			{
				int num2 = binaryReader.ReadInt32();
				if (num2 > array3.Length)
				{
					array3 = new byte[num2 + 1];
				}
				for (int j = 0; j < num2; j += binaryReader.Read(array3, j, num2 - j))
				{
				}
				for (int k = 0; k < num2; k++)
				{
					array3[k] ^= (byte)(array[k & 0xF] ^ (k * 2654435769u >> 3) ^ (uint)i);
				}
				array2[i] = Encoding.UTF8.GetString(array3, 0, num2);
			}
			_cache = array2;
		}
		catch
		{
			_cache = Array.Empty<string>();
		}
		_loaded = true;
	}
}
