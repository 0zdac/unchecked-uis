using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace supQ;

public class TabSession
{
	public class TabRecord
	{
		public string Header { get; set; } = "";

		public string Content { get; set; } = "";
	}

	public List<TabRecord> Tabs { get; set; } = new List<TabRecord>();

	public int SelectedIndex { get; set; }

	public static TabSession Load()
	{
		try
		{
			if (File.Exists(AppPaths.Tabs))
			{
				TabSession tabSession = JsonConvert.DeserializeObject<TabSession>(File.ReadAllText(AppPaths.Tabs));
				if (tabSession?.Tabs != null)
				{
					return tabSession;
				}
			}
		}
		catch (Exception)
		{
		}
		return new TabSession();
	}

	public void Save()
	{
		try
		{
			AppPaths.EnsureDirectory(AppPaths.Data);
			File.WriteAllText(AppPaths.Tabs, JsonConvert.SerializeObject(this, Formatting.Indented));
		}
		catch (Exception)
		{
		}
	}
}
