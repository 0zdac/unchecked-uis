using System;
using System.Windows;
using System.Windows.Controls;

namespace supQ;

public class TabStripPanel : Panel
{
	public static readonly DependencyProperty MinTabWidthProperty = DependencyProperty.Register("MinTabWidth", typeof(double), typeof(TabStripPanel), new FrameworkPropertyMetadata(54.0, FrameworkPropertyMetadataOptions.AffectsMeasure));

	public static readonly DependencyProperty MaxTabWidthProperty = DependencyProperty.Register("MaxTabWidth", typeof(double), typeof(TabStripPanel), new FrameworkPropertyMetadata(190.0, FrameworkPropertyMetadataOptions.AffectsMeasure));

	private const double CompactBelow = 92.0;

	public static readonly DependencyProperty IsCompactProperty = DependencyProperty.RegisterAttached("IsCompact", typeof(bool), typeof(TabStripPanel), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.Inherits));

	public double MinTabWidth
	{
		get
		{
			return (double)GetValue(MinTabWidthProperty);
		}
		set
		{
			SetValue(MinTabWidthProperty, value);
		}
	}

	public double MaxTabWidth
	{
		get
		{
			return (double)GetValue(MaxTabWidthProperty);
		}
		set
		{
			SetValue(MaxTabWidthProperty, value);
		}
	}

	public static void SetIsCompact(DependencyObject element, bool value)
	{
		element.SetValue(IsCompactProperty, value);
	}

	public static bool GetIsCompact(DependencyObject element)
	{
		return (bool)element.GetValue(IsCompactProperty);
	}

	private double SlotWidth(double available, int count)
	{
		if (count == 0)
		{
			return 0.0;
		}
		return Math.Max(MinTabWidth, Math.Min(MaxTabWidth, available / (double)count));
	}

	protected override Size MeasureOverride(Size availableSize)
	{
		int count = base.InternalChildren.Count;
		double height = (double.IsInfinity(availableSize.Height) ? 36.0 : availableSize.Height);
		if (count == 0)
		{
			return new Size(0.0, height);
		}
		double num = (double.IsInfinity(availableSize.Width) ? (MaxTabWidth * (double)count) : availableSize.Width);
		double num2 = SlotWidth(num, count);
		bool value = num2 < 92.0;
		foreach (UIElement internalChild in base.InternalChildren)
		{
			DependencyObject dependencyObject2;
			DependencyObject dependencyObject = (dependencyObject2 = internalChild);
			if (dependencyObject2 != null)
			{
				SetIsCompact(dependencyObject2, value);
			}
			((UIElement)dependencyObject).Measure(new Size(num2, height));
		}
		return new Size(Math.Min(num, num2 * (double)count), height);
	}

	protected override Size ArrangeOverride(Size finalSize)
	{
		int count = base.InternalChildren.Count;
		if (count == 0)
		{
			return finalSize;
		}
		double num = SlotWidth(finalSize.Width, count);
		double num2 = 0.0;
		foreach (UIElement internalChild in base.InternalChildren)
		{
			internalChild.Arrange(new Rect(num2, 0.0, num, finalSize.Height));
			num2 += num;
		}
		return finalSize;
	}
}
