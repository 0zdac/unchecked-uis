using System.Windows.Media;

namespace supQ;

public record Theme(string Name, Color Accent, Color AccentBright, Color AccentDim, Color AccentSubtle, Color AccentBorder, Color BgTop, Color BgMid, Color BgBottom, Color TitleBar, Color Rail, Color Panel, Color Surface, Color SurfaceRaised, Color Stroke, Color StrokeSoft, Color TextBright, Color TextMuted, Color TextDim)
{
	public bool IsLight { get; init; }

	public bool Glass { get; init; }

	public bool IsCustom { get; init; }
}
