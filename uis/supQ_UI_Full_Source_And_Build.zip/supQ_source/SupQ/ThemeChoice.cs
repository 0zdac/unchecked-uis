using System.Windows.Media;

namespace supQ;

public class ThemeChoice
{
	public string Name { get; init; } = "";

	public Brush Dot { get; init; } = Brushes.Transparent;

	public bool IsCustom { get; init; }
}
