using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using Newtonsoft.Json;

namespace supQ;

public static class ThemeManager
{
	private class ThemeDto
	{
		public string Name { get; set; } = "";

		public bool IsLight { get; set; }

		public bool Glass { get; set; }

		public Dictionary<string, string> Colors { get; set; } = new Dictionary<string, string>();
	}

	public static readonly List<Theme> Builtin;

	private static readonly List<Theme> _custom;

	public static readonly string[] Slots;

	public static IReadOnlyList<Theme> Custom => _custom;

	public static List<Theme> Themes
	{
		get
		{
			List<Theme> list = new List<Theme>(Builtin);
			list.AddRange(_custom);
			return list;
		}
	}

	public static Theme Current { get; private set; }

	private static string StorePath => AppPaths.Themes;

	private static Color C(string hex)
	{
		return FromHex(hex);
	}

	static ThemeManager()
	{
		Builtin = new List<Theme>
		{
			new Theme("Midnight", C("9B7BFF"), C("B8A1FF"), C("6A44D8"), C("231A40"), C("433275"), C("211E26"), C("1D1A22"), C("19171E"), C("211E26"), C("211E26"), C("282530"), C("2E2B38"), C("3A3647"), C("3D374D"), C("2C2738"), C("FFFFFF"), C("D4CEE0"), C("8E879C")),
			new Theme("Windows 7 Aero", C("1B7FD9"), C("42A5F5"), C("0D47A1"), C("D6EAF8"), C("8CC0E8"), C("D2E5F5"), C("E3EEF8"), C("F2F7FC"), C("B8D8F0"), C("F0F5FA"), C("E4EEF7"), C("FFFFFF"), C("F2F7FC"), C("96B8D6"), C("C8DCEF"), C("0C2942"), C("355670"), C("6888A0"))
			{
				IsLight = true,
				Glass = true
			},
			new Theme("Windows XP Luna", C("0055EA"), C("2C85FF"), C("003C9E"), C("D6E5F8"), C("7F9DB9"), C("ECE9D8"), C("ECE9D8"), C("E0DCC8"), C("0055EA"), C("D6DFF7"), C("ECE9D8"), C("FFFFFF"), C("F7F5EE"), C("7F9DB9"), C("D0D7E5"), C("000000"), C("444444"), C("777777"))
			{
				IsLight = true
			},
			new Theme("Slate", C("22D3EE"), C("67E8F9"), C("0E7490"), C("122E38"), C("1E5260"), C("202224"), C("1C1E20"), C("181A1C"), C("202224"), C("202224"), C("26292D"), C("2C3035"), C("383D44"), C("3B424C"), C("2A3038"), C("FFFFFF"), C("D0D8E0"), C("88929C")),
			new Theme("Emerald", C("34D399"), C("6EE7B7"), C("059669"), C("133026"), C("1E5945"), C("1E2421"), C("1A201D"), C("171C19"), C("1E2421"), C("1E2421"), C("252D29"), C("2B3530"), C("36433D"), C("384740"), C("28332E"), C("FFFFFF"), C("CFDCD5"), C("87968E")),
			new Theme("Crimson", C("FB7185"), C("FDA4AF"), C("E11D48"), C("381B22"), C("662C3A"), C("241E20"), C("201A1C"), C("1C1718"), C("241E20"), C("201A1C"), C("2D2628"), C("352D30"), C("44393D"), C("4A3C41"), C("33292D"), C("FFFFFF"), C("DCD0D3"), C("96878B")),
			new Theme("Amber", C("FBBF24"), C("FCD34D"), C("D97706"), C("362711"), C("63481D"), C("24221E"), C("201E1A"), C("1C1A17"), C("24221E"), C("24221E"), C("2D2A25"), C("35322B"), C("444037"), C("4A453A"), C("332F27"), C("FFFFFF"), C("DCD6CE"), C("968E84")),
			new Theme("Monochrome", C("FFFFFF"), C("FFFFFF"), C("808080"), C("242424"), C("3E3E3E"), C("1C1C1C"), C("181818"), C("141414"), C("1C1C1C"), C("1C1C1C"), C("222222"), C("282828"), C("333333"), C("3A3A3A"), C("282828"), C("FFFFFF"), C("CCCCCC"), C("888888")),
			new Theme("Paper", C("2B2B2B"), C("000000"), C("666666"), C("F0F0F0"), C("D4D4D4"), C("FFFFFF"), C("FAFAFA"), C("F3F3F3"), C("FFFFFF"), C("FAFAFA"), C("FFFFFF"), C("FFFFFF"), C("F2F2F2"), C("DCDCDC"), C("ECECEC"), C("111111"), C("5C5C5C"), C("949494"))
			{
				IsLight = true
			}
		};
		_custom = new List<Theme>();
		Current = Builtin[0];
		Slots = new string[18]
		{
			"Accent", "AccentBright", "AccentDim", "AccentSubtle", "AccentBorder", "BgTop", "BgMid", "BgBottom", "TitleBar", "Rail",
			"Panel", "Surface", "SurfaceRaised", "Stroke", "StrokeSoft", "TextBright", "TextMuted", "TextDim"
		};
		LoadCustom();
	}

	public static Theme ByName(string? name)
	{
		return Find(name) ?? Builtin[0];
	}

	public static Theme? Find(string? name)
	{
		if (name != null)
		{
			return Themes.FirstOrDefault((Theme t) => t.Name == name);
		}
		return null;
	}

	public static bool IsBuiltinName(string? name)
	{
		return Builtin.Any((Theme t) => t.Name == name);
	}

	public static string UniqueName(string baseName, string? ignore = null)
	{
		baseName = (string.IsNullOrWhiteSpace(baseName) ? "Custom Theme" : baseName.Trim());
		if (!Taken(baseName))
		{
			return baseName;
		}
		for (int i = 2; i < 1000; i++)
		{
			string text = $"{baseName} {i}";
			if (!Taken(text))
			{
				return text;
			}
		}
		return $"{baseName} {Guid.NewGuid():N}".Substring(0, 40);
		bool Taken(string n)
		{
			if (n != ignore)
			{
				return Themes.Any((Theme t) => t.Name == n);
			}
			return false;
		}
	}

	public static Theme Upsert(Theme theme, string? replacing = null)
	{
		Theme saved = theme with
		{
			IsCustom = true
		};
		int num = _custom.FindIndex((Theme t) => t.Name == saved.Name || (replacing != null && t.Name == replacing));
		_custom.RemoveAll((Theme t) => t.Name == saved.Name || (replacing != null && t.Name == replacing));
		if (num >= 0 && num <= _custom.Count)
		{
			_custom.Insert(num, saved);
		}
		else
		{
			_custom.Add(saved);
		}
		SaveCustom();
		return saved;
	}

	public static void Delete(string name)
	{
		_custom.RemoveAll((Theme t) => t.Name == name);
		SaveCustom();
	}

	private static void LoadCustom()
	{
		try
		{
			if (!File.Exists(StorePath))
			{
				return;
			}
			List<ThemeDto> list = JsonConvert.DeserializeObject<List<ThemeDto>>(File.ReadAllText(StorePath));
			if (list == null)
			{
				return;
			}
			foreach (ThemeDto item in list)
			{
				Theme theme = FromDto(item);
				if (theme != null && !IsBuiltinName(theme.Name) && !_custom.Any((Theme t) => t.Name == theme.Name))
				{
					_custom.Add(theme);
				}
			}
		}
		catch (Exception)
		{
		}
	}

	private static void SaveCustom()
	{
		try
		{
			string storePath = StorePath;
			string directoryName = Path.GetDirectoryName(storePath);
			if (!string.IsNullOrEmpty(directoryName) && !Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			List<ThemeDto> value = _custom.Select(ToDto).ToList();
			File.WriteAllText(storePath, JsonConvert.SerializeObject(value, Formatting.Indented));
		}
		catch (Exception)
		{
		}
	}

	public static void Export(Theme theme, string path)
	{
		File.WriteAllText(path, JsonConvert.SerializeObject(ToDto(theme), Formatting.Indented));
	}

	public static Theme? Import(string path)
	{
		string text = File.ReadAllText(path).TrimStart();
		return FromDto((!text.StartsWith("[")) ? JsonConvert.DeserializeObject<ThemeDto>(text) : JsonConvert.DeserializeObject<List<ThemeDto>>(text)?.FirstOrDefault());
	}

	private static ThemeDto ToDto(Theme t)
	{
		return new ThemeDto
		{
			Name = t.Name,
			IsLight = t.IsLight,
			Glass = t.Glass,
			Colors = Slots.ToDictionary((string s) => s, (string s) => ToHex(Get(t, s)))
		};
	}

	private static Theme? FromDto(ThemeDto? dto)
	{
		if (dto == null || string.IsNullOrWhiteSpace(dto.Name))
		{
			return null;
		}
		Theme theme = Builtin[0]with
		{
			Name = dto.Name.Trim(),
			IsLight = dto.IsLight,
			Glass = dto.Glass,
			IsCustom = true
		};
		string[] slots = Slots;
		foreach (string text in slots)
		{
			if (dto.Colors.TryGetValue(text, out string value) && TryParseHex(value, out var color))
			{
				theme = With(theme, text, color);
			}
		}
		return theme;
	}

	public static Color Get(Theme t, string slot)
	{
		return slot switch
		{
			"Accent" => t.Accent, 
			"AccentBright" => t.AccentBright, 
			"AccentDim" => t.AccentDim, 
			"AccentSubtle" => t.AccentSubtle, 
			"AccentBorder" => t.AccentBorder, 
			"BgTop" => t.BgTop, 
			"BgMid" => t.BgMid, 
			"BgBottom" => t.BgBottom, 
			"TitleBar" => t.TitleBar, 
			"Rail" => t.Rail, 
			"Panel" => t.Panel, 
			"Surface" => t.Surface, 
			"SurfaceRaised" => t.SurfaceRaised, 
			"Stroke" => t.Stroke, 
			"StrokeSoft" => t.StrokeSoft, 
			"TextBright" => t.TextBright, 
			"TextMuted" => t.TextMuted, 
			"TextDim" => t.TextDim, 
			_ => t.Accent, 
		};
	}

	public static Theme With(Theme t, string slot, Color c)
	{
		return slot switch
		{
			"Accent" => t with
			{
				Accent = c
			}, 
			"AccentBright" => t with
			{
				AccentBright = c
			}, 
			"AccentDim" => t with
			{
				AccentDim = c
			}, 
			"AccentSubtle" => t with
			{
				AccentSubtle = c
			}, 
			"AccentBorder" => t with
			{
				AccentBorder = c
			}, 
			"BgTop" => t with
			{
				BgTop = c
			}, 
			"BgMid" => t with
			{
				BgMid = c
			}, 
			"BgBottom" => t with
			{
				BgBottom = c
			}, 
			"TitleBar" => t with
			{
				TitleBar = c
			}, 
			"Rail" => t with
			{
				Rail = c
			}, 
			"Panel" => t with
			{
				Panel = c
			}, 
			"Surface" => t with
			{
				Surface = c
			}, 
			"SurfaceRaised" => t with
			{
				SurfaceRaised = c
			}, 
			"Stroke" => t with
			{
				Stroke = c
			}, 
			"StrokeSoft" => t with
			{
				StrokeSoft = c
			}, 
			"TextBright" => t with
			{
				TextBright = c
			}, 
			"TextMuted" => t with
			{
				TextMuted = c
			}, 
			"TextDim" => t with
			{
				TextDim = c
			}, 
			_ => t, 
		};
	}

	public static string ToHex(Color c)
	{
		return $"#{c.R:X2}{c.G:X2}{c.B:X2}";
	}

	public static Color FromHex(string hex)
	{
		TryParseHex(hex, out var color);
		return color;
	}

	public static bool TryParseHex(string? hex, out Color color)
	{
		color = Colors.Black;
		if (string.IsNullOrWhiteSpace(hex))
		{
			return false;
		}
		hex = hex.Trim().TrimStart('#');
		if (hex.Length == 3)
		{
			hex = $"{hex[0]}{hex[0]}{hex[1]}{hex[1]}{hex[2]}{hex[2]}";
		}
		if (hex.Length != 6)
		{
			return false;
		}
		try
		{
			color = Color.FromRgb(Convert.ToByte(hex.Substring(0, 2), 16), Convert.ToByte(hex.Substring(2, 2), 16), Convert.ToByte(hex.Substring(4, 2), 16));
			return true;
		}
		catch
		{
			return false;
		}
	}

	public static Color Mix(Color a, Color b, double amount)
	{
		amount = MathX.Clamp(amount, 0.0, 1.0);
		return Color.FromRgb((byte)Math.Round((double)(int)a.R + (double)(b.R - a.R) * amount), (byte)Math.Round((double)(int)a.G + (double)(b.G - a.G) * amount), (byte)Math.Round((double)(int)a.B + (double)(b.B - a.B) * amount));
	}

	public static Color Lighten(Color c, double amount)
	{
		return Mix(c, Colors.White, amount);
	}

	public static Color Darken(Color c, double amount)
	{
		return Mix(c, Colors.Black, amount);
	}

	public static double Luminance(Color c)
	{
		return (0.299 * (double)(int)c.R + 0.587 * (double)(int)c.G + 0.114 * (double)(int)c.B) / 255.0;
	}

	public static (double H, double S, double V) ToHsv(Color c)
	{
		double num = (double)(int)c.R / 255.0;
		double num2 = (double)(int)c.G / 255.0;
		double num3 = (double)(int)c.B / 255.0;
		double num4 = Math.Max(num, Math.Max(num2, num3));
		double num5 = Math.Min(num, Math.Min(num2, num3));
		double num6 = num4 - num5;
		double num7 = 0.0;
		if (num6 > 0.0)
		{
			num7 = ((num4 == num) ? (60.0 * ((num2 - num3) / num6 % 6.0)) : ((num4 != num2) ? (60.0 * ((num - num2) / num6 + 4.0)) : (60.0 * ((num3 - num) / num6 + 2.0))));
		}
		if (num7 < 0.0)
		{
			num7 += 360.0;
		}
		return (H: num7, S: (num4 <= 0.0) ? 0.0 : (num6 / num4), V: num4);
	}

	public static Color FromHsv(double h, double s, double v)
	{
		h = (h % 360.0 + 360.0) % 360.0;
		s = MathX.Clamp(s, 0.0, 1.0);
		v = MathX.Clamp(v, 0.0, 1.0);
		double num = v * s;
		double num2 = num * (1.0 - Math.Abs(h / 60.0 % 2.0 - 1.0));
		double num3 = v - num;
		var (num4, num5, num6) = ((h < 60.0) ? (num, num2, 0.0) : ((h < 120.0) ? (num2, num, 0.0) : ((h < 180.0) ? (0.0, num, num2) : ((h < 240.0) ? (0.0, num2, num) : ((!(h < 300.0)) ? (num, 0.0, num2) : (num2, 0.0, num))))));
		return Color.FromRgb((byte)Math.Round((num4 + num3) * 255.0), (byte)Math.Round((num5 + num3) * 255.0), (byte)Math.Round((num6 + num3) * 255.0));
	}

	public static Theme DeriveAccentRamp(Theme t)
	{
		Color accent = t.Accent;
		return t with
		{
			AccentBright = Lighten(accent, t.IsLight ? 0.1 : 0.25),
			AccentDim = Darken(accent, t.IsLight ? 0.3 : 0.45),
			AccentSubtle = (t.IsLight ? Lighten(accent, 0.88) : Mix(t.Surface, accent, 0.18)),
			AccentBorder = (t.IsLight ? Lighten(accent, 0.6) : Mix(t.Surface, accent, 0.45))
		};
	}

	private static LinearGradientBrush V(params (string Hex, double Offset)[] stops)
	{
		GradientStopCollection gradientStopCollection = new GradientStopCollection();
		for (int i = 0; i < stops.Length; i++)
		{
			var (hex, offset) = stops[i];
			gradientStopCollection.Add(new GradientStop(C(hex), offset));
		}
		return new LinearGradientBrush(gradientStopCollection, new Point(0.0, 0.0), new Point(0.0, 1.0));
	}

	public static void Apply(Theme t)
	{
		Current = t;
		ResourceDictionary r = Application.Current.Resources;
		r["AccentColor"] = t.Accent;
		r["AccentBrightColor"] = t.AccentBright;
		r["AccentBrush"] = new SolidColorBrush(t.Accent);
		r["AccentBrightBrush"] = new SolidColorBrush(t.AccentBright);
		r["AccentDimBrush"] = new SolidColorBrush(t.AccentDim);
		r["AccentSubtleBrush"] = new SolidColorBrush(t.AccentSubtle);
		r["AccentBorderBrush"] = new SolidColorBrush(t.AccentBorder);
		r["TitleBarBrush"] = new SolidColorBrush(t.TitleBar);
		r["RailBrush"] = new SolidColorBrush(t.Rail);
		r["PanelBrush"] = new SolidColorBrush(t.Panel);
		r["SurfaceBrush"] = new SolidColorBrush(t.Surface);
		r["SurfaceRaisedBrush"] = new SolidColorBrush(t.SurfaceRaised);
		r["StrokeBrush"] = new SolidColorBrush(t.Stroke);
		r["StrokeSoftBrush"] = new SolidColorBrush(t.StrokeSoft);
		r["TextBrightBrush"] = new SolidColorBrush(t.TextBright);
		r["TextMutedBrush"] = new SolidColorBrush(t.TextMuted);
		r["TextDimBrush"] = new SolidColorBrush(t.TextDim);
		r["BgBrush"] = new LinearGradientBrush(new GradientStopCollection
		{
			new GradientStop(t.BgTop, 0.0),
			new GradientStop(t.BgMid, 0.55),
			new GradientStop(t.BgBottom, 1.0)
		}, new Point(0.0, 0.0), new Point(1.0, 1.0));
		r["ShellBrush"] = new SolidColorBrush(t.BgBottom);
		Family("Run", C("4ADE80"));
		Family("Danger", C("F87171"));
		Family("Inject", t.Accent);
		r["NeutralFillBrush"] = new SolidColorBrush(t.SurfaceRaised);
		r["NeutralLineBrush"] = new SolidColorBrush(t.Stroke);
		r["NeutralTextBrush"] = new SolidColorBrush(t.TextMuted);
		if (t.Glass && t.IsCustom)
		{
			r["TitleBarBrush"] = Gloss(t.TitleBar, 0.55, 0.18, 0.12, 0.3);
			r["RailBrush"] = Gloss(t.Rail, 0.22, 0.06, 0.04, 0.12);
			r["PanelBrush"] = Gloss(t.Panel, 0.2, 0.05, 0.03, 0.1);
			r["SurfaceRaisedBrush"] = Gloss(t.SurfaceRaised, 0.45, 0.14, 0.1, 0.22);
		}
		else if (t.Glass)
		{
			r["TitleBarBrush"] = V(("F6FBFF", 0.0), ("D2E6F8", 0.4), ("A8CEEC", 0.41), ("BFDCF2", 0.88), ("DCEDFB", 1.0));
			r["RailBrush"] = V(("EEF6FD", 0.0), ("DFEDF9", 1.0));
			r["PanelBrush"] = V(("F6FAFE", 0.0), ("E9F2FB", 1.0));
			r["SurfaceRaisedBrush"] = V(("FFFFFF", 0.0), ("F2F8FE", 0.49), ("E2EFFA", 0.5), ("EEF6FD", 1.0));
			r["BgBrush"] = V(("F7FBFE", 0.0), ("E9F2FA", 0.55), ("DEEBF7", 1.0));
		}
		void Family(string name, Color hue)
		{
			r[name + "FillBrush"] = new SolidColorBrush(t.IsLight ? Lighten(hue, 0.86) : Mix(t.Surface, hue, 0.16));
			r[name + "LineBrush"] = new SolidColorBrush(t.IsLight ? Lighten(hue, 0.55) : Mix(t.Surface, hue, 0.42));
			r[name + "TextBrush"] = new SolidColorBrush(t.IsLight ? Darken(hue, 0.45) : Lighten(hue, 0.1));
		}
		static LinearGradientBrush Gloss(Color base_, double top, double breakHi, double breakLo, double bottom)
		{
			return new LinearGradientBrush(new GradientStopCollection
			{
				new GradientStop(Lighten(base_, top), 0.0),
				new GradientStop(Lighten(base_, breakHi), 0.49),
				new GradientStop(Darken(base_, breakLo), 0.5),
				new GradientStop(Lighten(base_, bottom), 1.0)
			}, new Point(0.0, 0.0), new Point(0.0, 1.0));
		}
	}

	public static void ApplyAndRemember(Theme t, AppSettings settings)
	{
		Apply(t);
		settings.ThemeName = t.Name;
		settings.Save();
	}
}
