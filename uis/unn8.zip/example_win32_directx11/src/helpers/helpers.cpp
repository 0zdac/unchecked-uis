#include <helpers/helpers.h>

namespace helpers {
	bool tab(const char* id, const char* label, bool selected, ImVec2 size) {
		ImGui::PushID(id);
		ImGui::InvisibleButton(label, size);
		bool clicked = ImGui::IsItemClicked();
		
		ImVec2 pos = ImGui::GetItemRectMin();
		ImVec2 max = ImGui::GetItemRectMax();
		ImDrawList* draw = ImGui::GetWindowDrawList();
		
		if (selected) {
			draw->AddRectFilledMultiColor(pos, max,
				IM_COL32(40, 40, 40, 255), IM_COL32(40, 40, 40, 255),
				IM_COL32(27, 27, 27, 255), IM_COL32(27, 27, 27, 255));
		} else {
			draw->AddRectFilledMultiColor(pos, max,
				IM_COL32(59, 59, 59, 255), IM_COL32(59, 59, 59, 255),
				IM_COL32(39, 39, 39, 255), IM_COL32(39, 39, 39, 255));
		}
		
		draw->AddRect(pos, max, IM_COL32(0, 0, 0, 255));
		
		ImVec2 text_size = ImGui::CalcTextSize(label);
		draw->AddText(ImVec2(pos.x + (size.x - text_size.x) * 0.5f, pos.y + (size.y - text_size.y) * 0.5f), IM_COL32(255, 255, 255, 255), label);
		
		ImGui::PopID();
		return clicked;
	}

	bool subtab(const char* id, const char* label, bool selected, ImVec2 size) {
		ImGui::PushID(id);
		ImGui::InvisibleButton(label, size);
		bool clicked = ImGui::IsItemClicked();
		
		ImVec2 pos = ImGui::GetItemRectMin();
		ImVec2 max = ImGui::GetItemRectMax();
		ImDrawList* draw = ImGui::GetWindowDrawList();
		
		if (selected) {
			draw->AddRectFilledMultiColor(pos, max,
				IM_COL32(40, 40, 40, 255), IM_COL32(40, 40, 40, 255),
				IM_COL32(26, 26, 26, 255), IM_COL32(26, 26, 26, 255));
		} else {
			draw->AddRectFilledMultiColor(pos, max,
				IM_COL32(59, 59, 59, 255), IM_COL32(59, 59, 59, 255),
				IM_COL32(39, 39, 39, 255), IM_COL32(39, 39, 39, 255));
		}
		
		draw->AddRect(pos, max, IM_COL32(0, 0, 0, 255));
		
		ImVec2 text_size = ImGui::CalcTextSize(label);
		draw->AddText(ImVec2(pos.x + (size.x - text_size.x) * 0.5f, pos.y + (size.y - text_size.y) * 0.5f), IM_COL32(255, 255, 255, 255), label);
		
		ImGui::PopID();
		return clicked;
	}

	void section(const char* label, ImVec2 size) {
		ImVec2 pos = ImGui::GetCursorScreenPos();
		ImDrawList* draw = ImGui::GetWindowDrawList();

		draw->AddLine(ImVec2(pos.x, pos.y + size.y), ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(0, 0, 0, 255));

		ImVec2 text_size = ImGui::CalcTextSize(label);
		draw->AddText(ImVec2(pos.x + 8.0f, pos.y + (size.y - text_size.y) * 0.5f), IM_COL32(255, 255, 255, 255), label);
		
		ImGui::Dummy(size);
	}

	void begin_child(const char* id, ImVec2 size) {
		ImVec2 cp = ImGui::GetCursorScreenPos();
		ImDrawList* draw = ImGui::GetWindowDrawList();

		draw->AddRectFilledMultiColor(cp, ImVec2(cp.x + size.x, cp.y + size.y), 
			IM_COL32(55, 55, 55, 255), IM_COL32(55, 55, 55, 255),
			IM_COL32(40, 40, 40, 255), IM_COL32(40, 40, 40, 255));
		draw->AddRect(cp, ImVec2(cp.x + size.x, cp.y + size.y), IM_COL32(0, 0, 0, 255));

		ImGui::PushStyleColor(ImGuiCol_ChildBg, IM_COL32(0, 0, 0, 0));
		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
		ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
		ImGui::BeginChild(id, size, false, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
	}

	void end_child() {
		ImGui::EndChild();
		ImGui::PopStyleVar(2);
		ImGui::PopStyleColor();
	}
}