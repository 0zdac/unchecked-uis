#pragma once
#include <imgui/imgui.h>
#include <imgui/imgui_internal.h>

namespace helpers {
    bool tab(const char* id, const char* label, bool selected, ImVec2 size);
    bool subtab(const char* id, const char* label, bool selected, ImVec2 size);
    void section(const char* label, ImVec2 size);
    void begin_child(const char* id, ImVec2 size);
    void end_child();
}