#include <menu.h>


namespace render {

	void menu() {
		ImGui::SetNextWindowSize(ImVec2(432, 258), ImGuiCond_Once);
		ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.0f);
		ImGui::PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
		ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(0, 0, 0, 255));
		
		ImGuiWindowFlags xx = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse;
		ImGui::Begin("##menu", nullptr, xx);
		ImGui::PopStyleColor(2);
		ImGui::PopStyleVar();
		
		ImVec2 p = ImGui::GetWindowPos();
		ImVec2 s = ImGui::GetWindowSize();
		ImDrawList* draw = ImGui::GetWindowDrawList();
		
		/* main window gradients */ 
		draw->AddRectFilledMultiColor(p, ImVec2(p.x + s.x, p.y + s.y),
			IM_COL32(40, 40, 40, 255),
			IM_COL32(40, 40, 40, 255),
			IM_COL32(26, 26, 26, 255),
			IM_COL32(26, 26, 26, 255));

		draw->AddRect(p, ImVec2(p.x + 432, p.y + 22), IM_COL32(0, 0, 0, 255));
		
		const char* title_text = "title";
		ImVec2 title_size = ImGui::CalcTextSize(title_text);
		draw->AddText(ImVec2(p.x + 7.0f, p.y + (22.0f - title_size.y) * 0.5f + 1.0f), IM_COL32(255, 255, 255, 255), title_text);

		ImGui::SetCursorPos(ImVec2(5, 26));
		helpers::begin_child("##tabs", ImVec2(97, 227));
		
		static int tab = 0;
		
		if (helpers::tab("tab1", "tab", tab == 0, ImVec2(97, 20))) tab = 0;
		ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 1 /* overlap by 1px so outlines NOT getting fuck */ );
		if (helpers::tab("tab2", "tab", tab == 1, ImVec2(97, 20))) tab = 1;
		
		helpers::end_child();

		ImGui::SetCursorPos(ImVec2(106, 26));
		helpers::begin_child("##subtabs", ImVec2(321, 22));
		
		static int subtab = 0;
		if (helpers::subtab("sub1", "sub-tab", subtab == 0, ImVec2(107, 22))) subtab = 0;
		ImGui::SameLine(0, 0);
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() - 1 /* overlap by 1px so outlines NOT getting fuck */ );
		if (helpers::subtab("sub2", "sub-tab", subtab == 1, ImVec2(108, 22))) subtab = 1;
		ImGui::SameLine(0, 0);
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() - 1 /* overlap by 1px so outlines NOT getting fuck */ );
		if (helpers::subtab("sub3", "sub-tab", subtab == 2, ImVec2(108, 22))) subtab = 2;
		helpers::end_child();

		ImGui::SetCursorPos(ImVec2(106, 52));
		helpers::begin_child("##child1", ImVec2(159, 201));
		
		helpers::section("section", ImVec2(159, 18));
		
		static bool toggle = false;
		widgets::checkbox("toggle", &toggle);
		
		static float color[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
		widgets::colorpicker("colorpicker", color);
		
		static int key = 0;
		static int keymode = 0;
		widgets::keybind("keybind", &key, &keymode);
		
		static int slider = 50;
		widgets::slider_int("slider", &slider, 0, 100);

		widgets::button("button");

		helpers::end_child();

		ImGui::SetCursorPos(ImVec2(269, 52));
		helpers::begin_child("##child2", ImVec2(158, 201));
		
		helpers::section("section", ImVec2(158, 18));
		
		helpers::end_child();

		ImGui::End();
	}

}
