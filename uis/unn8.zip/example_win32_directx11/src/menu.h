#pragma once
#include <imgui/imgui.h>
#include <imgui/imgui_internal.h>
#include <helpers/helpers.h>
#include <widgets/widgets.h>

namespace render {
    void menu();
}
