#include <widgets/widgets.h>
#include <windows.h>
#include <stdio.h>
#include <ctype.h>

const char* keyname(int key) {
	if (key == 0) return "[-]";
	static char buf[16];
	switch (key) {
		case VK_LBUTTON: return "[m1]";
		case VK_RBUTTON: return "[m2]";
		case VK_MBUTTON: return "[m3]";
		case VK_XBUTTON1: return "[m4]";
		case VK_XBUTTON2: return "[m5]";
		case VK_SHIFT: return "[sht]";
		case VK_CONTROL: return "[ctl]";
		case VK_MENU: return "[alt]";
		case VK_SPACE: return "[spc]";
		default:
			UINT scan = MapVirtualKeyA(key, MAPVK_VK_TO_VSC);
			char name[16] = {0};
			if (GetKeyNameTextA(scan << 16, name, sizeof(name)) > 0) {
				snprintf(buf, sizeof(buf), "[%.3s]", name);
				for(int i=1; buf[i] && buf[i]!=']'; i++) {
					if(buf[i] >= 'A' && buf[i] <= 'Z') buf[i] += 32;
				}
				return buf;
			}
			snprintf(buf, sizeof(buf), "[%c]", (char)tolower(key));
			return buf;
	}
}

namespace widgets {
	bool checkbox(const char* label, bool* v) {
		ImGui::PushID(label);
		
		float avail_width = ImGui::GetContentRegionAvail().x;
		ImVec2 pos = ImGui::GetCursorScreenPos();
		ImVec2 text_size = ImGui::CalcTextSize(label);
		float height = 18.0f;
		
		ImVec2 cb_max = ImVec2(pos.x + avail_width - 8.0f, pos.y + (height + 12.0f) * 0.5f + 1.0f);
		ImVec2 cb_min = ImVec2(cb_max.x - 12.0f, cb_max.y - 12.0f);
		
		ImGui::SetCursorScreenPos(cb_min);
		ImGui::InvisibleButton("##cb", ImVec2(12.0f, 12.0f));
		bool clicked = ImGui::IsItemClicked();
		if (clicked) *v = !*v;
		
		ImGui::SetCursorScreenPos(pos);
		ImGui::ItemSize(ImVec2(avail_width, height));
		
		ImDrawList* draw = ImGui::GetWindowDrawList();
		
		draw->AddText(ImVec2(pos.x + 6.0f, pos.y + (height - text_size.y) * 0.5f + 1.0f), IM_COL32(255, 255, 255, 255), label);

		if (*v) {
			draw->AddRectFilledMultiColor(cb_min, cb_max,
				IM_COL32(145, 194, 58, 255), IM_COL32(145, 194, 58, 255),
				IM_COL32(99, 132, 39, 255), IM_COL32(99, 132, 39, 255));
		} else {
			draw->AddRectFilledMultiColor(cb_min, cb_max,
				IM_COL32(39, 39, 39, 255), IM_COL32(39, 39, 39, 255),
				IM_COL32(27, 27, 27, 255), IM_COL32(27, 27, 27, 255));
		}
		
		draw->AddRect(cb_min, cb_max, IM_COL32(0, 0, 0, 255));

		ImGui::PopID();
		return clicked;
	}

	bool colorpicker(const char* label, float* col) {
		ImGui::PushID(label);
		
		float avail_width = ImGui::GetContentRegionAvail().x;
		ImVec2 pos = ImGui::GetCursorScreenPos();
		ImVec2 text_size = ImGui::CalcTextSize(label);
		float height = 18.0f;
		
		ImVec2 cp_max = ImVec2(pos.x + avail_width - 8.0f, pos.y + (height + 12.0f) * 0.5f + 1.0f);
		ImVec2 cp_min = ImVec2(cp_max.x - 12.0f, cp_max.y - 12.0f);
		
		ImGui::SetCursorScreenPos(cp_min);
		ImGui::InvisibleButton("##cp", ImVec2(12.0f, 12.0f));
		bool clicked = ImGui::IsItemClicked();
		
		ImGui::SetCursorScreenPos(pos);
		ImGui::ItemSize(ImVec2(avail_width, height));
		
		ImDrawList* draw = ImGui::GetWindowDrawList();
		
		draw->AddText(ImVec2(pos.x + 7.0f, pos.y + (height - text_size.y) * 0.5f + 1.0f), IM_COL32(255, 255, 255, 255), label);
		
		ImU32 col32 = ImGui::ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], col[3]));
		draw->AddRectFilled(cp_min, cp_max, col32);
		draw->AddRect(cp_min, cp_max, IM_COL32(0, 0, 0, 255));
		
		if (clicked) {
			ImGui::OpenPopup("##cp_popup");
		}
		
		bool changed = false;
		
		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(4, 4));
		ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding, 0.0f);
		ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 1.0f);
		ImGui::PushStyleColor(ImGuiCol_PopupBg, IM_COL32(33, 33, 33, 255));
		ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(0, 0, 0, 255));
		
		if (ImGui::BeginPopup("##cp_popup")) {
			ImGui::PushItemWidth(140.0f);
			ImGui::PushStyleVar(ImGuiStyleVar_ItemInnerSpacing, ImVec2(6, 6));
			ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(40, 40, 40, 255));
			
			if (ImGui::ColorPicker4("##picker", col, ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoTooltip)) {
				changed = true;
			}
			
			ImGui::PopStyleColor();
			ImGui::PopStyleVar();
			ImGui::PopItemWidth();
			ImGui::EndPopup();
		}
		
		ImGui::PopStyleColor(2);
		ImGui::PopStyleVar(3);
		
		ImGui::PopID();
		return changed;
	}

	bool keybind(const char* label, int* key, int* mode) {
		ImGui::PushID(label);
		
		float avail_width = ImGui::GetContentRegionAvail().x;
		ImVec2 pos = ImGui::GetCursorScreenPos();
		ImVec2 text_size = ImGui::CalcTextSize(label);
		float height = 18.0f;
		
		static ImGuiID active = 0;
		const char* key_name;
		if (active == ImGui::GetID("##kb")) {
			key_name = "[.]";
		} else {
			key_name = keyname(*key);
		}
		ImVec2 textsize = ImGui::CalcTextSize(key_name);
		
		float rightedge = pos.x + avail_width - 7.0f;
		ImVec2 textPos = ImVec2(rightedge - textsize.x, pos.y + (height - textsize.y) * 0.5f + 1.0f);
		
		ImVec2 kb_min = ImVec2(textPos.x, pos.y);
		ImVec2 kb_size = ImVec2(textsize.x, height);
		
		ImGui::SetCursorScreenPos(kb_min);
		ImGui::InvisibleButton("##kb", kb_size);
		bool clicked = ImGui::IsItemClicked(ImGuiMouseButton_Left);
		bool right_clicked = ImGui::IsItemClicked(ImGuiMouseButton_Right);
		
		ImGui::SetCursorScreenPos(pos);
		ImGui::ItemSize(ImVec2(avail_width, height));
		
		if (clicked) {
			if (active == ImGui::GetID("##kb")) active = 0;
			else active = ImGui::GetID("##kb");
		}
		
		if (active == ImGui::GetID("##kb")) {
			for (int i = 1; i < 256; i++) {
				if (i == VK_ESCAPE) {
					if (GetAsyncKeyState(i) & 0x8000) {
						*key = 0;
						active = 0;
						break;
					}
				} else if (i != VK_LBUTTON && i != VK_RBUTTON) {
					if (GetAsyncKeyState(i) & 0x8000) {
						*key = i;
						active = 0;
						break;
					}
				}
			}
		}
		
		ImDrawList* draw = ImGui::GetWindowDrawList();
		
		draw->AddText(ImVec2(pos.x + 7.0f, pos.y + (height - text_size.y) * 0.5f + 1.0f), IM_COL32(255, 255, 255, 255), label);
		draw->AddText(textPos, IM_COL32(255, 255, 255, 255), key_name);
		
		if (right_clicked) {
			ImGui::OpenPopup("##kb_popup");
		}
		
		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(4, 4));
		ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding, 0.0f);
		ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 1.0f);
		ImGui::PushStyleColor(ImGuiCol_PopupBg, IM_COL32(33, 33, 33, 255));
		ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(0, 0, 0, 255));
		ImGui::PushStyleColor(ImGuiCol_HeaderHovered, IM_COL32(45, 45, 45, 255));
		ImGui::PushStyleColor(ImGuiCol_HeaderActive, IM_COL32(50, 50, 50, 255));
		
		if (ImGui::BeginPopup("##kb_popup")) {
			ImVec2 sel_size = ImVec2(0, ImGui::GetTextLineHeight() + 2.0f);
			
			ImGui::PushStyleColor(ImGuiCol_Text, *mode == 0 ? IM_COL32(145, 194, 58, 255) : IM_COL32(255, 255, 255, 255));
			if (ImGui::Selectable("toggle", false, 0, sel_size)) *mode = 0;
			ImGui::PopStyleColor();
			
			ImGui::PushStyleColor(ImGuiCol_Text, *mode == 1 ? IM_COL32(145, 194, 58, 255) : IM_COL32(255, 255, 255, 255));
			if (ImGui::Selectable("hold", false, 0, sel_size)) *mode = 1;
			ImGui::PopStyleColor();
			
			ImGui::PushStyleColor(ImGuiCol_Text, *mode == 2 ? IM_COL32(145, 194, 58, 255) : IM_COL32(255, 255, 255, 255));
			if (ImGui::Selectable("always", false, 0, sel_size)) *mode = 2;
			ImGui::PopStyleColor();
			
			ImGui::EndPopup();
		}
		
		ImGui::PopStyleColor(4);
		ImGui::PopStyleVar(3);
		
		ImGui::PopID();
		return active == ImGui::GetID("##kb");
	}

	bool slider_int(const char* label, int* v, int v_min, int v_max) {
		ImGui::PushID(label);
		
		float avail_width = ImGui::GetContentRegionAvail().x;
		ImVec2 pos = ImGui::GetCursorScreenPos();
		
		float box_width = 146.0f;
		float box_height = 12.0f;
		
		ImVec2 text_size = ImGui::CalcTextSize(label);
		
		ImVec2 text_pos = ImVec2(pos.x + 7.0f, pos.y + 2.0f);
		
		char val_buf[32];
		snprintf(val_buf, sizeof(val_buf), "%d", *v);
		ImVec2 val_size = ImGui::CalcTextSize(val_buf);
		ImVec2 val_pos = ImVec2(pos.x + avail_width - 8.0f - val_size.x, pos.y + 2.0f);
		
		float box_y = text_pos.y + text_size.y + 4.0f;
		ImVec2 box_min = ImVec2(pos.x + 7.0f, box_y);
		ImVec2 box_max = ImVec2(box_min.x + box_width, box_min.y + box_height);
		
		ImGui::SetCursorScreenPos(box_min);
		ImGui::InvisibleButton("##slider", ImVec2(box_width, box_height));
		bool active = ImGui::IsItemActive();
		
		if (active) {
			float mouse_x = ImGui::GetIO().MousePos.x;
			float ratio = (mouse_x - box_min.x) / box_width;
			ratio = ratio < 0.0f ? 0.0f : (ratio > 1.0f ? 1.0f : ratio);
			*v = v_min + (int)(ratio * (v_max - v_min));
		}
		
		float total_height = (box_max.y - pos.y) + 4.0f;
		ImGui::SetCursorScreenPos(pos);
		ImGui::ItemSize(ImVec2(avail_width, total_height));
		
		ImDrawList* draw = ImGui::GetWindowDrawList();
		
		draw->AddText(text_pos, IM_COL32(255, 255, 255, 255), label);
		draw->AddText(val_pos, IM_COL32(255, 255, 255, 255), val_buf);
		
		draw->AddRectFilled(box_min, box_max, IM_COL32(40, 40, 40, 255));
		
		float ratio = (float)(*v - v_min) / (float)(v_max - v_min);
		ratio = ratio < 0.0f ? 0.0f : (ratio > 1.0f ? 1.0f : ratio);
		if (ratio > 0.0f) {
			float fill_w = (float)(int)(box_width * ratio);
			ImVec2 filled_max = ImVec2(box_min.x + fill_w, box_max.y);
			draw->AddRectFilledMultiColor(box_min, filled_max,
				IM_COL32(145, 194, 58, 255), IM_COL32(145, 194, 58, 255),
				IM_COL32(99, 132, 39, 255), IM_COL32(99, 132, 39, 255));
				
			if (ratio < 1.0f) {
				draw->AddRectFilled(ImVec2(filled_max.x, box_min.y), ImVec2(filled_max.x + 1.0f, box_max.y), IM_COL32(0, 0, 0, 255));
			}
		}
		
		draw->AddRect(box_min, box_max, IM_COL32(0, 0, 0, 255));
		
		ImGui::PopID();
		return active;
	}

	bool button(const char* label) {
		ImGui::PushID(label);
		
		float avail_width = ImGui::GetContentRegionAvail().x;
		ImVec2 pos = ImGui::GetCursorScreenPos();
		float height = 18.0f;
		
		float box_width = 146.0f;
		float box_height = 14.0f;
		
		ImVec2 btn_min = ImVec2(pos.x + 7.0f, pos.y + (height - box_height) * 0.5f);
		ImVec2 btn_max = ImVec2(btn_min.x + box_width, btn_min.y + box_height);
		
		ImGui::SetCursorScreenPos(btn_min);
		ImGui::InvisibleButton("##btn", ImVec2(box_width, box_height));
		bool clicked = ImGui::IsItemClicked();
		bool active = ImGui::IsItemActive();
		bool hovered = ImGui::IsItemHovered();
		
		ImGui::SetCursorScreenPos(pos);
		ImGui::ItemSize(ImVec2(avail_width, height));
		
		ImDrawList* draw = ImGui::GetWindowDrawList();
		
		ImU32 col_top = IM_COL32(38, 38, 38, 255);
		ImU32 col_bot = IM_COL32(26, 26, 26, 255);
		
		if (active) {
			col_top = IM_COL32(20, 20, 20, 255);
			col_bot = IM_COL32(30, 30, 30, 255);
		} else if (hovered) {
			col_top = IM_COL32(45, 45, 45, 255);
			col_bot = IM_COL32(33, 33, 33, 255);
		}
		
		draw->AddRectFilledMultiColor(btn_min, btn_max, col_top, col_top, col_bot, col_bot);
		draw->AddRect(btn_min, btn_max, IM_COL32(0, 0, 0, 255));
		
		ImVec2 text_size = ImGui::CalcTextSize(label);
		ImVec2 text_pos = ImVec2(btn_min.x + (box_width - text_size.x) * 0.5f, btn_min.y + (box_height - text_size.y) * 0.5f + 1.0f);
		draw->AddText(text_pos, IM_COL32(255, 255, 255, 255), label);
		
		ImGui::PopID();
		return clicked;
	}
}