#pragma once
#include <imgui/imgui.h>
#include <imgui/imgui_internal.h>

namespace widgets {
    bool checkbox(const char* label, bool* v);
    bool colorpicker(const char* label, float* col);
    bool keybind(const char* label, int* key, int* mode);
    bool slider_int(const char* label, int* v, int v_min, int v_max);
    bool button(const char* label);
}