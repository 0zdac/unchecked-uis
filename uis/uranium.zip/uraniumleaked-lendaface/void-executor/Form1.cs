﻿using CuoreUI.Components;
using Guna.UI2.WinForms;
using KeyAuth;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace void_executor
{
    public partial class Form1 : Form
    {
        public static api KeyAuthApp = new api(
    name: "Uranium", // App name
    ownerid: "OSLP46kINd", // Account ID
    version: "1.0" // Application version. Used for automatic downloads see video here https://www.youtube.com/watch?v=kW195PLCBKs
                   //path: @"Your_Path_Here" // (OPTIONAL) see tutorial here https://www.youtube.com/watch?v=I9rxt821gMk&t=1s
);

        private Guna.UI2.WinForms.Guna2Button lastClickedButton;
        private Image lastClickedButtonImage;

        private Dictionary<Guna.UI2.WinForms.Guna2Button, Image> buttonImages = new Dictionary<Guna.UI2.WinForms.Guna2Button, Image>();

        private Dictionary<string, string> savedFiles = new Dictionary<string, string>();



        private void ClickImage(Guna.UI2.WinForms.Guna2Button clickedButton, Image newImage)
        {
            if (lastClickedButton != null && lastClickedButton != clickedButton)
            {
                lastClickedButton.Image = buttonImages[lastClickedButton];
            }

            if (!buttonImages.ContainsKey(clickedButton))
            {
                buttonImages[clickedButton] = clickedButton.Image;
            }

            clickedButton.Image = newImage;

            lastClickedButton = clickedButton;
            lastClickedButtonImage = newImage;
        }



        private async void InitializeAsync()
        {
            try
            {
                await webView21.EnsureCoreWebView2Async(null);
                webView21.CoreWebView2.Navigate(new Uri($"file:///{Directory.GetCurrentDirectory()}/Monaco/index.html").ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing WebView2: {ex.Message}", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private static string GetUserIdFromUsername(string username)
        {
            string url = "https://users.roblox.com/v1/usernames/users";
            string json = $"{{\"usernames\": [\"{username}\"]}}";

            try
            {
                using (var client = new WebClient())
                {
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    string response = client.UploadString(url, "POST", json);
                    JObject data = JObject.Parse(response);

                    if (data["data"] != null && data["data"].HasValues)
                    {
                        string userId = data["data"][0]["id"].ToString();
                        return userId;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error getting user ID for {username}: {ex.Message}", "Quantum X");
            }

            return null;
        }
        public static System.Drawing.Image GetAvatar(string username)
        {
            string userId = GetUserIdFromUsername(username);
            if (string.IsNullOrEmpty(userId))
                return null;

            string avatarUrl = $"https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={userId}&size=420x420&format=png";

            try
            {
                using (var client = new WebClient())
                {
                    string response = client.DownloadString(avatarUrl);
                    JObject data = JObject.Parse(response);
                    if (data["data"] != null && data["data"].HasValues)
                    {
                        string imageUrl = data["data"][0]["imageUrl"].ToString();


                        byte[] imageBytes = client.DownloadData(imageUrl);


                        using (var ms = new MemoryStream(imageBytes))
                        {
                            return System.Drawing.Image.FromStream(ms);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error getting avatar for {username}: {ex.Message}", "Quantum X");
            }

            return null;
        }


        public static string GetUsername()
        {
            string userName = Environment.UserName;
            string fp = $@"C:\\Users\\{userName}\\AppData\\Local\\Roblox\\LocalStorage\\appStorage.json";

            if (!File.Exists(fp))
                return null;

            try
            {
                string jsc = File.ReadAllText(fp);
                JObject jsd = JObject.Parse(jsc);
                if (jsd.ContainsKey("Username"))
                    return jsd["Username"]?.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error getting username {ex.Message}", "");
            }
            return null;
        }



        public Form1()
        {
            this.AutoScaleMode = AutoScaleMode.Dpi;

            InitializeComponent();

            KeyAuthApp.init();

            this.StartPosition = FormStartPosition.CenterScreen;// center the form


        }

        private async void Form1_Load(object sender, EventArgs e)
        {

            InitializeAsync();

            ClickImage(guna2Button5, Properties.Resources.layout_grid__3_);

            guna2Button5.ForeColor = Color.FromArgb(192, 42, 42);

            guna2Button11.HoverState.Image = Properties.Resources.map_arrow_right_svgrepo_com__1_;

            guna2Button12.HoverState.Image = Properties.Resources.eraser_svgrepo_com__1_;

            guna2Button14.HoverState.Image = Properties.Resources.folder_favourite_bookmark_svgrepo_com__1_;

            guna2Button13.HoverState.Image = Properties.Resources.archive_up_minimlistic_svgrepo_com__1_;

            HiddenPanel.Visible = false;
            ExecutionBaseTab.Visible = false;
            SettingsBaseTab.Visible = false;








            string user = GetUsername();
            label21.Text = user;
            var avatar = GetAvatar(user);
            if (avatar != null)
            {
                guna2CirclePictureBox1.Image = avatar;




                string userId = GetUserIdFromUsername(user);


                label30.Text = "" + userId;





            }

            guna2ShadowPanel1.AutoScroll = true;

            label34.Visible = false;



            if (IsInjected())
            {
                guna2PictureBox8.BringToFront();
                guna2PictureBox8.Visible = true;
                guna2PictureBox7.Visible = false;
            }
            else
            {
                guna2PictureBox7.BringToFront();
                guna2PictureBox8.Visible = false;
                guna2PictureBox7.Visible = true;
            }


            string expiryText = KeyAuthApp.expirydaysleft();
            days.Text = expiryText.Contains("Days") ? expiryText : expiryText + "d";











        }













        public void settext(string text)
        {
            string sanitizedText = text.Replace("\\", "\\\\").Replace("'", "\\'").Replace("\n", "\\n").Replace("\r", "\\r");
            webView21.CoreWebView2.ExecuteScriptAsync($"SetText('{sanitizedText}')");
        }


            private async void guna2Button4_Click(object sender, EventArgs e)
            {

       
            while (this.Opacity > 0)
            {
                this.Opacity -= 0.1; 
                await Task.Delay(10);
            }
            Application.Exit();
            Environment.Exit(0);
        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            ExecutionBaseTab.Visible = true;
            ExecutionBaseTab.BringToFront();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2PictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {
        }

        private void label24_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click_2(object sender, EventArgs e)
        {

        }

        private void guna2Panel10_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Button5_Enter(object sender, EventArgs e)
        {
            ClickImage(guna2Button5, Properties.Resources.layout_grid__3_);

            guna2Button5.ForeColor = Color.FromArgb(192, 42, 42);
        }

        private void guna2Button6_Enter(object sender, EventArgs e)
        {
            ClickImage(guna2Button6, Properties.Resources.code__1_);

            guna2Button6.ForeColor = Color.FromArgb(192, 42, 42);
        }

        private void guna2Button7_Enter(object sender, EventArgs e)
        {
            ClickImage(guna2Button7, Properties.Resources.cube_alt_2_svgrepo_com__4_);

            guna2Button7.ForeColor = Color.FromArgb(192, 42, 42);
        }

        private void guna2Button5_Leave(object sender, EventArgs e)
        {
            guna2Button5.ForeColor = Color.FromArgb(110, 110, 110);
        }

        private void guna2Button6_Leave(object sender, EventArgs e)
        {
            guna2Button6.ForeColor = Color.FromArgb(110, 110, 110);
        }

        private void guna2Button7_Leave(object sender, EventArgs e)
        {
            guna2Button7.ForeColor = Color.FromArgb(110, 110, 110);
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Panel12_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            ExecutionBaseTab.Visible = false;
            SettingsBaseTab.Visible = false;
            
        }



        public static bool IsInjected(int timeoutMilliseconds = 500)
        {
            string fullPipeName = "Ura_nium_3hQP9w9sJtEsxjL0KP4ip95C1mkrzB7B333wmfa8BUhZC5K1vU";
            using (var pipeClient = new NamedPipeClientStream(".", fullPipeName, PipeDirection.InOut))
            {
                var connectTask = pipeClient.ConnectAsync(timeoutMilliseconds);
                connectTask.Wait(timeoutMilliseconds);

                if (pipeClient.IsConnected)
                    return true;
            }
            return false;
        }



        public async Task<string> GetText()
        {
            string result = await webView21.CoreWebView2.ExecuteScriptAsync("editor.getValue()");
            return JsonConvert.DeserializeObject<string>(result);
        }

        private async void guna2Button11_Click(object sender, EventArgs e)
        {
            using (var pipeClient = new NamedPipeClientStream(".", "Ura_nium_3hQP9w9sJtEsxjL0KP4ip95C1mkrzB7B333wmfa8BUhZC5K1vU", PipeDirection.Out))
            {
                try
                {
                    await pipeClient.ConnectAsync();

                    byte[] scriptBytes = Encoding.UTF8.GetBytes(await GetText());

                    await pipeClient.WriteAsync(scriptBytes, 0, scriptBytes.Length);

                    pipeClient.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error executing script: {ex.Message}");
                }
            }
        }



        private async void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void webView21_Click(object sender, EventArgs e)
        {

        }

        private async void guna2Button12_Click(object sender, EventArgs e)
        {
            await webView21.ExecuteScriptAsync("editor.setValue('');");
        }

        private async void guna2Button13_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Lua files (*.lua)|*.lua|Text files (*.txt)|*.txt|All files (*.*)|*.*";
                ofd.Title = "Open File";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    string fileContent = File.ReadAllText(ofd.FileName);


                    string safeContent = fileContent.Replace("\\", "\\\\").Replace("'", "\\'").Replace("\r", "").Replace("\n", "\\n");


                    await webView21.ExecuteScriptAsync($"editor.setValue('{safeContent}');");
                }
            }
        }

        private async void guna2Button14_Click(object sender, EventArgs e)
        {
            string result = await webView21.ExecuteScriptAsync("editor.getValue();");
            if (result.StartsWith("\"") && result.EndsWith("\""))
            {
                result = result.Substring(1, result.Length - 2);
            }
            string editorText = Regex.Unescape(result);

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Lua files (*.lua)|*.lua|Text files (*.txt)|*.txt|All files (*.*)|*.*";
                sfd.Title = "Save File";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(sfd.FileName, editorText);
                }
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
        }

        private void guna2Button15_Click(object sender, EventArgs e)
        {

        }

        private async void guna2Button15_Click_1(object sender, EventArgs e)
        {
            if (IsInjected())
            {
                MessageBox.Show("Already Injected");
            }
            else
            {
                Process.Start("uranium_injector.exe");
            }
        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click_1(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private async void guna2Button8_Click(object sender, EventArgs e)
        {
            // 1. Get code from Monaco inside WebView2
            string code = await webView21.ExecuteScriptAsync("editor.getValue();");
            code = code.Trim('"').Replace("\\n", "\n").Replace("\\\"", "\""); // clean JSON escape chars

            // 2. Create folder if not exists
            string folderPath = Path.Combine(Application.StartupPath, "Debug", "Scripts");
            if (!Directory.Exists(folderPath))
                Directory.CreateDirectory(folderPath);

            // 3. Auto filename (now .lua instead of .txt)
            string fileName = $"Script_{savedFiles.Count + 1}.lua";
            string filePath = Path.Combine(folderPath, fileName);

            // 4. Save file
            File.WriteAllText(filePath, code);

            // 5. Add entry to dictionary + Explorer
            savedFiles[fileName] = filePath;

            var entry = CreateFileEntry(fileName, filePath);
            guna2ShadowPanel1.Controls.Add(entry);
            guna2ShadowPanel1.Controls.SetChildIndex(entry, 0);
        }

        private Control CreateFileEntry(string fileName, string filePath)
        {
            // 🔹 Create new file button
            var fileBtn = new Guna.UI2.WinForms.Guna2Button
            {
                Text = fileName, // already ends with .lua
                Size = new Size(90, 25),
                Font = ScriptButton.Font,
                FillColor = ScriptButton.FillColor,
                ForeColor = ScriptButton.ForeColor,
                BorderRadius = ScriptButton.BorderRadius,
                BorderColor = ScriptButton.BorderColor,
                BorderThickness = ScriptButton.BorderThickness,
                Animated = ScriptButton.Animated,

                HoverState =
        {
            FillColor = ScriptButton.HoverState.FillColor,
            ForeColor = ScriptButton.HoverState.ForeColor,
            BorderColor = ScriptButton.HoverState.BorderColor
        },
                CheckedState =
        {
            FillColor = ScriptButton.CheckedState.FillColor,
            ForeColor = ScriptButton.CheckedState.ForeColor,
            BorderColor = ScriptButton.CheckedState.BorderColor
        },
                DisabledState =
        {
            FillColor = ScriptButton.DisabledState.FillColor,
            ForeColor = ScriptButton.DisabledState.ForeColor,
            BorderColor = ScriptButton.DisabledState.BorderColor
        },

                Image = ScriptButton.Image,
                ImageSize = ScriptButton.ImageSize,
                ImageAlign = ScriptButton.ImageAlign,
                TextAlign = ScriptButton.TextAlign,
                TextOffset = ScriptButton.TextOffset,
                ShadowDecoration = { Enabled = ScriptButton.ShadowDecoration.Enabled },

                Anchor = AnchorStyles.Left | AnchorStyles.Top,
                Margin = new Padding(5),
                Location = new Point(5, guna2ShadowPanel1.Controls.Count * 30 + 5)
            };

            // 🔹 Click = load file back into Monaco
            fileBtn.Click += async (s, e) =>
            {
                string content = File.ReadAllText(filePath);
                content = content.Replace("\\", "\\\\").Replace("'", "\\'").Replace("\r", "").Replace("\n", "\\n");
                await webView21.ExecuteScriptAsync($"editor.setValue('{content}');");
            };

            // 🔹 Double-click = rename (only name, not extension)
            fileBtn.DoubleClick += (s, e) =>
            {
                string baseName = Path.GetFileNameWithoutExtension(fileName);

                var txtRename = new Guna.UI2.WinForms.Guna2TextBox
                {
                    Text = baseName, // show only name, not extension
                    Size = fileBtn.Size,
                    Location = fileBtn.Location,
                    Font = fileBtn.Font,
                    ForeColor = fileBtn.ForeColor,
                    FillColor = Color.FromArgb(30, 30, 30),
                    BorderRadius = fileBtn.BorderRadius,
                    BorderThickness = 0
                };

                fileBtn.Parent.Controls.Add(txtRename);
                txtRename.BringToFront();
                txtRename.Focus();

                txtRename.KeyDown += (s2, e2) =>
                {
                    if (e2.KeyCode == Keys.Enter)
                    {
                        string newName = txtRename.Text.Trim();
                        if (!string.IsNullOrEmpty(newName))
                        {
                            string newFileName = newName + ".lua";
                            string newPath = Path.Combine(Path.GetDirectoryName(filePath), newFileName);

                            if (File.Exists(filePath))
                                File.Move(filePath, newPath);

                            savedFiles.Remove(fileName);
                            savedFiles[newFileName] = newPath;

                            fileBtn.Text = newFileName;
                            fileName = newFileName; // update local reference
                            filePath = newPath;

                            txtRename.Dispose();
                        }
                    }
                    else if (e2.KeyCode == Keys.Escape)
                    {
                        txtRename.Dispose();
                    }
                };
            };

            return fileBtn;
        }

        // 🔹 Save all files automatically when form closes
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (var kv in savedFiles)
            {
                string filePath = kv.Value;
                if (File.Exists(filePath))
                {
                    var task = webView21.ExecuteScriptAsync("editor.getValue();");
                    task.Wait();
                    string code = task.Result;
                    code = code.Trim('"').Replace("\\n", "\n").Replace("\\\"", "\"");

                    File.WriteAllText(filePath, code);
                }
            }
        }

        private void guna2ShadowPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private async void guna2Button10_Click(object sender, EventArgs e)
        {

            label34.Visible = true;


            int iterations = 4; 
            for (int i = 0; i < iterations; i++)
            {
                label34.Text = "Refreshing.";
                await Task.Delay(500);
                label34.Text = "Refreshing..";
                await Task.Delay(500);
                label34.Text = "Refreshing...";
                await Task.Delay(500);
            }

    
            label34.Visible = false;

        }

        private void label34_Click(object sender, EventArgs e)
        {

        }



        async void SmoothShowButton(Guna.UI2.WinForms.Guna2Button btn)
        {
            btn.Visible = true;
            for (int a = 0; a <= 255; a += 25)
            {
                btn.ForeColor = Color.FromArgb(a, btn.ForeColor);
                await Task.Delay(10);
            }
        }





        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            string searchText = guna2TextBox1.Text.Trim().ToLower();

            foreach (Control ctrl in guna2ShadowPanel1.Controls)
            {
                if (ctrl is Guna.UI2.WinForms.Guna2Button btn)
                {

                    bool matches = btn.Text.ToLower().Contains(searchText);

    
                    if (matches)
                    {
                        btn.Visible = true;
                        btn.BringToFront(); 
                    }
                    else
                    {
                        btn.Visible = false;
                    }
                }
            }
        }

        private void guna2Button16_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(new ProcessStartInfo
            {
                FileName = "https://discord.gg/HrDyqZtdnj",
                UseShellExecute = true
            });
        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            SettingsBaseTab.BringToFront();
            SettingsBaseTab.Visible = true;
        }

        private void label53_Click(object sender, EventArgs e)
        {

        }

        private void label52_Click(object sender, EventArgs e)
        {

        }

        private void label54_Click(object sender, EventArgs e)
        {

        }

        private void label55_Click(object sender, EventArgs e)
        {

        }

        private void label53_Click_1(object sender, EventArgs e)
        {

        }

        private void label52_Click_1(object sender, EventArgs e)
        {

        }

        private void label54_Click_1(object sender, EventArgs e)
        {

        }

        private void label55_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Panel12_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label46_Click(object sender, EventArgs e)
        {

        }

        private void label51_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel11_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2PictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button17_Click(object sender, EventArgs e)
        {
            if (guna2Button17.Text == "Enable")
            {
                guna2Button17.Text = "Disable";
                this.TopMost = true;   // Keep window always on top
            }
            else
            {
                guna2Button17.Text = "Enable";
                this.TopMost = false;  // Turn off always on top
            }
        }

        private void guna2Button19_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button19_Click_1(object sender, EventArgs e)
        {
            if (guna2Button19.Text == "Enable")
            {
                guna2Button19.Text = "Disable";
                HiddenPanel.Visible = true;
                HiddenPanel.BringToFront();
            }
            else
            {
                guna2Button19.Text = "Enable";
                HiddenPanel.Visible = false;
                guna2Panel8.Visible = true;
            }
        }

        private void guna2Button20_Click(object sender, EventArgs e)
        {
            try
            {
                // Kill all Roblox processes
                foreach (var process in Process.GetProcessesByName("RobloxPlayerBeta"))
                {
                    process.Kill();
                    process.WaitForExit();
                }

                // Path to Roblox Player (default install location)
                string robloxPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    @"Roblox\Versions"
                );

                // Get latest Roblox version folder
                string latestVersion = Directory.GetDirectories(robloxPath)
                    .OrderByDescending(d => Directory.GetCreationTime(d))
                    .FirstOrDefault();

                if (!string.IsNullOrEmpty(latestVersion))
                {
                    string exePath = Path.Combine(latestVersion, "RobloxPlayerBeta.exe");

                    if (File.Exists(exePath))
                    {
                        Process.Start(exePath); // Reopen Roblox
                    }
                    else
                    {
                        MessageBox.Show("Roblox executable not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Could not find Roblox installation folder.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error restarting Roblox: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private bool lastInjectedState = false;

        private void CheckInjection()
        {
            bool currentState = IsInjected();

            if (currentState != lastInjectedState) // only update when state changes
            {
                if (currentState)
                {
                    guna2PictureBox8.BringToFront();
                    guna2PictureBox8.Visible = true;
                    guna2PictureBox7.Visible = false;
                }
                else
                {
                    guna2PictureBox7.BringToFront();
                    guna2PictureBox8.Visible = false;
                    guna2PictureBox7.Visible = true;
                }

                lastInjectedState = currentState;
            }
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            CheckInjection();
        }

        private void guna2Panel15_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
