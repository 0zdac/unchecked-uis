﻿using Guna.UI2.WinForms;
using KeyAuth;
using Newtonsoft.Json.Linq;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace void_executor
{
    public partial class loginpage : Form
    {
        private double opacityStep = 0.03;
        private int minimizeTargetY;
        private double minimizeOpacityStep;

        public static api KeyAuthApp = new api(
            name: "Uranium",
            ownerid: "OSLP46kINd",
            version: "1.0"
        );

        private string savePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "void_executor_login.json"
        );

        private string keyStoragePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "void_executor_keys.json"
        );

        public loginpage()
        {
            InitializeComponent();
            KeyAuthApp.init();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Opacity = 0;

            if (KeyAuthApp.response.success)
                Debug.WriteLine("KeyAuthApp Connected");
            else
                Debug.WriteLine("KeyAuthApp Failed Connection");
        }

        private async void loginpage_Load(object sender, EventArgs e)
        {
            await KeyAuthApp.init();

            guna2TextBox1.UseSystemPasswordChar = false;
            guna2TextBox1.PasswordChar = '•';
            guna2TextBox1.ForeColor = Color.FromArgb(70, 70, 70);
            this.TopMost = true;

            LoadSavedLogin();

            await Task.Delay(100);
            while (this.Opacity < 1)
            {
                this.Opacity += 0.05;
                await Task.Delay(3);
            }
        }

        private void LoadSavedLogin()
        {
            if (!File.Exists(savePath)) return;
            try
            {
                string json = File.ReadAllText(savePath);
                JObject data = JObject.Parse(json);
                bool remember = data.Value<bool>("Remember");
                string savedLogin = data.Value<string>("Login");
                guna2Button2.Checked = remember;
                if (remember && !string.IsNullOrEmpty(savedLogin))
                {
                    guna2TextBox1.Text = savedLogin;
                }
            }
            catch { }
        }

        private void SaveLogin()
        {
            try
            {
                var data = new JObject
                {
                    ["Remember"] = guna2Button2.Checked,
                    ["Login"] = guna2Button2.Checked ? guna2TextBox1.Text : ""
                };
                File.WriteAllText(savePath, data.ToString());
            }
            catch { }
        }

        private void guna2Button2_CheckedChanged(object sender, EventArgs e)
        {
            SaveLogin();
        }

        private void loginpage_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveLogin();
        }

        private static string GetUserIdFromUsername(string username)
        {
            string url = "https://users.roblox.com/v1/usernames/users";
            string json = $"{{\"usernames\": [\"{username}\"]}}";
            try
            {
                using (var client = new WebClient())
                {
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    string response = client.UploadString(url, "POST", json);
                    JObject data = JObject.Parse(response);
                    if (data["data"] != null && data["data"].HasValues)
                    {
                        string userId = data["data"][0]["id"].ToString();
                        return userId;
                    }
                }
            }
            catch { }
            return null;
        }

        public static System.Drawing.Image GetAvatar(string username)
        {
            string userId = GetUserIdFromUsername(username);
            if (string.IsNullOrEmpty(userId))
                return null;
            string avatarUrl = $"https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={userId}&size=420x420&format=png";
            try
            {
                using (var client = new WebClient())
                {
                    string response = client.DownloadString(avatarUrl);
                    JObject data = JObject.Parse(response);
                    if (data["data"] != null && data["data"].HasValues)
                    {
                        string imageUrl = data["data"][0]["imageUrl"].ToString();
                        byte[] imageBytes = client.DownloadData(imageUrl);
                        using (var ms = new MemoryStream(imageBytes))
                        {
                            return System.Drawing.Image.FromStream(ms);
                        }
                    }
                }
            }
            catch { }
            return null;
        }

        public static string GetUsername()
        {
            return Environment.UserName;
        }

        private bool IsKeyRegisteredToAnotherUser(string key, string currentUser)
        {
            if (!File.Exists(keyStoragePath)) return false;
            try
            {
                string json = File.ReadAllText(keyStoragePath);
                JObject data = JObject.Parse(json);
                if (data.ContainsKey(key))
                {
                    string registeredUser = data[key].ToString();
                    if (registeredUser != currentUser)
                    {
                        return true;
                    }
                }
            }
            catch { }
            return false;
        }

        private void RegisterKeyToUser(string key, string currentUser)
        {
            JObject data = new JObject();
            if (File.Exists(keyStoragePath))
            {
                try
                {
                    data = JObject.Parse(File.ReadAllText(keyStoragePath));
                }
                catch { }
            }
            data[key] = currentUser;
            File.WriteAllText(keyStoragePath, data.ToString());
        }

        private async void guna2Button3_Click(object sender, EventArgs e)
        {
            SaveLogin();
            await KeyAuthApp.license(guna2TextBox1.Text);

            if (KeyAuthApp.response.success)
            {
                this.Hide();
                Form1 form1 = new Form1();
                form1.StartPosition = FormStartPosition.CenterScreen;
                form1.Opacity = 0;
                form1.Show();

                while (form1.Opacity < 1)
                {
                    form1.Opacity += 0.05;
                    await Task.Delay(10);
                }
            }
            else
            {
                Color originalColor = guna2TextBox1.ForeColor;
                guna2TextBox1.Text = "INVALID_KEY";
                guna2TextBox1.ForeColor = Color.FromArgb(123, 45, 38);
                await Task.Delay(1000);
                guna2TextBox1.Clear();
                guna2TextBox1.ForeColor = originalColor;
            }
        }

        bool isPasswordVisible = false;

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            if (isPasswordVisible)
            {
                guna2TextBox1.UseSystemPasswordChar = false;
                guna2TextBox1.PasswordChar = '•';
                isPasswordVisible = false;
            }
            else
            {
                guna2TextBox1.UseSystemPasswordChar = false;
                guna2TextBox1.PasswordChar = '\0';
                isPasswordVisible = true;
            }
            guna2TextBox1.Refresh();
        }

        private async void guna2Button1_Click_1(object sender, EventArgs e)
        {
            SaveLogin();
            while (this.Opacity > 0)
            {
                this.Opacity -= 0.1;
                await Task.Delay(10);
            }
            Application.Exit();
        }

        private void guna2Button16_Click(object sender, EventArgs e) { }
        private void guna2TextBox1_TextChanged(object sender, EventArgs e) { }

        // Remember Me button
        private async void guna2Button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(guna2TextBox1.Text))
            {
                MessageBox.Show("Please enter a key first.", "No Key", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string inputKey = guna2TextBox1.Text;

            // Validate before saving
            await KeyAuthApp.license(inputKey);

            if (KeyAuthApp.response.success)
            {
                try
                {
                    var data = new JObject
                    {
                        ["Remember"] = true,
                        ["Login"] = inputKey
                    };

                    File.WriteAllText(savePath, data.ToString());

                    guna2Button2.Checked = true;
   
                }
                catch
                {
         
                }
            }
            else
            {
          
            }
        }

        private void guna2CustomGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
